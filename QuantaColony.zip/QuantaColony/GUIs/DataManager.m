classdef DataManager < handle
    properties (Access = public)
        Data                    % In-memory data store
        CurrentProject          % Current active project name
        ProjectData             % Structure to hold data for multiple projects
        ConfigFile              % Path to the configuration file
        ProjectPaths            % Structure to hold project paths
        IsInProjectSelection    % Flag to indicate if we're in ProjectSelection
        LoadedProjects
        CombinedProjectCache
    end
    
    properties (Access = private)
        CommandWindow           % Reference to CommandWindowApp instance
        LoadedStates
    end
    
    methods (Access = public, Static)
               function dm = getInstance()
            persistent dataManagerInstance;
            if isempty(dataManagerInstance) || ~isvalid(dataManagerInstance)
                dataManagerInstance = DataManager();
            end
            dm = dataManagerInstance;
            
            % Only check combined status if not already cached
            if ~isempty(dm.CurrentProject) && ...
               (~isfield(dm.CombinedProjectCache, dm.CurrentProject) || ...
                isempty(dm.CombinedProjectCache.(dm.CurrentProject)))
                try
                    dm.determineIfCombinedProject();
                catch e
                    warning('Failed to determine if project is combined: %s', e.message);
                end
            end
        end
    end
    
    methods (Access = public)
        function loadConfig(obj)
    if exist(obj.ConfigFile, 'file')
        % Normal loading path - config exists
        loadedData = load(obj.ConfigFile);
        obj.ProjectPaths = loadedData.ProjectPaths;
        if isfield(loadedData, 'CurrentProject')
            obj.CurrentProject = loadedData.CurrentProject;
        else
            obj.CurrentProject = '';
            warning('No CurrentProject found in config file. Please set a current project.');
        end
    else
        % Auto-initialization path - config doesn't exist
        obj.ensureCommandWindowVisible();
        obj.CommandWindow.display('Configuration file not found. Creating default configuration...');
        
        % Initialize empty structures
        obj.ProjectPaths = struct();
        obj.CurrentProject = '';
        
        % Create parent directory if it doesn't exist
        configDir = fileparts(obj.ConfigFile);
        if ~exist(configDir, 'dir')
            [success, msg] = mkdir(configDir);
            if ~success
                error(['Failed to create directory for config file: ' msg]);
            end
        end
        
        % Create ProjectRoots folder if needed
        rootDir = fileparts(configDir);
        projectRootsDir = fullfile(rootDir, 'ProjectRoots');
        if ~exist(projectRootsDir, 'dir')
            [success, msg] = mkdir(projectRootsDir);
            if ~success
                warning(['Failed to create ProjectRoots directory: ' msg]);
            else
                obj.CommandWindow.display(['Created ProjectRoots folder at: ' projectRootsDir]);
            end
        end
        
        % Save the default config
        obj.saveConfig();
        obj.CommandWindow.display(['Created default configuration file at: ' obj.ConfigFile]);
    end
end

        function determineIfCombinedProject(obj)
    if isempty(obj.CurrentProject)
        error('No current project set. Use setCurrentProject first.');
    end
    
    validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
    
    % Check cache first
    if isfield(obj.CombinedProjectCache, validProjectName)
        return;
    end
    
    if ~isfield(obj.ProjectData, validProjectName) || ...
       ~isfield(obj.ProjectData.(validProjectName), 'BaseFolder') || ...
       isempty(obj.ProjectData.(validProjectName).BaseFolder)
        error('BaseFolder is not defined or is empty for the current project');
    end
    
    baseFolder = obj.ProjectData.(validProjectName).BaseFolder;
    markerPath = fullfile(baseFolder, '.combination_marker.json');
    
    % Check if marker file exists
    isCombined = exist(markerPath, 'file') == 2;
    
    % Optionally, validate the content
    if isCombined
        try
            markerData = jsondecode(fileread(markerPath));
            isCombined = isfield(markerData, 'isCombined') && markerData.isCombined;
        catch
            isCombined = false;
        end
    end
    
    % Cache the result
    obj.CombinedProjectCache.(validProjectName) = isCombined;
    obj.ProjectData.(validProjectName).IsCombined = isCombined;
    
    obj.ensureCommandWindowVisible();
    obj.CommandWindow.display(['Current project is combined: ' string(isCombined)]);
end
        function loadProjectData(obj, projectName)
            obj.ensureCommandWindowVisible();
            validProjectName = matlab.lang.makeValidName(projectName);
            
            % Check if already loaded
            if isfield(obj.LoadedStates, validProjectName) && ...
               obj.LoadedStates.(validProjectName)
                return;
            end
            
            workspaceFolder = obj.getProjectPath(validProjectName);
            if isempty(workspaceFolder)
                error('Workspace folder not found for project: %s', projectName);
            end

            % Use dir with specific pattern to avoid loading unnecessary files
            stateFiles = dir(fullfile(workspaceFolder, 'DataManagerState_*.mat'));
            if isempty(stateFiles)
                warning('No DataManagerState files found for project %s. Initializing empty project data.', projectName);
                obj.ProjectData.(validProjectName) = struct();
                obj.LoadedStates.(validProjectName) = true;
                
                return;
            end

            % Sort dates more efficiently using array operations
            dates = [stateFiles.datenum];
            [~, idx] = max(dates);
            latestFile = stateFiles(idx);
            
            try
                stateFilename = fullfile(workspaceFolder, latestFile.name);
                stateData = load(stateFilename, '-mat');
                obj.ProjectData.(validProjectName) = stateData;
                obj.LoadedStates.(validProjectName) = true;
            catch ME
                warning('Failed to load latest state file. Error: %s', ME.message);
                obj.deleteCorruptedFile(stateFilename);
                obj.ProjectData.(validProjectName) = struct();
                obj.LoadedStates.(validProjectName) = true;
            end
            obj.validateAndUpdateProjectPaths(validProjectName);
        end
        function validateAndUpdateProjectPaths(obj, validProjectName)
    % CONTROLLER: Validate and update individual project paths when needed
    % Following strict nested MVC - MODEL/VIEW functions are terminal
    
    obj.ensureCommandWindowVisible();
    
    % === COORDINATE SUB-CONTROLLERS ===
    
    % Identify which specific paths need updating
    pathUpdates = identifyIncorrectPaths(obj, validProjectName);
    
    % Update only the incorrect paths
    if pathUpdates.hasUpdates
        updateIncorrectPaths(obj, validProjectName, pathUpdates);
        
        % Validate that all paths exist on disk
        validatePathExistence(obj, validProjectName);
        
        % Save both project data and config with updated paths
        saveUpdatedData(obj, validProjectName);
    else
        % Still validate existence even if no updates needed
        validatePathExistence(obj, validProjectName);
    end
    
    % === SUB-CONTROLLERS ===
    
    function pathUpdates = identifyIncorrectPaths(obj, validProjectName)
        % SUB-CONTROLLER: Identify which specific paths need updating
        
        % Calculate what all paths should be
        correctPaths = calculateCorrectPaths(obj, validProjectName);
        
        % Compare each stored path against correct path
        incorrectPaths = compareStoredVsCorrectPaths(obj, validProjectName, correctPaths);
        
        % Log the comparison results
        logPathComparison(obj, incorrectPaths);
        
        pathUpdates = incorrectPaths;
        
        function correctPaths = calculateCorrectPaths(obj, validProjectName)
            % MODEL: Calculate what all paths should be based on current program location (TERMINAL)
            programFolder = fileparts(obj.ConfigFile);
            
            % Get project name for path construction
            if isfield(obj.ProjectData.(validProjectName), 'experimentConfig') && ...
               isfield(obj.ProjectData.(validProjectName).experimentConfig, 'projectName')
                projectName = obj.ProjectData.(validProjectName).experimentConfig.projectName;
            else
                error('experimentConfig.projectName not found in project data for %s', validProjectName);
            end
            
            correctPaths = struct();
            correctPaths.ProgramFolder = programFolder;
            correctPaths.ProjectRootsFolder = fullfile(programFolder, 'ProjectRoots');
            correctPaths.GUIFolder = fullfile(programFolder, 'GUIs');
            correctPaths.BaseFolder = fullfile(programFolder, 'ProjectRoots', projectName);
            correctPaths.DataTablePath = fullfile(programFolder, 'ProjectRoots', projectName, 'Workspace', [projectName '_CompleteCompiledData.xlsx']);
            correctPaths.HistogramsFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Histograms');
            correctPaths.IconFolder = fullfile(programFolder, 'GUIs', 'Icons');
            correctPaths.InputFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Input');
            correctPaths.MidputFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Midput');
            correctPaths.OutputFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Output');
            correctPaths.PlotsFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Plots');
            correctPaths.StatsFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Stats');
            correctPaths.WorkspaceFolder = fullfile(programFolder, 'ProjectRoots', projectName, 'Workspace');
        end
        
        function incorrectPaths = compareStoredVsCorrectPaths(obj, validProjectName, correctPaths)
            % MODEL: Compare each stored path against what it should be (TERMINAL)
            incorrectPaths = struct();
            incorrectPaths.hasUpdates = false;
            incorrectPaths.correctPaths = correctPaths;
            incorrectPaths.pathsToUpdate = {};
            incorrectPaths.updatedValues = struct();
            
            pathFields = fieldnames(correctPaths);
            projectData = obj.ProjectData.(validProjectName);
            
            for i = 1:length(pathFields)
                fieldName = pathFields{i};
                correctValue = correctPaths.(fieldName);
                
                % Check if field exists in project data and if it matches
                if isfield(projectData, fieldName)
                    storedValue = projectData.(fieldName);
                    if ~strcmp(storedValue, correctValue)
                        incorrectPaths.hasUpdates = true;
                        incorrectPaths.pathsToUpdate{end+1} = fieldName;
                        incorrectPaths.updatedValues.(fieldName) = correctValue;
                    end
                else
                    % Field doesn't exist, needs to be added
                    incorrectPaths.hasUpdates = true;
                    incorrectPaths.pathsToUpdate{end+1} = fieldName;
                    incorrectPaths.updatedValues.(fieldName) = correctValue;
                end
            end
        end
        
        function logPathComparison(obj, incorrectPaths)
            % VIEW: Log the path comparison results (TERMINAL)
            if incorrectPaths.hasUpdates
                obj.CommandWindow.display(['Path validation: Found ' num2str(length(incorrectPaths.pathsToUpdate)) ' paths that need updating']);
                for i = 1:length(incorrectPaths.pathsToUpdate)
                    fieldName = incorrectPaths.pathsToUpdate{i};
                    obj.CommandWindow.display(['  Updating: ' fieldName]);
                end
            else
                obj.CommandWindow.display('Path validation: All paths are correct');
            end
        end
    end
    
    function updateIncorrectPaths(obj, validProjectName, pathUpdates)
        % SUB-CONTROLLER: Update only the incorrect paths
        
        % Apply updates to project data
        applyPathUpdates(obj, validProjectName, pathUpdates);
        
        % Update config file workspace path if needed
        updateConfigWorkspacePath(obj, validProjectName, pathUpdates);
        
        function applyPathUpdates(obj, validProjectName, pathUpdates)
            % VIEW: Apply path updates to project data (TERMINAL)
            pathsToUpdate = pathUpdates.pathsToUpdate;
            updatedValues = pathUpdates.updatedValues;
            
            for i = 1:length(pathsToUpdate)
                fieldName = pathsToUpdate{i};
                newValue = updatedValues.(fieldName);
                obj.ProjectData.(validProjectName).(fieldName) = newValue;
                obj.CommandWindow.display(['  Applied update: ' fieldName ' = ' newValue]);
            end
        end
        
        function updateConfigWorkspacePath(obj, validProjectName, pathUpdates)
            % VIEW: Update workspace folder path in config if it was changed (TERMINAL)
            if ismember('WorkspaceFolder', pathUpdates.pathsToUpdate)
                newWorkspaceFolder = pathUpdates.updatedValues.WorkspaceFolder;
                obj.ProjectPaths.(validProjectName) = newWorkspaceFolder;
                obj.CommandWindow.display(['  Updated config WorkspaceFolder: ' newWorkspaceFolder]);
            end
        end
    end
    
    function validatePathExistence(obj, validProjectName)
        % SUB-CONTROLLER: Validate that all paths exist
        
        % Determine if project is combined
        isCombined = checkIfProjectIsCombined(obj, validProjectName);
        
        % Get paths that need validation
        pathsToValidate = getPathsForValidation(obj, validProjectName, isCombined);
        
        % Check each path and collect missing ones
        missingPaths = checkPathExistence(pathsToValidate);
        
        % Handle validation results
        handleValidationResults(obj, missingPaths);
        
        function isCombined = checkIfProjectIsCombined(obj, validProjectName)
            % MODEL: Check if project is combined using updated logic (TERMINAL)
            if ~isfield(obj.ProjectData.(validProjectName), 'BaseFolder')
                isCombined = false;
                return;
            end
            
            baseFolder = obj.ProjectData.(validProjectName).BaseFolder;
            markerPath = fullfile(baseFolder, '.combination_marker.json');
            isCombined = exist(markerPath, 'file') == 2;
            
            % Optionally, validate the content
            if isCombined
                try
                    markerData = jsondecode(fileread(markerPath));
                    isCombined = isfield(markerData, 'isCombined') && markerData.isCombined;
                catch
                    isCombined = false;
                end
            end
        end
        
      
        function pathsToValidate = getPathsForValidation(obj, validProjectName, isCombined)
    % MODEL: Get list of paths that must exist (TERMINAL)
    % DataTablePath is intentionally excluded - it is an output artifact
    % generated by compilation, not a scaffold path required for project load.
    projectData = obj.ProjectData.(validProjectName);

    pathsToValidate = struct();
    % Folder paths (scaffolding required for project to be loadable)
    pathsToValidate.ProgramFolder = projectData.ProgramFolder;
    pathsToValidate.ProjectRootsFolder = projectData.ProjectRootsFolder;
    pathsToValidate.GUIFolder = projectData.GUIFolder;
    pathsToValidate.BaseFolder = projectData.BaseFolder;
    pathsToValidate.HistogramsFolder = projectData.HistogramsFolder;
    pathsToValidate.IconFolder = projectData.IconFolder;
    pathsToValidate.InputFolder = projectData.InputFolder;
    pathsToValidate.MidputFolder = projectData.MidputFolder;
    pathsToValidate.OutputFolder = projectData.OutputFolder;
    pathsToValidate.PlotsFolder = projectData.PlotsFolder;
    pathsToValidate.StatsFolder = projectData.StatsFolder;
    pathsToValidate.WorkspaceFolder = projectData.WorkspaceFolder;
end
        function missingPaths = checkPathExistence(pathsToValidate)
            % MODEL: Check which paths don't exist on disk (TERMINAL)
            missingPaths = {};
            pathFields = fieldnames(pathsToValidate);
            
            for i = 1:length(pathFields)
                fieldName = pathFields{i};
                path = pathsToValidate.(fieldName);
                
                % Check if it's a file or folder based on field name
                if strcmp(fieldName, 'DataTablePath')
                    % Check file existence
                    if ~exist(path, 'file')
                        missingPaths{end+1} = sprintf('%s (file): %s', fieldName, path);
                    end
                else
                    % Check folder existence
                    if ~exist(path, 'dir')
                        missingPaths{end+1} = sprintf('%s (folder): %s', fieldName, path);
                    end
                end
            end
        end
        
        function handleValidationResults(obj, missingPaths)
            % VIEW: Handle path validation results (TERMINAL)
            if ~isempty(missingPaths)
                obj.CommandWindow.display('ERROR: The following required paths do not exist:');
                for i = 1:length(missingPaths)
                    obj.CommandWindow.display(['  ' missingPaths{i}]);
                end
                
                % Create detailed error message with missing paths
                errorMsg = sprintf('Path validation failed: Required project paths are missing:\n');
                for i = 1:length(missingPaths)
                    errorMsg = [errorMsg, sprintf('  %s\n', missingPaths{i})];
                end
                error(errorMsg);
            else
                obj.CommandWindow.display('Path validation: All required paths exist');
            end
        end
    end
    
    function saveUpdatedData(obj, validProjectName)
        % SUB-CONTROLLER: Save both project data and config after updates
        
        % Save updated project data to state file
        saveProjectStateFile(obj, validProjectName);
        
        % Save updated config file
        saveConfigFile(obj);
        
        % Log completion
        logUpdateCompletion(obj);
        
        function saveProjectStateFile(obj, validProjectName)
            % VIEW: Save project data to new state file (TERMINAL)
            workspaceFolder = obj.ProjectData.(validProjectName).WorkspaceFolder;
            stateFilename = ['DataManagerState_PathUpdate_', validProjectName, '_', datestr(now, 'yyyymmdd_HHMMSS'), '.mat'];
            stateFullPath = fullfile(workspaceFolder, stateFilename);
            stateData = obj.ProjectData.(validProjectName);
            save(stateFullPath, '-struct', 'stateData', '-v7.3');
        end
        
        function saveConfigFile(obj)
            % VIEW: Save updated config file (TERMINAL)
            obj.saveConfig();
        end
        
        function logUpdateCompletion(obj)
            % VIEW: Log successful path update completion (TERMINAL)
            obj.CommandWindow.display('Path validation: Successfully updated and saved all paths');
        end
    end
end
        
        function obj = DataManager()
    obj.Data = struct();
    obj.ProjectData = struct();
    obj.ProjectPaths = struct();
    obj.IsInProjectSelection = false;
    obj.CombinedProjectCache = struct();
    obj.LoadedStates = struct();
    
    % Set up config file path
    currentFolder = fileparts(mfilename('fullpath')); % GUIs folder
    parentFolder = fileparts(currentFolder);          % QuantaColony root
    
    configFileName = 'Quanta_Colony_config.mat';
    possiblePaths = {currentFolder, parentFolder};
    
    % Check if config exists in possible paths
    configExists = cellfun(@(p) exist(fullfile(p, configFileName), 'file') == 2, possiblePaths);
    configIdx = find(configExists, 1);
    
    if ~isempty(configIdx)
        obj.ConfigFile = fullfile(possiblePaths{configIdx}, configFileName);
    else
        % Create config in parent folder (QuantaColony root)
        obj.ConfigFile = fullfile(parentFolder, configFileName);
        
        % Initialize with empty values
        obj.CurrentProject = '';
        
        % Ensure ProjectRoots folder exists
        projectRootsPath = fullfile(parentFolder, 'ProjectRoots');
        if ~exist(projectRootsPath, 'dir')
            [success, ~] = mkdir(projectRootsPath);
            if ~success
                warning('Failed to create ProjectRoots folder');
            end
        end
        
        % Save the initial config
        obj.saveConfig();
    end
    
    obj.loadConfig();
    
    if ~isempty(obj.CurrentProject)
        obj.loadProjectData(obj.CurrentProject);
    end

    obj.CommandWindow = CommandWindowApp.getInstance();
end
        % Add method for efficient batch loading of multiple files
        function batchLoadFiles(obj, folder, pattern)
            files = dir(fullfile(folder, pattern));
            if isempty(files)
                return;
            end
            
            % Preallocate cell array for efficiency
            data = cell(length(files), 1);
            validFiles = false(length(files), 1);
            
            % Load all files in parallel if Parallel Computing Toolbox is available
            if license('test', 'Distrib_Computing_Toolbox')
                parfor i = 1:length(files)
                    try
                        data{i} = load(fullfile(folder, files(i).name), '-mat');
                        validFiles(i) = true;
                    catch
                        validFiles(i) = false;
                    end
                end
            else
                for i = 1:length(files)
                    try
                        data{i} = load(fullfile(folder, files(i).name), '-mat');
                        validFiles(i) = true;
                    catch
                        validFiles(i) = false;
                    end
                end
            end
            
            % Merge valid data
            data = data(validFiles);
            % Process merged data as needed
        end
        

        function setCurrentProject(obj, projectName, workspaceFolder)
    obj.ensureCommandWindowVisible();
    validProjectName = matlab.lang.makeValidName(projectName);
    
    % If we already have a current project that's different from the new one,
    % unload it first to free up memory
    if ~isempty(obj.CurrentProject) && ~strcmp(obj.CurrentProject, validProjectName)
        obj.unloadProject(obj.CurrentProject);
    end
    
    % Unload any other projects that might be loaded (for project combination, etc.)
    if ~isempty(fieldnames(obj.LoadedStates))
        loadedProjects = fieldnames(obj.LoadedStates);
        for i = 1:length(loadedProjects)
            loadedProject = loadedProjects{i};
            % Skip the project we're about to load
            if ~strcmp(loadedProject, validProjectName) && obj.LoadedStates.(loadedProject)
                obj.unloadProject(loadedProject);
            end
        end
    end
    
    % Set the new current project
    obj.CurrentProject = validProjectName;
    obj.ProjectPaths.(validProjectName) = workspaceFolder;
    
    % Ensure ProjectData exists for the current project
    if ~isfield(obj.ProjectData, validProjectName)
        obj.ProjectData.(validProjectName) = struct();
    end
    
    % Explicitly save WorkspaceFolder and CombinedWorkspaceFolder to ProjectData
    obj.ProjectData.(validProjectName).WorkspaceFolder = workspaceFolder;
    obj.ProjectData.(validProjectName).CombinedWorkspaceFolder = workspaceFolder;
    
    % Save config before loading project data
    obj.saveConfig();
    
    % Load data for the new current project
    obj.loadProjectData(validProjectName);
    
    % Determine if the project is combined
    try
        obj.determineIfCombinedProject();
    catch e
        warning('Failed to determine if project is combined: %s', e.message);
    end
    
    obj.CommandWindow.display(['Set current project to: ' projectName]);
end

        function latestState = getLatestNonCorruptedState(obj, projectName)
    obj.ensureCommandWindowVisible();
    validProjectName = matlab.lang.makeValidName(projectName);
    workspaceFolder = obj.getProjectPath(validProjectName);
    
    if isempty(workspaceFolder)
        error('Workspace folder not found for project: %s', projectName);
    end

    % Get list of DataManagerState files
    stateFiles = dir(fullfile(workspaceFolder, 'DataManagerState_*.mat'));
    
    if isempty(stateFiles)
        warning('No DataManagerState files found for project %s.', projectName);
        latestState = [];
        return;
    end

    % Sort files by date (newest first)
    [~, idx] = sort([stateFiles.datenum], 'descend');
    sortedStateFiles = stateFiles(idx);

    % Try loading files until a non-corrupted one is found
    for i = 1:length(sortedStateFiles)
        stateFilePath = fullfile(workspaceFolder, sortedStateFiles(i).name);
        try
            stateData = load(stateFilePath);
            latestState = stateData;
            obj.CommandWindow.display(['Loaded non-corrupted state file: ' sortedStateFiles(i).name]);
            return;
        catch ME
            warning('Failed to load file %s. Error: %s', stateFilePath, ME.message);
            obj.deleteCorruptedFile(stateFilePath);
        end
    end

    % If all files are corrupted
    warning('All DataManagerState files for project %s are corrupted.', projectName);
    latestState = [];
end
        
        function saveInitializationState(obj)
    obj.ensureCommandWindowVisible();
    if isempty(obj.CurrentProject)
        error('No current project set. Use setCurrentProject first.');
    end
    
    validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
    
    % More detailed error checking
    if ~isfield(obj.ProjectData, validProjectName)
        error('Project data not found for current project: %s', obj.CurrentProject);
    end
    
    % Use the WorkspaceFolder from ProjectData
    if isfield(obj.ProjectData.(validProjectName), 'WorkspaceFolder')
        workspaceFolder = obj.ProjectData.(validProjectName).WorkspaceFolder;
  
    else
        error('WorkspaceFolder is not set for the current project: %s', obj.CurrentProject);
    end
    
    if isempty(workspaceFolder)
        error('Workspace folder not set for the current project.');
    end
    
    stateFilename = ['DataManagerState_Initialization_', validProjectName, '_', datestr(now, 'yyyymmdd_HHMMSS'), '.mat'];
    stateFullPath = fullfile(workspaceFolder, stateFilename);
    
    % Ensure the workspace folder exists
    if ~exist(workspaceFolder, 'dir')
        [success, msg] = mkdir(workspaceFolder);
        if ~success
            error(['Failed to create workspace folder: ' msg]);
        end
      
    end
    
    % Prepare the state data
    stateData = obj.ProjectData.(validProjectName);
    
    % Ensure WorkspaceFolder is included in the state
    stateData.WorkspaceFolder = workspaceFolder;
    
    % Save the state file
    try
        save(stateFullPath, '-struct', 'stateData', '-v7.3');
       
    catch saveError
        error(['Failed to save initialization state: ' saveError.message]);
    end
    
    % Update the ProjectData with the latest state
    obj.ProjectData.(validProjectName) = stateData;
    
    % Save the config to ensure it's up to date
    obj.saveConfig();
    
   
end
 
        function saveToDataManager(obj, varName, value)
            obj.ensureCommandWindowVisible();
            if isempty(obj.CurrentProject)
                error('No current project set. Use setCurrentProject first.');
            end
            validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
            obj.ProjectData.(validProjectName).(varName) = value;
           
        end

        function value = getFromDataManager(obj, varName)
            obj.ensureCommandWindowVisible();
            if isempty(obj.CurrentProject)
                error('No current project set. Use setCurrentProject first.');
            end
            validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
            if isfield(obj.ProjectData, validProjectName) && isfield(obj.ProjectData.(validProjectName), varName)
                value = obj.ProjectData.(validProjectName).(varName);
            else
                error('Property %s does not exist for project %s.', varName, obj.CurrentProject);
            end
        end
    
        function loadedProjects = loadMultipleProjects(obj, projectNames, workspaceFolders, temporaryLoad)
    % loadMultipleProjects Loads data from multiple projects efficiently
    %
    % Parameters:
    %   projectNames - Cell array of project names to load
    %   workspaceFolders - Cell array of workspace folder paths
    %   temporaryLoad - (Optional) If true, unload projects after returning (default: false)
    %
    % Returns:
    %   loadedProjects - Struct containing loaded project data
    
    obj.ensureCommandWindowVisible();
    
    % Process optional arguments
    if nargin < 4
        temporaryLoad = false;
    end
    
    loadedProjects = struct();
    projectsLoaded = {};
    
    for i = 1:length(projectNames)
        projectName = projectNames{i};
        workspaceFolder = workspaceFolders{i};
        validProjectName = matlab.lang.makeValidName(projectName);
        
        % Check if project is already loaded
        alreadyLoaded = isfield(obj.ProjectData, validProjectName) && ...
                        isfield(obj.LoadedStates, validProjectName) && ...
                        obj.LoadedStates.(validProjectName);
        
        if alreadyLoaded
            % Use existing data
            loadedProjects.(validProjectName) = obj.ProjectData.(validProjectName);
            obj.CommandWindow.display(['Using cached data for project: ' projectName]);
        else
            % Load from file
            stateFiles = dir(fullfile(workspaceFolder, 'DataManagerState_*.mat'));
            if ~isempty(stateFiles)
                % Find the latest state file
                [~, idx] = sort([stateFiles.datenum], 'descend');
                latestStateFile = fullfile(workspaceFolder, stateFiles(idx(1)).name);
                
                try
                    % Load the data
                    stateData = load(latestStateFile);
                    loadedProjects.(validProjectName) = stateData;
                    
                    % Update tracking structures
                    obj.ProjectData.(validProjectName) = stateData;
                    obj.LoadedStates.(validProjectName) = true;
                    obj.ProjectPaths.(validProjectName) = workspaceFolder;
                    
                    % Add to list of projects loaded in this call
                    projectsLoaded{end+1} = validProjectName;
                    
                    obj.CommandWindow.display(['Loaded data for project: ' projectName]);
                catch ME
                    warning('Failed to load data for project %s. Error: %s', projectName, ME.message);
                    obj.deleteCorruptedFile(latestStateFile);
                    loadedProjects.(validProjectName) = struct();
                end
            else
                warning('No state files found for project %s.', projectName);
                loadedProjects.(validProjectName) = struct();
            end
        end
    end
    
    % Clean up if temporaryLoad is enabled
    if temporaryLoad && ~isempty(projectsLoaded)
        for i = 1:length(projectsLoaded)
            obj.unloadProject(projectsLoaded{i});
        end
        obj.CommandWindow.display('Temporary project data unloaded after returning results');
    end
end
        
        function ensureCommandWindowVisible(obj)
            if ~isempty(obj.CommandWindow) && isvalid(obj.CommandWindow)
                obj.CommandWindow.ensureVisible();
            else
                obj.CommandWindow = CommandWindowApp.getInstance();
                obj.CommandWindow.ensureVisible();
            end
        end

        function exportToWorkspace(obj)
            obj.ensureCommandWindowVisible();
            if isempty(obj.CurrentProject)
                warning('No current project set. Nothing to export.');
                return;
            end

            % Export all fields of the current project's data
            validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
            if isfield(obj.ProjectData, validProjectName)
                projectData = obj.ProjectData.(validProjectName);
                fields = fieldnames(projectData);
                for i = 1:length(fields)
                    fieldName = fields{i};
                
                end

       
            else
                warning('No data found for current project. Nothing to export.');
            end
        end
        
        function value = get(obj, propertyName)
            obj.ensureCommandWindowVisible();
            if isprop(obj, propertyName)
                % If it's a direct property of the class
                value = obj.(propertyName);
            elseif ~isempty(obj.CurrentProject)
                validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
                if ~isfield(obj.ProjectData, validProjectName)
                    obj.recoverProjectFromConfig(validProjectName);
                end
                if isfield(obj.ProjectData, validProjectName) && isfield(obj.ProjectData.(validProjectName), propertyName)
                    value = obj.ProjectData.(validProjectName).(propertyName);
                else
                    error('Property ''%s'' not found in current project data.', propertyName);
                end
            else
                error('No current project set. Unable to retrieve property ''%s''.', propertyName);
            end
        end
        
        function workspaceFolder = getProjectPath(obj, projectName)
            obj.ensureCommandWindowVisible();
            validProjectName = matlab.lang.makeValidName(projectName);
            if isfield(obj.ProjectPaths, validProjectName)
                workspaceFolder = obj.ProjectPaths.(validProjectName);
            else
                workspaceFolder = '';
            end
        end

        function saveConfig(obj)
            obj.ensureCommandWindowVisible();
            % Create a temporary structure to hold the data we want to save
            configData = struct();
            configData.ProjectPaths = obj.ProjectPaths;
            configData.CurrentProject = obj.CurrentProject;
            save(obj.ConfigFile, '-struct', 'configData', '-v7.3');
        end

      
        function setIsInProjectSelection(obj, value)
            obj.ensureCommandWindowVisible();
            obj.IsInProjectSelection = value;
        end

        function saveBothData(obj)
            obj.ensureCommandWindowVisible();
            if isempty(obj.CurrentProject)
                error('No current project set. Use setCurrentProject first.');
            end
            validProjectName = matlab.lang.makeValidName(obj.CurrentProject);
            
            workspaceFolder = obj.ProjectPaths.(validProjectName);
            if ~isempty(workspaceFolder)
                % Save DataManagerState file
                stateFilename = ['DataManagerState_', validProjectName, '_', datestr(now, 'yyyymmdd_HHMMSS'), '.mat'];
                stateFullPath = fullfile(workspaceFolder, stateFilename);
                stateData = obj.ProjectData.(validProjectName);
                save(stateFullPath, '-struct', 'stateData', '-v7.3');

                
                obj.cleanupOldStateFiles(workspaceFolder, 'DataManagerState');
            else
                warning('WorkspaceFolder is empty for project %s. Cannot save data.', obj.CurrentProject);
            end
            
            % Save config file
            obj.saveConfig();
        end

        function cleanupOldStateFiles(obj, workspaceFolder, prefix)
            obj.ensureCommandWindowVisible();
            files = dir(fullfile(workspaceFolder, [prefix, '*.mat']));
            maxStateFiles = 5;  
            
            if length(files) > maxStateFiles
                [~, idx] = sort([files.datenum], 'descend');
                filesToKeep = files(idx(1:maxStateFiles));
                filesToDelete = files(~ismember({files.name}, {filesToKeep.name}));
                for i = 1:length(filesToDelete)
                    delete(fullfile(workspaceFolder, filesToDelete(i).name));
                    disp(['Deleted old ', prefix, ' file: ', filesToDelete(i).name]);
                end
            end
        end

        function cleanupAllProjectStateFiles(obj)
            obj.ensureCommandWindowVisible();
            projectNames = fieldnames(obj.ProjectPaths);
            for i = 1:length(projectNames)
                workspaceFolder = obj.ProjectPaths.(projectNames{i});
                if ~isempty(workspaceFolder)
                    obj.cleanupOldStateFiles(workspaceFolder, 'DataManagerState');
                end
            end
        end

        function saveImageToInputFolder(obj, imagePath, newFileName)
            obj.ensureCommandWindowVisible();
            if isempty(obj.CurrentProject)
                error('No current project set. Use setCurrentProject first.');
            end
            inputFolder = obj.getFromDataManager('InputFolder');
            if isempty(inputFolder)
                error('Input folder not set for the current project.');
            end
            newFullPath = fullfile(inputFolder, newFileName);
            copyfile(imagePath, newFullPath);
        end

        function recoverProjectFromConfig(obj, projectName)
            obj.ensureCommandWindowVisible();
            % This method attempts to recover project data from the ConfigFile
            if exist(obj.ConfigFile, 'file')
                loadedData = load(obj.ConfigFile);
                if isfield(loadedData.ProjectPaths, projectName)
                    obj.ProjectPaths.(projectName) = loadedData.ProjectPaths.(projectName);
                    obj.loadProjectData(projectName);
                   
                else
                    warning('Project %s not found in ConfigFile. Initializing empty project data.', projectName);
                    obj.ProjectData.(projectName) = struct();
                    obj.ProjectPaths.(projectName) = '';
                end
            else
                warning('ConfigFile not found. Initializing empty project data for %s.', projectName);
                obj.ProjectData.(projectName) = struct();
                obj.ProjectPaths.(projectName) = '';
            end
        end
    
       function FinalParams = FindFinalParams(obj)
    obj.ensureCommandWindowVisible();
    if isempty(obj.CurrentProject)
        error('No current project set. Use setCurrentProject first.');
    end
    
    workspaceFolder = obj.getFromDataManager('WorkspaceFolder');
    if isempty(workspaceFolder)
        error('Workspace folder not set for the current project.');
    end
    
    % Get list of .mat files in the specified folder
    matFiles = dir(fullfile(workspaceFolder, '*.mat'));
    
    % Filter files that contain 'FinalParams' or 'CombinedParams' in their names (case-insensitive)
    isParamFile = ~cellfun('isempty', regexpi({matFiles.name}, 'FinalParams|CombinedParams'));
    FinalParamFiles = matFiles(isParamFile);
    
    % Variables to track the best file
    bestFilePath = '';
    maxNonEmptyFields = -1;
    bestFileParams = struct();
    
    % Display information
    disp('Comparing FinalParams structures:');
    fprintf('%-30s %-20s\n', 'Filename', 'Non-empty Fields Count');
    
    % Loop through the FinalParams files, find the largest
    for i = 1:length(FinalParamFiles)
        filePath = fullfile(workspaceFolder, FinalParamFiles(i).name);
        
        % Check file contents without loading everything
        fileInfo = whos('-file', filePath);
        fileVarNames = {fileInfo.name};
        
        % Check if FinalParams or CombinedParams exist in the file
        hasFinalParams = any(strcmpi(fileVarNames, 'FinalParams'));
        hasCombinedParams = any(strcmpi(fileVarNames, 'CombinedParams'));
        
        if ~hasFinalParams && ~hasCombinedParams
            fprintf('%-30s %-20s\n', FinalParamFiles(i).name, 'No matching params');
            continue;
        end
        
        % Determine which variable to load
        if hasFinalParams
            varName = 'FinalParams';
        else
            varName = 'CombinedParams';
        end
        
        % Load only the specific variable we need
        tempData = load(filePath, varName);
        finalParams = tempData.(varName);
        
        nonEmptyFieldsCount = 0;
        
        % Check if FinalParams is a struct array
        if isstruct(finalParams) && length(finalParams) > 1
            for j = 1:numel(finalParams)
                nonEmptyFieldsCount = nonEmptyFieldsCount + sum(structfun(@(x) ~isempty(x), finalParams(j)));
            end
        else
            nonEmptyFieldsCount = sum(structfun(@(x) ~isempty(x), finalParams));
        end
        
        % Display the result for the current file
        fprintf('%-30s %-20d\n', FinalParamFiles(i).name, nonEmptyFieldsCount);
        
        % Update the best file if this file has more non-empty fields
        if nonEmptyFieldsCount > maxNonEmptyFields
            maxNonEmptyFields = nonEmptyFieldsCount;
            bestFileParams = finalParams;
        end
        
        % Clear temporary data to free memory
        clear tempData finalParams
    end
    
    % Return the best params found or empty struct if none found
    if maxNonEmptyFields > -1
        FinalParams = bestFileParams;
    else
        FinalParams = struct();
        warning('No valid FinalParams found. Returning an empty structure.');
    end
end
        function deleteCorruptedFile(obj, filepath)
            try
                delete(filepath);
                disp(['Deleted corrupted file: ', filepath]);
            catch ME
                warning('Failed to delete corrupted file %s. Error: %s', filepath, ME.message);
            end
        end
    
    function unloadProject(obj, projectName)
    % Unloads a specific project's data from memory to reduce RAM usage
    %
    % Parameters:
    % projectName - Name of the project to unload
    
    % Input validation - prevent the concatenation error
    if isempty(projectName) || ~ischar(projectName)
        return; % Nothing to unload, exit silently
    end
    
    obj.ensureCommandWindowVisible();
    validProjectName = matlab.lang.makeValidName(projectName);
    
    % Only proceed if the project is actually loaded
    if isfield(obj.LoadedStates, validProjectName) && obj.LoadedStates.(validProjectName)
        % Clear project data if it exists (replace with empty struct instead of completely removing)
        if isfield(obj.ProjectData, validProjectName)
            obj.ProjectData.(validProjectName) = struct();
        end
        
        % Update tracking structures to mark project as unloaded
        obj.LoadedStates.(validProjectName) = false;
        
        % Clear any cache entries
        if isfield(obj.CombinedProjectCache, validProjectName)
            obj.CombinedProjectCache.(validProjectName) = [];
        end
        
        % Log the action - ONLY if something was actually unloaded
        obj.CommandWindow.display(['Unloaded project data: ' projectName]);
        
        % Force MATLAB to garbage collect (no direct way to call this)
        % A small pause can help MATLAB reclaim memory in some cases
        pause(0.1);
        
        % Clear any temporary variables in this function scope
        clear validProjectName;
    end
end
    end
end