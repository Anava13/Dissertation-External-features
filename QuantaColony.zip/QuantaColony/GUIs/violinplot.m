function violins = violinplot(data, cats, varargin)
% Modified version of violinplot that handles NaN spacers like boxplot does

hascategories = exist('cats','var') && not(isempty(cats));

% Parse the optional arguments
grouporder = {};
idx=find(strcmp(varargin, 'GroupOrder'));
if ~isempty(idx) && numel(varargin)>idx
    if iscell(varargin{idx+1})
        grouporder = varargin{idx+1};
        varargin(idx:idx+1)=[];
    else
        error('Second argument of ''GroupOrder'' optional arg must be a cell of category names')
    end
end

% Check and correct the structure of ViolinColor input
idx=find(strcmp(varargin, 'ViolinColor'));
if ~isempty(idx) && iscell(varargin{idx+1})
    if length(varargin{idx+1}(:))>2
        error('ViolinColor input can be at most a two element cell array');
    end
elseif ~isempty(idx) && isnumeric(varargin{idx+1})
    varargin{idx+1} = varargin(idx+1);
end

% Check and correct the structure of ViolinAlpha input
idx=find(strcmp(varargin, 'ViolinAlpha'));
if ~isempty(idx) && iscell(varargin{idx+1})
    if length(varargin{idx+1}(:))>2
        error('ViolinAlpha input can be at most a two element cell array');
    end
elseif ~isempty(idx) && isnumeric(varargin{idx+1})
    varargin{idx+1} = varargin(idx+1);
end

% Find the parent axes if specified
parentAxes = [];
idxParent = find(strcmp(varargin, 'Parent'));
if ~isempty(idxParent) && numel(varargin) > idxParent
    parentAxes = varargin{idxParent+1};
end

% Handle different input types
if isa(data, 'dataset') || isstruct(data) || istable(data)
    % Handle tabular data (unchanged from original)
    if isa(data, 'dataset')
        colnames = data.Properties.VarNames;
    elseif istable(data)
        colnames = data.Properties.VariableNames;
    elseif isstruct(data)
        colnames = fieldnames(data);
    end
    catnames = {};
    if isempty(grouporder)
        for n=1:length(colnames)
            if isnumeric(data.(colnames{n}))
                catnames = [catnames colnames{n}];
            end
        end
        catnames = sort(catnames);
    else
        for n=1:length(grouporder)
            if isnumeric(data.(grouporder{n}))
                catnames = [catnames grouporder{n}];
            end
        end
    end
    
    violins = [];
    for n=1:length(catnames)
        thisData = data.(catnames{n});
        violin_n = Violin({thisData}, n, varargin{:});
        violins = [violins violin_n];
    end
    if ~isempty(violins)
        if strcmp(violins(1).Orientation,'vertical')
            set(violins(1).Parent, 'XTick', 1:length(catnames), 'XTickLabels', catnames);
        else
            set(violins(1).Parent, 'YTick', 1:length(catnames), 'YTickLabels', catnames);
        end
        set(violins(1).Parent,'Box','on');
    end
    return
elseif iscell(data) && length(data(:))==2 % cell input
    if not(size(data{1},2)==size(data{2},2))
        error('The two input data matrices have to have the same number of columns');
    end
elseif iscell(data) && length(data(:))>2 % cell input
    error('Up to two datasets can be compared');
elseif isnumeric(data) % numeric input   
    % 1D data, one category for each data point
    if hascategories && numel(data) == numel(cats)    
        if isempty(grouporder)
            cats = categorical(cats);
        else
            cats = categorical(cats, grouporder);
        end
        
        catnames = (unique(cats)); % this ignores categories without any data
        catnames_labels = {};
        violins = [];
        for n = 1:length(catnames)
            thisCat = catnames(n);
            catnames_labels{n} = char(thisCat);
            thisData = data(cats == thisCat);
            violin_n = Violin({thisData}, n, varargin{:});
            violins = [violins violin_n];
        end
        if ~isempty(violins)
            if strcmp(violins(1).Orientation,'vertical')
                set(violins(1).Parent, 'XTick', 1:length(catnames), 'XTickLabels', catnames);
            else
                set(violins(1).Parent, 'YTick', 1:length(catnames), 'YTickLabels', catnames);
            end
            set(violins(1).Parent,'Box','on');
        end
        return
    else
        data = {data};
    end
end

% 1D data, no categories
if not(hascategories) && isvector(data{1})
    violins = Violin(data, 1, varargin{:});
    if ~isempty(violins)
        if strcmp(violins(1).Orientation,'vertical')
            set(violins(1).Parent, 'XTick', 1);
        else
            set(violins(1).Parent, 'yTick', 1);
        end
    end
% 2D data with or without categories
elseif ismatrix(data{1})
    % Determine which columns have data (not all NaN)
    hasData = false(1, size(data{1}, 2));
    for n = 1:size(data{1}, 2)
        colData = data{1}(:, n);
        hasData(n) = ~all(isnan(colData));
    end
    
    % Count how many real violins we will create
    validColCount = sum(hasData);
    if validColCount == 0
        error('No data to plot. All columns contain only NaN values.');
    end
    
    % Set up in the parent axes if provided
    if ~isempty(parentAxes)
        axes(parentAxes);
        hold(parentAxes, 'on');
    end
    
    % Create violin objects array
    violins = [];
    
    % Create violins only for columns with data, preserving position
    for n = 1:size(data{1}, 2)
        if hasData(n)
            % Extract data for this column
            thisData = cellfun(@(x)x(:,n),data,'UniformOutput',false);
            
            % Create violin at the correct position
            violin_n = Violin(thisData, n, varargin{:});
            violins = [violins violin_n];
        end
    end
    
    % Set up the X-ticks to include positions of all columns (including NaN spacers)
    if ~isempty(violins)
        if strcmp(violins(1).Orientation,'vertical')
            set(violins(1).Parent, 'XTick', 1:size(data{1}, 2));
        else
            set(violins(1).Parent, 'YTick', 1:size(data{1}, 2));
        end
        
        % Apply category labels if provided
        if hascategories && length(cats) == size(data{1}, 2)
            if strcmp(violins(1).Orientation,'vertical')
                set(violins(1).Parent, 'XTickLabels', cats);
            else
                set(violins(1).Parent, 'YTickLabels', cats);
            end
        end
    end
    
    % Release hold on the parent axes
    if ~isempty(parentAxes)
        hold(parentAxes, 'off');
    end
end

% Make sure we have at least one violin before accessing its properties
if ~isempty(violins)
    set(violins(1).Parent, 'Box', 'on');
end

end