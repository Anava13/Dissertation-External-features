

function generateProjectExportHTML(outputPath)
    % CONTROLLER: Generate Project Export/Import documentation HTML
    % 
    % USAGE:
    %   generateProjectExportHTML('ProjectExport.html')
    %
    % Creates standalone HTML documentation for QuantaColony's
    % Project Export/Import feature
    
    % === COORDINATE SUB-CONTROLLERS ===
    
    % Build complete HTML structure
    htmlContent = buildCompleteHTML();
    
    % Write HTML to file
    writeHTMLToFile(htmlContent, outputPath);
    
    % === SUB-CONTROLLERS ===
    
    function html = buildCompleteHTML()
        % SUB-CONTROLLER: Assemble complete HTML document
        
        % Generate document sections
        head = buildHTMLHead();
        body = buildHTMLBody();
        
        % Combine into complete document
        html = assembleHTMLDocument(head, body);
        
        function headContent = buildHTMLHead()
            % SUB-CONTROLLER: Build HTML head section
            
            % Get head components
            meta = generateMetaTags();
            styles = generateStyleSheet();
            
            % Assemble head section
            headContent = assembleHeadSection(meta, styles);
            
            function metaTags = generateMetaTags()
                % MODEL: Generate meta tags (TERMINAL)
                metaTags = {
                    '<meta charset="UTF-8">';
                    '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
                    '<title>QuantaColony Project Export/Import</title>'
                };
            end
            
            function stylesheet = generateStyleSheet()
                % MODEL: Generate CSS stylesheet (TERMINAL)
                stylesheet = {
                    '<style>';
                    'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 0; padding: 40px 20px; background: linear-gradient(135deg, #468f00 0%, #7ab829 100%); min-height: 100vh; }';
                    '.container { max-width: 800px; margin: 0 auto; background: #f8f5ec; border-radius: 12px; padding: 50px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); }';
                    'h1 { color: #468f00; margin-top: 0; font-size: 32px; line-height: 1.3; }';
                    'h2 { color: #468f00; font-size: 22px; margin-top: 35px; margin-bottom: 15px; border-bottom: 2px solid #468f00; padding-bottom: 8px; }';
                    '.section { background: white; padding: 25px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #468f00; }';
                    '.section p { margin: 0 0 12px 0; line-height: 1.6; color: #333; }';
                    '.section p:last-child { margin-bottom: 0; }';
                    '.feature-list { margin: 15px 0; }';
                    '.feature-item { background: #f8f5ec; padding: 12px 15px; margin: 8px 0; border-radius: 4px; border-left: 3px solid #7ab829; }';
                    '.workflow { display: flex; justify-content: space-between; margin: 20px 0; flex-wrap: wrap; }';
                    '.workflow-step { flex: 1; min-width: 200px; margin: 10px; text-align: center; }';
                    '.workflow-number { background: #468f00; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px; margin: 0 auto 12px; }';
                    '.workflow-title { font-weight: 600; color: #468f00; margin-bottom: 8px; }';
                    '.workflow-desc { font-size: 14px; color: #666; }';
                    'code { background: #e9ecef; padding: 2px 6px; border-radius: 3px; color: #468f00; font-family: "Courier New", monospace; font-size: 14px; }';
                    '.note { background: #e8f5e9; border-left: 4px solid #468f00; padding: 20px; margin: 25px 0; border-radius: 4px; }';
                    '.note p { margin: 0; line-height: 1.6; }';
                    '.footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 14px; }';
                    '</style>'
                };
            end
            
            function head = assembleHeadSection(meta, styles)
                % VIEW: Combine head components (TERMINAL)
                head = [{'<head>'}; meta; styles; {'</head>'}];
            end
        end
        
        function bodyContent = buildHTMLBody()
            % SUB-CONTROLLER: Build HTML body section
            
            % Generate body sections
            header = generateHeaderSection();
            whatItIs = generateWhatItIsSection();
            whatsIncluded = generateWhatsIncludedSection();
            howToUse = generateHowToUseSection();
            applications = generateApplicationsSection();
            transparency = generateTransparencySection();
            footer = generateFooterSection();
            
            % Assemble body section
            bodyContent = assembleBodySection(header, whatItIs, whatsIncluded, ...
                                            howToUse, applications, transparency, footer);
            
            function headerContent = generateHeaderSection()
                % MODEL: Generate page header (TERMINAL)
                headerContent = {
                    '<div class="container">';
                    '<h1>📦 Project Export/Import</h1>';
                    '<p style="font-size: 16px; color: #666; margin-bottom: 30px;">Complete project sharing and reproducibility in QuantaColony</p>'
                };
            end
            
            function section = generateWhatItIsSection()
                % MODEL: Generate "What It Is" section (TERMINAL)
                section = {
                    '<h2>What It Is</h2>';
                    '<div class="section">';
                    '<p>Project Export creates a single HDF5 file containing your complete QuantaColony project. Project Import recreates that project locally in your QuantaColony installation. The feature is not yet fully implemented, but is part of a future deployment</p>';
                    '<p>The exported <code>.h5</code> file is typically small enough for email attachment and contains everything needed to reproduce your analysis.</p>';
                    '</div>'
                };
            end
            
            function section = generateWhatsIncludedSection()
                % MODEL: Generate "What''s Included" section (TERMINAL)
                section = {
                    '<h2>What''s Included</h2>';
                    '<div class="section">';
                    '<div class="feature-list">';
                    '<div class="feature-item">All Colony Set measurements and metadata</div>';
                    '<div class="feature-item">Complete Ordinal-Nominal experimental structure</div>';
                    '<div class="feature-item">Detection parameters and refinement history</div>';
                    '<div class="feature-item">Statistical outputs and analysis results</div>';
                    '<div class="feature-item">Source image references and experimental labels</div>';
                    '</div>';
                    '</div>'
                };
            end
            
            function section = generateHowToUseSection()
                % MODEL: Generate "How to Use" section (TERMINAL)
                section = {
                    '<h2>How to Use</h2>';
                    '<div class="section">';
                    '<div class="workflow">';
                    '<div class="workflow-step">';
                    '<div class="workflow-number">1</div>';
                    '<div class="workflow-title">Export</div>';
                    '<div class="workflow-desc">File → Export Project<br>Creates .h5 file</div>';
                    '</div>';
                    '<div class="workflow-step">';
                    '<div class="workflow-number">2</div>';
                    '<div class="workflow-title">Share</div>';
                    '<div class="workflow-desc">Email attachment or<br>supplementary material</div>';
                    '</div>';
                    '<div class="workflow-step">';
                    '<div class="workflow-number">3</div>';
                    '<div class="workflow-title">Import</div>';
                    '<div class="workflow-desc">File → Import Project<br>Select .h5 file</div>';
                    '</div>';
                    '</div>';
                    '</div>'
                };
            end
            
            function section = generateApplicationsSection()
                % MODEL: Generate "Practical Applications" section (TERMINAL)
                section = {
                    '<h2>Practical Applications</h2>';
                    '<div class="section">';
                    '<p><strong>Verification:</strong> Load published datasets to inspect detection methods and rerun analyses with different parameters.</p>';
                    '<p><strong>Combination:</strong> Import projects for ERC (Experimental Replicate Combination) or VEC (Variable Extension Combination) merging with your own data.</p>';
                    '<p><strong>Collaboration:</strong> Share complete project state with co-authors, ensuring everyone works from identical data and experimental structure.</p>';
                    '<p><strong>Archiving:</strong> Single file for long-term storage containing all analysis details and decisions.</p>';
                    '</div>'
                };
            end
            
            function section = generateTransparencySection()
                % MODEL: Generate transparency note section (TERMINAL)
                section = {
                    '<div class="note">';
                    '<p><strong>Note on Transparency:</strong> Projects exported from QuantaColony include all detection decisions, parameter adjustments, and manual refinements. This makes methods fully auditable and enables others to understand exactly how colony measurements were obtained.</p>';
                    '</div>'
                };
            end
            
            function footerContent = generateFooterSection()
                % MODEL: Generate footer (TERMINAL)
                footerContent = {
                    '<div class="footer">';
                    '<p>QuantaColony: Computational Framework for Colony-Based Analysis</p>';
                    '</div>';
                    '</div>'
                };
            end
            
            function body = assembleBodySection(header, whatItIs, whatsIncluded, ...
                                               howToUse, applications, transparency, footer)
                % VIEW: Combine body components (TERMINAL)
                body = [{'<body>'}; header; whatItIs; whatsIncluded; ...
                       howToUse; applications; transparency; footer; {'</body>'}];
            end
        end
        
        function document = assembleHTMLDocument(head, body)
            % VIEW: Combine head and body into complete HTML (TERMINAL)
            allLines = [{'<!DOCTYPE html>'}; {'<html lang="en">'}; head; body; {'</html>'}];
            document = strjoin(allLines, newline);
        end
    end
    
    function writeHTMLToFile(content, filepath)
        % VIEW: Write HTML content to file (TERMINAL)
        fid = fopen(filepath, 'w', 'n', 'UTF-8');
        if fid == -1
            error('Could not open file for writing: %s', filepath);
        end
        fprintf(fid, '%s', content);
        fclose(fid);
        fprintf('HTML file created: %s\n', filepath);
    end
end