classdef CommandWindowApp < handle
    properties (Access = private)
        Figure
        TextArea
        IconFolder
        ReportBugButton
        ClearButton
        ParentPanel % Panel where the window is docked
        IsDocked = false % Flag to track if the window is docked
        CurrentText = '' % Store text content across state changes
    end
    
    properties (Access = private, Transient)
        IsCreatingGUI = false
    end
    
    methods (Access = private)
        function obj = CommandWindowApp()
            % Private constructor to prevent direct instantiation
        end
        
        % Helper function to safely concatenate text regardless of type
        function result = concatenateText(~, text1, text2)
            % Handle empty inputs
            if isempty(text1)
                result = text2;
                return;
            elseif isempty(text2)
                result = text1;
                return;
            end
            
            % Create temporary cell array for the concatenation
            tempCell = {};
            
            % Handle text1 based on its type
            if iscell(text1)
                tempCell = [tempCell; text1(:)];
            elseif isstring(text1)
                tempCell = [tempCell; cellstr(text1)];
            elseif ischar(text1)
                tempCell = [tempCell; {text1}];
            end
            
            % Add empty line
            tempCell = [tempCell; {''}];
            
            % Handle text2 based on its type
            if iscell(text2)
                tempCell = [tempCell; text2(:)];
            elseif isstring(text2)
                tempCell = [tempCell; cellstr(text2)];
            elseif ischar(text2)
                tempCell = [tempCell; {text2}];
            end
            
            % Return result in the format of text1 if possible
            if iscell(text1)
                result = tempCell;
            elseif isstring(text1)
                result = string(tempCell);
            else
                % Default to cell array which UITextArea can handle
                result = tempCell;
            end
        end
    end
    
    methods (Access = public, Static)
        

        function cwApp = getInstance()
            % Enhanced singleton pattern with better docked window detection
            persistent commandWindowInstance;
            
            % FIRST PRIORITY: Check for existing DOCKED CommandWindow in the application
            allTextAreas = findall(0, 'Type', 'UITextArea');
            for i = 1:length(allTextAreas)
                % Try to identify our text areas by their distinctive properties with more flexible matching
                try
                    if abs(allTextAreas(i).BackgroundColor(1) - 0.33) < 0.1 && ...
                       abs(allTextAreas(i).BackgroundColor(2) - 0.33) < 0.1 && ...
                       abs(allTextAreas(i).BackgroundColor(3) - 0.33) < 0.1 && ...
                       abs(allTextAreas(i).FontColor(1) - 1) < 0.1 && ...
                       abs(allTextAreas(i).FontColor(2) - 1) < 0.1 && ...
                       abs(allTextAreas(i).FontColor(3) - 1) < 0.1
                       
                        % Found what appears to be our text area in a panel
                        panel = ancestor(allTextAreas(i), 'UIPanel');
                        if ~isempty(panel)
                            % Check if we already have an instance pointing to this text area
                            if ~isempty(commandWindowInstance) && isvalid(commandWindowInstance) && ...
                               commandWindowInstance.IsDocked && ~isempty(commandWindowInstance.TextArea) && ...
                               isvalid(commandWindowInstance.TextArea) && commandWindowInstance.TextArea == allTextAreas(i)
                                % Already using this exact text area, return the existing instance
                                cwApp = commandWindowInstance;
                                return;
                            end
                            
                            % Create a new object pointing to the docked window
                            obj = CommandWindowApp();
                            obj.TextArea = allTextAreas(i);
                            obj.ParentPanel = panel;
                            obj.IsDocked = true;
                            
                            % Look for clear button near this text area
                            obj.ClearButton = findall(panel, 'Type', 'UIButton', 'Text', 'Clear');
                            
                            % If we have an existing instance, transfer any text
                            if ~isempty(commandWindowInstance) && isvalid(commandWindowInstance)
                                if ~isempty(commandWindowInstance.CurrentText)
                                    if isempty(obj.TextArea.Value)
                                        obj.TextArea.Value = commandWindowInstance.CurrentText;
                                    else
                                        obj.TextArea.Value = [obj.TextArea.Value; ''; commandWindowInstance.CurrentText];
                                    end
                                    drawnow;
                                    obj.TextArea.scroll('bottom');
                                end
                                
                                % Close any standalone window from previous instance
                                if ~commandWindowInstance.IsDocked && ~isempty(commandWindowInstance.Figure) && isvalid(commandWindowInstance.Figure)
                                    delete(commandWindowInstance.Figure);
                                end
                            end
                            
                            % Save to persistent variable
                            commandWindowInstance = obj;
                            cwApp = obj;
                            return;
                        end
                    end
                catch
                    % Skip if we can't check properties
                    continue;
                end
            end
            
            % SECOND PRIORITY: Check if we have a valid instance in persistent variable
            if ~isempty(commandWindowInstance) && isvalid(commandWindowInstance)
                cwApp = commandWindowInstance;
                
                % If we have a valid instance that's docked, double-check if the panel still exists
                if cwApp.IsDocked && ~isempty(cwApp.ParentPanel) && isvalid(cwApp.ParentPanel)
                    % Panel still exists, ensure TextArea is still valid
                    if isempty(cwApp.TextArea) || ~isvalid(cwApp.TextArea)
                        % TextArea is invalid, try to recreate it in the existing panel
                        try
                            cwApp.dockToPanel(cwApp.ParentPanel);
                        catch
                            % If recreation fails, reset docked state
                            cwApp.IsDocked = false;
                            cwApp.ParentPanel = [];
                        end
                    end
                end
                
                return;
            end
            
            % THIRD PRIORITY: Check for existing CommandWindow STANDALONE figures
            allFigs = findall(0, 'Type', 'figure', 'Name', 'Command Window');
            if ~isempty(allFigs)
                % We found an existing command window figure, create a wrapper for it
                obj = CommandWindowApp();
                obj.Figure = allFigs(1); % Use the first one
                obj.TextArea = findall(obj.Figure, 'Type', 'UITextArea');
                obj.ClearButton = findall(obj.Figure, 'Type', 'UIButton', 'Text', 'Clear');
                
                % Save this instance to persistent variable
                commandWindowInstance = obj;
                cwApp = obj;
                return;
            end
            
            % If we get here, no existing instance was found, create a new one
            obj = CommandWindowApp();
            commandWindowInstance = obj;
            cwApp = obj;
        end
        
        function display(text)
            % First try to find or create a docked instance if possible
            cwApp = CommandWindowApp.getInstance();
            
            % Prioritize docked window
            cwApp.preferDockedWindow();
            
            % Now append the text to our instance
            cwApp.appendText(text);
        end

        function clearText()
            % Get the instance
            cwApp = CommandWindowApp.getInstance();
            cwApp.clearTextArea();
        end
        
        % Static method to dock the command window in a panel
        function dockInPanel(panel)
            cwApp = CommandWindowApp.getInstance();
            cwApp.dockToPanel(panel);
        end
        
        % Static method to undock the command window
        function undock()
            cwApp = CommandWindowApp.getInstance();
            cwApp.undockFromPanel();
        end
        
        % Static method to check if currently docked
        function isDocked = isCurrentlyDocked()
            cwApp = CommandWindowApp.getInstance();
            isDocked = cwApp.IsDocked;
        end
        
        % New method to initialize as docked without ever creating a standalone window
        function cwApp = initializeAsDocked(panel)
            % Get the singleton instance
            cwApp = CommandWindowApp.getInstance();
            
            % First, enforce docked-only mode to prevent future undocking
            CommandWindowApp.preventUndocking();
            
            % Close any existing standalone windows
            cwApp.closeAllStandaloneWindows();
            
            % If we're already docked somewhere else, undock first
            % (this is allowed even when preventUndocking is active because we're redocking)
            if cwApp.IsDocked && ~isempty(cwApp.TextArea) && isvalid(cwApp.TextArea) && ...
               ~isempty(cwApp.ParentPanel) && cwApp.ParentPanel ~= panel
                cwApp.cleanupDockedUI(); % Just clean up, don't create standalone
            end
            
            % Set as docked immediately (prevents createGUI from running)
            cwApp.IsDocked = true;
            
            % Dock to the specified panel
            cwApp.dockToPanel(panel);
        end
        
        % Method to force all activity to go to the docked window
        function forceUniqueWindow()
            cwApp = CommandWindowApp.getInstance();
            cwApp.preferDockedWindow();
        end
        
        % Force all activity to go to the docked window
        function preventUndocking()
            % This is a static method that can be called at app startup
            % to permanently prevent any creation of standalone windows
            persistent DOCKED_ONLY;
            DOCKED_ONLY = true;
        end
        
        % Check if we should allow undocking
        function allowed = isUndockingAllowed()
            persistent DOCKED_ONLY;
            allowed = isempty(DOCKED_ONLY) || ~DOCKED_ONLY;
        end
    end
    
    methods (Access = public)
        function createGUI(obj)
    if obj.IsCreatingGUI
        return;
    end
    
    % First, always look for an existing docked window
    dockedTextArea = obj.findDockedWindow();
    if ~isempty(dockedTextArea)
        % We found a docked window, use it instead of creating standalone
        panel = ancestor(dockedTextArea, 'UIPanel');
        obj.TextArea = dockedTextArea;
        obj.ParentPanel = panel;
        obj.IsDocked = true;
        obj.ClearButton = findall(panel, 'Type', 'UIButton', 'Text', 'Clear');
        obj.ReportBugButton = findall(panel, 'Type', 'UIButton', 'Text', 'Report Bug');
        
        % Add our text to it
        if ~isempty(obj.CurrentText)
            currentText = obj.TextArea.Value;
            obj.TextArea.Value = obj.concatenateText(currentText, obj.CurrentText);
            drawnow;
            obj.TextArea.scroll('bottom');
        end
        return;
    end
    
    % Check if undocking is allowed
    if ~CommandWindowApp.isUndockingAllowed()
        warning('Cannot create standalone window - docked mode is enforced.');
        return;
    end
    
    if obj.IsDocked
        warning('Cannot create standalone GUI while docked. Call undockFromPanel() first.');
        return;
    end
    
    obj.IsCreatingGUI = true;
    
    try
        % Close any existing Command Window figures
        obj.closeAllStandaloneWindows();
        
        % Get screen size
        screenSize = get(0, 'ScreenSize');
        screenWidth = screenSize(3);
        screenHeight = screenSize(4);
        
        % Set window size
        windowWidth = 600;
        windowHeight = 430; % Increased height to accommodate the buttons
        
        % Calculate position
        xPos = screenWidth - windowWidth - 10;
        yPos = (screenHeight - windowHeight) / 2;
        
        obj.Figure = uifigure('Name', 'Command Window', ...
            'Position', [xPos, yPos, windowWidth, windowHeight], ...
            'Color', [0.33, 0.33, 0.33], ...
            'Visible', 'off');
        
        obj.TextArea = uitextarea(obj.Figure, ...
            'Position', [10, 50, windowWidth-20, windowHeight-60], ...
            'Value', obj.CurrentText, 'BackgroundColor', [0.33, 0.33, 0.33], ...
            'FontColor', [1, 1, 1], 'FontSize', 16, ...
            'FontName', 'Arial');
        
        % Add Clear button (left of center)
        obj.ClearButton = uibutton(obj.Figure, 'push', ...
            'Text', 'Clear', ...
            'Position', [windowWidth/2 - 105, 10, 100, 30], ...
            'ButtonPushedFcn', @(btn,event) obj.clearTextArea());
        
        % Add Report Bug button (right of center)
        obj.ReportBugButton = uibutton(obj.Figure, 'push', ...
            'Text', 'Report Bug', ...
            'Position', [windowWidth/2 + 5, 10, 100, 30], ...
            'ButtonPushedFcn', @(btn,event) obj.openBugReportForm());
        
        obj.applyDefaultStyling();
        
        obj.Figure.Visible = 'on';
        figure(obj.Figure); % Bring to front
        
        % Scroll to bottom if there's text
        if ~isempty(obj.CurrentText)
            drawnow;
            obj.TextArea.scroll('bottom');
        end
        
    catch ME
        warning('Failed to create CommandWindowApp GUI: %s', ME.message);
    end
    
    obj.IsCreatingGUI = false;
end

function dockToPanel(obj, panel)
    if ~isvalid(panel)
        error('The specified panel is not valid.');
    end
    
    % Close any standalone windows
    obj.closeAllStandaloneWindows();
    
    % Clean up any existing docked UI
    if obj.IsDocked
        obj.cleanupDockedUI();
    end
    
    % Set up new docked state
    obj.ParentPanel = panel;
    obj.IsDocked = true;
    
    % Create UI components in the parent panel
    try
        % Get panel dimensions
        panelPosition = obj.ParentPanel.Position;
        panelWidth = panelPosition(3);
        panelHeight = panelPosition(4);
        
        % Create text area in the parent panel
        obj.TextArea = uitextarea(obj.ParentPanel, ...
            'Position', [10, 50, panelWidth-20, panelHeight-60], ...
            'Value', obj.CurrentText, 'BackgroundColor', [0.33, 0.33, 0.33], ...
            'FontColor', [1, 1, 1], 'FontSize', 16, ...
            'FontName', 'Arial');
        
        % Add Clear button to the parent panel (left of center)
        obj.ClearButton = uibutton(obj.ParentPanel, 'push', ...
            'Text', 'Clear', ...
            'Position', [panelWidth/2 - 105, 10, 100, 30], ...
            'ButtonPushedFcn', @(btn,event) obj.clearTextArea());
        
        % Add Report Bug button to the parent panel (right of center)
        obj.ReportBugButton = uibutton(obj.ParentPanel, 'push', ...
            'Text', 'Report Bug', ...
            'Position', [panelWidth/2 + 5, 10, 100, 30], ...
            'ButtonPushedFcn', @(btn,event) obj.openBugReportForm());
        
        obj.applyDefaultStyling();
        
        % Scroll to bottom if there's text
        if ~isempty(obj.CurrentText)
            drawnow;
            obj.TextArea.scroll('bottom');
        end
        
        disp('Command Window successfully docked to panel.');
    catch ME
        warning('Failed to dock CommandWindowApp: %s', ME.message);
        % Revert to standalone mode if docking fails
        obj.IsDocked = false;
        obj.ParentPanel = [];
        if CommandWindowApp.isUndockingAllowed()
            obj.createGUI();
        end
    end
end

function cleanupDockedUI(obj)
    % Clean up the UI elements in a docked panel
    if ~isempty(obj.TextArea) && isvalid(obj.TextArea)
        % Save the current text before cleaning up
        obj.CurrentText = obj.TextArea.Value;
        delete(obj.TextArea);
        obj.TextArea = [];
    end
    
    if ~isempty(obj.ClearButton) && isvalid(obj.ClearButton)
        delete(obj.ClearButton);
        obj.ClearButton = [];
    end
    
    if ~isempty(obj.ReportBugButton) && isvalid(obj.ReportBugButton)
        delete(obj.ReportBugButton);
        obj.ReportBugButton = [];
    end
    
    obj.ParentPanel = [];
end

function delete(obj)
    % Destructor method
    if ~isempty(obj.TextArea) && isvalid(obj.TextArea)
        delete(obj.TextArea);
    end
    
    if ~isempty(obj.ClearButton) && isvalid(obj.ClearButton)
        delete(obj.ClearButton);
    end
    
    if ~isempty(obj.ReportBugButton) && isvalid(obj.ReportBugButton)
        delete(obj.ReportBugButton);
    end
    
    if ~isempty(obj.Figure) && isvalid(obj.Figure)
        delete(obj.Figure);
    end
end

function openBugReportForm(obj)
    % Open the bug report Google Form in the default web browser
    bugReportUrl = 'https://docs.google.com/forms/d/e/1FAIpQLSf4vCC0jIYnvEIQu12NCbOUmhCjJj5nF2m4ROucSRkayeOUmA/viewform?usp=sharing&ouid=108260719175782667789';
    web(bugReportUrl, '-browser');
end

        % Helper method to close all standalone command windows
        function closeAllStandaloneWindows(obj)
            % Find and close all Command Window figures
            allFigs = findall(0, 'Type', 'figure', 'Name', 'Command Window');
            for i = 1:length(allFigs)
                % Capture text if it's our figure
                if ~isempty(obj.Figure) && isvalid(obj.Figure) && obj.Figure == allFigs(i)
                    textArea = findall(obj.Figure, 'Type', 'UITextArea');
                    if ~isempty(textArea) && isvalid(textArea)
                        obj.CurrentText = textArea.Value;
                    end
                    obj.Figure = [];
                    obj.TextArea = [];
                    obj.ClearButton = [];
                end
                delete(allFigs(i));
            end
        end
        
        % Method to prioritize docked window over standalone
        function preferDockedWindow(obj)
            % Look for any existing docked CommandWindow
            dockedWindow = obj.findDockedWindow();
            
            if ~isempty(dockedWindow)
                % We found a docked window, which should take precedence
                if obj.IsDocked && obj.TextArea == dockedWindow
                    % We're already using this docked window, just close any standalone windows
                    obj.closeAllStandaloneWindows();
                    return;
                end
                
                % Transfer text if needed
                if ~isempty(obj.TextArea) && isvalid(obj.TextArea)
                    % Save our current text
                    if obj.IsDocked
                        % We're docked but not in the window we found
                        obj.CurrentText = obj.TextArea.Value;
                        obj.cleanupDockedUI();
                    else
                        % We're standalone, transfer text then close
                        obj.CurrentText = obj.TextArea.Value;
                        obj.closeAllStandaloneWindows();
                    end
                end
                
                % Update our state to point to the found docked window
                panel = ancestor(dockedWindow, 'UIPanel');
                obj.TextArea = dockedWindow;
                obj.ParentPanel = panel;
                obj.IsDocked = true;
                obj.ClearButton = findall(panel, 'Type', 'UIButton', 'Text', 'Clear');
                
                % Add our text to the docked window if needed
                if ~isempty(obj.CurrentText)
                    currentText = obj.TextArea.Value;
                    obj.TextArea.Value = obj.concatenateText(currentText, obj.CurrentText);
                    drawnow;
                    obj.TextArea.scroll('bottom');
                end
            else if obj.IsDocked && (~isempty(obj.TextArea) && isvalid(obj.TextArea))
                    % We're already docked with valid UI, just close any standalone windows
                    obj.closeAllStandaloneWindows();
                else
                    % No docked window found, and we're not properly docked
                    % If we're marked as docked but have invalid UI, reset state
                    if obj.IsDocked
                        obj.IsDocked = false;
                        obj.ParentPanel = [];
                    end
                    
                    % If undocking is not allowed, don't create standalone window
                    if ~CommandWindowApp.isUndockingAllowed()
                        % Just keep the text in memory without creating a window
                        return;
                    end
                    
                    % If we have a valid standalone window, keep using it
                    if ~isempty(obj.Figure) && isvalid(obj.Figure) && ...
                       ~isempty(obj.TextArea) && isvalid(obj.TextArea)
                        return;
                    end
                    
                    % Otherwise create a new standalone window
                    obj.createGUI();
                end
            end
        end
        
        % Helper method to find an existing docked command window
        function textArea = findDockedWindow(obj)
            textArea = [];
            
            % First check if we already have a valid TextArea that's docked
            if obj.IsDocked && ~isempty(obj.TextArea) && isvalid(obj.TextArea) && ...
               ~isempty(obj.ParentPanel) && isvalid(obj.ParentPanel)
                % The existing one is valid, use it
                textArea = obj.TextArea;
                return;
            end
            
            % Look for text areas with our distinctive styling
            allTextAreas = findall(0, 'Type', 'UITextArea');
            for i = 1:length(allTextAreas)
                try
                    % Use more flexible color matching
                    bgColor = allTextAreas(i).BackgroundColor;
                    fontColor = allTextAreas(i).FontColor;
                    
                    if abs(bgColor(1) - 0.33) < 0.1 && abs(bgColor(2) - 0.33) < 0.1 && abs(bgColor(3) - 0.33) < 0.1 && ...
                       abs(fontColor(1) - 1) < 0.1 && abs(fontColor(2) - 1) < 0.1 && abs(fontColor(3) - 1) < 0.1
                        
                        % Check if it's in a panel (docked)
                        panel = ancestor(allTextAreas(i), 'UIPanel');
                        if ~isempty(panel)
                            textArea = allTextAreas(i);
                            return;
                        end
                    end
                catch
                    % Skip if we can't check properties
                    continue;
                end
            end
            
            % If we haven't found anything, try a more general search
            for i = 1:length(allTextAreas)
                try
                    % Check if it's in a panel (docked)
                    panel = ancestor(allTextAreas(i), 'UIPanel');
                    if ~isempty(panel)
                        % Found a text area in a panel, return it even if styling doesn't match
                        textArea = allTextAreas(i);
                        return;
                    end
                catch
                    continue;
                end
            end
        end
        
     
        % Method to undock from panel and return to standalone mode
        function undockFromPanel(obj)
            % Check if undocking is allowed
            if ~CommandWindowApp.isUndockingAllowed()
                warning('Undocking is disabled by application settings.');
                return;
            end
            
            if ~obj.IsDocked
                return; % Already undocked
            end
            
            % Clean up the docked UI
            obj.cleanupDockedUI();
            
            % Reset the docked state
            obj.IsDocked = false;
            
            % Create the standalone GUI
            obj.createGUI();
        end
     
        function appendText(obj, text)
            % First, always try to find a docked window
            dockedTextArea = obj.findDockedWindow();
            
            if ~isempty(dockedTextArea)
                % If we found a docked window but it's not our current one
                if isempty(obj.TextArea) || ~isvalid(obj.TextArea) || obj.TextArea ~= dockedTextArea
                    % Update our object to use the docked window
                    panel = ancestor(dockedTextArea, 'UIPanel');
                    previousText = obj.CurrentText;
                    
                    % Close any standalone window
                    if ~obj.IsDocked && ~isempty(obj.Figure) && isvalid(obj.Figure)
                        obj.closeAllStandaloneWindows();
                    end
                    
                    % Update our state
                    obj.TextArea = dockedTextArea;
                    obj.ParentPanel = panel;
                    obj.IsDocked = true;
                    obj.ClearButton = findall(panel, 'Type', 'UIButton', 'Text', 'Clear');
                    
                    % Add any previous text to the docked window
                    if ~isempty(previousText)
                        currentText = obj.TextArea.Value;
                        obj.TextArea.Value = obj.concatenateText(currentText, previousText);
                        drawnow;
                        obj.TextArea.scroll('bottom');
                    end
                end
            else
                % Force unique window first with priority for docked windows
                obj.preferDockedWindow();
                
                % Now we should have a valid UI (either docked or standalone)
                % If we still don't, create one (respecting docked-only mode)
                if (obj.IsDocked && (isempty(obj.TextArea) || ~isvalid(obj.TextArea))) || ...
                   (~obj.IsDocked && (isempty(obj.Figure) || ~isvalid(obj.Figure)))
                    
                    if CommandWindowApp.isUndockingAllowed() && ~obj.IsDocked
                        % Reset state and create standalone window if allowed
                        obj.createGUI();
                    else
                        % Store the text but don't create window (docked mode enforced)
                        obj.CurrentText = obj.concatenateText(obj.CurrentText, text);
                        fprintf('CommandWindowApp (no window): %s\n', char(string(text)));
                        return;
                    end
                end
            end
            
            % Store the text regardless of UI state
            obj.CurrentText = obj.concatenateText(obj.CurrentText, text);
            
            % Add text to the TextArea if it's valid
            if ~isempty(obj.TextArea) && isvalid(obj.TextArea)
                currentText = obj.TextArea.Value;
                obj.TextArea.Value = obj.concatenateText(currentText, text);
                
                drawnow;
                obj.TextArea.scroll('bottom');
            else
                % If we still can't display, at least output to MATLAB console
                if iscell(text)
                    fprintf('CommandWindowApp: %s\n\n', text{1});
                else
                    fprintf('CommandWindowApp: %s\n\n', char(text));
                end
            end
        end
        
        function SetPosition(obj, position)
            if obj.IsDocked
                warning('Cannot set position when docked. Undock first using undockFromPanel().');
                return;
            end
            
            if isempty(obj.Figure) || ~isvalid(obj.Figure)
                obj.createGUI();
            end
            
            if isvalid(obj.Figure)
                if numel(position) == 4
                    oldPosition = obj.Figure.Position;
                    obj.Figure.Position = position;
                    drawnow;
                    newPosition = obj.Figure.Position;
                    
                    fprintf('CommandWindowApp: Position changed from [%d, %d, %d, %d] to [%d, %d, %d, %d]\n', ...
                        oldPosition, newPosition);
                else
                    warning('Invalid position format. Expected [x, y, width, height].');
                end
            else
                warning('Failed to set position. GUI is not valid.');
            end
        end

        function ensureVisible(obj)
            % Force unique window first, prioritizing docked
            obj.preferDockedWindow();
            
            if obj.IsDocked
                % If docked, make sure parent panel is visible
                if ~isempty(obj.ParentPanel) && isvalid(obj.ParentPanel)
                    try
                        parentFig = ancestor(obj.ParentPanel, 'figure');
                        if ~isempty(parentFig) && isvalid(parentFig)
                            parentFig.Visible = 'on';
                            figure(parentFig);
                        end
                    catch
                        % If we can't make the parent visible, do nothing
                    end
                end
            else
                if isempty(obj.Figure) || ~isvalid(obj.Figure)
                    obj.createGUI();
                end
                
                if ~isempty(obj.Figure) && isvalid(obj.Figure)
                    obj.Figure.Visible = 'on';
                    figure(obj.Figure);
                end
            end
        end
        
        function setIconFolder(obj, folderPath)
            obj.IconFolder = folderPath;
            if (~isempty(obj.Figure) && isvalid(obj.Figure)) || ...
               (~isempty(obj.TextArea) && isvalid(obj.TextArea))
                obj.applyDefaultStyling();
            end
        end
        
        function applyDefaultStyling(obj)
            if isempty(obj.TextArea) || ~isvalid(obj.TextArea)
                return;
            end
            
            % Set background color for text area
            obj.TextArea.BackgroundColor = [0.33, 0.33, 0.33];
            
            % Set text color to white
            obj.TextArea.FontColor = [1, 1, 1];
            
            % Set font size
            obj.TextArea.FontSize = 16;
            
            % Set background color for figure if not docked
            if ~obj.IsDocked && ~isempty(obj.Figure) && isvalid(obj.Figure)
                obj.Figure.Color = [0.33, 0.33, 0.33];
            end
            
            % Try to set custom font
            if ~isempty(obj.IconFolder) && exist(obj.IconFolder, 'dir')
                fontPath = fullfile(obj.IconFolder, 'Raleway-Regular.ttf');
                if exist(fontPath, 'file')
                    try
                        obj.setFont(fontPath);
                    catch
                        warning('Failed to set custom font. Using default font instead.');
                        obj.TextArea.FontName = 'Arial'; % Fallback font
                    end
                else
                    obj.TextArea.FontName = 'Arial'; % Fallback font
                end
            else
                obj.TextArea.FontName = 'Arial'; % Default font if IconFolder is not set
            end
        end
        
        function setFont(obj, fontPath)
            if isempty(obj.TextArea) || ~isvalid(obj.TextArea)
                return;
            end
            
            [~, ~, ext] = fileparts(fontPath);
            if strcmpi(ext, '.ttf')
                try
                    % Set the font for the TextArea
                    obj.TextArea.FontName = fontPath;
                catch
                    warning('Failed to set custom font. Using default font instead.');
                    obj.TextArea.FontName = 'Arial'; % Fallback font
                end
            else
                error('Unsupported font format. Please use a TTF file.');
            end
        end
        
        function clearTextArea(obj)
            if ~isempty(obj.TextArea) && isvalid(obj.TextArea)
                obj.TextArea.Value = '';
                obj.CurrentText = '';
            else
                obj.CurrentText = '';
            end
        end

    end
end