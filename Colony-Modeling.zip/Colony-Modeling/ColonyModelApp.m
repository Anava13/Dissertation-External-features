classdef ColonyModelApp < matlab.apps.AppBase
    % ColonyModelApp: interactive colony growth model for Supplemental 1
    %
    % Build a p(success) trajectory from flat segments, ramps, and branch
    % events, set epsilon per segment, and press Run Model to simulate the
    % colony set and view its histogram, KDE, mixture fit, and lineage
    % composition. The Presets panel loads every trajectory and grid
    % condition behind the Supplemental 1 figures and tables.
    %
    % Launch from the package folder:  ColonyModelApp

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure  matlab.ui.Figure
    end

    
    properties (Access = private)
        library 

        MainGrid 
        TrajectoryPlot
AddFlatButton
AddRampButton
AddBranchButton
RemoveSegmentButton
RunModelButton
UniversalPanel
NColoniesSpinner
DetectionLimitSpinner
LogNormalCheck
LibraryCheck
GaussianCheck
Parameters
  spec = struct()
        selected_node_id = 0
        selected_port = 0
        ArrestedLine
        VRoundsSpinner
        PresetPanel
        PresetDropDown
        PresetDescription
        PresetActionButton
        ExportButton
        SeedSpinner
        CompareControlCheck
        presets
        rootFolder
        lastResults = []
        lastSpec = []
        lastRunName = ''
        currentPresetId = 'Custom'
    end
    
    methods (Access = private)

%% User Interface
function createCustomComponents(app)
    % CONTROLLER: Build the complete Scenario Builder layout
    %
    % Creates: UIFigure, trajectory axes with segment buttons,
    % universal parameters panel, and dynamic node parameters panel.

    % === UIFigure ===

    app.UIFigure.Position = [60 60 1360 820];
    app.UIFigure.Name = 'Colony Model: Scenario Builder';
    app.UIFigure.Color = [1 1 1];

    % === Main Grid: [Trajectory+Buttons | Parameters] ===
    app.MainGrid = uigridlayout(app.UIFigure, [1 2]);
    app.MainGrid.ColumnWidth = {'3x', '1x'};
    app.MainGrid.Padding = [10 10 10 10];
    app.MainGrid.ColumnSpacing = 10;

    % === LEFT COLUMN: Trajectory axes + button bar ===
    leftGrid = uigridlayout(app.MainGrid, [2 1]);
    leftGrid.Layout.Row = 1;
    leftGrid.Layout.Column = 1;
    leftGrid.RowHeight = {'1x', 40};
    leftGrid.RowSpacing = 8;
    leftGrid.Padding = [0 0 0 0];

    % Trajectory axes
    app.TrajectoryPlot = uiaxes(leftGrid);
    app.TrajectoryPlot.Layout.Row = 1;
    app.TrajectoryPlot.Layout.Column = 1;
    title(app.TrajectoryPlot, 'p(success) Trajectory');
    xlabel(app.TrajectoryPlot, 'Round');
    ylabel(app.TrajectoryPlot, 'p(success)');
    app.TrajectoryPlot.YLim = [-0.12 1.05];
    app.TrajectoryPlot.XLim = [0 50];
    app.TrajectoryPlot.Box = 'on';
    grid(app.TrajectoryPlot, 'on');

    % Button bar
    buttonGrid = uigridlayout(leftGrid, [1 6]);
    buttonGrid.Layout.Row = 2;
    buttonGrid.Layout.Column = 1;
    buttonGrid.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
    buttonGrid.Padding = [0 0 0 0];
    buttonGrid.ColumnSpacing = 5;

    app.AddFlatButton = uibutton(buttonGrid, 'Text', 'Add Flat');
    app.AddFlatButton.Layout.Row = 1;
    app.AddFlatButton.Layout.Column = 1;

    app.AddRampButton = uibutton(buttonGrid, 'Text', 'Add Ramp');
    app.AddRampButton.Layout.Row = 1;
    app.AddRampButton.Layout.Column = 2;

    app.AddBranchButton = uibutton(buttonGrid, 'Text', 'Add Branch');
    app.AddBranchButton.Layout.Row = 1;
    app.AddBranchButton.Layout.Column = 3;

    app.RemoveSegmentButton = uibutton(buttonGrid, 'Text', 'Remove');
    app.RemoveSegmentButton.Layout.Row = 1;
    app.RemoveSegmentButton.Layout.Column = 4;

    app.RunModelButton = uibutton(buttonGrid, 'Text', 'Run Model');
    app.RunModelButton.Layout.Row = 1;
    app.RunModelButton.Layout.Column = 5;
    app.RunModelButton.BackgroundColor = [0.2 0.6 0.3];
    app.RunModelButton.FontColor = [1 1 1];
    app.RunModelButton.FontWeight = 'bold';

    app.ExportButton = uibutton(buttonGrid, 'Text', 'Export Last Run');
    app.ExportButton.Layout.Row = 1;
    app.ExportButton.Layout.Column = 6;
    app.ExportButton.Enable = 'off';

    % Wire button callbacks
    app.AddFlatButton.ButtonPushedFcn   = @(~,~) addNode(app, 'flat');
    app.AddRampButton.ButtonPushedFcn   = @(~,~) addNode(app, 'ramp');
    app.AddBranchButton.ButtonPushedFcn = @(~,~) addNode(app, 'branch');
    app.RemoveSegmentButton.ButtonPushedFcn = @(~,~) removeNode(app);
    app.RunModelButton.ButtonPushedFcn  = @(~,~) compileSpec(app);
    app.ExportButton.ButtonPushedFcn    = @(~,~) exportLastResults(app);
    

    % === RIGHT COLUMN: Universal params + Node params ===
    rightGrid = uigridlayout(app.MainGrid, [3 1]);
    rightGrid.Layout.Row = 1;
    rightGrid.Layout.Column = 2;
    rightGrid.RowHeight = {180, 290, '1x'};
    rightGrid.RowSpacing = 10;
    rightGrid.Padding = [0 0 0 0];

    % --- Presets Panel ---
    app.PresetPanel = uipanel(rightGrid, 'Title', 'Presets (Supplemental 1)');
    app.PresetPanel.Layout.Row = 1;
    app.PresetPanel.Layout.Column = 1;

    presetGrid = uigridlayout(app.PresetPanel, [3 1]);
    presetGrid.RowHeight = {22, '1x', 26};
    presetGrid.Padding = [10 8 10 8];
    presetGrid.RowSpacing = 6;

    presetItems = cell(1, length(app.presets));
    for k = 1:length(app.presets)
        if strcmp(app.presets(k).kind, 'trajectory')
            kindTag = 'Trajectory';
        else
            kindTag = 'Grid';
        end
        presetItems{k} = sprintf('%s | %s', kindTag, app.presets(k).title);
    end
    app.PresetDropDown = uidropdown(presetGrid, ...
        'Items', presetItems, 'ItemsData', 1:length(app.presets));
    app.PresetDropDown.Layout.Row = 1;
    app.PresetDropDown.ValueChangedFcn = @(~,~) onPresetSelected(app);

    app.PresetDescription = uilabel(presetGrid, 'Text', '', ...
        'WordWrap', 'on', 'VerticalAlignment', 'top', ...
        'FontColor', [0.3 0.3 0.3]);
    app.PresetDescription.Layout.Row = 2;

    app.PresetActionButton = uibutton(presetGrid, 'Text', 'Load into builder');
    app.PresetActionButton.Layout.Row = 3;
    app.PresetActionButton.ButtonPushedFcn = @(~,~) onPresetAction(app);

    % --- Universal Parameters Panel ---
    app.UniversalPanel = uipanel(rightGrid, 'Title', 'Universal Parameters');
    app.UniversalPanel.Layout.Row = 2;
    app.UniversalPanel.Layout.Column = 1;

    uniGrid = uigridlayout(app.UniversalPanel, [9 2]);
    uniGrid.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22};
    uniGrid.ColumnWidth = {'fit', '1x'};
    uniGrid.Padding = [10 10 10 5];
    uniGrid.RowSpacing = 4;

    % Row 1: Colonies
    lbl = uilabel(uniGrid, 'Text', 'Colonies', 'HorizontalAlignment', 'right');
    lbl.Layout.Row = 1; lbl.Layout.Column = 1;
    app.NColoniesSpinner = uispinner(uniGrid, 'Value', 1000, ...
        'Limits', [10 100000], 'Step', 100);
    app.NColoniesSpinner.Layout.Row = 1; app.NColoniesSpinner.Layout.Column = 2;

    % Row 2: Total Rounds
    lbl = uilabel(uniGrid, 'Text', 'Total Division Rounds', 'HorizontalAlignment', 'right');
    lbl.Layout.Row = 2; lbl.Layout.Column = 1;
    app.VRoundsSpinner = uispinner(uniGrid, 'Value', 40, ...
        'Limits', [5 200], 'Step', 5);
    app.VRoundsSpinner.Layout.Row = 2; app.VRoundsSpinner.Layout.Column = 2;
    app.VRoundsSpinner.ValueChangedFcn = @(~,~) onTotalRoundsChanged(app);

    % Row 3: Detection Limit
    lbl = uilabel(uniGrid, 'Text', 'Min. Detectable Colony Radius μm', 'HorizontalAlignment', 'right');
    lbl.Layout.Row = 3; lbl.Layout.Column = 1;
    app.DetectionLimitSpinner = uispinner(uniGrid, 'Value', 50, ...
        'Limits', [10 200], 'Step', 5);
    app.DetectionLimitSpinner.Layout.Row = 3; app.DetectionLimitSpinner.Layout.Column = 2;

    % Row 4: RNG seed
    lbl = uilabel(uniGrid, 'Text', 'RNG Seed', 'HorizontalAlignment', 'right');
    lbl.Layout.Row = 4; lbl.Layout.Column = 1;
    app.SeedSpinner = uispinner(uniGrid, 'Value', 1, ...
        'Limits', [0 2^31 - 1], 'Step', 1, 'RoundFractionalValues', 'on');
    app.SeedSpinner.Layout.Row = 4; app.SeedSpinner.Layout.Column = 2;

    % Row 5: Flat control comparison
    app.CompareControlCheck = uicheckbox(uniGrid, ...
        'Text', 'Run flat control (phi 0.75, eps 0) alongside', 'Value', true);
    app.CompareControlCheck.Layout.Row = 5; app.CompareControlCheck.Layout.Column = [1 2];

    % Row 6: Mixture Methods header
    lbl = uilabel(uniGrid, 'Text', 'Mixture Methods', 'FontWeight', 'bold');
    lbl.Layout.Row = 6; lbl.Layout.Column = [1 2];

    % Rows 7-9: Mixture method checkboxes
    app.LogNormalCheck = uicheckbox(uniGrid, 'Text', 'LogNormal', 'Value', true);
    app.LogNormalCheck.Layout.Row = 7; app.LogNormalCheck.Layout.Column = [1 2];

    app.LibraryCheck = uicheckbox(uniGrid, 'Text', 'Library (40 rounds only)', 'Value', true);
    app.LibraryCheck.Layout.Row = 8; app.LibraryCheck.Layout.Column = [1 2];

    app.GaussianCheck = uicheckbox(uniGrid, 'Text', 'Gaussian', 'Value', false);
    app.GaussianCheck.Layout.Row = 9; app.GaussianCheck.Layout.Column = [1 2];

    % --- Node Parameters Panel (dynamic content) ---
    app.Parameters = uipanel(rightGrid, 'Title', 'Node Parameters');
    app.Parameters.Layout.Row = 3;
    app.Parameters.Layout.Column = 1;

    % Initial placeholder
    placeholderGrid = uigridlayout(app.Parameters, [1 1]);
    placeholderGrid.Padding = [10 10 10 10];
    uilabel(placeholderGrid, ...
        'Text', 'Initializing...', ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'center', ...
        'FontColor', [0.5 0.5 0.5]);

    % === Show Figure and Initialize ===
    app.UIFigure.Visible = 'on';
    initializeSpec(app);
    onPresetSelected(app);
end
function updateButtonStates(app)
    % CONTROLLER: Enable or disable Add/Remove buttons based on current selection

    canAdd = resolveCanAdd(app);
    applyButtonStates(app, canAdd);

    % === SUB-CONTROLLERS ===

    function canAdd = resolveCanAdd(app)
        % MODEL: Determine which actions are valid for current selection (TERMINAL)
        canAdd = struct('flat', false, 'ramp', false, 'branch', false, 'remove', false);

        if app.selected_node_id == 0
            return;
        end

        % Arrested pool: only branch allowed
        if app.selected_node_id == -1
            canAdd.branch = true;
            return;
        end

        idx = findNodeIndex(app, app.selected_node_id);
        if idx == 0, return; end

        node = app.spec.nodes(idx);
        canAdd.remove = true;

        switch node.type
            case {'flat', 'ramp'}
                % Can add if no child exists
                if node.child_id == 0
                    canAdd.flat = true;
                    canAdd.ramp = true;
                    canAdd.branch = true;
                end

            case 'branch'
                % Can add to selected port if it has no child
                if app.selected_port > 0 ...
                        && app.selected_port <= length(node.outputs) ...
                        && node.outputs(app.selected_port).child_id == 0
                    canAdd.flat = true;
                    canAdd.ramp = true;
                    canAdd.branch = true;
                end
        end
    end

    function applyButtonStates(app, canAdd)
        % VIEW: Apply enable/disable states to buttons (TERMINAL)
        app.AddFlatButton.Enable = boolToOnOff(canAdd.flat);
        app.AddRampButton.Enable = boolToOnOff(canAdd.ramp);
        app.AddBranchButton.Enable = boolToOnOff(canAdd.branch);
        app.RemoveSegmentButton.Enable = boolToOnOff(canAdd.remove);

        function state = boolToOnOff(val)
            % MODEL: Convert boolean to 'on'/'off' string (TERMINAL)
            if val
                state = 'on';
            else
                state = 'off';
            end
        end
    end
end
function y = phiToY(~, phi, arrested_y)
    % MODEL: Map phi values to y-coordinates for rendering (TERMINAL)
    % phi == 0 renders on the arrested pool line
    y = phi;
    y(phi == 0) = arrested_y;
end
function initializeSpec(app)
    % CONTROLLER: Create the default trajectory specification and draw initial state

    spec = buildDefaultSpec(app);
    app.spec = spec;
    app.selected_node_id = spec.tree.root_ids(1);
    app.selected_port = 0;
    recomputeAllRounds(app);
    refreshTrajectory(app);
    selectNode(app, app.selected_node_id, 0);
    updateButtonStates(app);

    % === SUB-CONTROLLER ===
    function spec = buildDefaultSpec(app)
    % SUB-CONTROLLER: Build spec with one default flat node
    % Located inside: initializeSpec

    rootNode = makeDefaultRoot(app);
    spec = assembleSpec(rootNode);

    function node = makeDefaultRoot(app)
        % MODEL: Create default flat root node (TERMINAL)
        node = makeEmptyNode(app, 1, 'flat');
        node.phi = 0.75;
        node.epsilon = 0;
        node.duration = app.VRoundsSpinner.Value;
    end

    function spec = assembleSpec(rootNode)
        % MODEL: Assemble spec structure (TERMINAL)
        spec = struct();
        spec.tree = struct();
        spec.tree.root_ids = rootNode.id;
        spec.tree.next_id = rootNode.id + 1;
        spec.tree.arrested_pool = struct( ...
            'enabled', true, ...
            'y_position', -0.05);
        spec.nodes = rootNode;
    end
end

end
function phi = findUpstreamEndPhi(app, nodeId)
    % MODEL: Walk upstream through tree to find the phi flowing into a node (TERMINAL)
    phi = NaN;
    idx = findNodeIndex(app, nodeId);
    if idx == 0, return; end

    node = app.spec.nodes(idx);
    pid = node.parent_id;

    if pid <= 0, return; end

    pidx = findNodeIndex(app, pid);
    if pidx == 0, return; end

    parent = app.spec.nodes(pidx);
    if strcmp(parent.type, 'branch')
        phi = findUpstreamEndPhi(app, pid);
    else
        phi = getNodeEndPhi(app, parent);
    end
end

%% Segments


%% Nodes
function addNode(app, nodeType)
    % CONTROLLER: Add a new node at the selected attachment point

    newNode = buildNewNode(app, nodeType);
    if isempty(newNode), return; end

    attachNode(app, newNode);
    recomputeAllRounds(app);
    propagateLinkedValues(app);
    refreshTrajectory(app);
    selectNode(app, newNode.id, 0);
    updateButtonStates(app);

    % === SUB-CONTROLLERS ===

   function newNode = buildNewNode(app, nodeType)
    % SUB-CONTROLLER: Create a new node with appropriate defaults
    % Located inside: addNode

    prevPhi = resolvePreviousPhi(app);
    expectedStart = resolveExpectedStartRound(app);
    newNode = createDefaultNode(app, nodeType, prevPhi, expectedStart);

    function prevPhi = resolvePreviousPhi(app)
        % MODEL: Determine phi from upstream context (TERMINAL)
        prevPhi = 0.75;

        if app.selected_node_id == -1
            prevPhi = 0;
            return;
        end
        if app.selected_node_id == 0
            return;
        end

        idx = findNodeIndex(app, app.selected_node_id);
        if idx == 0, return; end

        node = app.spec.nodes(idx);
        if strcmp(node.type, 'branch')
            upstream = findUpstreamEndPhi(app, node.id);
            if ~isnan(upstream)
                prevPhi = upstream;
            end
        else
            candidate = getNodeEndPhi(app, node);
            if ~isnan(candidate)
                prevPhi = candidate;
            end
        end
    end

    function startRound = resolveExpectedStartRound(app)
        % MODEL: Determine what round the new node will start at (TERMINAL)
        startRound = 1;

        if app.selected_node_id <= 0
            return;
        end

        idx = findNodeIndex(app, app.selected_node_id);
        if idx == 0, return; end

        node = app.spec.nodes(idx);
        switch node.type
            case {'flat', 'ramp'}
                startRound = node.end_round + 1;
            case 'branch'
                startRound = node.start_round;
        end
    end

    function newNode = createDefaultNode(app, nodeType, prevPhi, expectedStart)
        % MODEL: Create a fully-configured default node (TERMINAL)
        newId = app.spec.tree.next_id;
        newNode = makeEmptyNode(app, newId, nodeType);
        totalRounds = app.VRoundsSpinner.Value;

        switch nodeType
            case 'flat'
                newNode.phi = prevPhi;
                newNode.duration = max(1, totalRounds - expectedStart + 1);
            case 'ramp'
                newNode.phi_start = prevPhi;
                newNode.phi_end = max(prevPhi - 0.20, 0.05);
                newNode.duration = min(10, max(1, totalRounds - expectedStart + 1));
                newNode.linked = true;
            case 'branch'
                newNode.outputs = struct( ...
                    'label',       {'continues', 'branch'}, ...
                    'probability', {0.50, 0.50}, ...
                    'child_id',    {0, 0});
                if app.selected_node_id == -1
                    newNode.anchor_round = 1;
                end
        end
    end
end
    function attachNode(app, newNode)
        % SUB-CONTROLLER: Wire the new node into the tree

        newNode = setParentInfo(app, newNode);
        updateParentLink(app, newNode);
        appendToNodes(app, newNode);

        function newNode = setParentInfo(app, newNode)
            % MODEL: Set parent_id and port_index on the new node (TERMINAL)
            if app.selected_node_id == -1
                newNode.parent_id = -1;
            elseif app.selected_node_id > 0
                newNode.parent_id = app.selected_node_id;
                idx = findNodeIndex(app, app.selected_node_id);
                if idx > 0 && strcmp(app.spec.nodes(idx).type, 'branch')
                    newNode.port_index = app.selected_port;
                end
            end
        end

        function updateParentLink(app, newNode)
            % MODEL: Update parent node's child pointer (TERMINAL)
            if newNode.parent_id == -1
                app.spec.tree.root_ids(end + 1) = newNode.id;
            elseif newNode.parent_id > 0
                pidx = findNodeIndex(app, newNode.parent_id);
                if pidx == 0, return; end

                if strcmp(app.spec.nodes(pidx).type, 'branch')
                    port = newNode.port_index;
                    if port > 0 && port <= length(app.spec.nodes(pidx).outputs)
                        app.spec.nodes(pidx).outputs(port).child_id = newNode.id;
                    end
                else
                    app.spec.nodes(pidx).child_id = newNode.id;
                end
            end
        end

        function appendToNodes(app, newNode)
            % MODEL: Add node to spec and increment counter (TERMINAL)
            if isempty(app.spec.nodes)
                app.spec.nodes = newNode;
            else
                app.spec.nodes(end + 1) = newNode;
            end
            app.spec.tree.next_id = app.spec.tree.next_id + 1;
        end
    end
end
function removeNode(app)
    % CONTROLLER: Remove the selected node and all descendants

    if app.selected_node_id <= 0, return; end

    disconnectFromParent(app);
    purgeNodeAndDescendants(app);
    updateSelectionAfterRemoval(app);
    recomputeAllRounds(app);
    propagateLinkedValues(app);
    refreshTrajectory(app);
    refreshPanelAfterRemoval(app);
    updateButtonStates(app);

    % === SUB-CONTROLLERS ===

    function disconnectFromParent(app)
        % SUB-CONTROLLER: Sever the parent's link to the removed node

        parentInfo = getParentInfo(app);
        clearParentLink(app, parentInfo);

        function info = getParentInfo(app)
            % MODEL: Get parent id and port of the selected node (TERMINAL)
            idx = findNodeIndex(app, app.selected_node_id);
            info = struct('parent_id', 0, 'port_index', 0, 'is_root', false);
            if idx == 0, return; end

            node = app.spec.nodes(idx);
            info.parent_id = node.parent_id;
            info.port_index = node.port_index;
            info.is_root = (node.parent_id == 0) || (node.parent_id == -1);
        end

        function clearParentLink(app, info)
            % MODEL: Clear the parent's child pointer (TERMINAL)
            if info.is_root
                app.spec.tree.root_ids( ...
                    app.spec.tree.root_ids == app.selected_node_id) = [];
            elseif info.parent_id > 0
                pidx = findNodeIndex(app, info.parent_id);
                if pidx == 0, return; end

                if strcmp(app.spec.nodes(pidx).type, 'branch')
                    port = info.port_index;
                    if port > 0 && port <= length(app.spec.nodes(pidx).outputs)
                        app.spec.nodes(pidx).outputs(port).child_id = 0;
                    end
                else
                    app.spec.nodes(pidx).child_id = 0;
                end
            end
        end
    end

    function purgeNodeAndDescendants(app)
        % MODEL: Remove the node and all descendants from spec.nodes (TERMINAL)
        removeIds = [app.selected_node_id, collectDescendantIds(app, app.selected_node_id)];
        keepMask = true(1, length(app.spec.nodes));
        for k = 1:length(app.spec.nodes)
            if any(app.spec.nodes(k).id == removeIds)
                keepMask(k) = false;
            end
        end
        app.spec.nodes = app.spec.nodes(keepMask);
    end

    function updateSelectionAfterRemoval(app)
        % MODEL: Move selection to parent or clear it (TERMINAL)
        if isempty(app.spec.nodes)
            app.selected_node_id = 0;
            app.selected_port = 0;
        elseif isempty(app.spec.tree.root_ids)
            app.selected_node_id = 0;
            app.selected_port = 0;
        else
            app.selected_node_id = app.spec.tree.root_ids(1);
            app.selected_port = 0;
        end
    end

    function refreshPanelAfterRemoval(app)
        % SUB-CONTROLLER: Show node info or placeholder after removal

        delete(app.Parameters.Children);

        if app.selected_node_id > 0
            selectNode(app, app.selected_node_id, 0);
        else
            showPlaceholder(app);
        end

        function showPlaceholder(app)
            % VIEW: Display empty-state placeholder (TERMINAL)
            g = uigridlayout(app.Parameters, [1 1]);
            g.Padding = [10 10 10 10];
            uilabel(g, ...
                'Text', 'Add a segment to begin', ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'center', ...
                'FontColor', [0.5 0.5 0.5]);
        end
    end
end
function selectNode(app, nodeId, portIndex)
    % CONTROLLER: Select a node, highlight it, and build its parameter panel

    app.selected_node_id = nodeId;
    app.selected_port = portIndex;
    refreshTrajectory(app);
    buildNodePanel(app);
    updateButtonStates(app);

    % === SUB-CONTROLLER ===

    function buildNodePanel(app)
        % SUB-CONTROLLER: Build the appropriate panel for the selected node

        clearPanel(app);

        if app.selected_node_id == -1
            buildArrestedPanel(app);
            return;
        end
        if app.selected_node_id == 0
            buildPlaceholderPanel(app);
            return;
        end

        idx = findNodeIndex(app, app.selected_node_id);
        if idx == 0
            buildPlaceholderPanel(app);
            return;
        end

        node = app.spec.nodes(idx);
        switch node.type
            case 'flat'
                buildFlatPanel(app, node);
            case 'ramp'
                buildRampPanel(app, node);
            case 'branch'
                buildBranchPanel(app, node);
        end

        function clearPanel(app)
            % VIEW: Remove all children from the parameters panel (TERMINAL)
            delete(app.Parameters.Children);
        end

        function buildPlaceholderPanel(app)
            % VIEW: Display empty-state placeholder (TERMINAL)
            g = uigridlayout(app.Parameters, [1 1]);
            g.Padding = [10 10 10 10];
            uilabel(g, ...
                'Text', 'Add a segment to begin', ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'center', ...
                'FontColor', [0.5 0.5 0.5]);
        end

        function buildArrestedPanel(app)
            % VIEW: Display arrested pool info (TERMINAL)
            g = uigridlayout(app.Parameters, [2 1]);
            g.RowHeight = {22, 'fit'};
            g.Padding = [10 10 10 10];
            g.RowSpacing = 8;

            uilabel(g, ...
                'Text', 'Arrested Pool', ...
                'FontWeight', 'bold', ...
                'HorizontalAlignment', 'center');

            uilabel(g, ...
                'Text', 'Select "Add Branch" to create a branch from the arrested pool.', ...
                'WordWrap', 'on', ...
                'HorizontalAlignment', 'center', ...
                'FontColor', [0.4 0.4 0.4]);
        end

        function buildFlatPanel(app, node)
    % SUB-CONTROLLER: Create controls for a flat node
    % Located inside: selectNode > buildNodePanel

    config = getFlatConfig(app, node);
    renderFlatControls(app, config);

    function config = getFlatConfig(app, node)
        % MODEL: Define flat panel values (TERMINAL)
        config = struct();
        config.phi = node.phi;
        config.epsilon = node.epsilon;
        config.duration = node.duration;
        config.maxDuration = max(1, app.VRoundsSpinner.Value - node.start_round + 1);
    end

    function renderFlatControls(app, config)
        % VIEW: Create flat node spinners and wire callbacks (TERMINAL)
        g = uigridlayout(app.Parameters, [3 2]);
        g.RowHeight = {22, 22, 22};
        g.ColumnWidth = {'fit', '1x'};
        g.Padding = [10 10 10 10];
        g.RowSpacing = 8;

        uilabel(g, 'Text', 'phi', 'HorizontalAlignment', 'right');
        sp = uispinner(g, 'Value', config.phi, ...
            'Limits', [0 0.99], 'Step', 0.01, ...
            'ValueDisplayFormat', '%.2f');
        sp.Layout.Row = 1; sp.Layout.Column = 2;
        sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'phi', src.Value);

        uilabel(g, 'Text', 'epsilon', 'HorizontalAlignment', 'right');
        sp = uispinner(g, 'Value', config.epsilon, ...
            'Limits', [0 0.30], 'Step', 0.01, ...
            'ValueDisplayFormat', '%.2f');
        sp.Layout.Row = 2; sp.Layout.Column = 2;
        sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'epsilon', src.Value);

        uilabel(g, 'Text', 'duration', 'HorizontalAlignment', 'right');
        sp = uispinner(g, 'Value', config.duration, ...
            'Limits', [1 config.maxDuration], 'Step', 1);
        sp.Layout.Row = 3; sp.Layout.Column = 2;
        sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'duration', src.Value);
    end
end
        function buildRampPanel(app, node)
    % SUB-CONTROLLER: Create controls for a ramp node
    % Located inside: selectNode > buildNodePanel

    config = getRampConfig(app, node);
    renderRampControls(app, config);

    function config = getRampConfig(app, node)
        % MODEL: Define ramp panel values (TERMINAL)
        config = struct();
        config.phi_start = node.phi_start;
        config.phi_end = node.phi_end;
        config.epsilon = node.epsilon;
        config.duration = node.duration;
        config.linked = node.linked;
        config.maxDuration = max(1, app.VRoundsSpinner.Value - node.start_round + 1);
    end

    function renderRampControls(app, config)
        % VIEW: Create ramp node spinners and wire callbacks (TERMINAL)
        g = uigridlayout(app.Parameters, [5 2]);
        g.RowHeight = {22, 22, 22, 22, 22};
        g.ColumnWidth = {'fit', '1x'};
        g.Padding = [10 10 10 10];
        g.RowSpacing = 8;

        uilabel(g, 'Text', 'phi start', 'HorizontalAlignment', 'right');
        phiStartSp = uispinner(g, 'Value', config.phi_start, ...
            'Limits', [0 0.99], 'Step', 0.01, ...
            'ValueDisplayFormat', '%.2f');
        phiStartSp.Layout.Row = 1; phiStartSp.Layout.Column = 2;
        phiStartSp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'phi_start', src.Value);
        if config.linked
            phiStartSp.Enable = 'off';
        end

        uilabel(g, 'Text', 'phi end', 'HorizontalAlignment', 'right');
        sp = uispinner(g, 'Value', config.phi_end, ...
            'Limits', [0 0.99], 'Step', 0.01, ...
            'ValueDisplayFormat', '%.2f');
        sp.Layout.Row = 2; sp.Layout.Column = 2;
        sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'phi_end', src.Value);

        uilabel(g, 'Text', 'epsilon', 'HorizontalAlignment', 'right');
        sp = uispinner(g, 'Value', config.epsilon, ...
            'Limits', [0 0.30], 'Step', 0.01, ...
            'ValueDisplayFormat', '%.2f');
        sp.Layout.Row = 3; sp.Layout.Column = 2;
        sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'epsilon', src.Value);

        uilabel(g, 'Text', 'duration', 'HorizontalAlignment', 'right');
        sp = uispinner(g, 'Value', config.duration, ...
            'Limits', [1 config.maxDuration], 'Step', 1);
        sp.Layout.Row = 4; sp.Layout.Column = 2;
        sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'duration', src.Value);

        cb = uicheckbox(g, 'Text', 'Link to previous', 'Value', config.linked);
        cb.Layout.Row = 5; cb.Layout.Column = [1 2];
        cb.ValueChangedFcn = @(src,~) onLinkedChanged(app, src.Value, phiStartSp);
    end
end
        function buildBranchPanel(app, node)
    % SUB-CONTROLLER: Create controls for a branch node
    % Located inside: selectNode > buildNodePanel

    config = getBranchConfig(app, node);
    renderBranchControls(app, config);

    function config = getBranchConfig(app, node)
        % MODEL: Define branch panel values (TERMINAL)
        config = struct();
        config.is_arrested = (node.parent_id == -1);
        config.anchor_round = node.anchor_round;
        config.outputs = node.outputs;
        config.n_outputs = length(node.outputs);
        config.selected_port = app.selected_port;
        config.branchRound = node.start_round;
        config.mode = node.mode;

        % Round spinner availability
        config.showRoundSpinner = false;
        config.minBranchRound = 1;
        config.maxBranchRound = app.VRoundsSpinner.Value;

        if ~config.is_arrested && node.parent_id > 0
            pidx = findNodeIndex(app, node.parent_id);
            if pidx > 0
                parentNode = app.spec.nodes(pidx);
                if ismember(parentNode.type, {'flat', 'ramp'})
                    config.showRoundSpinner = true;
                    config.minBranchRound = parentNode.start_round + 1;
                end
            end
        end

        % Probability sum
        config.prob_sum = 0;
        for k = 1:config.n_outputs
            config.prob_sum = config.prob_sum + node.outputs(k).probability;
        end
    end

    function renderBranchControls(app, config)
        % VIEW: Create branch node controls (TERMINAL)

        % Determine row count
        nRows = config.n_outputs + 3;
        if config.is_arrested
            nRows = nRows + 1;
        end
        if config.showRoundSpinner
            nRows = nRows + 1;
        end

        rowHeights = repmat({22}, 1, nRows);
        g = uigridlayout(app.Parameters, [nRows 4]);
        g.RowHeight = rowHeights;
        g.ColumnWidth = {'fit', '1x', 60, 40};
        g.Padding = [10 10 10 10];
        g.RowSpacing = 6;

        currentRow = 1;

        % Anchor round (arrested source only)
        if config.is_arrested
            uilabel(g, 'Text', 'Anchor Round', 'HorizontalAlignment', 'right');
            sp = uispinner(g, 'Value', config.anchor_round, ...
                'Limits', [1 config.maxBranchRound], 'Step', 1);
            sp.Layout.Row = currentRow; sp.Layout.Column = 2;
            sp.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'anchor_round', src.Value);
            currentRow = currentRow + 1;
        end

        % Branch round (non-arrested with segment parent)
        if config.showRoundSpinner
            lbl = uilabel(g, 'Text', 'Branch Round', 'HorizontalAlignment', 'right');
            lbl.Layout.Row = currentRow; lbl.Layout.Column = 1;
            sp = uispinner(g, 'Value', config.branchRound, ...
                'Limits', [config.minBranchRound config.maxBranchRound], 'Step', 1);
            sp.Layout.Row = currentRow; sp.Layout.Column = 2;
            sp.ValueChangedFcn = @(src,~) onBranchRoundChanged(app, src.Value);
            currentRow = currentRow + 1;
        end

        % Branch mode: one cell per colony, or every dividing cell rolls
        lbl = uilabel(g, 'Text', 'Branch Mode', 'HorizontalAlignment', 'right');
        lbl.Layout.Row = currentRow; lbl.Layout.Column = 1;
        dd = uidropdown(g, 'Items', {'per colony', 'per cell'}, ...
            'ItemsData', {'per_colony', 'per_cell'}, 'Value', config.mode);
        dd.Layout.Row = currentRow; dd.Layout.Column = [2 4];
        dd.ValueChangedFcn = @(src,~) onNodeParamChanged(app, 'mode', src.Value);
        currentRow = currentRow + 1;

        % Output rows
        for k = 1:config.n_outputs
            out = config.outputs(k);

            % Label
            lbl = uilabel(g, 'Text', sprintf('%d: %s', k, out.label));
            lbl.Layout.Row = currentRow; lbl.Layout.Column = 1;

            % Probability spinner
            sp = uispinner(g, 'Value', out.probability, ...
                'Limits', [0 1], 'Step', 0.05, ...
                'ValueDisplayFormat', '%.2f');
            sp.Layout.Row = currentRow; sp.Layout.Column = 2;
            sp.ValueChangedFcn = @(src,~) onBranchProbChanged(app, k, src.Value);

            % Status
            if out.child_id > 0
                cidx = findNodeIndex(app, out.child_id);
                if cidx > 0
                    statusText = formatNodeLabel(app, app.spec.nodes(cidx));
                else
                    statusText = '?';
                end
            else
                statusText = 'empty';
            end
            statusLbl = uilabel(g, 'Text', statusText, 'FontSize', 10, ...
                'FontColor', [0.4 0.4 0.4]);
            statusLbl.Layout.Row = currentRow; statusLbl.Layout.Column = 3;

            % Select button
            btn = uibutton(g, 'Text', char(9654));
            btn.Layout.Row = currentRow; btn.Layout.Column = 4;
            if k == config.selected_port
                btn.BackgroundColor = [0.7 0.85 1.0];
            end
            btn.ButtonPushedFcn = @(~,~) onPortSelected(app, k);

            currentRow = currentRow + 1;
        end

        % Add Output button
        addBtn = uibutton(g, 'Text', 'Add Output');
        addBtn.Layout.Row = currentRow; addBtn.Layout.Column = [1 2];
        addBtn.ButtonPushedFcn = @(~,~) onAddBranchOutput(app);
        currentRow = currentRow + 1;

        % Sum indicator
        if abs(config.prob_sum - 1.0) < 1e-6
            sumText = sprintf('Sum: %.2f  %s', config.prob_sum, char(10003));
            sumColor = [0.2 0.6 0.2];
        else
            sumText = sprintf('Sum: %.2f  %s', config.prob_sum, char(9888));
            sumColor = [0.8 0.2 0.2];
        end
        sumLbl = uilabel(g, 'Text', sumText, 'FontWeight', 'bold', ...
            'FontColor', sumColor);
        sumLbl.Layout.Row = currentRow; sumLbl.Layout.Column = [1 4];

        function onPortSelected(app, portIdx)
            % CONTROLLER: Set selected port and refresh panel
            app.selected_port = portIdx;
            refreshTrajectory(app);
            selectNode(app, app.selected_node_id, portIdx);
            updateButtonStates(app);
        end

        function onAddBranchOutput(app)
            % CONTROLLER: Add a new output to the branch node
            idx = findNodeIndex(app, app.selected_node_id);
            if idx == 0, return; end

            newOutput = struct( ...
                'label', sprintf('output_%d', length(app.spec.nodes(idx).outputs) + 1), ...
                'probability', 0, ...
                'child_id', 0);
            app.spec.nodes(idx).outputs(end + 1) = newOutput;
            selectNode(app, app.selected_node_id, app.selected_port);
        end
    end
end
    end
end
function node = makeEmptyNode(~, id, nodeType)
    % MODEL: Create a fully-fielded node struct with defaults (TERMINAL)
    node = struct( ...
        'id',           id, ...
        'type',         nodeType, ...
        'parent_id',    0, ...
        'port_index',   0, ...
        'phi',          NaN, ...
        'phi_start',    NaN, ...
        'phi_end',      NaN, ...
        'epsilon',      0, ...
        'duration',     0, ...
        'linked',       false, ...
        'child_id',     0, ...
        'anchor_round', NaN, ...
        'outputs',      [], ...
        'start_round',  0, ...
        'end_round',    0, ...
        'mode',         'per_colony');
end
function idx = findNodeIndex(app, nodeId)
    % MODEL: Find the array index of a node by its id (TERMINAL)
    idx = 0;
    for k = 1:length(app.spec.nodes)
        if app.spec.nodes(k).id == nodeId
            idx = k;
            return;
        end
    end
end
function phi = getNodeEndPhi(~, node)
    % MODEL: Return the ending phi of a segment node; NaN for branches (TERMINAL)
    switch node.type
        case 'flat'
            phi = node.phi;
        case 'ramp'
            phi = node.phi_end;
        case 'branch'
            phi = NaN;
    end
end
function label = formatNodeLabel(~, node)
    % MODEL: Build a human-readable label for a node (TERMINAL)
    switch node.type
        case 'flat'
            label = sprintf('Flat: phi=%.2f, rounds %d-%d', ...
                node.phi, node.start_round, node.end_round);
        case 'ramp'
            label = sprintf('Ramp: phi %.2f>%.2f, rounds %d-%d', ...
                node.phi_start, node.phi_end, node.start_round, node.end_round);
        case 'branch'
            nOut = length(node.outputs);
            if node.parent_id == -1
                label = sprintf('Branch (arrested) round %d, %d outputs', ...
                    node.start_round, nOut);
            else
                label = sprintf('Branch round %d, %d outputs', ...
                    node.start_round, nOut);
            end
    end
end

%% Calculation
function recomputeAllRounds(app)
    % CONTROLLER: Recompute start_round and end_round for all nodes in the tree

    for k = 1:length(app.spec.tree.root_ids)
        rootId = app.spec.tree.root_ids(k);
        rootIdx = findNodeIndex(app, rootId);
        if rootIdx == 0, continue; end

        if app.spec.nodes(rootIdx).parent_id == -1 ...
                && strcmp(app.spec.nodes(rootIdx).type, 'branch')
            startRound = app.spec.nodes(rootIdx).anchor_round;
            if isnan(startRound), startRound = 1; end
        else
            startRound = 1;
        end

        computeSubtreeRounds(app, rootId, startRound);
    end

    % === SUB-CONTROLLER ===

    function nextRound = computeSubtreeRounds(app, nodeId, startRound)
        % SUB-CONTROLLER: Recursively assign rounds to a subtree

        idx = findNodeIndex(app, nodeId);
        if idx == 0
            nextRound = startRound;
            return;
        end

        nodeRounds = assignNodeRounds(app, idx, startRound);
        nextRound = nodeRounds.next;
        propagateToChildren(app, idx, nodeRounds);

        function nr = assignNodeRounds(app, idx, startRound)
            % MODEL: Compute this node's round range (TERMINAL)
            nr = struct('next', startRound);
            node = app.spec.nodes(idx);

            switch node.type
                case {'flat', 'ramp'}
                    app.spec.nodes(idx).start_round = startRound;
                    app.spec.nodes(idx).end_round = startRound + node.duration - 1;
                    nr.next = app.spec.nodes(idx).end_round + 1;
                case 'branch'
                    app.spec.nodes(idx).start_round = startRound;
                    app.spec.nodes(idx).end_round = startRound;
                    nr.next = startRound;
            end
        end

        function propagateToChildren(app, idx, nodeRounds)
            % SUB-CONTROLLER: Recurse into child nodes
            node = app.spec.nodes(idx);

            switch node.type
                case {'flat', 'ramp'}
                    if node.child_id > 0
                        computeSubtreeRounds(app, node.child_id, nodeRounds.next);
                    end
                case 'branch'
                    for k = 1:length(node.outputs)
                        cid = node.outputs(k).child_id;
                        if cid > 0
                            computeSubtreeRounds(app, cid, nodeRounds.next);
                        end
                    end
            end
        end
    end
end
function propagateLinkedValues(app)
    % CONTROLLER: Update linked ramp phi_starts from their upstream predecessors

    for i = 1:length(app.spec.nodes)
        if strcmp(app.spec.nodes(i).type, 'ramp') && app.spec.nodes(i).linked
            upstreamPhi = resolveUpstreamPhi(app, app.spec.nodes(i).id);
            if ~isnan(upstreamPhi)
                app.spec.nodes(i).phi_start = upstreamPhi;
            end
        end
    end

    % === NESTED (called once) ===

    function phi = resolveUpstreamPhi(app, nodeId)
        % MODEL: Walk upstream past branches to find ending phi (TERMINAL)
        phi = NaN;
        idx = findNodeIndex(app, nodeId);
        if idx == 0, return; end

        pid = app.spec.nodes(idx).parent_id;
        while pid > 0
            pidx = findNodeIndex(app, pid);
            if pidx == 0, return; end

            pnode = app.spec.nodes(pidx);
            if ~strcmp(pnode.type, 'branch')
                phi = getNodeEndPhi(app, pnode);
                return;
            end
            pid = pnode.parent_id;
        end
    end
end
function refreshTrajectory(app)
    % CONTROLLER: Redraw the entire trajectory plot from the spec tree

    prepareAxes(app);
    drawArrestedPool(app);
    drawAllSubtrees(app);
    finalizeAxes(app);

    % === SUB-CONTROLLERS ===

    function prepareAxes(app)
        % VIEW: Clear axes and enable hold (TERMINAL)
        cla(app.TrajectoryPlot);
        hold(app.TrajectoryPlot, 'on');
    end

    function drawArrestedPool(app)
    % VIEW: Draw the arrested pool line and make it clickable (TERMINAL)
    % Located inside: refreshTrajectory
    if ~app.spec.tree.arrested_pool.enabled, return; end

    ay = app.spec.tree.arrested_pool.y_position;

    app.ArrestedLine = plot(app.TrajectoryPlot, ...
        [0, app.VRoundsSpinner.Value], [ay, ay], ...
        'Color', 'k', 'LineWidth', 2, 'LineStyle', '-', ...
        'HitTest', 'on', ...
        'ButtonDownFcn', @(~,~) selectNode(app, -1, 0));
end
    
    function drawAllSubtrees(app)
        % SUB-CONTROLLER: Walk each root and render its subtree
        for k = 1:length(app.spec.tree.root_ids)
            rootId = app.spec.tree.root_ids(k);
            connPoint = struct('round', NaN, 'phi', NaN);

            rootIdx = findNodeIndex(app, rootId);
            if rootIdx > 0 && app.spec.nodes(rootIdx).parent_id == -1
                connPoint.round = app.spec.nodes(rootIdx).start_round;
                connPoint.phi = app.spec.tree.arrested_pool.y_position;
            end

            drawSubtree(app, rootId, connPoint);
        end
    end

    function drawSubtree(app, nodeId, connPoint)
        % SUB-CONTROLLER: Recursively render a node and its children

        idx = findNodeIndex(app, nodeId);
        if idx == 0, return; end

        node = app.spec.nodes(idx);

        switch node.type
            case {'flat', 'ramp'}
                drawSegmentNode(app, node, connPoint);
            case 'branch'
                drawBranchNode(app, node, connPoint);
        end

        function drawSegmentNode(app, node, connPoint)
            % SUB-CONTROLLER: Render a segment with epsilon band and line

            plotData = computeSegmentPlotData(app, node, connPoint);
            style = computeNodeStyle(app, node);
            renderEpsilonBand(app, plotData, style);
            renderNodeLine(app, plotData, style, node.id);

            % Recurse to child
            if node.child_id > 0
                childConn = struct('round', node.end_round, ...
                    'phi', getNodeEndPhi(app, node));
                drawSubtree(app, node.child_id, childConn);
            end

            function plotData = computeSegmentPlotData(app, node, connPoint)
                % MODEL: Compute x, y, and epsilon band for one segment (TERMINAL)
                ay = app.spec.tree.arrested_pool.y_position;
                plotData = struct('x', [], 'y', [], 'band_upper', [], 'band_lower', []);

                switch node.type
                    case 'flat'
                        plotData.x = node.start_round:node.end_round;
                        plotData.y = phiToY(app, node.phi * ones(size(plotData.x)), ay);
                    case 'ramp'
                        plotData.x = node.start_round:node.end_round;
                        rawY = linspace(node.phi_start, node.phi_end, length(plotData.x));
                        plotData.y = phiToY(app, rawY, ay);
                end

                eps_val = node.epsilon;

                % Prepend connection point for visual continuity
                if ~isnan(connPoint.round) && ~isnan(connPoint.phi)
                    connY = phiToY(app, connPoint.phi, ay);
                    plotData.x = [connPoint.round, plotData.x];
                    plotData.y = [connY, plotData.y];
                end

                % Compute band in phi space, then map to y
                switch node.type
                    case 'flat'
                        rawPhi = node.phi * ones(size(plotData.x));
                    case 'ramp'
                        rawPhi = linspace(node.phi_start, node.phi_end, length(plotData.x));
                        if ~isnan(connPoint.phi)
                            rawPhi = [connPoint.phi, rawPhi(2:end)];
                        end
                end

                if ~isnan(connPoint.round) && ~isnan(connPoint.phi)
                    rawPhi = [connPoint.phi, rawPhi(2:end)];
                end

                bandUpper = min(1, rawPhi + 2 * eps_val);
                bandLower = max(0, rawPhi - 2 * eps_val);
                plotData.band_upper = phiToY(app, bandUpper, ay);
                plotData.band_lower = phiToY(app, bandLower, ay);
            end

            function style = computeNodeStyle(app, node)
                % MODEL: Determine visual properties for a node (TERMINAL)
                style = struct();
                isSelected = (node.id == app.selected_node_id);

                style.lineStyle = '-';
                style.alpha = 1.0;
                style.bandAlpha = 0.15;

                if isSelected
                    style.color = [0.0 0.4 0.8];
                    style.lineWidth = 3;
                else
                    style.color = [0.2 0.2 0.2];
                    style.lineWidth = 2;
                end
            end

            function renderEpsilonBand(app, plotData, style)
                % VIEW: Draw the epsilon shaded band (TERMINAL)
                if isempty(plotData.x), return; end
                if all(plotData.band_upper == plotData.band_lower), return; end

                band_x = [plotData.x, fliplr(plotData.x)];
                band_y = [plotData.band_upper, fliplr(plotData.band_lower)];
                fill(app.TrajectoryPlot, band_x, band_y, style.color, ...
                    'EdgeColor', 'none', 'FaceAlpha', style.bandAlpha, ...
                    'HitTest', 'off', 'PickableParts', 'none');
            end

            function renderNodeLine(app, plotData, style, nodeId)
                % VIEW: Draw the segment trajectory line (TERMINAL)
                if isempty(plotData.x), return; end

             h =   plot(app.TrajectoryPlot, plotData.x, plotData.y, ...
                    'Color', style.color, ...
                    'LineWidth', style.lineWidth, ...
                    'LineStyle', style.lineStyle, ...
                    'UserData', nodeId, ...
                    'HitTest', 'on', ...
                    'ButtonDownFcn', @(src,~) selectNode(app, src.UserData, 0));

                uistack(h, 'top')
            end
        end

        function drawBranchNode(app, node, connPoint)
    % SUB-CONTROLLER: Render smooth sigmoid fork and recurse into outputs
    %
    % Sigmoid arms extend BACKWARD from the branch round, overlapping
    % the upstream segment line. The "continues" arm lies flat on top
    % of the upstream line; diverging arms curve away, creating the
    % visual fork. Children pick up right at branch_round with no
    % connPoint prepend, so the sigmoid endpoint meets the child's
    % first plotted point exactly.

    forkConfig = computeForkConfig(app, node, connPoint);
    renderForkArms(app, node, forkConfig);

    function config = computeForkConfig(app, node, connPoint)
        % MODEL: Compute fork origin, geometry, and selection state (TERMINAL)
        ay = app.spec.tree.arrested_pool.y_position;

        config = struct();
        config.round    = node.start_round;
        config.spread   = 2;
        config.startX   = max(node.start_round - 2, 0);
        config.sigmoid_k  = 10;
        config.n_points   = 50;
        config.isSelected   = (node.id == app.selected_node_id);
        config.selectedPort = app.selected_port;
        config.ay = ay;

        if ~isnan(connPoint.phi)
            config.originY = phiToY(app, connPoint.phi, ay);
        elseif node.parent_id == -1
            config.originY = ay;
        else
            config.originY = 0.5;
        end
    end

    function renderForkArms(app, node, config)
        % SUB-CONTROLLER: Draw sigmoid arms and recurse into children

        for k = 1:length(node.outputs)
            cid = node.outputs(k).child_id;

            if cid > 0
                cidx = findNodeIndex(app, cid);
                if cidx == 0, continue; end

                childNode = app.spec.nodes(cidx);
                childPhi = getChildStartPhi(childNode);
                if isnan(childPhi), continue; end

                childY = phiToY(app, childPhi, config.ay);
                armStyle = computeArmStyle(config, k);
                sigmoidData = computeSigmoidCurve(config, childY);
                renderSigmoidArm(app, sigmoidData, armStyle, node.id);

                childConn = struct('round', NaN, 'phi', NaN);
                drawSubtree(app, cid, childConn);
            else
                stubData = computeStubData(config, k, length(node.outputs));
                renderStub(app, stubData, node.id);
            end
        end

        function phi = getChildStartPhi(childNode)
            % MODEL: Get starting phi of a child node (TERMINAL)
            switch childNode.type
                case 'flat'
                    phi = childNode.phi;
                case 'ramp'
                    phi = childNode.phi_start;
                otherwise
                    phi = NaN;
            end
        end

        function style = computeArmStyle(config, portIdx)
            % MODEL: Determine arm line styling (TERMINAL)
            style = struct();
            isPortSelected = config.isSelected && (portIdx == config.selectedPort);

            if isPortSelected
                style.color = [0.0 0.4 0.8];
                style.lineWidth = 3;
            elseif config.isSelected
                style.color = [0.4 0.4 0.4];
                style.lineWidth = 2;
            else
                style.color = [0.2 0.2 0.2];
                style.lineWidth = 2;
            end
        end

        function data = computeSigmoidCurve(config, targetY)
            % MODEL: Compute backward sigmoid from startX to branch round (TERMINAL)
            t = linspace(0, 1, config.n_points);
            s = 1 ./ (1 + exp(-config.sigmoid_k * (t - 0.5)));
            s = (s - s(1)) / (s(end) - s(1));

            data = struct();
            data.x = config.startX + t * (config.round - config.startX);
            data.y = config.originY + (targetY - config.originY) * s;
        end

        function renderSigmoidArm(app, data, style, nodeId)
            % VIEW: Draw one sigmoid arm, clickable to select the branch (TERMINAL)
            plot(app.TrajectoryPlot, data.x, data.y, ...
                'Color', style.color, ...
                'LineWidth', style.lineWidth, ...
                'LineStyle', '-', ...
                'UserData', nodeId, ...
                'HitTest', 'on', ...
                'ButtonDownFcn', @(src,~) selectNode(app, src.UserData, 0));
        end

        function data = computeStubData(config, portIdx, nOutputs)
            % MODEL: Compute short forward sigmoid stub for empty port (TERMINAL)
            yOffset = 0.08 * (portIdx - (nOutputs + 1) / 2);
            stubTargetY = config.originY + yOffset;

            stubEndX = config.round + config.spread * 0.5;

            t = linspace(0, 1, 30);
            s = 1 ./ (1 + exp(-config.sigmoid_k * (t - 0.5)));
            s = (s - s(1)) / (s(end) - s(1));

            data = struct();
            data.x = config.round + t * (stubEndX - config.round);
            data.y = config.originY + (stubTargetY - config.originY) * s;
        end

        function renderStub(app, data, nodeId)
            % VIEW: Draw stub line with open circle endpoint (TERMINAL)
            plot(app.TrajectoryPlot, data.x, data.y, ...
                'Color', [0.7 0.7 0.7], ...
                'LineWidth', 1, ...
                'LineStyle', '-', ...
                'UserData', nodeId, ...
                'HitTest', 'on', ...
                'ButtonDownFcn', @(src,~) selectNode(app, src.UserData, 0));

            scatter(app.TrajectoryPlot, data.x(end), data.y(end), 20, ...
                [0.7 0.7 0.7], 'o', 'LineWidth', 1, ...
                'HitTest', 'off', 'PickableParts', 'none');
        end
    end
end
    end

    function finalizeAxes(app)
    % VIEW: Set axis limits and release hold (TERMINAL)
    % Located inside: refreshTrajectory
    app.TrajectoryPlot.XLim = [0 app.VRoundsSpinner.Value];
    app.TrajectoryPlot.YLim = [-0.12 1.05];
    hold(app.TrajectoryPlot, 'off');
end
end
function compileSpec(app)
    % CONTROLLER: Compile the trajectory tree, run the engine, and launch viewer

    v = app.VRoundsSpinner.Value;

    pathInfos = enumerateAllPaths(app, v);
    pools = buildAllPools(app, pathInfos, v);
    events = buildAllBranchEvents(app, pathInfos);
    scenario = assembleScenario(app, pools, events, v);

    fprintf('Compiled: %d pools, %d branch events, v=%d\n', ...
        length(scenario.config(1).Custom.pools), ...
        length(scenario.config(1).Custom.branch_events), v);

    warnIfLibraryMismatch(app, v);
    results = executeBuilderRun(app, scenario);
    recordRun(app, results, app.currentPresetId, app.spec);
    buildResultsViewer(results);

    % === SUB-CONTROLLERS ===

    function warnIfLibraryMismatch(app, v)
        % SUB-CONTROLLER: Alert when the library cannot apply to this run
        if app.LibraryCheck.Value && v ~= app.library.config.v
            showLibraryMismatch(app, v);
        end

        function showLibraryMismatch(app, v)
            % VIEW: Non-blocking alert (TERMINAL)
            uialert(app.UIFigure, sprintf(['The reference library was built at %d rounds. ' ...
                'This run uses %d rounds, so library fitting is skipped. ' ...
                'KDE and mixture fits still run.'], app.library.config.v, v), ...
                'Library skipped', 'Icon', 'warning');
        end
    end

    function results = executeBuilderRun(app, scenario)
        % SUB-CONTROLLER: Run the compiled trajectory behind a progress dialog
        dlg = startRunFeedback(app, 'Builder trajectory');
        closer = onCleanup(@() delete(dlg)); %#ok<NASGU>
        results = runScenario(scenario);
    end

    function pathInfos = enumerateAllPaths(app, v)
        % SUB-CONTROLLER: Walk tree and collect all root-to-leaf paths

        pathInfos = {};
        for k = 1:length(app.spec.tree.root_ids)
            rootId = app.spec.tree.root_ids(k);
            rootIdx = findNodeIndex(app, rootId);
            if rootIdx == 0, continue; end

            rootNode = app.spec.nodes(rootIdx);

            if strcmp(rootNode.type, 'branch')
                pathInfos = collectBranchRootPaths( ...
                    app, rootNode, pathInfos);
            else
                pathInfos = collectSegmentPaths( ...
                    app, rootId, [], [], pathInfos);
            end
        end

        function pathInfos = collectBranchRootPaths(app, branchNode, pathInfos)
            % SUB-CONTROLLER: Enumerate paths from a root-level branch (arrested source)
            for k = 1:length(branchNode.outputs)
                cid = branchNode.outputs(k).child_id;
                if cid == 0, continue; end

                bc = struct('branch_id', branchNode.id, 'output_index', k, ...
                    'is_arrested', true);
                pathInfos = collectSegmentPaths(app, cid, [], bc, pathInfos);
            end
        end

        function pathInfos = collectSegmentPaths(app, nodeId, segIds, branchChoices, pathInfos)
            % SUB-CONTROLLER: Recursively collect paths through segments and branches
            idx = findNodeIndex(app, nodeId);
            if idx == 0
                if ~isempty(segIds)
                    pathInfos{end+1} = makePathInfo(segIds, branchChoices);
                end
                return;
            end

            node = app.spec.nodes(idx);

            switch node.type
                case {'flat', 'ramp'}
                    segIds = [segIds, nodeId]; %#ok<AGROW>
                    if node.child_id > 0
                        pathInfos = collectSegmentPaths( ...
                            app, node.child_id, segIds, branchChoices, pathInfos);
                    else
                        pathInfos{end+1} = makePathInfo(segIds, branchChoices);
                    end

                case 'branch'
                    for k = 1:length(node.outputs)
                        cid = node.outputs(k).child_id;
                        bc = struct('branch_id', node.id, 'output_index', k, ...
                            'is_arrested', false);
                        newChoices = appendChoice(branchChoices, bc);

                        if cid > 0
                            pathInfos = collectSegmentPaths( ...
                                app, cid, segIds, newChoices, pathInfos);
                        else
                            if ~isempty(segIds)
                                pathInfos{end+1} = makePathInfo(segIds, newChoices);
                            end
                        end
                    end
            end

            function info = makePathInfo(segIds, branchChoices)
                % MODEL: Package a path into a struct (TERMINAL)
                info = struct();
                info.segment_ids = segIds;
                if isempty(branchChoices)
                    info.branch_choices = [];
                else
                    info.branch_choices = branchChoices;
                end
            end

            function newChoices = appendChoice(existing, newBC)
                % MODEL: Append a branch choice to the list (TERMINAL)
                if isempty(existing)
                    newChoices = newBC;
                else
                    newChoices = [existing, newBC];
                end
            end
        end
    end

    function pools = buildAllPools(app, pathInfos, v)
        % SUB-CONTROLLER: Build pool structs from enumerated paths

        nPaths = length(pathInfos);
        pools = [];
        palette = getPoolPalette();

        for i = 1:nPaths
            poolData = compilePathToTrajectory(app, pathInfos{i}, v);
            colorIdx = mod(i - 1, size(palette, 1)) + 1;
            isRoot = isRootPath(pathInfos{i});

            pool = buildPool( ...
                poolData.p_traj, poolData.eps_traj, ...
                sprintf('Pool_%d', i), palette(colorIdx, :), [], ...
                isRoot);

            if isempty(pools)
                pools = pool;
            else
                pools(end + 1) = pool; %#ok<AGROW>
            end
        end

        function palette = getPoolPalette()
            % MODEL: Color palette for pools (TERMINAL)
            palette = [ ...
                0.30 0.45 0.75;
                0.75 0.55 0.10;
                0.55 0.75 0.30;
                0.75 0.30 0.45;
                0.45 0.30 0.75;
                0.30 0.75 0.55];
        end

        function isRoot = isRootPath(pathInfo)
            % MODEL: Check if this path is a root continuation (TERMINAL)
            isRoot = true;
            if isempty(pathInfo.branch_choices), return; end

            for k = 1:length(pathInfo.branch_choices)
                bc = pathInfo.branch_choices(k);
                if bc.is_arrested || bc.output_index > 1
                    isRoot = false;
                    return;
                end
            end
        end

        function poolData = compilePathToTrajectory(app, pathInfo, v)
            % MODEL: Build phi and epsilon vectors from a path's segments (TERMINAL)
            p_traj = zeros(1, v);
            eps_traj = zeros(1, v);
            lastPhi = 0;

            for k = 1:length(pathInfo.segment_ids)
                nid = pathInfo.segment_ids(k);
                nidx = findNodeIndex(app, nid);
                if nidx == 0, continue; end

                seg = app.spec.nodes(nidx);
                sr = seg.start_round;
                er = min(seg.end_round, v);
                if sr > v, continue; end

                rounds = sr:er;

                switch seg.type
                    case 'flat'
                        p_traj(rounds) = seg.phi;
                        eps_traj(rounds) = seg.epsilon;
                        lastPhi = seg.phi;
                    case 'ramp'
                        p_traj(rounds) = linspace(seg.phi_start, seg.phi_end, length(rounds));
                        eps_traj(rounds) = seg.epsilon;
                        lastPhi = seg.phi_end;
                end
            end

            % Pad remaining rounds with last phi
            if ~isempty(pathInfo.segment_ids)
                nidx = findNodeIndex(app, pathInfo.segment_ids(end));
                if nidx > 0
                    lastEnd = app.spec.nodes(nidx).end_round;
                    if lastEnd < v
                        p_traj(lastEnd + 1 : v) = lastPhi;
                    end
                end
            end

            poolData = struct('p_traj', p_traj, 'eps_traj', eps_traj);
        end
    end

    function events = buildAllBranchEvents(app, pathInfos)
        % SUB-CONTROLLER: Build branch events from the tree's branch nodes

        events = [];
        branchNodes = findAllBranchNodes(app);

        for b = 1:length(branchNodes)
            node = branchNodes(b);
            nodeEvents = buildEventsForBranch(app, node, pathInfos);
            if isempty(events)
                events = nodeEvents;
            elseif ~isempty(nodeEvents)
                events = [events, nodeEvents]; %#ok<AGROW>
            end
        end

        function branchNodes = findAllBranchNodes(app)
            % MODEL: Collect all branch-type nodes (TERMINAL)
            branchNodes = [];
            for k = 1:length(app.spec.nodes)
                if strcmp(app.spec.nodes(k).type, 'branch')
                    if isempty(branchNodes)
                        branchNodes = app.spec.nodes(k);
                    else
                        branchNodes(end+1) = app.spec.nodes(k); %#ok<AGROW>
                    end
                end
            end
        end

        function nodeEvents = buildEventsForBranch(app, node, pathInfos)
            % SUB-CONTROLLER: Build events for one branch node

            isArrested = (node.parent_id == -1);
            branchRound = node.start_round;

            if isArrested
                sourcePoolIdx = 1;
                sourceType = 'arrested';
                startOutput = 1;
            else
                sourcePoolIdx = findPoolForBranchOutput( ...
                    pathInfos, node.id, 1);
                sourceType = 'dividing';
                startOutput = 2;
            end

            nodeEvents = [];
            cumulativeP = 0;

            for k = startOutput:length(node.outputs)
                out = node.outputs(k);
                if out.child_id == 0, continue; end

                destPoolIdx = findPoolForBranchOutput( ...
                    pathInfos, node.id, k);
                if destPoolIdx == 0, continue; end

                % Compute conditional probability
                condP = computeConditionalProb(out.probability, cumulativeP);
                cumulativeP = cumulativeP + out.probability;

                event = buildBranchEvent( ...
                    sourcePoolIdx, sourceType, destPoolIdx, ...
                    node.mode, condP, branchRound);

                if isempty(nodeEvents)
                    nodeEvents = event;
                else
                    nodeEvents(end+1) = event; %#ok<AGROW>
                end
            end

            function poolIdx = findPoolForBranchOutput(pathInfos, branchId, outputIndex)
                % MODEL: Find the first path going through a specific branch output (TERMINAL)
                poolIdx = 0;
                for i = 1:length(pathInfos)
                    pi = pathInfos{i};
                    if isempty(pi.branch_choices), continue; end
                    for j = 1:length(pi.branch_choices)
                        bc = pi.branch_choices(j);
                        if bc.branch_id == branchId && bc.output_index == outputIndex
                            poolIdx = i;
                            return;
                        end
                    end
                end
            end

            function condP = computeConditionalProb(rawP, cumulativePrior)
                % MODEL: Convert raw probability to conditional (TERMINAL)
                remaining = 1 - cumulativePrior;
                if remaining <= 0
                    condP = 0;
                else
                    condP = rawP / remaining;
                end
            end
        end
    end

    function scenario = assembleScenario(app, pools, events, v)
        % SUB-CONTROLLER: Wrap pools and events in engine-compatible grid scenario

        cellConfig = buildCellConfig(app, pools, events, v);
        options = buildAnalysisOptions(app, v);
        scenario = wrapInScenarioShell(cellConfig, options);

        function cellConfig = buildCellConfig(app, pools, events, v)
            % MODEL: Package pools and events into a cell config (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = makeUniversalConfig( ...
                app.NColoniesSpinner.Value, v, app.DetectionLimitSpinner.Value);
            cellConfig.pools = pools;
            if isempty(events)
                cellConfig.branch_events = [];
            else
                cellConfig.branch_events = events;
            end
            cellConfig.log_params = struct('source', 'ScenarioBuilder');
        end

        function options = buildAnalysisOptions(app, v)
            % MODEL: Build analysis options from UI state (TERMINAL)
            % Library fitting runs only when the run uses the library's
            % round count.
            options = defaultAnalysisOptions();
            options.rng_seed = app.SeedSpinner.Value;
            libraryApplies = ~isempty(app.library) && v == app.library.config.v;
            methods = string.empty;
            if app.LogNormalCheck.Value
                methods(end+1) = "LogNormal";
            end
            if app.LibraryCheck.Value && libraryApplies
                methods(end+1) = "Library";
            end
            if app.GaussianCheck.Value
                methods(end+1) = "Gaussian";
            end
            if isempty(methods)
                methods = "LogNormal";
            end
            options.mixture_distribution = methods;
            if libraryApplies
                options.library = app.library;
            end
        end

        function scenario = wrapInScenarioShell(cellConfig, options)
            % SUB-CONTROLLER: Build the grid scenario: the builder
            % trajectory, plus the flat control when that box is checked

            includeControl = app.CompareControlCheck.Value;
            labels = buildShellLabels(includeControl);
            scenario = assembleScenarioShell(labels, options, 'ScenarioBuilder');
            scenario = addCellConfig(scenario, 1, 1, cellConfig);
            if includeControl
                controlConfig = buildControlCellConfig(cellConfig.universal);
                scenario = addCellConfig(scenario, 1, 2, controlConfig);
            end

            function labels = buildShellLabels(includeControl)
                % MODEL: Build labels for the one-row grid (TERMINAL)
                labels = struct();
                labels.ordinal_display = {''};
                if includeControl
                    labels.nominal_display = {'Custom', 'FlatControl'};
                    labels.nominal_fields  = {'Custom', 'FlatControl'};
                else
                    labels.nominal_display = {'Custom'};
                    labels.nominal_fields  = {'Custom'};
                end
            end

            function controlConfig = buildControlCellConfig(universal)
                % SUB-CONTROLLER: Flat phi = 0.75, eps = 0 under the same universals
                v_ctrl = universal.v;
                pool = buildPool(0.75 * ones(1, v_ctrl), zeros(1, v_ctrl), ...
                    'FlatControl', [0.45 0.45 0.45], [], 1);
                controlConfig = packControlConfig(universal, pool);

                function controlConfig = packControlConfig(universal, pool)
                    % MODEL: Package the control cell (TERMINAL)
                    controlConfig = struct();
                    controlConfig.universal = universal;
                    controlConfig.pools = pool;
                    controlConfig.branch_events = [];
                    controlConfig.log_params = struct('source', 'FlatControl');
                end
            end
        end
    end
end
function ids = collectDescendantIds(app, nodeId)
    % MODEL: Recursively collect all descendant node ids (TERMINAL)
    ids = [];
    idx = findNodeIndex(app, nodeId);
    if idx == 0, return; end
    node = app.spec.nodes(idx);

    switch node.type
        case {'flat', 'ramp'}
            if node.child_id > 0
                ids = [node.child_id, collectDescendantIds(app, node.child_id)];
            end
        case 'branch'
            for k = 1:length(node.outputs)
                cid = node.outputs(k).child_id;
                if cid > 0
                    ids = [ids, cid, collectDescendantIds(app, cid)]; %#ok<AGROW>
                end
            end
    end
end


%% Event Handlers
function onTotalRoundsChanged(app)
    % CONTROLLER: Clamp all node durations to fit within new total rounds
    %
    % Iterates clamp + recompute until stable, since clamping one node
    % shifts downstream start_rounds, which may require further clamping.
    % Add to methods (Access = private).

    stabilizeDurations(app);
    propagateLinkedValues(app);
    refreshTrajectory(app);
    rebuildCurrentPanel(app);
    updateButtonStates(app);

    % === SUB-CONTROLLERS ===

    function stabilizeDurations(app)
        % SUB-CONTROLLER: Iteratively clamp durations until no changes remain

        for pass = 1:20
            recomputeAllRounds(app);
            anyChanged = clampDurationPass(app);
            if ~anyChanged, break; end
        end

        function anyChanged = clampDurationPass(app)
            % MODEL: Single pass clamping all flat/ramp durations (TERMINAL)
            totalRounds = app.VRoundsSpinner.Value;
            anyChanged = false;

            for i = 1:length(app.spec.nodes)
                node = app.spec.nodes(i);
                if ~ismember(node.type, {'flat', 'ramp'})
                    continue;
                end

                maxDur = totalRounds - node.start_round + 1;
                if maxDur < 1
                    maxDur = 1;
                end

                if node.duration > maxDur
                    app.spec.nodes(i).duration = maxDur;
                    anyChanged = true;
                end
            end
        end
    end

    function rebuildCurrentPanel(app)
        % SUB-CONTROLLER: Refresh the parameter panel for current selection

        if app.selected_node_id > 0
            selectNode(app, app.selected_node_id, app.selected_port);
        end
    end
end
function onNodeParamChanged(app, fieldName, newValue)
    % CONTROLLER: Write a parameter change back to the node and refresh
    idx = findNodeIndex(app, app.selected_node_id);
    if idx == 0, return; end

    app.spec.nodes(idx).(fieldName) = newValue;
    propagateLinkedValues(app);
    recomputeAllRounds(app);
    refreshTrajectory(app);
end
function onLinkedChanged(app, isLinked, phiStartSpinner)
    % CONTROLLER: Handle linked checkbox toggle for ramp nodes
    idx = findNodeIndex(app, app.selected_node_id);
    if idx == 0, return; end

    app.spec.nodes(idx).linked = isLinked;

    if isLinked
        upstreamPhi = findUpstreamEndPhi(app, app.selected_node_id);
        if ~isnan(upstreamPhi)
            app.spec.nodes(idx).phi_start = upstreamPhi;
            phiStartSpinner.Value = upstreamPhi;
        end
        phiStartSpinner.Enable = 'off';
    else
        phiStartSpinner.Enable = 'on';
    end

    propagateLinkedValues(app);
    recomputeAllRounds(app);
    refreshTrajectory(app);
end
function onBranchRoundChanged(app, newRound)
    % CONTROLLER: Move branch to a new round by adjusting parent duration
    % Add to methods (Access = private) alongside other shared callbacks.

    adjustParentDuration(app, newRound);
    clampDownstreamDurations(app);
    propagateLinkedValues(app);
    refreshTrajectory(app);
    selectNode(app, app.selected_node_id, app.selected_port);
    updateButtonStates(app);

    % === SUB-CONTROLLERS ===

    function adjustParentDuration(app, newRound)
        % MODEL: Set parent segment duration to place branch at newRound (TERMINAL)
        idx = findNodeIndex(app, app.selected_node_id);
        if idx == 0, return; end

        node = app.spec.nodes(idx);
        if node.parent_id <= 0, return; end

        pidx = findNodeIndex(app, node.parent_id);
        if pidx == 0, return; end

        app.spec.nodes(pidx).duration = newRound - app.spec.nodes(pidx).start_round;
    end

    function clampDownstreamDurations(app)
        % SUB-CONTROLLER: Iteratively clamp durations that exceed total rounds

        totalRounds = app.VRoundsSpinner.Value;

        for pass = 1:20
            recomputeAllRounds(app);
            anyChanged = false;

            for i = 1:length(app.spec.nodes)
                node = app.spec.nodes(i);
                if ~ismember(node.type, {'flat', 'ramp'})
                    continue;
                end

                maxDur = max(1, totalRounds - node.start_round + 1);
                if node.duration > maxDur
                    app.spec.nodes(i).duration = maxDur;
                    anyChanged = true;
                end
            end

            if ~anyChanged, break; end
        end
    end
end
function onBranchProbChanged(app, outputIndex, newValue)
    % CONTROLLER: Handle branch output probability change
    idx = findNodeIndex(app, app.selected_node_id);
    if idx == 0, return; end

    nOutputs = length(app.spec.nodes(idx).outputs);

    % Write new value
    app.spec.nodes(idx).outputs(outputIndex).probability = newValue;

    % Auto-adjust complement for two-output branches
    if nOutputs == 2
        otherIdx = 3 - outputIndex;
        app.spec.nodes(idx).outputs(otherIdx).probability = 1 - newValue;
    end

    % Rebuild panel to reflect changes
    selectNode(app, app.selected_node_id, app.selected_port);
end

%% Presets, run bookkeeping, and export
function onPresetSelected(app)
    % CONTROLLER: Show the selected preset's description and action label
    preset = app.presets(app.PresetDropDown.Value);
    showPresetDetails(app, preset);

    % === SUB-CONTROLLER ===

    function showPresetDetails(app, preset)
        % VIEW: Update description text and button label (TERMINAL)
        app.PresetDescription.Text = sprintf('%s\n\nReproduces: %s', ...
            preset.description, preset.figure);
        if strcmp(preset.kind, 'trajectory')
            app.PresetActionButton.Text = 'Load into builder';
        else
            app.PresetActionButton.Text = 'Run grid preset';
        end
    end
end
function onPresetAction(app)
    % CONTROLLER: Load a trajectory preset into the builder, or run a grid preset
    preset = app.presets(app.PresetDropDown.Value);
    if strcmp(preset.kind, 'trajectory')
        applyTrajectoryPreset(app, preset);
    else
        runGridPreset(app, preset);
    end
end
function applyTrajectoryPreset(app, preset)
    % CONTROLLER: Replace the builder tree with a preset tree

    applyPresetUniversals(app, preset.universal);
    app.spec = buildSpecFromPreset(app, preset);
    app.currentPresetId = preset.id;
    app.selected_node_id = app.spec.tree.root_ids(1);
    app.selected_port = 0;
    recomputeAllRounds(app);
    refreshTrajectory(app);
    selectNode(app, app.selected_node_id, 0);
    updateButtonStates(app);

    % === SUB-CONTROLLERS ===

    function applyPresetUniversals(app, universal)
        % SUB-CONTROLLER: Set colonies, rounds, and detection limit
        setUniversalSpinners(app, universal);

        function setUniversalSpinners(app, universal)
            % VIEW: Write universal values into the spinners (TERMINAL)
            app.NColoniesSpinner.Value = universal.n_colonies;
            app.VRoundsSpinner.Value = universal.v;
            app.DetectionLimitSpinner.Value = universal.detection_limit;
        end
    end

    function spec = buildSpecFromPreset(app, preset)
        % SUB-CONTROLLER: Convert the preset trunk and branch into tree nodes
        %
        % Trunk segments chain from round 1. A branch node attaches to the
        % last trunk segment, so it sits at the round after the trunk ends.
        % Each branch output carries its own segment chain.

        nodes = createSegmentChain(app, preset.trunk, 1, 0, 0);
        nextId = length(nodes) + 1;

        if ~isempty(preset.branch)
            branchNode = createBranchNode(app, nextId, nodes(end).id, preset.branch);
            nodes = linkLastNodeToChild(nodes, branchNode.id);
            nodes = appendNode(app, nodes, branchNode);
            nextId = nextId + 1;

            for k = 1:length(preset.branch.outputs)
                chain = createSegmentChain(app, preset.branch.outputs{k}.segments, ...
                    nextId, branchNode.id, k);
                nodes = linkBranchOutput(nodes, branchNode.id, k, chain(1).id);
                nodes = [nodes, chain]; %#ok<AGROW>
                nextId = nextId + length(chain);
            end
        end

        spec = packPresetSpec(nodes, nextId);

        function node = createBranchNode(app, id, parentId, branch)
            % SUB-CONTROLLER: Create and fill one branch node
            node = makeEmptyNode(app, id, 'branch');
            node = fillBranchNode(node, parentId, branch);

            function node = fillBranchNode(node, parentId, branch)
                % MODEL: Set parent, mode, and outputs (TERMINAL)
                node.parent_id = parentId;
                node.mode = branch.mode;
                labels = cell(1, length(branch.outputs));
                probs = cell(1, length(branch.outputs));
                for k = 1:length(branch.outputs)
                    labels{k} = branch.outputs{k}.label;
                    probs{k} = branch.outputs{k}.probability;
                end
                node.outputs = struct('label', labels, 'probability', probs, ...
                    'child_id', 0);
            end
        end

        function nodes = linkLastNodeToChild(nodes, childId)
            % MODEL: Point the last trunk segment at its child (TERMINAL)
            nodes(end).child_id = childId;
        end

        function nodes = linkBranchOutput(nodes, branchId, outputIndex, childId)
            % MODEL: Point a branch output at the first node of its chain (TERMINAL)
            for i = 1:length(nodes)
                if nodes(i).id == branchId
                    nodes(i).outputs(outputIndex).child_id = childId;
                    return;
                end
            end
        end

        function spec = packPresetSpec(nodes, nextId)
            % MODEL: Assemble the spec structure (TERMINAL)
            spec = struct();
            spec.tree = struct();
            spec.tree.root_ids = nodes(1).id;
            spec.tree.next_id = nextId;
            spec.tree.arrested_pool = struct( ...
                'enabled', true, ...
                'y_position', -0.05);
            spec.nodes = nodes;
        end
    end
end
function nodes = createSegmentChain(app, segments, firstId, parentId, portIndex)
    % SUB-CONTROLLER: Build a linked chain of flat/ramp nodes from preset segments
    %
    % The first node attaches to parentId (0 for the root, a branch id
    % for a branch output). Each later node attaches to the one before it.

    nodes = [];
    nSeg = numel(segments);
    for k = 1:nSeg
        id = firstId + k - 1;
        node = makeEmptyNode(app, id, segments{k}.type);
        node = fillSegmentNode(node, segments{k}, parentId, portIndex, k, nSeg);
        nodes = appendNode(app, nodes, node);
    end

    % === SUB-CONTROLLER ===

    function node = fillSegmentNode(node, seg, parentId, portIndex, k, nSeg)
        % MODEL: Copy segment values and chain links into the node (TERMINAL)
        switch seg.type
            case 'flat'
                node.phi = seg.phi;
            case 'ramp'
                node.phi_start = seg.phi_start;
                node.phi_end = seg.phi_end;
                node.linked = false;
        end
        node.epsilon = seg.epsilon;
        node.duration = seg.duration;

        if k == 1
            node.parent_id = parentId;
            node.port_index = portIndex;
        else
            node.parent_id = node.id - 1;
            node.port_index = 0;
        end

        if k < nSeg
            node.child_id = node.id + 1;
        end
    end
end
function nodes = appendNode(~, nodes, node)
    % MODEL: Append a node to a node array (TERMINAL)
    if isempty(nodes)
        nodes = node;
    else
        nodes(end + 1) = node;
    end
end
function runGridPreset(app, preset)
    % CONTROLLER: Run a grid preset, record it, and open the results viewer

    results = executeGridPreset(app, preset);
    recordRun(app, results, preset.id, []);
    buildResultsViewer(results);
    runPostProcess(preset, results);

    % === SUB-CONTROLLERS ===

    function results = executeGridPreset(app, preset)
        % SUB-CONTROLLER: Run the scenario behind a progress dialog
        dlg = startRunFeedback(app, preset.title);
        closer = onCleanup(@() delete(dlg)); %#ok<NASGU>
        results = runPresetScenario(preset, app.library, app.SeedSpinner.Value);
    end

    function runPostProcess(preset, results)
        % SUB-CONTROLLER: Call the preset's follow-up figure function, if any
        if ~isempty(preset.postProcess)
            feval(preset.postProcess, results);
        end
    end
end
function dlg = startRunFeedback(app, titleText)
    % SUB-CONTROLLER: Show an indeterminate progress dialog during a run
    dlg = openRunDialog(app, titleText);

    % === VIEW ===

    function dlg = openRunDialog(app, titleText)
        % VIEW: Create the progress dialog (TERMINAL)
        dlg = uiprogressdlg(app.UIFigure, ...
            'Title', 'Running model', ...
            'Message', sprintf('%s\n\nProgress prints in the MATLAB Command Window.', titleText), ...
            'Indeterminate', 'on');
    end
end
function recordRun(app, results, runName, spec)
    % CONTROLLER: Keep the latest run for export and enable the Export button

    storeRunState(app, results, runName, spec);
    refreshExportButton(app);

    % === SUB-CONTROLLERS ===

    function storeRunState(app, results, runName, spec)
        % SUB-CONTROLLER: Save run data on the app
        writeRunState(app, results, runName, spec);

        function writeRunState(app, results, runName, spec)
            % MODEL: Store results, name, and spec (TERMINAL)
            app.lastResults = results;
            app.lastRunName = runName;
            app.lastSpec = spec;
        end
    end

    function refreshExportButton(app)
        % SUB-CONTROLLER: Enable export once a run exists
        enableExportButton(app);

        function enableExportButton(app)
            % VIEW: Turn the Export button on (TERMINAL)
            app.ExportButton.Enable = 'on';
        end
    end
end
function exportLastResults(app)
    % CONTROLLER: Save the latest run's results, PDF, and spec to a folder

    if isempty(app.lastResults)
        return;
    end

    target = requestExportTarget(app);
    if isempty(target)
        return;
    end

    exportRunOutputs(app.lastResults, target.folder, target.name, app.lastSpec);
    confirmExport(app, target);

    % === SUB-CONTROLLERS ===

    function target = requestExportTarget(app)
        % SUB-CONTROLLER: Ask for a folder and a run name
        defaultFolder = resolveDefaultFolder(app);
        target = askForTarget(app, defaultFolder);

        function defaultFolder = resolveDefaultFolder(app)
            % SUB-CONTROLLER: Make sure outputs/ exists and return it
            defaultFolder = ensureOutputsFolder(app);

            function folder = ensureOutputsFolder(app)
                % MODEL: Create <package>/outputs when missing (TERMINAL)
                folder = fullfile(app.rootFolder, 'outputs');
                if ~isfolder(folder)
                    mkdir(folder);
                end
            end
        end

        function target = askForTarget(app, defaultFolder)
            % SUB-CONTROLLER: Folder and name dialogs
            target = showExportDialogs(app, defaultFolder);

            function target = showExportDialogs(app, defaultFolder)
                % VIEW: uigetdir, then a name prompt (TERMINAL)
                target = [];
                folder = uigetdir(defaultFolder, 'Choose an export folder');
                figure(app.UIFigure);
                if isequal(folder, 0)
                    return;
                end
                defaultName = sprintf('%s_%s', app.lastRunName, ...
                    char(datetime('now', 'Format', 'yyyyMMdd_HHmmss')));
                answer = inputdlg('Run name (used as the file prefix):', ...
                    'Export run', [1 60], {defaultName});
                figure(app.UIFigure);
                if isempty(answer) || isempty(strtrim(answer{1}))
                    return;
                end
                target = struct('folder', folder, ...
                    'name', matlab.lang.makeValidName(strtrim(answer{1})));
            end
        end
    end

    function confirmExport(app, target)
        % SUB-CONTROLLER: Tell the user where the files went
        showExportConfirmation(app, target);

        function showExportConfirmation(app, target)
            % VIEW: Confirmation alert (TERMINAL)
            uialert(app.UIFigure, ...
                sprintf('Saved %s_results.mat and %s_results.pdf to\n%s', ...
                target.name, target.name, target.folder), ...
                'Export complete', 'Icon', 'success');
        end
    end
end

    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            % Resolve every path from the folder that holds this file
            app.rootFolder = fileparts(which('ColonyModelApp'));
            addpath(fullfile(app.rootFolder, 'engine'), ...
                fullfile(app.rootFolder, 'presets'));
            app.library = loadStablePhiLibrary( ...
                fullfile(app.rootFolder, 'library', 'stable_phi_library_V40.mat'));
            app.presets = presetCatalog();
            createCustomComponents(app)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = ColonyModelApp

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end