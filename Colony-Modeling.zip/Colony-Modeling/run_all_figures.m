% run_all_figures: run every grid preset without the app
%
% Runs each grid preset in presets/presetCatalog.m and writes, per
% preset, <id>_results.mat and <id>_results.pdf to outputs/figures.
% BranchingProbe3 also writes BranchingProbe3_heatmap.pdf.
%
% To run a subset, list preset ids in presetIds, e.g.
%   presetIds = {'LibraryDiagnostic', 'BranchModeVariation'};
% Leave it empty to run every grid preset.

presetIds = {};
seed = 1;

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'engine'), fullfile(root, 'presets'));
library = loadStablePhiLibrary(fullfile(root, 'library', 'stable_phi_library_V40.mat'));
outputFolder = fullfile(root, 'outputs', 'figures');

presets = presetCatalog();
isGrid = strcmp({presets.kind}, 'grid');
if ~isempty(presetIds)
    isGrid = isGrid & ismember({presets.id}, presetIds);
end
selected = presets(isGrid);

warningState = warning('off', 'all');
for k = 1:numel(selected)
    preset = selected(k);
    fprintf('\n[%d/%d] %s (%s)\n', k, numel(selected), preset.id, preset.figure);
    results = runPresetScenario(preset, library, seed);
    exportRunOutputs(results, outputFolder, preset.id);
    if ~isempty(preset.postProcess)
        feval(preset.postProcess, results);
        exportgraphics(gcf, fullfile(outputFolder, [preset.id '_heatmap.pdf']), ...
            'ContentType', 'vector');
    end
end
warning(warningState);
