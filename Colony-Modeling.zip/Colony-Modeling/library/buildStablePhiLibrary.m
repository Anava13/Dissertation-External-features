function buildStablePhiLibrary()
    % CONTROLLER: Build and save the stable-phi library for mixture modeling.
    %
    % Simulates a grid of (phi, epsilon) stable-phi colony sets using the
    % same branching-process primitives as the main simulation script,
    % normalizes radii to the theoretical ceiling, computes KDEs with
    % Freedman-Diaconis bandwidth, extracts descriptors, and saves the
    % result to outputs/library in the package folder.
    %
    % Output file: outputs/library/stable_phi_library_V40.mat
    % The shipped copy in library/ is the one every preset uses. Point
    % the app or run_all_figures at a rebuilt copy to use it instead.
    %
    % USAGE:
    %   buildStablePhiLibrary()

    % === COORDINATE SUB-CONTROLLERS ===

    config = defineLibraryConfig();
    library = generateLibraryGrid(config);
    saveLibraryToFile(library, config);

    % === SUB-CONTROLLERS ===
    function config = defineLibraryConfig()
    % MODEL: Define all library generation parameters (TERMINAL)
    config = struct();

    % Grid
    config.phi_values = 0.60:0.02:0.95;
    config.eps_values = 0:0.02:0.20;

    % Simulation parameters (match existing stable_phi scenarios)
    config.n_colonies = 10000;
    config.v = 40;   % V40: matches the shipped library and every Supplemental 1 scenario
    config.detection_limit = 50;
    config.packing_density = 0.0113;
    config.approx_threshold = 500;
    config.min_kappa = 2;

    % KDE output grid
    config.n_x_points = 500;

    % Minimum detected colonies required for a valid KDE
    config.min_detected = 10;

    % Null distribution generation
    % For each library entry, simulate n_null_sets independent colony sets
    % of size n_per_null_set, compute the EMD of each against the entry's
    % reference KDE, and store the resulting null distribution. This lets
    % the runtime test ask "is the real data's EMD against this entry
    % consistent with what truly stable-phi data produces at this size?"
    config.n_per_null_set = 500;   % size of each null colony set
    config.n_null_sets = 500;      % number of null sets per library entry
end
  function library = generateLibraryGrid(config)
        % SUB-CONTROLLER: Iterate over the (phi, eps) grid, build each entry

        library = initializeLibraryShell(config);
        library = populateLibraryEntries(library, config);

        function library = initializeLibraryShell(config)
    % MODEL: Build empty library shell with shared x-grid (TERMINAL)
    library = struct();
    library.x_grid = linspace(0, 1, config.n_x_points);
    library.ceiling_radius = cellsToRadius(2^config.v, config.packing_density);
    library.config = config;

    n_entries = length(config.phi_values) * length(config.eps_values);
    library.entries = repmat(emptyEntry(), 1, n_entries);

    function entry = emptyEntry()
        entry = struct();
        entry.phi = NaN;
        entry.epsilon = NaN;
        entry.kde_y = [];
        entry.peak_x = NaN;
        entry.peak_height = NaN;
        entry.width = NaN;
        entry.skew = NaN;
        entry.n_simulated = NaN;
        entry.n_detected = NaN;
        entry.valid = false;

        % Null distribution of EMD values from independent stable-phi sims
        % at the same (phi, eps), each simulating n_per_null_set colonies
        % and computing EMD against this entry's KDE in micrometers.
        entry.null_emd_values = [];
        entry.null_p05 = NaN;
        entry.null_p25 = NaN;
        entry.null_p50 = NaN;
        entry.null_p75 = NaN;
        entry.null_p95 = NaN;
        entry.null_p99 = NaN;
    end
end
        function library = populateLibraryEntries(library, config)
            % SUB-CONTROLLER: Loop over the grid and fill each entry

            printLibraryBanner(config);

            entry_idx = 0;
            total = length(config.phi_values) * length(config.eps_values);

            for p_idx = 1:length(config.phi_values)
                for e_idx = 1:length(config.eps_values)
                    entry_idx = entry_idx + 1;

                    phi = config.phi_values(p_idx);
                    eps = config.eps_values(e_idx);

                    entry = simulateLibraryEntry(phi, eps, ...
                        library.x_grid, library.ceiling_radius, config);

                    library.entries(entry_idx) = entry;

                    printEntryStatus(entry_idx, total, entry);
                end
            end

            function printLibraryBanner(config)
                % MODEL: Print startup banner (TERMINAL)
                fprintf('\n=================================================================\n');
                fprintf('  BUILDING STABLE-PHI LIBRARY\n');
                fprintf('  phi: %.2f to %.2f (%d values)\n', ...
                    config.phi_values(1), config.phi_values(end), ...
                    length(config.phi_values));
                fprintf('  eps: %.2f to %.2f (%d values)\n', ...
                    config.eps_values(1), config.eps_values(end), ...
                    length(config.eps_values));
                fprintf('  Total entries: %d\n', ...
                    length(config.phi_values) * length(config.eps_values));
                fprintf('  Colonies per entry: %d\n', config.n_colonies);
                fprintf('  v: %d, detection limit: %d\n', ...
                    config.v, config.detection_limit);
                fprintf('=================================================================\n');
            end

            function printEntryStatus(entry_idx, total, entry)
                % MODEL: Print per-entry status line (TERMINAL)
                if entry.valid
                    flag = 'OK';
                else
                    flag = 'INVALID';
                end
                fprintf('  [%3d/%3d] phi=%.2f eps=%.2f  n_det=%4d  %s\n', ...
                    entry_idx, total, entry.phi, entry.epsilon, ...
                    entry.n_detected, flag);
            end

            function entry = simulateLibraryEntry(phi, eps, x_grid, ceiling_radius, config)
                % SUB-CONTROLLER: Simulate one (phi, eps) entry, build its KDE + descriptors

                simData = runSingleEntrySimulation(phi, eps, config);
                entry = buildEntryFromSimulation(phi, eps, simData, ...
                    x_grid, ceiling_radius, config);

                function simData = runSingleEntrySimulation(phi, eps, config)
                    % MODEL: Build cellConfig and run simulate_stable_phi (TERMINAL)
                    cellConfig = struct();
                    cellConfig.universal = struct( ...
                        'n_colonies', config.n_colonies, ...
                        'v', config.v, ...
                        'detection_limit', config.detection_limit, ...
                        'packing_density', config.packing_density, ...
                        'approx_threshold', config.approx_threshold, ...
                        'min_kappa', config.min_kappa);
                    cellConfig.sim_model = 'stable_phi';
                    cellConfig.sim_params = struct('phi', phi, 'epsilon', eps);

                    simData = simulate_stable_phi(cellConfig);
                end

                function entry = buildEntryFromSimulation(phi, eps, simData, x_grid, ceiling_radius, config)
    % SUB-CONTROLLER: Normalize, compute KDE, descriptors, generate null
    % distribution, and pack entry

    normalized = normalizeRadii(simData.radii, ceiling_radius);

    entry = struct();
    entry.phi = phi;
    entry.epsilon = eps;
    entry.n_simulated = config.n_colonies;
    entry.n_detected = length(normalized);

    if entry.n_detected < config.min_detected
        entry = markEntryInvalid(entry, x_grid);
        return;
    end

    kde_y = computeNormalizedKDE(normalized, x_grid);
    descriptors = computeDescriptors(normalized, x_grid, kde_y);
    nullDist = generateNullDistribution(phi, eps, kde_y, x_grid, ceiling_radius, config);

    entry.kde_y = kde_y;
    entry.peak_x = descriptors.peak_x;
    entry.peak_height = descriptors.peak_height;
    entry.width = descriptors.width;
    entry.skew = descriptors.skew;
    entry.null_emd_values = nullDist.emd_values;
    entry.null_p05 = nullDist.p05;
    entry.null_p25 = nullDist.p25;
    entry.null_p50 = nullDist.p50;
    entry.null_p75 = nullDist.p75;
    entry.null_p95 = nullDist.p95;
    entry.null_p99 = nullDist.p99;
    entry.valid = true;

    function normalized = normalizeRadii(radii, ceiling_radius)
        % MODEL: Normalize radii to [0,1] by theoretical ceiling (TERMINAL)
        normalized = radii(:) / ceiling_radius;
    end

    function entry = markEntryInvalid(entry, x_grid)
        % MODEL: Fill invalid entry fields with zero KDE and NaN descriptors (TERMINAL)
        entry.kde_y = zeros(1, length(x_grid));
        entry.peak_x = NaN;
        entry.peak_height = NaN;
        entry.width = NaN;
        entry.skew = NaN;
        entry.null_emd_values = [];
        entry.null_p05 = NaN;
        entry.null_p25 = NaN;
        entry.null_p50 = NaN;
        entry.null_p75 = NaN;
        entry.null_p95 = NaN;
        entry.null_p99 = NaN;
        entry.valid = false;
    end

    function kde_y = computeNormalizedKDE(normalized, x_grid)
        % MODEL: Compute KDE with Freedman-Diaconis bandwidth (TERMINAL)
        n = length(normalized);
        iqr_val = iqr(normalized);

        if iqr_val > 0
            fd_bw = 2 * iqr_val / n^(1/3);
        else
            fd_bw = std(normalized) / n^(1/3);
        end

        fd_bw = max(fd_bw, 1e-6);

        kde_y = ksdensity(normalized, x_grid, 'Bandwidth', fd_bw);
    end

    function descriptors = computeDescriptors(normalized, x_grid, kde_y)
        % MODEL: Compute peak, width, skew descriptors (TERMINAL)
        descriptors = struct();

        [peak_height, peak_idx] = max(kde_y);
        descriptors.peak_x = x_grid(peak_idx);
        descriptors.peak_height = peak_height;
        descriptors.width = std(normalized);
        descriptors.skew = skewness(normalized);
    end

    function nullDist = generateNullDistribution(phi, eps, kde_y, x_grid, ceiling_radius, config)
        % SUB-CONTROLLER: Run independent sims at (phi, eps), compute EMD vs KDE for each

        model_cdf = buildModelCDF(kde_y, x_grid);
        emd_values = runNullEMDLoop(phi, eps, model_cdf, x_grid, ceiling_radius, config);
        nullDist = packNullDistribution(emd_values);

        function model_cdf = buildModelCDF(kde_y, x_grid)
            % MODEL: Build cumulative model CDF from KDE on x_grid (TERMINAL)
            model_cdf = cumtrapz(x_grid, kde_y);
            if model_cdf(end) > 0
                model_cdf = model_cdf / model_cdf(end);
            end
        end

        function emd_values = runNullEMDLoop(phi, eps, model_cdf, x_grid, ceiling_radius, config)
            % SUB-CONTROLLER: Iterate over independent sims, compute EMD per set

            n_sets = config.n_null_sets;
            emd_values = nan(1, n_sets);

            for i = 1:n_sets
                simData = simulateOneNullSet(phi, eps, config);
                emd_values(i) = computeOneNullEMD(simData.radii, model_cdf, x_grid, ceiling_radius);
            end

            function simData = simulateOneNullSet(phi, eps, config)
                % MODEL: Build cellConfig and run simulate_stable_phi (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = struct( ...
                    'n_colonies', config.n_per_null_set, ...
                    'v', config.v, ...
                    'detection_limit', config.detection_limit, ...
                    'packing_density', config.packing_density, ...
                    'approx_threshold', config.approx_threshold, ...
                    'min_kappa', config.min_kappa);
                cellConfig.sim_model = 'stable_phi';
                cellConfig.sim_params = struct('phi', phi, 'epsilon', eps);

                simData = simulate_stable_phi(cellConfig);
            end

            function emd_um = computeOneNullEMD(radii, model_cdf, x_grid, ceiling_radius)
                % MODEL: Compute 1D EMD between empirical sample and model CDF (TERMINAL)
                if isempty(radii)
                    emd_um = NaN;
                    return;
                end

                normalized = radii(:) / ceiling_radius;
                normalized = min(max(normalized, 0), 1);

                emp_cdf = sum(normalized <= x_grid, 1) / length(normalized);

                emd_normalized = trapz(x_grid, abs(emp_cdf - model_cdf(:)'));
                emd_um = emd_normalized * ceiling_radius;
            end
        end

        function nullDist = packNullDistribution(emd_values)
            % MODEL: Pack EMD vector with key percentiles (TERMINAL)
            valid = emd_values(~isnan(emd_values));

            nullDist = struct();
            nullDist.emd_values = emd_values;

            if isempty(valid)
                nullDist.p05 = NaN;
                nullDist.p25 = NaN;
                nullDist.p50 = NaN;
                nullDist.p75 = NaN;
                nullDist.p95 = NaN;
                nullDist.p99 = NaN;
            else
                nullDist.p05 = prctile(valid, 5);
                nullDist.p25 = prctile(valid, 25);
                nullDist.p50 = prctile(valid, 50);
                nullDist.p75 = prctile(valid, 75);
                nullDist.p95 = prctile(valid, 95);
                nullDist.p99 = prctile(valid, 99);
            end
        end
    end
end
            end
        end
    end
    function saveLibraryToFile(library, config)
    % MODEL: Save library struct to .mat file in outputs/library
    % with a rounds-tagged filename. Rounds tag is derived from config.v
    % so the filename can never drift from the actual round count of
    % the simulation (e.g., config.v = 80 -> stable_phi_library_V80.mat).
    % (TERMINAL)
    rounds = sprintf('V%d', config.v);
    output_dir = fullfile(fileparts(fileparts(mfilename('fullpath'))), 'outputs', 'library');
    if ~isfolder(output_dir)
        mkdir(output_dir);
    end
    filename = fullfile(output_dir, sprintf('stable_phi_library_%s.mat', rounds));
    save(filename, 'library', '-v7.3');

    n_valid = sum([library.entries.valid]);
    n_total = length(library.entries);

    fprintf('-----------------------------------------------------------------\n');
    fprintf('  Library saved to: %s\n', filename);
    fprintf('  Valid entries: %d / %d\n', n_valid, n_total);
    fprintf('  Ceiling radius: %.1f um\n', library.ceiling_radius);
    fprintf('=================================================================\n\n');
end
end


% ======================================================================
%   DUPLICATED PRIMITIVES FROM MAIN SIMULATION SCRIPT
%   Copied verbatim so this library builder is standalone. If the
%   primitives change in the main script, update them here too.
% ======================================================================


function simData = simulate_stable_phi(cellConfig)
    % CONTROLLER: Simulate a colony set under stable phi with symmetric beta epsilon
    % Returns simData.radii (post-detection) and simData.tracking (empty struct).

    rawData = simulateAllStablePhiColonies(cellConfig);
    simData = applyDetectionStablePhi(rawData, cellConfig.universal);

    function rawData = simulateAllStablePhiColonies(cellConfig)
        % SUB-CONTROLLER: Loop over all colonies and store raw radii

        universal = cellConfig.universal;
        sim_params = cellConfig.sim_params;
        n = universal.n_colonies;

        radii = zeros(n, 1);
        for c = 1:n
            radii(c) = simulateOneStablePhiColony(sim_params, universal);
        end

        rawData = struct('radii', radii);

        function radius = simulateOneStablePhiColony(sim_params, universal)
            % MODEL: Single colony, single pool, constant phi (TERMINAL)
            S = 1;
            A = 0;

            for r = 1:universal.v
                if S == 0
                    break;
                end

                p_eff = drawEffectiveP(sim_params.phi, sim_params.epsilon, universal.min_kappa);
                [succ, fail] = divideOnce(S, p_eff, universal.approx_threshold);

                S = 2 * succ;
                A = A + fail;
            end

            radius = cellsToRadius(S + A, universal.packing_density);
        end
    end

    function simData = applyDetectionStablePhi(rawData, universal)
        % SUB-CONTROLLER: Apply detection limit, package simData with empty tracking

        mask = rawData.radii >= universal.detection_limit;
        simData = packageStablePhiSimData(rawData, mask);

        function simData = packageStablePhiSimData(rawData, mask)
            % MODEL: Pack into simData struct (TERMINAL)
            simData = struct();
            simData.radii = rawData.radii(mask);
            simData.tracking = struct();
        end
    end
end


function [successes, failures] = divideOnce(S, p_eff, approx_threshold)
    % MODEL: Single round of branching division for S cells (TERMINAL)
    % Uses binomial draws for small S, normal approximation for large S.

    if S <= 0
        successes = 0;
        failures = 0;
        return;
    end

    if S > approx_threshold
        mu_s = S * p_eff;
        var_s = S * p_eff * (1 - p_eff);
        successes = max(0, min(S, round(normrnd(mu_s, sqrt(var_s)))));
    else
        successes = binornd(S, p_eff);
    end

    failures = S - successes;
end


function p_eff = drawEffectiveP(p, eps_spread, min_kappa)
    % MODEL: Draw effective p from a beta distribution centered on p (TERMINAL)
    % Falls back to deterministic p when eps_spread is zero or invalid.

    if eps_spread <= 0 || p <= 0 || p >= 1
        p_eff = p;
        return;
    end

    max_spread = sqrt(p * (1 - p));
    if eps_spread >= max_spread
        p_eff = p;
        return;
    end

    kappa = p * (1 - p) / (eps_spread^2) - 1;
    if kappa < min_kappa
        p_eff = p;
        return;
    end

    a = p * kappa;
    b = (1 - p) * kappa;
    p_eff = betarnd(a, b);
end


function radius = cellsToRadius(n_cells, packing_density)
    % MODEL: Convert total cell count to colony radius via hemisphere geometry (TERMINAL)

    if n_cells <= 0
        radius = 0;
        return;
    end

    radius = ((3 * n_cells) / (2 * pi * packing_density))^(1/3);
end