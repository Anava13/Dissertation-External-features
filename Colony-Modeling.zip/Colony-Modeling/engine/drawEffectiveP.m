function p_eff = drawEffectiveP(p, eps_spread, min_kappa)
    % MODEL: Draw effective p from beta distribution centered on p (TERMINAL)
    if eps_spread <= 0 || p <= 0 || p >= 1
        p_eff = p;
        return;
    end
    max_spread = sqrt(p * (1 - p));
    if eps_spread >= max_spread
        p_eff = p;
        return;
    end
    kappa = p * (1 - p) / (eps_spread^2) - 1;
    if kappa < min_kappa
        p_eff = p;
        return;
    end
    a = p * kappa;
    b = (1 - p) * kappa;
    p_eff = betarnd(a, b);
end
