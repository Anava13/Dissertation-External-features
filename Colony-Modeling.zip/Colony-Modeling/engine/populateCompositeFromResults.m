function Part3CompleteData = populateCompositeFromResults(results, OutputFiles, outputName)
    % CONTROLLER: Populate composite struct from analysis results, save to disk
    %
    % Replacement for runVisualization when running a CompositeData
    % scenario. Walks each composite entry, extracts every available
    % output from the matching results cell, and writes it back into
    % the entry. Bundles the populated composite with run metadata
    % into a single wrapping struct named Part3CompleteData and saves.
    %
    % Output structure:
    %   Part3CompleteData.composite : 1xN populated entries
    %   Part3CompleteData.run_meta  : analysis options, library config,
    %                                 timestamp, field schema
    %
    % Saved to [OutputFiles, '/', outputName, '_dataset.mat'] under the
    % variable Part3CompleteData.
    %
    % External dependencies: computeLogKDE (base-level shared function).

    validateScenarioCarriesComposite(results);
    composite = results.scenario.composite_source;
    composite = populateAllEntries(composite, results);
    run_meta = buildRunMeta(results);
    Part3CompleteData = struct('composite', composite, 'run_meta', run_meta);
    saveDatasetToFile(Part3CompleteData, OutputFiles, outputName);
    printPopulationSummary(composite);

    function validateScenarioCarriesComposite(results)
        % MODEL: Hard-error if scenario lacks composite_source (TERMINAL)
        if ~isfield(results, 'scenario') || ...
                ~isfield(results.scenario, 'composite_source')
            error('populateCompositeFromResults:MissingCompositeSource', ...
                ['results.scenario.composite_source not found. ' ...
                 'This function requires a scenario built by ' ...
                 'buildCompositeDataScenario.']);
        end
    end

    function composite = populateAllEntries(composite, results)
        % SUB-CONTROLLER: Pre-allocate new fields, walk every entry
        composite = ensureNewFieldsExist(composite);
        n = length(composite);
        for i = 1:n
            composite(i) = populateOneEntry(composite(i), results, i);
        end

        function composite = ensureNewFieldsExist(composite)
    % MODEL: Pre-add new substruct fields to all entries (TERMINAL)
    new_struct_fields = {'library_fit', 'fit_comparison', ...
                         'kde', 'mode_detection', 'summary_stats', ...
                         'full_colony_set'};
    for fi = 1:length(new_struct_fields)
        field = new_struct_fields{fi};
        if ~isfield(composite, field)
            [composite.(field)] = deal(struct());
        end
    end
    scalar_fields = {'phi', 'epsilon', 'q'};
    for fi = 1:length(scalar_fields)
        field = scalar_fields{fi};
        if ~isfield(composite, field)
            [composite.(field)] = deal(NaN);
        end
    end
    if ~isfield(composite, 'colony_count')
        [composite.colony_count] = deal(0);
    end
    if ~isfield(composite, 'modes')
        [composite.modes] = deal(repmat(struct(), 1, 0));
    end
end
        function entry = populateOneEntry(entry, results, idx)
    % SUB-CONTROLLER: Populate one composite entry
    colonySet = lookupColonySet(results, idx);
    entry = writeTopLineSummary(entry, colonySet);
    entry.modes = buildModesArray(colonySet);
    entry.library_fit = buildLibraryFit(colonySet);
    entry.fit_comparison = buildFitComparison(colonySet);
    entry.kde = buildKDE(entry);
    entry.mode_detection = buildModeDetection(colonySet);
    entry.summary_stats = buildSummaryStats(entry);
    entry.full_colony_set = buildFullColonySet(colonySet);

    function colonySet = lookupColonySet(results, idx)
        % MODEL: Retrieve colonySet for one composite index (TERMINAL)
        nom_field = sprintf('entry_%03d', idx);
        colonySet = results.analysisResults ...
            .SubpopulationAnalysis(1).(nom_field).ColonySet;
    end

    function entry = writeTopLineSummary(entry, colonySet)
        % MODEL: Write top-line phi/epsilon/q/colony_count (TERMINAL)
        entry.phi = NaN;
        entry.epsilon = NaN;
        entry.q = NaN;
        if isfield(colonySet, 'gmm_results') && ...
                isfield(colonySet.gmm_results, 'fitted_model')
            fm = colonySet.gmm_results.fitted_model;
            if isfield(fm, 'library_blobs') && ~isempty(fm.library_blobs)
                blobs = fm.library_blobs;
                if isfield(blobs, 'centroids_phi') && ~isempty(blobs.centroids_phi) && ...
                        isfield(blobs, 'centroids_eps') && ~isempty(blobs.centroids_eps)
                    if isfield(blobs, 'total_weights') && ~isempty(blobs.total_weights)
                        [~, dom] = max(blobs.total_weights);
                    else
                        dom = 1;
                    end
                    if dom <= length(blobs.centroids_phi) && dom <= length(blobs.centroids_eps)
                        entry.phi = blobs.centroids_phi(dom);
                        entry.epsilon = blobs.centroids_eps(dom);
                    end
                end
            end
            if isfield(fm, 'library_quality_shape')
                entry.q = fm.library_quality_shape;
            end
        end
        if isfield(entry, 'Measurements') && ...
                isstruct(entry.Measurements) && ...
                isfield(entry.Measurements, 'Radius')
            entry.colony_count = length(entry.Measurements.Radius);
        else
            entry.colony_count = 0;
        end
    end

    function modes = buildModesArray(colonySet)
        % MODEL: Build per-component modes struct array (TERMINAL)
        template = struct( ...
            'barcode', '', 'weight', NaN, ...
            'mu', NaN, 'sigma', NaN, ...
            'best_distribution', '', 'delta_aic', NaN, ...
            'next_best_distribution', '', ...
            'normal_fit', struct(), 'lognormal_fit', struct(), ...
            'fitted_params', struct(), 'stats', struct());

        k = 0;
        if isfield(colonySet, 'subpopulation_count')
            k = colonySet.subpopulation_count;
        end
        if k <= 0
            modes = repmat(template, 1, 0);
            return;
        end
        modes = repmat(template, 1, k);

        has_components = isfield(colonySet, 'gmm_results') && ...
            isfield(colonySet.gmm_results, 'components');
        has_fitted_arrays = has_components && ...
            isfield(colonySet.gmm_results, 'fitted_model') && ...
            isfield(colonySet.gmm_results.fitted_model, 'gmm_mu');
        has_subpops = isfield(colonySet, 'subpopulations');

        radii = [];
        assignments = [];
        if isfield(colonySet, 'raw_measurements')
            radii = colonySet.raw_measurements;
        end
        if has_components && ...
                isfield(colonySet.gmm_results, 'component_assignments') && ...
                isfield(colonySet.gmm_results.component_assignments, 'hard_assignments')
            assignments = colonySet.gmm_results.component_assignments.hard_assignments;
        end

        for c = 1:k
            if has_components && length(colonySet.gmm_results.components) >= c
                comp = colonySet.gmm_results.components(c);
                if isfield(comp, 'barcode')
                    modes(c).barcode = char(comp.barcode);
                end
                if isfield(comp, 'weight')
                    modes(c).weight = comp.weight;
                end
            end
            if has_fitted_arrays
                fm = colonySet.gmm_results.fitted_model;
                if length(fm.gmm_mu) >= c
                    modes(c).mu = fm.gmm_mu(c);
                end
                if isfield(fm, 'gmm_sigma') && length(fm.gmm_sigma) >= c
                    modes(c).sigma = fm.gmm_sigma(c);
                end
            end
            if has_subpops && length(colonySet.subpopulations) >= c
                sp = colonySet.subpopulations(c);
                if isfield(sp, 'best_distribution')
                    modes(c).best_distribution = char(sp.best_distribution);
                end
                if isfield(sp, 'delta_aic')
                    modes(c).delta_aic = sp.delta_aic;
                end
                if isfield(sp, 'next_best_distribution')
                    modes(c).next_best_distribution = char(sp.next_best_distribution);
                end
                if isfield(sp, 'fitted_params')
                    modes(c).fitted_params = sp.fitted_params;
                end
                if isfield(sp, 'distribution_tests')
                    if isfield(sp.distribution_tests, 'normal')
                        modes(c).normal_fit = sp.distribution_tests.normal;
                    end
                    if isfield(sp.distribution_tests, 'lognormal')
                        modes(c).lognormal_fit = sp.distribution_tests.lognormal;
                    end
                end
            end
            if ~isempty(assignments) && length(assignments) == length(radii)
                mask = (assignments == c);
                comp_radii = radii(mask);
                modes(c).stats = computeDescriptiveStats(comp_radii);
            else
                modes(c).stats = computeDescriptiveStats([]);
            end
        end
    end

    function lib = buildLibraryFit(colonySet)
        % MODEL: Build library_fit substruct (TERMINAL)
        lib = struct( ...
            'adequacy_emd', NaN, 'adequacy_cutoff', NaN, ...
            'adequacy_passed', false, ...
            'quality_shape', NaN, 'quality_scale', NaN, ...
            'centroids_phi', [], 'centroids_eps', [], ...
            'blob_weights', [], 'n_blobs', 0);
        if ~isfield(colonySet, 'gmm_results'), return; end
        if ~isfield(colonySet.gmm_results, 'fitted_model'), return; end
        fm = colonySet.gmm_results.fitted_model;
        if isfield(fm, 'library_adequacy_emd')
            lib.adequacy_emd = fm.library_adequacy_emd;
        end
        if isfield(fm, 'library_adequacy_cutoff')
            lib.adequacy_cutoff = fm.library_adequacy_cutoff;
        end
        if isfield(fm, 'library_adequacy_passed')
            lib.adequacy_passed = fm.library_adequacy_passed;
        end
        if isfield(fm, 'library_quality_shape')
            lib.quality_shape = fm.library_quality_shape;
        end
        if isfield(fm, 'library_quality_scale')
            lib.quality_scale = fm.library_quality_scale;
        end
        if isfield(fm, 'library_blobs') && ~isempty(fm.library_blobs)
            blobs = fm.library_blobs;
            if isfield(blobs, 'centroids_phi')
                lib.centroids_phi = blobs.centroids_phi;
            end
            if isfield(blobs, 'centroids_eps')
                lib.centroids_eps = blobs.centroids_eps;
            end
            if isfield(blobs, 'total_weights')
                lib.blob_weights = blobs.total_weights;
            end
            lib.n_blobs = length(lib.centroids_phi);
        end
    end

    function comp = buildFitComparison(colonySet)
        % MODEL: Build fit_comparison substruct (TERMINAL)
        comp = struct( ...
            'winner', '', 'winner_aic', NaN, ...
            'alternative_aics', struct(), ...
            'dominant_barcode', '', 'total_weight_check', NaN);
        if isfield(colonySet, 'selected_method')
            comp.winner = char(colonySet.selected_method);
        end
        if isfield(colonySet, 'gmm_results') && ...
                isfield(colonySet.gmm_results, 'fitted_model') && ...
                isfield(colonySet.gmm_results.fitted_model, 'final_aic')
            comp.winner_aic = colonySet.gmm_results.fitted_model.final_aic;
        end
        if isfield(colonySet, 'alternative_fits') && ...
                isstruct(colonySet.alternative_fits)
            altNames = fieldnames(colonySet.alternative_fits);
            for ai = 1:length(altNames)
                alt = colonySet.alternative_fits.(altNames{ai});
                if isfield(alt, 'aic')
                    comp.alternative_aics.(altNames{ai}) = alt.aic;
                end
            end
        end
        if isfield(colonySet, 'dominant_subpopulation_barcode')
            comp.dominant_barcode = char(colonySet.dominant_subpopulation_barcode);
        end
        if isfield(colonySet, 'total_weight_check')
            comp.total_weight_check = colonySet.total_weight_check;
        end
    end

    function kde = buildKDE(entry)
        % MODEL: Compute and store KDE outputs via computeLogKDE (TERMINAL)
        kde = struct( ...
            'bandwidth', NaN, 'eval_x_log', [], 'density', [], ...
            'mean_r', NaN, 'std_r', NaN, 'cv', NaN);
        if ~isfield(entry, 'Measurements'), return; end
        if ~isstruct(entry.Measurements), return; end
        if ~isfield(entry.Measurements, 'Radius'), return; end
        radii = entry.Measurements.Radius(:);
        radii = radii(isfinite(radii) & radii > 0);
        if length(radii) < 2, return; end
        kdeData = computeLogKDE(radii);
        if isfield(kdeData, 'bandwidth'),  kde.bandwidth  = kdeData.bandwidth;  end
        if isfield(kdeData, 'eval_x_log'), kde.eval_x_log = kdeData.eval_x_log; end
        if isfield(kdeData, 'density'),    kde.density    = kdeData.density;    end
        if isfield(kdeData, 'mean_r'),     kde.mean_r     = kdeData.mean_r;     end
        if isfield(kdeData, 'std_r'),      kde.std_r      = kdeData.std_r;      end
        if isfield(kdeData, 'cv'),         kde.cv         = kdeData.cv;         end
    end

    function md = buildModeDetection(colonySet)
        % MODEL: Copy mode_detection if engine populated it (TERMINAL)
        md = struct( ...
            'n_modes', NaN, 'peak_locations', [], ...
            'bandwidth_used', NaN, 'space', '');
        if ~isfield(colonySet, 'mode_detection'), return; end
        src = colonySet.mode_detection;
        if ~isstruct(src), return; end
        if isfield(src, 'n_modes')
            md.n_modes = src.n_modes;
        end
        if isfield(src, 'peak_locations')
            md.peak_locations = src.peak_locations;
        end
        if isfield(src, 'bandwidth_used')
            md.bandwidth_used = src.bandwidth_used;
        end
        if isfield(src, 'space')
            md.space = char(src.space);
        end
    end

    function ss = buildSummaryStats(entry)
        % MODEL: Compute whole-set descriptive stats on radii (TERMINAL)
        ss = struct( ...
            'n', 0, 'mean', NaN, 'median', NaN, 'mode', NaN, ...
            'std', NaN, 'var', NaN, 'cv', NaN, 'sem', NaN, ...
            'skew', NaN, 'kurtosis', NaN, ...
            'min', NaN, 'max', NaN, 'range', NaN, 'iqr', NaN, ...
            'q1', NaN, 'q3', NaN, 'p05', NaN, 'p95', NaN, ...
            'geo_mean', NaN, 'geo_std', NaN, 'bimodality_coef', NaN);
        if ~isfield(entry, 'Measurements'), return; end
        if ~isstruct(entry.Measurements), return; end
        if ~isfield(entry.Measurements, 'Radius'), return; end
        r = entry.Measurements.Radius(:);
        r = r(isfinite(r));
        ss.n = length(r);
        if ss.n == 0, return; end
        ss.mean = mean(r);
        ss.median = median(r);
        ss.std = std(r);
        ss.var = var(r);
        if ss.mean ~= 0
            ss.cv = ss.std / ss.mean;
        end
        ss.sem = ss.std / sqrt(ss.n);
        ss.min = min(r);
        ss.max = max(r);
        ss.range = ss.max - ss.min;
        ss.iqr = iqr(r);
        ss.q1 = quantile(r, 0.25);
        ss.q3 = quantile(r, 0.75);
        ss.p05 = quantile(r, 0.05);
        ss.p95 = quantile(r, 0.95);
        if ss.n >= 3
            ss.skew = skewness(r);
            ss.kurtosis = kurtosis(r);
        end
        pos_r = r(r > 0);
        if ~isempty(pos_r)
            log_r = log(pos_r);
            ss.geo_mean = exp(mean(log_r));
            ss.geo_std = exp(std(log_r));
        end
        if length(pos_r) >= 2
            kdeData = computeLogKDE(pos_r);
            if isstruct(kdeData) && isfield(kdeData, 'density') && ...
                    ~isempty(kdeData.density) && ...
                    isfield(kdeData, 'eval_x_log') && ...
                    ~isempty(kdeData.eval_x_log)
                [~, peak_idx] = max(kdeData.density);
                ss.mode = exp(kdeData.eval_x_log(peak_idx));
            end
        end
        if ss.n >= 4 && isfinite(ss.skew) && isfinite(ss.kurtosis)
            g = ss.skew;
            kappa = ss.kurtosis;
            n = ss.n;
            correction = 3 * (n - 1)^2 / ((n - 2) * (n - 3));
            ss.bimodality_coef = (g^2 + 1) / (kappa + correction);
        end
    end

    function fullSet = buildFullColonySet(colonySet)
        % MODEL: Pass the full colonySet through to the composite entry
        % verbatim, with no field selection or filtering. Returns an
        % empty struct if colonySet is missing or not a struct, so
        % downstream code can rely on the field always existing. (TERMINAL)
        if ~isstruct(colonySet) || isempty(colonySet)
            fullSet = struct();
            return;
        end
        fullSet = colonySet;
    end

    function stats = computeDescriptiveStats(data)
        % MODEL: Per-component descriptive stats (TERMINAL)
        stats = struct( ...
            'n_assigned', 0, 'mean', NaN, 'median', NaN, ...
            'std', NaN, 'skew', NaN, 'kurtosis', NaN, ...
            'iqr', NaN, 'min', NaN, 'max', NaN, ...
            'q1', NaN, 'q3', NaN);
        d = data(:);
        d = d(isfinite(d));
        stats.n_assigned = length(d);
        if stats.n_assigned == 0, return; end
        stats.mean = mean(d);
        stats.median = median(d);
        stats.std = std(d);
        stats.min = min(d);
        stats.max = max(d);
        stats.iqr = iqr(d);
        stats.q1 = quantile(d, 0.25);
        stats.q3 = quantile(d, 0.75);
        if stats.n_assigned >= 3
            stats.skew = skewness(d);
            stats.kurtosis = kurtosis(d);
        end
    end
end
    end

    function meta = buildRunMeta(results)
        % SUB-CONTROLLER: Build run_meta struct
        meta = struct();
        meta.scenario_name = '';
        if isfield(results, 'scenario') && isfield(results.scenario, 'scenario_name')
            meta.scenario_name = char(results.scenario.scenario_name);
        end
        meta.timestamp = char(datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss'));
        meta.analysis_options = extractAnalysisOptions(results);
        meta.library_config = extractLibraryConfig(results);
        meta.field_schema = buildFieldSchema();

        function opts = extractAnalysisOptions(results)
            % MODEL: Pull analysis_options minus library reference (TERMINAL)
            opts = struct();
            if isfield(results, 'scenario') && ...
                    isfield(results.scenario, 'analysis_options')
                opts = results.scenario.analysis_options;
                if isfield(opts, 'library')
                    opts = rmfield(opts, 'library');
                end
            end
        end

        function cfg = extractLibraryConfig(results)
            % MODEL: Pull library.config from scenario (TERMINAL)
            cfg = struct();
            if isfield(results, 'scenario') && ...
                    isfield(results.scenario, 'analysis_options') && ...
                    isfield(results.scenario.analysis_options, 'library')
                lib = results.scenario.analysis_options.library;
                if isstruct(lib) && isfield(lib, 'config')
                    cfg = lib.config;
                end
            end
        end
        function schema = buildFieldSchema()
    % MODEL: Build field schema documentation (TERMINAL)
    schema = struct();
    schema.composite_fields = { ...
        'phi',              'Dominant library mode phi (per-round division success probability)'; ...
        'epsilon',          'Dominant library mode epsilon (untracked variation)'; ...
        'q',                'Library quality_shape score'; ...
        'colony_count',     'Number of input radii measurements'; ...
        'modes',            'Per-component struct array (mixture model output)'; ...
        'library_fit',      'Library blob fit detail and adequacy'; ...
        'fit_comparison',   'Method selection (Library/LMM/GMM) and AIC scores'; ...
        'kde',              'Log-space KDE outputs'; ...
        'mode_detection',   'KDE-based mode count (NaN if engine did not populate)'; ...
        'summary_stats',    'Descriptive statistics on raw radii'; ...
        'full_colony_set',  'Complete colonySet from analysis engine, passed through verbatim. Contains raw_measurements, gmm_results (winning method full output), subpopulations, alternative_fits (full output of every losing method including LogNormal mixture parameters), selected_method, and mode_detection. No filtering applied.'};
    schema.modes_fields = { ...
        'barcode',                'Component identifier string'; ...
        'weight',                 'GMM mixing weight'; ...
        'mu',                     'GMM component mean (in normalization space)'; ...
        'sigma',                  'GMM component standard deviation'; ...
        'best_distribution',      'Selected distribution: Normal, LogNormal, Library, NonParametric'; ...
        'delta_aic',              'AIC gap between best and next-best distribution fit'; ...
        'next_best_distribution', 'Runner-up distribution name'; ...
        'normal_fit',             'Full Normal distribution fit results'; ...
        'lognormal_fit',          'Full LogNormal distribution fit results'; ...
        'fitted_params',          'Parameters of winning distribution'; ...
        'stats',                  'Descriptive stats on hard-assigned radii'};
    schema.library_fit_fields = { ...
        'adequacy_emd',    'EMD distance to closest library entry'; ...
        'adequacy_cutoff', 'EMD threshold for adequacy pass'; ...
        'adequacy_passed', 'Logical: did library fit pass adequacy gate'; ...
        'quality_shape',   'Library shape quality score'; ...
        'quality_scale',   'Library scale quality score'; ...
        'centroids_phi',   'All blob phi centroids'; ...
        'centroids_eps',   'All blob epsilon centroids'; ...
        'blob_weights',    'Per-blob total weights'; ...
        'n_blobs',         'Number of library blobs'};
    schema.fit_comparison_fields = { ...
        'winner',             'Selected method: Library, LogNormal, or Gaussian'; ...
        'winner_aic',         'AIC of winning method'; ...
        'alternative_aics',   'Struct of losing-method AIC scores'; ...
        'dominant_barcode',   'Barcode of highest-weight component'; ...
        'total_weight_check', 'Sum of component weights (should be ~1)'};
    schema.kde_fields = { ...
        'bandwidth',  'Shrunk Silverman bandwidth used'; ...
        'eval_x_log', 'Evaluation grid in log-radius space'; ...
        'density',    'KDE density values on eval_x_log'; ...
        'mean_r',     'Arithmetic mean of radii'; ...
        'std_r',      'Standard deviation of radii'; ...
        'cv',         'Coefficient of variation (std/mean)'};
    schema.summary_stats_fields = { ...
        'n',               'Number of finite measurements'; ...
        'mean',            'Arithmetic mean'; ...
        'median',          'Median'; ...
        'mode',            'KDE peak location (in raw radius space)'; ...
        'std',             'Standard deviation'; ...
        'var',             'Variance'; ...
        'cv',              'Coefficient of variation'; ...
        'sem',             'Standard error of mean'; ...
        'skew',            'Skewness'; ...
        'kurtosis',        'Kurtosis'; ...
        'min',             'Minimum'; ...
        'max',             'Maximum'; ...
        'range',           'Max minus min'; ...
        'iqr',             'Interquartile range'; ...
        'q1',              '25th percentile'; ...
        'q3',              '75th percentile'; ...
        'p05',             '5th percentile'; ...
        'p95',             '95th percentile'; ...
        'geo_mean',        'Geometric mean'; ...
        'geo_std',         'Geometric standard deviation'; ...
        'bimodality_coef', 'Sarle bimodality coefficient (>0.555 suggests bimodal)'};
end
    
    end

    function saveDatasetToFile(Part3CompleteData, OutputFiles, outputName)
        % VIEW: Save Part3CompleteData to disk (TERMINAL)
        outPath = fullfile(OutputFiles, [outputName '_dataset.mat']);
        save(outPath, 'Part3CompleteData');
        fprintf('Part3CompleteData saved: %s\n', outPath);
    end

    function printPopulationSummary(composite)
        % VIEW: Print summary of populated entries (TERMINAL)
        n = length(composite);
        phi_vals = arrayfun(@(e) e.phi, composite);
        n_fit = sum(~isnan(phi_vals));
        fprintf('Populated %d/%d entries with library fits\n', n_fit, n);
    end
end
