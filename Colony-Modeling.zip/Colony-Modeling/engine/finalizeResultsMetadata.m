function results = finalizeResultsMetadata(results)
    % SUB-CONTROLLER: Stamp end time, print summary
    results = applyEndTime(results);
    printRunSummary(results);

    function results = applyEndTime(results)
        % MODEL: Compute elapsed time (TERMINAL)
        results.metadata.end_time = datetime('now');
        results.metadata.elapsed_seconds = ...
            seconds(results.metadata.end_time - results.metadata.start_time);
    end

    function printRunSummary(results)
        % MODEL: Print run summary (TERMINAL)
        fprintf('-----------------------------------------------------------------\n');
        fprintf('  Done. %d cells, %d total colonies, %.1f seconds\n', ...
            results.metadata.n_cells, ...
            results.metadata.n_colonies_total, ...
            results.metadata.elapsed_seconds);
        fprintf('=================================================================\n\n');
    end
end
