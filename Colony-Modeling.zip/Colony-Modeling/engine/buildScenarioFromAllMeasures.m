function scenario = buildScenarioFromAllMeasures(AllMeasures, analysis_options)
        % SUB-CONTROLLER: Construct scenario shell from real measurement data

        nominalInfo = computeNominalInfo(AllMeasures);
        n_ord = computeOrdinalCount(AllMeasures, nominalInfo.fields);
        ordinalLabels = buildOrdinalLabels(n_ord);
        config = buildStubConfigGrid(n_ord, nominalInfo.fields);
        scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, analysis_options);

        function info = computeNominalInfo(AllMeasures)
            % MODEL: Extract field names and display labels (TERMINAL)
            displayMap = struct( ...
                'Wild_Type',     'Wild Type', ...
                'dbf41',         'dbf4-1', ...
                'dbf41_cdc132',  'dbf4-1, cdc13-2', ...
                'cdc132',        'cdc13-2');
            allFields = fieldnames(AllMeasures);
            n = length(allFields);
            displayLabels = cell(1, n);
            for i = 1:n
                fname = allFields{i};
                if isfield(displayMap, fname)
                    displayLabels{i} = displayMap.(fname);
                else
                    displayLabels{i} = strrep(fname, '_', ' ');
                end
            end
            info = struct();
            info.fields = allFields(:)';
            info.labels = displayLabels;
        end

        function n_ord = computeOrdinalCount(AllMeasures, fields)
            % MODEL: Find max generation count across genotypes (TERMINAL)
            n_ord = 0;
            for i = 1:length(fields)
                n_ord = max(n_ord, length(AllMeasures.(fields{i})));
            end
        end

        function labels = buildOrdinalLabels(n_ord)
            % MODEL: Build ordinal label cell array (TERMINAL)
            labels = cell(1, n_ord);
            for i = 1:n_ord
                labels{i} = sprintf('Plating %d', i);
            end
        end

        function config = buildStubConfigGrid(n_ord, nominal_fields)
            % MODEL: Build per-cell stub configs for real data (TERMINAL)
            stubCell = struct();
            stubCell.pools = struct( ...
                'initial_S', {}, ...
                'p_traj', {}, ...
                'eps_traj', {}, ...
                'phase_boundaries', {}, ...
                'color', {}, ...
                'label', {});
            stubCell.branch_events = struct( ...
                'source_pool', {}, ...
                'target_pool', {}, ...
                'eligible_rounds', {});
            stubCell.universal = struct('v', 40);
            stubCell.log_params = struct();

            config = repmat(struct(), 1, n_ord);
            for ord = 1:n_ord
                for nom = 1:length(nominal_fields)
                    config(ord).(nominal_fields{nom}) = stubCell;
                end
            end
        end

        function scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, analysis_options)
            % MODEL: Pack the scenario struct (TERMINAL)
            scenario = struct();
            scenario.scenario_name = 'RealData';
            scenario.nominal_fields = nominalInfo.fields;
            scenario.nominal_labels = nominalInfo.labels;
            scenario.ordinal_labels = ordinalLabels;
            scenario.config = config;
            scenario.analysis_options = analysis_options;
        end
    end
