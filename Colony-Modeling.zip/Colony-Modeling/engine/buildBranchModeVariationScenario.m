function scenario = buildBranchModeVariationScenario(n_colonies, v)
    % CONTROLLER: 6-condition branch event comparison scenario

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies, v);

    % -------------------------------------------------------------

    function scenario = initializeShell()
        labels = struct();

        labels.nominal_display = {'BranchConditions'};
        labels.nominal_fields  = {'branch_conditions'};

        labels.ordinal_display = { ...
            'Control', ...
            'DecreasedGap', ...
            'SwapDirection', ...
            'HighProb', ...
            'LowProb', ...
            'PerCellMode' ...
        };

        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BranchVariationComparison');
    end

    % -------------------------------------------------------------

    function scenario = populateGrid(scenario, n_colonies, v)

        universal = makeUniversalConfig(n_colonies, v, 50);

        phi_base = 0.75;
        phi_branch = 0.85;
        event_round = 5;
        p_base = 0.4;

        for ord_idx = 1:6
            switch ord_idx

                case 1
                    scenario = addCell(scenario, ord_idx, phi_base, phi_branch, p_base, 'per_colony');

                case 2
                    scenario = addCell(scenario, ord_idx, phi_base, 0.80, p_base, 'per_colony');

                case 3
                    scenario = addCell(scenario, ord_idx, 0.85, 0.75, p_base, 'per_colony');

                case 4
                    scenario = addCell(scenario, ord_idx, phi_base, phi_branch, 0.6, 'per_colony');

                case 5
                    scenario = addCell(scenario, ord_idx, phi_base, phi_branch, 0.2, 'per_colony');

                case 6
                    scenario = addCell(scenario, ord_idx, phi_base, phi_branch, p_base, 'per_cell');
            end
        end

        % ---------------------------------------------------------

        function scenario = addCell(scenario, ord_idx, phi_b, phi_a, p_event, mode)

            params = struct();
            params.p_base = phi_b;
            params.p_post = phi_a;
            params.event_round = event_round;
            params.p_event = p_event;
            params.mode = mode;

            p_eff = computeEffectiveTrajectory(params, v);
            predictors = computeTrajectoryPredictors(p_eff);

            cellConfig = struct();
            cellConfig.universal = universal;

            base_pool = buildPool( ...
                params.p_base * ones(1, v), zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);

            branch_pool = buildPool( ...
                params.p_post * ones(1, v), zeros(1, v), ...
                'BranchLineage', [0.75, 0.55, 0.10], [], 0);

            cellConfig.pools = [base_pool, branch_pool];

            cellConfig.branch_events = buildBranchEvent( ...
                1, 'dividing', 2, params.mode, ...
                params.p_event, [params.event_round]);

            cellConfig.log_params = struct( ...
                'mode', params.mode, ...
                'p_base', params.p_base, ...
                'p_post', params.p_post, ...
                'event_round', params.event_round, ...
                'p_event', params.p_event, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);

            scenario = addCellConfig(scenario, ord_idx, 1, cellConfig);
        end

        % ---------------------------------------------------------

        function p_eff = computeEffectiveTrajectory(params, v)
            r = 1:v;
            p_eff = params.p_base * ones(1, v);

            mask = r >= params.event_round;

            p_eff(mask) = params.p_event * params.p_post + ...
                          (1 - params.p_event) * params.p_base;
        end
    end
end
