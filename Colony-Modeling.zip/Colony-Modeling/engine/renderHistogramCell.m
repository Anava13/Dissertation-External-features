function renderHistogramCell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render histogram for one cell
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);
    drawHistogram(ax, histData, state);

    function drawHistogram(ax, histData, state)
        % VIEW: Draw log-space histogram (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end
        bar(ax, histData.log_bin_centers, histData.bin_counts, 1, ...
            'FaceColor', [0.30, 0.45, 0.75], 'EdgeColor', [0.20, 0.30, 0.55], ...
            'FaceAlpha', 0.7);
        text(ax, 0.97, 0.95, sprintf('n=%d\n\\mu=%.0f \\mum\nCV=%.2f', ...
            histData.n, histData.mean_r, histData.cv), ...
            'Units', 'normalized', 'FontSize', 8, ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'BackgroundColor', [1, 1, 1, 0.85], 'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);
        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end
end
