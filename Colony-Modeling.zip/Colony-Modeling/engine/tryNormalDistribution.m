function result = tryNormalDistribution(data)
    % MODEL: Fit normal distribution (TERMINAL)
    result = struct('final_mean', NaN, 'final_sigma', NaN, ...
        'confidence_interval', [NaN, NaN], 'aic_score', Inf, 'bic_score', Inf, ...
        'ks_test_pvalue', NaN, 'log_likelihood', NaN);
    if length(data) < 3, return; end
    try
        mu_hat = mean(data); sigma_hat = std(data, 1);
        if sigma_hat <= 0, return; end
        n = length(data);
        se_mean = sigma_hat / sqrt(n);
        t_crit = tinv(1 - 0.025, n - 1);
        ci = [mu_hat - t_crit * se_mean, mu_hat + t_crit * se_mean];
        log_likelihood = sum(log(normpdf(data, mu_hat, sigma_hat)));
        k_params = 2;
        aic_score = 2 * k_params - 2 * log_likelihood;
        bic_score = k_params * log(n) - 2 * log_likelihood;
        [~, ks_pvalue] = kstest((data - mu_hat) / sigma_hat);
        result.final_mean = mu_hat; result.final_sigma = sigma_hat;
        result.confidence_interval = ci;
        result.aic_score = aic_score; result.bic_score = bic_score;
        result.ks_test_pvalue = ks_pvalue; result.log_likelihood = log_likelihood;
    catch
    end
end
