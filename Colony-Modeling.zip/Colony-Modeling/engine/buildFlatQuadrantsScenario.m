function scenario = buildFlatQuadrantsScenario(n_colonies, v)
    % CONTROLLER: Build the four flat phi x epsilon conditions of
    % fig:phi_epsilon_grid
    %
    % Grid shape: one ordinal row, four nominal columns.
    %   1. HighPhi_LowEps    phi = 0.75, eps = 0.02
    %   2. HighPhi_HighEps   phi = 0.75, eps = 0.15
    %   3. LowPhi_HighEps    phi = 0.65, eps = 0.15
    %   4. LowPhi_LowEps     phi = 0.65, eps = 0.02
    %
    % The detection limit is 100 um, matching the script that drew the
    % original figure (BranchingProcessQuadrantsForDissertation.m).
    %
    % USAGE:
    %   scenario = buildFlatQuadrantsScenario();
    %   scenario = buildFlatQuadrantsScenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies, v);

    % === SUB-CONTROLLERS ===

    function scenario = initializeShell()
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels();
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'FlatQuadrants');

        function labels = buildLabels()
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = { ...
                'HighPhi_LowEps', 'HighPhi_HighEps', ...
                'LowPhi_HighEps', 'LowPhi_LowEps'};
            labels.nominal_fields = { ...
                'high_phi_low_eps', 'high_phi_high_eps', ...
                'low_phi_high_eps', 'low_phi_low_eps'};
            labels.ordinal_display = {'flat'};
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v)
        % SUB-CONTROLLER: Fill the four cells
        universal = makeUniversalConfig(n_colonies, v, 100);
        conditions = defineConditions();

        for nom_idx = 1:size(conditions, 1)
            cellConfig = buildFlatCell(conditions(nom_idx, 1), ...
                conditions(nom_idx, 2), universal, v);
            scenario = addCellConfig(scenario, 1, nom_idx, cellConfig);
        end

        function conditions = defineConditions()
            % MODEL: [phi, eps] for each column (TERMINAL)
            conditions = [ ...
                0.75, 0.02; ...
                0.75, 0.15; ...
                0.65, 0.15; ...
                0.65, 0.02];
        end

        function cellConfig = buildFlatCell(phi, eps_val, universal, v)
            % SUB-CONTROLLER: One flat single-pool cell
            pool = buildPool(phi * ones(1, v), eps_val * ones(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig = packFlatCell(pool, universal, phi, eps_val);

            function cellConfig = packFlatCell(pool, universal, phi, eps_val)
                % MODEL: Package the cell config (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = pool;
                cellConfig.branch_events = [];
                cellConfig.log_params = struct('family', 'flat_quadrant', ...
                    'phi', phi, 'epsilon', eps_val);
            end
        end
    end
end
