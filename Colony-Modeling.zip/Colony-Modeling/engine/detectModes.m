function colonySet = detectModes(colonySet)
    % SUB-CONTROLLER: Detect modes in raw radius distribution via KDE peak finding.
    % Stores results in colonySet.mode_detection.

    % Constants
    MIN_DATA_POINTS = 10;
    PROMINENCE_FRACTION = 0.05;     % 5% of max density
    N_EVAL_POINTS = 200;

    data = colonySet.raw_measurements;

    if length(data) < MIN_DATA_POINTS
        colonySet.mode_detection = buildInsufficientDataResult(data);
        return;
    end

    density = computeDensitySurface(data, N_EVAL_POINTS);
    peaks = findDensityPeaks(density, PROMINENCE_FRACTION);
    colonySet.mode_detection = packModeResult(density, peaks, length(data));

    function modeData = buildInsufficientDataResult(data)
        % MODEL: Empty result for insufficient data (TERMINAL)
        modeData = struct();
        modeData.n_modes = 0;
        modeData.peak_locations = [];
        modeData.peak_heights = [];
        modeData.peak_prominences = [];
        modeData.bandwidth_used = NaN;
        modeData.prominence_threshold = NaN;
        modeData.density_x = [];
        modeData.density_y = [];
        modeData.n_colonies = length(data);
        modeData.sufficient = false;
    end

    function density = computeDensitySurface(data, nPoints)
        % MODEL: Run KDE in raw radius space using shared utility (TERMINAL)
        kdeOptions = struct();
        kdeOptions.useRawData = true;
        kdeOptions.evaluationPoints = linspace(0, max(data) * 1.1, nPoints);
        kdeOptions.minBandwidth = 25;   % matches existing pipeline default
        [f, xi, bandwidth] = calculateKDE(data, kdeOptions);
        density = struct();
        density.x = xi;
        density.y = f;
        density.bandwidth = bandwidth;
    end

    function [f, xi, bandwidth] = calculateKDE(data, options)
    % CALCULATEKDE Performs standardized KDE calculation
%   [f, xi, bandwidth] = calculateKDE(data, options)
%
%   Parameters:
%       data - Vector of data points for KDE estimation
%       options - Structure with optional parameters:
%           .evaluationPoints - Vector of points to evaluate KDE (default: auto)
%           .minBandwidth - Minimum bandwidth to use (default depends on data mode)
%           .useRawData - Boolean flag for raw data mode (default: false)
%
%   Returns:
%       f - Density values
%       xi - Evaluation points
%       bandwidth - Bandwidth used for calculation
% Default options
if nargin < 2 || isempty(options)
        options = struct();
end
% Handle empty or insufficient data
if isempty(data) || length(data) < 3
        f = [];
        xi = [];
        bandwidth = NaN;
return;
end
% Determine if using raw data mode (affects range and bandwidth defaults)
    useRawData = isfield(options, 'useRawData') && options.useRawData;
% Set evaluation range based on mode
if isfield(options, 'evaluationPoints')
        xi = options.evaluationPoints;
else
if useRawData
            xi = linspace(0, max(data) * 1.1, 100);
else
            xi = linspace(0, 2, 100);
end
end
% Calculate bandwidth using Freedman-Diaconis rule
    bandwidth = 2 * iqr(data) / nthroot(length(data), 3);
% Apply minimum bandwidth based on mode
if isfield(options, 'minBandwidth')
        minBandwidth = options.minBandwidth;
else
if useRawData
            minBandwidth = 25; % For raw data (colony sizes in µm)
else
            minBandwidth = 0.05; % For normalized data
end
end
    bandwidth = max(bandwidth, minBandwidth);
% Calculate KDE
    [f, xi] = ksdensity(data, xi, 'Bandwidth', bandwidth);
end

    function peaks = findDensityPeaks(density, promFraction)
        % MODEL: Find local maxima above prominence threshold (TERMINAL)
        peaks = struct();
        peaks.locations = [];
        peaks.heights = [];
        peaks.prominences = [];
        peaks.threshold = NaN;

        if isempty(density.y) || all(density.y == 0)
            return;
        end

        peaks.threshold = promFraction * max(density.y);

        [pks, locs, ~, prom] = findpeaks(density.y, density.x, ...
            'MinPeakProminence', peaks.threshold);

        peaks.locations = locs(:)';
        peaks.heights = pks(:)';
        peaks.prominences = prom(:)';
    end

    function modeData = packModeResult(density, peaks, n)
        % MODEL: Assemble mode_detection result struct (TERMINAL)
        modeData = struct();
        modeData.n_modes = length(peaks.locations);
        modeData.peak_locations = peaks.locations;
        modeData.peak_heights = peaks.heights;
        modeData.peak_prominences = peaks.prominences;
        modeData.bandwidth_used = density.bandwidth;
        modeData.prominence_threshold = peaks.threshold;
        modeData.density_x = density.x;
        modeData.density_y = density.y;
        modeData.n_colonies = n;
        modeData.sufficient = true;
    end
end
