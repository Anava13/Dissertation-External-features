function colonySet = lookupColonySet(renderState, ord_idx, nom_idx)
             % MODEL: Retrieve colonySet from results by grid indices (TERMINAL)
             nom_field = renderState.results.scenario.nominal_fields{nom_idx};
             colonySet = renderState.results.analysisResults ...
                 .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
         end
