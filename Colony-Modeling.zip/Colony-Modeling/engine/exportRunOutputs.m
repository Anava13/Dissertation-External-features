function exportRunOutputs(results, outputFolder, runName, spec)
    % CONTROLLER: Save one run's results, PDF, and (optionally) its
    % trajectory spec to outputFolder
    %
    % Writes:
    %   <runName>_results.mat   results struct (radii, KDEs, fits)
    %   <runName>_results.pdf   index, library fit table, and views
    %   <runName>_spec.mat      trajectory tree from the app (if given)
    %
    % USAGE:
    %   exportRunOutputs(results, folder, 'EarlyBranch_L14')
    %   exportRunOutputs(results, folder, 'MyHypothesis', spec)

    if nargin < 4
        spec = [];
    end

    ensureOutputFolder(outputFolder);
    saveRunFiles(results, spec, outputFolder, runName);
    exportResultsPDF(results, outputFolder, runName);

    % === SUB-CONTROLLERS ===

    function ensureOutputFolder(outputFolder)
        % SUB-CONTROLLER: Create the folder when missing
        createFolderIfMissing(outputFolder);

        function createFolderIfMissing(outputFolder)
            % MODEL: mkdir when the folder does not exist (TERMINAL)
            if ~isfolder(outputFolder)
                mkdir(outputFolder);
            end
        end
    end

    function saveRunFiles(results, spec, outputFolder, runName)
        % SUB-CONTROLLER: Write the .mat files
        writeResultsFile(results, outputFolder, runName);
        if ~isempty(spec)
            writeSpecFile(spec, outputFolder, runName);
        end

        function writeResultsFile(results, outputFolder, runName)
            % MODEL: Save results (TERMINAL)
            save(fullfile(outputFolder, [runName '_results.mat']), 'results', '-v7.3');
        end

        function writeSpecFile(spec, outputFolder, runName)
            % MODEL: Save the app trajectory tree (TERMINAL)
            save(fullfile(outputFolder, [runName '_spec.mat']), 'spec');
        end
    end
end
