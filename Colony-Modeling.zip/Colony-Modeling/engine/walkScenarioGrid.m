function results = walkScenarioGrid(scenario, results, dataProvider)
% SUB-CONTROLLER: Iterate over every cell in the grid, calling
% dataProvider(cellConfig, ord_idx, nom_idx) to obtain simData.

n_ord = length(scenario.ordinal_labels);
n_nom = length(scenario.nominal_labels);
printGridStartBanner(scenario, n_ord, n_nom);

for ord_idx = 1:n_ord
    for nom_idx = 1:n_nom
        results = processSingleGridCell(results, scenario, ord_idx, nom_idx, dataProvider);
    end
end

 function printGridStartBanner(scenario, n_ord, n_nom)
        % MODEL: Print run start banner (TERMINAL)
        fprintf('\n=================================================================\n');
        fprintf('  RUNNING SCENARIO: %s\n', scenario.scenario_name);
        fprintf('  Grid: %d ordinals x %d nominals = %d cells\n', ...
            n_ord, n_nom, n_ord * n_nom);
        fprintf('=================================================================\n');
    end

end
