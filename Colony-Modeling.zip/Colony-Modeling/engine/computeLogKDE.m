function kdeData = computeLogKDE(radii, imposed_edges)
    % MODEL: Compute log-space KDE with shrunk Silverman bandwidth (TERMINAL)
    if nargin < 2, imposed_edges = []; end
    kdeData = struct();
    kdeData.radii = radii;
    kdeData.n = length(radii);
    if kdeData.n < 2
        kdeData.empty = true;
        kdeData.mean_r = NaN; kdeData.std_r = NaN; kdeData.cv = NaN;
        kdeData.eval_x_log = []; kdeData.density = [];
        kdeData.bandwidth = NaN;
        return;
    end
    kdeData.empty = false;
    kdeData.mean_r = mean(radii);
    kdeData.std_r = std(radii);
    kdeData.cv = kdeData.std_r / kdeData.mean_r;
    log_radii = log(radii);

    % Shrunk Silverman robust bandwidth (0.5x for mode preservation)
    sigma_log = std(log_radii);
    iqr_log = iqr(log_radii);
    if iqr_log > 0
        spread = min(sigma_log, iqr_log / 1.34);
    else
        spread = sigma_log;
    end
    if spread <= 0
        spread = 0.1;
    end
    silverman_h = 0.9 * spread * kdeData.n^(-1/5);
    h = 0.9 * silverman_h;
    kdeData.bandwidth = h;

    % Evaluation grid
    if isempty(imposed_edges)
        x_min = min(log_radii) - 3*h;
        x_max = max(log_radii) + 3*h;
    else
        x_min = imposed_edges(1);
        x_max = imposed_edges(end);
    end
    n_eval = 300;
    eval_x_log = linspace(x_min, x_max, n_eval);

    % Compute density (Gaussian kernel)
    density = zeros(1, n_eval);
    norm_factor = 1 / (kdeData.n * h * sqrt(2*pi));
    for i = 1:kdeData.n
        density = density + exp(-0.5 * ((eval_x_log - log_radii(i)) / h).^2);
    end
    density = density * norm_factor;

    kdeData.eval_x_log = eval_x_log;
    kdeData.density = density;
end
