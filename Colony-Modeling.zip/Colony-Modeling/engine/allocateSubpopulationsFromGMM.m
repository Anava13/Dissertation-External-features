function colonySet = allocateSubpopulationsFromGMM(colonySet)
    % SUB-CONTROLLER: Build component records and subpopulation slots
    colonySet = initializeComponentSlots(colonySet);
    colonySet = populateComponentMetrics(colonySet);

    function colonySet = initializeComponentSlots(colonySet)
        % MODEL: Allocate empty components and subpopulations (TERMINAL)
        k = colonySet.gmm_results.optimal_components;
        components = repmat(struct(), 1, k);
        for i = 1:k
            components(i).barcode = "";
            components(i).initial_mean = NaN;
            components(i).initial_sigma = NaN;
            components(i).weight = NaN;
            components(i).data_indices = [];
        end
        colonySet.gmm_results.components = components;
        subpopulations = repmat(struct(), 1, k);
        for i = 1:k
            subpopulations(i).component_String = "";
            subpopulations(i).distribution_tests = struct();
            subpopulations(i).selection_criteria = struct();
            subpopulations(i).best_distribution = "";
        end
        colonySet.subpopulations = subpopulations;
    end

    function colonySet = populateComponentMetrics(colonySet)
        % MODEL: Fill components with GMM-derived stats (TERMINAL)
        k = colonySet.gmm_results.optimal_components;
        fm = colonySet.gmm_results.fitted_model;
        ha = colonySet.gmm_results.component_assignments.hard_assignments;
        actual_k = min([length(fm.GMM_mu), length(fm.GMM_sigma), length(fm.GMM_weights)]);
        if actual_k < k
            k = actual_k;
            colonySet.gmm_results.optimal_components = k;
        end
        for i = 1:k
            barcode = sprintf('Comp%d', i);
            mask = (ha == i);
            colonySet.gmm_results.components(i).barcode = barcode;
            colonySet.gmm_results.components(i).initial_mean = fm.GMM_mu(i);
            colonySet.gmm_results.components(i).initial_sigma = fm.GMM_sigma(i);
            colonySet.gmm_results.components(i).weight = fm.GMM_weights(i);
            colonySet.gmm_results.components(i).data_indices = find(mask);
            colonySet.subpopulations(i).component_String = barcode;
        end
    end
end
