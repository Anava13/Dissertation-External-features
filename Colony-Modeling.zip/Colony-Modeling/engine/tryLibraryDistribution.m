function result = tryLibraryDistribution(data, options)
    % CONTROLLER: Match component data against best library entry with adequacy test
    result = buildEmptyLibraryResult();
    [ok, reason] = validateLibraryFitInputs(data, options);
    if ~ok, result.failure_reason = reason; return; end

    logLiks = scoreAllLibraryEntries(data, options.library);
    bestInfo = pickBestLibraryEntry(logLiks, options.library);
    if ~bestInfo.success
        result.failure_reason = 'No valid library entry produced finite log-likelihood';
        return;
    end

    adequacy = runAdequacyTest(data, bestInfo, options.library);
    if ~adequacy.passed
        result = packLibraryAdequacyFailure(bestInfo, adequacy);
        return;
    end
    result = packLibrarySuccess(bestInfo, adequacy, length(data));

    function result = buildEmptyLibraryResult()
        % MODEL: Default failed library result (TERMINAL)
        result = struct('phi_parameter', NaN, 'eps_parameter', NaN, ...
            'phi_index', NaN, 'eps_index', NaN, 'entry_index', NaN, ...
            'aic_score', Inf, 'bic_score', Inf, 'ks_test_pvalue', NaN, ...
            'log_likelihood', NaN, 'fitting_successful', false, ...
            'failure_reason', '', 'adequacy_emd', NaN, ...
            'adequacy_cutoff', NaN, 'adequacy_passed', false);
    end

    function [ok, reason] = validateLibraryFitInputs(data, options)
        % MODEL: Check gates (TERMINAL)
        if length(data) < 10
            ok = false; reason = sprintf('Insufficient data: n=%d', length(data)); return;
        end
        if ~isfield(options, 'library') || isempty(options.library)
            ok = false; reason = 'Library not provided'; return;
        end
        lib = options.library;
        if ~isfield(lib, 'entries') || isempty(lib.entries)
            ok = false; reason = 'Library has no entries'; return;
        end
        if ~isfield(lib, 'x_grid') || isempty(lib.x_grid)
            ok = false; reason = 'Library missing x_grid'; return;
        end
        if ~isfield(lib, 'ceiling_radius') || lib.ceiling_radius <= 0
            ok = false; reason = 'Library missing valid ceiling_radius'; return;
        end
        if ~isfield(lib, 'config')
            ok = false; reason = 'Library missing config'; return;
        end
        ok = true; reason = '';
    end

    function logLiks = scoreAllLibraryEntries(data, library)
        % MODEL: Log-likelihood under each entry KDE (TERMINAL)
        n_entries = length(library.entries);
        logLiks = -inf(1, n_entries);
        x_grid = library.x_grid; ceiling = library.ceiling_radius;
        n = length(data);
        normalized = min(max(data(:) / ceiling, 0), 1);
        dx = x_grid(2) - x_grid(1);
        bin_indices = round((normalized - x_grid(1)) / dx) + 1;
        bin_indices = max(1, min(length(x_grid), bin_indices));
        log_ceiling = log(ceiling);
        for i = 1:n_entries
            if ~library.entries(i).valid, continue; end
            kde_y = library.entries(i).kde_y;
            densities = max(kde_y(bin_indices), 1e-300);
            logLiks(i) = sum(log(densities)) - n * log_ceiling;
        end
    end

    function bestInfo = pickBestLibraryEntry(logLiks, library)
        % MODEL: Find max log-lik entry (TERMINAL)
        [best_logL, best_idx] = max(logLiks);
        bestInfo = struct();
        bestInfo.success = isfinite(best_logL);
        bestInfo.log_likelihood = best_logL;
        bestInfo.entry_index = best_idx;
        n_eps = length(library.config.eps_values);
        p_idx = floor((best_idx - 1) / n_eps) + 1;
        e_idx = mod(best_idx - 1, n_eps) + 1;
        bestInfo.phi_parameter = library.config.phi_values(p_idx);
        bestInfo.eps_parameter = library.config.eps_values(e_idx);
        bestInfo.phi_index = p_idx;
        bestInfo.eps_index = e_idx;
    end

    function adequacy = runAdequacyTest(data, bestInfo, library)
        % MODEL: EMD between data and best entry (TERMINAL)
        adequacy = struct();
        adequacy.emd = NaN; adequacy.cutoff = NaN; adequacy.passed = false;
        entry = library.entries(bestInfo.entry_index);
        x_grid = library.x_grid; ceiling = library.ceiling_radius;
        model_cdf = cumtrapz(x_grid, entry.kde_y);
        if model_cdf(end) > 0, model_cdf = model_cdf / model_cdf(end); end
        normalized = min(max(data(:) / ceiling, 0), 1);
        emp_cdf = sum(normalized <= x_grid, 1) / length(normalized);
        emd_normalized = trapz(x_grid, abs(emp_cdf - model_cdf(:)'));
        adequacy.emd = emd_normalized * ceiling;
        adequacy.cutoff = entry.null_p95;
        if isnan(adequacy.cutoff), adequacy.passed = false;
        else, adequacy.passed = adequacy.emd <= adequacy.cutoff; end
    end

    function result = packLibrarySuccess(bestInfo, adequacy, n)
        % MODEL: Pack winning entry (TERMINAL)
        k_params = 2; log_lik = bestInfo.log_likelihood;
        result = struct('phi_parameter', bestInfo.phi_parameter, ...
            'eps_parameter', bestInfo.eps_parameter, ...
            'phi_index', bestInfo.phi_index, 'eps_index', bestInfo.eps_index, ...
            'entry_index', bestInfo.entry_index, ...
            'aic_score', 2 * k_params - 2 * log_lik, ...
            'bic_score', k_params * log(n) - 2 * log_lik, ...
            'ks_test_pvalue', NaN, 'log_likelihood', log_lik, ...
            'fitting_successful', true, 'failure_reason', '', ...
            'adequacy_emd', adequacy.emd, 'adequacy_cutoff', adequacy.cutoff, ...
            'adequacy_passed', true);
    end

    function result = packLibraryAdequacyFailure(bestInfo, adequacy)
        % MODEL: Pack adequacy-failed result (TERMINAL)
        result = struct('phi_parameter', bestInfo.phi_parameter, ...
            'eps_parameter', bestInfo.eps_parameter, ...
            'phi_index', bestInfo.phi_index, 'eps_index', bestInfo.eps_index, ...
            'entry_index', bestInfo.entry_index, ...
            'aic_score', Inf, 'bic_score', Inf, ...
            'ks_test_pvalue', NaN, 'log_likelihood', bestInfo.log_likelihood, ...
            'fitting_successful', false, ...
            'failure_reason', sprintf('EMD=%.1fum exceeds null p95=%.1fum at (phi=%.2f, eps=%.2f)', ...
                adequacy.emd, adequacy.cutoff, bestInfo.phi_parameter, bestInfo.eps_parameter), ...
            'adequacy_emd', adequacy.emd, 'adequacy_cutoff', adequacy.cutoff, ...
            'adequacy_passed', false);
    end
end
