function result = tryLogNormalDistribution(data)
    % MODEL: Fit lognormal distribution (TERMINAL)
    result = struct('mu_parameter', NaN, 'sigma_parameter', NaN, ...
        'fitted_median', NaN, 'aic_score', Inf, 'bic_score', Inf, ...
        'ks_test_pvalue', NaN, 'log_likelihood', NaN);
    pos_data = data(data > 1e-6);
    if length(pos_data) < 3, return; end
    try
        params = mle(pos_data, 'distribution', 'LogNormal');
        mu_param = params(1); sigma_param = params(2);
        log_likelihood = sum(log(lognpdf(pos_data, mu_param, sigma_param)));
        n = length(pos_data); k_params = 2;
        aic_score = 2 * k_params - 2 * log_likelihood;
        bic_score = k_params * log(n) - 2 * log_likelihood;
        result.mu_parameter = mu_param; result.sigma_parameter = sigma_param;
        result.fitted_median = exp(mu_param);
        result.aic_score = aic_score; result.bic_score = bic_score;
        result.log_likelihood = log_likelihood;
    catch
    end
end
