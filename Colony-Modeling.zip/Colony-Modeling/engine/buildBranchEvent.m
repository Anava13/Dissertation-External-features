function event = buildBranchEvent(source_pool, source_compartment, target_pool, mode, probability, eligible_rounds)
    % MODEL: Construct a branch event struct (TERMINAL)
    event = struct();
    event.source_pool = source_pool;
    event.source_compartment = source_compartment;
    event.target_pool = target_pool;
    event.mode = mode;
    event.probability = probability;
    event.eligible_rounds = eligible_rounds;
end
