function renderCompositionCell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render composition-stacked histogram from pool tracking
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    cellConfig = state.results.scenario.config(ord_idx).(nom_field);

    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);

    n_pools = length(cellConfig.pools);
    hasMultiplePools = n_pools > 1 && isfield(colonySet, 'tracking') && ...
        isfield(colonySet.tracking, 'pool_cells_final') && ...
        size(colonySet.tracking.pool_cells_final, 2) >= n_pools;

    if hasMultiplePools
        poolMeta = extractPoolMeta(cellConfig.pools);
        compData = computeMultiPoolBinComposition(histData, ...
            colonySet.tracking.pool_cells_final, poolMeta);
        drawCompositionHistogram(ax, histData, compData, state);
    else
        drawFallbackHistogram(ax, histData, state);
    end

    function poolMeta = extractPoolMeta(pools)
        % MODEL: Extract colors and labels from pool structs (TERMINAL)
        n = length(pools);
        poolMeta = struct();
        poolMeta.colors = zeros(n, 3);
        poolMeta.labels = cell(1, n);
        for i = 1:n
            poolMeta.colors(i, :) = pools(i).color;
            poolMeta.labels{i} = pools(i).label;
        end
    end

    function compData = computeMultiPoolBinComposition(histData, pool_cells_final, poolMeta)
        % MODEL: Compute per-bin per-pool fractions (TERMINAL)
        compData = struct();
        n_pools = size(pool_cells_final, 2);
        compData.pool_colors = poolMeta.colors;
        compData.pool_labels = poolMeta.labels;

        if histData.empty
            compData.bin_pool_fracs = [];
            return;
        end

        log_radii = log(histData.radii);
        edges = histData.log_bin_edges;
        n_bins = length(edges) - 1;
        bin_pool_fracs = zeros(n_bins, n_pools);
        colony_totals = sum(pool_cells_final, 2);

        for b = 1:n_bins
            if b < n_bins
                in_bin = log_radii >= edges(b) & log_radii < edges(b + 1);
            else
                in_bin = log_radii >= edges(b) & log_radii <= edges(b + 1);
            end
            if any(in_bin)
                totals = colony_totals(in_bin);
                totals(totals == 0) = 1;
                for p = 1:n_pools
                    bin_pool_fracs(b, p) = mean(pool_cells_final(in_bin, p) ./ totals);
                end
            end
        end
        compData.bin_pool_fracs = bin_pool_fracs;
    end

    function drawCompositionHistogram(ax, histData, compData, state)
        % VIEW: Draw stacked histogram with pool coloring (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end

        bc = histData.log_bin_centers;
        counts = histData.bin_counts;
        bw = histData.log_bin_width;
        n_pools = size(compData.bin_pool_fracs, 2);

        for b = 1:length(bc)
            if counts(b) == 0, continue; end
            y_base = 0;
            for p = 1:n_pools
                height = counts(b) * compData.bin_pool_fracs(b, p);
                if height > 0.01
                    rectangle(ax, 'Position', [bc(b) - bw/2, y_base, bw, height], ...
                        'FaceColor', compData.pool_colors(p, :), ...
                        'EdgeColor', compData.pool_colors(p, :) * 0.7, ...
                        'LineWidth', 0.5);
                end
                y_base = y_base + height;
            end
        end

        % Legend
        legend_handles = gobjects(n_pools, 1);
        for p = 1:n_pools
            legend_handles(p) = patch(ax, NaN, NaN, compData.pool_colors(p, :), ...
                'EdgeColor', compData.pool_colors(p, :) * 0.7);
        end
        legend(ax, legend_handles, compData.pool_labels, ...
            'Location', 'northeast', 'FontSize', 8, 'Box', 'off');

        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end

    function drawFallbackHistogram(ax, histData, state)
        % VIEW: Plain histogram when single pool (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end
        bar(ax, histData.log_bin_centers, histData.bin_counts, 1, ...
            'FaceColor', [0.30, 0.45, 0.75], 'EdgeColor', [0.20, 0.30, 0.55], ...
            'FaceAlpha', 0.7);
        text(ax, 0.97, 0.95, sprintf('n=%d\n\\mu=%.0f \\mum\nCV=%.2f\n(single pool)', ...
            histData.n, histData.mean_r, histData.cv), ...
            'Units', 'normalized', 'FontSize', 8, ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'BackgroundColor', [1, 1, 1, 0.85], 'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);
        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end
end
