function predictors = computeTrajectoryPredictors(p_traj)
    % MODEL: Compute input-side deviation predictors for one trajectory (TERMINAL)
    phi_avg = mean(p_traj);
    deviations = p_traj - phi_avg;

    predictors = struct();
    predictors.phi_avg = phi_avg;
    predictors.flat_L2 = sqrt(mean(deviations .^ 2));

    v_local = length(p_traj);
    log_weights = (0:v_local - 1) * log(max(2 * phi_avg, eps));
    log_weights = log_weights - max(log_weights);
    weights = exp(log_weights);
    weights = weights / sum(weights);
    predictors.weighted_L2 = sqrt(sum(weights .* (deviations .^ 2)));
end
