function label = sanitizeDisplayLabel(label)
    % MODEL: Replace underscores for display (TERMINAL)
    %   Gene allele underscores become hyphens (case-insensitive,
    %   preserving original casing); all others become spaces.

    gene_patterns = {'est1_1','est2_1','est3_1','est4_1', ...
                     'tlc1_Δ','dbf4_1','cdc13_2','rif1_Δ'};

    for i = 1:length(gene_patterns)
        parts = strsplit(gene_patterns{i}, '_');
        regex = ['(' parts{1} ')_(' parts{2} ')'];
        label = regexprep(label, regex, '$1-$2', 'ignorecase');
    end

    label = strrep(label, '_', ' ');
end
