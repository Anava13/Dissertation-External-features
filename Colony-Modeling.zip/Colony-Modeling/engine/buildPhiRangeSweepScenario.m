function scenario = buildPhiRangeSweepScenario(n_colonies, v)
    % CONTROLLER: Build the PhiRangeSweep validation scenario
    %
    % Tests whether the geometric mean prediction for effective phi
    % holds across the full biologically relevant range of phi values
    % (0.60 to 0.95). Non-stationarity severity is held constant;
    % phi_baseline varies on the ordinal axis.
    %
    % 6 nominal columns (3 families x original/matched-flat pairs):
    %   1. LinearDecline          2. LinDecline_Flat
    %   3. StepDecline            4. StepDecline_Flat
    %   5. Bottleneck             6. Bottleneck_Flat
    %
    % 8 ordinal levels: phi_baseline = 0.60, 0.65, 0.70, ..., 0.95
    %
    % Fixed severity:
    %   LinearDecline: delta = 0.05 (ramps from phi+0.05 to phi-0.05)
    %   StepDecline:   delta = 0.05 (steps from phi+0.05 to phi-0.05)
    %   Bottleneck:    drop of 0.30 during rounds 16-20 (clamped at 0.01)
    %
    % USAGE:
    %   scenario = buildPhiRangeSweepScenario();
    %   scenario = buildPhiRangeSweepScenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    phi_values = 0.60:0.05:0.95;
    n_levels = length(phi_values);

    scenario = initializeShell(phi_values);
    scenario = populateGrid(scenario, n_colonies, v, phi_values);

    function scenario = initializeShell(phi_values)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(phi_values);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'PhiRangeSweep');

        function labels = buildLabels(phi_values)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = { ...
                'LinearDecline', 'LinDecline_Flat', ...
                'StepDecline',   'StepDecline_Flat', ...
                'Bottleneck',    'Bottleneck_Flat'};
            labels.nominal_fields = { ...
                'linear_decline', 'linear_decline_flat', ...
                'step_decline',   'step_decline_flat', ...
                'bottleneck',     'bottleneck_flat'};
            labels.ordinal_display = cell(1, length(phi_values));
            for i = 1:length(phi_values)
                labels.ordinal_display{i} = sprintf('phi_%.2f', phi_values(i));
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, phi_values)
        % SUB-CONTROLLER: Fill every cell
        universal = makeUniversalConfig(n_colonies, v, 50);
        delta = 0.05;
        bottleneck_drop = 0.30;

        for i = 1:length(phi_values)
            phi_base = phi_values(i);

            % LinearDecline pair
            [origCell, phi_geo] = buildLinearDeclineCell(phi_base, delta, v, universal);
            scenario = addCellConfig(scenario, i, 1, origCell);
            scenario = addCellConfig(scenario, i, 2, ...
                buildMatchedFlatCell(phi_geo, phi_base, v, universal, 'linear_decline_flat'));

            % StepDecline pair
            [origCell, phi_geo] = buildStepDeclineCell(phi_base, delta, v, universal);
            scenario = addCellConfig(scenario, i, 3, origCell);
            scenario = addCellConfig(scenario, i, 4, ...
                buildMatchedFlatCell(phi_geo, phi_base, v, universal, 'step_decline_flat'));

            % Bottleneck pair
            [origCell, phi_geo] = buildBottleneckCell(phi_base, bottleneck_drop, v, universal);
            scenario = addCellConfig(scenario, i, 5, origCell);
            scenario = addCellConfig(scenario, i, 6, ...
                buildMatchedFlatCell(phi_geo, phi_base, v, universal, 'bottleneck_flat'));
        end

        %% ---- MATCHED FLAT BUILDER ----

        function cellConfig = buildMatchedFlatCell(phi_geo, phi_base, v, universal, family_label)
            % SUB-CONTROLLER: Flat trajectory at phi_geo, eps = 0
            p_traj = phi_geo * ones(1, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packFlatCell(p_traj, universal, family_label, ...
                phi_base, phi_geo, predictors, v);

            function cellConfig = packFlatCell(p_traj, universal, family_label, ...
                    phi_base, phi_geo, predictors, v)
                % MODEL: Build matched flat cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    p_traj, zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'family', family_label, ...
                    'phi_baseline', phi_base, ...
                    'phi_geo', phi_geo, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        %% ---- FAMILY BUILDERS ----

        function [cellConfig, phi_geo] = buildLinearDeclineCell(phi_base, delta, v, universal)
            % SUB-CONTROLLER: Linear decline centered on phi_base
            p_traj = computeLinearDeclineTrajectory(phi_base, delta, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalCell(p_traj, universal, 'linear_decline', ...
                phi_base, phi_geo, predictors, v);

            function p_traj = computeLinearDeclineTrajectory(phi_base, delta, v)
                % MODEL: Linear ramp, clamped to [0.01, 0.99] (TERMINAL)
                r = 1:v;
                p_traj = (phi_base + delta) - 2 * delta * (r - 1) / (v - 1);
                p_traj = max(min(p_traj, 0.99), 0.01);
            end
        end

        function [cellConfig, phi_geo] = buildStepDeclineCell(phi_base, delta, v, universal)
            % SUB-CONTROLLER: Step function centered on phi_base
            p_traj = computeStepDeclineTrajectory(phi_base, delta, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalCell(p_traj, universal, 'step_decline', ...
                phi_base, phi_geo, predictors, v);

            function p_traj = computeStepDeclineTrajectory(phi_base, delta, v)
                % MODEL: Step at midpoint, clamped to [0.01, 0.99] (TERMINAL)
                half = floor(v / 2);
                high = min(phi_base + delta, 0.99);
                low  = max(phi_base - delta, 0.01);
                p_traj = [high * ones(1, half), low * ones(1, v - half)];
            end
        end

        function [cellConfig, phi_geo] = buildBottleneckCell(phi_base, drop, v, universal)
            % SUB-CONTROLLER: Transient low-phi window with recovery
            p_traj = computeBottleneckTrajectory(phi_base, drop, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalCell(p_traj, universal, 'bottleneck', ...
                phi_base, phi_geo, predictors, v);

            function p_traj = computeBottleneckTrajectory(phi_base, drop, v)
                % MODEL: Phi drops during rounds 16-20 then recovers (TERMINAL)
                p_traj = phi_base * ones(1, v);
                bottleneck_phi = max(phi_base - drop, 0.01);
                p_traj(16:20) = bottleneck_phi;
            end
        end

        %% ---- SHARED HELPERS ----

        function phi_geo = computeGeometricMean(p_traj)
            % MODEL: Geometric mean of per-round phi values (TERMINAL)
            phi_geo = exp(mean(log(p_traj)));
        end

        function cellConfig = packOriginalCell(p_traj, universal, family_label, ...
                phi_base, phi_geo, predictors, v)
            % MODEL: Build original non-flat cell (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;
            cellConfig.pools = buildPool( ...
                p_traj, zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig.branch_events = [];
            cellConfig.log_params = struct( ...
                'family', family_label, ...
                'phi_baseline', phi_base, ...
                'phi_geo', phi_geo, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end
    end
end
