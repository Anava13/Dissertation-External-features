function colonySet = processAllSubpopulations(colonySet, options)
    % SUB-CONTROLLER: Run distribution tests on each component
    k = colonySet.gmm_results.optimal_components;
    for c = 1:k
        colonySet = processSingleSubpopulation(colonySet, c, options);
    end

    function colonySet = processSingleSubpopulation(colonySet, c, options)
        % SUB-CONTROLLER: Pull data, fit, store
        compData = extractSubpopulationData(colonySet, c);
        analysis = determineBestDistributionAndFit(compData, options);
        colonySet = stowSubpopulationAnalysis(colonySet, c, analysis);

        function compData = extractSubpopulationData(colonySet, c)
            % MODEL: Pull component measurements (TERMINAL)
            indices = colonySet.gmm_results.components(c).data_indices;
            compData = colonySet.raw_measurements(indices);
        end

        function colonySet = stowSubpopulationAnalysis(colonySet, c, analysis)
            % MODEL: Store analysis results (TERMINAL)
            colonySet.subpopulations(c).distribution_tests = analysis.distribution_tests;
            colonySet.subpopulations(c).selection_criteria = analysis.selection_criteria;
            colonySet.subpopulations(c).best_distribution = analysis.best_distribution;
        end
    end
end
