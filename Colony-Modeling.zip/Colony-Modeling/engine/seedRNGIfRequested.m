function seedRNGIfRequested(scenario)
        % SUB-CONTROLLER: Apply RNG seed if specified
        seed = scenario.analysis_options.rng_seed;
        applySeed(seed);

        function applySeed(seed)
            % MODEL: Seed the RNG if non-empty (TERMINAL)
            if ~isempty(seed)
                rng(seed);
            end
        end
    end
