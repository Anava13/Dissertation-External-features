function options = defaultAnalysisOptions()
    % MODEL: Build default analysis options (TERMINAL)
    options = struct();
    options.max_components = 5;
    options.mixture_distribution = "LogNormal";
    options.normalization = 'Raw';
    options.connection_threshold = 0.5;
    options.connection_cost_bias = 0.5;
    options.rng_seed = [];
end
