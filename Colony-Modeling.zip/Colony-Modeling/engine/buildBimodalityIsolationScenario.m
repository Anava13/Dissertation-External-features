function scenario = buildBimodalityIsolationScenario(n_colonies, v)
    % CONTROLLER: Build the bimodality isolation scenario
    %
    % Seven conditions on the nominal axis testing whether branching
    % uniquely produces multimodality:
    %   1. BranchUp      — Branch 0.75 -> 0.80 at round 4, p_event=0.40 (reference)
    %   2. BranchDown    — Branch 0.75 -> 0.70 at round 4, p_event=0.40
    %   3. StepUp        — All colonies step 0.75 -> 0.80 at round 4
    %   4. StepDown      — All colonies step 0.75 -> 0.70 at round 4
    %   5. DelayBranch   — Branch 0.75 -> 0.80 at round 8, p_event=0.40
    %   6. LowProb       — Branch 0.75 -> 0.80 at round 4, p_event=0.20
    %   7. HighProb      — Branch 0.75 -> 0.80 at round 4, p_event=0.60
    %
    % Single ordinal row. All conditions use eps=0.
    %
    % USAGE:
    %   scenario = buildBimodalityIsolationScenario();
    %   scenario = buildBimodalityIsolationScenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies, v);

    function scenario = initializeShell()
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels();
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BimodalityIsolation');

        function labels = buildLabels()
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = { ...
                'BranchUp', 'BranchDown', 'StepUp', 'StepDown', ...
                'DelayBranch', 'LowProb', 'HighProb'};
            labels.nominal_fields = { ...
                'branch_up', 'branch_down', 'step_up', 'step_down', ...
                'delay_branch', 'low_prob', 'high_prob'};
            labels.ordinal_display = {''};
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v)
        % SUB-CONTROLLER: Fill all cells
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;

        % 1. BranchUp: reference case
        scenario = addCellConfig(scenario, 1, 1, ...
            buildBranchCell(phi_base, 0.85, 4, 0.40, universal, v, 'branch_up'));

        % 2. BranchDown: branch to lower phi
        scenario = addCellConfig(scenario, 1, 2, ...
            buildBranchCell(phi_base, 0.65, 4, 0.40, universal, v, 'branch_down'));

        % 3. StepUp: all colonies shift up
        scenario = addCellConfig(scenario, 1, 3, ...
            buildStepCell(phi_base, 0.85, 4, universal, v, 'step_up'));

        % 4. StepDown: all colonies shift down
        scenario = addCellConfig(scenario, 1, 4, ...
            buildStepCell(phi_base, 0.65, 4, universal, v, 'step_down'));

        % 5. DelayBranch: later timing
        scenario = addCellConfig(scenario, 1, 5, ...
            buildBranchCell(phi_base, 0.85, 8, 0.40, universal, v, 'delay_branch'));

        % 6. LowProb: reduced branch probability
        scenario = addCellConfig(scenario, 1, 6, ...
            buildBranchCell(phi_base, 0.85, 4, 0.20, universal, v, 'low_prob'));

        % 7. HighProb: increased branch probability
        scenario = addCellConfig(scenario, 1, 7, ...
            buildBranchCell(phi_base, 0.85, 4, 0.60, universal, v, 'high_prob'));

        %% ---- CELL BUILDERS ----

        function cellConfig = buildBranchCell(phi_base, phi_post, event_round, p_event, universal, v, label)
            % SUB-CONTROLLER: Build a two-pool branching cell
            params = computeBranchParams(phi_base, phi_post, event_round, p_event);
            p_eff = computeBranchEffectiveTrajectory(params, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchCell(params, universal, label, predictors, v);

            function params = computeBranchParams(phi_base, phi_post, event_round, p_event)
                % MODEL: Branch parameters (TERMINAL)
                params = struct();
                params.p_base = phi_base;
                params.p_post = phi_post;
                params.event_round = event_round;
                params.p_event = p_event;
            end

            function p_eff = computeBranchEffectiveTrajectory(params, v)
                % MODEL: Population-mean phi(r) for branching (TERMINAL)
                r = 1:v;
                p_eff = params.p_base * ones(1, v);
                mask = r >= params.event_round;
                p_eff(mask) = params.p_event * params.p_post + ...
                    (1 - params.p_event) * params.p_base;
            end

            function cellConfig = packBranchCell(params, universal, label, predictors, v)
                % MODEL: Assemble two-pool branch cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool( ...
                    params.p_base * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                event_pool = buildPool( ...
                    params.p_post * ones(1, v), zeros(1, v), ...
                    'BranchLineage', [0.75, 0.55, 0.10], [], 0);

                cellConfig.pools = [base_pool, event_pool];
                cellConfig.branch_events = buildBranchEvent( ...
                    1, 'dividing', 2, 'per_colony', ...
                    params.p_event, [params.event_round]);

                cellConfig.log_params = struct( ...
                    'condition', label, ...
                    'p_base', params.p_base, ...
                    'p_post', params.p_post, ...
                    'event_round', params.event_round, ...
                    'p_event', params.p_event, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        function cellConfig = buildStepCell(phi_base, phi_post, step_round, universal, v, label)
            % SUB-CONTROLLER: Build a single-pool step cell
            p_traj = computeStepTrajectory(phi_base, phi_post, step_round, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packStepCell(p_traj, universal, label, predictors, v, ...
                phi_base, phi_post, step_round);

            function p_traj = computeStepTrajectory(phi_base, phi_post, step_round, v)
                % MODEL: Step trajectory at specified round (TERMINAL)
                p_traj = phi_base * ones(1, v);
                p_traj(step_round:end) = phi_post;
            end

            function cellConfig = packStepCell(p_traj, universal, label, predictors, v, ...
                    phi_base, phi_post, step_round)
                % MODEL: Assemble single-pool step cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    p_traj, zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'condition', label, ...
                    'p_base', phi_base, ...
                    'p_post', phi_post, ...
                    'step_round', step_round, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end
    end
end
