function scenario = buildSenescenceScenario(n_colonies, p_healthy_values, p_floor_values)
    % CONTROLLER: Build the senescence sweep scenario
    %
    % Grid shape: ordinal axis = p_floor values x HR on/off,
    %             nominal axis = p_healthy values.
    % First half of ordinal rows are HR off (single pool),
    % second half are HR on (two pools with conversion branch event).
    %
    % USAGE:
    %   scenario = buildSenescenceScenario();
    %   scenario = buildSenescenceScenario(1000, [0.70 0.80 0.90], [0.01 0.05 0.10]);

    if nargin < 1 || isempty(n_colonies),       n_colonies = 1000; end
    if nargin < 2 || isempty(p_healthy_values),  p_healthy_values = [0.70, 0.75, 0.80, 0.85, 0.90]; end
    if nargin < 3 || isempty(p_floor_values),    p_floor_values = [0.01, 0.05, 0.10, 0.15]; end

    scenario = initializeShell(p_healthy_values, p_floor_values);
    scenario = populateGrid(scenario, p_healthy_values, p_floor_values, n_colonies);

    function scenario = initializeShell(p_healthy_values, p_floor_values)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(p_healthy_values, p_floor_values);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'SenescenceSweep');

        function labels = buildLabels(p_healthy_values, p_floor_values)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            n_healthy = length(p_healthy_values);
            labels.nominal_display = cell(1, n_healthy);
            labels.nominal_fields = cell(1, n_healthy);
            for i = 1:n_healthy
                labels.nominal_display{i} = sprintf('pH=%.2f', p_healthy_values(i));
                labels.nominal_fields{i} = sprintf('pH_%03d', round(p_healthy_values(i) * 100));
            end
            n_floors = length(p_floor_values);
            n_ordinals = 2 * n_floors;
            labels.ordinal_display = cell(1, n_ordinals);
            for i = 1:n_floors
                labels.ordinal_display{i} = sprintf('pF=%.2f_noHR', p_floor_values(i));
                labels.ordinal_display{i + n_floors} = sprintf('pF=%.2f_HR', p_floor_values(i));
            end
        end
    end

    function scenario = populateGrid(scenario, p_healthy_values, p_floor_values, n_colonies)
        % SUB-CONTROLLER: Fill every cell
        v = 40;
        universal = makeUniversalConfig(n_colonies, v, 50);
        n_floors = length(p_floor_values);
        n_healthy = length(p_healthy_values);

        for ord_idx = 1:(2 * n_floors)
            is_HR = ord_idx > n_floors;
            floor_idx = ord_idx;
            if is_HR
                floor_idx = ord_idx - n_floors;
            end

            for nom_idx = 1:n_healthy
                cellConfig = buildCellConfig( ...
                    p_healthy_values(nom_idx), p_floor_values(floor_idx), ...
                    is_HR, universal, v);
                scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig);
            end
        end

        function cellConfig = buildCellConfig(p_healthy, p_floor, is_HR, universal, v)
            % SUB-CONTROLLER: Build one senescence cell config

            phase1_end = 15;
            phase2_end = 30;
            p_survivor = 0.80;
            eps_survivor = 0.00;
            p_HR_val = 1.5e-5;

            [p_traj, eps_traj] = buildPhasedTrajectory( ...
                p_healthy, p_floor, phase1_end, phase2_end, v);

            cellConfig = packCellConfig( ...
                p_traj, eps_traj, p_healthy, p_floor, is_HR, ...
                p_survivor, eps_survivor, p_HR_val, ...
                phase1_end, phase2_end, universal, v);

            function [p_traj, eps_traj] = buildPhasedTrajectory( ...
                    p_healthy, p_floor, phase1_end, phase2_end, v)
                % MODEL: Build phased p and epsilon trajectories (TERMINAL)
                p_traj = zeros(1, v);
                eps_traj = zeros(1, v);

                p_traj(1:phase1_end) = p_healthy;
                eps_traj(1:phase1_end) = 0.00;

                phase2_len = phase2_end - phase1_end;
                p_traj(phase1_end + 1 : phase2_end) = ...
                    linspace(0.70, 0.05, phase2_len);
                eps_traj(phase1_end + 1 : phase2_end) = 0.0;

                p_traj(phase2_end + 1 : v) = p_floor;
                eps_traj(phase2_end + 1 : v) = 0.0;
            end

            function cellConfig = packCellConfig( ...
                    p_traj, eps_traj, p_healthy, p_floor, is_HR, ...
                    p_survivor, eps_survivor, p_HR_val, ...
                    phase1_end, phase2_end, universal, v)
                % MODEL: Assemble pools, branch events, and metadata (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool(p_traj, eps_traj, ...
                    'Base', [0.30, 0.45, 0.75], [phase1_end, phase2_end], 1);

                if is_HR
                    survivor_pool = buildPool( ...
                        p_survivor * ones(1, v), eps_survivor * ones(1, v), ...
                        'Survivor', [0.75, 0.55, 0.10], [], 0);
                    cellConfig.pools = [base_pool, survivor_pool];
                    cellConfig.branch_events = buildBranchEvent( ...
                        1, 'arrested', 2, 'per_cell', p_HR_val, [phase1_end + 1, v]);
                    cellConfig.log_params = struct( ...
                        'p_healthy', p_healthy, 'p_floor', p_floor, ...
                        'HR', true, 'p_HR', p_HR_val);
                else
                    cellConfig.pools = base_pool;
                    cellConfig.branch_events = [];
                    cellConfig.log_params = struct( ...
                        'p_healthy', p_healthy, 'p_floor', p_floor, ...
                        'HR', false);
                end
            end
        end
    end
end
