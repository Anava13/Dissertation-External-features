function scenario = buildLibraryDiagnosticScenario(n_colonies, v, n_levels)
    % CONTROLLER: Build the library diagnostic scenario
    %
    % Six families on the nominal axis testing library behavior
    % across flat and non-stationary trajectories:
    %   1. FlatControl    — genuine symmetric epsilon, no trajectory structure
    %   2. LinearDecline  — smooth linear decline, eps=0
    %   3. StepDecline    — abrupt midpoint step, eps=0
    %   4. Bottleneck     — transient low-phi window with recovery, eps=0
    %   5. EarlyBranch    — branch at round 5, eps=0
    %   6. LateBranch     — branch at round 35, eps=0
    %
    % Magnitude levels on the ordinal axis. Level 0 produces identical
    % flat phi=0.75, eps=0 across all families.
    %
    % USAGE:
    %   scenario = buildLibraryDiagnosticScenario();
    %   scenario = buildLibraryDiagnosticScenario(1000, 40, 15);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end
    if nargin < 3 || isempty(n_levels),   n_levels = 15; end

    scenario = initializeShell(n_levels);
    scenario = populateGrid(scenario, n_colonies, v, n_levels);

    function scenario = initializeShell(n_levels)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(n_levels);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'LibraryDiagnosticSweep');

        function labels = buildLabels(n_levels)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = { ...
                'FlatControl', 'LinearDecline', 'StepDecline', ...
                'Bottleneck', 'EarlyBranch', 'LateBranch'};
            labels.nominal_fields = { ...
                'flat_control', 'linear_decline', 'step_decline', ...
                'bottleneck', 'early_branch', 'late_branch'};
            labels.ordinal_display = cell(1, n_levels);
            for i = 1:n_levels
                labels.ordinal_display{i} = sprintf('level_%02d', i - 1);
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, n_levels)
        % SUB-CONTROLLER: Fill every cell
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;

        for level = 0:(n_levels - 1)
            ord_idx = level + 1;

            scenario = addCellConfig(scenario, ord_idx, 1, ...
                buildFlatControlCell(level, phi_base, v, universal));

            scenario = addCellConfig(scenario, ord_idx, 2, ...
                buildLinearDeclineCell(level, phi_base, v, universal));

            scenario = addCellConfig(scenario, ord_idx, 3, ...
                buildStepDeclineCell(level, phi_base, v, universal));

            scenario = addCellConfig(scenario, ord_idx, 4, ...
                buildBottleneckCell(level, phi_base, v, universal));

            scenario = addCellConfig(scenario, ord_idx, 5, ...
                buildEarlyBranchCell(level, phi_base, v, universal));

            scenario = addCellConfig(scenario, ord_idx, 6, ...
                buildLateBranchCell(level, phi_base, v, universal));
        end

        %% ---- FAMILY BUILDERS ----

        function cellConfig = buildFlatControlCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Flat trajectory with genuine symmetric epsilon
            params = computeFlatControlParams(level, phi_base, v);
            predictors = computeTrajectoryPredictors(params.p_traj);
            cellConfig = packSinglePoolDiagnosticCell( ...
                params.p_traj, params.eps_traj, universal, ...
                'flat_control', level, predictors, v);

            function params = computeFlatControlParams(level, phi_base, v)
                % MODEL: Flat phi with scaled epsilon (TERMINAL)
                params = struct();
                params.p_traj = phi_base * ones(1, v);
                params.eps_traj = (0.01 * level) * ones(1, v);
            end
        end

        function cellConfig = buildLinearDeclineCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Linear decline from high to low, mean = phi_base
            p_traj = computeLinearDeclineTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'linear_decline', level, predictors, v);

            function p_traj = computeLinearDeclineTrajectory(level, phi_base, v)
                % MODEL: Linear ramp centered on phi_base (TERMINAL)
                delta = 0.005 * level;
                r = 1:v;
                p_traj = (phi_base + delta) - 2 * delta * (r - 1) / (v - 1);
            end
        end

        function cellConfig = buildStepDeclineCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Step function, high first half, low second half
            p_traj = computeStepDeclineTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'step_decline', level, predictors, v);

            function p_traj = computeStepDeclineTrajectory(level, phi_base, v)
                % MODEL: Step at midpoint, symmetric around phi_base (TERMINAL)
                delta = 0.005 * level;
                half = floor(v / 2);
                p_traj = [(phi_base + delta) * ones(1, half), ...
                          (phi_base - delta) * ones(1, v - half)];
            end
        end

        function cellConfig = buildBottleneckCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Transient low-phi window with full recovery
            p_traj = computeBottleneckTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'bottleneck', level, predictors, v);

            function p_traj = computeBottleneckTrajectory(level, phi_base, v)
                % MODEL: Phi drops during rounds 16-20 then recovers (TERMINAL)
                p_traj = phi_base * ones(1, v);
                bottleneck_phi = max(phi_base - 0.06 * level, 0.01);
                p_traj(16:20) = bottleneck_phi;
            end
        end

        function cellConfig = buildEarlyBranchCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Branch event at round 5
            rp = computeEarlyBranchParams(level, phi_base, v);
            p_eff = computeBranchEffectiveTrajectory(rp, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchDiagnosticCell( ...
                rp, universal, 'early_branch', level, predictors, v);

            function rp = computeEarlyBranchParams(level, phi_base, v)
                % MODEL: Early branch parameters (TERMINAL)
                rp = struct();
                rp.p_base = phi_base;
                rp.p_post = phi_base + 0.01 * level;
                rp.event_round = 5;
                rp.p_event = 0.40;
            end
        end

        function cellConfig = buildLateBranchCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Branch event at round 35
            rp = computeLateBranchParams(level, phi_base, v);
            p_eff = computeBranchEffectiveTrajectory(rp, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchDiagnosticCell( ...
                rp, universal, 'late_branch', level, predictors, v);

            function rp = computeLateBranchParams(level, phi_base, v)
                % MODEL: Late branch parameters (TERMINAL)
                rp = struct();
                rp.p_base = phi_base;
                rp.p_post = phi_base + 0.01 * level;
                rp.event_round = 35;
                rp.p_event = 0.40;
            end
        end

        %% ---- SHARED CELL PACKERS ----

        function p_eff = computeBranchEffectiveTrajectory(rp, v)
            % MODEL: Population-mean phi(r) for branching scenario (TERMINAL)
            r = 1:v;
            p_eff = rp.p_base * ones(1, v);
            mask = r >= rp.event_round;
            p_eff(mask) = rp.p_event * rp.p_post + (1 - rp.p_event) * rp.p_base;
        end

        function cellConfig = packSinglePoolDiagnosticCell( ...
                p_traj, eps_traj, universal, family_label, level, predictors, v)
            % MODEL: Build single-pool diagnostic cell with predictors (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;
            cellConfig.pools = buildPool( ...
                p_traj, eps_traj, ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig.branch_events = [];
            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', false, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end

        function cellConfig = packBranchDiagnosticCell( ...
                rp, universal, family_label, level, predictors, v)
            % MODEL: Build two-pool branch diagnostic cell (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;

            base_pool = buildPool( ...
                rp.p_base * ones(1, v), zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            event_pool = buildPool( ...
                rp.p_post * ones(1, v), zeros(1, v), ...
                'BranchLineage', [0.75, 0.55, 0.10], [], 0);

            cellConfig.pools = [base_pool, event_pool];
            cellConfig.branch_events = buildBranchEvent( ...
                1, 'dividing', 2, 'per_colony', rp.p_event, [rp.event_round]);

            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', true, ...
                'p_base', rp.p_base, 'p_post', rp.p_post, ...
                'event_round', rp.event_round, 'p_event', rp.p_event, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end
    end
end
