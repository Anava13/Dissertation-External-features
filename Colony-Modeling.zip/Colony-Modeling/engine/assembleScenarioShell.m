function scenario = assembleScenarioShell(labels, options, scenario_name)
    % MODEL: Assemble empty scenario shell (TERMINAL)
    scenario = struct();
    scenario.scenario_name = scenario_name;
    scenario.ordinal_labels = labels.ordinal_display;
    scenario.nominal_labels = labels.nominal_display;
    scenario.nominal_fields = labels.nominal_fields;
    scenario.analysis_options = options;
    n_ord = length(labels.ordinal_display);
    scenario.config = repmat(struct(), 1, n_ord);
end
