function applyLogTickLabels(ax, histData)
    % VIEW: Set x-axis ticks with original-unit labels (TERMINAL)
    if histData.empty, return; end
    log_range = [histData.log_bin_edges(1), histData.log_bin_edges(end)];
    candidate_ticks_um = [5, 10, 20, 30, 50, 75, 100, 150, 200, 300, 500, 750, 1000, 2000];
    candidate_ticks_log = log(candidate_ticks_um);
    in_range = candidate_ticks_log >= log_range(1) & candidate_ticks_log <= log_range(2);
    tick_vals = candidate_ticks_log(in_range);
    tick_labels = arrayfun(@(x) sprintf('%.0f', x), candidate_ticks_um(in_range), 'UniformOutput', false);
    set(ax, 'XTick', tick_vals, 'XTickLabel', tick_labels);
    xlim(ax, log_range);
end
