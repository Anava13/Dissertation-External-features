function stressTable = extractTrajectoryStressResults(scenario, results)
    % CONTROLLER: Walk a TrajectoryStressSweep results pair and build a flat
    % struct array pairing each cell's input-side predictors (from log_params)
    % with its output-side library stress.
    %
    % USAGE:
    %   stressTable = extractTrajectoryStressResults(scenario, results);

    stressTable = walkScenarioForStress(scenario, results);

    function stressTable = walkScenarioForStress(scenario, results)
        % SUB-CONTROLLER: Iterate over every grid cell
        n_ord = length(scenario.ordinal_labels);
        n_nom = length(scenario.nominal_labels);
        stressTable = preallocateStressTable(n_ord * n_nom);
        row = 0;
        for ord_idx = 1:n_ord
            for nom_idx = 1:n_nom
                row = row + 1;
                stressTable(row) = buildStressRow(scenario, results, ord_idx, nom_idx);
            end
        end

        function stressTable = preallocateStressTable(n_rows)
            % MODEL: Preallocate output struct array (TERMINAL)
            template = struct( ...
                'ord_idx', NaN, 'nom_idx', NaN, 'nom_field', '', ...
                'family_label', '', 'level', NaN, 'is_branched', false, ...
                'phi_avg', NaN, 'flat_L2', NaN, 'weighted_L2', NaN, ...
                'library_emd', NaN, 'library_cutoff', NaN, ...
                'library_stress', NaN, 'library_passed', false, ...
                'library_present', false);
            stressTable = repmat(template, 1, n_rows);
        end
    end

    function row = buildStressRow(scenario, results, ord_idx, nom_idx)
        % SUB-CONTROLLER: Assemble one row from log_params and library stress
        nom_field = scenario.nominal_fields{nom_idx};
        cellConfig = scenario.config(ord_idx).(nom_field);
        colonySet = results.analysisResults ...
            .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
        lib = extractLibraryAdequacy(colonySet);
        row = packRow(scenario, cellConfig, lib, ord_idx, nom_idx);

        function row = packRow(scenario, cellConfig, lib, ord_idx, nom_idx)
            % MODEL: Flatten log_params + library stress into row (TERMINAL)
            lp = cellConfig.log_params;
            row = struct();
            row.ord_idx       = ord_idx;
            row.nom_idx       = nom_idx;
            row.nom_field     = scenario.nominal_fields{nom_idx};
            row.family_label  = getFieldOr(lp, 'family', '');
            row.level         = getFieldOr(lp, 'level', NaN);
            row.is_branched   = getFieldOr(lp, 'is_branched', false);
            row.phi_avg       = getFieldOr(lp, 'phi_avg', NaN);
            row.flat_L2       = getFieldOr(lp, 'flat_L2', NaN);
            row.weighted_L2   = getFieldOr(lp, 'weighted_L2', NaN);
            row.library_present = lib.present;
            row.library_emd     = lib.emd;
            row.library_cutoff  = lib.cutoff;
            row.library_passed  = lib.passed;
            if ~isnan(lib.emd) && ~isnan(lib.cutoff) && lib.cutoff > 0
                row.library_stress = lib.emd / lib.cutoff;
            else
                row.library_stress = NaN;
            end

            function v = getFieldOr(s, name, default)
                % MODEL: Safe struct field read (TERMINAL)
                if isfield(s, name), v = s.(name); else, v = default; end
            end
        end
    end
end
