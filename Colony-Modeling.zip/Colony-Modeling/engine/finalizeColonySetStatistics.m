function colonySet = finalizeColonySetStatistics(colonySet)
    % MODEL: Compute subpopulation count, dominant, weight check (TERMINAL)
    components = colonySet.gmm_results.components;
    k = colonySet.gmm_results.optimal_components;
    colonySet.subpopulation_count = k;
    if k > 0 && ~isempty(components) && isfield(components, 'weight')
        weights = [components.weight];
        if all(isnan(weights))
            colonySet.dominant_subpopulation_barcode = "";
            colonySet.total_weight_check = NaN;
        else
            [~, max_idx] = max(weights);
            colonySet.dominant_subpopulation_barcode = components(max_idx).barcode;
            colonySet.total_weight_check = sum(weights);
        end
    else
        colonySet.dominant_subpopulation_barcode = "";
        colonySet.total_weight_check = NaN;
    end
end
