function scenario = buildLevelSubsetWithControlScenario(n_colonies, v)
    % CONTROLLER: Subset scenario with levels 7 and 14 + flat control
    % Reordered:
    %   - Levels: 14 then 7
    %   - Families: custom ordering (as specified in user layout)

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    % ---------------- REORDERED LEVELS ----------------
    levels = [14, 7];
    n_levels = numel(levels);

    scenario = initializeShell(n_levels, levels);
    scenario = populateGrid(scenario, n_colonies, v, levels);

    %% ---------------- INITIALIZE ----------------
    function scenario = initializeShell(n_levels, levels)

        labels = struct();

        labels.nominal_display = { ...
            'FlatControl', ...
            'LinearDecline', 'StepDecline', 'Bottleneck', ...
            'EarlyBranchUp', 'LateBranchUp', ...
            'LinearIncline', 'StepIncline', 'Boost', ...
            'EarlyBranchDn', 'LateBranchDn'};

        labels.nominal_fields = { ...
            'flat_control', ...
            'linear_decline', 'step_decline', 'bottleneck', ...
            'early_branch_up', 'late_branch_up', ...
            'linear_incline', 'step_incline', 'boost', ...
            'early_branch_dn', 'late_branch_dn'};

        labels.ordinal_display = cell(1, n_levels);
        for i = 1:n_levels
            labels.ordinal_display{i} = sprintf('level_%02d', levels(i));
        end

        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'LevelSubsetWithControl');
    end

    %% ---------------- POPULATE ----------------
    function scenario = populateGrid(scenario, n_colonies, v, levels)

        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;

        % ---------------- CUSTOM FAMILY ORDER ----------------
        family_order = { ...
            'flat_control', ...
            'linear_decline', ...
            'step_decline', ...
            'bottleneck', ...
            'early_branch_up', ...
            'late_branch_up', ...
            'linear_incline', ...
            'step_incline', ...
            'boost', ...
            'early_branch_dn', ...
            'late_branch_dn'};

        for li = 1:length(levels)
            level = levels(li);
            ord_idx = li;

            col = 1;

            for fi = 1:length(family_order)
                fam = family_order{fi};

                switch fam

                    case 'linear_decline'
                        p = (phi_base + 0.005*level) - ...
                            2*(0.005*level)*((1:v)-1)/(v-1);
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildSinglePool(p, universal, 'linear_decline', level));

                    case 'linear_incline'
                        p = (phi_base - 0.005*level) + ...
                            2*(0.005*level)*((1:v)-1)/(v-1);
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildSinglePool(p, universal, 'linear_incline', level));

                    case 'step_decline'
                        half = floor(v/2);
                        p = [(phi_base + 0.005*level)*ones(1,half), ...
                             (phi_base - 0.005*level)*ones(1,v-half)];
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildSinglePool(p, universal, 'step_decline', level));

                    case 'step_incline'
                        half = floor(v/2);
                        p = [(phi_base - 0.005*level)*ones(1,half), ...
                             (phi_base + 0.005*level)*ones(1,v-half)];
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildSinglePool(p, universal, 'step_incline', level));

                    case 'bottleneck'
                        % Swap levels: 14↔7 so bottleneck histogram
                        % panel shows level 7 at the level-14 position
                        if level == 14
                            bn_level = 7;
                        elseif level == 7
                            bn_level = 14;
                        else
                            bn_level = level;
                        end
                        p = phi_base * ones(1,v);
                        p(16:20) = max(phi_base - 0.06*bn_level, 0.01);
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildSinglePool(p, universal, 'bottleneck', bn_level));

                    case 'boost'
                        p = phi_base * ones(1,v);
                        p(16:20) = min(phi_base + 0.06*level, 0.99);
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildSinglePool(p, universal, 'boost', level));

                    case 'early_branch_up'
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildBranch(phi_base, phi_base + 0.01*level, 5, level));

                    case 'early_branch_dn'
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildBranch(phi_base, phi_base - 0.01*level, 5, level));

                    case 'late_branch_up'
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildBranch(phi_base, phi_base + 0.01*level, 35, level));

                    case 'late_branch_dn'
                        scenario = addCellConfig(scenario, ord_idx, col, ...
                            buildBranch(phi_base, phi_base - 0.01*level, 35, level));

                    case 'flat_control'
    p = phi_base * ones(1,v);

    eps_level = 0.01 * level;

    scenario = addCellConfig(scenario, ord_idx, col, ...
        buildSinglePool(p, universal, 'flat_control', level));
                end

                col = col + 1;
            end
        end
    end

    %% ---------------- HELPERS (UNCHANGED) ----------------

  function cellConfig = buildSinglePool(p_traj, universal, label, level)

    predictors = computeTrajectoryPredictors(p_traj);

    % ---------------- EPSILON (ONLY MODIFIED FOR FLAT CONTROL) ----------------
    if strcmp(label, 'flat_control')
        eps_traj = 0.01 * level * ones(size(p_traj));
    else
        eps_traj = zeros(size(p_traj));
    end

    % ---------------- POOL CONSTRUCTION ----------------
    cellConfig = struct();
    cellConfig.universal = universal;

    cellConfig.pools = buildPool( ...
        p_traj, eps_traj, ...
        'Base', [0.30 0.45 0.75], [], 1);

    cellConfig.branch_events = [];

    cellConfig.log_params = struct( ...
        'family', label, ...
        'level', level, ...
        'phi_geo', exp(mean(log(p_traj))), ...
        'phi_avg', predictors.phi_avg);
end
    function cellConfig = buildBranch(p_base, p_post, event_round, level)

        v_local = 40;

        base_pool = buildPool( ...
            p_base * ones(1,v_local), zeros(1,v_local), ...
            'Base', [0.30 0.45 0.75], [], 1);

        branch_pool = buildPool( ...
            p_post * ones(1,v_local), zeros(1,v_local), ...
            'BranchLineage', [0.75 0.55 0.10], [], 0);

        cellConfig = struct();
        cellConfig.universal = makeUniversalConfig(1000, v_local, 50);
        cellConfig.pools = [base_pool, branch_pool];

        cellConfig.branch_events = buildBranchEvent( ...
            1, 'dividing', 2, 'per_colony', 0.40, [event_round]);

        cellConfig.log_params = struct( ...
            'family', 'branch', ...
            'level', level, ...
            'event_round', event_round, ...
            'p_post', p_post);
    end
end
