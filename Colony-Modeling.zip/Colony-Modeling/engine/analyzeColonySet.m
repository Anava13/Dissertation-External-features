function colonySet = analyzeColonySet(rawMeasurements, options)
    % CONTROLLER: Run the full analysis pipeline on one colony set's radii.
    % When multiple mixture methods are specified, runs each independently
    % and selects the best fit by AIC.

    colonySet = initializeColonySet(rawMeasurements);
    colonySet = detectModes(colonySet);
    methods = parseMethods(options.mixture_distribution);

    if length(methods) == 1
        colonySet = runSingleMethod(colonySet, options);
    else
        colonySet = runAndSelectBestMethod(colonySet, options, methods);
    end

    function methods = parseMethods(mixture_distribution)
        % MODEL: Normalize mixture_distribution to cell array of char (TERMINAL)
        if ischar(mixture_distribution)
            methods = {mixture_distribution};
        elseif isstring(mixture_distribution)
            methods = cellstr(mixture_distribution);
        elseif iscell(mixture_distribution)
            methods = mixture_distribution;
        else
            methods = {'LogNormal'};
        end
    end

    function colonySet = runSingleMethod(colonySet, options)
        % SUB-CONTROLLER: Single-method path
        singleOptions = overrideMethodString(options, parseMethods(options.mixture_distribution));
        colonySet = fitMixtureModel(colonySet, singleOptions);
        colonySet = allocateSubpopulationsFromGMM(colonySet);
        colonySet = processAllSubpopulations(colonySet, singleOptions);
        colonySet = finalizeColonySetStatistics(colonySet);
        colonySet.selected_method = singleOptions.mixture_distribution;
        colonySet.alternative_fits = struct();

        function opts = overrideMethodString(options, methods)
            % MODEL: Ensure single string for mixture_distribution (TERMINAL)
            opts = options;
            opts.mixture_distribution = methods{1};
        end
    end

    function colonySet = runAndSelectBestMethod(colonySet, options, methods)
        % SUB-CONTROLLER: Run full pipeline per method, compare, select winner
        candidates = runAllMethods(colonySet, options, methods);
        colonySet = selectWinningMethod(candidates, methods);

        function candidates = runAllMethods(baseColonySet, options, methods)
            % SUB-CONTROLLER: Produce completed colonySet per method
            n_methods = length(methods);
            candidates = cell(1, n_methods);
            for m = 1:n_methods
                methodOptions = buildMethodOptions(options, methods{m});
                cs = baseColonySet;
                cs = fitMixtureModel(cs, methodOptions);
                cs = allocateSubpopulationsFromGMM(cs);
                cs = processAllSubpopulations(cs, methodOptions);
                cs = finalizeColonySetStatistics(cs);
                candidates{m} = cs;
            end

            function methodOptions = buildMethodOptions(options, methodStr)
                % MODEL: Clone options with single method string (TERMINAL)
                methodOptions = options;
                methodOptions.mixture_distribution = methodStr;
            end
        end

        function colonySet = selectWinningMethod(candidates, methods)
            % SUB-CONTROLLER: Library wins if adequate, else lowest AIC
            aics = extractAICs(candidates);
            winnerIdx = pickWinnerWithLibraryPriority(candidates, methods, aics);
            colonySet = installWinnerAndAlternatives(candidates, methods, winnerIdx, aics);

            function aics = extractAICs(candidates)
                % MODEL: Pull final_aic from each candidate (TERMINAL)
                n = length(candidates);
                aics = inf(1, n);
                for i = 1:n
                    if isfield(candidates{i}, 'gmm_results') && ...
                            isfield(candidates{i}.gmm_results, 'fitted_model') && ...
                            isfield(candidates{i}.gmm_results.fitted_model, 'final_aic')
                        val = candidates{i}.gmm_results.fitted_model.final_aic;
                        if isfinite(val), aics(i) = val; end
                    end
                end
            end

            function idx = pickWinnerWithLibraryPriority(candidates, methods, aics)
                % MODEL: Adequate Library wins, else min AIC (TERMINAL)
                for i = 1:length(candidates)
                    if strcmp(methods{i}, 'Library')
                        fm = candidates{i}.gmm_results.fitted_model;
                        if isfield(fm, 'library_adequacy_passed') && fm.library_adequacy_passed
                            idx = i;
                            return;
                        end
                    end
                end
                [~, idx] = min(aics);
                if ~isfinite(aics(idx)), idx = 1; end
            end

            function colonySet = installWinnerAndAlternatives(candidates, methods, winnerIdx, aics)
                % MODEL: Set winner, attach others as alternatives (TERMINAL)
                colonySet = candidates{winnerIdx};
                colonySet.selected_method = methods{winnerIdx};
                alternatives = struct();
                for i = 1:length(candidates)
                    if i ~= winnerIdx
                        fieldName = matlab.lang.makeValidName(methods{i});
                        alt = struct();
                        alt.method = methods{i};
                        alt.aic = aics(i);
                        alt.optimal_components = candidates{i}.gmm_results.optimal_components;
                        alt.gmm_results = candidates{i}.gmm_results;
                        alt.subpopulations = candidates{i}.subpopulations;
                        alt.subpopulation_count = candidates{i}.subpopulation_count;
                        alternatives.(fieldName) = alt;
                    end
                end
                colonySet.alternative_fits = alternatives;
            end
        end
    end
end
