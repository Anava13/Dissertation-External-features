function results = runPresetScenario(preset, library, seed)
    % CONTROLLER: Run one grid preset from presetCatalog
    %
    % Inputs:
    %   preset  : one grid entry of presetCatalog (kind = 'grid')
    %   library : struct from loadStablePhiLibrary
    %   seed    : RNG seed. The global generator is reset before the run,
    %             so a preset returns the same output whenever it runs.
    %
    % The preset names a scenario builder, e.g. 'LibraryDiagnostic'
    % resolves to buildLibraryDiagnosticScenario.

    applyPresetSeed(seed);
    builder = resolvePresetBuilder(preset);
    results = runModel(builder, library, preset.args{:});

    % === SUB-CONTROLLERS ===

    function applyPresetSeed(seed)
        % SUB-CONTROLLER: Reset the global RNG
        resetGlobalRNG(seed);

        function resetGlobalRNG(seed)
            % MODEL: Seed the Mersenne Twister generator (TERMINAL)
            rng(seed, 'twister');
        end
    end

    function builder = resolvePresetBuilder(preset)
        % SUB-CONTROLLER: Turn the scenario name into a builder handle
        builder = buildHandleFromName(preset.scenario);

        function builder = buildHandleFromName(scenarioName)
            % MODEL: Resolve build<Name>Scenario on the path (TERMINAL)
            builderName = ['build', scenarioName, 'Scenario'];
            if exist(builderName, 'file') ~= 2
                error('runPresetScenario:UnknownScenario', ...
                    'No scenario builder named %s on the path', builderName);
            end
            builder = str2func(builderName);
        end
    end
end
