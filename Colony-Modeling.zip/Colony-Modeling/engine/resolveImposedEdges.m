function imposed_edges = resolveImposedEdges(state)
    % MODEL: Return global edges or empty (TERMINAL)
    if strcmp(state.axis_mode, 'global') && state.global_limits.valid
        imposed_edges = state.global_limits.hist_log_edges;
    else
        imposed_edges = [];
    end
end
