function exportResultsPDF(results, OutputFigures, scenarioName)
    % CONTROLLER: Export all views to a multi-page PDF with index table

    colonySets = flattenColonySets(results);
    renderState = buildPDFRenderState(results);
    pdfPath = fullfile(OutputFigures, [scenarioName '_results.pdf']);

    fig = createOffscreenFigure(scenarioName);

    % Pages 1+: Index table (paginated, max 20 rows per page)
    renderAndExportIndexPages(fig, colonySets, scenarioName, pdfPath);

    % Library fit table pages (appended only if any fits exist)
    renderAndExportLibraryTablePages(fig, colonySets, renderState, scenarioName, pdfPath);

    % Remaining pages: View modes (Trajectory, Histogram, Mixture, Composition)
    renderAndAppendViewPages(fig, renderState, colonySets, pdfPath);

    close(fig);
    fprintf('PDF saved: %s\n', pdfPath);

    % === SUB-CONTROLLERS ===

    function colonySets = flattenColonySets(results)
        % SUB-CONTROLLER: Build ordered colony set list with letter labels
        n_ord = length(results.scenario.ordinal_labels);
        n_nom = length(results.scenario.nominal_labels);
        n_sets = n_ord * n_nom;
        colonySets = repmat(struct('letter','','ord_idx',0,'nom_idx',0, ...
            'ord_label','','nom_label',''), 1, n_sets);
        idx = 0;
        for o = 1:n_ord
            for n = 1:n_nom
                idx = idx + 1;
                letter = generateLetterLabel(idx);
                colonySets(idx) = packEntry(letter, o, n, results);
            end
        end

        function label = generateLetterLabel(index)
            % MODEL: Convert 1-based index to spreadsheet-style letter (TERMINAL)
            label = '';
            while index > 0
                index = index - 1;
                label = [char('A' + mod(index, 26)), label];
                index = floor(index / 26);
            end
        end

        function entry = packEntry(letter, o, n, results)
    % MODEL: Pack one colony set entry (TERMINAL)
    entry = struct();
    entry.letter = letter;
    entry.ord_idx = o;
    entry.nom_idx = n;
    entry.ord_label = sanitizeDisplayLabel(results.scenario.ordinal_labels{o});
    entry.nom_label = sanitizeDisplayLabel(results.scenario.nominal_labels{n});
end
    end

    function renderState = buildPDFRenderState(results)
        % SUB-CONTROLLER: Build render state in global axis mode
        gl = computeGlobalLimits(results);
        renderState = packRenderState(results, gl);

        function rs = packRenderState(results, gl)
            % MODEL: Assemble render state struct (TERMINAL)
            rs = struct();
            rs.results = results;
            rs.axis_mode = 'global';
            rs.global_limits = gl;
        end
    end

    function fig = createOffscreenFigure(scenarioName)
        % VIEW: Create invisible figure for PDF rendering (TERMINAL)
        fig = figure('Visible', 'off', ...
            'Units', 'inches', 'Position', [0, 0, 11, 8.5], ...
            'PaperUnits', 'inches', 'PaperSize', [11, 8.5], ...
            'PaperPosition', [0, 0, 11, 8.5], ...
            'Color', 'w', 'NumberTitle', 'off', ...
            'Name', sprintf('PDF Export: %s', scenarioName));
    end

    function renderAndExportIndexPages(fig, colonySets, scenarioName, pdfPath)
        % SUB-CONTROLLER: Render paginated index table pages and export
        n_sets = length(colonySets);
        rows_per_page = 20;
        n_pages = ceil(n_sets / rows_per_page);

        for p = 1:n_pages
            startIdx = (p - 1) * rows_per_page + 1;
            endIdx = min(p * rows_per_page, n_sets);

            renderIndexTablePage(fig, colonySets(startIdx:endIdx), scenarioName, p, n_pages);

            if p == 1
                exportgraphics(fig, pdfPath, 'ContentType', 'vector');
            else
                exportgraphics(fig, pdfPath, 'ContentType', 'vector', 'Append', true);
            end
        end

        function renderIndexTablePage(fig, colonySubset, scenarioName, pageNum, totalPages)
            % SUB-CONTROLLER: Render one page of the index table
            clf(fig);
            tableData = buildTableData(colonySubset);
            drawIndexTable(fig, tableData, scenarioName, pageNum, totalPages);

            function tableData = buildTableData(colonySubset)
                % MODEL: Organize table content (TERMINAL)
                n = length(colonySubset);
                tableData = struct();
                tableData.headers = {'Index', 'Ordinal', 'Nominal'};
                tableData.n_rows = n;
                tableData.rows = cell(n, 3);
                for i = 1:n
                    tableData.rows{i, 1} = colonySubset(i).letter;
                    tableData.rows{i, 2} = colonySubset(i).ord_label;
                    tableData.rows{i, 3} = colonySubset(i).nom_label;
                end
            end

            function drawIndexTable(fig, tableData, scenarioName, pageNum, totalPages)
                % VIEW: Draw formatted index table with gridlines (TERMINAL)
                ax = axes(fig, 'Position', [0.15, 0.08, 0.70, 0.80]);
                hold(ax, 'on');
                set(ax, 'Visible', 'off');

                n_rows = tableData.n_rows;
                n_cols = 3;

                % Column layout (proportional widths within [0,1])
                col_widths = [0.12, 0.44, 0.44];
                col_x = [0, cumsum(col_widths)];

                font_data = 10;
                font_header = font_data + 1;

                total_rows = n_rows + 1;  % +1 for header
                row_h = 1 / total_rows;

                % --- Page title ---
                if totalPages > 1
                    titleStr = sprintf('Colony Set Index: %s  (page %d/%d)', ...
                        strrep(scenarioName, '_', ' '), pageNum, totalPages);
                else
                    titleStr = sprintf('Colony Set Index: %s', ...
                        strrep(scenarioName, '_', ' '));
                end
                text(ax, 0.5, 1.08, titleStr, ...
                    'FontSize', 14, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'bottom', 'Units', 'data');

                % --- Header row ---
                header_y_top = 1;
                header_y_mid = header_y_top - row_h / 2;
                for c = 1:n_cols
                    x_mid = (col_x(c) + col_x(c + 1)) / 2;
                    text(ax, x_mid, header_y_mid, tableData.headers{c}, ...
                        'FontSize', font_header, 'FontWeight', 'bold', ...
                        'HorizontalAlignment', 'center', ...
                        'VerticalAlignment', 'middle');
                end

                % Header background
                fill(ax, [0, 1, 1, 0], ...
                    [header_y_top, header_y_top, header_y_top - row_h, header_y_top - row_h], ...
                    [0.85, 0.85, 0.90], 'EdgeColor', 'none');

                % Header bottom border
                line(ax, [0, 1], [header_y_top - row_h, header_y_top - row_h], ...
                    'Color', 'k', 'LineWidth', 1.5);

                % --- Data rows ---
                for r = 1:n_rows
                    y_top = header_y_top - r * row_h;
                    y_mid = y_top - row_h / 2;

                    % Alternating row shading
                    if mod(r, 2) == 0
                        fill(ax, [0, 1, 1, 0], ...
                            [y_top, y_top, y_top - row_h, y_top - row_h], ...
                            [0.95, 0.95, 0.97], 'EdgeColor', 'none');
                    end

                    % Cell text
                    for c = 1:n_cols
                        x_mid = (col_x(c) + col_x(c + 1)) / 2;
                        text(ax, x_mid, y_mid, tableData.rows{r, c}, ...
                            'FontSize', font_data, ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle');
                    end
                end

                % --- Gridlines ---
                table_bottom = header_y_top - total_rows * row_h;

                % Vertical column dividers
                for c = 2:n_cols
                    line(ax, [col_x(c), col_x(c)], [header_y_top, table_bottom], ...
                        'Color', [0.7, 0.7, 0.7], 'LineWidth', 0.5);
                end

                % Outer border
                rectangle(ax, 'Position', [0, table_bottom, 1, header_y_top - table_bottom], ...
                    'EdgeColor', 'k', 'LineWidth', 1.2);

                % Top border (double weight)
                line(ax, [0, 1], [header_y_top, header_y_top], 'Color', 'k', 'LineWidth', 1.2);

                xlim(ax, [-0.05, 1.05]);
                ylim(ax, [table_bottom - 0.03, 1.12]);
                hold(ax, 'off');
            end
        end
    end

    function renderAndExportLibraryTablePages(fig, colonySets, renderState, scenarioName, pdfPath)
        % SUB-CONTROLLER: Render library fit table pages if any fits exist

        libraryRows = extractAllLibraryFits(colonySets, renderState);
        if ~libraryRows.anyFitsPresent
            return;
        end

        rows_per_page = 20;
        n_sets = length(colonySets);
        n_pages = ceil(n_sets / rows_per_page);

        for p = 1:n_pages
            startIdx = (p - 1) * rows_per_page + 1;
            endIdx = min(p * rows_per_page, n_sets);

            renderLibraryTablePage(fig, libraryRows, scenarioName, p, n_pages, startIdx, endIdx);
            exportgraphics(fig, pdfPath, 'ContentType', 'vector', 'Append', true);
        end

        function libraryRows = extractAllLibraryFits(colonySets, renderState)
            % SUB-CONTROLLER: Extract library fit data for all colony sets
            n = length(colonySets);
            fitData = repmat(struct('letter','','ord_label','','nom_label','', ...
                'hasFit',false,'phi',NaN,'eps',NaN,'q_shape',NaN), 1, n);
            anyFits = false;

            for i = 1:n
                cs = colonySets(i);
                colonySet = lookupColonySet(renderState, cs.ord_idx, cs.nom_idx);
                lib = extractLibraryAdequacy(colonySet);
                fitData(i) = packLibraryRow(cs, lib);
                if fitData(i).hasFit
                    anyFits = true;
                end
            end

            libraryRows = struct();
            libraryRows.fitData = fitData;
            libraryRows.anyFitsPresent = anyFits;

         
            function row = packLibraryRow(cs, lib)
                % MODEL: Pack one library table row (TERMINAL)
                row = struct();
                row.letter = cs.letter;
                row.ord_label = cs.ord_label;
                row.nom_label = cs.nom_label;
                row.hasFit = lib.present && ~isnan(lib.phi) && ~isnan(lib.eps);
                if row.hasFit
                    row.phi = lib.phi;
                    row.eps = lib.eps;
                    row.q_shape = lib.quality_shape;
                else
                    row.phi = NaN;
                    row.eps = NaN;
                    row.q_shape = NaN;
                end
            end
        end

        function renderLibraryTablePage(fig, libraryRows, scenarioName, pageNum, totalPages, startIdx, endIdx)
            % SUB-CONTROLLER: Render one page of the library fit table
            clf(fig);
            tableData = buildLibraryTableData(libraryRows.fitData(startIdx:endIdx));
            drawLibraryTable(fig, tableData, scenarioName, pageNum, totalPages);

            function tableData = buildLibraryTableData(fitSubset)
                % MODEL: Organize library table content (TERMINAL)
                n = length(fitSubset);
                tableData = struct();
                tableData.headers = {'Index', 'Ordinal', 'Nominal', ...
                    '\phi', '\epsilon', 'Q_{shape}'};
                tableData.n_rows = n;
                tableData.rows = cell(n, 6);
                for i = 1:n
                    tableData.rows{i, 1} = fitSubset(i).letter;
                    tableData.rows{i, 2} = fitSubset(i).ord_label;
                    tableData.rows{i, 3} = fitSubset(i).nom_label;
                    if fitSubset(i).hasFit
                        tableData.rows{i, 4} = sprintf('%.2f', fitSubset(i).phi);
                        tableData.rows{i, 5} = sprintf('%.2f', fitSubset(i).eps);
                        if ~isnan(fitSubset(i).q_shape)
                            tableData.rows{i, 6} = sprintf('%.2f', fitSubset(i).q_shape);
                        else
                            tableData.rows{i, 6} = '-';
                        end
                    else
                        tableData.rows{i, 4} = 'No Fit';
                        tableData.rows{i, 5} = 'No Fit';
                        tableData.rows{i, 6} = 'No Fit';
                    end
                end
            end

            function drawLibraryTable(fig, tableData, scenarioName, pageNum, totalPages)
                % VIEW: Draw formatted library fit table with gridlines (TERMINAL)
                ax = axes(fig, 'Position', [0.10, 0.08, 0.80, 0.80]);
                hold(ax, 'on');
                set(ax, 'Visible', 'off');

                n_rows = tableData.n_rows;
                n_cols = 6;

                % Column layout (proportional widths within [0,1])
                col_widths = [0.08, 0.26, 0.26, 0.12, 0.12, 0.16];
                col_x = [0, cumsum(col_widths)];

                font_data = 10;
                font_header = font_data + 1;

                total_rows = n_rows + 1;
                row_h = 1 / total_rows;

                % --- Page title ---
                if totalPages > 1
                    titleStr = sprintf('Library Fits: %s  (page %d/%d)', ...
                        strrep(scenarioName, '_', ' '), pageNum, totalPages);
                else
                    titleStr = sprintf('Library Fits: %s', ...
                        strrep(scenarioName, '_', ' '));
                end
                text(ax, 0.5, 1.08, titleStr, ...
                    'FontSize', 14, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'bottom', 'Units', 'data');

                % --- Header row ---
                header_y_top = 1;
                header_y_mid = header_y_top - row_h / 2;

                % Header background (drawn first so text renders on top)
                fill(ax, [0, 1, 1, 0], ...
                    [header_y_top, header_y_top, header_y_top - row_h, header_y_top - row_h], ...
                    [0.85, 0.85, 0.90], 'EdgeColor', 'none');

                % Header text
                for c = 1:n_cols
                    x_mid = (col_x(c) + col_x(c + 1)) / 2;
                    text(ax, x_mid, header_y_mid, tableData.headers{c}, ...
                        'FontSize', font_header, 'FontWeight', 'bold', ...
                        'HorizontalAlignment', 'center', ...
                        'VerticalAlignment', 'middle', ...
                        'Interpreter', 'tex');
                end

                % Header bottom border
                line(ax, [0, 1], [header_y_top - row_h, header_y_top - row_h], ...
                    'Color', 'k', 'LineWidth', 1.5);

                % --- Data rows ---
                for r = 1:n_rows
                    y_top = header_y_top - r * row_h;
                    y_mid = y_top - row_h / 2;

                    % Alternating row shading
                    if mod(r, 2) == 0
                        fill(ax, [0, 1, 1, 0], ...
                            [y_top, y_top, y_top - row_h, y_top - row_h], ...
                            [0.95, 0.95, 0.97], 'EdgeColor', 'none');
                    end

                    % Cell text
                    for c = 1:n_cols
                        x_mid = (col_x(c) + col_x(c + 1)) / 2;
                        text(ax, x_mid, y_mid, tableData.rows{r, c}, ...
                            'FontSize', font_data, ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle');
                    end
                end

                % --- Gridlines ---
                table_bottom = header_y_top - total_rows * row_h;

                % Vertical column dividers
                for c = 2:n_cols
                    line(ax, [col_x(c), col_x(c)], [header_y_top, table_bottom], ...
                        'Color', [0.7, 0.7, 0.7], 'LineWidth', 0.5);
                end

                % Outer border
                rectangle(ax, 'Position', [0, table_bottom, 1, header_y_top - table_bottom], ...
                    'EdgeColor', 'k', 'LineWidth', 1.2);

                % Top border (double weight)
                line(ax, [0, 1], [header_y_top, header_y_top], 'Color', 'k', 'LineWidth', 1.2);

                xlim(ax, [-0.05, 1.05]);
                ylim(ax, [table_bottom - 0.03, 1.12]);
                hold(ax, 'off');
            end
        end
    end
    function renderAndAppendViewPages(fig, renderState, colonySets, pdfPath)
    % SUB-CONTROLLER: Render all view mode pages and append to PDF
    viewNames = {'Trajectory', 'Histogram', 'Mixture Model', 'Composition', 'KDE'};
    renderers = {@renderTrajectoryCell, @renderHistogramCell, ...
                 @renderMixtureCell, @renderCompositionCell, @renderKDECell};

    n_sets = length(colonySets);
    n_per_page = 4;

    for v = 1:length(viewNames)
        n_pages = ceil(n_sets / n_per_page);
        for p = 1:n_pages
            startIdx = (p - 1) * n_per_page + 1;
            endIdx = min(p * n_per_page, n_sets);

            preparePage(fig, viewNames{v}, p, n_pages);
            populatePageCells(fig, renderState, colonySets, ...
                renderers{v}, viewNames{v}, startIdx, endIdx);

            exportgraphics(fig, pdfPath, 'ContentType', 'vector', 'Append', true);
        end
    end

    function preparePage(fig, viewName, pageNum, totalPages)
        % VIEW: Clear figure and add page title (TERMINAL)
        clf(fig);
        if totalPages > 1
            titleStr = sprintf('%s  (page %d/%d)', viewName, pageNum, totalPages);
        else
            titleStr = viewName;
        end
        annotation(fig, 'textbox', [0, 0.92, 1, 0.07], ...
            'String', titleStr, ...
            'FontSize', 16, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'middle', ...
            'EdgeColor', 'none', 'BackgroundColor', 'w');
    end

    function populatePageCells(fig, renderState, colonySets, renderer, viewName, startIdx, endIdx)
        % SUB-CONTROLLER: Create axes and render each cell on the page

        for i = startIdx:endIdx
            slotIdx = i - startIdx + 1;
            axPos = computeSubplotPosition(slotIdx);
            ax = createCellAxes(fig, axPos);

            cs = colonySets(i);
            renderer(ax, renderState, cs.ord_idx, cs.nom_idx);

            titleCellAxes(ax, cs);
            labelCellAxes(ax, cs.letter);

            if strcmp(viewName, 'Trajectory')
                annotateTrajectoryLibraryFit(ax, renderState, cs);
            end
        end

        function pos = computeSubplotPosition(slotIdx)
            % MODEL: Calculate axes position for 2x2 grid slot (TERMINAL)
            row = ceil(slotIdx / 2);
            col = mod(slotIdx - 1, 2) + 1;

            x_origins = [0.08, 0.54];
            y_origins = [0.52, 0.09];
            plot_w = 0.40;
            plot_h = 0.33;

            pos = [x_origins(col), y_origins(row), plot_w, plot_h];
        end

        function ax = createCellAxes(fig, pos)
            % VIEW: Create axes at specified position (TERMINAL)
            ax = axes(fig, 'Position', pos, 'Box', 'on');
        end

        function titleCellAxes(ax, cs)
            % VIEW: Set axes title to nominal and ordinal labels (TERMINAL)
            title(ax, sprintf('%s, %s', cs.nom_label, cs.ord_label), ...
                'FontSize', 10, 'FontWeight', 'normal');
        end

        function labelCellAxes(ax, letter)
            % VIEW: Add letter label just outside top-left of axes (TERMINAL)
            text(ax, -0.06, 1.04, letter, ...
                'Units', 'normalized', ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'FontSize', 11, ...
                'FontWeight', 'bold', ...
                'Clipping', 'off');
        end

        function annotateTrajectoryLibraryFit(ax, renderState, cs)
            % SUB-CONTROLLER: Add library fit annotation beside trajectory axes
            libInfo = extractCellLibraryInfo(renderState, cs);
            if ~libInfo.present
                return;
            end
            drawLibraryAnnotation(ax, libInfo);

            function libInfo = extractCellLibraryInfo(renderState, cs)
                % MODEL: Extract library adequacy for one cell (TERMINAL)
                nom_field = renderState.results.scenario.nominal_fields{cs.nom_idx};
                colonySet = renderState.results.analysisResults ...
                    .SubpopulationAnalysis(cs.ord_idx).(nom_field).ColonySet;
                lib = extractLibraryAdequacy(colonySet);
                libInfo = struct();
                libInfo.present = lib.present && ~isnan(lib.phi) && ~isnan(lib.eps);
                if libInfo.present
                    libInfo.phi = lib.phi;
                    libInfo.eps = lib.eps;
                    libInfo.q_shape = lib.quality_shape;
                else
                    libInfo.phi = NaN;
                    libInfo.eps = NaN;
                    libInfo.q_shape = NaN;
                end
            end

            function drawLibraryAnnotation(ax, libInfo)
                % VIEW: Draw library fit annotation inside axes (TERMINAL)

                % Title line
                text(ax, 0.98, 0.97, 'Library Fit', ...
                    'Units', 'normalized', ...
                    'HorizontalAlignment', 'right', ...
                    'VerticalAlignment', 'top', ...
                    'FontSize', 7, ...
                    'FontWeight', 'bold');

                % Values line
                if ~isnan(libInfo.q_shape)
                    valStr = sprintf('\\phi=%.2f, \\epsilon=%.2f, Q=%.2f', ...
                        libInfo.phi, libInfo.eps, libInfo.q_shape);
                else
                    valStr = sprintf('\\phi=%.2f, \\epsilon=%.2f', ...
                        libInfo.phi, libInfo.eps);
                end
                text(ax, 0.98, 0.89, valStr, ...
                    'Units', 'normalized', ...
                    'HorizontalAlignment', 'right', ...
                    'VerticalAlignment', 'top', ...
                    'FontSize', 7, ...
                    'Interpreter', 'tex');
            end
        end
    end
end

end
