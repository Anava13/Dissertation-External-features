function scenario = buildRescueScenario(n_colonies)
    % CONTROLLER: Build the rescue event scenario
    %
    % Grid shape: ordinal axis = single row,
    %             nominal axis = Rescue / Stable / Drop.
    % Each colony rolls p_event at event_round. Event colonies
    % found a second pool at p_post. Non-event colonies stay at p_base.
    %
    % USAGE:
    %   scenario = buildRescueScenario();
    %   scenario = buildRescueScenario(1000);

    if nargin < 1 || isempty(n_colonies)
        n_colonies = 1000;
    end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies);

    function scenario = initializeShell()
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels();
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'RescueEvent');

        function labels = buildLabels()
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = {'Rescue', 'Stable', 'Drop'};
            labels.nominal_fields  = {'Rescue', 'Stable', 'Drop'};
            labels.ordinal_display = {''};
        end
    end

    function scenario = populateGrid(scenario, n_colonies)
        % SUB-CONTROLLER: Fill all cells
        v = 40;
        universal = makeUniversalConfig(n_colonies, v, 50);

        % Column 1: Rescue (p_base=0.75, p_post=0.85)
        scenario = addCellConfig(scenario, 1, 1, ...
            buildCellConfig(0.75, 0.85, 5, 0.4, universal, v, 'Rescue'));

        % Column 2: Stable (p_base=0.75, p_post=0.75)
        scenario = addCellConfig(scenario, 1, 2, ...
            buildCellConfig(0.75, 0.75, 5, 0.4, universal, v, 'Stable'));

        % Column 3: Drop (p_base=0.75, p_post=0.0)
        scenario = addCellConfig(scenario, 1, 3, ...
            buildCellConfig(0.75, 0.0, 5, 0.4, universal, v, 'Drop'));

        function cellConfig = buildCellConfig(p_base, p_post, event_round, p_event, universal, v, condition_label)
            % MODEL: Build one rescue cell config (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;

            base_pool = buildPool( ...
                p_base * ones(1, v), zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);

            event_pool = buildPool( ...
                p_post * ones(1, v), zeros(1, v), ...
                'mutant lineage', [0.75, 0.55, 0.10], [], 0);

            cellConfig.pools = [base_pool, event_pool];
            cellConfig.branch_events = buildBranchEvent( ...
                1, 'dividing', 2, 'per_colony', p_event, [event_round]);

            cellConfig.log_params = struct( ...
                'condition', condition_label, ...
                'p_base', p_base, 'p_post', p_post, ...
                'p_event', p_event, 'event_round', event_round);
        end
    end
end
