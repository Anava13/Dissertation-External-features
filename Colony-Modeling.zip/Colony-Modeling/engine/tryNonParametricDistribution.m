function result = tryNonParametricDistribution(data)
    % MODEL: KDE-based non-parametric fit (TERMINAL)
    result = struct('bandwidth', NaN, 'kernel_points', [], 'density_values', [], ...
        'peak_estimate', NaN, 'effective_sample_size', length(data));
    if length(data) < 20
        if ~isempty(data), result.peak_estimate = mean(data); end
        return;
    end
    try
        [density_values, kernel_points, bandwidth] = ksdensity(data);
        [~, max_idx] = max(density_values);
        result.bandwidth = bandwidth;
        result.kernel_points = kernel_points;
        result.density_values = density_values;
        result.peak_estimate = kernel_points(max_idx);
    catch
        result.peak_estimate = mean(data);
    end
end
