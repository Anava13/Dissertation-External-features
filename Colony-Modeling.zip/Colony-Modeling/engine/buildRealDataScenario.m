function scenario = buildRealDataScenario(AllMeasures, experimentConfig)
    % CONTROLLER: Construct scenario shell from real measurement data
    %
    % Returns a scenario object compatible with the analysis and
    % visualization pipelines. The scenario carries the AllMeasures
    % source struct in scenario.real_data_source so that runRealData can
    % pull radii on demand. The is_real_data flag tells runModel which
    % runner to dispatch to.
    %
    % experimentConfig is the schema source: nominal field names and
    % display labels come from experimentConfig.variables.nominal,
    % ordinal labels from experimentConfig.variables.ordinal.
    %
    % experimentConfig.projectName is used as scenario_name. The full
    % experimentConfig is stored on the scenario for downstream use.

    validateExperimentConfig(experimentConfig);
    nominalInfo = computeNominalInfo(experimentConfig);
    n_ord = computeOrdinalCount(experimentConfig);
    ordinalLabels = buildOrdinalLabels(experimentConfig);
    config = buildStubConfigGrid(n_ord, nominalInfo.fields);
    analysis_options = buildDefaultAnalysisOptions();
    scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, ...
        analysis_options, AllMeasures, experimentConfig);

    function validateExperimentConfig(experimentConfig)
        % MODEL: Hard-error on missing or empty projectName (TERMINAL)
        if ~isstruct(experimentConfig) || ~isfield(experimentConfig, 'projectName')
            error('buildRealDataScenario:MissingProjectName', ...
                'experimentConfig must be a struct with a projectName field.');
        end
        if isempty(experimentConfig.projectName)
            error('buildRealDataScenario:EmptyProjectName', ...
                'experimentConfig.projectName must be non-empty.');
        end
    end

    function info = computeNominalInfo(experimentConfig)
        % MODEL: Pull nominal field names and display labels from config (TERMINAL)
        info = struct();
        info.fields = experimentConfig.variables.nominal.values;
        info.labels = experimentConfig.variables.nominal.display_values;
    end

    function n_ord = computeOrdinalCount(experimentConfig)
        % MODEL: Get ordinal count from config (TERMINAL)
        n_ord = length(experimentConfig.variables.ordinal.values);
    end

    function labels = buildOrdinalLabels(experimentConfig)
        % MODEL: Pull ordinal display labels from config (TERMINAL)
        labels = experimentConfig.variables.ordinal.display_values;
    end

    function config = buildStubConfigGrid(n_ord, nominal_fields)
        % MODEL: Build per-cell stub configs for real data (TERMINAL)
        stubCell = struct();
        stubCell.pools = struct( ...
            'initial_S', {}, ...
            'p_traj', {}, ...
            'eps_traj', {}, ...
            'phase_boundaries', {}, ...
            'color', {}, ...
            'label', {});
        stubCell.branch_events = struct( ...
            'source_pool', {}, ...
            'target_pool', {}, ...
            'eligible_rounds', {});
        stubCell.universal = struct('v', 40);
        stubCell.log_params = struct();

        config = repmat(struct(), 1, n_ord);
        for ord = 1:n_ord
            for nom = 1:length(nominal_fields)
                config(ord).(nominal_fields{nom}) = stubCell;
            end
        end
    end

    function options = buildDefaultAnalysisOptions()
        % MODEL: Default analysis options for real data (TERMINAL)
        options = struct();
        options.max_components = 4;
        options.connection_threshold = 0.5;
        options.connection_cost_bias = 0.5;
        options.normalization = 'log';
        options.rng_seed = [];
    end

    function scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, analysis_options, AllMeasures, experimentConfig)
        % MODEL: Pack the real-data scenario struct (TERMINAL)
        scenario = struct();
        scenario.scenario_name = experimentConfig.projectName;
        scenario.experiment_config = experimentConfig;
        scenario.nominal_fields = nominalInfo.fields;
        scenario.nominal_labels = nominalInfo.labels;
        scenario.ordinal_labels = ordinalLabels;
        scenario.config = config;
        scenario.analysis_options = analysis_options;
        scenario.is_real_data = true;
        scenario.real_data_source = AllMeasures;
    end
end
