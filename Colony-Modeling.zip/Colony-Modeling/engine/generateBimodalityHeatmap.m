function generateBimodalityHeatmap(results)
    % CONTROLLER: Generate gap x event_round bimodality heatmap from Probe 3 results
    %
    % USAGE:
    %   generateBimodalityHeatmap(results)
    %
    % Assumes results struct from BranchingProbe3 is in workspace.

    gridData = extractModeGrid(results);
    renderHeatmap(gridData);

    % === SUB-CONTROLLERS ===

    function gridData = extractModeGrid(results)
        % SUB-CONTROLLER: Build the mode-count matrix from results
        axes = extractAxisValues(results);
        modeMatrix = buildModeMatrix(results, axes);
        gridData = packGridData(axes, modeMatrix);

        function axes = extractAxisValues(results)
            % MODEL: Parse axis tick values from scenario labels (TERMINAL)
            axes = struct();
            n_ord = length(results.scenario.ordinal_labels);
            n_nom = length(results.scenario.nominal_labels);

            axes.gap_values = zeros(1, n_ord);
            for i = 1:n_ord
                label = results.scenario.ordinal_labels{i};
                axes.gap_values(i) = sscanf(label, 'gap=%f');
            end

            axes.round_values = zeros(1, n_nom);
            for i = 1:n_nom
                label = results.scenario.nominal_labels{i};
                axes.round_values(i) = sscanf(label, 'round=%d');
            end

            axes.n_ord = n_ord;
            axes.n_nom = n_nom;
        end

        function modeMatrix = buildModeMatrix(results, axes)
            % MODEL: Extract n_modes for every cell into a matrix (TERMINAL)
            modeMatrix = zeros(axes.n_ord, axes.n_nom);
            for ord_idx = 1:axes.n_ord
                for nom_idx = 1:axes.n_nom
                    nom_field = results.scenario.nominal_fields{nom_idx};
                    cs = results.analysisResults ...
                        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
                    modeMatrix(ord_idx, nom_idx) = cs.mode_detection.n_modes;
                end
            end
        end

        function gridData = packGridData(axes, modeMatrix)
            % MODEL: Combine axes and binary classification (TERMINAL)
            gridData = struct();
            gridData.gap_values = axes.gap_values;
            gridData.round_values = axes.round_values;
            gridData.is_bimodal = modeMatrix >= 2;
        end
    end

    function renderHeatmap(gridData)
        % SUB-CONTROLLER: Create figure and draw heatmap
        fig = createFigure();
        ax = createAxes(fig);
        drawHeatmapImage(ax, gridData);
        formatAxes(ax, gridData);
        addBoundaryContour(ax, gridData);

        function fig = createFigure()
            % VIEW: Create figure window (TERMINAL)
            fig = figure('Name', 'Bimodality Boundary Heatmap', ...
                'Position', [100, 100, 700, 600], ...
                'Color', 'w', 'NumberTitle', 'off');
        end

        function ax = createAxes(fig)
            % VIEW: Create axes (TERMINAL)
            ax = axes(fig, 'Position', [0.12, 0.12, 0.75, 0.78]);
        end

        function drawHeatmapImage(ax, gridData)
            % VIEW: Render the binary heatmap (TERMINAL)
            imagesc(ax, gridData.round_values, gridData.gap_values, ...
                double(gridData.is_bimodal));

            colormap(ax, [0.85, 0.90, 0.95;   % unimodal: light blue-gray
                          0.80, 0.25, 0.25]);  % bimodal:  muted red

            cb = colorbar(ax);
            set(cb, 'Ticks', [0.25, 0.75], 'TickLabels', {'Unimodal', 'Bimodal'});
            ylabel(cb, 'Detected Modes', 'FontSize', 11);
            caxis(ax, [0, 1]);
        end

        function formatAxes(ax, gridData)
            % VIEW: Set axis labels, ticks, direction (TERMINAL)
            set(ax, 'YDir', 'normal', 'FontSize', 10, 'Box', 'on');
            set(ax, 'XTick', gridData.round_values);
            set(ax, 'YTick', gridData.gap_values(1:2:end));
            xlabel(ax, 'Branch Event Round', 'FontSize', 12);
            ylabel(ax, '\Delta\phi (branch gap)', 'FontSize', 12);
            title(ax, sprintf(['Bimodality Boundary: \\phi_{baseline} = 0.75, ' ...
                'p_{branch} = 0.40, per-colony\n%d cells tested'], ...
                numel(gridData.is_bimodal)), 'FontSize', 13);
        end

        function addBoundaryContour(ax, gridData)
            % VIEW: Overlay contour line at the unimodal/bimodal boundary (TERMINAL)
            hold(ax, 'on');
            contour(ax, gridData.round_values, gridData.gap_values, ...
                double(gridData.is_bimodal), [0.5, 0.5], ...
                'LineColor', 'k', 'LineWidth', 2);
            hold(ax, 'off');
        end
    end
end