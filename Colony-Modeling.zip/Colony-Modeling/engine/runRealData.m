function results = runRealData(scenario)
% CONTROLLER: Run the analysis pipeline on real experimental data.
%
% Mirrors runScenario's structure: takes a scenario, runs the same
% grid-walking pipeline. The only difference is that the data
% provider reads from scenario.real_data_source (an AllMeasures
% struct) instead of calling simulateColonySet.
%
% After analysis, populates each cell's trajectory plot with a flat
% p_traj at the library-fitted phi and eps_traj at the library-fitted
% epsilon. This visualizes the library's interpretation of the data
% alongside the real distribution.
%
% Reuses base-level functions from the simulation runner:
% seedRNGIfRequested, initializeResultsObject, walkScenarioGrid,
% processSingleGridCell, pullCellConfig, analyzeColonySet,
% stowGridCellResults, printGridCellStatus, finalizeResultsMetadata.

AllMeasures = scenario.real_data_source;
seedRNGIfRequested(scenario);
results = initializeResultsObject(scenario);
dataProvider = @(cellConfig, ord_idx, nom_idx) ...
    lookupRadiiFromAllMeasures(AllMeasures, scenario, ord_idx, nom_idx);
results = walkScenarioGrid(scenario, results, dataProvider);
results = populateLibraryTrajectories(results);
results = finalizeResultsMetadata(results);

function simData = lookupRadiiFromAllMeasures(AllMeasures, scenario, ord_idx, nom_idx)
    % MODEL: Pull radii from AllMeasures, wrap in simData shape (TERMINAL)
    nom_field = scenario.nominal_fields{nom_idx};
    nom_data = AllMeasures.(nom_field);
    radii = [];
    if ord_idx <= length(nom_data)
        entry = nom_data(ord_idx);
        if isfield(entry, 'Measurements') && ...
                isstruct(entry.Measurements) && ...
                isfield(entry.Measurements, 'Radius')
            radii = entry.Measurements.Radius;
        end
    end
    simData = struct();
    simData.radii = radii(:);
    simData.tracking = struct();
end

function results = populateLibraryTrajectories(results)
    % SUB-CONTROLLER: Walk the grid and write a flat phi/eps pool
    % into each cell's scenario.config when a library fit exists.

    n_ord = length(results.scenario.ordinal_labels);
    n_nom = length(results.scenario.nominal_labels);
    for ord_idx = 1:n_ord
        for nom_idx = 1:n_nom
            results = populateOneTrajectory(results, ord_idx, nom_idx);
        end
    end

    function results = populateOneTrajectory(results, ord_idx, nom_idx)
        % SUB-CONTROLLER: Inject a flat pool for one cell if library fit exists
        nom_field = results.scenario.nominal_fields{nom_idx};
        colonySet = results.analysisResults ...
            .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
        libFit = extractLibraryFit(colonySet);
        if ~libFit.valid, return; end
        v = results.scenario.config(ord_idx).(nom_field).universal.v;
        pool = buildLibraryPool(libFit, v);
        results.scenario.config(ord_idx).(nom_field).pools = pool;
    end

    function libFit = extractLibraryFit(colonySet)
        % MODEL: Pull library phi and eps from colonySet (TERMINAL)
        libFit = struct('valid', false, 'phi', NaN, 'eps', NaN);
        if ~isfield(colonySet, 'gmm_results'), return; end
        if ~isfield(colonySet.gmm_results, 'fitted_model'), return; end
        fm = colonySet.gmm_results.fitted_model;
        if ~isfield(fm, 'library_blobs'), return; end
        blobs = fm.library_blobs;
        if isempty(blobs), return; end
        if ~isfield(blobs, 'centroids_phi') || isempty(blobs.centroids_phi), return; end
        if ~isfield(blobs, 'centroids_eps') || isempty(blobs.centroids_eps), return; end
        if isfield(blobs, 'total_weights') && ~isempty(blobs.total_weights)
            [~, dom] = max(blobs.total_weights);
        else
            dom = 1;
        end
        libFit.phi = blobs.centroids_phi(dom);
        libFit.eps = blobs.centroids_eps(dom);
        libFit.valid = isfinite(libFit.phi) && isfinite(libFit.eps);
    end

    function pool = buildLibraryPool(libFit, v)
        % MODEL: Construct a single flat-trajectory pool struct (TERMINAL)
        pool = struct();
        pool.initial_S = 1;
        pool.p_traj = repmat(libFit.phi, 1, v);
        pool.eps_traj = repmat(libFit.eps, 1, v);
        pool.phase_boundaries = [];
        pool.color = [0.20, 0.40, 0.70];
        pool.label = sprintf('Library: \\phi=%.2f \\epsilon=%.2f', ...
            libFit.phi, libFit.eps);
    end
end
end
