function colonySet = fitMixtureModel(colonySet, options)
    % SUB-CONTROLLER: Dispatch to library or GMM/LMM fitting
    if isfield(options, 'mixture_distribution') && ...
            strcmp(options.mixture_distribution, 'Library')
        colonySet = fitLibraryMixture(colonySet, options);
    else
        colonySet = determineOptimalComponentCount(colonySet, options);
        colonySet = executeMixtureFitting(colonySet, options);
    end

    % === GMM/LMM PATH ===

    function colonySet = determineOptimalComponentCount(colonySet, options)
        % SUB-CONTROLLER: Consensus sweeps for optimal k
        data = colonySet.raw_measurements;
        max_k = options.max_components;
        dist_type = options.mixture_distribution;
        N_CONSENSUS_ITERATIONS = 5;
        N_REPLICATES = 5;
        REGULARIZATION = 1e-3;

        if length(data) < 10
            colonySet = installInsufficientDataState(colonySet, max_k);
            return;
        end

        consensus = runConsensusSweeps(data, max_k, dist_type, ...
            N_CONSENSUS_ITERATIONS, N_REPLICATES, REGULARIZATION);
        colonySet = installConsensusResults(colonySet, consensus, max_k);

        function colonySet = installInsufficientDataState(colonySet, max_k)
            % MODEL: Fallback for insufficient data (TERMINAL)
            colonySet.gmm_results.optimal_components = 1;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', NaN(1, max_k), 'bic_scores', NaN(1, max_k), ...
                'component_counts_tested', 1:max_k, ...
                'k_distribution', zeros(1, max_k), ...
                'consensus_k_votes', 0, 'consensus_iterations', 0);
            colonySet.gmm_results.consensus_winning_fit = [];
        end

        function consensus = runConsensusSweeps(data, max_k, dist_type, n_iter, n_rep, reg)
            % MODEL: Run n_iter independent BIC sweeps (TERMINAL)
            consensus = struct();
            consensus.k_votes = zeros(1, max_k);
            consensus.aic_per_k_sum = zeros(1, max_k);
            consensus.bic_per_k_sum = zeros(1, max_k);
            consensus.aic_per_k_count = zeros(1, max_k);
            consensus.bic_per_k_count = zeros(1, max_k);
            consensus.best_fit_per_k = cell(1, max_k);
            consensus.best_bic_per_k = inf(1, max_k);

            if strcmp(dist_type, 'LogNormal')
                pos = data(data > 0);
                fit_data = log(pos);
            else
                fit_data = data;
            end
            opts = statset('MaxIter', 1000, 'TolFun', 1e-6);

            for iter = 1:n_iter
                iter_best_bic = Inf;
                iter_best_k = 1;
                for k = 1:max_k
                    try
                        gm = fitgmdist(fit_data, k, 'Options', opts, ...
                            'Replicates', n_rep, 'RegularizationValue', reg);
                        consensus.aic_per_k_sum(k) = consensus.aic_per_k_sum(k) + gm.AIC;
                        consensus.bic_per_k_sum(k) = consensus.bic_per_k_sum(k) + gm.BIC;
                        consensus.aic_per_k_count(k) = consensus.aic_per_k_count(k) + 1;
                        consensus.bic_per_k_count(k) = consensus.bic_per_k_count(k) + 1;
                        if gm.BIC < consensus.best_bic_per_k(k)
                            consensus.best_bic_per_k(k) = gm.BIC;
                            consensus.best_fit_per_k{k} = gm;
                        end
                        if gm.BIC < iter_best_bic
                            iter_best_bic = gm.BIC;
                            iter_best_k = k;
                        end
                    catch
                    end
                end
                if isfinite(iter_best_bic)
                    consensus.k_votes(iter_best_k) = consensus.k_votes(iter_best_k) + 1;
                end
            end

            consensus.aic_scores = nan(1, max_k);
            consensus.bic_scores = nan(1, max_k);
            for k = 1:max_k
                if consensus.aic_per_k_count(k) > 0
                    consensus.aic_scores(k) = consensus.aic_per_k_sum(k) / consensus.aic_per_k_count(k);
                end
                if consensus.bic_per_k_count(k) > 0
                    consensus.bic_scores(k) = consensus.bic_per_k_sum(k) / consensus.bic_per_k_count(k);
                end
            end

            [max_votes, modal_k] = max(consensus.k_votes);
            if max_votes == 0
                consensus.modal_k = 1;
                consensus.modal_k_votes = 0;
                consensus.winning_fit = [];
            else
                consensus.modal_k = modal_k;
                consensus.modal_k_votes = max_votes;
                consensus.winning_fit = consensus.best_fit_per_k{modal_k};
            end
            consensus.n_iterations = n_iter;
        end

        function colonySet = installConsensusResults(colonySet, consensus, max_k)
            % MODEL: Pack consensus results (TERMINAL)
            colonySet.gmm_results.optimal_components = consensus.modal_k;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', consensus.aic_scores, ...
                'bic_scores', consensus.bic_scores, ...
                'component_counts_tested', 1:max_k, ...
                'k_distribution', consensus.k_votes, ...
                'consensus_k_votes', consensus.modal_k_votes, ...
                'consensus_iterations', consensus.n_iterations);
            colonySet.gmm_results.consensus_winning_fit = consensus.winning_fit;
        end
    end

    function colonySet = executeMixtureFitting(colonySet, options)
        % SUB-CONTROLLER: Use consensus winning fit, compute deltas
        if length(colonySet.raw_measurements) < 10
            colonySet = installFallbackFit(colonySet);
            return;
        end
        winning_gm = colonySet.gmm_results.consensus_winning_fit;
        if isempty(winning_gm)
            colonySet = installFallbackFit(colonySet);
            return;
        end

        fit = unpackWinningFit(colonySet, winning_gm, options);
        deltas = computeGMMDeltaMetrics(colonySet);
        colonySet = installFitAndDeltas(colonySet, fit, deltas);

        function fit = unpackWinningFit(colonySet, gm, options)
            % MODEL: Extract parameters from consensus winning fit (TERMINAL)
            data = colonySet.raw_measurements;
            dist_type = options.mixture_distribution;
            k = gm.NumComponents;
            fit = struct();
            try
                if strcmp(dist_type, 'LogNormal')
                    fit_data = log(data(data > 0));
                else
                    fit_data = data;
                end
                [post_probs, ~] = posterior(gm, fit_data);
                [~, hard_assign] = max(post_probs, [], 2);
                sigma_values = zeros(1, k);
                for i = 1:k
                    sigma_values(i) = sqrt(gm.Sigma(:, :, i));
                end
                if strcmp(dist_type, 'LogNormal')
                    mu_values = exp(gm.mu(:)');
                else
                    mu_values = gm.mu(:)';
                end
                fit.success = true;
                fit.gmm = gm;
                fit.GMM_mu = mu_values;
                fit.GMM_sigma = sigma_values;
                fit.GMM_weights = gm.ComponentProportion;
                fit.posterior_probabilities = post_probs;
                fit.hard_assignments = hard_assign;
                fit.log_likelihood = -gm.NegativeLogLikelihood;
                fit.final_aic = gm.AIC;
                fit.final_bic = gm.BIC;
                fit.convergence_flag = gm.Converged;
            catch
                fit.success = false;
                fit.gmm = [];
                fit.GMM_mu = mean(data);
                fit.GMM_sigma = std(data);
                fit.GMM_weights = 1.0;
                fit.posterior_probabilities = ones(length(data), 1);
                fit.hard_assignments = ones(length(data), 1);
                fit.log_likelihood = NaN;
                fit.final_aic = NaN;
                fit.final_bic = NaN;
                fit.convergence_flag = false;
            end
        end

        function deltas = computeGMMDeltaMetrics(colonySet)
            % MODEL: Compute delta AIC/BIC (TERMINAL)
            ms = colonySet.gmm_results.model_selection_criteria;
            deltas = struct();
            valid_aic = ms.aic_scores(isfinite(ms.aic_scores));
            if length(valid_aic) >= 2
                s = sort(valid_aic);
                deltas.delta_aic_subpop = s(2) - s(1);
            else
                deltas.delta_aic_subpop = NaN;
            end
            valid_bic = ms.bic_scores(isfinite(ms.bic_scores));
            if length(valid_bic) >= 2
                s = sort(valid_bic);
                deltas.delta_bic_subpop = s(2) - s(1);
            else
                deltas.delta_bic_subpop = NaN;
            end
        end

        function colonySet = installFitAndDeltas(colonySet, fit, deltas)
            % MODEL: Pack fitted_model and assignments (TERMINAL)
            fitted_model = struct();
            fitted_model.convergence_flag = fit.convergence_flag;
            fitted_model.log_likelihood = fit.log_likelihood;
            fitted_model.final_aic = fit.final_aic;
            fitted_model.final_bic = fit.final_bic;
            fitted_model.GMM_mu = fit.GMM_mu;
            fitted_model.GMM_sigma = fit.GMM_sigma;
            fitted_model.GMM_weights = fit.GMM_weights;
            fitted_model.delta_aic_subpop = deltas.delta_aic_subpop;
            fitted_model.delta_bic_subpop = deltas.delta_bic_subpop;

            component_assignments = struct();
            component_assignments.hard_assignments = fit.hard_assignments;
            component_assignments.posterior_probabilities = fit.posterior_probabilities;

            colonySet.gmm_results.fitted_model = fitted_model;
            colonySet.gmm_results.component_assignments = component_assignments;
        end

        function colonySet = installFallbackFit(colonySet)
            % MODEL: Minimal fitted_model for insufficient data (TERMINAL)
            data = colonySet.raw_measurements;
            fitted_model = struct();
            fitted_model.convergence_flag = false;
            fitted_model.log_likelihood = NaN;
            fitted_model.final_aic = NaN;
            fitted_model.final_bic = NaN;
            if isempty(data)
                fitted_model.GMM_mu = NaN;
                fitted_model.GMM_sigma = NaN;
            else
                fitted_model.GMM_mu = mean(data);
                fitted_model.GMM_sigma = std(data);
            end
            fitted_model.GMM_weights = 1.0;
            fitted_model.delta_aic_subpop = NaN;
            fitted_model.delta_bic_subpop = NaN;
            n = length(data);
            component_assignments = struct();
            component_assignments.hard_assignments = ones(n, 1);
            component_assignments.posterior_probabilities = ones(n, 1);
            colonySet.gmm_results.fitted_model = fitted_model;
            colonySet.gmm_results.component_assignments = component_assignments;
        end
    end

    % === LIBRARY PATH ===

    function colonySet = fitLibraryMixture(colonySet, options)
        % SUB-CONTROLLER: Library-based fitting via best-entry EMD selection
        if length(colonySet.raw_measurements) < 10
            colonySet = installLibraryFallback(colonySet);
            return;
        end

        library = options.library;
        context = buildFitContext(colonySet, library);
        bestEntry = findBestEntryByEMD(context, library);

        if ~bestEntry.success
            colonySet = installLibraryFallback(colonySet);
            return;
        end

        blobs = buildSingleBlobFromEntry(bestEntry);
        assignments = assignAllColoniesToSingleBlob(context);
        fitQuality = computeLibraryFitQuality(context, bestEntry, library);
        adequacy = packAdequacyFromBestEntry(bestEntry, context);
        colonySet = installLibraryFit(colonySet, blobs, assignments, fitQuality, adequacy);

        function context = buildFitContext(colonySet, library)
            % SUB-CONTROLLER: Normalize data, build empirical CDF
            normalized = normalizeObservedRadii(colonySet.raw_measurements, library.ceiling_radius);
            emp_cdf = buildEmpiricalCDF(normalized, library.x_grid);
            data_median_um = computeDataMedian(colonySet.raw_measurements);
            context = packFitContext(colonySet.raw_measurements, normalized, emp_cdf, data_median_um, library.x_grid, library.ceiling_radius);

            function normalized = normalizeObservedRadii(radii, ceiling_radius)
                % MODEL: Normalize radii to [0,1] (TERMINAL)
                normalized = radii(:) / ceiling_radius;
                normalized = min(normalized, 1);
                normalized = max(normalized, 0);
            end

            function emp_cdf = buildEmpiricalCDF(normalized, x_grid)
                % MODEL: Empirical CDF on x_grid (TERMINAL)
                n = length(normalized);
                emp_cdf = sum(normalized(:) <= x_grid(:)', 1) / n;
                emp_cdf = emp_cdf(:);
            end

            function data_median_um = computeDataMedian(raw_measurements)
                % MODEL: Median of raw radii (TERMINAL)
                pos = raw_measurements(raw_measurements > 0);
                if isempty(pos), data_median_um = NaN; else, data_median_um = median(pos); end
            end

            function context = packFitContext(raw, normalized, emp_cdf, data_median_um, x_grid, ceiling_radius)
                % MODEL: Pack fit context (TERMINAL)
                context = struct();
                context.raw_measurements = raw;
                context.normalized = normalized;
                context.emp_cdf = emp_cdf;
                context.data_median_um = data_median_um;
                context.x_grid = x_grid;
                context.ceiling_radius = ceiling_radius;
            end
        end

        function bestEntry = findBestEntryByEMD(context, library)
            % SUB-CONTROLLER: Compute EMD against every entry, pick minimum
            emd_values = computeAllEntryEMDs(context, library);
            bestEntry = pickMinimumEMDEntry(emd_values, library);

            function emd_values = computeAllEntryEMDs(context, library)
                % MODEL: EMD between empirical CDF and each entry (TERMINAL)
                n_entries = length(library.entries);
                emd_values = inf(1, n_entries);
                x_grid = context.x_grid;
                emp_cdf = context.emp_cdf;
                ceiling = context.ceiling_radius;
                for i = 1:n_entries
                    if ~library.entries(i).valid, continue; end
                    kde_y = library.entries(i).kde_y(:);
                    model_cdf = cumtrapz(x_grid, kde_y);
                    if model_cdf(end) > 0, model_cdf = model_cdf / model_cdf(end); end
                    emd_normalized = trapz(x_grid, abs(emp_cdf - model_cdf(:)));
                    emd_values(i) = emd_normalized * ceiling;
                end
            end

            function bestEntry = pickMinimumEMDEntry(emd_values, library)
                % MODEL: Find min-EMD entry (TERMINAL)
                [best_emd, best_idx] = min(emd_values);
                bestEntry = struct();
                bestEntry.success = isfinite(best_emd);
                bestEntry.entry_index = best_idx;
                bestEntry.emd = best_emd;
                if ~bestEntry.success
                    bestEntry.phi = NaN; bestEntry.eps = NaN;
                    bestEntry.phi_index = NaN; bestEntry.eps_index = NaN;
                    bestEntry.null_p95 = NaN; bestEntry.entry_peak_um = NaN;
                    return;
                end
                n_eps = length(library.config.eps_values);
                p_idx = floor((best_idx - 1) / n_eps) + 1;
                e_idx = mod(best_idx - 1, n_eps) + 1;
                bestEntry.phi = library.config.phi_values(p_idx);
                bestEntry.eps = library.config.eps_values(e_idx);
                bestEntry.phi_index = p_idx;
                bestEntry.eps_index = e_idx;
                entry = library.entries(best_idx);
                if isfield(entry, 'null_p95'), bestEntry.null_p95 = entry.null_p95;
                else, bestEntry.null_p95 = NaN; end
                if isfield(entry, 'peak_x') && ~isnan(entry.peak_x)
                    bestEntry.entry_peak_um = entry.peak_x * library.ceiling_radius;
                else, bestEntry.entry_peak_um = NaN; end
            end
        end

        function blobs = buildSingleBlobFromEntry(bestEntry)
            % MODEL: Wrap entry as single-blob structure (TERMINAL)
            blobs = struct();
            blobs.n_blobs = 1;
            blobs.centroids_phi = bestEntry.phi;
            blobs.centroids_eps = bestEntry.eps;
            blobs.total_weights = 1.0;
            blobs.basin_phi_indices = {bestEntry.phi_index};
            blobs.basin_winning_phi_idx = bestEntry.phi_index;
            blobs.entry_index = bestEntry.entry_index;
        end

        function assignments = assignAllColoniesToSingleBlob(context)
            % MODEL: Assign all colonies to blob (TERMINAL)
            n = length(context.normalized);
            assignments = struct();
            assignments.hard = ones(n, 1);
            assignments.posterior = ones(n, 1);
        end

        function fitQuality = computeLibraryFitQuality(context, bestEntry, library)
            % SUB-CONTROLLER: Log-likelihood under winning entry
            bin_indices = findColonyBinIndices(context.normalized, context.x_grid);
            fitQuality = evaluateLogLikelihood(bin_indices, bestEntry, context, library);

            function bin_indices = findColonyBinIndices(normalized, x_grid)
                % MODEL: Find nearest bin for each colony (TERMINAL)
                dx = x_grid(2) - x_grid(1);
                bin_indices = round((normalized - x_grid(1)) / dx) + 1;
                bin_indices = max(1, min(length(x_grid), bin_indices));
            end

            function fitQuality = evaluateLogLikelihood(bin_indices, bestEntry, context, library)
                % MODEL: Log-likelihood from KDE (TERMINAL)
                entry = library.entries(bestEntry.entry_index);
                kde_y = entry.kde_y(:);
                area = trapz(context.x_grid, kde_y);
                if area > 0, kde_y = kde_y / area; end
                n = length(context.normalized);
                densities = kde_y(bin_indices);
                densities = max(densities, 1e-300);
                log_lik = sum(log(densities)) - n * log(library.ceiling_radius);
                fitQuality = struct();
                fitQuality.log_likelihood = log_lik;
                fitQuality.n_colonies = n;
            end
        end

        function adequacy = packAdequacyFromBestEntry(bestEntry, context)
            % MODEL: Domain check and EMD adequacy test with quality scores (TERMINAL)
            DOMAIN_TOLERANCE = 2.0;
            GRID_SNAP_TOLERANCE = 8.0;

            adequacy = struct();
            adequacy.emd = bestEntry.emd;
            adequacy.cutoff = bestEntry.null_p95 * GRID_SNAP_TOLERANCE;
            adequacy.domain_ratio = computeDomainRatio(context.data_median_um, bestEntry.entry_peak_um);
            adequacy.domain_tolerance = DOMAIN_TOLERANCE;

            domain_ok = isfinite(adequacy.domain_ratio) && adequacy.domain_ratio <= DOMAIN_TOLERANCE;
            emd_ok = ~isnan(adequacy.cutoff) && ~isnan(adequacy.emd) && adequacy.emd <= adequacy.cutoff;
            adequacy.passed = domain_ok && emd_ok;
            adequacy.domain_passed = domain_ok;
            adequacy.emd_passed = emd_ok;

            if isfinite(adequacy.cutoff) && adequacy.cutoff > 0 && isfinite(adequacy.emd)
                adequacy.quality_shape = adequacy.emd / adequacy.cutoff;
            else
                adequacy.quality_shape = NaN;
            end
            if isfinite(adequacy.domain_ratio) && adequacy.domain_tolerance > 0
                adequacy.quality_scale = adequacy.domain_ratio / adequacy.domain_tolerance;
            else
                adequacy.quality_scale = NaN;
            end

            function ratio = computeDomainRatio(data_median_um, entry_peak_um)
                % MODEL: Symmetric ratio (TERMINAL)
                if isnan(data_median_um) || isnan(entry_peak_um) || ...
                        data_median_um <= 0 || entry_peak_um <= 0
                    ratio = NaN; return;
                end
                ratio = max(data_median_um / entry_peak_um, entry_peak_um / data_median_um);
            end
        end

        function colonySet = installLibraryFit(colonySet, blobs, assignments, fitQuality, adequacy)
            % SUB-CONTROLLER: Pack library fit into gmm_results
            colonySet.gmm_results.optimal_components = blobs.n_blobs;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', NaN, 'bic_scores', NaN, 'component_counts_tested', NaN);

            fitted_model = buildFittedModelStruct(colonySet.raw_measurements, assignments, blobs, fitQuality, adequacy);
            fitted_model.library_blobs = buildLibraryBlobsInfo(blobs);
            colonySet.gmm_results.fitted_model = fitted_model;
            colonySet.gmm_results.component_assignments = buildCompAssignStruct(assignments);

            function fm = buildFittedModelStruct(raw_measurements, assignments, blobs, fitQuality, adequacy)
                % MODEL: Build lognormal-equivalent stats with AIC and adequacy (TERMINAL)
                k = blobs.n_blobs;
                GMM_mu = zeros(1, k); GMM_sigma = zeros(1, k);
                for i = 1:k
                    mask = (assignments.hard == i);
                    blob_radii = raw_measurements(mask);
                    pos_radii = blob_radii(blob_radii > 0);
                    if length(pos_radii) >= 2
                        log_r = log(pos_radii);
                        GMM_mu(i) = exp(mean(log_r));
                        GMM_sigma(i) = std(log_r);
                    elseif ~isempty(blob_radii)
                        GMM_mu(i) = mean(blob_radii); GMM_sigma(i) = 0.1;
                    else
                        GMM_mu(i) = NaN; GMM_sigma(i) = NaN;
                    end
                end
                k_params = max(3 * k - 1, 1);
                log_lik = fitQuality.log_likelihood;
                n = fitQuality.n_colonies;
                aic = 2 * k_params - 2 * log_lik;
                bic = k_params * log(n) - 2 * log_lik;

                fm = struct();
                fm.convergence_flag = true;
                fm.log_likelihood = log_lik;
                fm.final_aic = aic; fm.final_bic = bic;
                fm.GMM_mu = GMM_mu; fm.GMM_sigma = GMM_sigma;
                fm.GMM_weights = blobs.total_weights;
                fm.delta_aic_subpop = NaN; fm.delta_bic_subpop = NaN;
                fm.library_adequacy_emd = adequacy.emd;
                fm.library_adequacy_cutoff = adequacy.cutoff;
                fm.library_adequacy_passed = adequacy.passed;
                fm.library_domain_ratio = adequacy.domain_ratio;
                fm.library_domain_tolerance = adequacy.domain_tolerance;
                fm.library_domain_passed = adequacy.domain_passed;
                fm.library_emd_passed = adequacy.emd_passed;
                fm.library_quality_shape = adequacy.quality_shape;
                fm.library_quality_scale = adequacy.quality_scale;
            end

            function libInfo = buildLibraryBlobsInfo(blobs)
                % MODEL: Pack library blob metadata (TERMINAL)
                libInfo = struct();
                libInfo.n_blobs = blobs.n_blobs;
                libInfo.centroids_phi = blobs.centroids_phi;
                libInfo.centroids_eps = blobs.centroids_eps;
                libInfo.total_weights = blobs.total_weights;
                libInfo.basin_phi_indices = blobs.basin_phi_indices;
                libInfo.basin_winning_phi_idx = blobs.basin_winning_phi_idx;
            end

            function ca = buildCompAssignStruct(assignments)
                % MODEL: Build component_assignments (TERMINAL)
                ca = struct();
                ca.hard_assignments = assignments.hard(:);
                ca.posterior_probabilities = assignments.posterior;
            end
        end

        function colonySet = installLibraryFallback(colonySet)
            % MODEL: Minimal library fit for degenerate cases (TERMINAL)
            data = colonySet.raw_measurements;
            colonySet.gmm_results.optimal_components = 1;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', NaN, 'bic_scores', NaN, 'component_counts_tested', NaN);
            fm = struct();
            fm.convergence_flag = false;
            fm.log_likelihood = NaN; fm.final_aic = NaN; fm.final_bic = NaN;
            if isempty(data)
                fm.GMM_mu = NaN; fm.GMM_sigma = NaN;
            else
                pos = data(data > 0);
                if length(pos) >= 2
                    fm.GMM_mu = exp(mean(log(pos))); fm.GMM_sigma = std(log(pos));
                else
                    fm.GMM_mu = mean(data); fm.GMM_sigma = 0;
                end
            end
            fm.GMM_weights = 1.0;
            fm.delta_aic_subpop = NaN; fm.delta_bic_subpop = NaN;
            fm.library_adequacy_emd = NaN; fm.library_adequacy_cutoff = NaN;
            fm.library_adequacy_passed = false;
            fm.library_domain_ratio = NaN; fm.library_domain_tolerance = NaN;
            fm.library_domain_passed = false; fm.library_emd_passed = false;
            fm.library_quality_shape = NaN; fm.library_quality_scale = NaN;
            fm.library_blobs = struct('n_blobs', 0, 'centroids_phi', [], ...
                'centroids_eps', [], 'total_weights', [], ...
                'basin_phi_indices', {{}}, 'basin_winning_phi_idx', []);
            n = length(data);
            ca = struct();
            ca.hard_assignments = ones(n, 1);
            ca.posterior_probabilities = ones(n, 1);
            colonySet.gmm_results.fitted_model = fm;
            colonySet.gmm_results.component_assignments = ca;
        end
    end
end
