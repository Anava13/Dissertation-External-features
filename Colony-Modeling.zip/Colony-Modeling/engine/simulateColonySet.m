function simData = simulateColonySet(cellConfig)
    % CONTROLLER: Simulate all colonies under the unified pool/branch system.
    % Returns simData.radii (post-detection) and simData.tracking
    % (per-pool and per-event matrices, filtered to detectable colonies).

    rawData = simulateAllColonies(cellConfig);
    simData = applyDetection(rawData, cellConfig.universal);

    function rawData = simulateAllColonies(cellConfig)
        % SUB-CONTROLLER: Loop over all colonies, store raw tracking

        universal = cellConfig.universal;
        pools = cellConfig.pools;
        branch_events = cellConfig.branch_events;
        n = universal.n_colonies;
        n_pools = length(pools);
        n_events = length(branch_events);

        rawData = preallocateTracking(n, n_pools, n_events);

        for c = 1:n
            colonyResult = simulateOneColony(pools, branch_events, universal);
            rawData = appendColonyResult(rawData, colonyResult, c);
        end

        function rawData = preallocateTracking(n, n_pools, n_events)
            % MODEL: Allocate all tracking matrices (TERMINAL)
            rawData = struct();
            rawData.radii                    = zeros(n, 1);
            rawData.pool_S_final             = zeros(n, n_pools);
            rawData.pool_A_final             = zeros(n, n_pools);
            rawData.pool_cells_final         = zeros(n, n_pools);
            rawData.pool_first_populated_round = nan(n, n_pools);
            rawData.pool_S_zero_round        = nan(n, n_pools);
            if n_events > 0
                rawData.event_triggered          = false(n, n_events);
                rawData.event_first_trigger_round = nan(n, n_events);
                rawData.event_total_transferred  = zeros(n, n_events);
            else
                rawData.event_triggered          = false(n, 0);
                rawData.event_first_trigger_round = nan(n, 0);
                rawData.event_total_transferred  = zeros(n, 0);
            end
        end

        function colonyResult = simulateOneColony(pools, branch_events, universal)
            % MODEL: Single colony, multi-pool, with branch events (TERMINAL)
            n_pools = length(pools);
            n_events = length(branch_events);
            v = universal.v;

            % Initialize per-pool state
            S = zeros(1, n_pools);
            A = zeros(1, n_pools);
            for i = 1:n_pools
                S(i) = pools(i).initial_S;
            end

            % Per-pool tracking
            pool_first_populated = nan(1, n_pools);
            pool_S_zero = nan(1, n_pools);
            for i = 1:n_pools
                if S(i) > 0
                    pool_first_populated(i) = 1;
                end
            end

            % Per-event tracking
            evt_triggered = false(1, max(n_events, 1));
            evt_first_round = nan(1, max(n_events, 1));
            evt_total_xfer = zeros(1, max(n_events, 1));

            for r = 1:v

                % === DIVIDE ALL POOLS ===
                for i = 1:n_pools
                    if S(i) > 0
                        p_eff = drawEffectiveP( ...
                            pools(i).p_traj(r), pools(i).eps_traj(r), ...
                            universal.min_kappa);
                        [succ, fail] = divideOnce(S(i), p_eff, universal.approx_threshold);
                        S(i) = 2 * succ;
                        A(i) = A(i) + fail;
                    end
                end

                % === PROCESS BRANCH EVENTS ===
                for e = 1:n_events
                    ev = branch_events(e);

                    % Check eligibility window
                    if r < ev.eligible_rounds(1) || r > ev.eligible_rounds(end)
                        continue;
                    end

                    % Determine source count
                    if strcmp(ev.source_compartment, 'dividing')
                        src_count = S(ev.source_pool);
                    else
                        src_count = A(ev.source_pool);
                    end

                    if src_count <= 0
                        continue;
                    end

                    % Determine transfer count
                    xfer = 0;
                    if strcmp(ev.mode, 'per_cell')
                        xfer = binornd(src_count, ev.probability);
                    else  % per_colony
                        if ~evt_triggered(e)
                            if rand() < ev.probability
                                xfer = 1;
                            end
                        end
                    end

                    if xfer > 0
                        % Move cells from source to target dividing compartment
                        if strcmp(ev.source_compartment, 'dividing')
                            S(ev.source_pool) = S(ev.source_pool) - xfer;
                        else
                            A(ev.source_pool) = A(ev.source_pool) - xfer;
                        end
                        S(ev.target_pool) = S(ev.target_pool) + xfer;

                        % Update event tracking
                        if ~evt_triggered(e)
                            evt_triggered(e) = true;
                            evt_first_round(e) = r;
                        end
                        evt_total_xfer(e) = evt_total_xfer(e) + xfer;

                        % Update pool population tracking
                        if isnan(pool_first_populated(ev.target_pool))
                            pool_first_populated(ev.target_pool) = r;
                        end
                    end
                end

                % === TRACK S HITTING ZERO (after branch events) ===
                for i = 1:n_pools
                    if S(i) == 0 && ~isnan(pool_first_populated(i)) && isnan(pool_S_zero(i))
                        pool_S_zero(i) = r;
                    end
                end
            end

            % Pack result
            total_cells = sum(S) + sum(A);
            colonyResult = struct();
            colonyResult.S = S;
            colonyResult.A = A;
            colonyResult.pool_cells = S + A;
            colonyResult.total_cells = total_cells;
            colonyResult.pool_first_populated = pool_first_populated;
            colonyResult.pool_S_zero = pool_S_zero;
            colonyResult.event_triggered = evt_triggered(1:n_events);
            colonyResult.event_first_round = evt_first_round(1:n_events);
            colonyResult.event_total_transferred = evt_total_xfer(1:n_events);
            colonyResult.radius = cellsToRadius(total_cells, universal.packing_density);
        end

        function rawData = appendColonyResult(rawData, cr, c)
            % MODEL: Append one colony's result into tracking arrays (TERMINAL)
            rawData.radii(c) = cr.radius;
            rawData.pool_S_final(c, :) = cr.S;
            rawData.pool_A_final(c, :) = cr.A;
            rawData.pool_cells_final(c, :) = cr.pool_cells;
            rawData.pool_first_populated_round(c, :) = cr.pool_first_populated;
            rawData.pool_S_zero_round(c, :) = cr.pool_S_zero;
            n_events = size(rawData.event_triggered, 2);
            if n_events > 0
                rawData.event_triggered(c, :) = cr.event_triggered;
                rawData.event_first_trigger_round(c, :) = cr.event_first_round;
                rawData.event_total_transferred(c, :) = cr.event_total_transferred;
            end
        end
    end

    function simData = applyDetection(rawData, universal)
        % SUB-CONTROLLER: Apply detection limit, filter all tracking arrays

        mask = rawData.radii >= universal.detection_limit;
        simData = packageSimData(rawData, mask);

        function simData = packageSimData(rawData, mask)
            % MODEL: Pack into simData with filtered tracking (TERMINAL)
            simData = struct();
            simData.radii = rawData.radii(mask);

            tracking = struct();
            tracking.pool_S_final             = rawData.pool_S_final(mask, :);
            tracking.pool_A_final             = rawData.pool_A_final(mask, :);
            tracking.pool_cells_final         = rawData.pool_cells_final(mask, :);
            tracking.pool_first_populated_round = rawData.pool_first_populated_round(mask, :);
            tracking.pool_S_zero_round        = rawData.pool_S_zero_round(mask, :);
            tracking.event_triggered          = rawData.event_triggered(mask, :);
            tracking.event_first_trigger_round = rawData.event_first_trigger_round(mask, :);
            tracking.event_total_transferred  = rawData.event_total_transferred(mask, :);
            simData.tracking = tracking;
        end
    end
end
