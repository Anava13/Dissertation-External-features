function distribution_tests = runAllDistributionTests(data, options)
    % SUB-CONTROLLER: Run every distribution fit
    distribution_tests = struct();
    distribution_tests.normal = tryNormalDistribution(data);
    distribution_tests.lognormal = tryLogNormalDistribution(data);
    distribution_tests.library = tryLibraryDistribution(data, options);
    distribution_tests.nonparametric = tryNonParametricDistribution(data);
end
