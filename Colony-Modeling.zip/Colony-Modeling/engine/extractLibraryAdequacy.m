function lib = extractLibraryAdequacy(colonySet)
    % MODEL: Pull library adequacy info from selected fit or alternatives (TERMINAL)
    % Used by both the engine logger and post-processing functions.
    lib = struct('present', false, 'emd', NaN, 'cutoff', NaN, ...
                 'passed', false, 'phi', NaN, 'eps', NaN, ...
                 'quality_shape', NaN, 'quality_scale', NaN);

    if isfield(colonySet, 'selected_method') && ...
            strcmp(char(colonySet.selected_method), 'Library')
        fm = colonySet.gmm_results.fitted_model;
        lib = readLibFromFittedModel(fm);
        return;
    end

    if isfield(colonySet, 'alternative_fits')
        altNames = fieldnames(colonySet.alternative_fits);
        for i = 1:length(altNames)
            alt = colonySet.alternative_fits.(altNames{i});
            if isfield(alt, 'method') && strcmp(alt.method, 'Library')
                if isfield(alt, 'gmm_results') && ...
                        isfield(alt.gmm_results, 'fitted_model')
                    lib = readLibFromFittedModel(alt.gmm_results.fitted_model);
                end
                return;
            end
        end
    end

    function lib = readLibFromFittedModel(fm)
        % MODEL: Extract adequacy + dominant blob phi/eps (TERMINAL)
        lib = struct('present', true, 'emd', NaN, 'cutoff', NaN, ...
                     'passed', false, 'phi', NaN, 'eps', NaN, ...
                     'quality_shape', NaN, 'quality_scale', NaN);
        if isfield(fm, 'library_adequacy_emd')
            lib.emd = fm.library_adequacy_emd;
        end
        if isfield(fm, 'library_adequacy_cutoff')
            lib.cutoff = fm.library_adequacy_cutoff;
        end
        if isfield(fm, 'library_adequacy_passed')
            lib.passed = fm.library_adequacy_passed;
        end
        if isfield(fm, 'library_quality_shape')
            lib.quality_shape = fm.library_quality_shape;
        end
        if isfield(fm, 'library_quality_scale')
            lib.quality_scale = fm.library_quality_scale;
        end
        if isfield(fm, 'library_blobs') && ...
                isfield(fm.library_blobs, 'centroids_phi') && ...
                ~isempty(fm.library_blobs.centroids_phi) && ...
                isfield(fm.library_blobs, 'total_weights') && ...
                ~isempty(fm.library_blobs.total_weights)
            [~, dom] = max(fm.library_blobs.total_weights);
            lib.phi = fm.library_blobs.centroids_phi(dom);
            lib.eps = fm.library_blobs.centroids_eps(dom);
        end
    end
end
