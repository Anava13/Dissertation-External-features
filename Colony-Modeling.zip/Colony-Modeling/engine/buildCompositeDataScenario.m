function scenario = buildCompositeDataScenario(composite)
    % CONTROLLER: Construct scenario shell from composite struct
    %
    % Produces a scenario compatible with runRealData. Shape is flat:
    % a single ordinal slot, one nominal slot per composite entry. Each
    % nominal field on real_data_source is the composite entry's
    % Measurements struct, indexed at ord_idx = 1.
    %
    % Nominal field names are index-derived (entry_001, entry_002, ...)
    % so the mapping back to composite is just the index. Display labels
    % carry the original filenames.
    %
    % The original composite is stored on scenario.composite_source for
    % later merge steps that write fit outputs back per entry.

    validateComposite(composite);
    nominalInfo = computeNominalInfoFromComposite(composite);
    n_ord = 1;
    ordinalLabels = {'data'};
    config = buildStubConfigGrid(n_ord, nominalInfo.fields);
    analysis_options = buildDefaultAnalysisOptions();
    AllMeasures = packCompositeAsAllMeasures(composite, nominalInfo.fields);
    scenario = packCompositeScenario(nominalInfo, ordinalLabels, config, ...
        analysis_options, AllMeasures, composite);

    function validateComposite(composite)
        % MODEL: Hard-error on malformed composite input (TERMINAL)
        if ~isstruct(composite) || isempty(composite)
            error('buildCompositeDataScenario:EmptyComposite', ...
                'composite must be a non-empty struct array.');
        end
        if ~isfield(composite, 'Measurements')
            error('buildCompositeDataScenario:MissingMeasurements', ...
                'composite must have a Measurements field.');
        end
        if ~isfield(composite, 'filename')
            error('buildCompositeDataScenario:MissingFilename', ...
                'composite must have a filename field.');
        end
    end

    function info = computeNominalInfoFromComposite(composite)
        % MODEL: Build nominal field names and display labels (TERMINAL)
        n = length(composite);
        info = struct();
        info.fields = arrayfun(@(i) sprintf('entry_%03d', i), 1:n, ...
            'UniformOutput', false);
        info.labels = {composite.filename};
    end

    function config = buildStubConfigGrid(n_ord, nominal_fields)
        % MODEL: Build per-cell stub configs for real data (TERMINAL)
        stubCell = struct();
        stubCell.pools = struct( ...
            'initial_S', {}, ...
            'p_traj', {}, ...
            'eps_traj', {}, ...
            'phase_boundaries', {}, ...
            'color', {}, ...
            'label', {});
        stubCell.branch_events = struct( ...
            'source_pool', {}, ...
            'target_pool', {}, ...
            'eligible_rounds', {});
        stubCell.universal = struct('v', 40);
        stubCell.log_params = struct();

        config = repmat(struct(), 1, n_ord);
        for ord = 1:n_ord
            for nom = 1:length(nominal_fields)
                config(ord).(nominal_fields{nom}) = stubCell;
            end
        end
    end

    function options = buildDefaultAnalysisOptions()
        % MODEL: Default analysis options for real data (TERMINAL)
        options = struct();
        options.max_components = 4;
        options.connection_threshold = 0.5;
        options.connection_cost_bias = 0.5;
        options.normalization = 'log';
        options.rng_seed = [];
    end

    function AllMeasures = packCompositeAsAllMeasures(composite, nominal_fields)
        % MODEL: Reshape composite into AllMeasures-style struct (TERMINAL)
        AllMeasures = struct();
        for i = 1:length(composite)
            field = nominal_fields{i};
            entry = struct('Measurements', composite(i).Measurements);
            AllMeasures.(field) = entry;
        end
    end

    function scenario = packCompositeScenario(nominalInfo, ordinalLabels, config, analysis_options, AllMeasures, composite)
        % MODEL: Pack the composite-data scenario struct (TERMINAL)
        scenario = struct();
        scenario.scenario_name = 'CompositeData';
        scenario.composite_source = composite;
        scenario.nominal_fields = nominalInfo.fields;
        scenario.nominal_labels = nominalInfo.labels;
        scenario.ordinal_labels = ordinalLabels;
        scenario.config = config;
        scenario.analysis_options = analysis_options;
        scenario.is_real_data = true;
        scenario.real_data_source = AllMeasures;
    end
end    
