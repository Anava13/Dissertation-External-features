function renderTrajectoryCell(ax, state, ord_idx, nom_idx)
    % CONTROLLER: Render trajectory using fork-based design language
    %
    % Branch events are drawn as backward sigmoids that diverge from
    % the source pool line, creating a visual fork. The sigmoid extends
    % backward from the branch round, overlapping the upstream pool
    % line, and arrives at the target pool's starting phi exactly at
    % the branch round.

    td = prepareTrajectoryData(state, ord_idx, nom_idx);
    prepareAxes(ax);
    drawAllPoolTrajectories(ax, td);
    drawBranchForks(ax, td);
    finalizeTrajectoryAxes(ax, td);

    % === SUB-CONTROLLERS ===

    function td = prepareTrajectoryData(state, ord_idx, nom_idx)
        % SUB-CONTROLLER: Extract config and compute derived data
        raw = extractCellConfig(state, ord_idx, nom_idx);
        startRounds = computePoolStartRounds(raw.pools, raw.branch_events);
        td = packTrajectoryData(raw, startRounds);

        function raw = extractCellConfig(state, ord_idx, nom_idx)
            % MODEL: Extract pool and branch config from results (TERMINAL)
            nom_field = state.results.scenario.nominal_fields{nom_idx};
            cellConfig = state.results.scenario.config(ord_idx).(nom_field);
            raw = struct();
            raw.pools = cellConfig.pools;
            raw.branch_events = cellConfig.branch_events;
            raw.v = cellConfig.universal.v;
        end

        function sr = computePoolStartRounds(pools, branch_events)
            % MODEL: Determine when each pool first appears (TERMINAL)
            n = length(pools);
            sr = nan(1, n);
            for i = 1:n
                if pools(i).initial_S > 0, sr(i) = 1; end
            end
            for e = 1:length(branch_events)
                tgt = branch_events(e).target_pool;
                er = branch_events(e).eligible_rounds(1);
                if isnan(sr(tgt)) || er < sr(tgt), sr(tgt) = er; end
            end
        end

        function td = packTrajectoryData(raw, startRounds)
            % MODEL: Combine config with computed start rounds (TERMINAL)
            td = struct();
            td.pools = raw.pools;
            td.branch_events = raw.branch_events;
            td.v = raw.v;
            td.start_rounds = startRounds;
        end
    end

    function prepareAxes(ax)
        % VIEW: Clear axes and enable hold (TERMINAL)
        cla(ax);
        hold(ax, 'on');
        set(ax, 'Visible', 'on');
    end

    function drawAllPoolTrajectories(ax, td)
        % SUB-CONTROLLER: Draw each pool's epsilon band and trajectory line
        for i = 1:length(td.pools)
            sr = td.start_rounds(i);
            if isnan(sr), continue; end
            drawSinglePool(ax, td.pools(i), sr, td.v, i);
        end
        drawPhaseBoundaries(ax, td.pools);

        function drawSinglePool(ax, pool, sr, v, poolIndex)
            % SUB-CONTROLLER: Render one pool's band and line
            plotData = computePoolPlotData(pool, sr, v);
            style = computePoolStyle(pool, poolIndex);
            renderEpsilonBand(ax, plotData, style);
            renderPoolLine(ax, plotData, style);

            function plotData = computePoolPlotData(pool, sr, v)
                % MODEL: Compute trajectory coordinates and epsilon band (TERMINAL)
                draw_range = sr:v;
                plotData = struct();
                plotData.x = draw_range;
                plotData.y = pool.p_traj(draw_range);
                eps_vals = pool.eps_traj(draw_range);
                plotData.band_upper = min(1, plotData.y + 2 * eps_vals);
                plotData.band_lower = max(0, plotData.y - 2 * eps_vals);
            end

            function style = computePoolStyle(pool, poolIndex)
                % MODEL: Determine visual properties for a pool (TERMINAL)
                style = struct();
                style.color = pool.color;
                style.bandAlpha = 0.15;
                if poolIndex == 1
                    style.lineWidth = 2.5;
                else
                    style.lineWidth = 2.0;
                end
            end

            function renderEpsilonBand(ax, plotData, style)
                % VIEW: Draw the epsilon shaded band (TERMINAL)
                if isempty(plotData.x), return; end
                if all(plotData.band_upper == plotData.band_lower), return; end
                band_x = [plotData.x, fliplr(plotData.x)];
                band_y = [plotData.band_upper, fliplr(plotData.band_lower)];
                fill(ax, band_x, band_y, style.color, ...
                    'EdgeColor', 'none', 'FaceAlpha', style.bandAlpha, ...
                    'HitTest', 'off', 'PickableParts', 'none');
            end

            function renderPoolLine(ax, plotData, style)
                % VIEW: Draw the pool trajectory line (TERMINAL)
                if isempty(plotData.x), return; end
                h = plot(ax, plotData.x, plotData.y, '-', ...
                    'Color', style.color, 'LineWidth', style.lineWidth);
                uistack(h, 'top');
            end
        end

        function drawPhaseBoundaries(ax, pools)
            % VIEW: Draw phase boundary lines for all pools (TERMINAL)
            for i = 1:length(pools)
                for pb = pools(i).phase_boundaries
                    xline(ax, pb + 0.5, ':', ...
                        'Color', [0.75, 0.75, 0.75], 'LineWidth', 0.6);
                end
            end
        end
    end

    function drawBranchForks(ax, td)
        % SUB-CONTROLLER: Draw backward sigmoid forks at each branch event
        for e = 1:length(td.branch_events)
            drawSingleFork(ax, td.branch_events(e), td.pools);
        end

        function drawSingleFork(ax, ev, pools)
            % SUB-CONTROLLER: Render one backward sigmoid fork arm
            forkConfig = computeForkConfig(ev, pools);
            sigmoidData = computeSigmoidCurve(forkConfig);
            armStyle = computeArmStyle(pools, ev);
            renderSigmoidArm(ax, sigmoidData, armStyle);
            renderEligibleWindow(ax, ev, pools);

            function config = computeForkConfig(ev, pools)
                % MODEL: Compute fork geometry for one branch event (TERMINAL)
                config = struct();
                er = ev.eligible_rounds(1);
                config.branchRound = er;
                config.spread = 2;
                config.startX = max(er - config.spread, 0);
                config.originY = pools(ev.source_pool).p_traj(er);
                config.targetY = pools(ev.target_pool).p_traj(er);
                config.sigmoid_k = 10;
                config.n_points = 50;
            end

            function data = computeSigmoidCurve(config)
                % MODEL: Compute backward sigmoid from startX to branch round (TERMINAL)
                t = linspace(0, 1, config.n_points);
                s = 1 ./ (1 + exp(-config.sigmoid_k * (t - 0.5)));
                s = (s - s(1)) / (s(end) - s(1));
                data = struct();
                data.x = config.startX + t * (config.branchRound - config.startX);
                data.y = config.originY + (config.targetY - config.originY) * s;
            end

            function style = computeArmStyle(pools, ev)
                % MODEL: Determine fork arm visual properties (TERMINAL)
                style = struct();
                style.color = pools(ev.target_pool).color;
                style.lineWidth = 1.5;
            end

            function renderSigmoidArm(ax, data, style)
                % VIEW: Draw one sigmoid fork arm (TERMINAL)
                plot(ax, data.x, data.y, '-', ...
                    'Color', style.color, ...
                    'LineWidth', style.lineWidth, ...
                    'HitTest', 'off', 'PickableParts', 'none');
            end

            function renderEligibleWindow(ax, ev, pools)
                % VIEW: Draw eligible round indicator bar if multi-round (TERMINAL)
                if length(ev.eligible_rounds) <= 1 && ...
                        ev.eligible_rounds(end) <= ev.eligible_rounds(1)
                    return;
                end
                er_start = ev.eligible_rounds(1);
                er_end = ev.eligible_rounds(end);
                tgt_color = pools(ev.target_pool).color;
                patch(ax, ...
                    [er_start, er_end, er_end, er_start], ...
                    [-0.03, -0.03, -0.01, -0.01], ...
                    tgt_color, 'EdgeColor', 'none', 'FaceAlpha', 0.4);
            end
        end
    end

    function finalizeTrajectoryAxes(ax, td)
        % SUB-CONTROLLER: Set axis properties and build legend
        axisConfig = computeAxisConfig(td.v);
        applyAxisFormatting(ax, axisConfig);
        buildPoolLegend(ax, td.pools, td.start_rounds);
        hold(ax, 'off');

        function config = computeAxisConfig(v)
            % MODEL: Determine axis limits and tick values (TERMINAL)
            config = struct();
            config.xLim = [0, v + 1];
            config.yLim = [-0.05, 1.05];
            config.yTicks = [0, 0.25, 0.50, 0.75, 1.0];
        end

        function applyAxisFormatting(ax, config)
            % VIEW: Apply axis limits, labels, and formatting (TERMINAL)
            xlim(ax, config.xLim);
            ylim(ax, config.yLim);
            xlabel(ax, 'Division Round', 'FontSize', 10);
            ylabel(ax, 'p_{success}', 'FontSize', 10);
            set(ax, 'FontSize', 9, 'Box', 'on', 'YTick', config.yTicks);
        end

        function buildPoolLegend(ax, pools, start_rounds)
            % VIEW: Add pool color legend (TERMINAL)
            n_pools = length(pools);
            legend_handles = gobjects(n_pools, 1);
            legend_labels = cell(n_pools, 1);
            for i = 1:n_pools
                if isnan(start_rounds(i)), continue; end
                legend_handles(i) = plot(ax, NaN, NaN, '-', ...
                    'Color', pools(i).color, 'LineWidth', 2);
                legend_labels{i} = pools(i).label;
            end
            valid = ~isnan(start_rounds);
            if sum(valid) > 1
                legend(ax, legend_handles(valid), legend_labels(valid), ...
                    'Location', 'best', 'FontSize', 8, 'Box', 'off');
            end
        end
    end
end
