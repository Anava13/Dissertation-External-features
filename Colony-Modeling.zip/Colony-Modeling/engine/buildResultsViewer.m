function buildResultsViewer(results)
    % CONTROLLER: Build the interactive results viewer

    state = initializeViewerState(results);
    [fig, handles] = createViewerLayout(state);
    state.handles = handles;
    setappdata(fig, 'ViewerState', state);
    renderCurrentView(fig);
    updateNavigationLabels(fig);

    % === SUB-CONTROLLERS ===

    function state = initializeViewerState(results)
        % SUB-CONTROLLER: Build initial state with precomputed global limits
        core = buildCoreState(results);
        globalLimits = computeGlobalLimits(results);  % now shared
        state = packViewerState(core, globalLimits);
        function core = buildCoreState(results)
    % MODEL: Build core navigation state (TERMINAL)
    core = struct();
    core.results = results;
    core.view_mode = 1;
    core.ord_offset = 1;
    core.nom_offset = 1;
    core.n_ord = length(results.scenario.ordinal_labels);
    core.n_nom = length(results.scenario.nominal_labels);
    core.max_rows = min(2, core.n_ord);
    core.max_cols = min(2, core.n_nom);
    core.view_names = {'Trajectory', 'Histogram', 'Mixture Model', 'Composition', 'KDE'};
    core.axis_mode = 'local';

    % Sanitize display labels
    for i = 1:core.n_ord
        core.results.scenario.ordinal_labels{i} = ...
            sanitizeDisplayLabel(results.scenario.ordinal_labels{i});
    end
    for i = 1:core.n_nom
        core.results.scenario.nominal_labels{i} = ...
            sanitizeDisplayLabel(results.scenario.nominal_labels{i});
    end
end
        function state = packViewerState(core, globalLimits)
            % MODEL: Combine core state and global limits (TERMINAL)
            state = core;
            state.global_limits = globalLimits;
        end
    end

    function [fig, handles] = createViewerLayout(state)
        % SUB-CONTROLLER: Create figure, axes grid, navigation controls
        fig = createFigureWindow(state);
        handles = struct();
        handles.axes = createAxesGrid(fig);
        handles = createNavigationControls(fig, handles);
        handles = createGridLabels(fig, handles);

        function fig = createFigureWindow(state)
            % VIEW: Create figure window (TERMINAL)
            fig = figure('Name', sprintf('Results Viewer: %s', ...
                state.results.scenario.scenario_name), ...
                'Position', [50, 50, 1400, 800], 'Color', 'w', 'NumberTitle', 'off');
        end

        function ax_grid = createAxesGrid(fig)
            % VIEW: Create 2x2 axes grid (TERMINAL)
            ax_grid = cell(2, 2);
            positions = {[0.10, 0.48, 0.38, 0.33], [0.56, 0.48, 0.38, 0.33], ...
                         [0.10, 0.08, 0.38, 0.33], [0.56, 0.08, 0.38, 0.33]};
            idx = 0;
            for r = 1:2
                for c = 1:2
                    idx = idx + 1;
                    ax_grid{r, c} = axes(fig, 'Position', positions{idx}, ...
                        'Visible', 'off', 'Box', 'on');
                end
            end
        end

        function handles = createNavigationControls(fig, handles)
            % SUB-CONTROLLER: Create all navigation buttons
            handles = createViewModeControls(fig, handles);
            handles = createOrdinalControls(fig, handles);
            handles = createNominalControls(fig, handles);
            handles = createAxisToggle(fig, handles);

            function handles = createViewModeControls(fig, handles)
                % VIEW: View mode navigation (TERMINAL)
                y_pos = 755;
                uicontrol(fig, 'Style', 'text', 'String', 'View:', ...
                    'Position', [20, y_pos, 40, 25], 'FontSize', 10, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w', ...
                    'HorizontalAlignment', 'right');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9664), ...
                    'Position', [65, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'view_prev'));
                handles.view_label = uicontrol(fig, 'Style', 'text', 'String', '', ...
                    'Position', [100, y_pos, 160, 25], 'FontSize', 11, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9654), ...
                    'Position', [265, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'view_next'));
            end

            function handles = createOrdinalControls(fig, handles)
                % VIEW: Ordinal navigation (TERMINAL)
                y_pos = 755;
                uicontrol(fig, 'Style', 'text', 'String', 'Row:', ...
                    'Position', [340, y_pos, 35, 25], 'FontSize', 10, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w', ...
                    'HorizontalAlignment', 'right');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9664), ...
                    'Position', [380, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'ord_prev'));
                handles.ord_label = uicontrol(fig, 'Style', 'text', 'String', '', ...
                    'Position', [415, y_pos, 260, 25], 'FontSize', 10, 'BackgroundColor', 'w');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9654), ...
                    'Position', [680, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'ord_next'));
            end

            function handles = createNominalControls(fig, handles)
                % VIEW: Nominal navigation (TERMINAL)
                y_pos = 755;
                uicontrol(fig, 'Style', 'text', 'String', 'Col:', ...
                    'Position', [760, y_pos, 30, 25], 'FontSize', 10, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w', ...
                    'HorizontalAlignment', 'right');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9664), ...
                    'Position', [795, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'nom_prev'));
                handles.nom_label = uicontrol(fig, 'Style', 'text', 'String', '', ...
                    'Position', [830, y_pos, 260, 25], 'FontSize', 10, 'BackgroundColor', 'w');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9654), ...
                    'Position', [1095, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'nom_next'));
            end

            function handles = createAxisToggle(fig, handles)
                % VIEW: Axis mode toggle (TERMINAL)
                handles.axis_toggle = uicontrol(fig, 'Style', 'pushbutton', ...
                    'String', 'Axis: Local', 'Position', [1200, 755, 120, 25], ...
                    'FontSize', 10, 'FontWeight', 'bold', ...
                    'Callback', @(~,~) handleNavigation(fig, 'toggle_axis'));
            end
        end

        function handles = createGridLabels(fig, handles)
            % VIEW: Create row and column header annotations (TERMINAL)
            handles.col_headers = cell(1, 2);
            handles.row_headers = cell(1, 2);
            col_x = [0.10, 0.56];
            for c = 1:2
                handles.col_headers{c} = annotation(fig, 'textbox', ...
                    [col_x(c), 0.82, 0.38, 0.04], 'String', '', ...
                    'FontSize', 11, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', 'EdgeColor', 'none');
            end
            row_y_centers = [0.625, 0.225];
            for r = 1:2
                handles.row_headers{r} = annotation(fig, 'textbox', ...
                    [0.00, row_y_centers(r), 0.10, 0.04], 'String', '', ...
                    'FontSize', 10, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'EdgeColor', 'none');
            end
        end
    end

%   CONTROLLER 2: NAVIGATION
function handleNavigation(fig, action)
    % CONTROLLER: Process navigation, update state, re-render
    state = getappdata(fig, 'ViewerState');
    state = applyNavigationAction(state, action);
    setappdata(fig, 'ViewerState', state);
    renderCurrentView(fig);
    updateNavigationLabels(fig);

    function state = applyNavigationAction(state, action)
        % MODEL: Update state offsets (TERMINAL)
        switch action
            case 'view_prev'
                state.view_mode = max(1, state.view_mode - 1);
            case 'view_next'
                state.view_mode = min(length(state.view_names), state.view_mode + 1);
            case 'ord_prev'
                state.ord_offset = max(1, state.ord_offset - state.max_rows);
            case 'ord_next'
                max_offset = max(1, state.n_ord - state.max_rows + 1);
                state.ord_offset = min(max_offset, state.ord_offset + state.max_rows);
            case 'nom_prev'
                state.nom_offset = max(1, state.nom_offset - state.max_cols);
            case 'nom_next'
                max_offset = max(1, state.n_nom - state.max_cols + 1);
                state.nom_offset = min(max_offset, state.nom_offset + state.max_cols);
            case 'toggle_axis'
                if strcmp(state.axis_mode, 'local')
                    state.axis_mode = 'global';
                else
                    state.axis_mode = 'local';
                end
        end
    end
end

%   CONTROLLER 3: RENDER DISPATCH
function renderCurrentView(fig)
    % CONTROLLER: Clear all axes, render visible cells via shared renderers
    state = getappdata(fig, 'ViewerState');
    clearAllAxes(state);
    renderVisibleCells(state);

    function clearAllAxes(state)
        % VIEW: Clear and hide all axes (TERMINAL)
        for r = 1:2
            for c = 1:2
                ax = state.handles.axes{r, c};
                cla(ax); legend(ax, 'off'); title(ax, '');
                set(ax, 'Visible', 'off', ...
                    'XLimMode', 'auto', 'YLimMode', 'auto', ...
                    'XTickMode', 'auto', 'YTickMode', 'auto', ...
                    'XTickLabelMode', 'auto', 'YTickLabelMode', 'auto');
            end
        end
    end
    function renderVisibleCells(state)
    % SUB-CONTROLLER: Loop over visible cells, dispatch to shared renderers
    visible_rows = min(state.max_rows, state.n_ord - state.ord_offset + 1);
    visible_cols = min(state.max_cols, state.n_nom - state.nom_offset + 1);
    for r = 1:visible_rows
        for c = 1:visible_cols
            ord_idx = state.ord_offset + r - 1;
            nom_idx = state.nom_offset + c - 1;
            ax = state.handles.axes{r, c};
            switch state.view_mode
                case 1, renderTrajectoryCell(ax, state, ord_idx, nom_idx);
                case 2, renderHistogramCell(ax, state, ord_idx, nom_idx);
                case 3, renderMixtureCell(ax, state, ord_idx, nom_idx);
                case 4, renderCompositionCell(ax, state, ord_idx, nom_idx);
                case 5, renderKDECell(ax, state, ord_idx, nom_idx);
            end
        end
    end
end
end

%   CONTROLLER 4: NAVIGATION LABELS
function updateNavigationLabels(fig)
    % CONTROLLER: Refresh all navigation text and grid headers
    state = getappdata(fig, 'ViewerState');
    updateViewModeLabel(state);
    updateOrdinalLabel(state);
    updateNominalLabel(state);
    updateColumnHeaders(state);
    updateRowHeaders(state);
    updateAxisToggle(state);

    function updateViewModeLabel(state)
        % VIEW: Update view mode text (TERMINAL)
        set(state.handles.view_label, 'String', ...
            sprintf('%s  (%d/%d)', state.view_names{state.view_mode}, ...
                state.view_mode, length(state.view_names)));
    end

    function updateOrdinalLabel(state)
        % VIEW: Update ordinal range text (TERMINAL)
        visible_rows = min(state.max_rows, state.n_ord - state.ord_offset + 1);
        ord_end = state.ord_offset + visible_rows - 1;
        set(state.handles.ord_label, 'String', ...
            sprintf('%s .. %s  (%d-%d of %d)', ...
                state.results.scenario.ordinal_labels{state.ord_offset}, ...
                state.results.scenario.ordinal_labels{ord_end}, ...
                state.ord_offset, ord_end, state.n_ord));
    end

    function updateNominalLabel(state)
        % VIEW: Update nominal range text (TERMINAL)
        visible_cols = min(state.max_cols, state.n_nom - state.nom_offset + 1);
        nom_end = state.nom_offset + visible_cols - 1;
        set(state.handles.nom_label, 'String', ...
            sprintf('%s .. %s  (%d-%d of %d)', ...
                state.results.scenario.nominal_labels{state.nom_offset}, ...
                state.results.scenario.nominal_labels{nom_end}, ...
                state.nom_offset, nom_end, state.n_nom));
    end

    function updateColumnHeaders(state)
        % VIEW: Update column headers (TERMINAL)
        for c = 1:2
            nom_idx = state.nom_offset + c - 1;
            if nom_idx <= state.n_nom
                set(state.handles.col_headers{c}, 'String', ...
                    state.results.scenario.nominal_labels{nom_idx}, 'Visible', 'on');
            else
                set(state.handles.col_headers{c}, 'Visible', 'off');
            end
        end
    end

    function updateRowHeaders(state)
        % VIEW: Update row headers (TERMINAL)
        for r = 1:2
            ord_idx = state.ord_offset + r - 1;
            if ord_idx <= state.n_ord
                set(state.handles.row_headers{r}, 'String', ...
                    state.results.scenario.ordinal_labels{ord_idx}, 'Visible', 'on');
            else
                set(state.handles.row_headers{r}, 'Visible', 'off');
            end
        end
    end

    function updateAxisToggle(state)
        % VIEW: Update toggle button (TERMINAL)
        if strcmp(state.axis_mode, 'local')
            set(state.handles.axis_toggle, 'String', 'Axis: Local');
        else
            set(state.handles.axis_toggle, 'String', 'Axis: Global');
        end
    end
end

end
