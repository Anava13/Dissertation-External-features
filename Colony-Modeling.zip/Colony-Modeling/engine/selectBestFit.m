function [best_dist, criteria] = selectBestFit(distribution_tests)
    % SUB-CONTROLLER: Select best parametric fit by AIC
    scores = gatherDistributionScores(distribution_tests);
    qualityFlags = evaluateQualityFlags(distribution_tests, scores);
    bestInfo = pickBestDistribution(scores, qualityFlags);
    deltas = computeDistributionDeltas(scores, qualityFlags);
    criteria = packSelectionCriteria(scores, qualityFlags, bestInfo, deltas);
    best_dist = bestInfo.name;

    function scores = gatherDistributionScores(dt)
        % MODEL: Pull AIC/BIC (TERMINAL)
        scores = struct();
        scores.normal_aic = dt.normal.aic_score;
        scores.lognormal_aic = dt.lognormal.aic_score;
        scores.library_aic = dt.library.aic_score;
        scores.normal_bic = dt.normal.bic_score;
        scores.lognormal_bic = dt.lognormal.bic_score;
        scores.library_bic = dt.library.bic_score;
    end

    function qf = evaluateQualityFlags(dt, scores)
        % MODEL: Mark valid fits (TERMINAL)
        qf = struct();
        qf.normal_converged = isfinite(scores.normal_aic);
        qf.lognormal_valid = isfinite(scores.lognormal_aic);
        qf.library_valid = isfinite(scores.library_aic);
        qf.nonparam_sufficient = dt.nonparametric.effective_sample_size >= 20;
        qf.insufficient_data = false;
    end

    function bestInfo = pickBestDistribution(scores, qf)
        % MODEL: Pick best parametric or fall back (TERMINAL)
        bestInfo = struct();
        valid_dists = {};
        valid_aics = [];
        if qf.normal_converged
            valid_dists{end+1} = 'Normal'; valid_aics(end+1) = scores.normal_aic;
        end
        if qf.lognormal_valid
            valid_dists{end+1} = 'LogNormal'; valid_aics(end+1) = scores.lognormal_aic;
        end
        if qf.library_valid
            valid_dists{end+1} = 'Library'; valid_aics(end+1) = scores.library_aic;
        end
        if ~isempty(valid_aics)
            [sorted_aics, idx] = sort(valid_aics);
            bestInfo.name = valid_dists{idx(1)};
            if length(sorted_aics) > 1
                bestInfo.winning_margin = sorted_aics(2) - sorted_aics(1);
                bestInfo.selection_reason = sprintf('Lowest AIC by margin of %.1f', bestInfo.winning_margin);
            else
                bestInfo.winning_margin = Inf;
                bestInfo.selection_reason = 'Only valid parametric distribution';
            end
        elseif qf.nonparam_sufficient
            bestInfo.name = 'Non-parametric';
            bestInfo.winning_margin = NaN;
            bestInfo.selection_reason = 'Non-parametric: no valid parametric fits';
        else
            bestInfo.name = 'No_Valid_Fit';
            bestInfo.winning_margin = NaN;
            bestInfo.selection_reason = 'No valid distribution fits available';
        end
    end

    function deltas = computeDistributionDeltas(scores, qf)
        % MODEL: Compute delta AIC/BIC (TERMINAL)
        deltas = struct();
        valid_aic = [];
        if qf.normal_converged, valid_aic(end+1) = scores.normal_aic; end
        if qf.lognormal_valid, valid_aic(end+1) = scores.lognormal_aic; end
        if qf.library_valid, valid_aic(end+1) = scores.library_aic; end
        if length(valid_aic) >= 2
            s = sort(valid_aic); deltas.Delta_aic_distribution = s(2) - s(1);
        else
            deltas.Delta_aic_distribution = NaN;
        end
        valid_bic = [];
        if qf.normal_converged, valid_bic(end+1) = scores.normal_bic; end
        if qf.lognormal_valid, valid_bic(end+1) = scores.lognormal_bic; end
        if qf.library_valid, valid_bic(end+1) = scores.library_bic; end
        if length(valid_bic) >= 2
            s = sort(valid_bic); deltas.Delta_bic_distribution = s(2) - s(1);
        else
            deltas.Delta_bic_distribution = NaN;
        end
    end

    function criteria = packSelectionCriteria(scores, qf, bestInfo, deltas)
        % MODEL: Pack selection_criteria (TERMINAL)
        criteria = struct();
        criteria.aic_scores = struct('normal', scores.normal_aic, ...
            'LogNormal', scores.lognormal_aic, 'library', scores.library_aic, ...
            'nonparametric', NaN, 'Delta_aic_distribution', deltas.Delta_aic_distribution);
        criteria.bic_scores = struct('normal', scores.normal_bic, ...
            'LogNormal', scores.lognormal_bic, 'library', scores.library_bic, ...
            'nonparametric', NaN, 'Delta_bic_distribution', deltas.Delta_bic_distribution);
        criteria.quality_flags = qf;
        criteria.selection_reason = bestInfo.selection_reason;
        criteria.winning_margin = bestInfo.winning_margin;
    end
end
