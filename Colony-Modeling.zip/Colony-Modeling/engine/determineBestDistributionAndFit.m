function analysis = determineBestDistributionAndFit(data, options)
    % SUB-CONTROLLER: Run all distribution tests and select best
    if length(data) < 3
        analysis = buildInsufficientDataAnalysis(data);
        return;
    end
    distribution_tests = runAllDistributionTests(data, options);
    [best_dist, selection_criteria] = selectBestFit(distribution_tests);
    analysis = struct();
    analysis.distribution_tests = distribution_tests;
    analysis.selection_criteria = selection_criteria;
    analysis.best_distribution = best_dist;
end
