function renderMixtureCell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render mixture model overlay
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);
    mixtureData = buildMixtureCurves(colonySet, histData);
    drawMixturePanel(ax, histData, mixtureData, state);

    function mixtureData = buildMixtureCurves(colonySet, histData)
        % MODEL: Compute component and total curves (TERMINAL)
        mixtureData = struct();
        mixtureData.success = false;
        mixtureData.library_info = '';

        k = colonySet.gmm_results.optimal_components;
        mixtureData.k = k;
        if histData.empty || k == 0, return; end

        fm = colonySet.gmm_results.fitted_model;
        if any(isnan(fm.GMM_mu)) || any(fm.GMM_mu <= 0), return; end

        % Library info
        if isfield(colonySet, 'selected_method') && ...
                strcmp(char(colonySet.selected_method), 'Library') && ...
                isfield(fm, 'library_blobs') && ~isempty(fm.library_blobs.centroids_phi)
            [~, dom] = max(fm.library_blobs.total_weights);
            phi_str = sprintf('Library: \\phi=%.2f \\epsilon=%.2f', ...
                fm.library_blobs.centroids_phi(dom), fm.library_blobs.centroids_eps(dom));
            quality_str = '';
            if isfield(fm, 'library_quality_shape') && isfield(fm, 'library_quality_scale') && ...
                    ~isnan(fm.library_quality_shape) && ~isnan(fm.library_quality_scale)
                quality_str = sprintf('Q_{shape}=%.2f Q_{scale}=%.2f', ...
                    fm.library_quality_shape, fm.library_quality_scale);
            elseif isfield(fm, 'library_quality_shape') && ~isnan(fm.library_quality_shape)
                quality_str = sprintf('Q_{shape}=%.2f', fm.library_quality_shape);
            elseif isfield(fm, 'library_quality_scale') && ~isnan(fm.library_quality_scale)
                quality_str = sprintf('Q_{scale}=%.2f', fm.library_quality_scale);
            end
            if isempty(quality_str)
                mixtureData.library_info = phi_str;
            else
                mixtureData.library_info = sprintf('%s\n%s', phi_str, quality_str);
            end
        end

        n = histData.n;
        bw = histData.log_bin_width;
        x_log = linspace(histData.log_bin_edges(1), histData.log_bin_edges(end), 300);
        [~, sort_idx] = sort(fm.GMM_mu);

        component_curves = zeros(k, length(x_log));
        total_curve = zeros(1, length(x_log));
        comp_info = cell(k, 1);
        for i = 1:k
            ci = sort_idx(i);
            mu_log = log(fm.GMM_mu(ci));
            sigma_log = fm.GMM_sigma(ci);
            w = fm.GMM_weights(ci);
            if sigma_log <= 0 || ~isfinite(mu_log)
                comp_info{i} = sprintf('k%d: invalid', i); continue;
            end
            curve = w * normpdf(x_log, mu_log, sigma_log) * n * bw;
            component_curves(i, :) = curve;
            total_curve = total_curve + curve;
            dist_type = '';
            if isfield(colonySet, 'subpopulations') && length(colonySet.subpopulations) >= ci
                dist_type = char(colonySet.subpopulations(ci).best_distribution);
            end
            comp_info{i} = sprintf('k%d: \\mu=%.0f, w=%.0f%% [%s]', ...
                i, fm.GMM_mu(ci), w * 100, dist_type);
        end

        mixtureData.x_log = x_log;
        mixtureData.component_curves = component_curves;
        mixtureData.total_curve = total_curve;
        mixtureData.comp_info = comp_info;
        mixtureData.success = true;
    end

    function drawMixturePanel(ax, histData, mixtureData, state)
        % VIEW: Draw histogram with mixture overlay (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end

        bar(ax, histData.log_bin_centers, histData.bin_counts, 1, ...
            'FaceColor', [0.80, 0.80, 0.80], 'EdgeColor', [0.60, 0.60, 0.60], ...
            'FaceAlpha', 0.6);

        if mixtureData.success && mixtureData.k > 0
            comp_colors = [0.12, 0.47, 0.71; 0.89, 0.10, 0.11; ...
                           0.17, 0.63, 0.17; 0.58, 0.40, 0.74];
            for i = 1:mixtureData.k
                color = comp_colors(min(i, size(comp_colors, 1)), :);
                plot(ax, mixtureData.x_log, mixtureData.component_curves(i, :), ...
                    '-', 'Color', color, 'LineWidth', 2);
            end
            plot(ax, mixtureData.x_log, mixtureData.total_curve, 'k--', 'LineWidth', 1.5);

            info_lines = cell(mixtureData.k + 1, 1);
            info_lines{1} = sprintf('k = %d', mixtureData.k);
            for i = 1:mixtureData.k
                info_lines{i + 1} = mixtureData.comp_info{i};
            end
            if ~isempty(mixtureData.library_info)
                info_lines{end + 1} = mixtureData.library_info;
            end

            curve_at_bins = interp1(mixtureData.x_log, mixtureData.total_curve, ...
                histData.log_bin_centers, 'linear', 0);
            envelope = max(histData.bin_counts, curve_at_bins);
            if strcmp(state.axis_mode, 'global') && state.global_limits.valid
                effective_y_max = state.global_limits.hist_y_max;
            else
                effective_y_max = max(envelope) * 1.1;
            end

            placement = findLeastOccludedCorner(histData.log_bin_centers, ...
                envelope, effective_y_max, length(info_lines));
            text(ax, placement.x, placement.y, strjoin(info_lines, '\n'), ...
                'Units', 'normalized', 'FontSize', 7, ...
                'HorizontalAlignment', placement.h_align, ...
                'VerticalAlignment', placement.v_align, ...
                'BackgroundColor', [1, 1, 1, 0.85], ...
                'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);
        end

        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end

    function placement = findLeastOccludedCorner(bin_centers, envelope, y_max, n_lines)
        % MODEL: Score four corners by occlusion (TERMINAL)
        margin = 0.03;
        box_w = 0.35;
        box_h = min(0.045 * n_lines + 0.03, 0.85);
        candidates = struct( ...
            'x', {1-margin, margin, 1-margin, margin}, ...
            'y', {1-margin, 1-margin, margin, margin}, ...
            'h_align', {'right', 'left', 'right', 'left'}, ...
            'v_align', {'top', 'top', 'bottom', 'bottom'}, ...
            'rect', {[1-margin-box_w, 1-margin-box_h, 1-margin, 1-margin], ...
                     [margin, 1-margin-box_h, margin+box_w, 1-margin], ...
                     [1-margin-box_w, margin, 1-margin, margin+box_h], ...
                     [margin, margin, margin+box_w, margin+box_h]});
        x_lo = min(bin_centers); x_hi = max(bin_centers);
        x_range = x_hi - x_lo; y_range = y_max;
        if x_range <= 0 || y_range <= 0
            placement = candidates(1); return;
        end
        scores = zeros(1, 4);
        for cc = 1:4
            r = candidates(cc).rect;
            data_x_min = x_lo + r(1) * x_range;
            data_x_max = x_lo + r(3) * x_range;
            data_y_min = r(2) * y_range;
            data_y_max = r(4) * y_range;
            in_x = bin_centers >= data_x_min & bin_centers <= data_x_max;
            heights = envelope(in_x);
            for h = 1:length(heights)
                overlap = min(heights(h), data_y_max) - data_y_min;
                if overlap > 0, scores(cc) = scores(cc) + overlap; end
            end
        end
        [~, best] = min(scores);
        placement = struct('x', candidates(best).x, 'y', candidates(best).y, ...
            'h_align', candidates(best).h_align, 'v_align', candidates(best).v_align);
    end
end
