function scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig)
    % MODEL: Place a cellConfig into the scenario grid (TERMINAL)
    nom_field = scenario.nominal_fields{nom_idx};
    scenario.config(ord_idx).(nom_field) = cellConfig;
end
