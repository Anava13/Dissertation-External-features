function scenario = buildStablePhiScenario(phi_values, epsilon_spreads, n_colonies, v)
    % CONTROLLER: Build the phi-epsilon sweep scenario
    %
    % Grid shape: ordinal axis = epsilon spreads, nominal axis = phi values.
    % Every cell uses a single pool with constant phi and epsilon.
    %
    % USAGE:
    %   scenario = buildStablePhiScenario();
    %   scenario = buildStablePhiScenario(0.6:0.04:0.92, 0:0.04:0.20, 1000, 40);

    if nargin < 1 || isempty(phi_values),      phi_values = 0.61:0.04:0.93; end
    if nargin < 2 || isempty(epsilon_spreads),  epsilon_spreads = 0:0.04:0.20; end
    if nargin < 3 || isempty(n_colonies),       n_colonies = 1000; end
    if nargin < 4 || isempty(v),                v = 40; end

    scenario = initializeShell(phi_values, epsilon_spreads);
    scenario = populateGrid(scenario, phi_values, epsilon_spreads, n_colonies, v);

    function scenario = initializeShell(phi_values, epsilon_spreads)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(phi_values, epsilon_spreads);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'StablePhiSweep');

        function labels = buildLabels(phi_values, epsilon_spreads)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            n_phi = length(phi_values);
            labels.nominal_display = cell(1, n_phi);
            labels.nominal_fields = cell(1, n_phi);
            for i = 1:n_phi
                labels.nominal_display{i} = sprintf('phi=%.2f', phi_values(i));
                labels.nominal_fields{i} = sprintf('phi_%03d', round(phi_values(i) * 100));
            end
            n_eps = length(epsilon_spreads);
            labels.ordinal_display = cell(1, n_eps);
            for i = 1:n_eps
                labels.ordinal_display{i} = sprintf('eps=%.2f', epsilon_spreads(i));
            end
        end
    end

    function scenario = populateGrid(scenario, phi_values, epsilon_spreads, n_colonies, v)
        % SUB-CONTROLLER: Fill every cell
        universal = makeUniversalConfig(n_colonies, v, 50);
        n_eps = length(epsilon_spreads);
        n_phi = length(phi_values);
        for ord_idx = 1:n_eps
            for nom_idx = 1:n_phi
                cellConfig = buildCellConfig( ...
                    phi_values(nom_idx), epsilon_spreads(ord_idx), universal, v);
                scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig);
            end
        end

        function cellConfig = buildCellConfig(phi, eps_val, universal, v)
            % MODEL: Build one stable-phi cell config (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;
            cellConfig.pools = buildPool( ...
                phi * ones(1, v), eps_val * ones(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig.branch_events = [];
            cellConfig.log_params = struct('phi', phi, 'epsilon', eps_val);
            cellConfig.ground_truth = struct('phi', phi, 'epsilon', eps_val);
        end
    end
end
