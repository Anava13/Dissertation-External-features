function scenario = buildBranchingProbe2Scenario(n_colonies, v)
    % CONTROLLER: Build branching probe scenario for phi_baseline sweep
    %
    % Sweeps phi_baseline (ordinal) x p_branch (nominal) at fixed gap=0.10,
    % branch round 5, branch-up, per-colony branching, eps=0.
    %
    % Ordinal axis (6 values):  phi_baseline from 0.65 to 0.90
    % Nominal axis (9 values):  p_branch from 0.05 to 0.80
    %
    % Held constants:
    %   phi_gap = 0.10, branch_round = 5, direction = up,
    %   mode = per_colony, eps = 0, v = 40, n = 1000
    %
    % USAGE:
    %   scenario = buildBranchingProbe2Scenario();
    %   scenario = buildBranchingProbe2Scenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies, v);

    function scenario = initializeShell()
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels();
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BranchingProbe2');

        function labels = buildLabels()
            % MODEL: Build display labels for phi_base (ordinal) and p_branch (nominal) (TERMINAL)
            phi_bases = getPhiBaseValues();
            p_branches = getPBranchValues();

            labels = struct();
            labels.ordinal_display = arrayfun(@(b) sprintf('phi_base=%.2f', b), ...
                phi_bases, 'UniformOutput', false);
            labels.nominal_display = arrayfun(@(p) sprintf('p=%.2f', p), ...
                p_branches, 'UniformOutput', false);
            labels.nominal_fields = arrayfun(@(p) sprintf('p_%03d', round(p*100)), ...
                p_branches, 'UniformOutput', false);
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v)
        % SUB-CONTROLLER: Fill all phi_base x p_branch cells
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_gap = 0.10;
        branch_round = 5;
        phi_bases = getPhiBaseValues();
        p_branches = getPBranchValues();

        for ord_idx = 1:length(phi_bases)
            for nom_idx = 1:length(p_branches)
                cellConfig = buildBranchCell( ...
                    phi_bases(ord_idx), ...
                    phi_bases(ord_idx) + phi_gap, ...
                    branch_round, ...
                    p_branches(nom_idx), ...
                    universal, v, ...
                    sprintf('base%02d_p%03d', round(phi_bases(ord_idx)*100), ...
                        round(p_branches(nom_idx)*100)));
                scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig);
            end
        end

        function cellConfig = buildBranchCell(phi_base, phi_post, event_round, p_event, universal, v, label)
            % SUB-CONTROLLER: Build a two-pool branching cell
            params = computeBranchParams(phi_base, phi_post, event_round, p_event);
            p_eff = computeBranchEffectiveTrajectory(params, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchCell(params, universal, label, predictors, v);

            function params = computeBranchParams(phi_base, phi_post, event_round, p_event)
                % MODEL: Branch parameters (TERMINAL)
                params = struct();
                params.p_base = phi_base;
                params.p_post = phi_post;
                params.event_round = event_round;
                params.p_event = p_event;
            end

            function p_eff = computeBranchEffectiveTrajectory(params, v)
                % MODEL: Population-mean phi(r) for branching (TERMINAL)
                r = 1:v;
                p_eff = params.p_base * ones(1, v);
                mask = r >= params.event_round;
                p_eff(mask) = params.p_event * params.p_post + ...
                    (1 - params.p_event) * params.p_base;
            end

            function cellConfig = packBranchCell(params, universal, label, predictors, v)
                % MODEL: Assemble two-pool branch cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool( ...
                    params.p_base * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                event_pool = buildPool( ...
                    params.p_post * ones(1, v), zeros(1, v), ...
                    'BranchLineage', [0.75, 0.55, 0.10], [], 0);

                cellConfig.pools = [base_pool, event_pool];
                cellConfig.branch_events = buildBranchEvent( ...
                    1, 'dividing', 2, 'per_colony', ...
                    params.p_event, [params.event_round]);

                cellConfig.log_params = struct( ...
                    'condition', label, ...
                    'p_base', params.p_base, ...
                    'p_post', params.p_post, ...
                    'phi_gap', params.p_post - params.p_base, ...
                    'event_round', params.event_round, ...
                    'p_event', params.p_event, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end
    end

    function bases = getPhiBaseValues()
        % MODEL: Ordinal axis phi_baseline values (TERMINAL)
        bases = [0.65, 0.70, 0.75, 0.80, 0.85, 0.90];
    end

    function ps = getPBranchValues()
        % MODEL: Nominal axis p_branch values (TERMINAL)
        ps = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80];
    end
end
