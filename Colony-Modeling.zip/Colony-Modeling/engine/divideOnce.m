function [successes, failures] = divideOnce(S, p_eff, approx_threshold)
    % MODEL: Single round of branching division for S cells (TERMINAL)
    if S <= 0
        successes = 0;
        failures = 0;
        return;
    end
    if S > approx_threshold
        mu_s = S * p_eff;
        var_s = S * p_eff * (1 - p_eff);
        successes = max(0, min(S, round(normrnd(mu_s, sqrt(var_s)))));
    else
        successes = binornd(S, p_eff);
    end
    failures = S - successes;
end
