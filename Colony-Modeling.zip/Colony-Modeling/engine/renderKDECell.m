function renderKDECell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render KDE with histogram backing
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);
    kdeData = computeLogKDE(colonySet.raw_measurements, imposed_edges);
    drawKDEPanel(ax, histData, kdeData, state);

    function drawKDEPanel(ax, histData, kdeData, state)
        % VIEW: Draw KDE with density-normalized histogram backing (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if kdeData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', kdeData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end

        % Density-normalized histogram backing
        if ~histData.empty
            density_counts = histData.bin_counts / (histData.n * histData.log_bin_width);
            bar(ax, histData.log_bin_centers, density_counts, 1, ...
                'FaceColor', [0.75, 0.75, 0.78], 'EdgeColor', [0.60, 0.60, 0.65], ...
                'FaceAlpha', 0.4);
        end

        % KDE curve
        plot(ax, kdeData.eval_x_log, kdeData.density, '-', ...
            'Color', [0.75, 0.20, 0.30], 'LineWidth', 2);

        % Info panel
        text(ax, 0.97, 0.95, sprintf('n=%d\n\\mu=%.0f \\mum\nCV=%.2f\nh=%.3f', ...
            kdeData.n, kdeData.mean_r, kdeData.cv, kdeData.bandwidth), ...
            'Units', 'normalized', 'FontSize', 8, ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'BackgroundColor', [1, 1, 1, 0.85], 'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);

        applyLogTickLabels(ax, histData);

        % Override xlim to encompass full KDE range and apply y-limits
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            xlim(ax, [state.global_limits.hist_log_edges(1), ...
                      state.global_limits.hist_log_edges(end)]);
            ylim(ax, [0, state.global_limits.kde_y_max]);
        else
            xlim(ax, [kdeData.eval_x_log(1), kdeData.eval_x_log(end)]);
        end

        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Density', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end
end
