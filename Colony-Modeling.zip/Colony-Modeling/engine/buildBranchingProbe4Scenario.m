function scenario = buildBranchingProbe4Scenario(n_colonies, v)
    % CONTROLLER: Build branching probe scenario for gap x baseline sweep
    %
    % Sweeps phi_gap (ordinal) x phi_baseline (nominal) at fixed event_round=5,
    % p_branch=0.40, branch-up, per-colony branching, eps=0.
    %
    % Ordinal axis (24 values): phi gap from 0.02 to 0.25
    % Nominal axis (13 values): phi_baseline from 0.600 to 0.900
    %
    % Cells where phi_baseline + phi_gap > 1.0 are capped at phi_branch = 1.0.
    %
    % Held constants:
    %   event_round = 5, p_branch = 0.40, direction = up,
    %   mode = per_colony, eps = 0, v = 40, n = 1000
    %
    % USAGE:
    %   scenario = buildBranchingProbe4Scenario();
    %   scenario = buildBranchingProbe4Scenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies, v);

    function scenario = initializeShell()
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels();
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BranchingProbe4');

        function labels = buildLabels()
            % MODEL: Build display labels for gap (ordinal) and baseline (nominal) (TERMINAL)
            phi_gaps = getPhiGapValues();
            phi_bases = getPhiBaseValues();

            labels = struct();
            labels.ordinal_display = arrayfun(@(g) sprintf('gap=%.2f', g), ...
                phi_gaps, 'UniformOutput', false);
            labels.nominal_display = arrayfun(@(b) sprintf('base=%.3f', b), ...
                phi_bases, 'UniformOutput', false);
            labels.nominal_fields = arrayfun(@(b) sprintf('b_%03d', round(b*1000)), ...
                phi_bases, 'UniformOutput', false);
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v)
        % SUB-CONTROLLER: Fill all gap x baseline cells, capping phi_branch at 1.0
        universal = makeUniversalConfig(n_colonies, v, 50);
        event_round = 5;
        p_branch = 0.40;
        phi_gaps = getPhiGapValues();
        phi_bases = getPhiBaseValues();

        for ord_idx = 1:length(phi_gaps)
            for nom_idx = 1:length(phi_bases)
                phi_post = min(phi_bases(nom_idx) + phi_gaps(ord_idx), 1.0);

                cellConfig = buildBranchCell( ...
                    phi_bases(nom_idx), ...
                    phi_post, ...
                    event_round, ...
                    p_branch, ...
                    universal, v, ...
                    sprintf('gap%02d_base%03d', round(phi_gaps(ord_idx)*100), ...
                        round(phi_bases(nom_idx)*1000)));
                scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig);
            end
        end

        function cellConfig = buildBranchCell(phi_base, phi_post, event_round, p_event, universal, v, label)
            % SUB-CONTROLLER: Build a two-pool branching cell
            params = computeBranchParams(phi_base, phi_post, event_round, p_event);
            p_eff = computeBranchEffectiveTrajectory(params, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchCell(params, universal, label, predictors, v);

            function params = computeBranchParams(phi_base, phi_post, event_round, p_event)
                % MODEL: Branch parameters (TERMINAL)
                params = struct();
                params.p_base = phi_base;
                params.p_post = phi_post;
                params.event_round = event_round;
                params.p_event = p_event;
            end

            function p_eff = computeBranchEffectiveTrajectory(params, v)
                % MODEL: Population-mean phi(r) for branching (TERMINAL)
                r = 1:v;
                p_eff = params.p_base * ones(1, v);
                mask = r >= params.event_round;
                p_eff(mask) = params.p_event * params.p_post + ...
                    (1 - params.p_event) * params.p_base;
            end

            function cellConfig = packBranchCell(params, universal, label, predictors, v)
                % MODEL: Assemble two-pool branch cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool( ...
                    params.p_base * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                event_pool = buildPool( ...
                    params.p_post * ones(1, v), zeros(1, v), ...
                    'BranchLineage', [0.75, 0.55, 0.10], [], 0);

                cellConfig.pools = [base_pool, event_pool];
                cellConfig.branch_events = buildBranchEvent( ...
                    1, 'dividing', 2, 'per_colony', ...
                    params.p_event, [params.event_round]);

                cellConfig.log_params = struct( ...
                    'condition', label, ...
                    'p_base', params.p_base, ...
                    'p_post', params.p_post, ...
                    'phi_gap', params.p_post - params.p_base, ...
                    'event_round', params.event_round, ...
                    'p_event', params.p_event, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end
    end

    function gaps = getPhiGapValues()
        % MODEL: Ordinal axis gap values (TERMINAL)
        gaps = 0.02:0.01:0.25;
    end

    function bases = getPhiBaseValues()
        % MODEL: Nominal axis phi_baseline values (TERMINAL)
        bases = 0.600:0.025:0.900;
    end
end
