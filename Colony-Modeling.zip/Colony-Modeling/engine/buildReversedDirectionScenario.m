function scenario = buildReversedDirectionScenario(n_colonies, v)
    % CONTROLLER: Build reversed-direction validation scenario
    %
    % Tests whether reversing trajectory direction produces different
    % library outputs or phi_geo accuracy compared to the original
    % decline/branch-up families in buildMatchedFlatScenario.
    %
    % 10 nominal columns (5 reversed families + 5 matched flats):
    %   1. LinearIncline          2. LinearIncline_Flat
    %   3. StepIncline            4. StepIncline_Flat
    %   5. Boost                  6. Boost_Flat
    %   7. EarlyBranchDown        8. EarlyBranchDown_Flat
    %   9. LateBranchDown        10. LateBranchDown_Flat
    %
    % 2 ordinal levels corresponding to levels 7 and 14 from the
    % original severity sweep.
    %
    % USAGE:
    %   scenario = buildReversedDirectionScenario();
    %   scenario = buildReversedDirectionScenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    levels = [7, 14];
    n_levels = length(levels);

    scenario = initializeShell(n_levels, levels);
    scenario = populateGrid(scenario, n_colonies, v, levels);

    function scenario = initializeShell(n_levels, levels)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(n_levels, levels);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'ReversedDirectionValidation');

        function labels = buildLabels(n_levels, levels)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = { ...
                'LinearIncline', 'LinIncline_Flat', ...
                'StepIncline',   'StepIncline_Flat', ...
                'Boost',         'Boost_Flat', ...
                'EarlyBranchDn', 'EarlyBranchDn_Flat', ...
                'LateBranchDn',  'LateBranchDn_Flat'};
            labels.nominal_fields = { ...
                'linear_incline', 'linear_incline_flat', ...
                'step_incline',   'step_incline_flat', ...
                'boost',          'boost_flat', ...
                'early_branch_dn', 'early_branch_dn_flat', ...
                'late_branch_dn',  'late_branch_dn_flat'};
            labels.ordinal_display = cell(1, n_levels);
            for i = 1:n_levels
                labels.ordinal_display{i} = sprintf('level_%02d', levels(i));
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, levels)
        % SUB-CONTROLLER: Fill every cell with reversed families + matched flats
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;

        for li = 1:length(levels)
            level = levels(li);
            ord_idx = li;

            % LinearIncline pair
            [origCell, phi_geo] = buildLinearInclineCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 1, origCell);
            scenario = addCellConfig(scenario, ord_idx, 2, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'linear_incline_flat', level));

            % StepIncline pair
            [origCell, phi_geo] = buildStepInclineCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 3, origCell);
            scenario = addCellConfig(scenario, ord_idx, 4, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'step_incline_flat', level));

            % Boost pair
            [origCell, phi_geo] = buildBoostCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 5, origCell);
            scenario = addCellConfig(scenario, ord_idx, 6, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'boost_flat', level));

            % EarlyBranchDown pair
            [origCell, phi_geo] = buildEarlyBranchDownCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 7, origCell);
            scenario = addCellConfig(scenario, ord_idx, 8, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'early_branch_dn_flat', level));

            % LateBranchDown pair
            [origCell, phi_geo] = buildLateBranchDownCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 9, origCell);
            scenario = addCellConfig(scenario, ord_idx, 10, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'late_branch_dn_flat', level));
        end

        %% ---- MATCHED FLAT BUILDER ----

        function cellConfig = buildMatchedFlatCell(phi_geo, v, universal, family_label, level)
            % SUB-CONTROLLER: Flat trajectory at phi_geo, eps = 0
            params = computeMatchedFlatParams(phi_geo, v);
            predictors = computeTrajectoryPredictors(params.p_traj);
            cellConfig = packMatchedFlatDiagnosticCell( ...
                params.p_traj, universal, family_label, level, predictors, phi_geo);

            function params = computeMatchedFlatParams(phi_geo, v)
                % MODEL: Constant phi at geometric mean value (TERMINAL)
                params = struct();
                params.p_traj = phi_geo * ones(1, v);
            end

            function cellConfig = packMatchedFlatDiagnosticCell( ...
                    p_traj, universal, family_label, level, predictors, phi_geo)
                % MODEL: Build matched flat cell with phi_geo logged (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    p_traj, zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'family', family_label, 'level', level, ...
                    'is_branched', false, ...
                    'phi_geo', phi_geo, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        %% ---- REVERSED FAMILY BUILDERS ----

        function [cellConfig, phi_geo] = buildLinearInclineCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Linear incline from low to high, mean = phi_base
            p_traj = computeLinearInclineTrajectory(level, phi_base, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'linear_incline', level, predictors, phi_geo, false);

            function p_traj = computeLinearInclineTrajectory(level, phi_base, v)
                % MODEL: Linear ramp UP centered on phi_base (TERMINAL)
                delta = 0.005 * level;
                r = 1:v;
                p_traj = (phi_base - delta) + 2 * delta * (r - 1) / (v - 1);
            end
        end

        function [cellConfig, phi_geo] = buildStepInclineCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Step function, low first half, high second half
            p_traj = computeStepInclineTrajectory(level, phi_base, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'step_incline', level, predictors, phi_geo, false);

            function p_traj = computeStepInclineTrajectory(level, phi_base, v)
                % MODEL: Step UP at midpoint, symmetric around phi_base (TERMINAL)
                delta = 0.005 * level;
                half = floor(v / 2);
                p_traj = [(phi_base - delta) * ones(1, half), ...
                          (phi_base + delta) * ones(1, v - half)];
            end
        end

        function [cellConfig, phi_geo] = buildBoostCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Transient high-phi window (opposite of bottleneck)
            p_traj = computeBoostTrajectory(level, phi_base, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'boost', level, predictors, phi_geo, false);

            function p_traj = computeBoostTrajectory(level, phi_base, v)
                % MODEL: Phi rises during rounds 16-20 then returns (TERMINAL)
                % NOTE: At level 7+, boost_phi caps at 0.99. Both tested
                % levels (7 and 14) produce identical boost trajectories.
                p_traj = phi_base * ones(1, v);
                boost_phi = min(phi_base + 0.06 * level, 0.99);
                p_traj(16:20) = boost_phi;
            end
        end

        function [cellConfig, phi_geo] = buildEarlyBranchDownCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Branch event at round 5, branch lineage at LOWER phi
            rp = computeEarlyBranchDownParams(level, phi_base);
            p_eff = computeBranchEffectiveTrajectory(rp, v);
            phi_geo = computeGeometricMean(p_eff);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchDiagnosticCell( ...
                rp, universal, 'early_branch_dn', level, predictors, phi_geo, v);

            function rp = computeEarlyBranchDownParams(level, phi_base)
                % MODEL: Early branch-down parameters (TERMINAL)
                rp = struct();
                rp.p_base = phi_base;
                rp.p_post = phi_base - 0.01 * level;
                rp.event_round = 5;
                rp.p_event = 0.40;
            end
        end

        function [cellConfig, phi_geo] = buildLateBranchDownCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Branch event at round 35, branch lineage at LOWER phi
            rp = computeLateBranchDownParams(level, phi_base);
            p_eff = computeBranchEffectiveTrajectory(rp, v);
            phi_geo = computeGeometricMean(p_eff);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchDiagnosticCell( ...
                rp, universal, 'late_branch_dn', level, predictors, phi_geo, v);

            function rp = computeLateBranchDownParams(level, phi_base)
                % MODEL: Late branch-down parameters (TERMINAL)
                rp = struct();
                rp.p_base = phi_base;
                rp.p_post = phi_base - 0.01 * level;
                rp.event_round = 35;
                rp.p_event = 0.40;
            end
        end

        %% ---- SHARED HELPERS ----

        function p_eff = computeBranchEffectiveTrajectory(rp, v)
            % MODEL: Population-mean phi(r) for branching scenario (TERMINAL)
            r = 1:v;
            p_eff = rp.p_base * ones(1, v);
            mask = r >= rp.event_round;
            p_eff(mask) = rp.p_event * rp.p_post + (1 - rp.p_event) * rp.p_base;
        end

        function phi_geo = computeGeometricMean(p_traj)
            % MODEL: Geometric mean of per-round phi values (TERMINAL)
            phi_geo = exp(mean(log(p_traj)));
        end

        function cellConfig = packOriginalDiagnosticCell( ...
                p_traj, eps_traj, universal, family_label, level, predictors, phi_geo, is_branched)
            % MODEL: Build single-pool diagnostic cell (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;
            cellConfig.pools = buildPool( ...
                p_traj, eps_traj, ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig.branch_events = [];
            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', is_branched, ...
                'phi_geo', phi_geo, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end

        function cellConfig = packBranchDiagnosticCell( ...
                rp, universal, family_label, level, predictors, phi_geo, v)
            % MODEL: Build two-pool branch diagnostic cell (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;

            base_pool = buildPool( ...
                rp.p_base * ones(1, v), zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            event_pool = buildPool( ...
                rp.p_post * ones(1, v), zeros(1, v), ...
                'BranchLineage', [0.75, 0.55, 0.10], [], 0);

            cellConfig.pools = [base_pool, event_pool];
            cellConfig.branch_events = buildBranchEvent( ...
                1, 'dividing', 2, 'per_colony', rp.p_event, [rp.event_round]);

            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', true, ...
                'p_base', rp.p_base, 'p_post', rp.p_post, ...
                'event_round', rp.event_round, 'p_event', rp.p_event, ...
                'phi_geo', phi_geo, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end
    end
end
