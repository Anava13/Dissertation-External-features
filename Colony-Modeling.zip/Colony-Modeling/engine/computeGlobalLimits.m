function globalLimits = computeGlobalLimits(results)
    % SUB-CONTROLLER: Scan all cells for shared axis limits
    allRadii = collectAllRadii(results);
    globalLimits = buildGlobalLimitStruct(allRadii, results);

    function allRadii = collectAllRadii(results)
        % MODEL: Gather radii from every cell (TERMINAL)
        allRadii = [];
        n_ord = length(results.scenario.ordinal_labels);
        n_nom = length(results.scenario.nominal_labels);
        for ord = 1:n_ord
            for nom = 1:n_nom
                nom_field = results.scenario.nominal_fields{nom};
                cs = results.analysisResults ...
                    .SubpopulationAnalysis(ord).(nom_field).ColonySet;
                r = cs.raw_measurements;
                if ~isempty(r), allRadii = [allRadii; r(:)]; end %#ok<AGROW>
            end
        end
    end

    function gl = buildGlobalLimitStruct(allRadii, results)
        % SUB-CONTROLLER: Compute shared edges and y-maxes for all view modes
        gl = initializeLimitStruct();
        if length(allRadii) < 2
            return;
        end
        gl.valid = true;
        gl.hist_log_edges = computeSharedEdges(allRadii);
        gl.hist_y_max = computeMaxHistCount(results, gl.hist_log_edges) * 1.1;
        gl.kde_y_max = computeMaxKDEDensity(results, gl.hist_log_edges) * 1.1;

        function gl = initializeLimitStruct()
            % MODEL: Default invalid struct (TERMINAL)
            gl = struct();
            gl.valid = false;
            gl.hist_log_edges = [];
            gl.hist_y_max = 1;
            gl.kde_y_max = 1;
        end

        function edges = computeSharedEdges(allRadii)
            % MODEL: Compute log-space bin edges across all data (TERMINAL)
            log_all = log(allRadii);
            n_bins = 50;
            edges = linspace(min(log_all) - 0.1, max(log_all) + 0.1, n_bins + 1);
        end

        function max_count = computeMaxHistCount(results, edges)
            % MODEL: Find max histogram count across all cells (TERMINAL)
            max_count = 0;
            n_ord = length(results.scenario.ordinal_labels);
            n_nom = length(results.scenario.nominal_labels);
            for ord = 1:n_ord
                for nom = 1:n_nom
                    nom_field = results.scenario.nominal_fields{nom};
                    cs = results.analysisResults ...
                        .SubpopulationAnalysis(ord).(nom_field).ColonySet;
                    r = cs.raw_measurements;
                    if length(r) >= 2
                        [counts, ~] = histcounts(log(r), edges);
                        max_count = max(max_count, max(counts));
                    end
                end
            end
        end

        function max_density = computeMaxKDEDensity(results, edges)
            % MODEL: Find max KDE density across all cells (TERMINAL)
            max_density = 0;
            n_ord = length(results.scenario.ordinal_labels);
            n_nom = length(results.scenario.nominal_labels);
            for ord = 1:n_ord
                for nom = 1:n_nom
                    nom_field = results.scenario.nominal_fields{nom};
                    cs = results.analysisResults ...
                        .SubpopulationAnalysis(ord).(nom_field).ColonySet;
                    r = cs.raw_measurements;
                    if length(r) >= 2
                        kde_cell = computeLogKDE(r, edges);
                        if ~kde_cell.empty
                            max_density = max(max_density, max(kde_cell.density));
                        end
                    end
                end
            end
        end
    end
end
