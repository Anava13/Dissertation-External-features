function universal = makeUniversalConfig(n_colonies, v, detection_limit)
    % MODEL: Build the universal config block (TERMINAL)
    universal = struct();
    universal.n_colonies = n_colonies;
    universal.v = v;
    universal.detection_limit = detection_limit;
    universal.packing_density = 0.0113;
    universal.approx_threshold = 500;
    universal.min_kappa = 2;
end
