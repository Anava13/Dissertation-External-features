function results = runScenario(scenario)
    % CONTROLLER: Walk the scenario grid, simulate and analyze every cell,
    % return the unified results object.

    seedRNGIfRequested(scenario);
    results = initializeResultsObject(scenario);
    dataProvider = @(cellConfig, ord_idx, nom_idx) simulateColonySet(cellConfig);
    results = walkScenarioGrid(scenario, results, dataProvider);
    results = finalizeResultsMetadata(results);
end
