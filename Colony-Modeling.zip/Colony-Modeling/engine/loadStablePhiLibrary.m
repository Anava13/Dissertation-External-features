function library = loadStablePhiLibrary(filename)
    % MODEL: Load the stable-phi library from a .mat file (TERMINAL)
    %
    % filename: full path to the library file. The app and
    % run_all_figures pass library/stable_phi_library_V40.mat.

    if ~isfile(filename)
        error('loadStablePhiLibrary:FileNotFound', ...
            'Library file not found: %s', filename);
    end

    S = load(filename, 'library');

    if ~isfield(S, 'library')
        error('loadStablePhiLibrary:InvalidFile', ...
            'File %s does not contain a library variable', filename);
    end

    library = S.library;

    required_fields = {'x_grid', 'ceiling_radius', 'config', 'entries'};
    for i = 1:length(required_fields)
        if ~isfield(library, required_fields{i})
            error('loadStablePhiLibrary:MissingField', ...
                'Library is missing required field: %s', required_fields{i});
        end
    end

    fprintf('Loaded library from %s: %d entries, ceiling=%.1f um, v=%d\n', ...
        filename, length(library.entries), library.ceiling_radius, library.config.v);
end
