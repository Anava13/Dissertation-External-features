function scenario = buildMatchedFlatScenario(n_colonies, v, n_levels)
    % CONTROLLER: Build the MatchedFlat validation scenario
    %
    % Tests whether the geometric mean of per-round phi values predicts
    % the colony size produced by a non-stationary trajectory. Each
    % non-flat family from LibraryDiagnostic is paired with a flat
    % trajectory at phi = phi_geo, eps = 0.
    %
    % 10 nominal columns (5 original + 5 matched flat):
    %   1. LinearDecline          2. LinearDecline_MatchedFlat
    %   3. StepDecline            4. StepDecline_MatchedFlat
    %   5. Bottleneck             6. Bottleneck_MatchedFlat
    %   7. EarlyBranch            8. EarlyBranch_MatchedFlat
    %   9. LateBranch            10. LateBranch_MatchedFlat
    %
    % If phi_geo is the correct effective phi, the matched flat should
    % produce the same median colony size and library-reported phi as
    % the original. Where it doesn't, the discrepancy reveals what
    % phi_geo fails to capture.
    %
    % USAGE:
    %   scenario = buildMatchedFlatScenario();
    %   scenario = buildMatchedFlatScenario(1000, 40, 15);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end
    if nargin < 3 || isempty(n_levels),   n_levels = 15; end

    scenario = initializeShell(n_levels);
    scenario = populateGrid(scenario, n_colonies, v, n_levels);

    function scenario = initializeShell(n_levels)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(n_levels);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'MatchedFlatValidation');

        function labels = buildLabels(n_levels)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = { ...
                'LinearDecline', 'LinDecline_Flat', ...
                'StepDecline',   'StepDecline_Flat', ...
                'Bottleneck',    'Bottleneck_Flat', ...
                'EarlyBranch',   'EarlyBranch_Flat', ...
                'LateBranch',    'LateBranch_Flat'};
            labels.nominal_fields = { ...
                'linear_decline', 'linear_decline_flat', ...
                'step_decline',   'step_decline_flat', ...
                'bottleneck',     'bottleneck_flat', ...
                'early_branch',   'early_branch_flat', ...
                'late_branch',    'late_branch_flat'};
            labels.ordinal_display = cell(1, n_levels);
            for i = 1:n_levels
                labels.ordinal_display{i} = sprintf('level_%02d', i - 1);
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, n_levels)
        % SUB-CONTROLLER: Fill every cell with original + matched flat pairs
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;

        for level = 0:(n_levels - 1)
            ord_idx = level + 1;

            % LinearDecline pair
            [origCell, phi_geo] = buildLinearDeclineCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 1, origCell);
            scenario = addCellConfig(scenario, ord_idx, 2, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'linear_decline_flat', level));

            % StepDecline pair
            [origCell, phi_geo] = buildStepDeclineCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 3, origCell);
            scenario = addCellConfig(scenario, ord_idx, 4, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'step_decline_flat', level));

            % Bottleneck pair
            [origCell, phi_geo] = buildBottleneckCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 5, origCell);
            scenario = addCellConfig(scenario, ord_idx, 6, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'bottleneck_flat', level));

            % EarlyBranch pair
            [origCell, phi_geo] = buildEarlyBranchCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 7, origCell);
            scenario = addCellConfig(scenario, ord_idx, 8, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'early_branch_flat', level));

            % LateBranch pair
            [origCell, phi_geo] = buildLateBranchCell(level, phi_base, v, universal);
            scenario = addCellConfig(scenario, ord_idx, 9, origCell);
            scenario = addCellConfig(scenario, ord_idx, 10, ...
                buildMatchedFlatCell(phi_geo, v, universal, 'late_branch_flat', level));
        end

        %% ---- MATCHED FLAT BUILDER ----

        function cellConfig = buildMatchedFlatCell(phi_geo, v, universal, family_label, level)
            % SUB-CONTROLLER: Flat trajectory at phi_geo, eps = 0
            params = computeMatchedFlatParams(phi_geo, v);
            predictors = computeTrajectoryPredictors(params.p_traj);
            cellConfig = packMatchedFlatDiagnosticCell( ...
                params.p_traj, universal, family_label, level, predictors, phi_geo);

            function params = computeMatchedFlatParams(phi_geo, v)
                % MODEL: Constant phi at geometric mean value (TERMINAL)
                params = struct();
                params.p_traj = phi_geo * ones(1, v);
            end

            function cellConfig = packMatchedFlatDiagnosticCell( ...
                    p_traj, universal, family_label, level, predictors, phi_geo)
                % MODEL: Build matched flat cell with phi_geo logged (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    p_traj, zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'family', family_label, 'level', level, ...
                    'is_branched', false, ...
                    'phi_geo', phi_geo, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        %% ---- ORIGINAL FAMILY BUILDERS ----

        function [cellConfig, phi_geo] = buildLinearDeclineCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Linear decline from high to low, mean = phi_base
            p_traj = computeLinearDeclineTrajectory(level, phi_base, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'linear_decline', level, predictors, phi_geo, false);

            function p_traj = computeLinearDeclineTrajectory(level, phi_base, v)
                % MODEL: Linear ramp centered on phi_base (TERMINAL)
                delta = 0.005 * level;
                r = 1:v;
                p_traj = (phi_base + delta) - 2 * delta * (r - 1) / (v - 1);
            end
        end

        function [cellConfig, phi_geo] = buildStepDeclineCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Step function, high first half, low second half
            p_traj = computeStepDeclineTrajectory(level, phi_base, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'step_decline', level, predictors, phi_geo, false);

            function p_traj = computeStepDeclineTrajectory(level, phi_base, v)
                % MODEL: Step at midpoint, symmetric around phi_base (TERMINAL)
                delta = 0.005 * level;
                half = floor(v / 2);
                p_traj = [(phi_base + delta) * ones(1, half), ...
                          (phi_base - delta) * ones(1, v - half)];
            end
        end

        function [cellConfig, phi_geo] = buildBottleneckCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Transient low-phi window with full recovery
            p_traj = computeBottleneckTrajectory(level, phi_base, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packOriginalDiagnosticCell( ...
                p_traj, zeros(1, v), universal, ...
                'bottleneck', level, predictors, phi_geo, false);

            function p_traj = computeBottleneckTrajectory(level, phi_base, v)
                % MODEL: Phi drops during rounds 16-20 then recovers (TERMINAL)
                p_traj = phi_base * ones(1, v);
                bottleneck_phi = max(phi_base - 0.06 * level, 0.01);
                p_traj(16:20) = bottleneck_phi;
            end
        end

        function [cellConfig, phi_geo] = buildEarlyBranchCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Branch event at round 5
            rp = computeEarlyBranchParams(level, phi_base);
            p_eff = computeBranchEffectiveTrajectory(rp, v);
            phi_geo = computeGeometricMean(p_eff);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchDiagnosticCell( ...
                rp, universal, 'early_branch', level, predictors, phi_geo, v);

            function rp = computeEarlyBranchParams(level, phi_base)
                % MODEL: Early branch parameters (TERMINAL)
                rp = struct();
                rp.p_base = phi_base;
                rp.p_post = phi_base + 0.01 * level;
                rp.event_round = 5;
                rp.p_event = 0.40;
            end
        end

        function [cellConfig, phi_geo] = buildLateBranchCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Branch event at round 35
            rp = computeLateBranchParams(level, phi_base);
            p_eff = computeBranchEffectiveTrajectory(rp, v);
            phi_geo = computeGeometricMean(p_eff);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchDiagnosticCell( ...
                rp, universal, 'late_branch', level, predictors, phi_geo, v);

            function rp = computeLateBranchParams(level, phi_base)
                % MODEL: Late branch parameters (TERMINAL)
                rp = struct();
                rp.p_base = phi_base;
                rp.p_post = phi_base + 0.01 * level;
                rp.event_round = 35;
                rp.p_event = 0.40;
            end
        end

        %% ---- SHARED HELPERS ----

        function p_eff = computeBranchEffectiveTrajectory(rp, v)
            % MODEL: Population-mean phi(r) for branching scenario (TERMINAL)
            r = 1:v;
            p_eff = rp.p_base * ones(1, v);
            mask = r >= rp.event_round;
            p_eff(mask) = rp.p_event * rp.p_post + (1 - rp.p_event) * rp.p_base;
        end

        function phi_geo = computeGeometricMean(p_traj)
            % MODEL: Geometric mean of per-round phi values (TERMINAL)
            phi_geo = exp(mean(log(p_traj)));
        end

        function cellConfig = packOriginalDiagnosticCell( ...
                p_traj, eps_traj, universal, family_label, level, predictors, phi_geo, is_branched)
            % MODEL: Build single-pool diagnostic cell with both means logged (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;
            cellConfig.pools = buildPool( ...
                p_traj, eps_traj, ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig.branch_events = [];
            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', is_branched, ...
                'phi_geo', phi_geo, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end

        function cellConfig = packBranchDiagnosticCell( ...
                rp, universal, family_label, level, predictors, phi_geo, v)
            % MODEL: Build two-pool branch diagnostic cell (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;

            base_pool = buildPool( ...
                rp.p_base * ones(1, v), zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            event_pool = buildPool( ...
                rp.p_post * ones(1, v), zeros(1, v), ...
                'BranchLineage', [0.75, 0.55, 0.10], [], 0);

            cellConfig.pools = [base_pool, event_pool];
            cellConfig.branch_events = buildBranchEvent( ...
                1, 'dividing', 2, 'per_colony', rp.p_event, [rp.event_round]);

            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', true, ...
                'p_base', rp.p_base, 'p_post', rp.p_post, ...
                'event_round', rp.event_round, 'p_event', rp.p_event, ...
                'phi_geo', phi_geo, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end
    end
end
