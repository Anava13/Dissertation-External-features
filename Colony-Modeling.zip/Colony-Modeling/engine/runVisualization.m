function runVisualization(results, OutputFigures, scenarioName)
    % CONTROLLER: Orchestrate interactive viewer and PDF export
    buildResultsViewer(results);
    exportResultsPDF(results, OutputFigures, scenarioName);
end
