function scenario = buildTrajectoryStressScenario(n_colonies, v, n_levels)
    % CONTROLLER: Build the trajectory-stress sweep scenario
    %
    % Five families on the nominal axis (Ramp, Sinusoid, Step, Plateau, Rescue).
    % Magnitude levels on the ordinal axis. Each cell stores its precomputed
    % deviation predictors in log_params so post-processing can pair
    % library stress with input predictors.
    %
    % USAGE:
    %   scenario = buildTrajectoryStressScenario();
    %   scenario = buildTrajectoryStressScenario(1000, 40, 15);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end
    if nargin < 3 || isempty(n_levels),   n_levels = 15; end

    scenario = initializeShell(n_levels);
    scenario = populateGrid(scenario, n_colonies, v, n_levels);

    function scenario = initializeShell(n_levels)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(n_levels);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'TrajectoryStressSweep');

        function labels = buildLabels(n_levels)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = {'Ramp', 'Sinusoid', 'Step', 'Plateau', 'Rescue'};
            labels.nominal_fields  = {'ramp', 'sinusoid', 'step', 'plateau', 'rescue'};
            labels.ordinal_display = cell(1, n_levels);
            for i = 1:n_levels
                labels.ordinal_display{i} = sprintf('level_%02d', i - 1);
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, n_levels)
        % SUB-CONTROLLER: Fill every cell
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;

        for level = 0:(n_levels - 1)
            ord_idx = level + 1;
            scenario = addCellConfig(scenario, ord_idx, 1, ...
                buildRampCell(level, phi_base, v, universal));
            scenario = addCellConfig(scenario, ord_idx, 2, ...
                buildSinusoidCell(level, phi_base, v, universal));
            scenario = addCellConfig(scenario, ord_idx, 3, ...
                buildStepCell(level, phi_base, v, universal));
            scenario = addCellConfig(scenario, ord_idx, 4, ...
                buildPlateauCell(level, phi_base, v, universal));
            scenario = addCellConfig(scenario, ord_idx, 5, ...
                buildRescueCell(level, phi_base, v, universal));
        end

        function cellConfig = buildRampCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Ramp family cell
            p_traj = computeRampTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolStressCell( ...
                p_traj, universal, 'ramp', level, predictors, v);

            function p_traj = computeRampTrajectory(level, phi_base, v)
                % MODEL: Linear ramp (TERMINAL)
                delta = 0.01 * level;
                r = 1:v;
                p_traj = phi_base + delta * (1 - 2 * (r - 1) / (v - 1));
            end
        end

        function cellConfig = buildSinusoidCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Sinusoid family cell
            p_traj = computeSinusoidTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolStressCell( ...
                p_traj, universal, 'sinusoid', level, predictors, v);

            function p_traj = computeSinusoidTrajectory(level, phi_base, v)
                % MODEL: Sinusoid with one full cycle (TERMINAL)
                A = 0.01 * level;
                period = v / 2;
                r = 1:v;
                p_traj = phi_base + A * sin(2 * pi * r / period);
            end
        end

        function cellConfig = buildStepCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Step family cell
            p_traj = computeStepTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolStressCell( ...
                p_traj, universal, 'step', level, predictors, v);

            function p_traj = computeStepTrajectory(level, phi_base, v)
                % MODEL: Single mid-run step (TERMINAL)
                delta = 0.01 * level;
                half = floor(v / 2);
                p_traj = [(phi_base + delta) * ones(1, half), ...
                          (phi_base - delta) * ones(1, v - half)];
            end
        end

        function cellConfig = buildPlateauCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Plateau-decline-plateau family cell
            p_traj = computePlateauTrajectory(level, phi_base, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packSinglePoolStressCell( ...
                p_traj, universal, 'plateau', level, predictors, v);

            function p_traj = computePlateauTrajectory(level, phi_base, v)
                % MODEL: Plateau, linear decline, floor (TERMINAL)
                floor_val = max(phi_base - 0.05 * level, 0);
                phase1_end = round(v * 0.20);
                phase2_end = round(v * 0.45);
                p_traj = zeros(1, v);
                p_traj(1:phase1_end) = phi_base;
                phase2_len = phase2_end - phase1_end;
                if phase2_len > 0
                    p_traj(phase1_end + 1 : phase2_end) = ...
                        linspace(phi_base, floor_val, phase2_len);
                end
                p_traj(phase2_end + 1 : v) = floor_val;
            end
        end

        function cellConfig = buildRescueCell(level, phi_base, v, universal)
            % SUB-CONTROLLER: Rescue branch family cell
            rp = computeRescueParams(level, phi_base, v);
            p_eff = computeRescueEffectiveTrajectory(rp, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packRescueStressCell(rp, p_eff, universal, level, predictors, v);

            function rp = computeRescueParams(level, phi_base, v)
                % MODEL: Rescue parameters from magnitude level (TERMINAL)
                rp = struct();
                rp.p_base      = phi_base;
                rp.p_post      = phi_base + 0.01 * level;
                rp.event_round = round(v / 2);
                rp.p_event     = 0.5;
            end

            function p_eff = computeRescueEffectiveTrajectory(rp, v)
                % MODEL: Population-mean phi(r) over rescue branching (TERMINAL)
                r = 1:v;
                p_eff = rp.p_base * ones(1, v);
                mask = r >= rp.event_round;
                p_eff(mask) = rp.p_event * rp.p_post + (1 - rp.p_event) * rp.p_base;
            end

            function cellConfig = packRescueStressCell(rp, p_eff, universal, level, predictors, v)
                % MODEL: Build two-pool rescue cell with stress metadata (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool( ...
                    rp.p_base * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                event_pool = buildPool( ...
                    rp.p_post * ones(1, v), zeros(1, v), ...
                    'mutant lineage', [0.75, 0.55, 0.10], [], 0);

                cellConfig.pools = [base_pool, event_pool];
                cellConfig.branch_events = buildBranchEvent( ...
                    1, 'dividing', 2, 'per_colony', rp.p_event, [rp.event_round]);

                cellConfig.log_params = struct( ...
                    'family', 'rescue', 'level', level, ...
                    'is_branched', true, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        function cellConfig = packSinglePoolStressCell(p_traj, universal, family_label, level, predictors, v)
            % MODEL: Build single-pool stress cell with predictors (TERMINAL)
            cellConfig = struct();
            cellConfig.universal = universal;
            cellConfig.pools = buildPool( ...
                p_traj, zeros(1, v), ...
                'Base', [0.30, 0.45, 0.75], [], 1);
            cellConfig.branch_events = [];
            cellConfig.log_params = struct( ...
                'family', family_label, 'level', level, ...
                'is_branched', false, ...
                'phi_avg', predictors.phi_avg, ...
                'flat_L2', predictors.flat_L2, ...
                'weighted_L2', predictors.weighted_L2);
        end
    end
end
