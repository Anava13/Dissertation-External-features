function results = initializeResultsObject(scenario)
    % SUB-CONTROLLER: Build empty results shell

    analysisResults = buildAnalysisResultsShell(scenario);
    simTracking = buildSimTrackingShell(scenario);
    runMetadata = buildRunMetadataShell(scenario);
    results = packResultsShell(scenario, analysisResults, simTracking, runMetadata);

    function analysisResults = buildAnalysisResultsShell(scenario)
        % MODEL: Build empty QC-compatible analysisResults (TERMINAL)
        options = scenario.analysis_options;

        metadata = struct();
        metadata.analysis_timestamp = string(datetime('now'));
        metadata.Max_Components = options.max_components;
        metadata.Connection_Threshold = options.connection_threshold;
        metadata.size_weight = options.connection_cost_bias;
        metadata.normalization_method = options.normalization;
        metadata.mixture_distribution = options.mixture_distribution;
        metadata.simulation_metadata = struct();
        metadata.simulation_metadata.scenario_name = scenario.scenario_name;
        metadata.simulation_metadata.rng_seed = options.rng_seed;

        n_ord = length(scenario.ordinal_labels);
        n_nom = length(scenario.nominal_labels);

        SubpopulationAnalysis = repmat(struct(), 1, n_ord);
        for ord = 1:n_ord
            for nom = 1:n_nom
                nom_field = scenario.nominal_fields{nom};
                SubpopulationAnalysis(ord).(nom_field) = struct();
                SubpopulationAnalysis(ord).(nom_field).ColonySet = struct();
                SubpopulationAnalysis(ord).(nom_field).Connections = [];
            end
        end

        analysisResults = struct();
        analysisResults.metadata = metadata;
        analysisResults.SubpopulationAnalysis = SubpopulationAnalysis;
    end

    function simTracking = buildSimTrackingShell(scenario)
        % MODEL: Build empty simTracking struct (TERMINAL)
        n_ord = length(scenario.ordinal_labels);
        n_nom = length(scenario.nominal_labels);
        simTracking = repmat(struct(), 1, n_ord);
        for ord = 1:n_ord
            for nom = 1:n_nom
                nom_field = scenario.nominal_fields{nom};
                simTracking(ord).(nom_field) = struct();
            end
        end
    end

    function runMetadata = buildRunMetadataShell(scenario)
        % MODEL: Build runner metadata shell (TERMINAL)
        runMetadata = struct();
        runMetadata.scenario_name = scenario.scenario_name;
        runMetadata.start_time = datetime('now');
        runMetadata.end_time = NaT;
        runMetadata.elapsed_seconds = NaN;
        runMetadata.n_cells = length(scenario.ordinal_labels) * ...
            length(scenario.nominal_labels);
        runMetadata.n_colonies_total = 0;
        runMetadata.rng_seed = scenario.analysis_options.rng_seed;
    end

    function results = packResultsShell(scenario, analysisResults, simTracking, runMetadata)
        % MODEL: Pack the top-level results object (TERMINAL)
        results = struct();
        results.scenario = scenario;
        results.analysisResults = analysisResults;
        results.simTracking = simTracking;
        results.metadata = runMetadata;
    end
end
