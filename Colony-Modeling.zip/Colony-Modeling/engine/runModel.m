function results = runModel(scenarioBuilder, library, varargin)
    % CONTROLLER: Build scenario, apply standard analysis options, and
    % dispatch to the appropriate runner based on whether the scenario
    % is real data or simulation-based.
    %
    % Inputs:
    %   scenarioBuilder : function handle
    %                       (e.g., @buildSenescenceScenario, @buildRealDataScenario)
    %   library         : library object
    %   varargin        : optional arguments forwarded to scenarioBuilder
    %                       (e.g., n_colonies for sim builders,
    %                        AllMeasures for buildRealDataScenario)
    %
    % Examples:
    %   runModel(@buildSenescenceScenario, lib, 1000)
    %   runModel(@buildRealDataScenario, lib, AllMeasures)

    scenario = scenarioBuilder(varargin{:});
    scenario = applyStandardAnalysisOptions(scenario, library);

    if isfield(scenario, 'is_real_data') && scenario.is_real_data
        results = runRealData(scenario);
    else
        results = runScenario(scenario);
    end

    function scenario = applyStandardAnalysisOptions(scenario, library)
        % MODEL: Inject library and standard mixture distributions (TERMINAL)
        scenario.analysis_options.mixture_distribution = ["LogNormal", "Library"];
        scenario.analysis_options.library = library;
    end
end
