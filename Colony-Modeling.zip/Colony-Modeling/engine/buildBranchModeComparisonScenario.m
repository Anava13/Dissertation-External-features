function scenario = buildBranchModeComparisonScenario(n_colonies, v)
    % CONTROLLER: Build the per-colony vs per-cell branching comparison
    %
    % Tests how branching mode (per-colony vs per-cell) affects bimodality
    % structure at matched event parameters. Both modes use early branch
    % timing (round 5), phi_baseline = 0.75, phi_branch = 0.85, eps = 0.
    %
    % Grid shape:
    %   Nominal axis (columns): 2 branching modes
    %     1. per_colony
    %     2. per_cell
    %   Ordinal axis (rows): 7 event probability values
    %     p = [0.001, 0.005, 0.01, 0.05, 0.10, 0.20, 0.40]
    %
    % Per-colony: at round 5, each colony rolls once. If successful,
    %   exactly one dividing cell transfers to the branch pool.
    % Per-cell: at round 5, each dividing cell independently rolls.
    %   Multiple cells can transfer in one round.
    %
    % At the same nominal p, per-cell transfers far more cells than
    % per-colony (which transfers at most 1). The sweep includes small
    % p values (0.001-0.01) relevant to per-cell biological rates
    % (e.g., HR probability per cell per round) and larger values
    % (0.10-0.40) relevant to per-colony event frequencies.
    %
    % USAGE:
    %   scenario = buildBranchModeComparisonScenario();
    %   scenario = buildBranchModeComparisonScenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    p_values = [0.001, 0.005, 0.01, 0.05, 0.10, 0.20, 0.40];

    scenario = initializeShell(p_values);
    scenario = populateGrid(scenario, n_colonies, v, p_values);

    function scenario = initializeShell(p_values)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(p_values);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BranchModeComparison');

        function labels = buildLabels(p_values)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            labels.nominal_display = {'PerColony', 'PerCell'};
            labels.nominal_fields  = {'per_colony', 'per_cell'};
            n_p = length(p_values);
            labels.ordinal_display = cell(1, n_p);
            for i = 1:n_p
                labels.ordinal_display{i} = sprintf('p=%.4f', p_values(i));
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, p_values)
        % SUB-CONTROLLER: Fill every cell
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;
        phi_branch = 0.85;
        event_round = 5;

        for ord_idx = 1:length(p_values)
            p_val = p_values(ord_idx);

            scenario = addCellConfig(scenario, ord_idx, 1, ...
                buildBranchCell(phi_base, phi_branch, event_round, ...
                    p_val, 'per_colony', universal, v));

            scenario = addCellConfig(scenario, ord_idx, 2, ...
                buildBranchCell(phi_base, phi_branch, event_round, ...
                    p_val, 'per_cell', universal, v));
        end

        function cellConfig = buildBranchCell(phi_base, phi_branch, ...
                event_round, p_event, mode, universal, v)
            % SUB-CONTROLLER: Build a two-pool branching cell
            params = assembleBranchParams( ...
                phi_base, phi_branch, event_round, p_event, mode);
            p_eff = computeEffectiveTrajectory(params, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchCell(params, universal, predictors, v);

            function params = assembleBranchParams( ...
                    phi_base, phi_branch, event_round, p_event, mode)
                % MODEL: Branch parameters (TERMINAL)
                params = struct();
                params.p_base = phi_base;
                params.p_post = phi_branch;
                params.event_round = event_round;
                params.p_event = p_event;
                params.mode = mode;
            end

            function p_eff = computeEffectiveTrajectory(params, v)
                % MODEL: Population-mean phi(r) (TERMINAL)
                r = 1:v;
                p_eff = params.p_base * ones(1, v);
                mask = r >= params.event_round;
                p_eff(mask) = params.p_event * params.p_post + ...
                    (1 - params.p_event) * params.p_base;
            end

            function cellConfig = packBranchCell(params, universal, predictors, v)
                % MODEL: Assemble two-pool branch cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool( ...
                    params.p_base * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                event_pool = buildPool( ...
                    params.p_post * ones(1, v), zeros(1, v), ...
                    'BranchLineage', [0.75, 0.55, 0.10], [], 0);

                cellConfig.pools = [base_pool, event_pool];
                cellConfig.branch_events = buildBranchEvent( ...
                    1, 'dividing', 2, params.mode, ...
                    params.p_event, [params.event_round]);

                cellConfig.log_params = struct( ...
                    'mode', params.mode, ...
                    'p_base', params.p_base, ...
                    'p_post', params.p_post, ...
                    'event_round', params.event_round, ...
                    'p_event', params.p_event, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end
    end
end
