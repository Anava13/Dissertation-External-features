function results = processSingleGridCell(results, scenario, ord_idx, nom_idx, dataProvider)
% SUB-CONTROLLER: Obtain simData from dataProvider and analyze one grid cell

cellConfig = pullCellConfig(scenario, ord_idx, nom_idx);
simData = dataProvider(cellConfig, ord_idx, nom_idx);
colonySet = analyzeColonySet(simData.radii, scenario.analysis_options);
results = stowGridCellResults(results, scenario, colonySet, simData, ord_idx, nom_idx);
printGridCellStatus(ord_idx, scenario.nominal_fields{nom_idx}, ...
    simData, colonySet, cellConfig);
           function cellConfig = pullCellConfig(scenario, ord_idx, nom_idx)
            % MODEL: Look up the cellConfig (TERMINAL)
            nom_field = scenario.nominal_fields{nom_idx};
            cellConfig = scenario.config(ord_idx).(nom_field);
        end

        function results = stowGridCellResults(results, scenario, colonySet, simData, ord_idx, nom_idx)
            % MODEL: Attach grid coords, store everything in results (TERMINAL)
            nom_field = scenario.nominal_fields{nom_idx};
            colonySet.nominal_index = nom_field;
            colonySet.ordinal_index = ord_idx;
            colonySet.nominal_display = scenario.nominal_labels{nom_idx};
            colonySet.ordinal_display = scenario.ordinal_labels{ord_idx};
            colonySet.tracking = simData.tracking;
            results.analysisResults.SubpopulationAnalysis(ord_idx).(nom_field).ColonySet = colonySet;
            results.simTracking(ord_idx).(nom_field) = simData.tracking;
            results.metadata.n_colonies_total = ...
                results.metadata.n_colonies_total + length(simData.radii);
        end

        function printGridCellStatus(ord_idx, nom_field, simData, colonySet, cellConfig)
% SUB-CONTROLLER: Print per-cell status with log_params and optional ground truth

n_det = length(simData.radii);
k = extractOptimalK(colonySet);
nModes = extractModeCount(colonySet);
methodInfo = extractMethodInfo(colonySet);
libraryAdequacy = extractLibraryAdequacy(colonySet);
componentDetails = extractComponentDetails(colonySet, k);

printCellHeader(ord_idx, nom_field, n_det, k, nModes, ...
    methodInfo, libraryAdequacy, cellConfig.log_params);
printComponentLines(componentDetails);

if isfield(cellConfig, 'ground_truth') && ~isempty(cellConfig.ground_truth)
    printGroundTruthComparison(cellConfig.ground_truth, colonySet);
end

function k = extractOptimalK(colonySet)
    % MODEL: Pull optimal_components (TERMINAL)
    if isfield(colonySet, 'gmm_results') && ...
            isfield(colonySet.gmm_results, 'optimal_components')
        k = colonySet.gmm_results.optimal_components;
    else
        k = 0;
    end
end

function nModes = extractModeCount(colonySet)
    % MODEL: Pull mode count from mode_detection (TERMINAL)
    if isfield(colonySet, 'mode_detection') && ...
            isfield(colonySet.mode_detection, 'n_modes')
        nModes = colonySet.mode_detection.n_modes;
    else
        nModes = NaN;
    end
end

function info = extractMethodInfo(colonySet)
    % MODEL: Pull method selection and AIC info (TERMINAL)
    info = struct();
    info.selected = 'Unknown';
    info.selected_aic = NaN;
    info.alternatives = struct();

    if isfield(colonySet, 'selected_method')
        if ischar(colonySet.selected_method)
            info.selected = colonySet.selected_method;
        else
            info.selected = char(colonySet.selected_method);
        end
    end

    if isfield(colonySet, 'gmm_results') && ...
            isfield(colonySet.gmm_results, 'fitted_model') && ...
            isfield(colonySet.gmm_results.fitted_model, 'final_aic')
        info.selected_aic = colonySet.gmm_results.fitted_model.final_aic;
    end

    if isfield(colonySet, 'alternative_fits')
        altNames = fieldnames(colonySet.alternative_fits);
        for i = 1:length(altNames)
            alt = colonySet.alternative_fits.(altNames{i});
            if isfield(alt, 'aic')
                info.alternatives.(altNames{i}) = alt.aic;
            end
        end
    end
end

function details = extractComponentDetails(colonySet, k)
    % MODEL: Pull per-component distribution info (TERMINAL)
    details = repmat(struct('weight', NaN, 'dist_type', 'N/A', ...
        'param_str', ''), 1, max(k, 1));
    if k == 0, return; end

    hasComponents = isfield(colonySet, 'gmm_results') && ...
        isfield(colonySet.gmm_results, 'components');
    hasSubpops = isfield(colonySet, 'subpopulations') && ...
        length(colonySet.subpopulations) >= k;

    for c = 1:k
        if hasComponents && length(colonySet.gmm_results.components) >= c
            details(c).weight = colonySet.gmm_results.components(c).weight;
        end
        if hasSubpops
            sp = colonySet.subpopulations(c);
            if isfield(sp, 'best_distribution') && ~isempty(sp.best_distribution)
                details(c).dist_type = char(sp.best_distribution);
            end
            details(c).param_str = buildParamString(sp, details(c).dist_type);
        end
    end

    function s = buildParamString(sp, dist_type)
        % MODEL: Format parameter string (TERMINAL)
        s = '';
        if ~isfield(sp, 'distribution_tests'), return; end
        dt = sp.distribution_tests;
        switch dist_type
            case 'Normal'
                if isfield(dt, 'normal') && isfield(dt.normal, 'final_mean')
                    s = sprintf('mu=%.1f sig=%.1f', ...
                        dt.normal.final_mean, dt.normal.final_sigma);
                end
            case 'LogNormal'
                if isfield(dt, 'lognormal') && isfield(dt.lognormal, 'fitted_median')
                    s = sprintf('med=%.1f sig=%.2f', ...
                        dt.lognormal.fitted_median, dt.lognormal.sigma_parameter);
                end
            case 'Library'
                if isfield(dt, 'library') && isfield(dt.library, 'phi_parameter')
                    s = sprintf('phi=%.2f eps=%.2f', ...
                        dt.library.phi_parameter, dt.library.eps_parameter);
                end
            case 'Non-parametric'
                if isfield(dt, 'nonparametric') && isfield(dt.nonparametric, 'peak_estimate')
                    s = sprintf('peak=%.1f', dt.nonparametric.peak_estimate);
                end
            case 'Insufficient_Data'
                if isfield(dt, 'insufficient_data')
                    s = sprintf('n=%d', dt.insufficient_data.sample_size);
                end
        end
    end
end

function printCellHeader(ord_idx, nom_field, n_det, k, nModes, methodInfo, lib, log_params)
    % MODEL: Print main status line with log_params (TERMINAL)

    paramStr = formatLogParams(log_params);

    altStr = '';
    altNames = fieldnames(methodInfo.alternatives);
    for i = 1:length(altNames)
        altAic = methodInfo.alternatives.(altNames{i});
        altStr = sprintf('%s %s:%.0f', altStr, altNames{i}, altAic);
    end

    if isnan(nModes)
        modeStr = 'modes=?';
    else
        modeStr = sprintf('modes=%d', nModes);
    end

    if isempty(altStr)
        mainLine = sprintf('  [ord=%d %s] n=%d k=%d %s  method=%s AIC=%.0f  {%s}', ...
            ord_idx, nom_field, n_det, k, modeStr, ...
            methodInfo.selected, methodInfo.selected_aic, paramStr);
    else
        mainLine = sprintf('  [ord=%d %s] n=%d k=%d %s  method=%s AIC=%.0f (vs%s)  {%s}', ...
            ord_idx, nom_field, n_det, k, modeStr, ...
            methodInfo.selected, methodInfo.selected_aic, altStr, paramStr);
    end

    if lib.present && ~isnan(lib.emd) && ~isnan(lib.cutoff)
        if lib.passed, verdict = 'PASS'; else, verdict = 'FAIL'; end
        qualityStr = '';
        if ~isnan(lib.quality_shape) && ~isnan(lib.quality_scale)
            qualityStr = sprintf(' Qshape=%.2f Qscale=%.2f', ...
                lib.quality_shape, lib.quality_scale);
        elseif ~isnan(lib.quality_shape)
            qualityStr = sprintf(' Qshape=%.2f', lib.quality_shape);
        elseif ~isnan(lib.quality_scale)
            qualityStr = sprintf(' Qscale=%.2f', lib.quality_scale);
        end
        libLine = sprintf('  Library: phi=%.2f eps=%.2f EMD=%.1fum vs cutoff %.1fum %s%s', ...
            lib.phi, lib.eps, lib.emd, lib.cutoff, verdict, qualityStr);
        fprintf('%s\n%s\n', mainLine, libLine);
    else
        fprintf('%s\n', mainLine);
    end

    function paramStr = formatLogParams(log_params)
        % MODEL: Format log_params as compact key=value string (TERMINAL)
        paramStr = '';
        fields = fieldnames(log_params);
        for i = 1:length(fields)
            val = log_params.(fields{i});
            if i > 1, paramStr = [paramStr ', ']; end %#ok<AGROW>
            if islogical(val)
                paramStr = sprintf('%s%s=%d', paramStr, fields{i}, val);
            elseif isnumeric(val) && isscalar(val)
                if val == round(val) && abs(val) < 1e6
                    paramStr = sprintf('%s%s=%d', paramStr, fields{i}, val);
                else
                    paramStr = sprintf('%s%s=%.4g', paramStr, fields{i}, val);
                end
            elseif ischar(val) || isstring(val)
                paramStr = sprintf('%s%s=%s', paramStr, fields{i}, char(val));
            end
        end
    end
end

function printComponentLines(details)
    % MODEL: Print one line per component (TERMINAL)
    for c = 1:length(details)
        if isnan(details(c).weight), continue; end
        fprintf('    Comp%d: w=%.2f %s %s\n', ...
            c, details(c).weight, details(c).dist_type, details(c).param_str);
    end
end

function printGroundTruthComparison(ground_truth, colonySet)
    % MODEL: Print generic ground truth vs library prediction (TERMINAL)
    if ~isfield(ground_truth, 'phi') || ~isfield(ground_truth, 'epsilon')
        return;
    end
    hasBlobs = isfield(colonySet, 'gmm_results') && ...
        isfield(colonySet.gmm_results, 'fitted_model') && ...
        isfield(colonySet.gmm_results.fitted_model, 'library_blobs') && ...
        ~isempty(colonySet.gmm_results.fitted_model.library_blobs) && ...
        isfield(colonySet.gmm_results.fitted_model.library_blobs, 'centroids_phi') && ...
        ~isempty(colonySet.gmm_results.fitted_model.library_blobs.centroids_phi);
    if ~hasBlobs, return; end

    truth_phi = ground_truth.phi;
    truth_eps = ground_truth.epsilon;
    pred_phi = colonySet.gmm_results.fitted_model.library_blobs.centroids_phi(1);
    pred_eps = colonySet.gmm_results.fitted_model.library_blobs.centroids_eps(1);
    fprintf('    truth=(%.2f,%.2f) pred=(%.2f,%.2f) dphi=%+.3f deps=%+.3f\n', ...
        truth_phi, truth_eps, pred_phi, pred_eps, ...
        pred_phi - truth_phi, pred_eps - truth_eps);
end
end
   
end
