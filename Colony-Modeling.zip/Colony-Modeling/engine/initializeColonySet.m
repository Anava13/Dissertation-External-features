function colonySet = initializeColonySet(rawMeasurements)
    % SUB-CONTROLLER: Build empty colony set with raw data
    cleaned = cleanRawMeasurements(rawMeasurements);
    colonySet = buildEmptyColonySet(cleaned);

    function cleaned = cleanRawMeasurements(raw)
        % MODEL: Remove NaN and ensure column vector (TERMINAL)
        raw = raw(:);
        cleaned = raw(~isnan(raw));
    end

    function colonySet = buildEmptyColonySet(measurements)
        % MODEL: Initialize colony set struct (TERMINAL)
        colonySet = struct();
        colonySet.raw_measurements = measurements;
        colonySet.colony_count = length(measurements);
        colonySet.gmm_results = struct();
        colonySet.subpopulations = struct([]);
        colonySet.subpopulation_count = NaN;
        colonySet.dominant_subpopulation_barcode = "";
        colonySet.total_weight_check = NaN;
    end
end
