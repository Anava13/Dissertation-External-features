function scenario = buildSampleSizeSweepScenario(v)
    % CONTROLLER: Build the sample size sweep scenario
    %
    % Tests how colony count affects the Bernoulli noise floor in
    % library-reported epsilon. All conditions use flat phi = 0.75,
    % eps = 0. The only variable is the number of colonies simulated.
    %
    % Grid shape:
    %   Nominal axis (columns): 6 colony counts
    %     N = 100, 250, 500, 1000, 2000, 5000
    %   Ordinal axis (rows): 3 phi values
    %     phi = 0.65, 0.75, 0.85
    %     (tests whether the noise floor depends on phi)
    %
    % USAGE:
    %   scenario = buildSampleSizeSweepScenario();
    %   scenario = buildSampleSizeSweepScenario(40);

    if nargin < 1 || isempty(v), v = 40; end

    colony_counts = [100, 250, 500, 1000, 2000, 5000];
    phi_values = [0.65, 0.75, 0.85];

    scenario = initializeShell(colony_counts, phi_values);
    scenario = populateGrid(scenario, v, colony_counts, phi_values);

    function scenario = initializeShell(colony_counts, phi_values)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(colony_counts, phi_values);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'SampleSizeSweep');

        function labels = buildLabels(colony_counts, phi_values)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            n_counts = length(colony_counts);
            labels.nominal_display = cell(1, n_counts);
            labels.nominal_fields = cell(1, n_counts);
            for i = 1:n_counts
                labels.nominal_display{i} = sprintf('N=%d', colony_counts(i));
                labels.nominal_fields{i} = sprintf('N_%04d', colony_counts(i));
            end
            n_phi = length(phi_values);
            labels.ordinal_display = cell(1, n_phi);
            for i = 1:n_phi
                labels.ordinal_display{i} = sprintf('phi=%.2f', phi_values(i));
            end
        end
    end

    function scenario = populateGrid(scenario, v, colony_counts, phi_values)
        % SUB-CONTROLLER: Fill every cell
        n_counts = length(colony_counts);
        n_phi = length(phi_values);

        for ord_idx = 1:n_phi
            for nom_idx = 1:n_counts
                cellConfig = buildFlatCell( ...
                    phi_values(ord_idx), colony_counts(nom_idx), v);
                scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig);
            end
        end

        function cellConfig = buildFlatCell(phi, n_colonies, v)
            % SUB-CONTROLLER: Build one flat cell at specified colony count
            universal = makeUniversalConfig(n_colonies, v, 50);
            cellConfig = packFlatCell(phi, universal, n_colonies, v);

            function cellConfig = packFlatCell(phi, universal, n_colonies, v)
                % MODEL: Build flat cell with sample size metadata (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    phi * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'phi', phi, ...
                    'n_colonies', n_colonies, ...
                    'epsilon', 0);
                cellConfig.ground_truth = struct( ...
                    'phi', phi, ...
                    'epsilon', 0);
            end
        end
    end
end
