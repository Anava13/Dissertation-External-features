function scenario = buildBottleneckTimingSweepScenario(n_colonies, v)
    % CONTROLLER: Build the bottleneck timing sweep scenario
    %
    % Tests whether the geometric mean of per-round phi values correctly
    % predicts colony size when the TIMING of a concentrated failure
    % changes but phi_geo stays constant.
    %
    % All conditions use the same 5-round bottleneck window at the same
    % reduced phi, but the window is placed at different positions in
    % the growth trajectory. Because the bottleneck phi and duration
    % are identical, phi_geo is identical across all timing positions.
    % If phi_geo fully determines colony size, all positions should
    % produce the same median colony size. If timing matters independently,
    % early bottlenecks (which deplete the compounding base before most
    % growth occurs) should produce smaller colonies than late bottlenecks.
    %
    % Grid shape:
    %   Nominal axis (columns): 7 timing positions x 2 (original + matched flat)
    %     Positions: rounds 1-5, 6-10, 11-15, 16-20, 21-25, 26-30, 31-35
    %     Each paired with a flat trajectory at phi = phi_geo
    %   Ordinal axis (rows): 5 severity levels
    %     Bottleneck phi = 0.75 - 0.10 * level (levels 1-5)
    %     Level 0: no bottleneck (all flat at 0.75, calibration row)
    %
    % USAGE:
    %   scenario = buildBottleneckTimingSweepScenario();
    %   scenario = buildBottleneckTimingSweepScenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    timing_starts = [1, 6, 11, 16, 21, 26, 31];
    window_width = 5;
    n_timings = length(timing_starts);
    n_levels = 6;

    scenario = initializeShell(timing_starts, n_levels);
    scenario = populateGrid(scenario, n_colonies, v, timing_starts, window_width, n_levels);

    function scenario = initializeShell(timing_starts, n_levels)
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels(timing_starts, n_levels);
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BottleneckTimingSweep');

        function labels = buildLabels(timing_starts, n_levels)
            % MODEL: Build display labels (TERMINAL)
            labels = struct();
            n_timings = length(timing_starts);
            n_cols = 2 * n_timings;
            labels.nominal_display = cell(1, n_cols);
            labels.nominal_fields = cell(1, n_cols);
            for i = 1:n_timings
                r_start = timing_starts(i);
                labels.nominal_display{2*i - 1} = sprintf('BN_r%02d', r_start);
                labels.nominal_fields{2*i - 1}  = sprintf('bn_r%02d', r_start);
                labels.nominal_display{2*i}     = sprintf('BN_r%02d_Flat', r_start);
                labels.nominal_fields{2*i}      = sprintf('bn_r%02d_flat', r_start);
            end
            labels.ordinal_display = cell(1, n_levels);
            for i = 1:n_levels
                labels.ordinal_display{i} = sprintf('level_%02d', i - 1);
            end
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v, timing_starts, window_width, n_levels)
        % SUB-CONTROLLER: Fill every cell
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_base = 0.75;
        n_timings = length(timing_starts);

        for level = 0:(n_levels - 1)
            ord_idx = level + 1;
            bottleneck_phi = phi_base - 0.10 * level;
            if level == 0
                bottleneck_phi = phi_base;
            end

            for t = 1:n_timings
                r_start = timing_starts(t);
                r_end = min(r_start + window_width - 1, v);

                [origCell, phi_geo] = buildBottleneckCell( ...
                    phi_base, bottleneck_phi, r_start, r_end, v, universal, level);

                nom_orig = 2 * t - 1;
                nom_flat = 2 * t;

                scenario = addCellConfig(scenario, ord_idx, nom_orig, origCell);
                scenario = addCellConfig(scenario, ord_idx, nom_flat, ...
                    buildMatchedFlatCell(phi_geo, v, universal, ...
                        sprintf('bn_r%02d_flat', r_start), level));
            end
        end

        function [cellConfig, phi_geo] = buildBottleneckCell( ...
                phi_base, bottleneck_phi, r_start, r_end, v, universal, level)
            % SUB-CONTROLLER: Build one bottleneck cell with timing metadata
            p_traj = computeBottleneckTrajectory( ...
                phi_base, bottleneck_phi, r_start, r_end, v);
            phi_geo = computeGeometricMean(p_traj);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packBottleneckCell( ...
                p_traj, universal, r_start, r_end, ...
                bottleneck_phi, phi_geo, level, predictors, v);

            function p_traj = computeBottleneckTrajectory( ...
                    phi_base, bottleneck_phi, r_start, r_end, v)
                % MODEL: Flat trajectory with bottleneck window (TERMINAL)
                p_traj = phi_base * ones(1, v);
                p_traj(r_start:r_end) = max(bottleneck_phi, 0.01);
            end

            function cellConfig = packBottleneckCell( ...
                    p_traj, universal, r_start, r_end, ...
                    bottleneck_phi, phi_geo, level, predictors, v)
                % MODEL: Assemble bottleneck cell with metadata (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    p_traj, zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'family', sprintf('bn_r%02d', r_start), ...
                    'level', level, ...
                    'is_branched', false, ...
                    'bottleneck_phi', bottleneck_phi, ...
                    'r_start', r_start, ...
                    'r_end', r_end, ...
                    'phi_geo', phi_geo, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        function cellConfig = buildMatchedFlatCell(phi_geo, v, universal, family_label, level)
            % SUB-CONTROLLER: Flat trajectory at phi_geo, eps = 0
            p_traj = phi_geo * ones(1, v);
            predictors = computeTrajectoryPredictors(p_traj);
            cellConfig = packMatchedFlatCell( ...
                p_traj, universal, family_label, level, phi_geo, predictors);

            function cellConfig = packMatchedFlatCell( ...
                    p_traj, universal, family_label, level, phi_geo, predictors)
                % MODEL: Build matched flat cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;
                cellConfig.pools = buildPool( ...
                    p_traj, zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                cellConfig.branch_events = [];
                cellConfig.log_params = struct( ...
                    'family', family_label, ...
                    'level', level, ...
                    'is_branched', false, ...
                    'phi_geo', phi_geo, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end

        function phi_geo = computeGeometricMean(p_traj)
            % MODEL: Geometric mean of per-round phi values (TERMINAL)
            phi_geo = exp(mean(log(p_traj)));
        end
    end
end
