function pool = buildPool(p_traj, eps_traj, label, color, phase_boundaries, initial_S)
    % MODEL: Construct a pool struct (TERMINAL)
    pool = struct();
    pool.p_traj = p_traj;
    pool.eps_traj = eps_traj;
    pool.label = label;
    pool.color = color;
    pool.phase_boundaries = phase_boundaries;
    pool.initial_S = initial_S;
end
