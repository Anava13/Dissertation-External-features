function scenario = buildBranchingProbe1Scenario(n_colonies, v)
    % CONTROLLER: Build branching probe scenario for boundary characterization
    %
    % Sweeps phi gap (ordinal) x p_branch (nominal) at fixed branch round 5,
    % branch-up, per-colony branching, phi_baseline=0.75, eps=0.
    %
    % Ordinal axis (13 values): phi gap from 0.02 to 0.20
    % Nominal axis (9 values):  p_branch from 0.05 to 0.80
    %
    % Held constants:
    %   phi_baseline = 0.75, branch_round = 5, direction = up,
    %   mode = per_colony, eps = 0, v = 40, n = 1000
    %
    % USAGE:
    %   scenario = buildBranchingProbe1Scenario();
    %   scenario = buildBranchingProbe1Scenario(1000, 40);

    if nargin < 1 || isempty(n_colonies), n_colonies = 1000; end
    if nargin < 2 || isempty(v),          v = 40; end

    scenario = initializeShell();
    scenario = populateGrid(scenario, n_colonies, v);

    function scenario = initializeShell()
        % SUB-CONTROLLER: Build empty scenario shell
        labels = buildLabels();
        options = defaultAnalysisOptions();
        scenario = assembleScenarioShell(labels, options, 'BranchingProbe1');

        function labels = buildLabels()
            % MODEL: Build display labels for gap (ordinal) and p_branch (nominal) (TERMINAL)
            phi_gaps = getPhiGapValues();
            p_branches = getPBranchValues();

            labels = struct();
            labels.ordinal_display = arrayfun(@(g) sprintf('gap=%.2f', g), ...
                phi_gaps, 'UniformOutput', false);
            labels.nominal_display = arrayfun(@(p) sprintf('p=%.2f', p), ...
                p_branches, 'UniformOutput', false);
            labels.nominal_fields = arrayfun(@(p) sprintf('p_%03d', round(p*100)), ...
                p_branches, 'UniformOutput', false);
        end
    end

    function scenario = populateGrid(scenario, n_colonies, v)
        % SUB-CONTROLLER: Fill all gap x p_branch cells
        universal = makeUniversalConfig(n_colonies, v, 50);
        phi_baseline = 0.75;
        branch_round = 5;
        phi_gaps = getPhiGapValues();
        p_branches = getPBranchValues();

        for ord_idx = 1:length(phi_gaps)
            for nom_idx = 1:length(p_branches)
                cellConfig = buildBranchCell( ...
                    phi_baseline, ...
                    phi_baseline + phi_gaps(ord_idx), ...
                    branch_round, ...
                    p_branches(nom_idx), ...
                    universal, v, ...
                    sprintf('gap%02d_p%03d', round(phi_gaps(ord_idx)*100), ...
                        round(p_branches(nom_idx)*100)));
                scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig);
            end
        end

        function cellConfig = buildBranchCell(phi_base, phi_post, event_round, p_event, universal, v, label)
            % SUB-CONTROLLER: Build a two-pool branching cell
            params = computeBranchParams(phi_base, phi_post, event_round, p_event);
            p_eff = computeBranchEffectiveTrajectory(params, v);
            predictors = computeTrajectoryPredictors(p_eff);
            cellConfig = packBranchCell(params, universal, label, predictors, v);

            function params = computeBranchParams(phi_base, phi_post, event_round, p_event)
                % MODEL: Branch parameters (TERMINAL)
                params = struct();
                params.p_base = phi_base;
                params.p_post = phi_post;
                params.event_round = event_round;
                params.p_event = p_event;
            end

            function p_eff = computeBranchEffectiveTrajectory(params, v)
                % MODEL: Population-mean phi(r) for branching (TERMINAL)
                r = 1:v;
                p_eff = params.p_base * ones(1, v);
                mask = r >= params.event_round;
                p_eff(mask) = params.p_event * params.p_post + ...
                    (1 - params.p_event) * params.p_base;
            end

            function cellConfig = packBranchCell(params, universal, label, predictors, v)
                % MODEL: Assemble two-pool branch cell (TERMINAL)
                cellConfig = struct();
                cellConfig.universal = universal;

                base_pool = buildPool( ...
                    params.p_base * ones(1, v), zeros(1, v), ...
                    'Base', [0.30, 0.45, 0.75], [], 1);
                event_pool = buildPool( ...
                    params.p_post * ones(1, v), zeros(1, v), ...
                    'BranchLineage', [0.75, 0.55, 0.10], [], 0);

                cellConfig.pools = [base_pool, event_pool];
                cellConfig.branch_events = buildBranchEvent( ...
                    1, 'dividing', 2, 'per_colony', ...
                    params.p_event, [params.event_round]);

                cellConfig.log_params = struct( ...
                    'condition', label, ...
                    'p_base', params.p_base, ...
                    'p_post', params.p_post, ...
                    'phi_gap', params.p_post - params.p_base, ...
                    'event_round', params.event_round, ...
                    'p_event', params.p_event, ...
                    'phi_avg', predictors.phi_avg, ...
                    'flat_L2', predictors.flat_L2, ...
                    'weighted_L2', predictors.weighted_L2);
            end
        end
    end

    function gaps = getPhiGapValues()
        % MODEL: Ordinal axis gap values (TERMINAL)
        gaps = [0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, ...
                0.10, 0.11, 0.13, 0.15, 0.20];
    end

    function ps = getPBranchValues()
        % MODEL: Nominal axis p_branch values (TERMINAL)
        ps = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80];
    end
end
