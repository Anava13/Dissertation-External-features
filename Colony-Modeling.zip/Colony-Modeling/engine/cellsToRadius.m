function radius = cellsToRadius(n_cells, packing_density)
    % MODEL: Convert total cell count to colony radius (TERMINAL)
    if n_cells <= 0
        radius = 0;
        return;
    end
    radius = ((3 * n_cells) / (2 * pi * packing_density))^(1/3);
end
