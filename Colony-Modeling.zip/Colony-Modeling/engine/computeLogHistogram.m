function histData = computeLogHistogram(radii, imposed_edges)
    % MODEL: Compute log-space histogram (TERMINAL)
    if nargin < 2, imposed_edges = []; end
    histData = struct();
    histData.radii = radii;
    histData.n = length(radii);
    if histData.n < 2
        histData.empty = true;
        histData.mean_r = NaN; histData.std_r = NaN; histData.cv = NaN;
        histData.log_bin_centers = []; histData.log_bin_edges = [];
        histData.bin_counts = []; histData.log_bin_width = NaN;
        return;
    end
    histData.empty = false;
    histData.mean_r = mean(radii);
    histData.std_r = std(radii);
    histData.cv = histData.std_r / histData.mean_r;
    log_radii = log(radii);
    if isempty(imposed_edges)
        log_min = min(log_radii);
        log_max = max(log_radii);
        log_range = log_max - log_min;
        iqr_log = iqr(log_radii);
        if iqr_log > 0 && log_range > 0
            fd_width = 2 * iqr_log / (histData.n ^ (1/3));
            n_bins = ceil(log_range / fd_width);
        else
            n_bins = 10;
        end
        n_bins = min(100, max(10, n_bins));
        edges = linspace(log_min - 0.1, log_max + 0.1, n_bins + 1);
    else
        edges = imposed_edges;
    end
    [counts, ~] = histcounts(log_radii, edges);
    histData.log_bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    histData.log_bin_edges = edges;
    histData.bin_counts = counts;
    histData.log_bin_width = edges(2) - edges(1);
end
