# Colony Modeling (Supplemental 1)

MATLAB code for Supplemental 1 of Alejandro Navarro's PhD dissertation, *Colony Size Modeling through computational approaches*.

The model grows colonies as a branching process. In every round, each dividing cell succeeds with probability p(success), set by a trajectory φ(r) and a colony-level perturbation ε. Cells that fail arrest. Final cell counts convert to radii through hemisphere geometry, and colonies below the detection limit drop out. Each colony set is then read by kernel density estimation, mixture modeling, and reference library fitting.

The code runs forward, from a trajectory to a distribution. It predicts how a change in growth would reshape colony size KDEs. The dissertation's analysis of real plates is in the Analytical Pipeline package.

## Requirements

- MATLAB R2021b or later
- Statistics and Machine Learning Toolbox

## Quick start

1. Unzip the package anywhere.
2. In MATLAB, change to the package folder.
3. Run `ColonyModelApp`.

The app adds `engine/` and `presets/` to the path and loads the reference library on startup.

## Using the app

**Build a trajectory.** The plot on the left shows p(success) by round. Select a segment, then use **Add Flat**, **Add Ramp**, or **Add Branch** to extend it, and set its values in **Node Parameters**:

- *Flat* holds φ constant for a number of rounds.
- *Ramp* changes φ linearly from a start value to an end value.
- *Branch* moves a cell onto a new trajectory at the branch round. Each output has a probability, and each output takes its own segments. **Branch Mode** sets whether one cell per colony moves (*per colony*) or every dividing cell rolls (*per cell*).

Each flat or ramp segment carries its own ε.

**Set universal parameters.** Colonies per set, total rounds, detection limit, RNG seed, and the mixture methods. With **Run flat control alongside** checked, every run also simulates the flat control (φ = 0.75, ε = 0) under the same settings, so the viewer shows the trajectory beside its reference.

**Run.** **Run Model** simulates the colony set and opens the results viewer: trajectory, histogram, mixture fit, KDE, and lineage composition, with buttons to page between views and colony sets.

**Export.** **Export Last Run** saves the latest run to a folder you choose: `<name>_results.mat`, `<name>_results.pdf`, and, for builder runs, `<name>_spec.mat` with the trajectory tree.

The library was built at 40 rounds. When a run uses a different round count, the app skips library fitting and says so; KDE and mixture fits still run.

## Presets

The **Presets** panel lists every condition behind the Supplemental 1 figures and tables. Each entry names the LaTeX label it reproduces.

**Trajectory presets** load into the builder. Press **Run Model** to reproduce the figure panel, or edit the tree first to test a variation.

| Preset | Reproduces |
|---|---|
| Flat control, φ = 0.75, ε = 0 | `fig:control_baseline` |
| Flat with epsilon variation, level 14 | `fig:trajectory_histograms` A |
| Linear decline, level 14 | `fig:trajectory_histograms` B |
| Step decline, level 14 | `fig:trajectory_histograms` C |
| Bottleneck, level 7 | `fig:trajectory_histograms` D |
| Early branch, level 14 | `fig:trajectory_histograms` E |
| Late branch, level 14 | `fig:trajectory_histograms` F |
| Branch variation A to F | `fig:branch_progression` A to F |
| Four flat φ × ε conditions | `fig:phi_epsilon_grid` rows 1 to 4 |

**Grid presets** run a full scenario of many colony sets and open the results viewer on the whole grid.

| Preset | Contents | Reproduces |
|---|---|---|
| `LibraryDiagnostic` | Six trajectory families, levels 0 to 14 | `fig:control_baseline`, `fig:trajectory_families`, `fig:trajectory_histograms`, `tab:diagnostic_outputs` |
| `LevelSubsetWithControl` | Families at levels 7 and 14 beside the flat control | `fig:trajectory_histograms` |
| `ReversedDirection` | Incline against decline; five-round rise against the Bottleneck drop | `sec:trajectory_families`, `sec:diagnostic_framework` |
| `MatchedFlat` | Non-flat families paired with flat sets at φ_geo | `sec:phi_nonstationarity` |
| `PhiRangeSweep` | φ_geo pairing across baselines 0.60 to 0.95 | `sec:phi_nonstationarity` |
| `BottleneckTimingSweep` | Bottleneck window position | `sec:phi_nonstationarity` |
| `SampleSizeSweep` | Library ε floor from 100 to 5,000 colonies | `sec:library_outputs` |
| `BimodalityIsolation` | Branch against a shared step at the same φ change | `sec:multimodality` |
| `BranchModeComparison` | Per-colony against per-cell branching | `sec:multimodality` |
| `BranchModeVariation` | Branch variations A to F | `fig:branch_progression` |
| `BranchingProbe1` | φ gap × p_branch at round 5 | `tab:bimodality_conditions` |
| `BranchingProbe2` | φ_baseline × p_branch at gap 0.10 | `tab:bimodality_conditions` |
| `BranchingProbe3` | φ gap × branch round; draws the bimodality heatmap | `tab:bimodality_conditions`, `sec:multimodality` |
| `BranchingProbe4` | φ gap × φ_baseline at round 5 | `tab:bimodality_conditions` |
| `FlatQuadrants` | Four flat φ × ε conditions | `fig:phi_epsilon_grid` |

The largest grid presets take much longer than a single trajectory: `LibraryDiagnostic` simulates 90 colony sets, `BranchingProbe3` 240, and `BranchingProbe4` 312. Progress prints in the Command Window.

To add a preset, add an entry to `presets/presetCatalog.m`. A trajectory you build and export can be copied into the catalog the same way.

## Running every grid preset without the app

`run_all_figures` runs each grid preset in turn and writes `<id>_results.mat` and `<id>_results.pdf` to `outputs/figures`. Set `presetIds` at the top of the script to run a subset.

## Reproducibility

Every run seeds the random number generator (default seed 1), so a preset returns the same output each time it runs at the same seed. The values reported in the dissertation came from unseeded runs. A seeded rerun matches them within simulation noise, not digit for digit.

## Shared simulation settings

| Setting | Value |
|---|---|
| Division rounds (ν) | 40 |
| Colonies per condition | 1,000 |
| Detection limit | 50 µm radius (100 µm for the `fig:phi_epsilon_grid` presets, as in the original figure) |
| Cell packing density | 0.0113 cells per µm³ |
| Binomial draws | Exact below 500 dividing cells, normal approximation above |
| ε draw | p(success) for each pool and round drawn from a beta distribution with mean φ(r) and standard deviation ε |

## Files

| Path | Contents |
|---|---|
| `ColonyModelApp.m` | The app |
| `run_all_figures.m` | Batch run of every grid preset |
| `engine/` | Simulation, scenario builders, KDE, mixture modeling, library fitting, results viewer, PDF export. One function per file. |
| `presets/presetCatalog.m` | Every trajectory and grid preset |
| `library/stable_phi_library_V40.mat` | Reference library used for library fitting |
| `library/buildStablePhiLibrary.m` | Rebuilds the library |

`engine/` also holds the scenario builders for real QuantaColony data (`buildRealDataScenario`, `buildCompositeDataScenario`, `buildScenarioFromAllMeasures`). They are included for transparency. No preset calls them.

## Rebuilding the library

`buildStablePhiLibrary` simulates 10,000 colonies at every (φ₀, ε) pair on the grid φ₀ = 0.60 to 0.94 and ε = 0.00 to 0.20, both in steps of 0.02, at ν = 40. It stores a KDE for each entry and a null distribution of earth mover's distances from 500 sets of 500 colonies, then writes `outputs/library/stable_phi_library_V40.mat`. A rebuilt library matches the shipped copy within simulation noise.
