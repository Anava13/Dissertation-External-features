function preparePartZips(releaseFolder)
% CONTROLLER: Build the release zips for Complete Analyses and print the
% checksum lines for pipelineConfig.m
%
% For the repository maintainer. Reviewers never run this. Run it once, after
% the analyses are final, from a copy of the pipeline whose
% data/Complete Analyses folder (or analysesOverride) holds all four parts.
%
% Each zip holds one part folder at its top level (P2/, P3/, Anbalagan/,
% Historical/), the layout ensureCompleteAnalyses expects. Any zip at or above
% the GitHub release limit of 2 GiB per file is flagged.
%
% Usage:
%   preparePartZips                 % writes zips to <pipeline>/release
%   preparePartZips('D:\release')   % writes zips to a chosen folder
%
% Afterward:
%   1. Paste the printed sha256 lines into pipelineConfig.m
%   2. On GitHub, create a release with the printed tag and attach the zips

    cfg = pipelineConfig();
    if nargin < 1 || isempty(releaseFolder)
        releaseFolder = fullfile(cfg.root, 'release');
    end

    prepareReleaseFolder(cfg, releaseFolder);
    results = zipAllParts(cfg, releaseFolder);
    reportRelease(results, cfg);

    % === SUB-CONTROLLERS ===

    function prepareReleaseFolder(cfg, releaseFolder)
        % SUB-CONTROLLER: Check the source parts, then create the release folder

        checkSourceParts(cfg);
        createFolder(releaseFolder);

        function checkSourceParts(cfg)
            % MODEL: Stop when any part folder is missing (TERMINAL)
            missing = {};
            for k = 1:numel(cfg.parts)
                if ~isfolder(fullfile(cfg.analysesFolder, cfg.parts{k}))
                    missing{end+1} = cfg.parts{k}; %#ok<AGROW>
                end
            end
            if ~isempty(missing)
                error('preparePartZips:MissingParts', ...
                    'Part folders missing from %s: %s', ...
                    cfg.analysesFolder, strjoin(missing, ', '));
            end
        end

        function createFolder(releaseFolder)
            % MODEL: Create the release folder when absent (TERMINAL)
            if ~isfolder(releaseFolder)
                mkdir(releaseFolder);
            end
        end
    end

    function results = zipAllParts(cfg, releaseFolder)
        % SUB-CONTROLLER: Zip each part, then record its size and checksum

        results = struct('part', {}, 'zipPath', {}, 'bytes', {}, 'sha256', {});
        for k = 1:numel(cfg.parts)
            part = cfg.parts{k};
            announcePart(part);
            zipPath = zipOnePart(cfg, releaseFolder, part);
            results(k).part    = part;
            results(k).zipPath = zipPath;
            results(k).bytes   = fileBytes(zipPath);
            results(k).sha256  = sha256File(zipPath);
        end

        function announcePart(part)
            % VIEW: Progress line before a part is zipped (TERMINAL)
            fprintf('Zipping %s ...\n', part);
        end

        function zipPath = zipOnePart(cfg, releaseFolder, part)
            % MODEL: Zip one part folder with the folder itself at the top level (TERMINAL)
            % Passing the analyses folder as rootfolder stores entries as
            % <part>/<project>/..., with no machine-specific path above them.
            zipPath = fullfile(releaseFolder, [part '.zip']);
            if isfile(zipPath)
                delete(zipPath);
            end
            zip(zipPath, part, cfg.analysesFolder);
        end

        function bytes = fileBytes(zipPath)
            % MODEL: Size of a file in bytes (TERMINAL)
            info  = dir(zipPath);
            bytes = info.bytes;
        end
    end

    function reportRelease(results, cfg)
        % VIEW: Sizes, size-limit flags, checksum lines, and release steps (TERMINAL)

        limitBytes = 2^31;   % GitHub release limit: 2 GiB per file

        fprintf('\n=== Release zips ===\n');
        for k = 1:numel(results)
            flag = '';
            if results(k).bytes >= limitBytes
                flag = '  OVER 2 GiB LIMIT: split this part before uploading';
            end
            fprintf('  %-12s %10.1f MB  %s%s\n', results(k).part, ...
                results(k).bytes / 2^20, results(k).zipPath, flag);
        end

        fprintf('\n=== Paste into pipelineConfig.m ===\n');
        for k = 1:numel(results)
            fprintf('    sha256.%-10s = ''%s'';\n', results(k).part, results(k).sha256);
        end

        fprintf('\n=== GitHub release ===\n');
        fprintf('  Repository: https://github.com/%s/%s/releases/new\n', ...
            cfg.release.owner, cfg.release.repo);
        fprintf('  Tag:        %s\n', cfg.release.tag);
        fprintf('  Attach:     %s\n\n', strjoin(strcat({results.part}, '.zip'), ', '));
    end
end
