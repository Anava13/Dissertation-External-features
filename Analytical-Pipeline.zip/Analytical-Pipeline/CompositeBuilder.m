clear
clc
% CompositeBuilder: Build the composite dataset from Complete Analyses
%
% Run this script first, then LeanFinalAnalysis.m (run_all.m runs both).
%   1. Downloads Complete Analyses from the GitHub release when it is not
%      already in place (see ensureCompleteAnalyses.m)
%   2. Builds every part (P2, P3, Anbalagan, Historical) from the project
%      folders
%   3. Fits the stable-phi library to each part
%   4. Saves the fitted bundle to the composite file named in pipelineConfig.m
% A full run takes about 15 minutes after the download. Paths and settings
% live in pipelineConfig.m; nothing in this file depends on the machine.

addpath(fileparts(mfilename('fullpath')));
cfg = pipelineConfig();
rng(cfg.rngSeed, 'twister');
ensureCompleteAnalyses(cfg);

[OutputText, OutputFigures] = folderdesignation(cfg.outputFolder);
library = loadStablePhiLibrary(cfg.rounds, cfg.dataFolder);

combined = TopLevelCompositeBuilderPhase1(cfg.analysesFolder, cfg.outputFolder, cfg.rounds);
composite = MainController('CompositeData', cfg.rounds, cfg.outputFolder, ...
    OutputText, OutputFigures, library, combined);

saveCompositeBundle(composite, cfg.compositeFile);


%% Pipeline Output
function saveCompositeBundle(composite, compositeFile)
    % MODEL: Save the fitted bundle for LeanFinalAnalysis.m (TERMINAL)
    % MAT-file version 7 drops any variable of 2 GB or more with only a
    % warning, so a bundle at that size is saved as version 7.3.
    outputFolder = fileparts(compositeFile);
    if ~isfolder(outputFolder)
        mkdir(outputFolder);
    end
    info = whos('composite');
    if info.bytes >= 2^31
        save(compositeFile, 'composite', '-v7.3');
    else
        save(compositeFile, 'composite', '-v7');
    end
    fprintf('\nComposite saved: %s\n', compositeFile);
end

%% Phase 1: Composite Construction
function combined = TopLevelCompositeBuilderPhase1(rootFolder, outputFolder, rounds, partsToBuild)
    % CONTROLLER: Build and enrich composites for the requested parts
    %
    % For each requested part this builds the raw composite, writes
    % Measurements.Radius_Pixels and biomass_occupation coverage to every
    % measured entry, and applies P3 pooling.
    %
    % Enrichment runs before pooling. A pooled entry carries no image by
    % definition, so colony and growth coverage are computed on the real plates
    % first and the pooled aggregates are appended afterward. Radius_Pixels is
    % written before biomass_occupation because the biomass step reads
    % Radius_Pixels for both the colony footprint and the growth-mask inputs.
    %
    % partsToBuild is optional. Omitted, it builds every configured part and
    % returns the full bundle. Supplied as a cell array of part names, it builds
    % only those, which allows one part to be rebuilt and appended to an
    % existing bundle without regenerating the others. The P2/P3 pairing runs
    % only when both are present in the build; any other part is attached to the
    % bundle under its lowercased name.
    %
    % Depends on these path functions, which are called and not redefined here:
    %   buildCompositeStruct, addPooledEntries.
    %
    % Usage:
    %   combined  = TopLevelCompositeBuilderPhase1(rootFolder, outputFolder, rounds);
    %   justOne   = TopLevelCompositeBuilderPhase1(rootFolder, outputFolder, rounds, {'Historical'});
    %
    % Inputs:
    %   rootFolder   - Path to folder containing one subfolder per part
    %   outputFolder - Destination folder for saved composites (trailing
    %                  separator expected, matching prior call sites)
    %   rounds       - Filename prefix string applied before the part suffix
    %   partsToBuild - Optional cell array of part names to build

    if nargin < 4 || isempty(partsToBuild)
        parts = {'P2', 'P3', 'Anbalagan', 'Historical'};
    elseif ischar(partsToBuild)
        parts = {partsToBuild};
    else
        parts = partsToBuild;
    end

    partData = struct();
    for p = 1:numel(parts)
        partData.(lower(parts{p})) = ...
            buildOneComposite(rootFolder, outputFolder, rounds, parts{p});
    end

    combined = assembleBundle(rounds, partData);

    % === SUB-CONTROLLERS ===

    function combined = assembleBundle(rounds, partData)
        % SUB-CONTROLLER: Pair P2 with P3 when both were built, then attach
        % every remaining part under its own field. A build that omits P2 or P3
        % simply returns the parts it produced alongside the rounds tag, so a
        % single-part rebuild is a valid bundle to read a field off.

        hasPair = isfield(partData, 'p2') && isfield(partData, 'p3');

        if hasPair
            combined = BuildCombinedDataset(rounds, partData.p2, partData.p3);
        else
            combined = struct('rounds', rounds);
        end

        fields = fieldnames(partData);
        for k = 1:numel(fields)
            if hasPair && any(strcmp(fields{k}, {'p2', 'p3'}))
                continue;
            end
            combined.(fields{k}) = partData.(fields{k});
        end
    end

    function combined = BuildCombinedDataset(rounds, part2, part3)
        % CONTROLLER: Load both Part 2 and Part 3 datasets under a single rounds
        % tag and return them paired in one struct. Because both parts share one
        % rounds tag, the two datasets must be regenerated in lockstep.

        combined = struct();
        combined.rounds = rounds;
        combined.part2 = part2;
        combined.part3 = part3;
    end

    function composite = buildOneComposite(rootFolder, outputFolder, rounds, part)
        % SUB-CONTROLLER: Build, enrich, conditionally pool, and save one part

        composite = buildCompositeStruct(rootFolder, part);
        composite = populateRadiusPixels(composite);
        composite = processPartComposite(composite);

        if partRequiresPooling(part)
            composite = addPooledEntries(composite);
        end

        %saveComposite(composite, outputFolder, rounds, part);

        % --- NESTED IN buildOneComposite ---

        function composite = populateRadiusPixels(composite)
            % SUB-CONTROLLER: Write Measurements.Radius_Pixels to each entry
            % Runs before pooling, so every entry here is a real plate. Entries
            % still awaiting measurement (empty Measurements, NaN scaling) are
            % skipped and left without the field, which the biomass step reads as
            % unmeasured.

            for k = 1:numel(composite)
                composite(k).Measurements = setEntryRadiusPixels(composite(k));
            end

            function measurementsOut = setEntryRadiusPixels(entry)
                % MODEL: Area-equivalent colony radius in pixels (TERMINAL)
                % Radius is the area-equivalent radius in microns, so dividing by
                % 1000 gives millimeters and multiplying by pixels_per_mm gives
                % pixels. Returns Measurements unchanged when there is no Radius to
                % convert or no finite scaling.
                measurementsOut = entry.Measurements;
                if ~isfield(measurementsOut, 'Radius') || isempty(measurementsOut.Radius) ...
                        || ~isfinite(entry.pixels_per_mm)
                    return;
                end
                measurementsOut.Radius_Pixels = entry.pixels_per_mm * (measurementsOut.Radius / 1000);
            end
        end

        function composite = processPartComposite(composite)
            % SUB-CONTROLLER: Write colony and growth coverage to every entry of one part
            %
            % For each composite entry, runs the extracted growth-mask builder, sums the
            % colony footprint, and measures the growable disk, then stores three values
            % under biomass_occupation: colony (summed colony footprint over the disk),
            % growth (growth-mask pixels over the same disk), and mask (the logical growth
            % mask, kept so a reduced viewer can draw the overlay without recomputing it).
            % Both fractions divide by one identical denominator, the pixel count of the
            % inscribed disk the growth mask is clipped to. Pooled or image-less entries
            % resolve to NaN fractions and an empty mask, so the struct array stays
            % homogeneous.

            for k = 1:numel(composite)
                composite(k).biomass_occupation = computeEntryBiomass(composite(k));
            end

            function biomass = computeEntryBiomass(entry)
                % SUB-CONTROLLER: Build the growth mask, then derive both coverages

                growthMask = resolveGrowthMask(entry);
                biomass    = resolveCoverages(entry, growthMask);

                function maskOut = resolveGrowthMask(entryA)
                    % SUB-CONTROLLER: Assemble mask inputs and run the mask builder
                    % Grid size is fixed at 10 so the stored masks match the reduced viewer.

                    maskInputs = gatherMaskInputs(entryA);
                    maskOut    = computeGrowthMask(maskInputs.image, maskInputs.boundaries, ...
                                                   maskInputs.centers, maskInputs.radiiPixels, 10);

                    function inputsOut = gatherMaskInputs(entryB)
                        % MODEL: Pull image and colony arrays from the entry (TERMINAL)
                        % An absent or empty image flows through as [] so computeGrowthMask
                        % returns an empty mask. Missing measurement fields stay at their
                        % empty defaults, which computeGrowthMask treats as no colonies.
                        inputsOut = struct('image', [], 'boundaries', {{}}, ...
                                           'centers', [], 'radiiPixels', []);
                        if isfield(entryB, 'image')
                            inputsOut.image = entryB.image;
                        end
                        if isfield(entryB, 'Measurements') && ~isempty(entryB.Measurements)
                            m = entryB.Measurements;
                            if isfield(m, 'Boundaries'),    inputsOut.boundaries  = m.Boundaries; end
                            if isfield(m, 'Centers'),       inputsOut.centers     = m.Centers; end
                            if isfield(m, 'Radius_Pixels'), inputsOut.radiiPixels = m.Radius_Pixels; end
                        end
                    end

                    function growthMask = computeGrowthMask(image, boundaries, centers, radiiPixels, gridSize)
    % CONTROLLER: Build a growth (foreground) coverage mask for one plate image
    %
    % Grayscales the plate, restricts to an inscribed-circle growable disk, and
    % separates growth from agar in three stages: a topological reconciliation of
    % two tile passes, then a photometric veto against a local agar surface.
    %
    % The gated pass keeps only tiles whose internal contrast reaches a fraction
    % of a plate-wide growth/agar gap (measured from detected colony pixels).
    % Those tiles hold a real boundary, so the growth carved from them carries no
    % bare-agar false positive. It is the trusted seed.
    %
    % The legacy pass is the prior per-tile Otsu method. It over-calls bare agar
    % but never drops real growth, so it is continuous across every real growth
    % region. It serves as the connectivity ceiling.
    %
    % Reconstruction grows the seed through the legacy ceiling. Real growth the
    % gate dropped connects to the seed through the continuous legacy mask and is
    % recovered (the false negatives that touch surviving growth). Legacy growth
    % with no seed pixel in its component is discarded (the free-floating
    % bare-agar false positives).
    %
    % The photometric veto handles the error reconstruction cannot: agar that is
    % gradient-darkened to a growth-like absolute brightness but is connected to a
    % real colony, so the colony seeds it and the whole halo survives. A coarse
    % interpolated agar surface gives the local agar level at each pixel; a pixel
    % stays growth only if it sits a full contrast below its local agar, which
    % keeps colonies and real growth and drops the surrounding agar. The veto runs
    % before the colony union, so detected colonies are never removed.
    %
    % Returns a logical H x W mask, true where growth sits inside the disk. Empty
    % image returns [].
    %
    % Assumption: every real growth component contains at least one gate-clearing
    % tile or a detected colony, so reconstruction can reach it. The only residual
    % false negative is growth less than vetoFraction of the gap below local agar
    % (faint, low-contrast growth), which the veto would remove.

    % === COORDINATE MODELS ===

    if isempty(image)
        growthMask = [];
        return;
    end

    params     = growthMaskParameters();
    diskMask   = buildDiskMask(size(image));
    colonyMask = buildColonyMask(size(image), boundaries, centers, radiiPixels);

    % A plate with no detected colony footprint has no growth to find, so the
    % analysis is skipped and a sized empty mask is returned. The sized mask (not
    % []) yields growth coverage 0 rather than N/A downstream, since packBiomass
    % reads an empty mask as unmeasured but an all-false sized mask as zero. This
    % holds only while every plate carrying real growth also carries at least one
    % detected colony; a confluent plate with zero detections would be zeroed in
    % error. On these plates that case is a single empty plate.
    if ~any(colonyMask(:))
        growthMask = false(size(image, 1), size(image, 2));
        return;
    end

    grayImg    = toGrayscale(image);
    refs       = resolvePlateReferences(grayImg, diskMask, colonyMask, params);

    % Trusted seed: gate-cleared tiles plus detected colonies, no bare-agar paint.
    seedCore   = buildGatedSeed(grayImg, diskMask, refs, params, gridSize) | colonyMask;

    % Connectivity ceiling: the prior method, continuous across real growth.
    legacyMask = buildLegacyMask(grayImg, diskMask, refs, params, gridSize);

    % Keep only legacy growth connected to the trusted seed.
    recovered  = reconcileMasks(seedCore, legacyMask);

    % Photometric veto: drop pixels not a full contrast below the local agar
    % surface, removing gradient-darkened agar fused to a colony or to growth.
    agarField  = buildLocalAgarField(grayImg, diskMask, refs, params);
    recovered  = recovered & applyAgarVeto(grayImg, agarField, refs, params);

    growthMask = (recovered | colonyMask) & diskMask;

    % === MODELS ===

    function p = growthMaskParameters()
        % MODEL: All tunable constants for growth-mask construction (TERMINAL)
        % Percentiles are stated for the growth-is-dark case; the reference and
        % field builders mirror them when polarity is reversed.
        p = struct();
        p.agarPercentile           = 80;   % bright side of a region reads as its agar level
        p.growthFallbackPercentile = 20;   % dark side, used only when no colonies detected
        p.tileHighPercentile       = 85;   % tile bright reference for internal contrast
        p.tileLowPercentile        = 10;   % tile dark reference for internal contrast
        p.gapFraction              = 0.40; % tile contrast must reach this fraction of the plate gap to seed
        p.minPlateGap              = 0.08; % plate gap below this means no detectable growth/agar contrast
        p.emFloor                  = 0.50; % legacy ceiling: Otsu effectiveness below this falls back to global
        p.coarseGridSize           = 5;    % grid for the local agar surface, coarser than the tile grid
        p.vetoFraction             = 0.50; % a kept pixel must sit this fraction of the gap below local agar
        p.minTilePixels            = 50;   % cells/tiles with fewer in-disk pixels are skipped
    end

    function diskOut = buildDiskMask(imgSize)
        % MODEL: Inscribed-circle disk over the square plate image (TERMINAL)
        H = imgSize(1);
        W = imgSize(2);
        cx = (W + 1) / 2;
        cy = (H + 1) / 2;
        R = min(H, W) / 2;
        [X, Y] = meshgrid(1:W, 1:H);
        diskOut = (X - cx).^2 + (Y - cy).^2 <= R^2;
    end

    function colOut = buildColonyMask(imgSize, polys, ctrs, radii)
        % MODEL: Union of detected colony footprints (TERMINAL)
        % Polygon via poly2mask where a valid boundary exists, otherwise a
        % synthesized circle from center and pixel radius (mirrors the viewer).
        H = imgSize(1);
        W = imgSize(2);
        colOut = false(H, W);
        nCol = min([numel(polys), size(ctrs, 1), numel(radii)]);
        [X, Y] = meshgrid(1:W, 1:H);
        for i = 1:nCol
            b = polys{i};
            if ~isempty(b) && isnumeric(b) && size(b, 2) >= 2 && ~any(isnan(b(:)))
                colOut = colOut | poly2mask(b(:, 2), b(:, 1), H, W);
            else
                cx = ctrs(i, 1);
                cy = ctrs(i, 2);
                r  = radii(i);
                if isfinite(r) && r > 0
                    colOut = colOut | ((X - cx).^2 + (Y - cy).^2 <= r^2);
                end
            end
        end
    end

    function grayOut = toGrayscale(rgbIn)
        % MODEL: Grayscale image normalized to [0,1] (TERMINAL)
        if ndims(rgbIn) == 3 && size(rgbIn, 3) == 3
            grayOut = rgb2gray(rgbIn);
        else
            grayOut = rgbIn;
        end
        grayOut = im2double(grayOut);
    end

    function refs = resolvePlateReferences(g, dmask, cmask, params)
        % MODEL: Plate-wide growth and agar brightness references (TERMINAL)
        % growthLevel comes from colony-interior pixels, definite growth detected
        % at high accuracy. agarLevel is a bright percentile of the whole disk;
        % because growth is dark, the brightest pixels are agar regardless of how
        % much growth covers the plate, as long as some agar is present. gap is
        % the plate-wide growth/agar contrast, the yardstick for both the seed
        % gate and the veto distance. midpoint separates agar-bearing from
        % agar-poor coarse cells. When no colonies are detected, growthLevel
        % falls back to a dark percentile; on a bare plate this collapses the gap
        % below minPlateGap and the seed is empty.
        refs = struct('growthLevel', 0, 'agarLevel', 0, 'gap', 0, ...
                      'midpoint', 0, 'growthIsDark', true, 'hasContrast', false);

        inDisk = g(dmask);
        if isempty(inDisk)
            return;
        end

        s = sort(inDisk);
        n = numel(s);
        diskMedian = median(inDisk);

        growthPix = g(dmask & cmask);
        if isempty(growthPix)
            refs.growthIsDark = true;
        else
            refs.growthIsDark = median(growthPix) < diskMedian;
        end

        if refs.growthIsDark
            agarP       = params.agarPercentile;
            growthFallP = params.growthFallbackPercentile;
        else
            agarP       = 100 - params.agarPercentile;
            growthFallP = 100 - params.growthFallbackPercentile;
        end

        agarIdx = min(n, max(1, round(agarP / 100 * n)));
        refs.agarLevel = s(agarIdx);

        if isempty(growthPix)
            growthIdx = min(n, max(1, round(growthFallP / 100 * n)));
            refs.growthLevel = s(growthIdx);
        else
            refs.growthLevel = median(growthPix);
        end

        refs.gap         = abs(refs.agarLevel - refs.growthLevel);
        refs.midpoint    = (refs.agarLevel + refs.growthLevel) / 2;
        refs.hasContrast = refs.gap >= params.minPlateGap;
    end

    function seedOut = buildGatedSeed(g, dmask, refs, params, nGrid)
        % MODEL: Growth from tiles that clear the contrast gate (TERMINAL)
        % A tile whose internal contrast (high minus low percentile) reaches
        % gapFraction of the plate gap holds a real boundary and is carved with
        % its own local Otsu threshold. A bare-agar gradient tile has small
        % internal contrast and never clears the gate, so it contributes no paint
        % and cannot produce a false positive here. Single-class tiles (full
        % confluence, dark corners) contribute nothing; their real growth, if any,
        % is recovered by reconstruction through the legacy ceiling.
        H = size(g, 1);
        W = size(g, 2);
        seedOut = false(H, W);

        if ~refs.hasContrast
            return;
        end

        rowEdges  = round(linspace(1, H + 1, nGrid + 1));
        colEdges  = round(linspace(1, W + 1, nGrid + 1));
        gateLevel = params.gapFraction * refs.gap;

        for ri = 1:nGrid
            rr = rowEdges(ri):(rowEdges(ri + 1) - 1);
            for ci = 1:nGrid
                cc = colEdges(ci):(colEdges(ci + 1) - 1);

                tileDisk = dmask(rr, cc);
                if nnz(tileDisk) < params.minTilePixels
                    continue;
                end

                tileGray = g(rr, cc);
                tilePix  = tileGray(tileDisk);

                sTile = sort(tilePix);
                nTile = numel(sTile);
                hiIdx = min(nTile, max(1, round(params.tileHighPercentile / 100 * nTile)));
                loIdx = min(nTile, max(1, round(params.tileLowPercentile  / 100 * nTile)));

                if (sTile(hiIdx) - sTile(loIdx)) >= gateLevel
                    localT = graythresh(tilePix);
                    if refs.growthIsDark
                        tileGrowth = tileGray <= localT;
                    else
                        tileGrowth = tileGray >= localT;
                    end
                    seedOut(rr, cc) = tileGrowth & tileDisk;
                end
            end
        end
    end

    function legacyOut = buildLegacyMask(g, dmask, refs, params, nGrid)
        % MODEL: Original per-tile Otsu mask with EM floor and global fallback (TERMINAL)
        % The prior method. A tile with Otsu effectiveness at or above emFloor
        % uses its own local threshold; a tile below it falls back to the global
        % disk threshold. This over-calls bare agar but never drops real growth,
        % so it is continuous across every real growth region. Used only as the
        % reconstruction ceiling, never returned directly.
        H = size(g, 1);
        W = size(g, 2);
        legacyOut = false(H, W);

        inDisk = g(dmask);
        if isempty(inDisk)
            return;
        end
        globalT = graythresh(inDisk);

        rowEdges = round(linspace(1, H + 1, nGrid + 1));
        colEdges = round(linspace(1, W + 1, nGrid + 1));

        for ri = 1:nGrid
            rr = rowEdges(ri):(rowEdges(ri + 1) - 1);
            for ci = 1:nGrid
                cc = colEdges(ci):(colEdges(ci + 1) - 1);

                tileDisk = dmask(rr, cc);
                if nnz(tileDisk) < params.minTilePixels
                    continue;
                end

                tileGray = g(rr, cc);
                tilePix  = tileGray(tileDisk);

                [localT, em] = graythresh(tilePix);
                if em >= params.emFloor
                    useT = localT;
                else
                    useT = globalT;
                end

                if refs.growthIsDark
                    tileGrowth = tileGray <= useT;
                else
                    tileGrowth = tileGray >= useT;
                end

                legacyOut(rr, cc) = tileGrowth & tileDisk;
            end
        end
    end

    function recoveredOut = reconcileMasks(seedCore, legacyMask)
        % MODEL: Keep legacy growth connected to the trusted seed (TERMINAL)
        % imreconstruct grows the seed through the legacy mask by morphological
        % reconstruction. Legacy growth in a component that contains a seed pixel
        % flows in (confluent interiors reached through a gate-cleared edge, and
        % the faint edges the gate dropped). Legacy growth in a component with no
        % seed pixel is left out (isolated bare-agar false positives). The union
        % in the ceiling guarantees the seed is a subset of the mask, which
        % imreconstruct requires.
        ceiling      = legacyMask | seedCore;
        recoveredOut = imreconstruct(seedCore, ceiling);
    end

    function agarField = buildLocalAgarField(g, dmask, refs, params)
        % MODEL: Smooth local agar brightness surface over a coarse grid (TERMINAL)
        % Each coarse cell contributes one agar reading from its bright pixels
        % (its dark pixels for bright-growth polarity). A coarse grid is used
        % because each cell then holds enough agar for a stable reading, and the
        % lighting gradient is low spatial frequency, so interpolation between
        % cell centers tracks it without per-cell steps. Cells with no agar to
        % sample (a confluent interior, where even the bright percentile sits past
        % the plate midpoint) are left out, so the surface is filled from
        % agar-bearing neighbors and stays bright there. Erring bright is
        % deliberate: an over-bright surface risks keeping a little agar, while an
        % over-dark surface would push the veto into real growth. Falls back to a
        % constant plate agar level when fewer than three cells carry agar.
        H = size(g, 1);
        W = size(g, 2);
        nGrid = params.coarseGridSize;

        rowEdges = round(linspace(1, H + 1, nGrid + 1));
        colEdges = round(linspace(1, W + 1, nGrid + 1));

        cxList = zeros(nGrid * nGrid, 1);
        cyList = zeros(nGrid * nGrid, 1);
        vList  = zeros(nGrid * nGrid, 1);
        count  = 0;

        for ri = 1:nGrid
            rr = rowEdges(ri):(rowEdges(ri + 1) - 1);
            for ci = 1:nGrid
                cc = colEdges(ci):(colEdges(ci + 1) - 1);

                cellDisk = dmask(rr, cc);
                if nnz(cellDisk) < params.minTilePixels
                    continue;
                end

                cellGray = g(rr, cc);
                cellPix  = cellGray(cellDisk);

                sCell = sort(cellPix);
                nCell = numel(sCell);
                if refs.growthIsDark
                    idx        = min(nCell, max(1, round(params.agarPercentile / 100 * nCell)));
                    agarVal    = sCell(idx);
                    isAgarPoor = agarVal < refs.midpoint;
                else
                    idx        = min(nCell, max(1, round((100 - params.agarPercentile) / 100 * nCell)));
                    agarVal    = sCell(idx);
                    isAgarPoor = agarVal > refs.midpoint;
                end

                if isAgarPoor
                    continue;
                end

                count = count + 1;
                cxList(count) = mean(cc);
                cyList(count) = mean(rr);
                vList(count)  = agarVal;
            end
        end

        if count < 3
            agarField = refs.agarLevel * ones(H, W);
            return;
        end

        cxList = cxList(1:count);
        cyList = cyList(1:count);
        vList  = vList(1:count);

        F = scatteredInterpolant(cxList, cyList, vList, 'linear', 'nearest');
        [X, Y] = meshgrid(1:W, 1:H);
        agarField = F(X, Y);
    end

    function keepMask = applyAgarVeto(g, agarField, refs, params)
        % MODEL: Keep only pixels a full contrast past the local agar level (TERMINAL)
        % Growth sits a near-full plate gap from its local agar; gradient-darkened
        % agar sits at the local agar level. Requiring at least vetoFraction of
        % the gap of separation keeps growth and colonies and drops the agar halo.
        % The controller unions colonies back afterward, so this never removes a
        % detected colony.
        if refs.growthIsDark
            keepMask = g <= (agarField - params.vetoFraction * refs.gap);
        else
            keepMask = g >= (agarField + params.vetoFraction * refs.gap);
        end
    end
end

                end

                function biomassOut = resolveCoverages(entryC, maskC)
                    % SUB-CONTROLLER: Divide both numerators by one shared denominator

                    areaDisk   = computePlateArea(entryC);
                    areaColony = computeColonyArea(entryC);
                    biomassOut = packBiomass(maskC, areaColony, areaDisk);

                    function diskPixelCount = computePlateArea(entryD)
                        % MODEL: Growable disk area as a pixel count (TERMINAL)
                        % Inscribed circle with R = min(H,W)/2 centered on the image, the
                        % same disk computeGrowthMask clips to, so the growth mask is always
                        % a subset and growth coverage stays in [0,1]. Counted in pixels
                        % (not pi*R^2) so numerator and denominator share one discretization.
                        % Empty image gives NaN.
                        if ~isfield(entryD, 'image') || isempty(entryD.image)
                            diskPixelCount = NaN;
                            return;
                        end
                        imageMatrix = entryD.image;
                        H  = size(imageMatrix, 1);
                        W  = size(imageMatrix, 2);
                        cx = (W + 1) / 2;
                        cy = (H + 1) / 2;
                        R  = min(H, W) / 2;
                        [X, Y] = meshgrid(1:W, 1:H);
                        diskMask       = (X - cx).^2 + (Y - cy).^2 <= R^2;
                        diskPixelCount = nnz(diskMask);
                    end

                    function colonyPixelArea = computeColonyArea(entryE)
                        % MODEL: Summed colony footprint area in px^2 (TERMINAL)
                        % Radius_Pixels is the area-equivalent radius, so pi*r^2 recovers
                        % the true footprint for every DetectionType (circular and
                        % irregular). Summed over finite radii only.
                        %
                        % An entry with no Measurements struct is unprocessed or pooled and
                        % gives NaN. An entry that has a Measurements struct but no finite
                        % radii is a measured plate on which no colony was detected, so its
                        % footprint is zero, not unmeasured. Returning 0 there makes colony
                        % coverage report 0 rather than N/A on a colony-free plate, matching
                        % the growth side, which a sized empty mask drives to 0.
                        if ~isfield(entryE, 'Measurements') || isempty(entryE.Measurements)
                            colonyPixelArea = NaN;
                            return;
                        end
                        measurements = entryE.Measurements;
                        if ~isfield(measurements, 'Radius_Pixels') || isempty(measurements.Radius_Pixels)
                            colonyPixelArea = 0;
                            return;
                        end
                        radiiPixels = measurements.Radius_Pixels(:);
                        finiteRadii = radiiPixels(isfinite(radiiPixels));
                        if isempty(finiteRadii)
                            colonyPixelArea = 0;
                            return;
                        end
                        colonyPixelArea = sum(pi .* finiteRadii .^ 2);
                    end

                    function biomassFields = packBiomass(maskP, colonyP, diskP)
                        % MODEL: Pack both fractions and the mask under one struct (TERMINAL)
                        % Both fractions divide by diskP. growth is the growth-pixel fraction,
                        % bounded in [0,1]. colony is the summed footprint over the same disk,
                        % left unclamped so a value above 1 flags footprint overlap. A fraction
                        % is NaN when its numerator is undefined or the disk is not positive.
                        % The mask is stored as is, empty when the entry had no image.
                        biomassFields = struct();

                        if isnan(colonyP) || isnan(diskP) || diskP <= 0
                            biomassFields.colony = NaN;
                        else
                            biomassFields.colony = colonyP / diskP;
                        end

                        if isempty(maskP) || isnan(diskP) || diskP <= 0
                            biomassFields.growth = NaN;
                        else
                            biomassFields.growth = nnz(maskP) / diskP;
                        end
                        biomassFields.CaptureRatio = biomassFields.colony / biomassFields.growth;
                        biomassFields.mask = maskP;
                    end
                end
            end
        end

        function tf = partRequiresPooling(part)
            % MODEL: Declare which parts get pooled entries (TERMINAL)
            tf = strcmp(part, 'P3');
        end

        function saveComposite(composite, outputFolder, rounds, part)
            % MODEL: Build output path and save composite (TERMINAL)
            outputPath = fullfile(outputFolder, [rounds part '.mat']);
            save(outputPath, 'composite');
        end
    end
end
function composite = buildCompositeStruct(rootFolder, part)
    % CONTROLLER: Build composite struct from plate registry and project folder
    %
    % Merged P2/P3/Anbalagan builder. Scans the project folders under
    % rootFolder/part, loads the most recent DataManagerState .mat file from
    % each project's Workspace folder, and populates a registry-derived
    % composite. rootFolder holds one subfolder per part (P2, P3, Anbalagan),
    % and each part's projects live in its own subfolder, so a part never sees
    % another part's projects.
    %
    % Two ingestion modes exist, selected by the part profile:
    %   inputFileDriven (P2, P3) - iterate the project's InputFiles, match each
    %       to a registry row by filename, and extract that one plate. The
    %       filename match is what scopes each project's plates and lets a
    %       cross-part project pass through as all-unmatched.
    %   registryDriven (Anbalagan) - iterate the registry rows directly and read
    %       each plate from the ON-structured data by its (nominal key, ordinal
    %       index). No filename match is used, which is what lets several
    %       registry rows share one source image filename (four genotypes cropped
    %       from one quadrant image per passage). The part-scoped scan root is
    %       what keeps a cross-part project out of this mode; the key-presence
    %       check in ingestByRegistry is a backstop, not the scoping mechanism.
    %
    % Usage:
    %   composite = buildCompositeStruct(rootFolder, 'P2');
    %   composite = buildCompositeStruct(rootFolder, 'P3');
    %   composite = buildCompositeStruct(rootFolder, 'Anbalagan');
    %
    % Inputs:
    %   rootFolder - Path to the folder holding one subfolder per part (P2, P3,
    %                Anbalagan); each part's project folders live in its subfolder
    %   part       - 'P2', 'P3', or 'Anbalagan'; selects registry, extraction
    %                layout, ingestion mode, grouping, and summary style, and
    %                names the subfolder of rootFolder that is scanned
    %
    % Returns:
    %   Struct array where each element is one plate, carrying registry
    %   metadata, Measurements, image data, and NaN placeholders for
    %   library fitting outputs.

    % === RESOLVE PART PROFILE (shared with nested sub-controllers) ===
    profile = resolvePartProfile(part);

    % === COORDINATE SUB-CONTROLLERS ===
    % The scan is scoped to rootFolder/part, so each part only ever sees its
    % own projects. This is what prevents a cross-part project (e.g. a P3 study
    % that shares genotypes with the Anbalagan reanalysis) from being
    % misattributed under registry-driven ingestion.
    composite = initializeComposite();
    projects  = discoverProjects(fullfile(rootFolder, part));
    composite = ingestAllProjects(composite, projects);
    reportSummary(composite);

    % === PROFILE RESOLUTION ===

    function profile = resolvePartProfile(part)
        % MODEL: Map part identifier to its divergence points (TERMINAL)
        %
        % Anbalagan groups its summary on dataset_field_name rather than
        % genotype. Wild_Type and rif1 each appear in Figure 2 and Figure 8, so
        % grouping on genotype would merge the two figures into one summary
        % line; dataset_field_name keeps them as eight separate groups.
        %
        % Historical groups on genotype, because its six genotype names do not
        % collide across the Lendvay and Lundblad source papers.
        switch part
            case 'P2'
                profile.registryFn     = @getPlateRegistryP2;
                profile.nonComplexMode = 'ordinalByHandle';
                profile.ingestionMode  = 'inputFileDriven';
                profile.groupField     = 'dilution_display';
                profile.summaryStyle   = 'P2';
            case 'P3'
                profile.registryFn     = @getPlateRegistryP3;
                profile.nonComplexMode = 'flatKeyed';
                profile.ingestionMode  = 'inputFileDriven';
                profile.groupField     = 'genotype';
                profile.summaryStyle   = 'P3';
            case 'Anbalagan'
                profile.registryFn     = @getPlateRegistryAnbalagan;
                profile.nonComplexMode = 'flatKeyed';   % inert: registry-driven ingestion never reaches the non-complex path
                profile.ingestionMode  = 'registryDriven';
                profile.groupField     = 'dataset_field_name';
                profile.summaryStyle   = 'P3';
            case 'Historical'
                profile.registryFn     = @getPlateRegistryHistorical;
                profile.nonComplexMode = 'flatKeyed';   % inert: registry-driven ingestion never reaches the non-complex path
                profile.ingestionMode  = 'registryDriven';
                profile.groupField     = 'genotype';
                profile.summaryStyle   = 'P3';
            otherwise
                error('buildCompositeStruct:unknownPart', ...
                    ['Unknown part "%s". Expected ''P2'', ''P3'', ''Anbalagan'', ' ...
                     'or ''Historical''.'], part);
        end
    end
    % === SUB-CONTROLLERS ===

    function composite = initializeComposite()
        % SUB-CONTROLLER: Build composite from registry with empty fields

        registry  = profile.registryFn();
        composite = addEmptyFields(registry);

        function composite = addEmptyFields(registry)
            % MODEL: Append empty Measurements and NaN placeholders (TERMINAL)
            for i = 1:length(registry)
                registry(i).Measurements  = struct();
                registry(i).image         = [];
                registry(i).pixels_per_mm = NaN;
                registry(i).phi           = NaN;
                registry(i).epsilon       = NaN;
                registry(i).q             = NaN;
                registry(i).modes         = NaN;
                registry(i).colony_count  = NaN;
            end
            composite = registry;
        end
    end

    function projects = discoverProjects(rootFolder)
        % SUB-CONTROLLER: Find all project .mat files under rootFolder

        folders  = listProjectFolders(rootFolder);
        projects = struct('name', {}, 'filepath', {}, 'filename', {}, 'dateModified', {});
        skipped  = {};

        for f = 1:length(folders)
            [project, skipReason] = resolveProjectFile(folders(f), rootFolder);
            if ~isempty(project)
                projects(end+1) = project; %#ok<AGROW>
            else
                skipped{end+1} = sprintf('  [SKIP] %s: %s', folders(f).name, skipReason); %#ok<AGROW>
            end
        end

        printDiscoverySummary(length(folders), projects, skipped);

        function folders = listProjectFolders(rootFolder)
            % MODEL: List immediate subdirectories of rootFolder (TERMINAL)
            entries    = dir(rootFolder);
            isValidDir = [entries.isdir] & ~startsWith({entries.name}, '.');
            folders    = entries(isValidDir);
        end

        function [project, skipReason] = resolveProjectFile(folder, rootFolder)
            % MODEL: Find most recent DataManagerState .mat in Workspace (TERMINAL)
            workspacePath = fullfile(rootFolder, folder.name, 'Workspace');

            if ~isfolder(workspacePath)
                project    = [];
                skipReason = 'no Workspace folder';
                return;
            end

            matFiles = dir(fullfile(workspacePath, '*DataManagerState*.mat'));

            if isempty(matFiles)
                project    = [];
                skipReason = 'no DataManagerState .mat files in Workspace';
                return;
            end

            [~, newest] = max([matFiles.datenum]);
            project = struct( ...
                'name',         folder.name, ...
                'filepath',     fullfile(matFiles(newest).folder, matFiles(newest).name), ...
                'filename',     matFiles(newest).name, ...
                'dateModified', matFiles(newest).date);
            skipReason = '';
        end

        function printDiscoverySummary(totalFolders, projects, skipped)
            % VIEW: Print project discovery results (TERMINAL)
            fprintf('\n=== Project Discovery ===\n');
            fprintf('Folders scanned: %d\n', totalFolders);
            fprintf('Projects found:  %d\n', length(projects));

            if ~isempty(skipped)
                fprintf('Skipped:         %d\n', length(skipped));
                for s = 1:length(skipped)
                    fprintf('%s\n', skipped{s});
                end
            end

            fprintf('\nResolved projects:\n');
            for p = 1:length(projects)
                fprintf('  [%s] -> %s (%s)\n', ...
                    projects(p).name, projects(p).filename, projects(p).dateModified);
            end
            fprintf('\n');
        end
    end

    function composite = ingestAllProjects(composite, projects)
        % SUB-CONTROLLER: Iterate all discovered projects and ingest each

        printIngestionHeader(length(projects));

        for p = 1:length(projects)
            composite = ingestOneProject(composite, projects(p));
        end

        function composite = ingestOneProject(composite, project)
            % SUB-CONTROLLER: Load one project, then route to the part's ingestion mode
            %
            % Both modes reuse the shared extract/assign/report functions defined
            % at this level. The mode wrappers (ingestByInputFiles,
            % ingestByRegistry) hold only the iteration unit that differs:
            % InputFiles for P2/P3, registry rows for Anbalagan.

            [data, isValid] = loadAndValidateProject(project);
            if ~isValid, return; end

            switch profile.ingestionMode
                case 'inputFileDriven'
                    composite = ingestByInputFiles(composite, data, project);
                case 'registryDriven'
                    composite = ingestByRegistry(composite, data, project);
            end

            % --- SUB-CONTROLLERS OF ingestOneProject ---

            function [data, isValid] = loadAndValidateProject(project)
                % SUB-CONTROLLER: Load .mat and check for required variables

                data        = loadMatFile(project.filepath);
                missingVars = checkRequiredVars(data);
                isValid     = isempty(missingVars);

                if ~isValid
                    printValidationError(project.name, missingVars);
                end

                function data = loadMatFile(filepath)
                    % MODEL: Load .mat file contents (TERMINAL)
                    try
                        data = load(filepath);
                    catch ME
                        fprintf('  [ERROR] Failed to load %s: %s\n', filepath, ME.message);
                        data = [];
                    end
                end

                function missingVars = checkRequiredVars(data)
                    % MODEL: Check for required top-level variables (TERMINAL)
                    required = {'experimentConfig', 'AllMeasures', 'MidputImages', 'FinalParams'};
                    if isempty(data)
                        missingVars = required;
                    else
                        present     = isfield(data, required);
                        missingVars = required(~present);
                    end
                end

                function printValidationError(projectName, missingVars)
                    % VIEW: Print missing variable warning (TERMINAL)
                    fprintf('  [SKIP] %s: missing required variables: %s\n', ...
                        projectName, strjoin(missingVars, ', '));
                end
            end

            function composite = ingestByInputFiles(composite, data, project)
                % SUB-CONTROLLER: Iterate InputFiles, match to registry, extract and assign
                %
                % The original P2/P3 path. Each InputFile is matched to one
                % registry row by filename, so cross-part projects pass through as
                % all-unmatched and write nothing.

                plan       = buildIngestionPlan(data.experimentConfig);
                stats      = initIngestionStats();
                inputFiles = data.experimentConfig.InputFiles;

                for i = 1:length(inputFiles)
                    [composite, stats] = ingestOneInputFile( ...
                        composite, data, inputFiles(i), i, plan, stats);
                end

                printProjectResult(project, stats);

                % --- NESTED IN ingestByInputFiles ---

                function plan = buildIngestionPlan(config)
                    % MODEL: Determine ingestion routing from experimentConfig (TERMINAL)
                    plan = struct();
                    plan.isComplex   = strcmp(config.organizationtype, 'complex');
                    plan.nominalType = config.variables.nominal.type;

                    if ~plan.isComplex
                        plan.nominalValues = config.variables.nominal.values;
                        plan.mapping       = config.mapping.nominal;
                    end
                end

                function [composite, stats] = ingestOneInputFile(composite, data, inputFile, fileIdx, plan, stats)
                    % SUB-CONTROLLER: Match one InputFile to registry, extract and assign

                    filename        = inputFile.OriginalName;
                    [idx, matchMsg] = findFilenameMatch(composite, filename);

                    if ~isempty(matchMsg)
                        fprintf('      %s\n', matchMsg);
                    end

                    if isempty(idx)
                        stats.unmatched{end+1} = filename;
                        return;
                    end

                    % Extract plate data via organization-appropriate path
                    if plan.isComplex
                        [plateData, warnings] = extractComplexPlate(data, composite(idx));
                    else
                        [plateData, warnings] = extractNonComplexPlate(data, plan, fileIdx);
                    end

                    % Report extraction warnings
                    if ~isempty(warnings)
                        printExtractionWarnings(filename, warnings);
                    end

                    % Assign extracted data to composite
                    composite(idx) = assignPlateData(composite(idx), plateData);

                    % Update stats
                    stats = updateStats(stats, plateData);

                    % --- NESTED IN ingestOneInputFile ---

                    function [idx, msg] = findFilenameMatch(composite, filename)
                        % MODEL: Find composite index by exact filename match (TERMINAL)
                        matches = find(strcmp({composite.filename}, filename));
                        msg     = '';
                        if length(matches) == 1
                            idx = matches(1);
                        elseif isempty(matches)
                            idx = [];
                            msg = sprintf('[NO MATCH] %s not found in registry', filename);
                        else
                            idx = matches(1);
                            msg = sprintf('[WARN] %s: %d registry matches, using first', ...
                                filename, length(matches));
                        end
                    end

                    function [plateData, warnings] = extractNonComplexPlate(data, plan, fileIdx)
                        % SUB-CONTROLLER: Dispatch to the layout-specific non-complex extractor
                        %
                        % P3 projects store non-complex plates in a flat keyed layout;
                        % P2 projects store them in an ordinal-indexed nominal='None'
                        % layout addressed by handle. profile.nonComplexMode selects
                        % which. Both branches package results via the shared
                        % buildPlateData defined at the ingestOneProject level.

                        switch profile.nonComplexMode
                            case 'flatKeyed'
                                [plateData, warnings] = extractFlatKeyed(data, plan, fileIdx);
                            case 'ordinalByHandle'
                                [plateData, warnings] = extractOrdinalByHandle(data, fileIdx);
                        end

                        % --- NESTED IN extractNonComplexPlate ---

                        function [plateData, warnings] = extractFlatKeyed(data, plan, fileIdx)
                            % SUB-CONTROLLER: Extract from flat keyed layout (P3)
                            %   AllMeasures.(amKey), MidputImages.(midKey),
                            %   FinalParams.(fpPrefix_suffix)

                            keys     = deriveNonComplexKeys(plan, fileIdx);
                            warnings = {};

                            % Measurements
                            [meas, ok] = getNonComplexMeasurements(data.AllMeasures, keys.allMeasures);
                            if ~ok
                                warnings{end+1} = sprintf( ...
                                    'AllMeasures.%s.Measurements not found', keys.allMeasures);
                                meas = struct();
                            end

                            % Boundaries
                            [val, ok] = getNonComplexField(data.FinalParams, keys.finalParams, 'Boundaries');
                            if ok,  meas.Boundaries = val;
                            else,   warnings{end+1} = sprintf( ...
                                        'FinalParams.%s_Boundaries not found', keys.finalParams);
                            end

                            % DetectionType
                            [val, ok] = getNonComplexField(data.FinalParams, keys.finalParams, 'DetectionType');
                            if ok,  meas.DetectionType = val;
                            else,   warnings{end+1} = sprintf( ...
                                        'FinalParams.%s_DetectionType not found', keys.finalParams);
                            end

                            % Image
                            [img, hasImg] = getNonComplexImage(data.MidputImages, keys.midputImages);
                            if ~hasImg
                                warnings{end+1} = sprintf( ...
                                    'MidputImages.%s not found', keys.midputImages);
                            end

                            % Scaling
                            [scale, hasScale] = getNonComplexScaling(data.MidputImages, keys.midputImages);
                            if ~hasScale
                                warnings{end+1} = sprintf( ...
                                    'MidputImages.%s_Scaling not found', keys.midputImages);
                            end

                            plateData = buildPlateData(meas, img, hasImg, scale, hasScale);

                            % --- NESTED IN extractFlatKeyed ---

                            function keys = deriveNonComplexKeys(plan, fileIdx)
                                % MODEL: Derive AllMeasures/FinalParams/MidputImages keys (TERMINAL)
                                keys = struct();
                                if strcmp(plan.nominalType, 'None')
                                    keys.allMeasures  = 'None';
                                    keys.midputImages = 'None';
                                else
                                    keys.allMeasures  = plan.nominalValues{fileIdx};
                                    keys.midputImages = plan.nominalValues{fileIdx};
                                end
                                keys.finalParams = plan.mapping(fileIdx).value;
                            end

                            function [meas, ok] = getNonComplexMeasurements(allMeasures, key)
                                % MODEL: Extract Measurements from flat AllMeasures (TERMINAL)
                                ok   = false;
                                meas = struct();
                                if ~isfield(allMeasures, key), return; end
                                entry = allMeasures.(key);
                                if ~isfield(entry, 'Measurements'), return; end
                                meas = entry.Measurements;
                                ok   = true;
                            end

                            function [img, hasImg] = getNonComplexImage(midputImages, key)
                                % MODEL: Extract image from flat MidputImages (TERMINAL)
                                hasImg = false;
                                img    = [];
                                if ~isfield(midputImages, key), return; end
                                val = midputImages.(key);
                                if isempty(val), return; end
                                img    = val;
                                hasImg = true;
                            end

                            function [scale, hasScale] = getNonComplexScaling(midputImages, key)
                                % MODEL: Extract scaling from flat MidputImages (TERMINAL)
                                hasScale     = false;
                                scale        = NaN;
                                scalingField = [key '_Scaling'];
                                if ~isfield(midputImages, scalingField), return; end
                                val = midputImages.(scalingField);
                                if isempty(val), return; end
                                scale    = val;
                                hasScale = true;
                            end

                            % SHARED in extractFlatKeyed (called 2x: Boundaries, DetectionType)
                            function [val, ok] = getNonComplexField(source, prefix, suffix)
                                % MODEL: Extract a named field from flat source struct (TERMINAL)
                                ok        = false;
                                val       = [];
                                fieldName = [prefix '_' suffix];
                                if ~isfield(source, fieldName), return; end
                                val = source.(fieldName);
                                ok  = ~isempty(val);
                            end
                        end

                        function [plateData, warnings] = extractOrdinalByHandle(data, fileIdx)
                            % SUB-CONTROLLER: Extract from ordinal-indexed nominal='None' layout (P2)
                            %   AllMeasures.None(ordIdx).Measurements
                            %   MidputImages(ordIdx).None, MidputImages(ordIdx).None_Scaling
                            %   FinalParams(ordIdx).None_<suffix>
                            %
                            % ordIdx is resolved by matching the input file's NewName (the
                            % QuantaColony internal handle) against
                            % experimentConfig.mapping.ordinal handles.

                            cfg      = data.experimentConfig;
                            handle   = cfg.InputFiles(fileIdx).NewName;
                            ordIdx   = resolveOrdinalByHandle(cfg.mapping.ordinal, handle);
                            nomKey   = 'None';
                            warnings = {};

                            if ordIdx < 1
                                warnings{end+1} = sprintf( ...
                                    '%s not found in mapping.ordinal handles', handle);
                                plateData = buildPlateData(struct(), [], false, NaN, false);
                                return;
                            end

                            % Measurements
                            [meas, ok] = getOrdinalIndexedMeasurements(data.AllMeasures, nomKey, ordIdx);
                            if ~ok
                                warnings{end+1} = sprintf( ...
                                    'AllMeasures.%s(%d).Measurements not found', nomKey, ordIdx);
                                meas = struct();
                            end

                            % Boundaries
                            [val, ok] = getOrdinalIndexedField(data.FinalParams, nomKey, ordIdx, 'Boundaries');
                            if ok,  meas.Boundaries = val;
                            else,   warnings{end+1} = sprintf( ...
                                        'FinalParams(%d).%s_Boundaries not found', ordIdx, nomKey);
                            end

                            % DetectionType
                            [val, ok] = getOrdinalIndexedField(data.FinalParams, nomKey, ordIdx, 'DetectionType');
                            if ok,  meas.DetectionType = val;
                            else,   warnings{end+1} = sprintf( ...
                                        'FinalParams(%d).%s_DetectionType not found', ordIdx, nomKey);
                            end

                            % Image
                            [img, hasImg] = getOrdinalIndexedImage(data.MidputImages, nomKey, ordIdx);
                            if ~hasImg
                                warnings{end+1} = sprintf( ...
                                    'MidputImages(%d).%s not found', ordIdx, nomKey);
                            end

                            % Scaling
                            [scale, hasScale] = getOrdinalIndexedScaling(data.MidputImages, nomKey, ordIdx);
                            if ~hasScale
                                warnings{end+1} = sprintf( ...
                                    'MidputImages(%d).%s_Scaling not found', ordIdx, nomKey);
                            end

                            plateData = buildPlateData(meas, img, hasImg, scale, hasScale);

                            % --- NESTED IN extractOrdinalByHandle ---

                            function ordIdx = resolveOrdinalByHandle(mappingOrdinal, handle)
                                % MODEL: Find ordinal index by matching handle string (TERMINAL)
                                ordIdx = -1;
                                for k = 1:length(mappingOrdinal)
                                    if strcmp(mappingOrdinal(k).handle, handle)
                                        ordIdx = k;
                                        return;
                                    end
                                end
                            end

                            function [meas, ok] = getOrdinalIndexedMeasurements(allMeasures, nomKey, ordIdx)
                                % MODEL: Extract Measurements from ordinal-indexed AllMeasures (TERMINAL)
                                ok   = false;
                                meas = struct();
                                if ~isfield(allMeasures, nomKey), return; end
                                arr = allMeasures.(nomKey);
                                if ordIdx > length(arr), return; end
                                if ~isfield(arr(ordIdx), 'Measurements'), return; end
                                meas = arr(ordIdx).Measurements;
                                ok   = true;
                            end

                            function [img, hasImg] = getOrdinalIndexedImage(midputImages, nomKey, ordIdx)
                                % MODEL: Extract image from ordinal-indexed MidputImages (TERMINAL)
                                hasImg = false;
                                img    = [];
                                if ordIdx > length(midputImages), return; end
                                if ~isfield(midputImages, nomKey), return; end
                                val = midputImages(ordIdx).(nomKey);
                                if isempty(val), return; end
                                img    = val;
                                hasImg = true;
                            end

                            function [scale, hasScale] = getOrdinalIndexedScaling(midputImages, nomKey, ordIdx)
                                % MODEL: Extract scaling from ordinal-indexed MidputImages (TERMINAL)
                                hasScale     = false;
                                scale        = NaN;
                                scalingField = [nomKey '_Scaling'];
                                if ordIdx > length(midputImages), return; end
                                if ~isfield(midputImages, scalingField), return; end
                                val = midputImages(ordIdx).(scalingField);
                                if isempty(val), return; end
                                scale    = val;
                                hasScale = true;
                            end

                            % SHARED in extractOrdinalByHandle (called 2x: Boundaries, DetectionType)
                            function [val, ok] = getOrdinalIndexedField(source, nomKey, ordIdx, suffix)
                                % MODEL: Extract a named field from ordinal-indexed source (TERMINAL)
                                ok        = false;
                                val       = [];
                                fieldName = [nomKey '_' suffix];
                                if ordIdx > length(source), return; end
                                if ~isfield(source, fieldName), return; end
                                val = source(ordIdx).(fieldName);
                                ok  = ~isempty(val);
                            end
                        end
                    end
                end
            end

            function composite = ingestByRegistry(composite, data, project)
                % SUB-CONTROLLER: Drive ingestion from the registry, not InputFiles
                %
                % Each registry row is self-addressing: it carries
                % dataset_field_name (-> nominal key via the default branch of
                % resolveNominalKey) and passage (-> ordinal index via the default
                % branch of resolveOrdinalIndex), so extractComplexPlate reads the
                % plate straight from the ON-structured data with no filename
                % match. That is what lets four genotype rows share one source
                % image filename.
                %
                % discoverProjects is scoped to rootFolder/Anbalagan, so this
                % branch only sees Anbalagan projects and a cross-part project
                % (e.g. a P3 study sharing the cdc132 and Wild_Type genotypes)
                % is never present to be misattributed. registryKeysPresent
                % remains as a cheap backstop: a stray or mis-filed folder that
                % carries none of this registry's dataset_field_name keys is
                % reported as matched=0 and left untouched, rather than relied on
                % as the scoping mechanism. Within the matching project,
                % assignment is gated on a non-empty Measurements result, so a
                % (genotype, passage) cell that is absent or genuinely unmeasured
                % stays in its initialized awaiting-measurement state and is
                % never written with an empty struct, and matched counts only
                % plates that carry measurements.

                stats          = initIngestionStats();
                projectMatches = registryKeysPresent(composite, data);

                if projectMatches
                    for idx = 1:numel(composite)
                        [plateData, warnings] = extractComplexPlate(data, composite(idx));

                        if ~isempty(warnings)
                            printExtractionWarnings(composite(idx).filename, warnings);
                        end

                        if ~isempty(fieldnames(plateData.measurements))
                            composite(idx) = assignPlateData(composite(idx), plateData);
                            stats          = updateStats(stats, plateData);
                        end
                    end
                end

                printProjectResult(project, stats);

                % --- NESTED IN ingestByRegistry ---

                function tf = registryKeysPresent(composite, data)
                    % MODEL: True if this project carries any registry nominal key (TERMINAL)
                    % Reads the registry's dataset_field_name values as the set of
                    % nominal keys the ON-structured AllMeasures would hold if this
                    % were the matching project. A project with none of them is a
                    % cross-part project and is skipped.
                    expectedKeys = unique({composite.dataset_field_name});
                    tf           = any(isfield(data.AllMeasures, expectedKeys));
                end
            end

            % === SHARED FUNCTIONS OF ingestOneProject (used by both modes) ===

            function stats = initIngestionStats()
                % MODEL: Initialize per-project ingestion stats (TERMINAL)
                stats = struct( ...
                    'matched',       0, ...
                    'images',        0, ...
                    'scaling',       0, ...
                    'boundaries',    0, ...
                    'detectionType', 0, ...
                    'unmatched',     {{}});
            end

            function [plateData, warnings] = extractComplexPlate(data, entry)
                % SUB-CONTROLLER: Extract from complex (ON) structured data
                %   AllMeasures.(nomKey)(ordIdx), MidputImages(ordIdx).(nomKey),
                %   FinalParams(ordIdx).(nomKey_suffix)
                %
                % Resolves nomKey and ordIdx from the project's experimentConfig so
                % different complex projects can use different axis pairings (e.g.
                % Genotype x Passage for P3_Dataset1/2/3 and the Anbalagan
                % reanalysis, or Incubation Time x Cells Plated for TimeCourseRepA).
                %
                % Called from both ingestion modes: from ingestOneInputFile on the
                % matched entry (P2/P3 complex projects) and from ingestByRegistry
                % on each registry row in turn (Anbalagan).

                nomKey   = resolveNominalKey(data.experimentConfig, entry);
                ordIdx   = resolveOrdinalIndex(data.experimentConfig, entry);
                warnings = {};

                % Measurements
                [meas, ok] = getComplexMeasurements(data.AllMeasures, nomKey, ordIdx);
                if ~ok
                    warnings{end+1} = sprintf( ...
                        'AllMeasures.%s(%d).Measurements not found', nomKey, ordIdx);
                    meas = struct();
                end

                % Boundaries
                [val, ok] = getComplexField(data.FinalParams, nomKey, ordIdx, 'Boundaries');
                if ok,  meas.Boundaries = val;
                else,   warnings{end+1} = sprintf( ...
                            'FinalParams(%d).%s_Boundaries not found', ordIdx, nomKey);
                end

                % DetectionType
                [val, ok] = getComplexField(data.FinalParams, nomKey, ordIdx, 'DetectionType');
                if ok,  meas.DetectionType = val;
                else,   warnings{end+1} = sprintf( ...
                            'FinalParams(%d).%s_DetectionType not found', ordIdx, nomKey);
                end

                % Image
                [img, hasImg] = getComplexImage(data.MidputImages, nomKey, ordIdx);
                if ~hasImg
                    warnings{end+1} = sprintf( ...
                        'MidputImages(%d).%s not found', ordIdx, nomKey);
                end

                % Scaling
                [scale, hasScale] = getComplexScaling(data.MidputImages, nomKey, ordIdx);
                if ~hasScale
                    warnings{end+1} = sprintf( ...
                        'MidputImages(%d).%s_Scaling not found', ordIdx, nomKey);
                end

                plateData = buildPlateData(meas, img, hasImg, scale, hasScale);

                % --- NESTED IN extractComplexPlate ---

                function nomKey = resolveNominalKey(config, entry)
                    % MODEL: Map registry entry to project's nominal field key (TERMINAL)
                    switch config.variables.nominal.type
                        case 'Incubation Time'
                            nomKey = sprintf('v_%d_Days', entry.incubation_days);
                        otherwise
                            % Default: genotype-axis projects (P3_Dataset1/2/3, Anbalagan)
                            nomKey = entry.dataset_field_name;
                    end
                end

                function ordIdx = resolveOrdinalIndex(config, entry)
                    % MODEL: Map registry entry to project's ordinal array index (TERMINAL)
                    switch config.variables.ordinal.type
                        case 'Estimated Number of Cells Plated'
                            % The project stores cell estimates low by a factor of
                            % 16, so each parsed ordinal value is scaled to the
                            % registry's hce convention before the nearest match.
                            % Without the scaling, every density variant of one
                            % genotype-passage collapses onto a single index: the
                            % unscaled values sit far below the registry hce values
                            % and the smallest project value wins all comparisons.
                            % Scaling by 16 separates them (5100 -> 81600,
                            % 1020 -> 16320, 200 -> 3200), so High/Med/Low map to
                            % distinct indices.
                            hceScaleFactor = 16;
                            values = config.variables.ordinal.values;
                            numericValues = zeros(1, length(values));
                            for i = 1:length(values)
                                numStr = strrep(values{i}, 'v_', '');
                                numericValues(i) = str2double(numStr) * hceScaleFactor;
                            end
                            [~, ordIdx] = min(abs(numericValues - entry.hce));
                        otherwise
                            % Default: passage-axis projects (P3_Dataset1/2/3, Anbalagan)
                            ordIdx = entry.passage;
                    end
                end

                function [meas, ok] = getComplexMeasurements(allMeasures, nomKey, ordIdx)
                    % MODEL: Extract Measurements from ON-structured AllMeasures (TERMINAL)
                    ok   = false;
                    meas = struct();
                    if ~isfield(allMeasures, nomKey), return; end
                    arr = allMeasures.(nomKey);
                    if ordIdx > length(arr), return; end
                    if ~isfield(arr(ordIdx), 'Measurements'), return; end
                    meas = arr(ordIdx).Measurements;
                    ok   = true;
                end

                function [img, hasImg] = getComplexImage(midputImages, nomKey, ordIdx)
                    % MODEL: Extract image from ON-structured MidputImages (TERMINAL)
                    hasImg = false;
                    img    = [];
                    if ordIdx > length(midputImages), return; end
                    if ~isfield(midputImages, nomKey), return; end
                    val = midputImages(ordIdx).(nomKey);
                    if isempty(val), return; end
                    img    = val;
                    hasImg = true;
                end

                function [scale, hasScale] = getComplexScaling(midputImages, nomKey, ordIdx)
                    % MODEL: Extract scaling from ON-structured MidputImages (TERMINAL)
                    hasScale     = false;
                    scale        = NaN;
                    scalingField = [nomKey '_Scaling'];
                    if ordIdx > length(midputImages), return; end
                    if ~isfield(midputImages, scalingField), return; end
                    val = midputImages(ordIdx).(scalingField);
                    if isempty(val), return; end
                    scale    = val;
                    hasScale = true;
                end

                % SHARED in extractComplexPlate (called 2x: Boundaries, DetectionType)
                function [val, ok] = getComplexField(source, nomKey, ordIdx, suffix)
                    % MODEL: Extract a named field from ON-structured source (TERMINAL)
                    ok        = false;
                    val       = [];
                    fieldName = [nomKey '_' suffix];
                    if ordIdx > length(source), return; end
                    if ~isfield(source, fieldName), return; end
                    val = source(ordIdx).(fieldName);
                    ok  = ~isempty(val);
                end
            end

            function printExtractionWarnings(filename, warnings)
                % VIEW: Print extraction warnings for one file or plate (TERMINAL)
                for w = 1:length(warnings)
                    fprintf('      [WARN] %s: %s\n', filename, warnings{w});
                end
            end

            function entry = assignPlateData(entry, plateData)
                % MODEL: Write extracted data into composite entry (TERMINAL)
                entry.Measurements = plateData.measurements;
                if plateData.hasImage
                    entry.image = plateData.image;
                end
                if plateData.hasScaling
                    entry.pixels_per_mm = plateData.scaling;
                end
            end

            function stats = updateStats(stats, plateData)
                % MODEL: Increment ingestion counters (TERMINAL)
                stats.matched       = stats.matched + 1;
                stats.images        = stats.images        + double(plateData.hasImage);
                stats.scaling       = stats.scaling       + double(plateData.hasScaling);
                stats.boundaries    = stats.boundaries    + double(isfield(plateData.measurements, 'Boundaries'));
                stats.detectionType = stats.detectionType + double(isfield(plateData.measurements, 'DetectionType'));
            end

            function plateData = buildPlateData(meas, img, hasImg, scale, hasScale)
                % MODEL: Package extraction results into standard struct (TERMINAL)
                % Called from extractComplexPlate, extractFlatKeyed, and
                % extractOrdinalByHandle, so it lives at the shared
                % ingestOneProject level rather than nested in one extractor.
                plateData = struct( ...
                    'measurements', meas, ...
                    'image',        img, ...
                    'hasImage',     hasImg, ...
                    'scaling',      scale, ...
                    'hasScaling',   hasScale);
            end

            function printProjectResult(project, stats)
                % VIEW: Print per-project ingestion summary (TERMINAL)
                extras = sprintf('img=%d scaling=%d bnd=%d dt=%d', ...
                    stats.images, stats.scaling, stats.boundaries, stats.detectionType);

                if isempty(stats.unmatched)
                    fprintf('  [%s] matched=%d (%s)\n', ...
                        project.name, stats.matched, extras);
                else
                    fprintf('  [%s] matched=%d unmatched=%d (%s)\n', ...
                        project.name, stats.matched, length(stats.unmatched), extras);
                    for u = 1:length(stats.unmatched)
                        fprintf('      - %s\n', stats.unmatched{u});
                    end
                end
            end
        end

        function printIngestionHeader(nProjects)
            % VIEW: Print ingestion section header (TERMINAL)
            fprintf('=== Ingestion (%d projects) ===\n', nProjects);
        end
    end

    function reportSummary(composite)
        % VIEW: Print final composite summary to console (TERMINAL)
        %
        % Grouping is driven by profile.groupField ('genotype' for P3 and
        % Anbalagan, 'dilution_display' for P2). The per-plate detail line for
        % missing plates is the one place the parts print different columns, so
        % it branches on profile.summaryStyle.

        gf = profile.groupField;

        total       = length(composite);
        isEmpty     = arrayfun(@(c) isempty(fieldnames(c.Measurements)), composite);
        populated   = sum(~isEmpty);
        withImages  = sum(arrayfun(@(c) ~isempty(c.image), composite));
        withScaling = sum(~isnan([composite.pixels_per_mm]));
        nMissing    = sum(isEmpty);

        fprintf('\n=== Composite Struct Summary ===\n');
        fprintf('Total plates:          %d\n', total);
        fprintf('With measurements:     %d\n', populated);
        fprintf('With images:           %d\n', withImages);
        fprintf('With scaling:          %d\n', withScaling);
        fprintf('Awaiting measurement:  %d\n\n', nMissing);

        groups = unique({composite.(gf)}, 'stable');
        for g = 1:length(groups)
            grpVal   = groups{g};
            grpMask  = strcmp({composite.(gf)}, grpVal);
            grpTotal = sum(grpMask);
            grpPop   = sum(~isEmpty(grpMask));
            fprintf('  %-12s  %2d / %2d\n', grpVal, grpPop, grpTotal);
        end

        if nMissing > 0
            fprintf('\nPlates awaiting measurement:\n');
            for g = 1:length(groups)
                grpVal     = groups{g};
                grpMissing = find(strcmp({composite.(gf)}, grpVal) & isEmpty);
                if isempty(grpMissing), continue; end

                fprintf('  %s:\n', grpVal);
                for m = 1:length(grpMissing)
                    idx = grpMissing(m);
                    switch profile.summaryStyle
                        case 'P3'
                            fprintf('    P%d  %-50s  %2dd  %s\n', ...
                                composite(idx).passage, ...
                                composite(idx).filename, ...
                                composite(idx).incubation_days, ...
                                composite(idx).enrichment);
                        case 'P2'
                            fprintf('    %-55s  hce=%-7g  %2dd\n', ...
                                composite(idx).filename, ...
                                composite(idx).hce, ...
                                composite(idx).incubation_days);
                    end
                end
            end
        end
        fprintf('\n');
    end

end
function composite = addPooledEntries(composite)
    % CONTROLLER: Append pooled replicate entries to composite struct
    %
    % Groups plates by (genotype, passage, hce, incubation_days, source_type,
    % enrichment). For each group with exactly two members that both have
    % populated Measurements, creates a new entry with concatenated per-colony
    % vectors, replicate label 'A+B', and analysis fields reset to NaN.
    % Original per-plate entries are not modified.
    %
    % Usage:
    %   composite = addPooledEntries(composite);
    
    groups = identifyReplicateGroups(composite);
    pooledEntries = buildAllPooledEntries(composite, groups);
    composite = appendEntries(composite, pooledEntries);
    reportPoolingSummary(pooledEntries);
    
    %% === SUB-CONTROLLERS ===
    
    function groups = identifyReplicateGroups(composite)
        % MODEL: Find index pairs sharing a 6-field grouping key (TERMINAL)
        n = length(composite);
        keys = cell(n, 1);
        for i = 1:n
            keys{i} = sprintf('%s|%d|%g|%d|%s|%s', ...
                composite(i).genotype, composite(i).passage, ...
                composite(i).hce, composite(i).incubation_days, ...
                composite(i).source_type, composite(i).enrichment);
        end
        
        [uniqueKeys, ~, keyIdx] = unique(keys, 'stable');
        groups = struct('key', {}, 'indices', {});
        
        for k = 1:length(uniqueKeys)
            members = find(keyIdx == k);
            if length(members) ~= 2; continue; end
            
            bothPopulated = ~isempty(fieldnames(composite(members(1)).Measurements)) ...
                          & ~isempty(fieldnames(composite(members(2)).Measurements));
            if ~bothPopulated; continue; end
            
            groups(end+1).key = uniqueKeys{k}; %#ok<AGROW>
            groups(end).indices = members';
        end
    end
    
    function pooledEntries = buildAllPooledEntries(composite, groups)
        % SUB-CONTROLLER: Build one pooled entry per replicate group
        
        pooledEntries = [];
        for g = 1:length(groups)
            entry = buildOnePooledEntry(composite, groups(g).indices);
            if isempty(pooledEntries)
                pooledEntries = entry;
            else
                pooledEntries(end+1) = entry; %#ok<AGROW>
            end
        end
        
        function entry = buildOnePooledEntry(composite, indices)
            % SUB-CONTROLLER: Create pooled entry from a replicate pair
            
            pooledMeas = poolMeasurements(composite, indices);
            meta = buildPooledMeta(composite, indices);
            entry = assemblePooledEntry(composite(indices(1)), pooledMeas, meta);
            
            function pooledMeas = poolMeasurements(composite, indices)
                % MODEL: Concatenate all per-colony measurement vectors (TERMINAL)
                m1 = composite(indices(1)).Measurements;
                m2 = composite(indices(2)).Measurements;
                pooledMeas = struct();
                
                % Numeric column vectors (always present on populated plates)
                pooledMeas.Radius = [m1.Radius; m2.Radius];
                pooledMeas.Radius_Pixels = [m1.Radius_Pixels; m2.Radius_Pixels];
                pooledMeas.Circularity = [m1.Circularity; m2.Circularity];
                pooledMeas.BoundaryComplexity = [m1.BoundaryComplexity; m2.BoundaryComplexity];
                pooledMeas.CrowdingScores = [m1.CrowdingScores; m2.CrowdingScores];
                
                % Logical filter masks
                pooledMeas.RadiusSubset = [m1.RadiusSubset; m2.RadiusSubset];
                pooledMeas.CircularitySubset = [m1.CircularitySubset; m2.CircularitySubset];
                pooledMeas.BoundaryComplexitySubset = [m1.BoundaryComplexitySubset; m2.BoundaryComplexitySubset];
                pooledMeas.CrowdingScoreSubset = [m1.CrowdingScoreSubset; m2.CrowdingScoreSubset];
                pooledMeas.FinalFilterSubset = [m1.FinalFilterSubset; m2.FinalFilterSubset];
                
                % Cell arrays
                pooledMeas.ColonyID = [m1.ColonyID; m2.ColonyID];
                pooledMeas.Centers = [m1.Centers; m2.Centers];
                pooledMeas.Source = [m1.Source ' + ' m2.Source];
                
                % Optional fields (may be absent if extraction warnings occurred)
                if isfield(m1, 'Boundaries') && isfield(m2, 'Boundaries')
                    pooledMeas.Boundaries = [m1.Boundaries; m2.Boundaries];
                end
                if isfield(m1, 'DetectionType') && isfield(m2, 'DetectionType')
                    pooledMeas.DetectionType = [m1.DetectionType; m2.DetectionType];
                end
            end
            
            function meta = buildPooledMeta(composite, indices)
                % MODEL: Derive pooled replicate label, filename, colony count (TERMINAL)
                reps = sort({composite(indices).replicate});
                meta = struct();
                meta.replicate = strjoin(reps, '+');
                meta.filename = strjoin({composite(indices).filename}, ' + ');
                meta.colony_count = numel(composite(indices(1)).Measurements.Radius) ...
                                  + numel(composite(indices(2)).Measurements.Radius);
                meta.pixels_per_mm = composite(indices(1)).pixels_per_mm;
            end
            
            function entry = assemblePooledEntry(template, pooledMeas, meta)
                % MODEL: Override template fields for pooled entry (TERMINAL)
                entry = template;
                entry.Measurements = pooledMeas;
                entry.replicate = meta.replicate;
                entry.filename = meta.filename;
                entry.colony_count = meta.colony_count;
                entry.pixels_per_mm = meta.pixels_per_mm;
                entry.image = [];
                
                % Reset analysis scalars
                entry.phi = NaN;
                entry.epsilon = NaN;
                entry.q = NaN;
                entry.modes = NaN;
                
                % Reset analysis structs if present from prior fitting
                structFields = {'library_fit', 'fit_comparison', 'kde', ...
                    'mode_detection', 'summary_stats', 'full_colony_set'};
                for f = 1:length(structFields)
                    if isfield(entry, structFields{f})
                        entry.(structFields{f}) = struct();
                    end
                end
            end
        end
    end
    
    function composite = appendEntries(composite, pooledEntries)
        % MODEL: Append pooled entries to composite array (TERMINAL)
        if ~isempty(pooledEntries)
            composite = [composite, pooledEntries];
        end
    end
    
    function reportPoolingSummary(pooledEntries)
        % VIEW: Print pooling results to console (TERMINAL)
        fprintf('\n=== Replicate Pooling ===\n');
        fprintf('Pooled entries created: %d\n', length(pooledEntries));
        
        if ~isempty(pooledEntries)
            for i = 1:length(pooledEntries)
                fprintf('  %-12s P%d  HCE %-6g  rep %-5s  n=%d\n', ...
                    pooledEntries(i).genotype, pooledEntries(i).passage, ...
                    pooledEntries(i).hce, pooledEntries(i).replicate, ...
                    pooledEntries(i).colony_count);
            end
        end
        fprintf('\n');
    end
end
function registry = getPlateRegistryP3()
    % MODEL: Hardcoded metadata registry for all plates in the experiment (TERMINAL)
    %
    % Returns a struct array (one element per plate) with fields:
    %   filename           - Original image filename (string)
    %   genotype           - 'cdc13-2', 'dbf4-1', 'double', 'wild_type'
    %   passage            - Integer 1-5
    %   hce                - Hemocytometer cell estimate (numeric)
    %   incubation_days    - Days of incubation (default 6)
    %   source_type        - 'Standard', 'LargeSourced', or 'SmallSourced'
    %   replicate          - 'A', 'B', or ''
    %   enrichment         - Full enrichment description from spreadsheet
    %   dataset_field_name - Genotype field name used in Dataset .mat files
    %   plate_type         - Struct with fields:
    %                          plate_size      - 'Standard' (90 mm) or 'Large' (140 mm)
    %                          plate_radius_cm - 4.5 (Standard) or 7.0 (Large)

    registry = repmat(makeEmptyEntry(), 1, 0);
    n = 0;

    % =====================================================================
    %  CDC13-2
    % =====================================================================

   % --- P1 (passage 1) ---
    n=n+1; registry(n) = mk('Cdc13_2_P1_6Days_High_RepA.JPG',       'cdc13-2', 1, 75520, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P1_6Days_High_RepB.JPG',       'cdc13-2', 1, 75520, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P1_6Days_Low_RepA.JPG',        'cdc13-2', 1,  3024, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P1_6Days_Low_RepB.JPG',        'cdc13-2', 1,  3024, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P1_6Days_Med_RepA.JPG',        'cdc13-2', 1, 15104, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P1_6Days_Med_RepB.JPG',        'cdc13-2', 1, 15104, 'Standard', 'B', 'Standard');

    % --- P2 (passage 2) ---
    n=n+1; registry(n) = mk('Cdc13_2_P2V2_6Days_High_RepA.JPG',     'cdc13-2', 2,  4352, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P2V2_6Days_High_RepB.JPG',     'cdc13-2', 2,  4352, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P2V2_6Days_Low_RepA.JPG',      'cdc13-2', 2,   176, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P2V2_6Days_Low_RepB.JPG',      'cdc13-2', 2,   176, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P2V2_6Days_Med_RepA.JPG',      'cdc13-2', 2,   864, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P2V2_6Days_Med_RepB.JPG',      'cdc13-2', 2,   864, 'Standard', 'B', 'Standard');

    % --- P3 (passage 3) ---
    n=n+1; registry(n) = mk('Cdc13_2_P3V1_6Days_High_RepA.JPG',     'cdc13-2', 3,  3872, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P3V1_6Days_High_RepB.JPG',     'cdc13-2', 3,  3872, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P3V1_6Days_Low_RepA.JPG',      'cdc13-2', 3,   160, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P3V1_6Days_Low_RepB.JPG',      'cdc13-2', 3,   160, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P3V1_6Days_Med_RepA.JPG',      'cdc13-2', 3,   768, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P3V1_6Days_Med_RepB.JPG',      'cdc13-2', 3,   768, 'Standard', 'B', 'Standard');

    % --- P4 (passage 4) ---
    n=n+1; registry(n) = mk('Cdc13_2_P4V2_6Days_High_RepB.JPG',     'cdc13-2', 4,  4064, 'Standard',     'B', 'Standard');
    n=n+1; registry(n) = mk('Cdc13_2_P4_6Days_LargeColonies_A.JPG', 'cdc13-2', 4,   752, 'LargeSourced', 'A', 'Large Colonies (Source: Cdc13_2_P3V1_6Days_Low_RepB.JPG)');
    n=n+1; registry(n) = mk('Cdc13_2_P4_6Days_LargeColonies_B.JPG', 'cdc13-2', 4,   752, 'LargeSourced', 'B', 'Large Colonies (Source: Cdc13_2_P3V1_6Days_Low_RepB.JPG)');
    n=n+1; registry(n) = mk('Cdc13_2_P4_6Days_SmallColonies.JPG',   'cdc13-2', 4,   656, 'SmallSourced', '',  'Small Colonies (Source: Cdc13_2_P3V1_6Days_Low_RepB.JPG)');

    % --- P5 (passage 5) --- All from Large-Enriched P4 plates ---
    n=n+1; registry(n) = mk('Cdc13_2_P5_6Days_High_RepA.JPG',       'cdc13-2', 5,  4032, 'Standard', 'A', 'Standard, but from a Large-Enriched Plate');
    n=n+1; registry(n) = mk('Cdc13_2_P5_6Days_High_RepB.JPG',       'cdc13-2', 5,  4032, 'Standard', 'B', 'Standard, but from a Large-Enriched Plate');
    n=n+1; registry(n) = mk('Cdc13_2_P5_6Days_Low_RepA.JPG',        'cdc13-2', 5,   160, 'Standard', 'A', 'Standard, but from a Large-Enriched Plate');
    n=n+1; registry(n) = mk('Cdc13_2_P5_6Days_Low_RepB.JPG',        'cdc13-2', 5,   160, 'Standard', 'B', 'Standard, but from a Large-Enriched Plate');
    n=n+1; registry(n) = mk('Cdc13_2_P5_6Days_Med_RepA.JPG',        'cdc13-2', 5,   800, 'Standard', 'A', 'Standard, but from a Large-Enriched Plate');
    n=n+1; registry(n) = mk('Cdc13_2_P5_6Days_Med_RepB.JPG',        'cdc13-2', 5,   800, 'Standard', 'B', 'Standard, but from a Large-Enriched Plate');

    % --- P1 (passage 1) ---
    n=n+1; registry(n) = mk('Dbf4_1_P1_6Days_High_RepA.JPG',        'dbf4-1', 1, 81600, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P1_6Days_High_RepB.JPG',        'dbf4-1', 1, 81600, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P1_6Days_Low_RepA.JPG',         'dbf4-1', 1,  3264, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P1_6Days_Low_RepB.JPG',         'dbf4-1', 1,  3264, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P1_6Days_Med_RepA.JPG',         'dbf4-1', 1, 16320, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P1_6Days_Med_RepB.JPG',         'dbf4-1', 1, 16320, 'Standard', 'B', 'Standard');

    % --- P1 (passage 1, 21-day incubation) ---
    n=n+1; registry(n) = mk('Dbf4_1_P1_21Days_High_RepA.JPG',       'dbf4-1', 1, 81600, 'Standard', 'A', 'Standard', 21);
    n=n+1; registry(n) = mk('Dbf4_1_P1_21Days_High_RepB.JPG',       'dbf4-1', 1, 81600, 'Standard', 'B', 'Standard', 21);
    n=n+1; registry(n) = mk('Dbf4_1_P1_21Days_Low_RepA.JPG',        'dbf4-1', 1,  3264, 'Standard', 'A', 'Standard', 21);
    n=n+1; registry(n) = mk('Dbf4_1_P1_21Days_Low_RepB.JPG',        'dbf4-1', 1,  3264, 'Standard', 'B', 'Standard', 21);
    n=n+1; registry(n) = mk('Dbf4_1_P1_21Days_Med_RepA.JPG',        'dbf4-1', 1, 16320, 'Standard', 'A', 'Standard', 21);
    n=n+1; registry(n) = mk('Dbf4_1_P1_21Days_Med_RepB.JPG',        'dbf4-1', 1, 16320, 'Standard', 'B', 'Standard', 21);

    % --- P2 (passage 2) ---
    n=n+1; registry(n) = mk('Dbf4_1_P2V2_6Days_High_RepB.JPG',      'dbf4-1', 2,  3840, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P2V2_6Days_Low_RepA.JPG',       'dbf4-1', 2,   144, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P2V2_6Days_Low_RepB.JPG',       'dbf4-1', 2,   144, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P2V2_6Days_Med_RepA.JPG',       'dbf4-1', 2,   768, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P2V2_6Days_Med_RepB.JPG',       'dbf4-1', 2,   768, 'Standard', 'B', 'Standard');

    % --- P3 (passage 3) ---
    n=n+1; registry(n) = mk('Dbf4_1_P3V1_6Days_High_RepA.JPG',      'dbf4-1', 3,  4096, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P3V1_6Days_Low_RepA.JPG',       'dbf4-1', 3,   160, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P3V1_6Days_Low_RepB.JPG',       'dbf4-1', 3,   160, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P3V1_6Days_Med_RepA.JPG',       'dbf4-1', 3,   816, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P3V1_6Days_Med_RepB.JPG',       'dbf4-1', 3,   816, 'Standard', 'B', 'Standard');

    % --- P4 (passage 4) ---
    n=n+1; registry(n) = mk('Dbf4_1_P4V2_6Days_High_RepA.JPG',      'dbf4-1', 4,  3456, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P4V2_6Days_High_RepB.JPG',      'dbf4-1', 4,  3456, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P4V2_6Days_Low_RepA.JPG',       'dbf4-1', 4,   144, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P4V2_6Days_Low_RepB.JPG',       'dbf4-1', 4,   144, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P4V2_6Days_Med_RepA.JPG',       'dbf4-1', 4,   688, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P4V2_6Days_Med_RepB.JPG',       'dbf4-1', 4,   688, 'Standard', 'B', 'Standard');

    % --- P5 (passage 5) ---
    n=n+1; registry(n) = mk('Dbf4_1_P5V1_6Days_High_RepA.JPG',      'dbf4-1', 5,  4000, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P5V1_6Days_High_RepB.JPG',      'dbf4-1', 5,  4000, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P5V1_6Days_Low_RepA.JPG',       'dbf4-1', 5,   160, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P5V1_6Days_Low_RepB.JPG',       'dbf4-1', 5,   160, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P5V1_6Days_Med_RepA.JPG',       'dbf4-1', 5,   800, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Dbf4_1_P5V1_6Days_Med_RepB.JPG',       'dbf4-1', 5,   800, 'Standard', 'B', 'Standard');

    % --- P1 (passage 1) ---
    n=n+1; registry(n) = mk('Double_P1_6Days_High_RepA.JPG',        'double', 1, 79360, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P1_6Days_High_RepB.JPG',        'double', 1, 79360, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P1_6Days_Low_RepA.JPG',         'double', 1,  3168, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P1_6Days_Low_RepB.JPG',         'double', 1,  3168, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P1_6Days_Med_RepA.JPG',         'double', 1, 15872, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P1_6Days_Med_RepB.JPG',         'double', 1, 15872, 'Standard', 'B', 'Standard');

    % --- P2 (passage 2) ---
    n=n+1; registry(n) = mk('Double_P2V2_6Days_High_RepA.JPG',      'double', 2,  3744, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P2V2_6Days_High_RepB.JPG',      'double', 2,  3744, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P2V2_6Days_Low_RepA.JPG',       'double', 2,   144, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P2V2_6Days_Low_RepB.JPG',       'double', 2,   144, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P2V2_6Days_Med_RepA.JPG',       'double', 2,   752, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P2V2_6Days_Med_RepB.JPG',       'double', 2,   752, 'Standard', 'B', 'Standard');

    % --- P3 (passage 3) ---
    n=n+1; registry(n) = mk('Double_P3V1_6Days_High_RepA.JPG',      'double', 3,  4096, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P3V1_6Days_High_RepB.JPG',      'double', 3,  4096, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P3V1_6Days_Low_RepA.JPG',       'double', 3,   816, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P3V1_6Days_Low_RepB.JPG',       'double', 3,   160, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P3V1_6Days_Med_RepA.JPG',       'double', 3,   816, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P3V1_6Days_Med_RepB.JPG',       'double', 3,   160, 'Standard', 'B', 'Standard');

    % --- P4 (passage 4) ---
    n=n+1; registry(n) = mk('Double_P4V2_6Days_High_RepA.JPG',      'double', 4,  4256, 'Standard',     'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P4V2_6Days_High_RepB.JPG',      'double', 4,  4256, 'Standard',     'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P4V2_6Days_Low_RepA.JPG',       'double', 4,   176, 'Standard',     'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P4V2_6Days_Low_RepB.JPG',       'double', 4,   176, 'Standard',     'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P4V2_6Days_Med_RepA.JPG',       'double', 4,   848, 'Standard',     'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P4V2_6Days_Med_RepB.JPG',       'double', 4,   848, 'Standard',     'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P4_6Days_LargeColonies.JPG',    'double', 4,   928, 'LargeSourced', '',  'Large Colonies (Source: Double_P3V1_6Days_Low_RepA.JPG)');
    n=n+1; registry(n) = mk('Double_P4_6Days_SmallColonies_A.JPG',  'double', 4,   656, 'SmallSourced', 'A', 'Small Colonies (Source: Double_P3V1_6Days_Low_RepA.JPG)');
    n=n+1; registry(n) = mk('Double_P4_6Days_SmallColonies_B.JPG',  'double', 4,   656, 'SmallSourced', 'B', 'Small Colonies (Source: Double_P3V1_6Days_Low_RepA.JPG)');

    % --- P5 (passage 5) ---
    n=n+1; registry(n) = mk('Double_P5_6Days_High_RepA.JPG',        'double', 5,  3456, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P5_6Days_High_RepB.JPG',        'double', 5,  3456, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P5_6Days_Med_A.JPG',            'double', 5,   144, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P5_6Days_Med_B.JPG',            'double', 5,   144, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Double_P5_6Days_Med_RepA.JPG',         'double', 5,   688, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Double_P5_6Days_Med_RepB.JPG',         'double', 5,   688, 'Standard', 'B', 'Standard');

    % --- P1 (passage 1) ---
    n=n+1; registry(n) = mk('Wild_Type_P1_6Days_High_RepA.JPG',     'wild_type', 1, 57600, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P1_6Days_High_RepB.JPG',     'wild_type', 1, 57600, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P1_6Days_Low_RepA.JPG',      'wild_type', 1,  2304, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P1_6Days_Low_RepB.JPG',      'wild_type', 1,  2304, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P1_6Days_Med_RepA.JPG',      'wild_type', 1, 11520, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P1_6Days_Med_RepB.JPG',      'wild_type', 1, 11520, 'Standard', 'B', 'Standard');

    % --- P2 (passage 2, V2 standard plates) ---
    n=n+1; registry(n) = mk('Wild_Type_P2V2_6Days_High_RepA.JPG',   'wild_type', 2,  3776, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V2_6Days_High_RepB.JPG',   'wild_type', 2,  3776, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V2_6Days_Low_RepA.JPG',    'wild_type', 2,   144, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V2_6Days_Low_RepB.JPG',    'wild_type', 2,   144, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V2_6Days_Med_RepA.JPG',    'wild_type', 2,   752, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V2_6Days_Med_RepB.JPG',    'wild_type', 2,   752, 'Standard', 'B', 'Standard');

    % --- P2 (passage 2, V3 dilution series) ---
    n=n+1; registry(n) = mk('Wild_Type_P2V3_6Days_High.JPG',        'wild_type', 2,   160, 'Standard', '',  'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V3_6Days_Low.JPG',         'wild_type', 2,   6.4, 'Standard', '',  'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P2V3_6Days_Med.JPG',         'wild_type', 2,    32, 'Standard', '',  'Standard');

    % --- P3 (passage 3, V1 standard plates) ---
    n=n+1; registry(n) = mk('WildType_P3_LargePlate_6Days_RepA.JPG','wild_type', 3,   160, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('WildType_P3_LargePlate_6Days_RepB.JPG','wild_type', 3,   160, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P3V1_6Days_High_RepB.JPG',   'wild_type', 3,  3856, 'Standard', 'B', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P3V1_6Days_Med_RepA.JPG',    'wild_type', 3,   768, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P3V1_6Days_Med_RepB.JPG',    'wild_type', 3,   768, 'Standard', 'B', 'Standard');

    % --- P3 (passage 3, V2 dedicated ~50 colony plates) ---
    n=n+1; registry(n) = mk('Wild_Type_P3V2_6Days_50_RepA.JPG',     'wild_type', 3,   800, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P3V2_6Days_50_RepB.JPG',     'wild_type', 3,   800, 'Standard', 'B', 'Standard');

    % --- P4 (passage 4) ---
    n=n+1; registry(n) = mk('Wild_Type_P4V2_6Days_50_RepA.JPG',     'wild_type', 4,   800, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P4V2_6Days_50_RepB.JPG',     'wild_type', 4,   800, 'Standard', 'B', 'Standard');

    % --- P5 (passage 5) ---
    n=n+1; registry(n) = mk('Wild_Type_P5V2_6Days_50_RepA.JPG',     'wild_type', 5,   800, 'Standard', 'A', 'Standard');
    n=n+1; registry(n) = mk('Wild_Type_P5V2_6Days_50_RepB.JPG',     'wild_type', 5,   800, 'Standard', 'B', 'Standard');

    % === STAMP PLATE SIZES ===
    % Every entry above defaults to Standard; override the large plates here.
    registry = applyPlateSizes(registry);

    % === SHARED FUNCTIONS ===

    function plateType = makePlateType(sizeLabel)
        % MODEL: Build the plate_type sub-struct from a size label (TERMINAL)
        % Single source of truth for the size-to-radius mapping.
        switch sizeLabel
            case 'Standard'
                radiusCm = 4.5;   % 90 mm diameter plate
            case 'Large'
                radiusCm = 7.0;   % 140 mm diameter plate
            otherwise
                error('getPlateRegistryP3:badPlateSize', ...
                      'Unknown plate size label: %s', sizeLabel);
        end
        plateType = struct( ...
            'plate_size',      sizeLabel, ...
            'plate_radius_cm', radiusCm);
    end

    % === NESTED HELPERS ===

    function entry = makeEmptyEntry()
        % MODEL: Create empty struct with all registry fields (TERMINAL)
        entry = struct( ...
            'filename',           '', ...
            'genotype',           '', ...
            'passage',            0, ...
            'hce',                NaN, ...
            'incubation_days',    6, ...
            'source_type',        '', ...
            'replicate',          '', ...
            'enrichment',         '', ...
            'dataset_field_name', '', ...
            'plate_type',         makePlateType('Standard'));
    end

    function entry = mk(fn, gt, ps, hce, st, rep, enr, inc)
        % MODEL: Create one registry entry (TERMINAL)
        % Optional 8th argument: incubation_days (default 6)
        % plate_type defaults to Standard; applyPlateSizes overrides large plates.
        if nargin < 8
            inc = 6;
        end
        entry = struct( ...
            'filename',           fn, ...
            'genotype',           gt, ...
            'passage',            ps, ...
            'hce',                hce, ...
            'incubation_days',    inc, ...
            'source_type',        st, ...
            'replicate',          rep, ...
            'enrichment',         enr, ...
            'dataset_field_name', mapGenotypeToField(gt), ...
            'plate_type',         makePlateType('Standard'));

        function fieldName = mapGenotypeToField(gt)
            % MODEL: Map genotype to Dataset .mat field name (TERMINAL)
            switch gt
                case 'cdc13-2',    fieldName = 'cdc132';
                case 'dbf4-1',     fieldName = 'dbf41';
                case 'double',     fieldName = 'dbf41_cdc132';
                case 'wild_type',  fieldName = 'Wild_Type';
                otherwise,         fieldName = gt;
            end
        end
    end

    function registry = applyPlateSizes(registry)
        % CONTROLLER: Override the large-plate entries with the Large plate_type
        % Calls only MODEL functions (getLargePlateFilenames, makePlateType).

        largeFilenames = getLargePlateFilenames();

        registryFilenames = {registry.filename};

        % Validate every large filename matches a registry entry (catches typos)
        matched = ismember(largeFilenames, registryFilenames);
        if ~all(matched)
            unmatched = largeFilenames(~matched);
            error('getPlateRegistryP3:largePlateNotFound', ...
                  'Large-plate filename(s) not found in registry: %s', ...
                  strjoin(unmatched, ', '));
        end

        largeType = makePlateType('Large');
        isLarge = ismember(registryFilenames, largeFilenames);
        for i = find(isLarge)
            registry(i).plate_type = largeType;
        end

        function filenames = getLargePlateFilenames()
            % MODEL: Filenames that used 140 mm (large) plates (TERMINAL)
            filenames = { ...
                'WildType_P3_LargePlate_6Days_RepA.JPG', ...
                'WildType_P3_LargePlate_6Days_RepB.JPG', ...
                'Wild_Type_P2V3_6Days_High.JPG', ...
                'Wild_Type_P2V3_6Days_Low.JPG', ...
                'Wild_Type_P2V3_6Days_Med.JPG', ...
                'Wild_Type_P3V2_6Days_50_RepA.JPG', ...
                'Wild_Type_P3V2_6Days_50_RepB.JPG', ...
                'Wild_Type_P4V2_6Days_50_RepA.JPG', ...
                'Wild_Type_P4V2_6Days_50_RepB.JPG', ...
                'Wild_Type_P5V2_6Days_50_RepA.JPG', ...
                'Wild_Type_P5V2_6Days_50_RepB.JPG', ...
                'Dbf4_1_P5V1_6Days_High_RepA.JPG', ...
                'Dbf4_1_P5V1_6Days_High_RepB.JPG', ...
                'Dbf4_1_P5V1_6Days_Low_RepA.JPG', ...
                'Dbf4_1_P5V1_6Days_Low_RepB.JPG', ...
                'Dbf4_1_P5V1_6Days_Med_RepB.JPG', ...
                'Cdc13_2_P4_6Days_LargeColonies_A.JPG', ...
                'Cdc13_2_P4_6Days_LargeColonies_B.JPG', ...
                'Cdc13_2_P4_6Days_SmallColonies.JPG', ...
                'Double_P4_6Days_LargeColonies.JPG', ...
                'Double_P4_6Days_SmallColonies_A.JPG', ...
                'Double_P4_6Days_SmallColonies_B.JPG'};
        end
    end
end
function registry = getPlateRegistryP2()
    % MODEL: Hardcoded metadata registry for dilution series plates (TERMINAL)
    %
    % Returns a struct array (one element per plate) with fields:
    %   filename           - Original image filename (string, matches InputFiles.OriginalName)
    %   genotype           - 'wild_type' (constant for this project)
    %   passage            - 1 (constant)
    %   hce                - Estimated hemocytometer cell equivalents,
    %                        back-calculated from anchor: 16000X plate ~ 150 HCE
    %                        Stock HCE = 150 * 16000 = 2,400,000
    %   incubation_days    - 3 (constant)
    %   source_type        - 'Standard' (constant)
    %   replicate          - 'A' (constant)
    %   enrichment         - 'Standard' (constant)
    %   dataset_field_name - 'None' (unused on non-complex path; kept for schema parity)
    %   dilution_display   - Human-readable dilution label (e.g., '100X')
    %   dilution_factor    - Numeric dilution factor (e.g., 100)
    %   plate_type         - Struct with fields:
    %                          plate_size      - 'Standard' (90 mm), constant for this project
    %                          plate_radius_cm - 4.5 (Standard)

    registry = repmat(makeEmptyEntry(), 1, 0);
    n = 0;

    n=n+1; registry(n) = mk('100X.jpeg',    '100X',       100, 384000);
    n=n+1; registry(n) = mk('500X.jpeg',    '500X',       500,  76800);
    n=n+1; registry(n) = mk('1000X.jpeg',   '1000X',     1000,  38400);
    n=n+1; registry(n) = mk('2000X.jpeg',   '2000X',     2000,  19200);
    n=n+1; registry(n) = mk('4000X.jpeg',   '4000X',     4000,   9600);
    n=n+1; registry(n) = mk('8000X.jpeg',   '8000X',     8000,   4800);
    n=n+1; registry(n) = mk('16000X.jpeg',  '16000X',   16000,   2400);
    n=n+1; registry(n) = mk('32000X.jpeg',  '32000X',   32000,   1200);
    n=n+1; registry(n) = mk('64000X.jpeg',  '64000X',   64000,    600);
    n=n+1; registry(n) = mk('128000X.jpeg', '128000X', 128000,    300);

    % === SHARED FUNCTIONS ===

    function plateType = makePlateType(sizeLabel)
        % MODEL: Build the plate_type sub-struct from a size label (TERMINAL)
        % Single source of truth for the size-to-radius mapping.
        switch sizeLabel
            case 'Standard'
                radiusCm = 4.5;   % 90 mm diameter plate
            case 'Large'
                radiusCm = 7.0;   % 140 mm diameter plate
            otherwise
                error('getPlateRegistryP2:badPlateSize', ...
                      'Unknown plate size label: %s', sizeLabel);
        end
        plateType = struct( ...
            'plate_size',      sizeLabel, ...
            'plate_radius_cm', radiusCm);
    end

    % === NESTED HELPERS ===

    function entry = makeEmptyEntry()
        % MODEL: Create empty struct with all registry fields (TERMINAL)
        entry = struct( ...
            'filename',           '', ...
            'genotype',           '', ...
            'passage',            0, ...
            'hce',                NaN, ...
            'incubation_days',    3, ...
            'source_type',        '', ...
            'replicate',          '', ...
            'enrichment',         '', ...
            'dataset_field_name', '', ...
            'dilution_display',   '', ...
            'dilution_factor',    NaN, ...
            'plate_type',         makePlateType('Standard'));
    end

    function entry = mk(fn, dilDisp, dilFactor, hce)
        % MODEL: Create one registry entry (TERMINAL)
        % plate_type is Standard for every plate in this project.
        entry = struct( ...
            'filename',           fn, ...
            'genotype',           'wild_type', ...
            'passage',            1, ...
            'hce',                hce, ...
            'incubation_days',    3, ...
            'source_type',        'Standard', ...
            'replicate',          'A', ...
            'enrichment',         'Standard', ...
            'dataset_field_name', 'None', ...
            'dilution_display',   dilDisp, ...
            'dilution_factor',    dilFactor, ...
            'plate_type',         makePlateType('Standard'));
    end
end
function registry = getPlateRegistryAnbalagan()
    % MODEL: Hardcoded metadata registry for the Anbalagan 2011 reanalysis (TERMINAL)
    %
    % One element per (figure, genotype, generation) cell, 32 total. Each figure
    % has four genotypes and four generation timepoints (25, 50, 75, 100). One
    % source image per (figure, generation) holds all four genotypes of that
    % figure, so four registry rows share each filename. Source image 1 is
    % Figure 2 and source image 2 is Figure 8, following the filename pattern
    % Anbalagan2011_<image>_<generations>.png.
    %
    % Ingestion for this part is registry-driven: extractComplexPlate reads each
    % row from AllMeasures.(dataset_field_name)(passage), so filename is never
    % used to locate data. It serves as the display label in Phase 2.
    %
    % Returns a struct array with fields:
    %   filename           - Source image filename (display label only)
    %   genotype           - Machine-safe genotype name, shared across figures
    %   genotype_display   - Human-readable genotype label
    %   figure             - Anbalagan 2011 figure number (2 or 8)
    %   generations        - Generation timepoint (25, 50, 75, or 100)
    %   passage            - Ordinal SLOT INDEX 1-4 in the QuantaColony project
    %                        (v_25, v_50, v_75, v_100). Holds the index, not a
    %                        passage number; the field name is kept because
    %                        resolveOrdinalIndex reads entry.passage.
    %   hce                - 'N/A' (no hemocytometer estimate for this dataset)
    %   incubation_days    - 3 (constant)
    %   source_type        - 'Standard' (constant)
    %   replicate          - 'N/A' (not recorded for this dataset)
    %   enrichment         - 'N/A' (not recorded for this dataset)
    %   dataset_field_name - Nominal key in the project's AllMeasures, formed as
    %                        <genotype>_Figure_<figure> (e.g. 'rif1_est2_Figure_8')
    %   plate_type         - Struct with fields:
    %                          plate_size      - 'Standard' (90 mm)
    %                          plate_radius_cm - 4.5

    registry = repmat(makeEmptyEntry(), 1, 0);
    n = 0;

    % =====================================================================
    %  FIGURE 2 (source image 1)
    % =====================================================================

    % --- Wild Type ---
    n=n+1; registry(n) = mk('Anbalagan2011_1_25.png',  'Wild_Type',   'Wild Type',      2,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_1_50.png',  'Wild_Type',   'Wild Type',      2,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_1_75.png',  'Wild_Type',   'Wild Type',      2,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_1_100.png', 'Wild_Type',   'Wild Type',      2, 100, 4);

    % --- rif1Δ ---
    n=n+1; registry(n) = mk('Anbalagan2011_1_25.png',  'rif1',        'rif1Δ',          2,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_1_50.png',  'rif1',        'rif1Δ',          2,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_1_75.png',  'rif1',        'rif1Δ',          2,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_1_100.png', 'rif1',        'rif1Δ',          2, 100, 4);

    % --- cdc13-2 ---
    n=n+1; registry(n) = mk('Anbalagan2011_1_25.png',  'cdc132',      'cdc13-2',        2,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_1_50.png',  'cdc132',      'cdc13-2',        2,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_1_75.png',  'cdc132',      'cdc13-2',        2,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_1_100.png', 'cdc132',      'cdc13-2',        2, 100, 4);

    % --- rif1Δ cdc13-2 ---
    n=n+1; registry(n) = mk('Anbalagan2011_1_25.png',  'rif1_cdc132', 'rif1Δ, cdc13-2', 2,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_1_50.png',  'rif1_cdc132', 'rif1Δ, cdc13-2', 2,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_1_75.png',  'rif1_cdc132', 'rif1Δ, cdc13-2', 2,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_1_100.png', 'rif1_cdc132', 'rif1Δ, cdc13-2', 2, 100, 4);

    % =====================================================================
    %  FIGURE 8 (source image 2)
    % =====================================================================

    % --- Wild Type ---
    n=n+1; registry(n) = mk('Anbalagan2011_2_25.png',  'Wild_Type',   'Wild Type',      8,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_2_50.png',  'Wild_Type',   'Wild Type',      8,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_2_75.png',  'Wild_Type',   'Wild Type',      8,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_2_100.png', 'Wild_Type',   'Wild Type',      8, 100, 4);

    % --- est2Δ ---
    n=n+1; registry(n) = mk('Anbalagan2011_2_25.png',  'est2',        'est2Δ',          8,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_2_50.png',  'est2',        'est2Δ',          8,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_2_75.png',  'est2',        'est2Δ',          8,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_2_100.png', 'est2',        'est2Δ',          8, 100, 4);

    % --- rif1Δ ---
    n=n+1; registry(n) = mk('Anbalagan2011_2_25.png',  'rif1',        'rif1Δ',          8,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_2_50.png',  'rif1',        'rif1Δ',          8,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_2_75.png',  'rif1',        'rif1Δ',          8,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_2_100.png', 'rif1',        'rif1Δ',          8, 100, 4);

    % --- rif1Δ est2Δ ---
    n=n+1; registry(n) = mk('Anbalagan2011_2_25.png',  'rif1_est2',   'rif1Δ, est2Δ',   8,  25, 1);
    n=n+1; registry(n) = mk('Anbalagan2011_2_50.png',  'rif1_est2',   'rif1Δ, est2Δ',   8,  50, 2);
    n=n+1; registry(n) = mk('Anbalagan2011_2_75.png',  'rif1_est2',   'rif1Δ, est2Δ',   8,  75, 3);
    n=n+1; registry(n) = mk('Anbalagan2011_2_100.png', 'rif1_est2',   'rif1Δ, est2Δ',   8, 100, 4);

    % === SHARED FUNCTIONS ===

    function plateType = makePlateType(sizeLabel)
        % MODEL: Build the plate_type sub-struct from a size label (TERMINAL)
        % Single source of truth for the size-to-radius mapping.
        switch sizeLabel
            case 'Standard'
                radiusCm = 4.5;   % 90 mm diameter plate
            case 'Large'
                radiusCm = 7.0;   % 140 mm diameter plate
            otherwise
                error('getPlateRegistryAnbalagan:badPlateSize', ...
                      'Unknown plate size label: %s', sizeLabel);
        end
        plateType = struct( ...
            'plate_size',      sizeLabel, ...
            'plate_radius_cm', radiusCm);
    end

    % === NESTED HELPERS ===

    function entry = makeEmptyEntry()
        % MODEL: Create empty struct with all registry fields (TERMINAL)
        entry = struct( ...
            'filename',           '', ...
            'genotype',           '', ...
            'genotype_display',   '', ...
            'figure',             NaN, ...
            'generations',        NaN, ...
            'passage',            0, ...
            'hce',                'N/A', ...
            'incubation_days',    3, ...
            'source_type',        'Standard', ...
            'replicate',          'N/A', ...
            'enrichment',         'N/A', ...
            'dataset_field_name', '', ...
            'plate_type',         makePlateType('Standard'));
    end

    function entry = mk(fn, gt, gtDisp, fig, gens, slot)
        % MODEL: Create one registry entry (TERMINAL)
        % dataset_field_name is formed as <gt>_Figure_<fig>, which reproduces the
        % project's nominal values exactly for all eight genotypes.
        entry = struct( ...
            'filename',           fn, ...
            'genotype',           gt, ...
            'genotype_display',   gtDisp, ...
            'figure',             fig, ...
            'generations',        gens, ...
            'passage',            slot, ...
            'hce',                'N/A', ...
            'incubation_days',    3, ...
            'source_type',        'Standard', ...
            'replicate',          'N/A', ...
            'enrichment',         'N/A', ...
            'dataset_field_name', sprintf('%s_Figure_%d', gt, fig), ...
            'plate_type',         makePlateType('Standard'));
    end
end
function registry = getPlateRegistryHistorical()
    % MODEL: Hardcoded metadata registry for the Historical reanalyses (TERMINAL)
    %
    % One element per (genotype, passage) cell, 24 total: five Lendvay 1996
    % genotypes and one Lundblad 1989 genotype, each across four passages.
    % Genotype names do not collide between the two papers, so genotype alone
    % remains a valid grouping key; source_paper is carried separately so
    % downstream code can split the two experiments without parsing suffixes.
    %
    % Source images hold several genotypes each, so filename is shared by every
    % row cropped from one figure panel:
    %   Fig Senescence Mutants of 1.png  - est1Delta, tlc1Delta
    %   Fig Senescence Mutants of 2.png  - est2-1, est3-1
    %   Fig Senescence Mutants of 3.png  - est4-1
    %   Fig A mutant WIth.png            - est1-1 (Lundblad)
    %
    % Ingestion for this part is registry-driven: extractComplexPlate reads each
    % row from AllMeasures.(dataset_field_name)(passage), so filename never
    % locates data. It serves as the Phase 2 display label and the per-plate
    % column in the build summary.
    %
    % Many cells carry a Measurements struct whose fields are all empty, which
    % is the senescent phenotype rather than missing analysis. Those rows are
    % written like any other; an entry with no colonies is told apart from an
    % uncropped one by whether its image field is empty.
    %
    % Returns a struct array with fields:
    %   filename           - Source image filename (display label only)
    %   genotype           - Machine-safe genotype slug
    %   genotype_display   - Human-readable genotype label
    %   source_paper       - 'Lendvay' or 'Lundblad'
    %   passage            - Passage number 1-4, also the ordinal slot index
    %   hce                - 'N/A' (no hemocytometer estimate for this dataset)
    %   incubation_days    - 'N/A' (not recorded in the source publications)
    %   source_type        - 'Standard' (constant)
    %   replicate          - 'N/A' (not recorded for this dataset)
    %   enrichment         - 'N/A' (not recorded for this dataset)
    %   dataset_field_name - Nominal key in the project's AllMeasures, formed as
    %                        <genotype>_<source_paper> (e.g. 'est21_Lendvay')
    %   plate_type         - Struct with fields:
    %                          plate_size      - 'Standard' (90 mm)
    %                          plate_radius_cm - 4.5

    registry = repmat(makeEmptyEntry(), 1, 0);
    n = 0;

    % =====================================================================
    %  LENDVAY 1996
    % =====================================================================

    % --- est1Delta (Fig Senescence Mutants of 1) ---
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'est1',  'est1-Δ',  'Lendvay',  1);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'est1',  'est1-Δ',  'Lendvay',  2);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'est1',  'est1-Δ',  'Lendvay',  3);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'est1',  'est1-Δ',  'Lendvay',  4);

    % --- tlc1Delta (Fig Senescence Mutants of 1) ---
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'tlc1',  'tlc1-Δ',  'Lendvay',  1);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'tlc1',  'tlc1-Δ',  'Lendvay',  2);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'tlc1',  'tlc1-Δ',  'Lendvay',  3);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 1.png', 'tlc1',  'tlc1-Δ',  'Lendvay',  4);

    % --- est2-1 (Fig Senescence Mutants of 2) ---
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est21', 'est2-1',  'Lendvay',  1);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est21', 'est2-1',  'Lendvay',  2);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est21', 'est2-1',  'Lendvay',  3);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est21', 'est2-1',  'Lendvay',  4);

    % --- est3-1 (Fig Senescence Mutants of 2) ---
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est31', 'est3-1',  'Lendvay',  1);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est31', 'est3-1',  'Lendvay',  2);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est31', 'est3-1',  'Lendvay',  3);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 2.png', 'est31', 'est3-1',  'Lendvay',  4);

    % --- est4-1 (Fig Senescence Mutants of 3) ---
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 3.png', 'est41', 'est4-1',  'Lendvay',  1);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 3.png', 'est41', 'est4-1',  'Lendvay',  2);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 3.png', 'est41', 'est4-1',  'Lendvay',  3);
    n=n+1; registry(n) = mk('Fig Senescence Mutants of 3.png', 'est41', 'est4-1',  'Lendvay',  4);

    % =====================================================================
    %  LUNDBLAD 1989
    % =====================================================================

    % --- est1-1 (Fig A mutant WIth) ---
    n=n+1; registry(n) = mk('Fig A mutant WIth.png',           'est11', 'est1-1',  'Lundblad', 1);
    n=n+1; registry(n) = mk('Fig A mutant WIth.png',           'est11', 'est1-1',  'Lundblad', 2);
    n=n+1; registry(n) = mk('Fig A mutant WIth.png',           'est11', 'est1-1',  'Lundblad', 3);
    n=n+1; registry(n) = mk('Fig A mutant WIth.png',           'est11', 'est1-1',  'Lundblad', 4);

    % === SHARED FUNCTIONS ===

    function plateType = makePlateType(sizeLabel)
        % MODEL: Build the plate_type sub-struct from a size label (TERMINAL)
        % Single source of truth for the size-to-radius mapping.
        switch sizeLabel
            case 'Standard'
                radiusCm = 4.5;   % 90 mm diameter plate
            case 'Large'
                radiusCm = 7.0;   % 140 mm diameter plate
            otherwise
                error('getPlateRegistryHistorical:badPlateSize', ...
                      'Unknown plate size label: %s', sizeLabel);
        end
        plateType = struct( ...
            'plate_size',      sizeLabel, ...
            'plate_radius_cm', radiusCm);
    end

    % === NESTED HELPERS ===

    function entry = makeEmptyEntry()
        % MODEL: Create empty struct with all registry fields (TERMINAL)
        entry = struct( ...
            'filename',           '', ...
            'genotype',           '', ...
            'genotype_display',   '', ...
            'source_paper',       '', ...
            'passage',            0, ...
            'hce',                'N/A', ...
            'incubation_days',    'N/A', ...
            'source_type',        'Standard', ...
            'replicate',          'N/A', ...
            'enrichment',         'N/A', ...
            'dataset_field_name', '', ...
            'plate_type',         makePlateType('Standard'));
    end

    function entry = mk(fn, gt, gtDisp, paper, ps)
        % MODEL: Create one registry entry (TERMINAL)
        % dataset_field_name is formed as <gt>_<paper>, which reproduces the
        % project's nominal values exactly for all six genotypes.
        entry = struct( ...
            'filename',           fn, ...
            'genotype',           gt, ...
            'genotype_display',   gtDisp, ...
            'source_paper',       paper, ...
            'passage',            ps, ...
            'hce',                'N/A', ...
            'incubation_days',    'N/A', ...
            'source_type',        'Standard', ...
            'replicate',          'N/A', ...
            'enrichment',         'N/A', ...
            'dataset_field_name', sprintf('%s_%s', gt, paper), ...
            'plate_type',         makePlateType('Standard'));
    end
end
%% Phase 2: Library Fitting
function [OutputText, OutputFigures] = folderdesignation(OutputFiles)
    % MODEL: Return base output paths. Round-specific subfolders are
    % created downstream by MainController based on the rounds argument
    % (e.g., OutputFiles/V40/, OutputFiles/V80/). (TERMINAL)
   
    OutputText    = fullfile(OutputFiles, 'Text');
    OutputFigures = fullfile(OutputFiles, 'Figures');
end
function library = loadStablePhiLibrary(rounds, libraryPath)
    % MODEL: Load the stable-phi library for a specific rounds version
    % (e.g., 'V40', 'V80') from a .mat file in libraryPath (TERMINAL)

    filename = fullfile(libraryPath, ['stable_phi_library_' rounds '.mat']);

    if ~isfile(filename)
        error('loadStablePhiLibrary:FileNotFound', ...
            'Library file not found: %s', filename);
    end

    S = load(filename, 'library');

    if ~isfield(S, 'library')
        error('loadStablePhiLibrary:InvalidFile', ...
            'File %s does not contain a library variable', filename);
    end

    library = S.library;

    required_fields = {'x_grid', 'ceiling_radius', 'config', 'entries'};
    for i = 1:length(required_fields)
        if ~isfield(library, required_fields{i})
            error('loadStablePhiLibrary:MissingField', ...
                'Library is missing required field: %s', required_fields{i});
        end
    end

    fprintf('Loaded library from %s: %d entries, ceiling=%.1f um\n', ...
        filename, length(library.entries), library.ceiling_radius);
end
function composite = MainController(Scenario, rounds, OutputFiles, OutputText, OutputFigures, library, varargin)
    % CONTROLLER: Top-level orchestrator for scenario runs.
    %
    % Two entry shapes, dispatched at the top:
    %
    %   (1) Multi-part bundle. The trailing argument is the combined loader
    %       struct (a scalar struct carrying a rounds field, no per-entry
    %       Measurements field), e.g. struct('rounds', rounds, 'part2', ...,
    %       'part3', ...). MainController loops the part fields, calls itself
    %       once per part through the single-part path, and writes each fitted
    %       part back into a copy of the bundle. The reassembled bundle is
    %       returned. Each per-part call runs its own diary, save, and
    %       populate, so P2 and P3 land in separate files under their own
    %       project names.
    %
    %   (2) Single part. The trailing argument is a composite struct array
    %       whose entries each carry Measurements. This is the original
    %       behavior: resolve the output name, set up folders, run the model,
    %       save, and post-process.
    %
    % Inputs:
    %   Scenario       : scenario name string. Resolved as
    %                    ['build', Scenario, 'Scenario'] to a function
    %                    handle (e.g., 'Senescence' -> @buildSenescenceScenario,
    %                    'RealData' -> @buildRealDataScenario,
    %                    'CompositeData' -> @buildCompositeDataScenario)
    %   rounds         : library version tag (e.g., 'V40', 'V80'). Used to
    %                    select the library file, route outputs to a
    %                    round-specific subfolder, and suffix every output
    %                    filename.
    %   OutputFiles    : base path for .mat results. Actual writes go to
    %                    fullfile(OutputFiles, rounds).
    %   OutputText     : base path for diary log. Actual writes go to
    %                    fullfile(OutputText, rounds).
    %   OutputFigures  : base path for PDF output. Actual writes go to
    %                    fullfile(OutputFigures, rounds).
    %   library        : library object (load via loadStablePhiLibrary(rounds))
    %   varargin       : extra arguments forwarded to the scenario builder.
    %                    rounds is also forwarded as the first builder arg.
    %                    If any struct in varargin has a projectName field,
    %                    that name overrides the Scenario string for output
    %                    filenames and the runVisualization label.
    %
    % Post-processing is split on whether the scenario carries real data.
    % Real-data scenarios (CompositeData, RealData) write fits back into the
    % composite via populateCompositeFromResults. Simulated scenarios render
    % the fit through runVisualization. A simulated run returns [] for the
    % composite output.
    %
    % Examples:
    %   MainController('Senescence', 'V80', files, text, figs, library)
    %   MainController('CompositeData', 'V40', files, text, figs, library, combined)

    % === DISPATCH: multi-part bundle recurses through the single-part path ===
    if isMultiPartBundle(varargin)
        composite = runAllParts(Scenario, rounds, OutputFiles, OutputText, OutputFigures, library, varargin{1});
        return
    end

    % === SINGLE-PART PATH ===
    CurrentScenario = ['build', Scenario, 'Scenario'];
    outputName = resolveOutputName(Scenario, varargin);
    [filesDir, textDir, figuresDir] = ensureRoundsSubfolders(OutputFiles, OutputText, OutputFigures, rounds);
    clc
    diary(fullfile(textDir, [outputName '_' rounds '.txt']))
    results = runModel(str2func(CurrentScenario), library, rounds, varargin{:});
    save(fullfile(filesDir, [outputName '_results_' rounds '.mat']), 'results');
    diary off

    if isRealDataScenario(Scenario)
        composite = populateCompositeFromResults(results, filesDir, outputName, rounds);
    else
        composite = [];
        runVisualization(results, figuresDir, outputName, rounds)
    end

    % === SUB-CONTROLLERS ===

    function bundleOut = runAllParts(Scenario, rounds, OutputFiles, OutputText, OutputFigures, library, bundle)
        % SUB-CONTROLLER: Fit every part through MainController and reassemble
        % Iterates the bundle's part fields, runs each composite through the
        % single-part path via a recursive MainController call, and replaces
        % that field with its fitted return. Non-part bookkeeping fields (the
        % rounds tag) pass through untouched because bundleOut starts as a copy
        % of bundle.

        partFields = getPartFields(bundle);
        bundleOut = bundle;
        for i = 1:numel(partFields)
            field = partFields{i};
            projectName = partProjectName(field);
            fittedPart = MainController(Scenario, rounds, OutputFiles, OutputText, OutputFigures, library, ...
                            bundle.(field), struct('projectName', projectName));
            bundleOut.(field) = fittedPart;
        end

        function fields = getPartFields(bundle)
            % MODEL: All bundle fields except the rounds tag (TERMINAL)
            allFields = fieldnames(bundle);
            fields = allFields(~strcmp(allFields, 'rounds'));
            fields = fields(:)';
        end

        function name = partProjectName(field)
            % MODEL: Map a bundle field to its output project name (TERMINAL)
            % part2 -> P2, part3 -> P3, matching the part suffix Phase 1 uses
            % so each fit .mat lines up with its composite .mat. Any field not
            % starting with 'part' passes through unchanged.
            name = regexprep(field, '^part', 'P');
        end
    end

    % === MODELS ===

    function tf = isMultiPartBundle(varargin_in)
        % MODEL: Detect the combined loader bundle in the trailing args (TERMINAL)
        % A bundle is a scalar struct carrying a rounds field with no per-entry
        % Measurements field. A single-part composite is a struct array whose
        % entries each carry Measurements (and no rounds field), so the two
        % never collide regardless of how many entries the part holds.
        tf = false;
        if isempty(varargin_in)
            return
        end
        candidate = varargin_in{1};
        tf = isstruct(candidate) && isscalar(candidate) ...
            && isfield(candidate, 'rounds') && ~isfield(candidate, 'Measurements');
    end

    function outputName = resolveOutputName(Scenario, varargin_in)
        % MODEL: Pick projectName from any varargin struct that carries it,
        % else fall back to the Scenario string (TERMINAL)
        outputName = Scenario;
        for i = 1:length(varargin_in)
            arg = varargin_in{i};
            if isstruct(arg) && isscalar(arg) && isfield(arg, 'projectName') ...
                    && ~isempty(arg.projectName)
                outputName = arg.projectName;
                return
            end
        end
    end

    function [filesDir, textDir, figuresDir] = ensureRoundsSubfolders(OutputFiles, OutputText, OutputFigures, rounds)
        % MODEL: Build round-specific subfolder paths and create them if
        % missing (TERMINAL)
        filesDir = fullfile(OutputFiles, rounds);
        textDir = fullfile(OutputText, rounds);
        figuresDir = fullfile(OutputFigures, rounds);
        if ~isfolder(filesDir),   mkdir(filesDir);   end
        if ~isfolder(textDir),    mkdir(textDir);    end
        if ~isfolder(figuresDir), mkdir(figuresDir); end
    end

    function tf = isRealDataScenario(Scenario)
        % MODEL: Real-data scenarios use the composite populate path, simulated
        % scenarios use the visualization path (TERMINAL)
        tf = any(strcmp(Scenario, {'CompositeData', 'RealData'}));
    end
end
function results = runModel(scenarioBuilder, library, rounds, varargin)
    % CONTROLLER: Build scenario, apply standard analysis options, and
    % dispatch to the appropriate runner based on whether the scenario
    % is real data or simulation-based.
    %
    % Inputs:
    %   scenarioBuilder : function handle
    %                       (e.g., @buildSenescenceScenario,
    %                        @buildRealDataScenario,
    %                        @buildCompositeDataScenario)
    %   library         : library object
    %   rounds          : library version tag (e.g., 'V40', 'V80'),
    %                       forwarded as the first argument to the
    %                       scenario builder so builders that load
    %                       round-specific source data can use it.
    %   varargin        : optional arguments forwarded to scenarioBuilder
    %                       after rounds (e.g., n_colonies for sim
    %                       builders, AllMeasures for buildRealDataScenario).
    %
    % Examples:
    %   runModel(@buildSenescenceScenario, lib, 'V80', 1000)
    %   runModel(@buildRealDataScenario, lib, 'V40', AllMeasures)

    scenario = scenarioBuilder(rounds, varargin{:});
    scenario = applyStandardAnalysisOptions(scenario, library);

    if isfield(scenario, 'is_real_data') && scenario.is_real_data
        results = runRealData(scenario);
    else
        results = runScenario(scenario);
    end

    function scenario = applyStandardAnalysisOptions(scenario, library)
        % MODEL: Inject library and standard mixture distributions (TERMINAL)
        scenario.analysis_options.mixture_distribution = ["LogNormal", "Library"];
        scenario.analysis_options.library = library;
    end
end

%%   SCENARIO BUILDERS
function scenario = buildScenarioFromAllMeasures(AllMeasures, analysis_options)
        % SUB-CONTROLLER: Construct scenario shell from real measurement data

        nominalInfo = computeNominalInfo(AllMeasures);
        n_ord = computeOrdinalCount(AllMeasures, nominalInfo.fields);
        ordinalLabels = buildOrdinalLabels(n_ord);
        config = buildStubConfigGrid(n_ord, nominalInfo.fields);
        scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, analysis_options);

        function info = computeNominalInfo(AllMeasures)
            % MODEL: Extract field names and display labels (TERMINAL)
            displayMap = struct( ...
                'Wild_Type',     'Wild Type', ...
                'dbf41',         'dbf4-1', ...
                'dbf41_cdc132',  'dbf4-1, cdc13-2', ...
                'cdc132',        'cdc13-2');
            allFields = fieldnames(AllMeasures);
            n = length(allFields);
            displayLabels = cell(1, n);
            for i = 1:n
                fname = allFields{i};
                if isfield(displayMap, fname)
                    displayLabels{i} = displayMap.(fname);
                else
                    displayLabels{i} = strrep(fname, '_', ' ');
                end
            end
            info = struct();
            info.fields = allFields(:)';
            info.labels = displayLabels;
        end

        function n_ord = computeOrdinalCount(AllMeasures, fields)
            % MODEL: Find max generation count across genotypes (TERMINAL)
            n_ord = 0;
            for i = 1:length(fields)
                n_ord = max(n_ord, length(AllMeasures.(fields{i})));
            end
        end

        function labels = buildOrdinalLabels(n_ord)
            % MODEL: Build ordinal label cell array (TERMINAL)
            labels = cell(1, n_ord);
            for i = 1:n_ord
                labels{i} = sprintf('Plating %d', i);
            end
        end

        function config = buildStubConfigGrid(n_ord, nominal_fields)
            % MODEL: Build per-cell stub configs for real data (TERMINAL)
            stubCell = struct();
            stubCell.pools = struct( ...
                'initial_S', {}, ...
                'p_traj', {}, ...
                'eps_traj', {}, ...
                'phase_boundaries', {}, ...
                'color', {}, ...
                'label', {});
            stubCell.branch_events = struct( ...
                'source_pool', {}, ...
                'target_pool', {}, ...
                'eligible_rounds', {});
            stubCell.universal = struct('v', 40);
            stubCell.log_params = struct();

            config = repmat(struct(), 1, n_ord);
            for ord = 1:n_ord
                for nom = 1:length(nominal_fields)
                    config(ord).(nominal_fields{nom}) = stubCell;
                end
            end
        end

        function scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, analysis_options)
            % MODEL: Pack the scenario struct (TERMINAL)
            scenario = struct();
            scenario.scenario_name = 'RealData';
            scenario.nominal_fields = nominalInfo.fields;
            scenario.nominal_labels = nominalInfo.labels;
            scenario.ordinal_labels = ordinalLabels;
            scenario.config = config;
            scenario.analysis_options = analysis_options;
        end
    end
function scenario = buildRealDataScenario(AllMeasures, experimentConfig)
    % CONTROLLER: Construct scenario shell from real measurement data
    %
    % Returns a scenario object compatible with the analysis and
    % visualization pipelines. The scenario carries the AllMeasures
    % source struct in scenario.real_data_source so that runRealData can
    % pull radii on demand. The is_real_data flag tells runModel which
    % runner to dispatch to.
    %
    % experimentConfig is the schema source: nominal field names and
    % display labels come from experimentConfig.variables.nominal,
    % ordinal labels from experimentConfig.variables.ordinal.
    %
    % experimentConfig.projectName is used as scenario_name. The full
    % experimentConfig is stored on the scenario for downstream use.

    validateExperimentConfig(experimentConfig);
    nominalInfo = computeNominalInfo(experimentConfig);
    n_ord = computeOrdinalCount(experimentConfig);
    ordinalLabels = buildOrdinalLabels(experimentConfig);
    config = buildStubConfigGrid(n_ord, nominalInfo.fields);
    analysis_options = buildDefaultAnalysisOptions();
    scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, ...
        analysis_options, AllMeasures, experimentConfig);

    function validateExperimentConfig(experimentConfig)
        % MODEL: Hard-error on missing or empty projectName (TERMINAL)
        if ~isstruct(experimentConfig) || ~isfield(experimentConfig, 'projectName')
            error('buildRealDataScenario:MissingProjectName', ...
                'experimentConfig must be a struct with a projectName field.');
        end
        if isempty(experimentConfig.projectName)
            error('buildRealDataScenario:EmptyProjectName', ...
                'experimentConfig.projectName must be non-empty.');
        end
    end

    function info = computeNominalInfo(experimentConfig)
        % MODEL: Pull nominal field names and display labels from config (TERMINAL)
        info = struct();
        info.fields = experimentConfig.variables.nominal.values;
        info.labels = experimentConfig.variables.nominal.display_values;
    end

    function n_ord = computeOrdinalCount(experimentConfig)
        % MODEL: Get ordinal count from config (TERMINAL)
        n_ord = length(experimentConfig.variables.ordinal.values);
    end

    function labels = buildOrdinalLabels(experimentConfig)
        % MODEL: Pull ordinal display labels from config (TERMINAL)
        labels = experimentConfig.variables.ordinal.display_values;
    end

    function config = buildStubConfigGrid(n_ord, nominal_fields)
        % MODEL: Build per-cell stub configs for real data (TERMINAL)
        stubCell = struct();
        stubCell.pools = struct( ...
            'initial_S', {}, ...
            'p_traj', {}, ...
            'eps_traj', {}, ...
            'phase_boundaries', {}, ...
            'color', {}, ...
            'label', {});
        stubCell.branch_events = struct( ...
            'source_pool', {}, ...
            'target_pool', {}, ...
            'eligible_rounds', {});
        stubCell.universal = struct('v', 40);
        stubCell.log_params = struct();

        config = repmat(struct(), 1, n_ord);
        for ord = 1:n_ord
            for nom = 1:length(nominal_fields)
                config(ord).(nominal_fields{nom}) = stubCell;
            end
        end
    end

    function options = buildDefaultAnalysisOptions()
        % MODEL: Default analysis options for real data (TERMINAL)
        options = struct();
        options.max_components = 4;
        options.connection_threshold = 0.5;
        options.connection_cost_bias = 0.5;
        options.normalization = 'log';
        options.rng_seed = [];
    end

    function scenario = packRealDataScenario(nominalInfo, ordinalLabels, config, analysis_options, AllMeasures, experimentConfig)
        % MODEL: Pack the real-data scenario struct (TERMINAL)
        scenario = struct();
        scenario.scenario_name = experimentConfig.projectName;
        scenario.experiment_config = experimentConfig;
        scenario.nominal_fields = nominalInfo.fields;
        scenario.nominal_labels = nominalInfo.labels;
        scenario.ordinal_labels = ordinalLabels;
        scenario.config = config;
        scenario.analysis_options = analysis_options;
        scenario.is_real_data = true;
        scenario.real_data_source = AllMeasures;
    end
end
function scenario = buildCompositeDataScenario(rounds, composite, runConfig)
    % CONTROLLER: Construct scenario shell from composite struct
    %
    % Produces a scenario compatible with runRealData. Shape is flat:
    % a single ordinal slot, one nominal slot per composite entry. Each
    % nominal field on real_data_source is the composite entry's
    % Measurements struct, indexed at ord_idx = 1.
    %
    % Nominal field names are index-derived (entry_001, entry_002, ...)
    % so the mapping back to composite is just the index. Display labels
    % carry the original filenames.
    %
    % The original composite is stored on scenario.composite_source for
    % later merge steps that write fit outputs back per entry. The rounds
    % tag is stamped on scenario.rounds so downstream code can verify
    % library/composite/scenario all agree.
    %
    % runConfig is optional. When supplied it must be a scalar struct
    % carrying a non-empty projectName, recording which part this run
    % targets (e.g. 'P2', 'P3'). It is stored on scenario.run_config and
    % does not affect scenario_name, which stays fixed at 'CompositeData'
    % because that label is read as a key throughout the downstream
    % pipeline. Output filenames are set upstream from the same projectName,
    % so run_config here is carried only so later merge steps can read which
    % part they are writing back without re-parsing filenames. When runConfig
    % is omitted, projectName defaults to 'CompositeData' so the field is
    % never empty.

    validateRounds(rounds);
    validateComposite(composite);
    if nargin < 3
        runConfig = [];
    end
    runConfig = resolveRunConfig(runConfig);
    nominalInfo = computeNominalInfoFromComposite(composite);
    n_ord = 1;
    ordinalLabels = {'data'};
    config = buildStubConfigGrid(n_ord, nominalInfo.fields, rounds);
    analysis_options = buildDefaultAnalysisOptions();
    AllMeasures = packCompositeAsAllMeasures(composite, nominalInfo.fields);
    scenario = packCompositeScenario(rounds, nominalInfo, ordinalLabels, config, ...
        analysis_options, AllMeasures, composite, runConfig);

    function validateRounds(rounds)
        % MODEL: Hard-error on malformed rounds tag. Required format is
        % 'V' followed by one or more digits (e.g., 'V40', 'V80'), so the
        % numeric round count can be parsed by str2double(rounds(2:end)). (TERMINAL)
        if ~(ischar(rounds) || (isstring(rounds) && isscalar(rounds))) || isempty(rounds)
            error('buildCompositeDataScenario:InvalidRounds', ...
                'rounds must be a non-empty character vector or string scalar (e.g., ''V40'', ''V80'').');
        end
        if isempty(regexp(char(rounds), '^V\d+$', 'once'))
            error('buildCompositeDataScenario:InvalidRoundsFormat', ...
                'rounds must match the pattern V<integer> (e.g., ''V40'', ''V80''). Got: %s', char(rounds));
        end
    end

    function validateComposite(composite)
        % MODEL: Hard-error on malformed composite input (TERMINAL)
        if ~isstruct(composite) || isempty(composite)
            error('buildCompositeDataScenario:EmptyComposite', ...
                'composite must be a non-empty struct array.');
        end
        if ~isfield(composite, 'Measurements')
            error('buildCompositeDataScenario:MissingMeasurements', ...
                'composite must have a Measurements field.');
        end
        if ~isfield(composite, 'filename')
            error('buildCompositeDataScenario:MissingFilename', ...
                'composite must have a filename field.');
        end
    end

    function runConfigOut = resolveRunConfig(runConfigIn)
        % MODEL: Normalize the optional run config to a scalar struct with a
        % non-empty projectName (TERMINAL)
        % Absent input ([]) defaults projectName to 'CompositeData', matching
        % scenario_name so the field is never empty and downstream code can
        % read run_config.projectName unconditionally. A supplied value must
        % be a scalar struct carrying a non-empty projectName. This does not
        % set scenario_name; it only records which part the run targets.
        defaultName = 'CompositeData';
        if isempty(runConfigIn)
            runConfigOut = struct('projectName', defaultName);
            return
        end
        if ~isstruct(runConfigIn) || ~isscalar(runConfigIn)
            error('buildCompositeDataScenario:InvalidRunConfig', ...
                'runConfig must be a scalar struct with a projectName field.');
        end
        if ~isfield(runConfigIn, 'projectName') || isempty(runConfigIn.projectName)
            error('buildCompositeDataScenario:EmptyProjectName', ...
                'runConfig.projectName must be present and non-empty.');
        end
        runConfigOut = runConfigIn;
    end

    function info = computeNominalInfoFromComposite(composite)
        % MODEL: Build nominal field names and display labels (TERMINAL)
        n = length(composite);
        info = struct();
        info.fields = arrayfun(@(i) sprintf('entry_%03d', i), 1:n, ...
            'UniformOutput', false);
        info.labels = {composite.filename};
    end

    function config = buildStubConfigGrid(n_ord, nominal_fields, rounds)
        % MODEL: Build per-cell stub configs for real data. The universal.v
        % round count is derived from the rounds tag (e.g., 'V40' -> 40).
        % Rounds format is enforced by validateRounds upstream. (TERMINAL)
        v_count = str2double(char(rounds(2:end)));
        stubCell = struct();
        stubCell.pools = struct( ...
            'initial_S', {}, ...
            'p_traj', {}, ...
            'eps_traj', {}, ...
            'phase_boundaries', {}, ...
            'color', {}, ...
            'label', {});
        stubCell.branch_events = struct( ...
            'source_pool', {}, ...
            'target_pool', {}, ...
            'eligible_rounds', {});
        stubCell.universal = struct('v', v_count);
        stubCell.log_params = struct();

        config = repmat(struct(), 1, n_ord);
        for ord = 1:n_ord
            for nom = 1:length(nominal_fields)
                config(ord).(nominal_fields{nom}) = stubCell;
            end
        end
    end

    function options = buildDefaultAnalysisOptions()
        % MODEL: Default analysis options for real data (TERMINAL)
        options = struct();
        options.max_components = 4;
        options.connection_threshold = 0.5;
        options.connection_cost_bias = 0.5;
        options.normalization = 'log';
        options.rng_seed = [];
    end

    function AllMeasures = packCompositeAsAllMeasures(composite, nominal_fields)
        % MODEL: Reshape composite into AllMeasures-style struct (TERMINAL)
        AllMeasures = struct();
        for i = 1:length(composite)
            field = nominal_fields{i};
            entry = struct('Measurements', composite(i).Measurements);
            AllMeasures.(field) = entry;
        end
    end

    function scenario = packCompositeScenario(rounds, nominalInfo, ordinalLabels, config, analysis_options, AllMeasures, composite, run_config)
        % MODEL: Pack the composite-data scenario struct (TERMINAL)
        scenario = struct();
        scenario.scenario_name = 'CompositeData';
        scenario.rounds = rounds;
        scenario.run_config = run_config;
        scenario.composite_source = composite;
        scenario.nominal_fields = nominalInfo.fields;
        scenario.nominal_labels = nominalInfo.labels;
        scenario.ordinal_labels = ordinalLabels;
        scenario.config = config;
        scenario.analysis_options = analysis_options;
        scenario.is_real_data = true;
        scenario.real_data_source = AllMeasures;
    end
end

%%   SHARED CONFIGURATION HELPERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function universal = makeUniversalConfig(n_colonies, v, detection_limit)
    % MODEL: Build the universal config block (TERMINAL)
    universal = struct();
    universal.n_colonies = n_colonies;
    universal.v = v;
    universal.detection_limit = detection_limit;
    universal.packing_density = 0.0113;
    universal.approx_threshold = 500;
    universal.min_kappa = 2;
end

function options = defaultAnalysisOptions()
    % MODEL: Build default analysis options (TERMINAL)
    options = struct();
    options.max_components = 5;
    options.mixture_distribution = "LogNormal";
    options.normalization = 'Raw';
    options.connection_threshold = 0.5;
    options.connection_cost_bias = 0.5;
    options.rng_seed = [];
end

function scenario = assembleScenarioShell(labels, options, scenario_name)
    % MODEL: Assemble empty scenario shell (TERMINAL)
    scenario = struct();
    scenario.scenario_name = scenario_name;
    scenario.ordinal_labels = labels.ordinal_display;
    scenario.nominal_labels = labels.nominal_display;
    scenario.nominal_fields = labels.nominal_fields;
    scenario.analysis_options = options;
    n_ord = length(labels.ordinal_display);
    scenario.config = repmat(struct(), 1, n_ord);
end

function scenario = addCellConfig(scenario, ord_idx, nom_idx, cellConfig)
    % MODEL: Place a cellConfig into the scenario grid (TERMINAL)
    nom_field = scenario.nominal_fields{nom_idx};
    scenario.config(ord_idx).(nom_field) = cellConfig;
end

function pool = buildPool(p_traj, eps_traj, label, color, phase_boundaries, initial_S)
    % MODEL: Construct a pool struct (TERMINAL)
    pool = struct();
    pool.p_traj = p_traj;
    pool.eps_traj = eps_traj;
    pool.label = label;
    pool.color = color;
    pool.phase_boundaries = phase_boundaries;
    pool.initial_S = initial_S;
end

function event = buildBranchEvent(source_pool, source_compartment, target_pool, mode, probability, eligible_rounds)
    % MODEL: Construct a branch event struct (TERMINAL)
    event = struct();
    event.source_pool = source_pool;
    event.source_compartment = source_compartment;
    event.target_pool = target_pool;
    event.mode = mode;
    event.probability = probability;
    event.eligible_rounds = eligible_rounds;
end


%%   SECTION 2: UNIFIED ENGINE
%   Everything between scenario configuration and visualization-ready
%   results. The engine knows about pools and branch events as
%   generic primitives. It has no scenario-specific logic.
%
%   Layers:
%       (1) GRID RUNNER         - public entry point
%       (2) UNIFIED SIMULATOR   - pool/branch_event colony generator
%       (3) ENGINE PRIMITIVES   - pure math
%       (4) SHARED UTILITIES    - extractLibraryAdequacy
%
%   ENTRY POINT:
%       results = runScenario(scenario)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function results = runScenario(scenario)
    % CONTROLLER: Walk the scenario grid, simulate and analyze every cell,
    % return the unified results object.

    seedRNGIfRequested(scenario);
    results = initializeResultsObject(scenario);
    dataProvider = @(cellConfig, ord_idx, nom_idx) simulateColonySet(cellConfig);
    results = walkScenarioGrid(scenario, results, dataProvider);
    results = finalizeResultsMetadata(results);
end
function seedRNGIfRequested(scenario)
        % SUB-CONTROLLER: Apply RNG seed if specified
        seed = scenario.analysis_options.rng_seed;
        applySeed(seed);

        function applySeed(seed)
            % MODEL: Seed the RNG if non-empty (TERMINAL)
            if ~isempty(seed)
                rng(seed);
            end
        end
    end
function results = initializeResultsObject(scenario)
        % SUB-CONTROLLER: Build empty results shell

        analysisResults = buildAnalysisResultsShell(scenario);
        simTracking = buildSimTrackingShell(scenario);
        runMetadata = buildRunMetadataShell(scenario);
        results = packResultsShell(scenario, analysisResults, simTracking, runMetadata);

        function analysisResults = buildAnalysisResultsShell(scenario)
            % MODEL: Build empty QC-compatible analysisResults (TERMINAL)
            options = scenario.analysis_options;

            metadata = struct();
            metadata.analysis_timestamp = string(datetime('now'));
            metadata.Max_Components = options.max_components;
            metadata.Connection_Threshold = options.connection_threshold;
            metadata.size_weight = options.connection_cost_bias;
            metadata.normalization_method = options.normalization;
            metadata.mixture_distribution = options.mixture_distribution;
            metadata.simulation_metadata = struct();
            metadata.simulation_metadata.scenario_name = scenario.scenario_name;
            metadata.simulation_metadata.rng_seed = options.rng_seed;

            n_ord = length(scenario.ordinal_labels);
            n_nom = length(scenario.nominal_labels);

            SubpopulationAnalysis = repmat(struct(), 1, n_ord);
            for ord = 1:n_ord
                for nom = 1:n_nom
                    nom_field = scenario.nominal_fields{nom};
                    SubpopulationAnalysis(ord).(nom_field) = struct();
                    SubpopulationAnalysis(ord).(nom_field).ColonySet = struct();
                    SubpopulationAnalysis(ord).(nom_field).Connections = [];
                end
            end

            analysisResults = struct();
            analysisResults.metadata = metadata;
            analysisResults.SubpopulationAnalysis = SubpopulationAnalysis;
        end

        function simTracking = buildSimTrackingShell(scenario)
            % MODEL: Build empty simTracking struct (TERMINAL)
            n_ord = length(scenario.ordinal_labels);
            n_nom = length(scenario.nominal_labels);
            simTracking = repmat(struct(), 1, n_ord);
            for ord = 1:n_ord
                for nom = 1:n_nom
                    nom_field = scenario.nominal_fields{nom};
                    simTracking(ord).(nom_field) = struct();
                end
            end
        end

        function runMetadata = buildRunMetadataShell(scenario)
            % MODEL: Build runner metadata shell (TERMINAL)
            runMetadata = struct();
            runMetadata.scenario_name = scenario.scenario_name;
            runMetadata.start_time = datetime('now');
            runMetadata.end_time = NaT;
            runMetadata.elapsed_seconds = NaN;
            runMetadata.n_cells = length(scenario.ordinal_labels) * ...
                length(scenario.nominal_labels);
            runMetadata.n_colonies_total = 0;
            runMetadata.rng_seed = scenario.analysis_options.rng_seed;
        end

        function results = packResultsShell(scenario, analysisResults, simTracking, runMetadata)
            % MODEL: Pack the top-level results object (TERMINAL)
            results = struct();
            results.scenario = scenario;
            results.analysisResults = analysisResults;
            results.simTracking = simTracking;
            results.metadata = runMetadata;
        end
    end
    function results = processSingleGridCell(results, scenario, ord_idx, nom_idx, dataProvider)
    % SUB-CONTROLLER: Obtain simData from dataProvider and analyze one grid cell

    cellConfig = pullCellConfig(scenario, ord_idx, nom_idx);
    simData = dataProvider(cellConfig, ord_idx, nom_idx);
    colonySet = analyzeColonySet(simData.radii, scenario.analysis_options);
    results = stowGridCellResults(results, scenario, colonySet, simData, ord_idx, nom_idx);
    printGridCellStatus(ord_idx, scenario.nominal_fields{nom_idx}, ...
        simData, colonySet, cellConfig);
               function cellConfig = pullCellConfig(scenario, ord_idx, nom_idx)
                % MODEL: Look up the cellConfig (TERMINAL)
                nom_field = scenario.nominal_fields{nom_idx};
                cellConfig = scenario.config(ord_idx).(nom_field);
            end

            function results = stowGridCellResults(results, scenario, colonySet, simData, ord_idx, nom_idx)
                % MODEL: Attach grid coords, store everything in results (TERMINAL)
                nom_field = scenario.nominal_fields{nom_idx};
                colonySet.nominal_index = nom_field;
                colonySet.ordinal_index = ord_idx;
                colonySet.nominal_display = scenario.nominal_labels{nom_idx};
                colonySet.ordinal_display = scenario.ordinal_labels{ord_idx};
                colonySet.tracking = simData.tracking;
                results.analysisResults.SubpopulationAnalysis(ord_idx).(nom_field).ColonySet = colonySet;
                results.simTracking(ord_idx).(nom_field) = simData.tracking;
                results.metadata.n_colonies_total = ...
                    results.metadata.n_colonies_total + length(simData.radii);
            end

            function printGridCellStatus(ord_idx, nom_field, simData, colonySet, cellConfig)
    % SUB-CONTROLLER: Print per-cell status with log_params and optional ground truth

    n_det = length(simData.radii);
    k = extractOptimalK(colonySet);
    nModes = extractModeCount(colonySet);
    methodInfo = extractMethodInfo(colonySet);
    libraryAdequacy = extractLibraryAdequacy(colonySet);
    componentDetails = extractComponentDetails(colonySet, k);

    printCellHeader(ord_idx, nom_field, n_det, k, nModes, ...
        methodInfo, libraryAdequacy, cellConfig.log_params);
    printComponentLines(componentDetails);

    if isfield(cellConfig, 'ground_truth') && ~isempty(cellConfig.ground_truth)
        printGroundTruthComparison(cellConfig.ground_truth, colonySet);
    end

    function k = extractOptimalK(colonySet)
        % MODEL: Pull optimal_components (TERMINAL)
        if isfield(colonySet, 'gmm_results') && ...
                isfield(colonySet.gmm_results, 'optimal_components')
            k = colonySet.gmm_results.optimal_components;
        else
            k = 0;
        end
    end

    function nModes = extractModeCount(colonySet)
        % MODEL: Pull mode count from mode_detection (TERMINAL)
        if isfield(colonySet, 'mode_detection') && ...
                isfield(colonySet.mode_detection, 'n_modes')
            nModes = colonySet.mode_detection.n_modes;
        else
            nModes = NaN;
        end
    end

    function info = extractMethodInfo(colonySet)
        % MODEL: Pull method selection and AIC info (TERMINAL)
        info = struct();
        info.selected = 'Unknown';
        info.selected_aic = NaN;
        info.alternatives = struct();

        if isfield(colonySet, 'selected_method')
            if ischar(colonySet.selected_method)
                info.selected = colonySet.selected_method;
            else
                info.selected = char(colonySet.selected_method);
            end
        end

        if isfield(colonySet, 'gmm_results') && ...
                isfield(colonySet.gmm_results, 'fitted_model') && ...
                isfield(colonySet.gmm_results.fitted_model, 'final_aic')
            info.selected_aic = colonySet.gmm_results.fitted_model.final_aic;
        end

        if isfield(colonySet, 'alternative_fits')
            altNames = fieldnames(colonySet.alternative_fits);
            for i = 1:length(altNames)
                alt = colonySet.alternative_fits.(altNames{i});
                if isfield(alt, 'aic')
                    info.alternatives.(altNames{i}) = alt.aic;
                end
            end
        end
    end

    function details = extractComponentDetails(colonySet, k)
        % MODEL: Pull per-component distribution info (TERMINAL)
        details = repmat(struct('weight', NaN, 'dist_type', 'N/A', ...
            'param_str', ''), 1, max(k, 1));
        if k == 0, return; end

        hasComponents = isfield(colonySet, 'gmm_results') && ...
            isfield(colonySet.gmm_results, 'components');
        hasSubpops = isfield(colonySet, 'subpopulations') && ...
            length(colonySet.subpopulations) >= k;

        for c = 1:k
            if hasComponents && length(colonySet.gmm_results.components) >= c
                details(c).weight = colonySet.gmm_results.components(c).weight;
            end
            if hasSubpops
                sp = colonySet.subpopulations(c);
                if isfield(sp, 'best_distribution') && ~isempty(sp.best_distribution)
                    details(c).dist_type = char(sp.best_distribution);
                end
                details(c).param_str = buildParamString(sp, details(c).dist_type);
            end
        end

        function s = buildParamString(sp, dist_type)
            % MODEL: Format parameter string (TERMINAL)
            s = '';
            if ~isfield(sp, 'distribution_tests'), return; end
            dt = sp.distribution_tests;
            switch dist_type
                case 'Normal'
                    if isfield(dt, 'normal') && isfield(dt.normal, 'final_mean')
                        s = sprintf('mu=%.1f sig=%.1f', ...
                            dt.normal.final_mean, dt.normal.final_sigma);
                    end
                case 'LogNormal'
                    if isfield(dt, 'lognormal') && isfield(dt.lognormal, 'fitted_median')
                        s = sprintf('med=%.1f sig=%.2f', ...
                            dt.lognormal.fitted_median, dt.lognormal.sigma_parameter);
                    end
                case 'Library'
                    if isfield(dt, 'library') && isfield(dt.library, 'phi_parameter')
                        s = sprintf('phi=%.2f eps=%.2f', ...
                            dt.library.phi_parameter, dt.library.eps_parameter);
                    end
                case 'Non-parametric'
                    if isfield(dt, 'nonparametric') && isfield(dt.nonparametric, 'peak_estimate')
                        s = sprintf('peak=%.1f', dt.nonparametric.peak_estimate);
                    end
                case 'Insufficient_Data'
                    if isfield(dt, 'insufficient_data')
                        s = sprintf('n=%d', dt.insufficient_data.sample_size);
                    end
            end
        end
    end

    function printCellHeader(ord_idx, nom_field, n_det, k, nModes, methodInfo, lib, log_params)
        % MODEL: Print main status line with log_params (TERMINAL)

        paramStr = formatLogParams(log_params);

        altStr = '';
        altNames = fieldnames(methodInfo.alternatives);
        for i = 1:length(altNames)
            altAic = methodInfo.alternatives.(altNames{i});
            altStr = sprintf('%s %s:%.0f', altStr, altNames{i}, altAic);
        end

        if isnan(nModes)
            modeStr = 'modes=?';
        else
            modeStr = sprintf('modes=%d', nModes);
        end

        if isempty(altStr)
            mainLine = sprintf('  [ord=%d %s] n=%d k=%d %s  method=%s AIC=%.0f  {%s}', ...
                ord_idx, nom_field, n_det, k, modeStr, ...
                methodInfo.selected, methodInfo.selected_aic, paramStr);
        else
            mainLine = sprintf('  [ord=%d %s] n=%d k=%d %s  method=%s AIC=%.0f (vs%s)  {%s}', ...
                ord_idx, nom_field, n_det, k, modeStr, ...
                methodInfo.selected, methodInfo.selected_aic, altStr, paramStr);
        end

        if lib.present && ~isnan(lib.emd) && ~isnan(lib.cutoff)
            if lib.passed, verdict = 'PASS'; else, verdict = 'FAIL'; end
            qualityStr = '';
            if ~isnan(lib.quality_shape) && ~isnan(lib.quality_scale)
                qualityStr = sprintf(' Qshape=%.2f Qscale=%.2f', ...
                    lib.quality_shape, lib.quality_scale);
            elseif ~isnan(lib.quality_shape)
                qualityStr = sprintf(' Qshape=%.2f', lib.quality_shape);
            elseif ~isnan(lib.quality_scale)
                qualityStr = sprintf(' Qscale=%.2f', lib.quality_scale);
            end
            libLine = sprintf('  Library: phi=%.2f eps=%.2f EMD=%.1fum vs cutoff %.1fum %s%s', ...
                lib.phi, lib.eps, lib.emd, lib.cutoff, verdict, qualityStr);
            fprintf('%s\n%s\n', mainLine, libLine);
        else
            fprintf('%s\n', mainLine);
        end

        function paramStr = formatLogParams(log_params)
            % MODEL: Format log_params as compact key=value string (TERMINAL)
            paramStr = '';
            fields = fieldnames(log_params);
            for i = 1:length(fields)
                val = log_params.(fields{i});
                if i > 1, paramStr = [paramStr ', ']; end %#ok<AGROW>
                if islogical(val)
                    paramStr = sprintf('%s%s=%d', paramStr, fields{i}, val);
                elseif isnumeric(val) && isscalar(val)
                    if val == round(val) && abs(val) < 1e6
                        paramStr = sprintf('%s%s=%d', paramStr, fields{i}, val);
                    else
                        paramStr = sprintf('%s%s=%.4g', paramStr, fields{i}, val);
                    end
                elseif ischar(val) || isstring(val)
                    paramStr = sprintf('%s%s=%s', paramStr, fields{i}, char(val));
                end
            end
        end
    end

    function printComponentLines(details)
        % MODEL: Print one line per component (TERMINAL)
        for c = 1:length(details)
            if isnan(details(c).weight), continue; end
            fprintf('    Comp%d: w=%.2f %s %s\n', ...
                c, details(c).weight, details(c).dist_type, details(c).param_str);
        end
    end

    function printGroundTruthComparison(ground_truth, colonySet)
        % MODEL: Print generic ground truth vs library prediction (TERMINAL)
        if ~isfield(ground_truth, 'phi') || ~isfield(ground_truth, 'epsilon')
            return;
        end
        hasBlobs = isfield(colonySet, 'gmm_results') && ...
            isfield(colonySet.gmm_results, 'fitted_model') && ...
            isfield(colonySet.gmm_results.fitted_model, 'library_blobs') && ...
            ~isempty(colonySet.gmm_results.fitted_model.library_blobs) && ...
            isfield(colonySet.gmm_results.fitted_model.library_blobs, 'centroids_phi') && ...
            ~isempty(colonySet.gmm_results.fitted_model.library_blobs.centroids_phi);
        if ~hasBlobs, return; end

        truth_phi = ground_truth.phi;
        truth_eps = ground_truth.epsilon;
        pred_phi = colonySet.gmm_results.fitted_model.library_blobs.centroids_phi(1);
        pred_eps = colonySet.gmm_results.fitted_model.library_blobs.centroids_eps(1);
        fprintf('    truth=(%.2f,%.2f) pred=(%.2f,%.2f) dphi=%+.3f deps=%+.3f\n', ...
            truth_phi, truth_eps, pred_phi, pred_eps, ...
            pred_phi - truth_phi, pred_eps - truth_eps);
    end
end
       
end
    function results = walkScenarioGrid(scenario, results, dataProvider)
    % SUB-CONTROLLER: Iterate over every cell in the grid, calling
    % dataProvider(cellConfig, ord_idx, nom_idx) to obtain simData.

    n_ord = length(scenario.ordinal_labels);
    n_nom = length(scenario.nominal_labels);
    printGridStartBanner(scenario, n_ord, n_nom);

    for ord_idx = 1:n_ord
        for nom_idx = 1:n_nom
            results = processSingleGridCell(results, scenario, ord_idx, nom_idx, dataProvider);
        end
    end

     function printGridStartBanner(scenario, n_ord, n_nom)
            % MODEL: Print run start banner (TERMINAL)
            fprintf('\n=================================================================\n');
            fprintf('  RUNNING SCENARIO: %s\n', scenario.scenario_name);
            fprintf('  Grid: %d ordinals x %d nominals = %d cells\n', ...
                n_ord, n_nom, n_ord * n_nom);
            fprintf('=================================================================\n');
        end

end
    function results = finalizeResultsMetadata(results)
        % SUB-CONTROLLER: Stamp end time, print summary
        results = applyEndTime(results);
        printRunSummary(results);

        function results = applyEndTime(results)
            % MODEL: Compute elapsed time (TERMINAL)
            results.metadata.end_time = datetime('now');
            results.metadata.elapsed_seconds = ...
                seconds(results.metadata.end_time - results.metadata.start_time);
        end

        function printRunSummary(results)
            % MODEL: Print run summary (TERMINAL)
            fprintf('-----------------------------------------------------------------\n');
            fprintf('  Done. %d cells, %d total colonies, %.1f seconds\n', ...
                results.metadata.n_cells, ...
                results.metadata.n_colonies_total, ...
                results.metadata.elapsed_seconds);
            fprintf('=================================================================\n\n');
        end
    end
    function results = runRealData(scenario)
    % CONTROLLER: Run the analysis pipeline on real experimental data.
    %
    % Mirrors runScenario's structure: takes a scenario, runs the same
    % grid-walking pipeline. The only difference is that the data
    % provider reads from scenario.real_data_source (an AllMeasures
    % struct) instead of calling simulateColonySet.
    %
    % After analysis, populates each cell's trajectory plot with a flat
    % p_traj at the library-fitted phi and eps_traj at the library-fitted
    % epsilon. This visualizes the library's interpretation of the data
    % alongside the real distribution.
    %
    % Reuses base-level functions from the simulation runner:
    % seedRNGIfRequested, initializeResultsObject, walkScenarioGrid,
    % processSingleGridCell, pullCellConfig, analyzeColonySet,
    % stowGridCellResults, printGridCellStatus, finalizeResultsMetadata.

    AllMeasures = scenario.real_data_source;
    seedRNGIfRequested(scenario);
    results = initializeResultsObject(scenario);
    dataProvider = @(cellConfig, ord_idx, nom_idx) ...
        lookupRadiiFromAllMeasures(AllMeasures, scenario, ord_idx, nom_idx);
    results = walkScenarioGrid(scenario, results, dataProvider);
    results = populateLibraryTrajectories(results);
    results = finalizeResultsMetadata(results);

    function simData = lookupRadiiFromAllMeasures(AllMeasures, scenario, ord_idx, nom_idx)
        % MODEL: Pull radii from AllMeasures, wrap in simData shape (TERMINAL)
        nom_field = scenario.nominal_fields{nom_idx};
        nom_data = AllMeasures.(nom_field);
        radii = [];
        if ord_idx <= length(nom_data)
            entry = nom_data(ord_idx);
            if isfield(entry, 'Measurements') && ...
                    isstruct(entry.Measurements) && ...
                    isfield(entry.Measurements, 'Radius')
                radii = entry.Measurements.Radius;
            end
        end
        simData = struct();
        simData.radii = radii(:);
        simData.tracking = struct();
    end

    function results = populateLibraryTrajectories(results)
        % SUB-CONTROLLER: Walk the grid and write a flat phi/eps pool
        % into each cell's scenario.config when a library fit exists.

        n_ord = length(results.scenario.ordinal_labels);
        n_nom = length(results.scenario.nominal_labels);
        for ord_idx = 1:n_ord
            for nom_idx = 1:n_nom
                results = populateOneTrajectory(results, ord_idx, nom_idx);
            end
        end

        function results = populateOneTrajectory(results, ord_idx, nom_idx)
            % SUB-CONTROLLER: Inject a flat pool for one cell if library fit exists
            nom_field = results.scenario.nominal_fields{nom_idx};
            colonySet = results.analysisResults ...
                .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
            libFit = extractLibraryFit(colonySet);
            if ~libFit.valid, return; end
            v = results.scenario.config(ord_idx).(nom_field).universal.v;
            pool = buildLibraryPool(libFit, v);
            results.scenario.config(ord_idx).(nom_field).pools = pool;
        end

        function libFit = extractLibraryFit(colonySet)
            % MODEL: Pull library phi and eps from colonySet (TERMINAL)
            libFit = struct('valid', false, 'phi', NaN, 'eps', NaN);
            if ~isfield(colonySet, 'gmm_results'), return; end
            if ~isfield(colonySet.gmm_results, 'fitted_model'), return; end
            fm = colonySet.gmm_results.fitted_model;
            if ~isfield(fm, 'library_blobs'), return; end
            blobs = fm.library_blobs;
            if isempty(blobs), return; end
            if ~isfield(blobs, 'centroids_phi') || isempty(blobs.centroids_phi), return; end
            if ~isfield(blobs, 'centroids_eps') || isempty(blobs.centroids_eps), return; end
            if isfield(blobs, 'total_weights') && ~isempty(blobs.total_weights)
                [~, dom] = max(blobs.total_weights);
            else
                dom = 1;
            end
            libFit.phi = blobs.centroids_phi(dom);
            libFit.eps = blobs.centroids_eps(dom);
            libFit.valid = isfinite(libFit.phi) && isfinite(libFit.eps);
        end

        function pool = buildLibraryPool(libFit, v)
            % MODEL: Construct a single flat-trajectory pool struct (TERMINAL)
            pool = struct();
            pool.initial_S = 1;
            pool.p_traj = repmat(libFit.phi, 1, v);
            pool.eps_traj = repmat(libFit.eps, 1, v);
            pool.phase_boundaries = [];
            pool.color = [0.20, 0.40, 0.70];
            pool.label = sprintf('Library: \\phi=%.2f \\epsilon=%.2f', ...
                libFit.phi, libFit.eps);
        end
    end
end
    %%   (2) UNIFIED SIMULATOR
%   Single simulator that reads pools and branch_events generically.
%   Replaces simulate_stable_phi, simulate_senescence_hr,
%   simulate_rescue_event, and simulate_custom_trajectory.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function simData = simulateColonySet(cellConfig)
    % CONTROLLER: Simulate all colonies under the unified pool/branch system.
    % Returns simData.radii (post-detection) and simData.tracking
    % (per-pool and per-event matrices, filtered to detectable colonies).

    rawData = simulateAllColonies(cellConfig);
    simData = applyDetection(rawData, cellConfig.universal);

    function rawData = simulateAllColonies(cellConfig)
        % SUB-CONTROLLER: Loop over all colonies, store raw tracking

        universal = cellConfig.universal;
        pools = cellConfig.pools;
        branch_events = cellConfig.branch_events;
        n = universal.n_colonies;
        n_pools = length(pools);
        n_events = length(branch_events);

        rawData = preallocateTracking(n, n_pools, n_events);

        for c = 1:n
            colonyResult = simulateOneColony(pools, branch_events, universal);
            rawData = appendColonyResult(rawData, colonyResult, c);
        end

        function rawData = preallocateTracking(n, n_pools, n_events)
            % MODEL: Allocate all tracking matrices (TERMINAL)
            rawData = struct();
            rawData.radii                    = zeros(n, 1);
            rawData.pool_S_final             = zeros(n, n_pools);
            rawData.pool_A_final             = zeros(n, n_pools);
            rawData.pool_cells_final         = zeros(n, n_pools);
            rawData.pool_first_populated_round = nan(n, n_pools);
            rawData.pool_S_zero_round        = nan(n, n_pools);
            if n_events > 0
                rawData.event_triggered          = false(n, n_events);
                rawData.event_first_trigger_round = nan(n, n_events);
                rawData.event_total_transferred  = zeros(n, n_events);
            else
                rawData.event_triggered          = false(n, 0);
                rawData.event_first_trigger_round = nan(n, 0);
                rawData.event_total_transferred  = zeros(n, 0);
            end
        end

        function colonyResult = simulateOneColony(pools, branch_events, universal)
            % MODEL: Single colony, multi-pool, with branch events (TERMINAL)
            n_pools = length(pools);
            n_events = length(branch_events);
            v = universal.v;

            % Initialize per-pool state
            S = zeros(1, n_pools);
            A = zeros(1, n_pools);
            for i = 1:n_pools
                S(i) = pools(i).initial_S;
            end

            % Per-pool tracking
            pool_first_populated = nan(1, n_pools);
            pool_S_zero = nan(1, n_pools);
            for i = 1:n_pools
                if S(i) > 0
                    pool_first_populated(i) = 1;
                end
            end

            % Per-event tracking
            evt_triggered = false(1, max(n_events, 1));
            evt_first_round = nan(1, max(n_events, 1));
            evt_total_xfer = zeros(1, max(n_events, 1));

            for r = 1:v

                % === DIVIDE ALL POOLS ===
                for i = 1:n_pools
                    if S(i) > 0
                        p_eff = drawEffectiveP( ...
                            pools(i).p_traj(r), pools(i).eps_traj(r), ...
                            universal.min_kappa);
                        [succ, fail] = divideOnce(S(i), p_eff, universal.approx_threshold);
                        S(i) = 2 * succ;
                        A(i) = A(i) + fail;
                    end
                end

                % === PROCESS BRANCH EVENTS ===
                for e = 1:n_events
                    ev = branch_events(e);

                    % Check eligibility window
                    if r < ev.eligible_rounds(1) || r > ev.eligible_rounds(end)
                        continue;
                    end

                    % Determine source count
                    if strcmp(ev.source_compartment, 'dividing')
                        src_count = S(ev.source_pool);
                    else
                        src_count = A(ev.source_pool);
                    end

                    if src_count <= 0
                        continue;
                    end

                    % Determine transfer count
                    xfer = 0;
                    if strcmp(ev.mode, 'per_cell')
                        xfer = binornd(src_count, ev.probability);
                    else  % per_colony
                        if ~evt_triggered(e)
                            if rand() < ev.probability
                                xfer = 1;
                            end
                        end
                    end

                    if xfer > 0
                        % Move cells from source to target dividing compartment
                        if strcmp(ev.source_compartment, 'dividing')
                            S(ev.source_pool) = S(ev.source_pool) - xfer;
                        else
                            A(ev.source_pool) = A(ev.source_pool) - xfer;
                        end
                        S(ev.target_pool) = S(ev.target_pool) + xfer;

                        % Update event tracking
                        if ~evt_triggered(e)
                            evt_triggered(e) = true;
                            evt_first_round(e) = r;
                        end
                        evt_total_xfer(e) = evt_total_xfer(e) + xfer;

                        % Update pool population tracking
                        if isnan(pool_first_populated(ev.target_pool))
                            pool_first_populated(ev.target_pool) = r;
                        end
                    end
                end

                % === TRACK S HITTING ZERO (after branch events) ===
                for i = 1:n_pools
                    if S(i) == 0 && ~isnan(pool_first_populated(i)) && isnan(pool_S_zero(i))
                        pool_S_zero(i) = r;
                    end
                end
            end

            % Pack result
            total_cells = sum(S) + sum(A);
            colonyResult = struct();
            colonyResult.S = S;
            colonyResult.A = A;
            colonyResult.pool_cells = S + A;
            colonyResult.total_cells = total_cells;
            colonyResult.pool_first_populated = pool_first_populated;
            colonyResult.pool_S_zero = pool_S_zero;
            colonyResult.event_triggered = evt_triggered(1:n_events);
            colonyResult.event_first_round = evt_first_round(1:n_events);
            colonyResult.event_total_transferred = evt_total_xfer(1:n_events);
            colonyResult.radius = cellsToRadius(total_cells, universal.packing_density);
        end

        function rawData = appendColonyResult(rawData, cr, c)
            % MODEL: Append one colony's result into tracking arrays (TERMINAL)
            rawData.radii(c) = cr.radius;
            rawData.pool_S_final(c, :) = cr.S;
            rawData.pool_A_final(c, :) = cr.A;
            rawData.pool_cells_final(c, :) = cr.pool_cells;
            rawData.pool_first_populated_round(c, :) = cr.pool_first_populated;
            rawData.pool_S_zero_round(c, :) = cr.pool_S_zero;
            n_events = size(rawData.event_triggered, 2);
            if n_events > 0
                rawData.event_triggered(c, :) = cr.event_triggered;
                rawData.event_first_trigger_round(c, :) = cr.event_first_round;
                rawData.event_total_transferred(c, :) = cr.event_total_transferred;
            end
        end
    end

    function simData = applyDetection(rawData, universal)
        % SUB-CONTROLLER: Apply detection limit, filter all tracking arrays

        mask = rawData.radii >= universal.detection_limit;
        simData = packageSimData(rawData, mask);

        function simData = packageSimData(rawData, mask)
            % MODEL: Pack into simData with filtered tracking (TERMINAL)
            simData = struct();
            simData.radii = rawData.radii(mask);

            tracking = struct();
            tracking.pool_S_final             = rawData.pool_S_final(mask, :);
            tracking.pool_A_final             = rawData.pool_A_final(mask, :);
            tracking.pool_cells_final         = rawData.pool_cells_final(mask, :);
            tracking.pool_first_populated_round = rawData.pool_first_populated_round(mask, :);
            tracking.pool_S_zero_round        = rawData.pool_S_zero_round(mask, :);
            tracking.event_triggered          = rawData.event_triggered(mask, :);
            tracking.event_first_trigger_round = rawData.event_first_trigger_round(mask, :);
            tracking.event_total_transferred  = rawData.event_total_transferred(mask, :);
            simData.tracking = tracking;
        end
    end
end

%%   (3) ENGINE PRIMITIVES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [successes, failures] = divideOnce(S, p_eff, approx_threshold)
    % MODEL: Single round of branching division for S cells (TERMINAL)
    if S <= 0
        successes = 0;
        failures = 0;
        return;
    end
    if S > approx_threshold
        mu_s = S * p_eff;
        var_s = S * p_eff * (1 - p_eff);
        successes = max(0, min(S, round(normrnd(mu_s, sqrt(var_s)))));
    else
        successes = binornd(S, p_eff);
    end
    failures = S - successes;
end

function p_eff = drawEffectiveP(p, eps_spread, min_kappa)
    % MODEL: Draw effective p from beta distribution centered on p (TERMINAL)
    if eps_spread <= 0 || p <= 0 || p >= 1
        p_eff = p;
        return;
    end
    max_spread = sqrt(p * (1 - p));
    if eps_spread >= max_spread
        p_eff = p;
        return;
    end
    kappa = p * (1 - p) / (eps_spread^2) - 1;
    if kappa < min_kappa
        p_eff = p;
        return;
    end
    a = p * kappa;
    b = (1 - p) * kappa;
    p_eff = betarnd(a, b);
end

function radius = cellsToRadius(n_cells, packing_density)
    % MODEL: Convert total cell count to colony radius (TERMINAL)
    if n_cells <= 0
        radius = 0;
        return;
    end
    radius = ((3 * n_cells) / (2 * pi * packing_density))^(1/3);
end

%%   (4) SHARED UTILITIES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function lib = extractLibraryAdequacy(colonySet)
    % MODEL: Pull library adequacy info from selected fit or alternatives (TERMINAL)
    % Used by both the engine logger and post-processing functions.
    lib = struct('present', false, 'emd', NaN, 'cutoff', NaN, ...
                 'passed', false, 'phi', NaN, 'eps', NaN, ...
                 'quality_shape', NaN, 'quality_scale', NaN);

    if isfield(colonySet, 'selected_method') && ...
            strcmp(char(colonySet.selected_method), 'Library')
        fm = colonySet.gmm_results.fitted_model;
        lib = readLibFromFittedModel(fm);
        return;
    end

    if isfield(colonySet, 'alternative_fits')
        altNames = fieldnames(colonySet.alternative_fits);
        for i = 1:length(altNames)
            alt = colonySet.alternative_fits.(altNames{i});
            if isfield(alt, 'method') && strcmp(alt.method, 'Library')
                if isfield(alt, 'gmm_results') && ...
                        isfield(alt.gmm_results, 'fitted_model')
                    lib = readLibFromFittedModel(alt.gmm_results.fitted_model);
                end
                return;
            end
        end
    end

    function lib = readLibFromFittedModel(fm)
        % MODEL: Extract adequacy + dominant blob phi/eps (TERMINAL)
        lib = struct('present', true, 'emd', NaN, 'cutoff', NaN, ...
                     'passed', false, 'phi', NaN, 'eps', NaN, ...
                     'quality_shape', NaN, 'quality_scale', NaN);
        if isfield(fm, 'library_adequacy_emd')
            lib.emd = fm.library_adequacy_emd;
        end
        if isfield(fm, 'library_adequacy_cutoff')
            lib.cutoff = fm.library_adequacy_cutoff;
        end
        if isfield(fm, 'library_adequacy_passed')
            lib.passed = fm.library_adequacy_passed;
        end
        if isfield(fm, 'library_quality_shape')
            lib.quality_shape = fm.library_quality_shape;
        end
        if isfield(fm, 'library_quality_scale')
            lib.quality_scale = fm.library_quality_scale;
        end
        if isfield(fm, 'library_blobs') && ...
                isfield(fm.library_blobs, 'centroids_phi') && ...
                ~isempty(fm.library_blobs.centroids_phi) && ...
                isfield(fm.library_blobs, 'total_weights') && ...
                ~isempty(fm.library_blobs.total_weights)
            [~, dom] = max(fm.library_blobs.total_weights);
            lib.phi = fm.library_blobs.centroids_phi(dom);
            lib.eps = fm.library_blobs.centroids_eps(dom);
        end
    end
end

%%   SECTION 3: ANALYSIS ENGINE
%   Decoupled QuantaColony pipeline. Takes a vector of radii and
%   options, returns a colonySet struct in QC format. This section
%   is entirely independent of simulation mechanics. It only sees
%   radii and analysis_options.
%
%   ENTRY POINT:
%       colonySet = analyzeColonySet(rawMeasurements, options)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function colonySet = analyzeColonySet(rawMeasurements, options)
    % CONTROLLER: Run the full analysis pipeline on one colony set's radii.
    % When multiple mixture methods are specified, runs each independently
    % and selects the best fit by AIC.

    colonySet = initializeColonySet(rawMeasurements);
    colonySet = detectModes(colonySet);
    methods = parseMethods(options.mixture_distribution);

    if length(methods) == 1
        colonySet = runSingleMethod(colonySet, options);
    else
        colonySet = runAndSelectBestMethod(colonySet, options, methods);
    end

    function methods = parseMethods(mixture_distribution)
        % MODEL: Normalize mixture_distribution to cell array of char (TERMINAL)
        if ischar(mixture_distribution)
            methods = {mixture_distribution};
        elseif isstring(mixture_distribution)
            methods = cellstr(mixture_distribution);
        elseif iscell(mixture_distribution)
            methods = mixture_distribution;
        else
            methods = {'LogNormal'};
        end
    end

    function colonySet = runSingleMethod(colonySet, options)
        % SUB-CONTROLLER: Single-method path
        singleOptions = overrideMethodString(options, parseMethods(options.mixture_distribution));
        colonySet = fitMixtureModel(colonySet, singleOptions);
        colonySet = allocateSubpopulationsFromGMM(colonySet);
        colonySet = processAllSubpopulations(colonySet, singleOptions);
        colonySet = finalizeColonySetStatistics(colonySet);
        colonySet.selected_method = singleOptions.mixture_distribution;
        colonySet.alternative_fits = struct();

        function opts = overrideMethodString(options, methods)
            % MODEL: Ensure single string for mixture_distribution (TERMINAL)
            opts = options;
            opts.mixture_distribution = methods{1};
        end
    end

    function colonySet = runAndSelectBestMethod(colonySet, options, methods)
        % SUB-CONTROLLER: Run full pipeline per method, compare, select winner
        candidates = runAllMethods(colonySet, options, methods);
        colonySet = selectWinningMethod(candidates, methods);

        function candidates = runAllMethods(baseColonySet, options, methods)
            % SUB-CONTROLLER: Produce completed colonySet per method
            n_methods = length(methods);
            candidates = cell(1, n_methods);
            for m = 1:n_methods
                methodOptions = buildMethodOptions(options, methods{m});
                cs = baseColonySet;
                cs = fitMixtureModel(cs, methodOptions);
                cs = allocateSubpopulationsFromGMM(cs);
                cs = processAllSubpopulations(cs, methodOptions);
                cs = finalizeColonySetStatistics(cs);
                candidates{m} = cs;
            end

            function methodOptions = buildMethodOptions(options, methodStr)
                % MODEL: Clone options with single method string (TERMINAL)
                methodOptions = options;
                methodOptions.mixture_distribution = methodStr;
            end
        end

        function colonySet = selectWinningMethod(candidates, methods)
            % SUB-CONTROLLER: Library wins if adequate, else lowest AIC
            aics = extractAICs(candidates);
            winnerIdx = pickWinnerWithLibraryPriority(candidates, methods, aics);
            colonySet = installWinnerAndAlternatives(candidates, methods, winnerIdx, aics);

            function aics = extractAICs(candidates)
                % MODEL: Pull final_aic from each candidate (TERMINAL)
                n = length(candidates);
                aics = inf(1, n);
                for i = 1:n
                    if isfield(candidates{i}, 'gmm_results') && ...
                            isfield(candidates{i}.gmm_results, 'fitted_model') && ...
                            isfield(candidates{i}.gmm_results.fitted_model, 'final_aic')
                        val = candidates{i}.gmm_results.fitted_model.final_aic;
                        if isfinite(val), aics(i) = val; end
                    end
                end
            end

            function idx = pickWinnerWithLibraryPriority(candidates, methods, aics)
                % MODEL: Adequate Library wins, else min AIC (TERMINAL)
                for i = 1:length(candidates)
                    if strcmp(methods{i}, 'Library')
                        fm = candidates{i}.gmm_results.fitted_model;
                        if isfield(fm, 'library_adequacy_passed') && fm.library_adequacy_passed
                            idx = i;
                            return;
                        end
                    end
                end
                [~, idx] = min(aics);
                if ~isfinite(aics(idx)), idx = 1; end
            end

            function colonySet = installWinnerAndAlternatives(candidates, methods, winnerIdx, aics)
                % MODEL: Set winner, attach others as alternatives (TERMINAL)
                colonySet = candidates{winnerIdx};
                colonySet.selected_method = methods{winnerIdx};
                alternatives = struct();
                for i = 1:length(candidates)
                    if i ~= winnerIdx
                        fieldName = matlab.lang.makeValidName(methods{i});
                        alt = struct();
                        alt.method = methods{i};
                        alt.aic = aics(i);
                        alt.optimal_components = candidates{i}.gmm_results.optimal_components;
                        alt.gmm_results = candidates{i}.gmm_results;
                        alt.subpopulations = candidates{i}.subpopulations;
                        alt.subpopulation_count = candidates{i}.subpopulation_count;
                        alternatives.(fieldName) = alt;
                    end
                end
                colonySet.alternative_fits = alternatives;
            end
        end
    end
end
function colonySet = initializeColonySet(rawMeasurements)
    % SUB-CONTROLLER: Build empty colony set with raw data
    cleaned = cleanRawMeasurements(rawMeasurements);
    colonySet = buildEmptyColonySet(cleaned);

    function cleaned = cleanRawMeasurements(raw)
        % MODEL: Remove NaN and ensure column vector (TERMINAL)
        raw = raw(:);
        cleaned = raw(~isnan(raw));
    end

    function colonySet = buildEmptyColonySet(measurements)
        % MODEL: Initialize colony set struct (TERMINAL)
        colonySet = struct();
        colonySet.raw_measurements = measurements;
        colonySet.colony_count = length(measurements);
        colonySet.gmm_results = struct();
        colonySet.subpopulations = struct([]);
        colonySet.subpopulation_count = NaN;
        colonySet.dominant_subpopulation_barcode = "";
        colonySet.total_weight_check = NaN;
    end
end

function colonySet = fitMixtureModel(colonySet, options)
    % SUB-CONTROLLER: Dispatch to library or GMM/LMM fitting
    if isfield(options, 'mixture_distribution') && ...
            strcmp(options.mixture_distribution, 'Library')
        colonySet = fitLibraryMixture(colonySet, options);
    else
        colonySet = determineOptimalComponentCount(colonySet, options);
        colonySet = executeMixtureFitting(colonySet, options);
    end

    % === GMM/LMM PATH ===

    function colonySet = determineOptimalComponentCount(colonySet, options)
        % SUB-CONTROLLER: Consensus sweeps for optimal k
        data = colonySet.raw_measurements;
        max_k = options.max_components;
        dist_type = options.mixture_distribution;
        N_CONSENSUS_ITERATIONS = 5;
        N_REPLICATES = 5;
        REGULARIZATION = 1e-3;

        if length(data) < 10
            colonySet = installInsufficientDataState(colonySet, max_k);
            return;
        end

        consensus = runConsensusSweeps(data, max_k, dist_type, ...
            N_CONSENSUS_ITERATIONS, N_REPLICATES, REGULARIZATION);
        colonySet = installConsensusResults(colonySet, consensus, max_k);

        function colonySet = installInsufficientDataState(colonySet, max_k)
            % MODEL: Fallback for insufficient data (TERMINAL)
            colonySet.gmm_results.optimal_components = 1;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', NaN(1, max_k), 'bic_scores', NaN(1, max_k), ...
                'component_counts_tested', 1:max_k, ...
                'k_distribution', zeros(1, max_k), ...
                'consensus_k_votes', 0, 'consensus_iterations', 0);
            colonySet.gmm_results.consensus_winning_fit = [];
        end

        function consensus = runConsensusSweeps(data, max_k, dist_type, n_iter, n_rep, reg)
            % MODEL: Run n_iter independent BIC sweeps (TERMINAL)
            consensus = struct();
            consensus.k_votes = zeros(1, max_k);
            consensus.aic_per_k_sum = zeros(1, max_k);
            consensus.bic_per_k_sum = zeros(1, max_k);
            consensus.aic_per_k_count = zeros(1, max_k);
            consensus.bic_per_k_count = zeros(1, max_k);
            consensus.best_fit_per_k = cell(1, max_k);
            consensus.best_bic_per_k = inf(1, max_k);

            if strcmp(dist_type, 'LogNormal')
                pos = data(data > 0);
                fit_data = log(pos);
            else
                fit_data = data;
            end
            opts = statset('MaxIter', 1000, 'TolFun', 1e-6);

            for iter = 1:n_iter
                iter_best_bic = Inf;
                iter_best_k = 1;
                for k = 1:max_k
                    try
                        gm = fitgmdist(fit_data, k, 'Options', opts, ...
                            'Replicates', n_rep, 'RegularizationValue', reg);
                        consensus.aic_per_k_sum(k) = consensus.aic_per_k_sum(k) + gm.AIC;
                        consensus.bic_per_k_sum(k) = consensus.bic_per_k_sum(k) + gm.BIC;
                        consensus.aic_per_k_count(k) = consensus.aic_per_k_count(k) + 1;
                        consensus.bic_per_k_count(k) = consensus.bic_per_k_count(k) + 1;
                        if gm.BIC < consensus.best_bic_per_k(k)
                            consensus.best_bic_per_k(k) = gm.BIC;
                            consensus.best_fit_per_k{k} = gm;
                        end
                        if gm.BIC < iter_best_bic
                            iter_best_bic = gm.BIC;
                            iter_best_k = k;
                        end
                    catch
                    end
                end
                if isfinite(iter_best_bic)
                    consensus.k_votes(iter_best_k) = consensus.k_votes(iter_best_k) + 1;
                end
            end

            consensus.aic_scores = nan(1, max_k);
            consensus.bic_scores = nan(1, max_k);
            for k = 1:max_k
                if consensus.aic_per_k_count(k) > 0
                    consensus.aic_scores(k) = consensus.aic_per_k_sum(k) / consensus.aic_per_k_count(k);
                end
                if consensus.bic_per_k_count(k) > 0
                    consensus.bic_scores(k) = consensus.bic_per_k_sum(k) / consensus.bic_per_k_count(k);
                end
            end

            [max_votes, modal_k] = max(consensus.k_votes);
            if max_votes == 0
                consensus.modal_k = 1;
                consensus.modal_k_votes = 0;
                consensus.winning_fit = [];
            else
                consensus.modal_k = modal_k;
                consensus.modal_k_votes = max_votes;
                consensus.winning_fit = consensus.best_fit_per_k{modal_k};
            end
            consensus.n_iterations = n_iter;
        end

        function colonySet = installConsensusResults(colonySet, consensus, max_k)
            % MODEL: Pack consensus results (TERMINAL)
            colonySet.gmm_results.optimal_components = consensus.modal_k;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', consensus.aic_scores, ...
                'bic_scores', consensus.bic_scores, ...
                'component_counts_tested', 1:max_k, ...
                'k_distribution', consensus.k_votes, ...
                'consensus_k_votes', consensus.modal_k_votes, ...
                'consensus_iterations', consensus.n_iterations);
            colonySet.gmm_results.consensus_winning_fit = consensus.winning_fit;
        end
    end

    function colonySet = executeMixtureFitting(colonySet, options)
        % SUB-CONTROLLER: Use consensus winning fit, compute deltas
        if length(colonySet.raw_measurements) < 10
            colonySet = installFallbackFit(colonySet);
            return;
        end
        winning_gm = colonySet.gmm_results.consensus_winning_fit;
        if isempty(winning_gm)
            colonySet = installFallbackFit(colonySet);
            return;
        end

        fit = unpackWinningFit(colonySet, winning_gm, options);
        deltas = computeGMMDeltaMetrics(colonySet);
        colonySet = installFitAndDeltas(colonySet, fit, deltas);

        function fit = unpackWinningFit(colonySet, gm, options)
            % MODEL: Extract parameters from consensus winning fit (TERMINAL)
            data = colonySet.raw_measurements;
            dist_type = options.mixture_distribution;
            k = gm.NumComponents;
            fit = struct();
            try
                if strcmp(dist_type, 'LogNormal')
                    fit_data = log(data(data > 0));
                else
                    fit_data = data;
                end
                [post_probs, ~] = posterior(gm, fit_data);
                [~, hard_assign] = max(post_probs, [], 2);
                sigma_values = zeros(1, k);
                for i = 1:k
                    sigma_values(i) = sqrt(gm.Sigma(:, :, i));
                end
                if strcmp(dist_type, 'LogNormal')
                    mu_values = exp(gm.mu(:)');
                else
                    mu_values = gm.mu(:)';
                end
                fit.success = true;
                fit.gmm = gm;
                fit.GMM_mu = mu_values;
                fit.GMM_sigma = sigma_values;
                fit.GMM_weights = gm.ComponentProportion;
                fit.posterior_probabilities = post_probs;
                fit.hard_assignments = hard_assign;
                fit.log_likelihood = -gm.NegativeLogLikelihood;
                fit.final_aic = gm.AIC;
                fit.final_bic = gm.BIC;
                fit.convergence_flag = gm.Converged;
            catch
                fit.success = false;
                fit.gmm = [];
                fit.GMM_mu = mean(data);
                fit.GMM_sigma = std(data);
                fit.GMM_weights = 1.0;
                fit.posterior_probabilities = ones(length(data), 1);
                fit.hard_assignments = ones(length(data), 1);
                fit.log_likelihood = NaN;
                fit.final_aic = NaN;
                fit.final_bic = NaN;
                fit.convergence_flag = false;
            end
        end

        function deltas = computeGMMDeltaMetrics(colonySet)
            % MODEL: Compute delta AIC/BIC (TERMINAL)
            ms = colonySet.gmm_results.model_selection_criteria;
            deltas = struct();
            valid_aic = ms.aic_scores(isfinite(ms.aic_scores));
            if length(valid_aic) >= 2
                s = sort(valid_aic);
                deltas.delta_aic_subpop = s(2) - s(1);
            else
                deltas.delta_aic_subpop = NaN;
            end
            valid_bic = ms.bic_scores(isfinite(ms.bic_scores));
            if length(valid_bic) >= 2
                s = sort(valid_bic);
                deltas.delta_bic_subpop = s(2) - s(1);
            else
                deltas.delta_bic_subpop = NaN;
            end
        end

        function colonySet = installFitAndDeltas(colonySet, fit, deltas)
            % MODEL: Pack fitted_model and assignments (TERMINAL)
            fitted_model = struct();
            fitted_model.convergence_flag = fit.convergence_flag;
            fitted_model.log_likelihood = fit.log_likelihood;
            fitted_model.final_aic = fit.final_aic;
            fitted_model.final_bic = fit.final_bic;
            fitted_model.GMM_mu = fit.GMM_mu;
            fitted_model.GMM_sigma = fit.GMM_sigma;
            fitted_model.GMM_weights = fit.GMM_weights;
            fitted_model.delta_aic_subpop = deltas.delta_aic_subpop;
            fitted_model.delta_bic_subpop = deltas.delta_bic_subpop;

            component_assignments = struct();
            component_assignments.hard_assignments = fit.hard_assignments;
            component_assignments.posterior_probabilities = fit.posterior_probabilities;

            colonySet.gmm_results.fitted_model = fitted_model;
            colonySet.gmm_results.component_assignments = component_assignments;
        end

        function colonySet = installFallbackFit(colonySet)
            % MODEL: Minimal fitted_model for insufficient data (TERMINAL)
            data = colonySet.raw_measurements;
            fitted_model = struct();
            fitted_model.convergence_flag = false;
            fitted_model.log_likelihood = NaN;
            fitted_model.final_aic = NaN;
            fitted_model.final_bic = NaN;
            if isempty(data)
                fitted_model.GMM_mu = NaN;
                fitted_model.GMM_sigma = NaN;
            else
                fitted_model.GMM_mu = mean(data);
                fitted_model.GMM_sigma = std(data);
            end
            fitted_model.GMM_weights = 1.0;
            fitted_model.delta_aic_subpop = NaN;
            fitted_model.delta_bic_subpop = NaN;
            n = length(data);
            component_assignments = struct();
            component_assignments.hard_assignments = ones(n, 1);
            component_assignments.posterior_probabilities = ones(n, 1);
            colonySet.gmm_results.fitted_model = fitted_model;
            colonySet.gmm_results.component_assignments = component_assignments;
        end
    end

    % === LIBRARY PATH ===

    function colonySet = fitLibraryMixture(colonySet, options)
        % SUB-CONTROLLER: Library-based fitting via best-entry EMD selection
        if length(colonySet.raw_measurements) < 10
            colonySet = installLibraryFallback(colonySet);
            return;
        end

        library = options.library;
        context = buildFitContext(colonySet, library);
        bestEntry = findBestEntryByEMD(context, library);

        if ~bestEntry.success
            colonySet = installLibraryFallback(colonySet);
            return;
        end

        blobs = buildSingleBlobFromEntry(bestEntry);
        assignments = assignAllColoniesToSingleBlob(context);
        fitQuality = computeLibraryFitQuality(context, bestEntry, library);
        adequacy = packAdequacyFromBestEntry(bestEntry, context);
        colonySet = installLibraryFit(colonySet, blobs, assignments, fitQuality, adequacy);

        function context = buildFitContext(colonySet, library)
            % SUB-CONTROLLER: Normalize data, build empirical CDF
            normalized = normalizeObservedRadii(colonySet.raw_measurements, library.ceiling_radius);
            emp_cdf = buildEmpiricalCDF(normalized, library.x_grid);
            data_median_um = computeDataMedian(colonySet.raw_measurements);
            context = packFitContext(colonySet.raw_measurements, normalized, emp_cdf, data_median_um, library.x_grid, library.ceiling_radius);

            function normalized = normalizeObservedRadii(radii, ceiling_radius)
                % MODEL: Normalize radii to [0,1] (TERMINAL)
                normalized = radii(:) / ceiling_radius;
                normalized = min(normalized, 1);
                normalized = max(normalized, 0);
            end

            function emp_cdf = buildEmpiricalCDF(normalized, x_grid)
                % MODEL: Empirical CDF on x_grid (TERMINAL)
                n = length(normalized);
                emp_cdf = sum(normalized(:) <= x_grid(:)', 1) / n;
                emp_cdf = emp_cdf(:);
            end

            function data_median_um = computeDataMedian(raw_measurements)
                % MODEL: Median of raw radii (TERMINAL)
                pos = raw_measurements(raw_measurements > 0);
                if isempty(pos), data_median_um = NaN; else, data_median_um = median(pos); end
            end

            function context = packFitContext(raw, normalized, emp_cdf, data_median_um, x_grid, ceiling_radius)
                % MODEL: Pack fit context (TERMINAL)
                context = struct();
                context.raw_measurements = raw;
                context.normalized = normalized;
                context.emp_cdf = emp_cdf;
                context.data_median_um = data_median_um;
                context.x_grid = x_grid;
                context.ceiling_radius = ceiling_radius;
            end
        end

        function bestEntry = findBestEntryByEMD(context, library)
            % SUB-CONTROLLER: Compute EMD against every entry, pick minimum
            emd_values = computeAllEntryEMDs(context, library);
            bestEntry = pickMinimumEMDEntry(emd_values, library);

            function emd_values = computeAllEntryEMDs(context, library)
                % MODEL: EMD between empirical CDF and each entry (TERMINAL)
                n_entries = length(library.entries);
                emd_values = inf(1, n_entries);
                x_grid = context.x_grid;
                emp_cdf = context.emp_cdf;
                ceiling = context.ceiling_radius;
                for i = 1:n_entries
                    if ~library.entries(i).valid, continue; end
                    kde_y = library.entries(i).kde_y(:);
                    model_cdf = cumtrapz(x_grid, kde_y);
                    if model_cdf(end) > 0, model_cdf = model_cdf / model_cdf(end); end
                    emd_normalized = trapz(x_grid, abs(emp_cdf - model_cdf(:)));
                    emd_values(i) = emd_normalized * ceiling;
                end
            end

            function bestEntry = pickMinimumEMDEntry(emd_values, library)
                % MODEL: Find min-EMD entry (TERMINAL)
                [best_emd, best_idx] = min(emd_values);
                bestEntry = struct();
                bestEntry.success = isfinite(best_emd);
                bestEntry.entry_index = best_idx;
                bestEntry.emd = best_emd;
                if ~bestEntry.success
                    bestEntry.phi = NaN; bestEntry.eps = NaN;
                    bestEntry.phi_index = NaN; bestEntry.eps_index = NaN;
                    bestEntry.null_p95 = NaN; bestEntry.entry_peak_um = NaN;
                    return;
                end
                n_eps = length(library.config.eps_values);
                p_idx = floor((best_idx - 1) / n_eps) + 1;
                e_idx = mod(best_idx - 1, n_eps) + 1;
                bestEntry.phi = library.config.phi_values(p_idx);
                bestEntry.eps = library.config.eps_values(e_idx);
                bestEntry.phi_index = p_idx;
                bestEntry.eps_index = e_idx;
                entry = library.entries(best_idx);
                if isfield(entry, 'null_p95'), bestEntry.null_p95 = entry.null_p95;
                else, bestEntry.null_p95 = NaN; end
                if isfield(entry, 'peak_x') && ~isnan(entry.peak_x)
                    bestEntry.entry_peak_um = entry.peak_x * library.ceiling_radius;
                else, bestEntry.entry_peak_um = NaN; end
            end
        end

        function blobs = buildSingleBlobFromEntry(bestEntry)
            % MODEL: Wrap entry as single-blob structure (TERMINAL)
            blobs = struct();
            blobs.n_blobs = 1;
            blobs.centroids_phi = bestEntry.phi;
            blobs.centroids_eps = bestEntry.eps;
            blobs.total_weights = 1.0;
            blobs.basin_phi_indices = {bestEntry.phi_index};
            blobs.basin_winning_phi_idx = bestEntry.phi_index;
            blobs.entry_index = bestEntry.entry_index;
        end

        function assignments = assignAllColoniesToSingleBlob(context)
            % MODEL: Assign all colonies to blob (TERMINAL)
            n = length(context.normalized);
            assignments = struct();
            assignments.hard = ones(n, 1);
            assignments.posterior = ones(n, 1);
        end

        function fitQuality = computeLibraryFitQuality(context, bestEntry, library)
            % SUB-CONTROLLER: Log-likelihood under winning entry
            bin_indices = findColonyBinIndices(context.normalized, context.x_grid);
            fitQuality = evaluateLogLikelihood(bin_indices, bestEntry, context, library);

            function bin_indices = findColonyBinIndices(normalized, x_grid)
                % MODEL: Find nearest bin for each colony (TERMINAL)
                dx = x_grid(2) - x_grid(1);
                bin_indices = round((normalized - x_grid(1)) / dx) + 1;
                bin_indices = max(1, min(length(x_grid), bin_indices));
            end

            function fitQuality = evaluateLogLikelihood(bin_indices, bestEntry, context, library)
                % MODEL: Log-likelihood from KDE (TERMINAL)
                entry = library.entries(bestEntry.entry_index);
                kde_y = entry.kde_y(:);
                area = trapz(context.x_grid, kde_y);
                if area > 0, kde_y = kde_y / area; end
                n = length(context.normalized);
                densities = kde_y(bin_indices);
                densities = max(densities, 1e-300);
                log_lik = sum(log(densities)) - n * log(library.ceiling_radius);
                fitQuality = struct();
                fitQuality.log_likelihood = log_lik;
                fitQuality.n_colonies = n;
            end
        end

        function adequacy = packAdequacyFromBestEntry(bestEntry, context)
            % MODEL: Domain check and EMD adequacy test with quality scores (TERMINAL)
            DOMAIN_TOLERANCE = 2.0;
            GRID_SNAP_TOLERANCE = 8.0;

            adequacy = struct();
            adequacy.emd = bestEntry.emd;
            adequacy.cutoff = bestEntry.null_p95 * GRID_SNAP_TOLERANCE;
            adequacy.domain_ratio = computeDomainRatio(context.data_median_um, bestEntry.entry_peak_um);
            adequacy.domain_tolerance = DOMAIN_TOLERANCE;

            domain_ok = isfinite(adequacy.domain_ratio) && adequacy.domain_ratio <= DOMAIN_TOLERANCE;
            emd_ok = ~isnan(adequacy.cutoff) && ~isnan(adequacy.emd) && adequacy.emd <= adequacy.cutoff;
            adequacy.passed = domain_ok && emd_ok;
            adequacy.domain_passed = domain_ok;
            adequacy.emd_passed = emd_ok;

            if isfinite(adequacy.cutoff) && adequacy.cutoff > 0 && isfinite(adequacy.emd)
                adequacy.quality_shape = adequacy.emd / adequacy.cutoff;
            else
                adequacy.quality_shape = NaN;
            end
            if isfinite(adequacy.domain_ratio) && adequacy.domain_tolerance > 0
                adequacy.quality_scale = adequacy.domain_ratio / adequacy.domain_tolerance;
            else
                adequacy.quality_scale = NaN;
            end

            function ratio = computeDomainRatio(data_median_um, entry_peak_um)
                % MODEL: Symmetric ratio (TERMINAL)
                if isnan(data_median_um) || isnan(entry_peak_um) || ...
                        data_median_um <= 0 || entry_peak_um <= 0
                    ratio = NaN; return;
                end
                ratio = max(data_median_um / entry_peak_um, entry_peak_um / data_median_um);
            end
        end

        function colonySet = installLibraryFit(colonySet, blobs, assignments, fitQuality, adequacy)
            % SUB-CONTROLLER: Pack library fit into gmm_results
            colonySet.gmm_results.optimal_components = blobs.n_blobs;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', NaN, 'bic_scores', NaN, 'component_counts_tested', NaN);

            fitted_model = buildFittedModelStruct(colonySet.raw_measurements, assignments, blobs, fitQuality, adequacy);
            fitted_model.library_blobs = buildLibraryBlobsInfo(blobs);
            colonySet.gmm_results.fitted_model = fitted_model;
            colonySet.gmm_results.component_assignments = buildCompAssignStruct(assignments);

            function fm = buildFittedModelStruct(raw_measurements, assignments, blobs, fitQuality, adequacy)
                % MODEL: Build lognormal-equivalent stats with AIC and adequacy (TERMINAL)
                k = blobs.n_blobs;
                GMM_mu = zeros(1, k); GMM_sigma = zeros(1, k);
                for i = 1:k
                    mask = (assignments.hard == i);
                    blob_radii = raw_measurements(mask);
                    pos_radii = blob_radii(blob_radii > 0);
                    if length(pos_radii) >= 2
                        log_r = log(pos_radii);
                        GMM_mu(i) = exp(mean(log_r));
                        GMM_sigma(i) = std(log_r);
                    elseif ~isempty(blob_radii)
                        GMM_mu(i) = mean(blob_radii); GMM_sigma(i) = 0.1;
                    else
                        GMM_mu(i) = NaN; GMM_sigma(i) = NaN;
                    end
                end
                k_params = max(3 * k - 1, 1);
                log_lik = fitQuality.log_likelihood;
                n = fitQuality.n_colonies;
                aic = 2 * k_params - 2 * log_lik;
                bic = k_params * log(n) - 2 * log_lik;

                fm = struct();
                fm.convergence_flag = true;
                fm.log_likelihood = log_lik;
                fm.final_aic = aic; fm.final_bic = bic;
                fm.GMM_mu = GMM_mu; fm.GMM_sigma = GMM_sigma;
                fm.GMM_weights = blobs.total_weights;
                fm.delta_aic_subpop = NaN; fm.delta_bic_subpop = NaN;
                fm.library_adequacy_emd = adequacy.emd;
                fm.library_adequacy_cutoff = adequacy.cutoff;
                fm.library_adequacy_passed = adequacy.passed;
                fm.library_domain_ratio = adequacy.domain_ratio;
                fm.library_domain_tolerance = adequacy.domain_tolerance;
                fm.library_domain_passed = adequacy.domain_passed;
                fm.library_emd_passed = adequacy.emd_passed;
                fm.library_quality_shape = adequacy.quality_shape;
                fm.library_quality_scale = adequacy.quality_scale;
            end

            function libInfo = buildLibraryBlobsInfo(blobs)
                % MODEL: Pack library blob metadata (TERMINAL)
                libInfo = struct();
                libInfo.n_blobs = blobs.n_blobs;
                libInfo.centroids_phi = blobs.centroids_phi;
                libInfo.centroids_eps = blobs.centroids_eps;
                libInfo.total_weights = blobs.total_weights;
                libInfo.basin_phi_indices = blobs.basin_phi_indices;
                libInfo.basin_winning_phi_idx = blobs.basin_winning_phi_idx;
            end

            function ca = buildCompAssignStruct(assignments)
                % MODEL: Build component_assignments (TERMINAL)
                ca = struct();
                ca.hard_assignments = assignments.hard(:);
                ca.posterior_probabilities = assignments.posterior;
            end
        end

        function colonySet = installLibraryFallback(colonySet)
            % MODEL: Minimal library fit for degenerate cases (TERMINAL)
            data = colonySet.raw_measurements;
            colonySet.gmm_results.optimal_components = 1;
            colonySet.gmm_results.model_selection_criteria = struct( ...
                'aic_scores', NaN, 'bic_scores', NaN, 'component_counts_tested', NaN);
            fm = struct();
            fm.convergence_flag = false;
            fm.log_likelihood = NaN; fm.final_aic = NaN; fm.final_bic = NaN;
            if isempty(data)
                fm.GMM_mu = NaN; fm.GMM_sigma = NaN;
            else
                pos = data(data > 0);
                if length(pos) >= 2
                    fm.GMM_mu = exp(mean(log(pos))); fm.GMM_sigma = std(log(pos));
                else
                    fm.GMM_mu = mean(data); fm.GMM_sigma = 0;
                end
            end
            fm.GMM_weights = 1.0;
            fm.delta_aic_subpop = NaN; fm.delta_bic_subpop = NaN;
            fm.library_adequacy_emd = NaN; fm.library_adequacy_cutoff = NaN;
            fm.library_adequacy_passed = false;
            fm.library_domain_ratio = NaN; fm.library_domain_tolerance = NaN;
            fm.library_domain_passed = false; fm.library_emd_passed = false;
            fm.library_quality_shape = NaN; fm.library_quality_scale = NaN;
            fm.library_blobs = struct('n_blobs', 0, 'centroids_phi', [], ...
                'centroids_eps', [], 'total_weights', [], ...
                'basin_phi_indices', {{}}, 'basin_winning_phi_idx', []);
            n = length(data);
            ca = struct();
            ca.hard_assignments = ones(n, 1);
            ca.posterior_probabilities = ones(n, 1);
            colonySet.gmm_results.fitted_model = fm;
            colonySet.gmm_results.component_assignments = ca;
        end
    end
end

function colonySet = allocateSubpopulationsFromGMM(colonySet)
    % SUB-CONTROLLER: Build component records and subpopulation slots
    colonySet = initializeComponentSlots(colonySet);
    colonySet = populateComponentMetrics(colonySet);

    function colonySet = initializeComponentSlots(colonySet)
        % MODEL: Allocate empty components and subpopulations (TERMINAL)
        k = colonySet.gmm_results.optimal_components;
        components = repmat(struct(), 1, k);
        for i = 1:k
            components(i).barcode = "";
            components(i).initial_mean = NaN;
            components(i).initial_sigma = NaN;
            components(i).weight = NaN;
            components(i).data_indices = [];
        end
        colonySet.gmm_results.components = components;
        subpopulations = repmat(struct(), 1, k);
        for i = 1:k
            subpopulations(i).component_String = "";
            subpopulations(i).distribution_tests = struct();
            subpopulations(i).selection_criteria = struct();
            subpopulations(i).best_distribution = "";
        end
        colonySet.subpopulations = subpopulations;
    end

    function colonySet = populateComponentMetrics(colonySet)
        % MODEL: Fill components with GMM-derived stats (TERMINAL)
        k = colonySet.gmm_results.optimal_components;
        fm = colonySet.gmm_results.fitted_model;
        ha = colonySet.gmm_results.component_assignments.hard_assignments;
        actual_k = min([length(fm.GMM_mu), length(fm.GMM_sigma), length(fm.GMM_weights)]);
        if actual_k < k
            k = actual_k;
            colonySet.gmm_results.optimal_components = k;
        end
        for i = 1:k
            barcode = sprintf('Comp%d', i);
            mask = (ha == i);
            colonySet.gmm_results.components(i).barcode = barcode;
            colonySet.gmm_results.components(i).initial_mean = fm.GMM_mu(i);
            colonySet.gmm_results.components(i).initial_sigma = fm.GMM_sigma(i);
            colonySet.gmm_results.components(i).weight = fm.GMM_weights(i);
            colonySet.gmm_results.components(i).data_indices = find(mask);
            colonySet.subpopulations(i).component_String = barcode;
        end
    end
end

function colonySet = processAllSubpopulations(colonySet, options)
    % SUB-CONTROLLER: Run distribution tests on each component
    k = colonySet.gmm_results.optimal_components;
    for c = 1:k
        colonySet = processSingleSubpopulation(colonySet, c, options);
    end

    function colonySet = processSingleSubpopulation(colonySet, c, options)
        % SUB-CONTROLLER: Pull data, fit, store
        compData = extractSubpopulationData(colonySet, c);
        analysis = determineBestDistributionAndFit(compData, options);
        colonySet = stowSubpopulationAnalysis(colonySet, c, analysis);

        function compData = extractSubpopulationData(colonySet, c)
            % MODEL: Pull component measurements (TERMINAL)
            indices = colonySet.gmm_results.components(c).data_indices;
            compData = colonySet.raw_measurements(indices);
        end

        function colonySet = stowSubpopulationAnalysis(colonySet, c, analysis)
            % MODEL: Store analysis results (TERMINAL)
            colonySet.subpopulations(c).distribution_tests = analysis.distribution_tests;
            colonySet.subpopulations(c).selection_criteria = analysis.selection_criteria;
            colonySet.subpopulations(c).best_distribution = analysis.best_distribution;
        end
    end
end

function analysis = determineBestDistributionAndFit(data, options)
    % SUB-CONTROLLER: Run all distribution tests and select best
    if length(data) < 3
        analysis = buildInsufficientDataAnalysis(data);
        return;
    end
    distribution_tests = runAllDistributionTests(data, options);
    [best_dist, selection_criteria] = selectBestFit(distribution_tests);
    analysis = struct();
    analysis.distribution_tests = distribution_tests;
    analysis.selection_criteria = selection_criteria;
    analysis.best_distribution = best_dist;
end

function distribution_tests = runAllDistributionTests(data, options)
    % SUB-CONTROLLER: Run every distribution fit
    distribution_tests = struct();
    distribution_tests.normal = tryNormalDistribution(data);
    distribution_tests.lognormal = tryLogNormalDistribution(data);
    distribution_tests.library = tryLibraryDistribution(data, options);
    distribution_tests.nonparametric = tryNonParametricDistribution(data);
end

function [best_dist, criteria] = selectBestFit(distribution_tests)
    % SUB-CONTROLLER: Select best parametric fit by AIC
    scores = gatherDistributionScores(distribution_tests);
    qualityFlags = evaluateQualityFlags(distribution_tests, scores);
    bestInfo = pickBestDistribution(scores, qualityFlags);
    deltas = computeDistributionDeltas(scores, qualityFlags);
    criteria = packSelectionCriteria(scores, qualityFlags, bestInfo, deltas);
    best_dist = bestInfo.name;

    function scores = gatherDistributionScores(dt)
        % MODEL: Pull AIC/BIC (TERMINAL)
        scores = struct();
        scores.normal_aic = dt.normal.aic_score;
        scores.lognormal_aic = dt.lognormal.aic_score;
        scores.library_aic = dt.library.aic_score;
        scores.normal_bic = dt.normal.bic_score;
        scores.lognormal_bic = dt.lognormal.bic_score;
        scores.library_bic = dt.library.bic_score;
    end

    function qf = evaluateQualityFlags(dt, scores)
        % MODEL: Mark valid fits (TERMINAL)
        qf = struct();
        qf.normal_converged = isfinite(scores.normal_aic);
        qf.lognormal_valid = isfinite(scores.lognormal_aic);
        qf.library_valid = isfinite(scores.library_aic);
        qf.nonparam_sufficient = dt.nonparametric.effective_sample_size >= 20;
        qf.insufficient_data = false;
    end

    function bestInfo = pickBestDistribution(scores, qf)
        % MODEL: Pick best parametric or fall back (TERMINAL)
        bestInfo = struct();
        valid_dists = {};
        valid_aics = [];
        if qf.normal_converged
            valid_dists{end+1} = 'Normal'; valid_aics(end+1) = scores.normal_aic;
        end
        if qf.lognormal_valid
            valid_dists{end+1} = 'LogNormal'; valid_aics(end+1) = scores.lognormal_aic;
        end
        if qf.library_valid
            valid_dists{end+1} = 'Library'; valid_aics(end+1) = scores.library_aic;
        end
        if ~isempty(valid_aics)
            [sorted_aics, idx] = sort(valid_aics);
            bestInfo.name = valid_dists{idx(1)};
            if length(sorted_aics) > 1
                bestInfo.winning_margin = sorted_aics(2) - sorted_aics(1);
                bestInfo.selection_reason = sprintf('Lowest AIC by margin of %.1f', bestInfo.winning_margin);
            else
                bestInfo.winning_margin = Inf;
                bestInfo.selection_reason = 'Only valid parametric distribution';
            end
        elseif qf.nonparam_sufficient
            bestInfo.name = 'Non-parametric';
            bestInfo.winning_margin = NaN;
            bestInfo.selection_reason = 'Non-parametric: no valid parametric fits';
        else
            bestInfo.name = 'No_Valid_Fit';
            bestInfo.winning_margin = NaN;
            bestInfo.selection_reason = 'No valid distribution fits available';
        end
    end

    function deltas = computeDistributionDeltas(scores, qf)
        % MODEL: Compute delta AIC/BIC (TERMINAL)
        deltas = struct();
        valid_aic = [];
        if qf.normal_converged, valid_aic(end+1) = scores.normal_aic; end
        if qf.lognormal_valid, valid_aic(end+1) = scores.lognormal_aic; end
        if qf.library_valid, valid_aic(end+1) = scores.library_aic; end
        if length(valid_aic) >= 2
            s = sort(valid_aic); deltas.Delta_aic_distribution = s(2) - s(1);
        else
            deltas.Delta_aic_distribution = NaN;
        end
        valid_bic = [];
        if qf.normal_converged, valid_bic(end+1) = scores.normal_bic; end
        if qf.lognormal_valid, valid_bic(end+1) = scores.lognormal_bic; end
        if qf.library_valid, valid_bic(end+1) = scores.library_bic; end
        if length(valid_bic) >= 2
            s = sort(valid_bic); deltas.Delta_bic_distribution = s(2) - s(1);
        else
            deltas.Delta_bic_distribution = NaN;
        end
    end

    function criteria = packSelectionCriteria(scores, qf, bestInfo, deltas)
        % MODEL: Pack selection_criteria (TERMINAL)
        criteria = struct();
        criteria.aic_scores = struct('normal', scores.normal_aic, ...
            'LogNormal', scores.lognormal_aic, 'library', scores.library_aic, ...
            'nonparametric', NaN, 'Delta_aic_distribution', deltas.Delta_aic_distribution);
        criteria.bic_scores = struct('normal', scores.normal_bic, ...
            'LogNormal', scores.lognormal_bic, 'library', scores.library_bic, ...
            'nonparametric', NaN, 'Delta_bic_distribution', deltas.Delta_bic_distribution);
        criteria.quality_flags = qf;
        criteria.selection_reason = bestInfo.selection_reason;
        criteria.winning_margin = bestInfo.winning_margin;
    end
end

function analysis = buildInsufficientDataAnalysis(data)
    % MODEL: Analysis struct for too few data points (TERMINAL)
    if isempty(data)
        sample_mean = NaN; sample_median = NaN; sample_std = NaN;
        data_range = [NaN, NaN]; sample_size = 0;
    else
        sample_mean = mean(data); sample_median = median(data); sample_std = std(data);
        data_range = [min(data), max(data)]; sample_size = length(data);
    end

    dt = struct();
    dt.insufficient_data = struct('sample_size', sample_size, 'sample_mean', sample_mean, ...
        'sample_median', sample_median, 'sample_std', sample_std, ...
        'data_range', data_range, ...
        'reason', sprintf('Subpopulation has %d points (minimum 3 required)', sample_size));
    dt.normal = struct('final_mean', sample_mean, 'final_sigma', sample_std, ...
        'confidence_interval', [NaN, NaN], 'aic_score', Inf, 'bic_score', Inf, ...
        'ks_test_pvalue', NaN, 'log_likelihood', NaN);
    dt.lognormal = struct('mu_parameter', NaN, 'sigma_parameter', NaN, ...
        'fitted_median', sample_median, 'aic_score', Inf, 'bic_score', Inf, ...
        'ks_test_pvalue', NaN, 'log_likelihood', NaN);
    dt.library = struct('phi_parameter', NaN, 'eps_parameter', NaN, ...
        'phi_index', NaN, 'eps_index', NaN, 'entry_index', NaN, ...
        'aic_score', Inf, 'bic_score', Inf, 'ks_test_pvalue', NaN, ...
        'log_likelihood', NaN, 'fitting_successful', false, ...
        'failure_reason', 'Insufficient data', ...
        'adequacy_emd', NaN, 'adequacy_cutoff', NaN, 'adequacy_passed', false);
    dt.nonparametric = struct('bandwidth', NaN, 'kernel_points', [], ...
        'density_values', [], 'peak_estimate', sample_mean, ...
        'effective_sample_size', sample_size);

    sc = struct();
    sc.aic_scores = struct('normal', Inf, 'LogNormal', Inf, 'library', Inf, ...
        'nonparametric', NaN, 'Delta_aic_distribution', NaN);
    sc.bic_scores = struct('normal', Inf, 'LogNormal', Inf, 'library', Inf, ...
        'nonparametric', NaN, 'Delta_bic_distribution', NaN);
    sc.quality_flags = struct('normal_converged', false, 'lognormal_valid', false, ...
        'library_valid', false, 'nonparam_sufficient', false, 'insufficient_data', true);
    sc.selection_reason = 'Insufficient data for fitting';
    sc.winning_margin = NaN;

    analysis = struct();
    analysis.distribution_tests = dt;
    analysis.selection_criteria = sc;
    analysis.best_distribution = 'Insufficient_Data';
end

function colonySet = finalizeColonySetStatistics(colonySet)
    % MODEL: Compute subpopulation count, dominant, weight check (TERMINAL)
    components = colonySet.gmm_results.components;
    k = colonySet.gmm_results.optimal_components;
    colonySet.subpopulation_count = k;
    if k > 0 && ~isempty(components) && isfield(components, 'weight')
        weights = [components.weight];
        if all(isnan(weights))
            colonySet.dominant_subpopulation_barcode = "";
            colonySet.total_weight_check = NaN;
        else
            [~, max_idx] = max(weights);
            colonySet.dominant_subpopulation_barcode = components(max_idx).barcode;
            colonySet.total_weight_check = sum(weights);
        end
    else
        colonySet.dominant_subpopulation_barcode = "";
        colonySet.total_weight_check = NaN;
    end
end

%%   DISTRIBUTION FITS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function colonySet = detectModes(colonySet)
    % SUB-CONTROLLER: Detect modes in raw radius distribution via KDE peak finding.
    % Stores results in colonySet.mode_detection.

    % Constants
    MIN_DATA_POINTS = 10;
    PROMINENCE_FRACTION = 0.05;     % 5% of max density
    N_EVAL_POINTS = 200;

    data = colonySet.raw_measurements;

    if length(data) < MIN_DATA_POINTS
        colonySet.mode_detection = buildInsufficientDataResult(data);
        return;
    end

    density = computeDensitySurface(data, N_EVAL_POINTS);
     peaks = findDensityPeaks(density, PROMINENCE_FRACTION);
     peaks.locations = exp(peaks.locations);
     colonySet.mode_detection = packModeResult(density, peaks, length(data));
    function modeData = buildInsufficientDataResult(data)
        % MODEL: Empty result for insufficient data (TERMINAL)
        modeData = struct();
        modeData.n_modes = 0;
        modeData.peak_locations = [];
        modeData.peak_heights = [];
        modeData.peak_prominences = [];
        modeData.bandwidth_used = NaN;
        modeData.prominence_threshold = NaN;
        modeData.density_x = [];
        modeData.density_y = [];
        modeData.n_colonies = length(data);
        modeData.sufficient = false;
    end

  function density = computeDensitySurface(data, ~)
    % MODEL: Run KDE in log-radius space via computeLogKDE (TERMINAL)
    kdeResult = computeLogKDE(data);
    density = struct();
    density.x = kdeResult.eval_x_log;
    density.y = kdeResult.density;
    density.bandwidth = kdeResult.bandwidth;
end
    function [f, xi, bandwidth] = calculateKDE(data, options)
    % CALCULATEKDE Performs standardized KDE calculation
%   [f, xi, bandwidth] = calculateKDE(data, options)
%
%   Parameters:
%       data - Vector of data points for KDE estimation
%       options - Structure with optional parameters:
%           .evaluationPoints - Vector of points to evaluate KDE (default: auto)
%           .minBandwidth - Minimum bandwidth to use (default depends on data mode)
%           .useRawData - Boolean flag for raw data mode (default: false)
%
%   Returns:
%       f - Density values
%       xi - Evaluation points
%       bandwidth - Bandwidth used for calculation
% Default options
if nargin < 2 || isempty(options)
        options = struct();
end
% Handle empty or insufficient data
if isempty(data) || length(data) < 3
        f = [];
        xi = [];
        bandwidth = NaN;
return;
end
% Determine if using raw data mode (affects range and bandwidth defaults)
    useRawData = isfield(options, 'useRawData') && options.useRawData;
% Set evaluation range based on mode
if isfield(options, 'evaluationPoints')
        xi = options.evaluationPoints;
else
if useRawData
            xi = linspace(0, max(data) * 1.1, 100);
else
            xi = linspace(0, 2, 100);
end
end
% Calculate bandwidth using Freedman-Diaconis rule
    bandwidth = 2 * iqr(data) / nthroot(length(data), 3);
% Apply minimum bandwidth based on mode
if isfield(options, 'minBandwidth')
        minBandwidth = options.minBandwidth;
else
if useRawData
            minBandwidth = 25; % For raw data (colony sizes in µm)
else
            minBandwidth = 0.05; % For normalized data
end
end
    bandwidth = max(bandwidth, minBandwidth);
% Calculate KDE
    [f, xi] = ksdensity(data, xi, 'Bandwidth', bandwidth);
end

    function peaks = findDensityPeaks(density, promFraction)
        % MODEL: Find local maxima above prominence threshold (TERMINAL)
        peaks = struct();
        peaks.locations = [];
        peaks.heights = [];
        peaks.prominences = [];
        peaks.threshold = NaN;

        if isempty(density.y) || all(density.y == 0)
            return;
        end

        peaks.threshold = promFraction * max(density.y);

        [pks, locs, ~, prom] = findpeaks(density.y, density.x, ...
            'MinPeakProminence', peaks.threshold);

        peaks.locations = locs(:)';
        peaks.heights = pks(:)';
        peaks.prominences = prom(:)';
    end

    function modeData = packModeResult(density, peaks, n)
        % MODEL: Assemble mode_detection result struct (TERMINAL)
        modeData = struct();
        modeData.n_modes = length(peaks.locations);
        modeData.peak_locations = peaks.locations;
        modeData.peak_heights = peaks.heights;
        modeData.peak_prominences = peaks.prominences;
        modeData.bandwidth_used = density.bandwidth;
        modeData.prominence_threshold = peaks.threshold;
        modeData.density_x = density.x;
        modeData.density_y = density.y;
        modeData.n_colonies = n;
        modeData.sufficient = true;
    end
end
function result = tryNormalDistribution(data)
    % MODEL: Fit normal distribution (TERMINAL)
    result = struct('final_mean', NaN, 'final_sigma', NaN, ...
        'confidence_interval', [NaN, NaN], 'aic_score', Inf, 'bic_score', Inf, ...
        'ks_test_pvalue', NaN, 'log_likelihood', NaN);
    if length(data) < 3, return; end
    try
        mu_hat = mean(data); sigma_hat = std(data, 1);
        if sigma_hat <= 0, return; end
        n = length(data);
        se_mean = sigma_hat / sqrt(n);
        t_crit = tinv(1 - 0.025, n - 1);
        ci = [mu_hat - t_crit * se_mean, mu_hat + t_crit * se_mean];
        log_likelihood = sum(log(normpdf(data, mu_hat, sigma_hat)));
        k_params = 2;
        aic_score = 2 * k_params - 2 * log_likelihood;
        bic_score = k_params * log(n) - 2 * log_likelihood;
        [~, ks_pvalue] = kstest((data - mu_hat) / sigma_hat);
        result.final_mean = mu_hat; result.final_sigma = sigma_hat;
        result.confidence_interval = ci;
        result.aic_score = aic_score; result.bic_score = bic_score;
        result.ks_test_pvalue = ks_pvalue; result.log_likelihood = log_likelihood;
    catch
    end
end

function result = tryLogNormalDistribution(data)
    % MODEL: Fit lognormal distribution (TERMINAL)
    result = struct('mu_parameter', NaN, 'sigma_parameter', NaN, ...
        'fitted_median', NaN, 'aic_score', Inf, 'bic_score', Inf, ...
        'ks_test_pvalue', NaN, 'log_likelihood', NaN);
    pos_data = data(data > 1e-6);
    if length(pos_data) < 3, return; end
    try
        params = mle(pos_data, 'distribution', 'LogNormal');
        mu_param = params(1); sigma_param = params(2);
        log_likelihood = sum(log(lognpdf(pos_data, mu_param, sigma_param)));
        n = length(pos_data); k_params = 2;
        aic_score = 2 * k_params - 2 * log_likelihood;
        bic_score = k_params * log(n) - 2 * log_likelihood;
        result.mu_parameter = mu_param; result.sigma_parameter = sigma_param;
        result.fitted_median = exp(mu_param);
        result.aic_score = aic_score; result.bic_score = bic_score;
        result.log_likelihood = log_likelihood;
    catch
    end
end

function result = tryLibraryDistribution(data, options)
    % CONTROLLER: Match component data against best library entry with adequacy test
    result = buildEmptyLibraryResult();
    [ok, reason] = validateLibraryFitInputs(data, options);
    if ~ok, result.failure_reason = reason; return; end

    logLiks = scoreAllLibraryEntries(data, options.library);
    bestInfo = pickBestLibraryEntry(logLiks, options.library);
    if ~bestInfo.success
        result.failure_reason = 'No valid library entry produced finite log-likelihood';
        return;
    end

    adequacy = runAdequacyTest(data, bestInfo, options.library);
    if ~adequacy.passed
        result = packLibraryAdequacyFailure(bestInfo, adequacy);
        return;
    end
    result = packLibrarySuccess(bestInfo, adequacy, length(data));

    function result = buildEmptyLibraryResult()
        % MODEL: Default failed library result (TERMINAL)
        result = struct('phi_parameter', NaN, 'eps_parameter', NaN, ...
            'phi_index', NaN, 'eps_index', NaN, 'entry_index', NaN, ...
            'aic_score', Inf, 'bic_score', Inf, 'ks_test_pvalue', NaN, ...
            'log_likelihood', NaN, 'fitting_successful', false, ...
            'failure_reason', '', 'adequacy_emd', NaN, ...
            'adequacy_cutoff', NaN, 'adequacy_passed', false);
    end

    function [ok, reason] = validateLibraryFitInputs(data, options)
        % MODEL: Check gates (TERMINAL)
        if length(data) < 10
            ok = false; reason = sprintf('Insufficient data: n=%d', length(data)); return;
        end
        if ~isfield(options, 'library') || isempty(options.library)
            ok = false; reason = 'Library not provided'; return;
        end
        lib = options.library;
        if ~isfield(lib, 'entries') || isempty(lib.entries)
            ok = false; reason = 'Library has no entries'; return;
        end
        if ~isfield(lib, 'x_grid') || isempty(lib.x_grid)
            ok = false; reason = 'Library missing x_grid'; return;
        end
        if ~isfield(lib, 'ceiling_radius') || lib.ceiling_radius <= 0
            ok = false; reason = 'Library missing valid ceiling_radius'; return;
        end
        if ~isfield(lib, 'config')
            ok = false; reason = 'Library missing config'; return;
        end
        ok = true; reason = '';
    end

    function logLiks = scoreAllLibraryEntries(data, library)
        % MODEL: Log-likelihood under each entry KDE (TERMINAL)
        n_entries = length(library.entries);
        logLiks = -inf(1, n_entries);
        x_grid = library.x_grid; ceiling = library.ceiling_radius;
        n = length(data);
        normalized = min(max(data(:) / ceiling, 0), 1);
        dx = x_grid(2) - x_grid(1);
        bin_indices = round((normalized - x_grid(1)) / dx) + 1;
        bin_indices = max(1, min(length(x_grid), bin_indices));
        log_ceiling = log(ceiling);
        for i = 1:n_entries
            if ~library.entries(i).valid, continue; end
            kde_y = library.entries(i).kde_y;
            densities = max(kde_y(bin_indices), 1e-300);
            logLiks(i) = sum(log(densities)) - n * log_ceiling;
        end
    end

    function bestInfo = pickBestLibraryEntry(logLiks, library)
        % MODEL: Find max log-lik entry (TERMINAL)
        [best_logL, best_idx] = max(logLiks);
        bestInfo = struct();
        bestInfo.success = isfinite(best_logL);
        bestInfo.log_likelihood = best_logL;
        bestInfo.entry_index = best_idx;
        n_eps = length(library.config.eps_values);
        p_idx = floor((best_idx - 1) / n_eps) + 1;
        e_idx = mod(best_idx - 1, n_eps) + 1;
        bestInfo.phi_parameter = library.config.phi_values(p_idx);
        bestInfo.eps_parameter = library.config.eps_values(e_idx);
        bestInfo.phi_index = p_idx;
        bestInfo.eps_index = e_idx;
    end

    function adequacy = runAdequacyTest(data, bestInfo, library)
        % MODEL: EMD between data and best entry (TERMINAL)
        adequacy = struct();
        adequacy.emd = NaN; adequacy.cutoff = NaN; adequacy.passed = false;
        entry = library.entries(bestInfo.entry_index);
        x_grid = library.x_grid; ceiling = library.ceiling_radius;
        model_cdf = cumtrapz(x_grid, entry.kde_y);
        if model_cdf(end) > 0, model_cdf = model_cdf / model_cdf(end); end
        normalized = min(max(data(:) / ceiling, 0), 1);
        emp_cdf = sum(normalized <= x_grid, 1) / length(normalized);
        emd_normalized = trapz(x_grid, abs(emp_cdf - model_cdf(:)'));
        adequacy.emd = emd_normalized * ceiling;
        adequacy.cutoff = entry.null_p95;
        if isnan(adequacy.cutoff), adequacy.passed = false;
        else, adequacy.passed = adequacy.emd <= adequacy.cutoff; end
    end

    function result = packLibrarySuccess(bestInfo, adequacy, n)
        % MODEL: Pack winning entry (TERMINAL)
        k_params = 2; log_lik = bestInfo.log_likelihood;
        result = struct('phi_parameter', bestInfo.phi_parameter, ...
            'eps_parameter', bestInfo.eps_parameter, ...
            'phi_index', bestInfo.phi_index, 'eps_index', bestInfo.eps_index, ...
            'entry_index', bestInfo.entry_index, ...
            'aic_score', 2 * k_params - 2 * log_lik, ...
            'bic_score', k_params * log(n) - 2 * log_lik, ...
            'ks_test_pvalue', NaN, 'log_likelihood', log_lik, ...
            'fitting_successful', true, 'failure_reason', '', ...
            'adequacy_emd', adequacy.emd, 'adequacy_cutoff', adequacy.cutoff, ...
            'adequacy_passed', true);
    end

    function result = packLibraryAdequacyFailure(bestInfo, adequacy)
        % MODEL: Pack adequacy-failed result (TERMINAL)
        result = struct('phi_parameter', bestInfo.phi_parameter, ...
            'eps_parameter', bestInfo.eps_parameter, ...
            'phi_index', bestInfo.phi_index, 'eps_index', bestInfo.eps_index, ...
            'entry_index', bestInfo.entry_index, ...
            'aic_score', Inf, 'bic_score', Inf, ...
            'ks_test_pvalue', NaN, 'log_likelihood', bestInfo.log_likelihood, ...
            'fitting_successful', false, ...
            'failure_reason', sprintf('EMD=%.1fum exceeds null p95=%.1fum at (phi=%.2f, eps=%.2f)', ...
                adequacy.emd, adequacy.cutoff, bestInfo.phi_parameter, bestInfo.eps_parameter), ...
            'adequacy_emd', adequacy.emd, 'adequacy_cutoff', adequacy.cutoff, ...
            'adequacy_passed', false);
    end
end

function result = tryNonParametricDistribution(data)
    % MODEL: KDE-based non-parametric fit (TERMINAL)
    result = struct('bandwidth', NaN, 'kernel_points', [], 'density_values', [], ...
        'peak_estimate', NaN, 'effective_sample_size', length(data));
    if length(data) < 20
        if ~isempty(data), result.peak_estimate = mean(data); end
        return;
    end
    try
        [density_values, kernel_points, bandwidth] = ksdensity(data);
        [~, max_idx] = max(density_values);
        result.bandwidth = bandwidth;
        result.kernel_points = kernel_points;
        result.density_values = density_values;
        result.peak_estimate = kernel_points(max_idx);
    catch
        result.peak_estimate = mean(data);
    end
end


%% Visualization
function Part2CompleteData = populateCompositeFromResults(results, OutputFiles, outputName, rounds)
    % CONTROLLER: Populate composite struct from analysis results, save to disk
    %
    % Replacement for runVisualization when running a CompositeData
    % scenario. Walks each composite entry, extracts every available
    % output from the matching results cell, and writes it back into
    % the entry. Bundles the populated composite with run metadata
    % into a single wrapping struct named Part2CompleteData and saves.
    %
    % Inputs:
    %   results     : analysis results struct from runModel
    %   OutputFiles : round-specific output folder (already includes /<rounds>)
    %   outputName  : base name for the output file (e.g. 'CompositeData')
    %   rounds      : library version tag (e.g. 'V40', 'V80'), appended to
    %                 the output filename and recorded in run_meta.
    %
    % Output structure:
    %   Part2CompleteData.composite : 1xN populated entries
    %   Part2CompleteData.run_meta  : analysis options, library config,
    %                                 timestamp, rounds tag, field schema
    %
    % Saved to [OutputFiles, '/', outputName, '_dataset_', rounds, '.mat']
    % under the variable Part2CompleteData.
    %
    % External dependencies: computeLogKDE (base-level shared function).

    validateScenarioCarriesComposite(results);
    composite = results.scenario.composite_source;
    composite = populateAllEntries(composite, results);
    run_meta = buildRunMeta(results, rounds);
    Part2CompleteData = struct('composite', composite, 'run_meta', run_meta);
    saveDatasetToFile(Part2CompleteData, OutputFiles, outputName, rounds);
    printPopulationSummary(composite);

    function validateScenarioCarriesComposite(results)
        % MODEL: Hard-error if scenario lacks composite_source (TERMINAL)
        if ~isfield(results, 'scenario') || ...
                ~isfield(results.scenario, 'composite_source')
            error('populateCompositeFromResults:MissingCompositeSource', ...
                ['results.scenario.composite_source not found. ' ...
                 'This function requires a scenario built by ' ...
                 'buildCompositeDataScenario.']);
        end
    end

    function composite = populateAllEntries(composite, results)
        % SUB-CONTROLLER: Pre-allocate new fields, walk every entry
        composite = ensureNewFieldsExist(composite);
        n = length(composite);
        for i = 1:n
            composite(i) = populateOneEntry(composite(i), results, i);
        end

        function composite = ensureNewFieldsExist(composite)
            % MODEL: Pre-add new substruct fields to all entries (TERMINAL)
            new_struct_fields = {'library_fit', 'fit_comparison', ...
                                 'kde', 'mode_detection', 'summary_stats', ...
                                 'full_colony_set'};
            for fi = 1:length(new_struct_fields)
                field = new_struct_fields{fi};
                if ~isfield(composite, field)
                    [composite.(field)] = deal(struct());
                end
            end
            scalar_fields = {'phi', 'epsilon', 'q'};
            for fi = 1:length(scalar_fields)
                field = scalar_fields{fi};
                if ~isfield(composite, field)
                    [composite.(field)] = deal(NaN);
                end
            end
            if ~isfield(composite, 'colony_count')
                [composite.colony_count] = deal(0);
            end
            if ~isfield(composite, 'modes')
                [composite.modes] = deal(repmat(struct(), 1, 0));
            end
        end

        function entry = populateOneEntry(entry, results, idx)
            % SUB-CONTROLLER: Populate one composite entry
            colonySet = lookupColonySet(results, idx);
            entry = writeTopLineSummary(entry, colonySet);
            entry.modes = buildModesArray(colonySet);
            entry.library_fit = buildLibraryFit(colonySet);
            entry.fit_comparison = buildFitComparison(colonySet);
            entry.kde = buildKDE(entry);
            entry.mode_detection = buildModeDetection(colonySet);
            entry.summary_stats = buildSummaryStats(entry);
            entry.full_colony_set = buildFullColonySet(colonySet);

            function colonySet = lookupColonySet(results, idx)
                % MODEL: Retrieve colonySet for one composite index (TERMINAL)
                nom_field = sprintf('entry_%03d', idx);
                colonySet = results.analysisResults ...
                    .SubpopulationAnalysis(1).(nom_field).ColonySet;
            end

            function entry = writeTopLineSummary(entry, colonySet)
                % MODEL: Write top-line phi/epsilon/q/colony_count (TERMINAL)
                entry.phi = NaN;
                entry.epsilon = NaN;
                entry.q = NaN;
                if isfield(colonySet, 'gmm_results') && ...
                        isfield(colonySet.gmm_results, 'fitted_model')
                    fm = colonySet.gmm_results.fitted_model;
                    if isfield(fm, 'library_blobs') && ~isempty(fm.library_blobs)
                        blobs = fm.library_blobs;
                        if isfield(blobs, 'centroids_phi') && ~isempty(blobs.centroids_phi) && ...
                                isfield(blobs, 'centroids_eps') && ~isempty(blobs.centroids_eps)
                            if isfield(blobs, 'total_weights') && ~isempty(blobs.total_weights)
                                [~, dom] = max(blobs.total_weights);
                            else
                                dom = 1;
                            end
                            if dom <= length(blobs.centroids_phi) && dom <= length(blobs.centroids_eps)
                                entry.phi = blobs.centroids_phi(dom);
                                entry.epsilon = blobs.centroids_eps(dom);
                            end
                        end
                    end
                    if isfield(fm, 'library_quality_shape')
                        entry.q = fm.library_quality_shape;
                    end
                end
                if isfield(entry, 'Measurements') && ...
                        isstruct(entry.Measurements) && ...
                        isfield(entry.Measurements, 'Radius')
                    entry.colony_count = length(entry.Measurements.Radius);
                else
                    entry.colony_count = 0;
                end
            end

            function modes = buildModesArray(colonySet)
                % MODEL: Build per-component modes struct array (TERMINAL)
                template = struct( ...
                    'barcode', '', 'weight', NaN, ...
                    'mu', NaN, 'sigma', NaN, ...
                    'best_distribution', '', 'delta_aic', NaN, ...
                    'next_best_distribution', '', ...
                    'normal_fit', struct(), 'lognormal_fit', struct(), ...
                    'fitted_params', struct(), 'stats', struct());

                k = 0;
                if isfield(colonySet, 'subpopulation_count')
                    k = colonySet.subpopulation_count;
                end
                if k <= 0
                    modes = repmat(template, 1, 0);
                    return;
                end
                modes = repmat(template, 1, k);

                has_components = isfield(colonySet, 'gmm_results') && ...
                    isfield(colonySet.gmm_results, 'components');
                has_fitted_arrays = has_components && ...
                    isfield(colonySet.gmm_results, 'fitted_model') && ...
                    isfield(colonySet.gmm_results.fitted_model, 'gmm_mu');
                has_subpops = isfield(colonySet, 'subpopulations');

                radii = [];
                assignments = [];
                if isfield(colonySet, 'raw_measurements')
                    radii = colonySet.raw_measurements;
                end
                if has_components && ...
                        isfield(colonySet.gmm_results, 'component_assignments') && ...
                        isfield(colonySet.gmm_results.component_assignments, 'hard_assignments')
                    assignments = colonySet.gmm_results.component_assignments.hard_assignments;
                end

                for c = 1:k
                    if has_components && length(colonySet.gmm_results.components) >= c
                        comp = colonySet.gmm_results.components(c);
                        if isfield(comp, 'barcode')
                            modes(c).barcode = char(comp.barcode);
                        end
                        if isfield(comp, 'weight')
                            modes(c).weight = comp.weight;
                        end
                    end
                    if has_fitted_arrays
                        fm = colonySet.gmm_results.fitted_model;
                        if length(fm.gmm_mu) >= c
                            modes(c).mu = fm.gmm_mu(c);
                        end
                        if isfield(fm, 'gmm_sigma') && length(fm.gmm_sigma) >= c
                            modes(c).sigma = fm.gmm_sigma(c);
                        end
                    end
                    if has_subpops && length(colonySet.subpopulations) >= c
                        sp = colonySet.subpopulations(c);
                        if isfield(sp, 'best_distribution')
                            modes(c).best_distribution = char(sp.best_distribution);
                        end
                        if isfield(sp, 'delta_aic')
                            modes(c).delta_aic = sp.delta_aic;
                        end
                        if isfield(sp, 'next_best_distribution')
                            modes(c).next_best_distribution = char(sp.next_best_distribution);
                        end
                        if isfield(sp, 'fitted_params')
                            modes(c).fitted_params = sp.fitted_params;
                        end
                        if isfield(sp, 'distribution_tests')
                            if isfield(sp.distribution_tests, 'normal')
                                modes(c).normal_fit = sp.distribution_tests.normal;
                            end
                            if isfield(sp.distribution_tests, 'lognormal')
                                modes(c).lognormal_fit = sp.distribution_tests.lognormal;
                            end
                        end
                    end
                    if ~isempty(assignments) && length(assignments) == length(radii)
                        mask = (assignments == c);
                        comp_radii = radii(mask);
                        modes(c).stats = computeDescriptiveStats(comp_radii);
                    else
                        modes(c).stats = computeDescriptiveStats([]);
                    end
                end
            end

            function lib = buildLibraryFit(colonySet)
                % MODEL: Build library_fit substruct (TERMINAL)
                lib = struct( ...
                    'adequacy_emd', NaN, 'adequacy_cutoff', NaN, ...
                    'adequacy_passed', false, ...
                    'quality_shape', NaN, 'quality_scale', NaN, ...
                    'centroids_phi', [], 'centroids_eps', [], ...
                    'blob_weights', [], 'n_blobs', 0);
                if ~isfield(colonySet, 'gmm_results'), return; end
                if ~isfield(colonySet.gmm_results, 'fitted_model'), return; end
                fm = colonySet.gmm_results.fitted_model;
                if isfield(fm, 'library_adequacy_emd')
                    lib.adequacy_emd = fm.library_adequacy_emd;
                end
                if isfield(fm, 'library_adequacy_cutoff')
                    lib.adequacy_cutoff = fm.library_adequacy_cutoff;
                end
                if isfield(fm, 'library_adequacy_passed')
                    lib.adequacy_passed = fm.library_adequacy_passed;
                end
                if isfield(fm, 'library_quality_shape')
                    lib.quality_shape = fm.library_quality_shape;
                end
                if isfield(fm, 'library_quality_scale')
                    lib.quality_scale = fm.library_quality_scale;
                end
                if isfield(fm, 'library_blobs') && ~isempty(fm.library_blobs)
                    blobs = fm.library_blobs;
                    if isfield(blobs, 'centroids_phi')
                        lib.centroids_phi = blobs.centroids_phi;
                    end
                    if isfield(blobs, 'centroids_eps')
                        lib.centroids_eps = blobs.centroids_eps;
                    end
                    if isfield(blobs, 'total_weights')
                        lib.blob_weights = blobs.total_weights;
                    end
                    lib.n_blobs = length(lib.centroids_phi);
                end
            end

            function comp = buildFitComparison(colonySet)
                % MODEL: Build fit_comparison substruct (TERMINAL)
                comp = struct( ...
                    'winner', '', 'winner_aic', NaN, ...
                    'alternative_aics', struct(), ...
                    'dominant_barcode', '', 'total_weight_check', NaN);
                if isfield(colonySet, 'selected_method')
                    comp.winner = char(colonySet.selected_method);
                end
                if isfield(colonySet, 'gmm_results') && ...
                        isfield(colonySet.gmm_results, 'fitted_model') && ...
                        isfield(colonySet.gmm_results.fitted_model, 'final_aic')
                    comp.winner_aic = colonySet.gmm_results.fitted_model.final_aic;
                end
                if isfield(colonySet, 'alternative_fits') && ...
                        isstruct(colonySet.alternative_fits)
                    altNames = fieldnames(colonySet.alternative_fits);
                    for ai = 1:length(altNames)
                        alt = colonySet.alternative_fits.(altNames{ai});
                        if isfield(alt, 'aic')
                            comp.alternative_aics.(altNames{ai}) = alt.aic;
                        end
                    end
                end
                if isfield(colonySet, 'dominant_subpopulation_barcode')
                    comp.dominant_barcode = char(colonySet.dominant_subpopulation_barcode);
                end
                if isfield(colonySet, 'total_weight_check')
                    comp.total_weight_check = colonySet.total_weight_check;
                end
            end

            function kde = buildKDE(entry)
                % MODEL: Compute and store KDE outputs via computeLogKDE (TERMINAL)
                kde = struct( ...
                    'bandwidth', NaN, 'eval_x_log', [], 'density', [], ...
                    'mean_r', NaN, 'std_r', NaN, 'cv', NaN);
                if ~isfield(entry, 'Measurements'), return; end
                if ~isstruct(entry.Measurements), return; end
                if ~isfield(entry.Measurements, 'Radius'), return; end
                radii = entry.Measurements.Radius(:);
                radii = radii(isfinite(radii) & radii > 0);
                if length(radii) < 2, return; end
                kdeData = computeLogKDE(radii);
                if isfield(kdeData, 'bandwidth'),  kde.bandwidth  = kdeData.bandwidth;  end
                if isfield(kdeData, 'eval_x_log'), kde.eval_x_log = kdeData.eval_x_log; end
                if isfield(kdeData, 'density'),    kde.density    = kdeData.density;    end
                if isfield(kdeData, 'mean_r'),     kde.mean_r     = kdeData.mean_r;     end
                if isfield(kdeData, 'std_r'),      kde.std_r      = kdeData.std_r;      end
                if isfield(kdeData, 'cv'),         kde.cv         = kdeData.cv;         end
            end

            function md = buildModeDetection(colonySet)
                % MODEL: Copy mode_detection if engine populated it (TERMINAL)
                md = struct( ...
                    'n_modes', NaN, 'peak_locations', [], ...
                    'bandwidth_used', NaN, 'space', '');
                if ~isfield(colonySet, 'mode_detection'), return; end
                src = colonySet.mode_detection;
                if ~isstruct(src), return; end
                if isfield(src, 'n_modes')
                    md.n_modes = src.n_modes;
                end
                if isfield(src, 'peak_locations')
                    md.peak_locations = src.peak_locations;
                end
                if isfield(src, 'bandwidth_used')
                    md.bandwidth_used = src.bandwidth_used;
                end
                if isfield(src, 'space')
                    md.space = char(src.space);
                end
            end

            function ss = buildSummaryStats(entry)
                % MODEL: Compute whole-set descriptive stats on radii (TERMINAL)
                ss = struct( ...
                    'n', 0, 'mean', NaN, 'median', NaN, 'mode', NaN, ...
                    'std', NaN, 'var', NaN, 'cv', NaN, 'sem', NaN, ...
                    'skew', NaN, 'kurtosis', NaN, ...
                    'min', NaN, 'max', NaN, 'range', NaN, 'iqr', NaN, ...
                    'q1', NaN, 'q3', NaN, 'p05', NaN, 'p95', NaN, ...
                    'geo_mean', NaN, 'geo_std', NaN, 'bimodality_coef', NaN);
                if ~isfield(entry, 'Measurements'), return; end
                if ~isstruct(entry.Measurements), return; end
                if ~isfield(entry.Measurements, 'Radius'), return; end
                r = entry.Measurements.Radius(:);
                r = r(isfinite(r));
                ss.n = length(r);
                if ss.n == 0, return; end
                ss.mean = mean(r);
                ss.median = median(r);
                ss.std = std(r);
                ss.var = var(r);
                if ss.mean ~= 0
                    ss.cv = ss.std / ss.mean;
                end
                ss.sem = ss.std / sqrt(ss.n);
                ss.min = min(r);
                ss.max = max(r);
                ss.range = ss.max - ss.min;
                ss.iqr = iqr(r);
                ss.q1 = quantile(r, 0.25);
                ss.q3 = quantile(r, 0.75);
                ss.p05 = quantile(r, 0.05);
                ss.p95 = quantile(r, 0.95);
                if ss.n >= 3
                    ss.skew = skewness(r);
                    ss.kurtosis = kurtosis(r);
                end
                pos_r = r(r > 0);
                if ~isempty(pos_r)
                    log_r = log(pos_r);
                    ss.geo_mean = exp(mean(log_r));
                    ss.geo_std = exp(std(log_r));
                end
                if length(pos_r) >= 2
                    kdeData = computeLogKDE(pos_r);
                    if isstruct(kdeData) && isfield(kdeData, 'density') && ...
                            ~isempty(kdeData.density) && ...
                            isfield(kdeData, 'eval_x_log') && ...
                            ~isempty(kdeData.eval_x_log)
                        [~, peak_idx] = max(kdeData.density);
                        ss.mode = exp(kdeData.eval_x_log(peak_idx));
                    end
                end
                if ss.n >= 4 && isfinite(ss.skew) && isfinite(ss.kurtosis)
                    g = ss.skew;
                    kappa = ss.kurtosis;
                    n = ss.n;
                    correction = 3 * (n - 1)^2 / ((n - 2) * (n - 3));
                    ss.bimodality_coef = (g^2 + 1) / (kappa + correction);
                end
            end

            function fullSet = buildFullColonySet(colonySet)
                % MODEL: Pass the full colonySet through to the composite entry
                % verbatim, with no field selection or filtering. Returns an
                % empty struct if colonySet is missing or not a struct, so
                % downstream code can rely on the field always existing. (TERMINAL)
                if ~isstruct(colonySet) || isempty(colonySet)
                    fullSet = struct();
                    return;
                end
                fullSet = colonySet;
            end

            function stats = computeDescriptiveStats(data)
                % MODEL: Per-component descriptive stats (TERMINAL)
                stats = struct( ...
                    'n_assigned', 0, 'mean', NaN, 'median', NaN, ...
                    'std', NaN, 'skew', NaN, 'kurtosis', NaN, ...
                    'iqr', NaN, 'min', NaN, 'max', NaN, ...
                    'q1', NaN, 'q3', NaN);
                d = data(:);
                d = d(isfinite(d));
                stats.n_assigned = length(d);
                if stats.n_assigned == 0, return; end
                stats.mean = mean(d);
                stats.median = median(d);
                stats.std = std(d);
                stats.min = min(d);
                stats.max = max(d);
                stats.iqr = iqr(d);
                stats.q1 = quantile(d, 0.25);
                stats.q3 = quantile(d, 0.75);
                if stats.n_assigned >= 3
                    stats.skew = skewness(d);
                    stats.kurtosis = kurtosis(d);
                end
            end
        end
    end

    function meta = buildRunMeta(results, rounds)
        % SUB-CONTROLLER: Build run_meta struct
        meta = struct();
        meta.scenario_name = '';
        if isfield(results, 'scenario') && isfield(results.scenario, 'scenario_name')
            meta.scenario_name = char(results.scenario.scenario_name);
        end
        meta.rounds = rounds;
        meta.timestamp = char(datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss'));
        meta.analysis_options = extractAnalysisOptions(results);
        meta.library_config = extractLibraryConfig(results);
        meta.field_schema = buildFieldSchema();

        function opts = extractAnalysisOptions(results)
            % MODEL: Pull analysis_options minus library reference (TERMINAL)
            opts = struct();
            if isfield(results, 'scenario') && ...
                    isfield(results.scenario, 'analysis_options')
                opts = results.scenario.analysis_options;
                if isfield(opts, 'library')
                    opts = rmfield(opts, 'library');
                end
            end
        end

        function cfg = extractLibraryConfig(results)
            % MODEL: Pull library.config from scenario (TERMINAL)
            cfg = struct();
            if isfield(results, 'scenario') && ...
                    isfield(results.scenario, 'analysis_options') && ...
                    isfield(results.scenario.analysis_options, 'library')
                lib = results.scenario.analysis_options.library;
                if isstruct(lib) && isfield(lib, 'config')
                    cfg = lib.config;
                end
            end
        end

        function schema = buildFieldSchema()
            % MODEL: Build field schema documentation (TERMINAL)
            schema = struct();
            schema.composite_fields = { ...
                'phi',              'Dominant library mode phi (per-round division success probability)'; ...
                'epsilon',          'Dominant library mode epsilon (untracked variation)'; ...
                'q',                'Library quality_shape score'; ...
                'colony_count',     'Number of input radii measurements'; ...
                'modes',            'Per-component struct array (mixture model output)'; ...
                'library_fit',      'Library blob fit detail and adequacy'; ...
                'fit_comparison',   'Method selection (Library/LMM/GMM) and AIC scores'; ...
                'kde',              'Log-space KDE outputs'; ...
                'mode_detection',   'KDE-based mode count (NaN if engine did not populate)'; ...
                'summary_stats',    'Descriptive statistics on raw radii'; ...
                'full_colony_set',  'Complete colonySet from analysis engine, passed through verbatim. Contains raw_measurements, gmm_results (winning method full output), subpopulations, alternative_fits (full output of every losing method including LogNormal mixture parameters), selected_method, and mode_detection. No filtering applied.'};
            schema.modes_fields = { ...
                'barcode',                'Component identifier string'; ...
                'weight',                 'GMM mixing weight'; ...
                'mu',                     'GMM component mean (in normalization space)'; ...
                'sigma',                  'GMM component standard deviation'; ...
                'best_distribution',      'Selected distribution: Normal, LogNormal, Library, NonParametric'; ...
                'delta_aic',              'AIC gap between best and next-best distribution fit'; ...
                'next_best_distribution', 'Runner-up distribution name'; ...
                'normal_fit',             'Full Normal distribution fit results'; ...
                'lognormal_fit',          'Full LogNormal distribution fit results'; ...
                'fitted_params',          'Parameters of winning distribution'; ...
                'stats',                  'Descriptive stats on hard-assigned radii'};
            schema.library_fit_fields = { ...
                'adequacy_emd',    'EMD distance to closest library entry'; ...
                'adequacy_cutoff', 'EMD threshold for adequacy pass'; ...
                'adequacy_passed', 'Logical: did library fit pass adequacy gate'; ...
                'quality_shape',   'Library shape quality score'; ...
                'quality_scale',   'Library scale quality score'; ...
                'centroids_phi',   'All blob phi centroids'; ...
                'centroids_eps',   'All blob epsilon centroids'; ...
                'blob_weights',    'Per-blob total weights'; ...
                'n_blobs',         'Number of library blobs'};
            schema.fit_comparison_fields = { ...
                'winner',             'Selected method: Library, LogNormal, or Gaussian'; ...
                'winner_aic',         'AIC of winning method'; ...
                'alternative_aics',   'Struct of losing-method AIC scores'; ...
                'dominant_barcode',   'Barcode of highest-weight component'; ...
                'total_weight_check', 'Sum of component weights (should be ~1)'};
            schema.kde_fields = { ...
                'bandwidth',  'Shrunk Silverman bandwidth used'; ...
                'eval_x_log', 'Evaluation grid in log-radius space'; ...
                'density',    'KDE density values on eval_x_log'; ...
                'mean_r',     'Arithmetic mean of radii'; ...
                'std_r',      'Standard deviation of radii'; ...
                'cv',         'Coefficient of variation (std/mean)'};
            schema.summary_stats_fields = { ...
                'n',               'Number of finite measurements'; ...
                'mean',            'Arithmetic mean'; ...
                'median',          'Median'; ...
                'mode',            'KDE peak location (in raw radius space)'; ...
                'std',             'Standard deviation'; ...
                'var',             'Variance'; ...
                'cv',              'Coefficient of variation'; ...
                'sem',             'Standard error of mean'; ...
                'skew',            'Skewness'; ...
                'kurtosis',        'Kurtosis'; ...
                'min',             'Minimum'; ...
                'max',             'Maximum'; ...
                'range',           'Max minus min'; ...
                'iqr',             'Interquartile range'; ...
                'q1',              '25th percentile'; ...
                'q3',              '75th percentile'; ...
                'p05',             '5th percentile'; ...
                'p95',             '95th percentile'; ...
                'geo_mean',        'Geometric mean'; ...
                'geo_std',         'Geometric standard deviation'; ...
                'bimodality_coef', 'Sarle bimodality coefficient (>0.555 suggests bimodal)'};
        end
    end

    function saveDatasetToFile(Part2CompleteData, OutputFiles, outputName, rounds)
        % VIEW: Save Part2CompleteData to disk with rounds suffix (TERMINAL)
        outPath = fullfile(OutputFiles, [outputName '_dataset_' rounds '.mat']);
        save(outPath, 'Part2CompleteData');
        fprintf('Part2CompleteData saved: %s\n', outPath);
    end

    function printPopulationSummary(composite)
        % VIEW: Print summary of populated entries (TERMINAL)
        n = length(composite);
        phi_vals = arrayfun(@(e) e.phi, composite);
        n_fit = sum(~isnan(phi_vals));
        fprintf('Populated %d/%d entries with library fits\n', n_fit, n);
    end
end
function runVisualization(results, OutputFigures, scenarioName)
    % CONTROLLER: Orchestrate interactive viewer and PDF export
    buildResultsViewer(results);
    exportResultsPDF(results, OutputFigures, scenarioName);
end
   function colonySet = lookupColonySet(renderState, ord_idx, nom_idx)
                % MODEL: Retrieve colonySet from results by grid indices (TERMINAL)
                nom_field = renderState.results.scenario.nominal_fields{nom_idx};
                colonySet = renderState.results.analysisResults ...
                    .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
            end

function label = sanitizeDisplayLabel(label)
    % MODEL: Replace underscores for display (TERMINAL)
    %   Gene allele underscores become hyphens (case-insensitive,
    %   preserving original casing); all others become spaces.

    gene_patterns = {'est1_1','est2_1','est3_1','est4_1', ...
                     'tlc1_Δ','dbf4_1','cdc13_2','rif1_Δ'};

    for i = 1:length(gene_patterns)
        parts = strsplit(gene_patterns{i}, '_');
        regex = ['(' parts{1} ')_(' parts{2} ')'];
        label = regexprep(label, regex, '$1-$2', 'ignorecase');
    end

    label = strrep(label, '_', ' ');
end
function buildResultsViewer(results)
    % CONTROLLER: Build the interactive results viewer

    state = initializeViewerState(results);
    [fig, handles] = createViewerLayout(state);
    state.handles = handles;
    setappdata(fig, 'ViewerState', state);
    renderCurrentView(fig);
    updateNavigationLabels(fig);

    % === SUB-CONTROLLERS ===

    function state = initializeViewerState(results)
        % SUB-CONTROLLER: Build initial state with precomputed global limits
        core = buildCoreState(results);
        globalLimits = computeGlobalLimits(results);  % now shared
        state = packViewerState(core, globalLimits);
        function core = buildCoreState(results)
    % MODEL: Build core navigation state (TERMINAL)
    core = struct();
    core.results = results;
    core.view_mode = 1;
    core.ord_offset = 1;
    core.nom_offset = 1;
    core.n_ord = length(results.scenario.ordinal_labels);
    core.n_nom = length(results.scenario.nominal_labels);
    core.max_rows = min(2, core.n_ord);
    core.max_cols = min(2, core.n_nom);
    core.view_names = {'Trajectory', 'Histogram', 'Mixture Model', 'Composition', 'KDE'};
    core.axis_mode = 'local';

    % Sanitize display labels
    for i = 1:core.n_ord
        core.results.scenario.ordinal_labels{i} = ...
            sanitizeDisplayLabel(results.scenario.ordinal_labels{i});
    end
    for i = 1:core.n_nom
        core.results.scenario.nominal_labels{i} = ...
            sanitizeDisplayLabel(results.scenario.nominal_labels{i});
    end
end
        function state = packViewerState(core, globalLimits)
            % MODEL: Combine core state and global limits (TERMINAL)
            state = core;
            state.global_limits = globalLimits;
        end
    end

    function [fig, handles] = createViewerLayout(state)
        % SUB-CONTROLLER: Create figure, axes grid, navigation controls
        fig = createFigureWindow(state);
        handles = struct();
        handles.axes = createAxesGrid(fig);
        handles = createNavigationControls(fig, handles);
        handles = createGridLabels(fig, handles);

        function fig = createFigureWindow(state)
            % VIEW: Create figure window (TERMINAL)
            fig = figure('Name', sprintf('Results Viewer: %s', ...
                state.results.scenario.scenario_name), ...
                'Position', [50, 50, 1400, 800], 'Color', 'w', 'NumberTitle', 'off');
        end

        function ax_grid = createAxesGrid(fig)
            % VIEW: Create 2x2 axes grid (TERMINAL)
            ax_grid = cell(2, 2);
            positions = {[0.10, 0.48, 0.38, 0.33], [0.56, 0.48, 0.38, 0.33], ...
                         [0.10, 0.08, 0.38, 0.33], [0.56, 0.08, 0.38, 0.33]};
            idx = 0;
            for r = 1:2
                for c = 1:2
                    idx = idx + 1;
                    ax_grid{r, c} = axes(fig, 'Position', positions{idx}, ...
                        'Visible', 'off', 'Box', 'on');
                end
            end
        end

        function handles = createNavigationControls(fig, handles)
            % SUB-CONTROLLER: Create all navigation buttons
            handles = createViewModeControls(fig, handles);
            handles = createOrdinalControls(fig, handles);
            handles = createNominalControls(fig, handles);
            handles = createAxisToggle(fig, handles);

            function handles = createViewModeControls(fig, handles)
                % VIEW: View mode navigation (TERMINAL)
                y_pos = 755;
                uicontrol(fig, 'Style', 'text', 'String', 'View:', ...
                    'Position', [20, y_pos, 40, 25], 'FontSize', 10, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w', ...
                    'HorizontalAlignment', 'right');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9664), ...
                    'Position', [65, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'view_prev'));
                handles.view_label = uicontrol(fig, 'Style', 'text', 'String', '', ...
                    'Position', [100, y_pos, 160, 25], 'FontSize', 11, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9654), ...
                    'Position', [265, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'view_next'));
            end

            function handles = createOrdinalControls(fig, handles)
                % VIEW: Ordinal navigation (TERMINAL)
                y_pos = 755;
                uicontrol(fig, 'Style', 'text', 'String', 'Row:', ...
                    'Position', [340, y_pos, 35, 25], 'FontSize', 10, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w', ...
                    'HorizontalAlignment', 'right');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9664), ...
                    'Position', [380, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'ord_prev'));
                handles.ord_label = uicontrol(fig, 'Style', 'text', 'String', '', ...
                    'Position', [415, y_pos, 260, 25], 'FontSize', 10, 'BackgroundColor', 'w');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9654), ...
                    'Position', [680, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'ord_next'));
            end

            function handles = createNominalControls(fig, handles)
                % VIEW: Nominal navigation (TERMINAL)
                y_pos = 755;
                uicontrol(fig, 'Style', 'text', 'String', 'Col:', ...
                    'Position', [760, y_pos, 30, 25], 'FontSize', 10, ...
                    'FontWeight', 'bold', 'BackgroundColor', 'w', ...
                    'HorizontalAlignment', 'right');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9664), ...
                    'Position', [795, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'nom_prev'));
                handles.nom_label = uicontrol(fig, 'Style', 'text', 'String', '', ...
                    'Position', [830, y_pos, 260, 25], 'FontSize', 10, 'BackgroundColor', 'w');
                uicontrol(fig, 'Style', 'pushbutton', 'String', char(9654), ...
                    'Position', [1095, y_pos, 30, 25], 'FontSize', 12, ...
                    'Callback', @(~,~) handleNavigation(fig, 'nom_next'));
            end

            function handles = createAxisToggle(fig, handles)
                % VIEW: Axis mode toggle (TERMINAL)
                handles.axis_toggle = uicontrol(fig, 'Style', 'pushbutton', ...
                    'String', 'Axis: Local', 'Position', [1200, 755, 120, 25], ...
                    'FontSize', 10, 'FontWeight', 'bold', ...
                    'Callback', @(~,~) handleNavigation(fig, 'toggle_axis'));
            end
        end

        function handles = createGridLabels(fig, handles)
            % VIEW: Create row and column header annotations (TERMINAL)
            handles.col_headers = cell(1, 2);
            handles.row_headers = cell(1, 2);
            col_x = [0.10, 0.56];
            for c = 1:2
                handles.col_headers{c} = annotation(fig, 'textbox', ...
                    [col_x(c), 0.82, 0.38, 0.04], 'String', '', ...
                    'FontSize', 11, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', 'EdgeColor', 'none');
            end
            row_y_centers = [0.625, 0.225];
            for r = 1:2
                handles.row_headers{r} = annotation(fig, 'textbox', ...
                    [0.00, row_y_centers(r), 0.10, 0.04], 'String', '', ...
                    'FontSize', 10, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'EdgeColor', 'none');
            end
        end
    end

%   CONTROLLER 2: NAVIGATION
function handleNavigation(fig, action)
    % CONTROLLER: Process navigation, update state, re-render
    state = getappdata(fig, 'ViewerState');
    state = applyNavigationAction(state, action);
    setappdata(fig, 'ViewerState', state);
    renderCurrentView(fig);
    updateNavigationLabels(fig);

    function state = applyNavigationAction(state, action)
        % MODEL: Update state offsets (TERMINAL)
        switch action
            case 'view_prev'
                state.view_mode = max(1, state.view_mode - 1);
            case 'view_next'
                state.view_mode = min(length(state.view_names), state.view_mode + 1);
            case 'ord_prev'
                state.ord_offset = max(1, state.ord_offset - state.max_rows);
            case 'ord_next'
                max_offset = max(1, state.n_ord - state.max_rows + 1);
                state.ord_offset = min(max_offset, state.ord_offset + state.max_rows);
            case 'nom_prev'
                state.nom_offset = max(1, state.nom_offset - state.max_cols);
            case 'nom_next'
                max_offset = max(1, state.n_nom - state.max_cols + 1);
                state.nom_offset = min(max_offset, state.nom_offset + state.max_cols);
            case 'toggle_axis'
                if strcmp(state.axis_mode, 'local')
                    state.axis_mode = 'global';
                else
                    state.axis_mode = 'local';
                end
        end
    end
end

%   CONTROLLER 3: RENDER DISPATCH
function renderCurrentView(fig)
    % CONTROLLER: Clear all axes, render visible cells via shared renderers
    state = getappdata(fig, 'ViewerState');
    clearAllAxes(state);
    renderVisibleCells(state);

    function clearAllAxes(state)
        % VIEW: Clear and hide all axes (TERMINAL)
        for r = 1:2
            for c = 1:2
                ax = state.handles.axes{r, c};
                cla(ax); legend(ax, 'off'); title(ax, '');
                set(ax, 'Visible', 'off', ...
                    'XLimMode', 'auto', 'YLimMode', 'auto', ...
                    'XTickMode', 'auto', 'YTickMode', 'auto', ...
                    'XTickLabelMode', 'auto', 'YTickLabelMode', 'auto');
            end
        end
    end
    function renderVisibleCells(state)
    % SUB-CONTROLLER: Loop over visible cells, dispatch to shared renderers
    visible_rows = min(state.max_rows, state.n_ord - state.ord_offset + 1);
    visible_cols = min(state.max_cols, state.n_nom - state.nom_offset + 1);
    for r = 1:visible_rows
        for c = 1:visible_cols
            ord_idx = state.ord_offset + r - 1;
            nom_idx = state.nom_offset + c - 1;
            ax = state.handles.axes{r, c};
            switch state.view_mode
                case 1, renderTrajectoryCell(ax, state, ord_idx, nom_idx);
                case 2, renderHistogramCell(ax, state, ord_idx, nom_idx);
                case 3, renderMixtureCell(ax, state, ord_idx, nom_idx);
                case 4, renderCompositionCell(ax, state, ord_idx, nom_idx);
                case 5, renderKDECell(ax, state, ord_idx, nom_idx);
            end
        end
    end
end
end

%   CONTROLLER 4: NAVIGATION LABELS
function updateNavigationLabels(fig)
    % CONTROLLER: Refresh all navigation text and grid headers
    state = getappdata(fig, 'ViewerState');
    updateViewModeLabel(state);
    updateOrdinalLabel(state);
    updateNominalLabel(state);
    updateColumnHeaders(state);
    updateRowHeaders(state);
    updateAxisToggle(state);

    function updateViewModeLabel(state)
        % VIEW: Update view mode text (TERMINAL)
        set(state.handles.view_label, 'String', ...
            sprintf('%s  (%d/%d)', state.view_names{state.view_mode}, ...
                state.view_mode, length(state.view_names)));
    end

    function updateOrdinalLabel(state)
        % VIEW: Update ordinal range text (TERMINAL)
        visible_rows = min(state.max_rows, state.n_ord - state.ord_offset + 1);
        ord_end = state.ord_offset + visible_rows - 1;
        set(state.handles.ord_label, 'String', ...
            sprintf('%s .. %s  (%d-%d of %d)', ...
                state.results.scenario.ordinal_labels{state.ord_offset}, ...
                state.results.scenario.ordinal_labels{ord_end}, ...
                state.ord_offset, ord_end, state.n_ord));
    end

    function updateNominalLabel(state)
        % VIEW: Update nominal range text (TERMINAL)
        visible_cols = min(state.max_cols, state.n_nom - state.nom_offset + 1);
        nom_end = state.nom_offset + visible_cols - 1;
        set(state.handles.nom_label, 'String', ...
            sprintf('%s .. %s  (%d-%d of %d)', ...
                state.results.scenario.nominal_labels{state.nom_offset}, ...
                state.results.scenario.nominal_labels{nom_end}, ...
                state.nom_offset, nom_end, state.n_nom));
    end

    function updateColumnHeaders(state)
        % VIEW: Update column headers (TERMINAL)
        for c = 1:2
            nom_idx = state.nom_offset + c - 1;
            if nom_idx <= state.n_nom
                set(state.handles.col_headers{c}, 'String', ...
                    state.results.scenario.nominal_labels{nom_idx}, 'Visible', 'on');
            else
                set(state.handles.col_headers{c}, 'Visible', 'off');
            end
        end
    end

    function updateRowHeaders(state)
        % VIEW: Update row headers (TERMINAL)
        for r = 1:2
            ord_idx = state.ord_offset + r - 1;
            if ord_idx <= state.n_ord
                set(state.handles.row_headers{r}, 'String', ...
                    state.results.scenario.ordinal_labels{ord_idx}, 'Visible', 'on');
            else
                set(state.handles.row_headers{r}, 'Visible', 'off');
            end
        end
    end

    function updateAxisToggle(state)
        % VIEW: Update toggle button (TERMINAL)
        if strcmp(state.axis_mode, 'local')
            set(state.handles.axis_toggle, 'String', 'Axis: Local');
        else
            set(state.handles.axis_toggle, 'String', 'Axis: Global');
        end
    end
end

end
function exportResultsPDF(results, OutputFigures, scenarioName)
    % CONTROLLER: Export all views to a multi-page PDF with index table

    colonySets = flattenColonySets(results);
    renderState = buildPDFRenderState(results);
    pdfPath = fullfile(OutputFigures, [scenarioName '_results.pdf']);

    fig = createOffscreenFigure(scenarioName);

    % Pages 1+: Index table (paginated, max 20 rows per page)
    renderAndExportIndexPages(fig, colonySets, scenarioName, pdfPath);

    % Library fit table pages (appended only if any fits exist)
    renderAndExportLibraryTablePages(fig, colonySets, renderState, scenarioName, pdfPath);

    % Remaining pages: View modes (Trajectory, Histogram, Mixture, Composition)
    renderAndAppendViewPages(fig, renderState, colonySets, pdfPath);

    close(fig);
    fprintf('PDF saved: %s\n', pdfPath);

    % === SUB-CONTROLLERS ===

    function colonySets = flattenColonySets(results)
        % SUB-CONTROLLER: Build ordered colony set list with letter labels
        n_ord = length(results.scenario.ordinal_labels);
        n_nom = length(results.scenario.nominal_labels);
        n_sets = n_ord * n_nom;
        colonySets = repmat(struct('letter','','ord_idx',0,'nom_idx',0, ...
            'ord_label','','nom_label',''), 1, n_sets);
        idx = 0;
        for o = 1:n_ord
            for n = 1:n_nom
                idx = idx + 1;
                letter = generateLetterLabel(idx);
                colonySets(idx) = packEntry(letter, o, n, results);
            end
        end

        function label = generateLetterLabel(index)
            % MODEL: Convert 1-based index to spreadsheet-style letter (TERMINAL)
            label = '';
            while index > 0
                index = index - 1;
                label = [char('A' + mod(index, 26)), label];
                index = floor(index / 26);
            end
        end

        function entry = packEntry(letter, o, n, results)
    % MODEL: Pack one colony set entry (TERMINAL)
    entry = struct();
    entry.letter = letter;
    entry.ord_idx = o;
    entry.nom_idx = n;
    entry.ord_label = sanitizeDisplayLabel(results.scenario.ordinal_labels{o});
    entry.nom_label = sanitizeDisplayLabel(results.scenario.nominal_labels{n});
end
    end

    function renderState = buildPDFRenderState(results)
        % SUB-CONTROLLER: Build render state in global axis mode
        gl = computeGlobalLimits(results);
        renderState = packRenderState(results, gl);

        function rs = packRenderState(results, gl)
            % MODEL: Assemble render state struct (TERMINAL)
            rs = struct();
            rs.results = results;
            rs.axis_mode = 'global';
            rs.global_limits = gl;
        end
    end

    function fig = createOffscreenFigure(scenarioName)
        % VIEW: Create invisible figure for PDF rendering (TERMINAL)
        fig = figure('Visible', 'off', ...
            'Units', 'inches', 'Position', [0, 0, 11, 8.5], ...
            'PaperUnits', 'inches', 'PaperSize', [11, 8.5], ...
            'PaperPosition', [0, 0, 11, 8.5], ...
            'Color', 'w', 'NumberTitle', 'off', ...
            'Name', sprintf('PDF Export: %s', scenarioName));
    end

    function renderAndExportIndexPages(fig, colonySets, scenarioName, pdfPath)
        % SUB-CONTROLLER: Render paginated index table pages and export
        n_sets = length(colonySets);
        rows_per_page = 20;
        n_pages = ceil(n_sets / rows_per_page);

        for p = 1:n_pages
            startIdx = (p - 1) * rows_per_page + 1;
            endIdx = min(p * rows_per_page, n_sets);

            renderIndexTablePage(fig, colonySets(startIdx:endIdx), scenarioName, p, n_pages);

            if p == 1
                exportgraphics(fig, pdfPath, 'ContentType', 'vector');
            else
                exportgraphics(fig, pdfPath, 'ContentType', 'vector', 'Append', true);
            end
        end

        function renderIndexTablePage(fig, colonySubset, scenarioName, pageNum, totalPages)
            % SUB-CONTROLLER: Render one page of the index table
            clf(fig);
            tableData = buildTableData(colonySubset);
            drawIndexTable(fig, tableData, scenarioName, pageNum, totalPages);

            function tableData = buildTableData(colonySubset)
                % MODEL: Organize table content (TERMINAL)
                n = length(colonySubset);
                tableData = struct();
                tableData.headers = {'Index', 'Ordinal', 'Nominal'};
                tableData.n_rows = n;
                tableData.rows = cell(n, 3);
                for i = 1:n
                    tableData.rows{i, 1} = colonySubset(i).letter;
                    tableData.rows{i, 2} = colonySubset(i).ord_label;
                    tableData.rows{i, 3} = colonySubset(i).nom_label;
                end
            end

            function drawIndexTable(fig, tableData, scenarioName, pageNum, totalPages)
                % VIEW: Draw formatted index table with gridlines (TERMINAL)
                ax = axes(fig, 'Position', [0.15, 0.08, 0.70, 0.80]);
                hold(ax, 'on');
                set(ax, 'Visible', 'off');

                n_rows = tableData.n_rows;
                n_cols = 3;

                % Column layout (proportional widths within [0,1])
                col_widths = [0.12, 0.44, 0.44];
                col_x = [0, cumsum(col_widths)];

                font_data = 10;
                font_header = font_data + 1;

                total_rows = n_rows + 1;  % +1 for header
                row_h = 1 / total_rows;

                % --- Page title ---
                if totalPages > 1
                    titleStr = sprintf('Colony Set Index: %s  (page %d/%d)', ...
                        strrep(scenarioName, '_', ' '), pageNum, totalPages);
                else
                    titleStr = sprintf('Colony Set Index: %s', ...
                        strrep(scenarioName, '_', ' '));
                end
                text(ax, 0.5, 1.08, titleStr, ...
                    'FontSize', 14, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'bottom', 'Units', 'data');

                % --- Header row ---
                header_y_top = 1;
                header_y_mid = header_y_top - row_h / 2;
                for c = 1:n_cols
                    x_mid = (col_x(c) + col_x(c + 1)) / 2;
                    text(ax, x_mid, header_y_mid, tableData.headers{c}, ...
                        'FontSize', font_header, 'FontWeight', 'bold', ...
                        'HorizontalAlignment', 'center', ...
                        'VerticalAlignment', 'middle');
                end

                % Header background
                fill(ax, [0, 1, 1, 0], ...
                    [header_y_top, header_y_top, header_y_top - row_h, header_y_top - row_h], ...
                    [0.85, 0.85, 0.90], 'EdgeColor', 'none');

                % Header bottom border
                line(ax, [0, 1], [header_y_top - row_h, header_y_top - row_h], ...
                    'Color', 'k', 'LineWidth', 1.5);

                % --- Data rows ---
                for r = 1:n_rows
                    y_top = header_y_top - r * row_h;
                    y_mid = y_top - row_h / 2;

                    % Alternating row shading
                    if mod(r, 2) == 0
                        fill(ax, [0, 1, 1, 0], ...
                            [y_top, y_top, y_top - row_h, y_top - row_h], ...
                            [0.95, 0.95, 0.97], 'EdgeColor', 'none');
                    end

                    % Cell text
                    for c = 1:n_cols
                        x_mid = (col_x(c) + col_x(c + 1)) / 2;
                        text(ax, x_mid, y_mid, tableData.rows{r, c}, ...
                            'FontSize', font_data, ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle');
                    end
                end

                % --- Gridlines ---
                table_bottom = header_y_top - total_rows * row_h;

                % Vertical column dividers
                for c = 2:n_cols
                    line(ax, [col_x(c), col_x(c)], [header_y_top, table_bottom], ...
                        'Color', [0.7, 0.7, 0.7], 'LineWidth', 0.5);
                end

                % Outer border
                rectangle(ax, 'Position', [0, table_bottom, 1, header_y_top - table_bottom], ...
                    'EdgeColor', 'k', 'LineWidth', 1.2);

                % Top border (double weight)
                line(ax, [0, 1], [header_y_top, header_y_top], 'Color', 'k', 'LineWidth', 1.2);

                xlim(ax, [-0.05, 1.05]);
                ylim(ax, [table_bottom - 0.03, 1.12]);
                hold(ax, 'off');
            end
        end
    end

    function renderAndExportLibraryTablePages(fig, colonySets, renderState, scenarioName, pdfPath)
        % SUB-CONTROLLER: Render library fit table pages if any fits exist

        libraryRows = extractAllLibraryFits(colonySets, renderState);
        if ~libraryRows.anyFitsPresent
            return;
        end

        rows_per_page = 20;
        n_sets = length(colonySets);
        n_pages = ceil(n_sets / rows_per_page);

        for p = 1:n_pages
            startIdx = (p - 1) * rows_per_page + 1;
            endIdx = min(p * rows_per_page, n_sets);

            renderLibraryTablePage(fig, libraryRows, scenarioName, p, n_pages, startIdx, endIdx);
            exportgraphics(fig, pdfPath, 'ContentType', 'vector', 'Append', true);
        end

        function libraryRows = extractAllLibraryFits(colonySets, renderState)
            % SUB-CONTROLLER: Extract library fit data for all colony sets
            n = length(colonySets);
            fitData = repmat(struct('letter','','ord_label','','nom_label','', ...
                'hasFit',false,'phi',NaN,'eps',NaN,'q_shape',NaN), 1, n);
            anyFits = false;

            for i = 1:n
                cs = colonySets(i);
                colonySet = lookupColonySet(renderState, cs.ord_idx, cs.nom_idx);
                lib = extractLibraryAdequacy(colonySet);
                fitData(i) = packLibraryRow(cs, lib);
                if fitData(i).hasFit
                    anyFits = true;
                end
            end

            libraryRows = struct();
            libraryRows.fitData = fitData;
            libraryRows.anyFitsPresent = anyFits;

         
            function row = packLibraryRow(cs, lib)
                % MODEL: Pack one library table row (TERMINAL)
                row = struct();
                row.letter = cs.letter;
                row.ord_label = cs.ord_label;
                row.nom_label = cs.nom_label;
                row.hasFit = lib.present && ~isnan(lib.phi) && ~isnan(lib.eps);
                if row.hasFit
                    row.phi = lib.phi;
                    row.eps = lib.eps;
                    row.q_shape = lib.quality_shape;
                else
                    row.phi = NaN;
                    row.eps = NaN;
                    row.q_shape = NaN;
                end
            end
        end

        function renderLibraryTablePage(fig, libraryRows, scenarioName, pageNum, totalPages, startIdx, endIdx)
            % SUB-CONTROLLER: Render one page of the library fit table
            clf(fig);
            tableData = buildLibraryTableData(libraryRows.fitData(startIdx:endIdx));
            drawLibraryTable(fig, tableData, scenarioName, pageNum, totalPages);

            function tableData = buildLibraryTableData(fitSubset)
                % MODEL: Organize library table content (TERMINAL)
                n = length(fitSubset);
                tableData = struct();
                tableData.headers = {'Index', 'Ordinal', 'Nominal', ...
                    '\phi', '\epsilon', 'Q_{shape}'};
                tableData.n_rows = n;
                tableData.rows = cell(n, 6);
                for i = 1:n
                    tableData.rows{i, 1} = fitSubset(i).letter;
                    tableData.rows{i, 2} = fitSubset(i).ord_label;
                    tableData.rows{i, 3} = fitSubset(i).nom_label;
                    if fitSubset(i).hasFit
                        tableData.rows{i, 4} = sprintf('%.2f', fitSubset(i).phi);
                        tableData.rows{i, 5} = sprintf('%.2f', fitSubset(i).eps);
                        if ~isnan(fitSubset(i).q_shape)
                            tableData.rows{i, 6} = sprintf('%.2f', fitSubset(i).q_shape);
                        else
                            tableData.rows{i, 6} = '-';
                        end
                    else
                        tableData.rows{i, 4} = 'No Fit';
                        tableData.rows{i, 5} = 'No Fit';
                        tableData.rows{i, 6} = 'No Fit';
                    end
                end
            end

            function drawLibraryTable(fig, tableData, scenarioName, pageNum, totalPages)
                % VIEW: Draw formatted library fit table with gridlines (TERMINAL)
                ax = axes(fig, 'Position', [0.10, 0.08, 0.80, 0.80]);
                hold(ax, 'on');
                set(ax, 'Visible', 'off');

                n_rows = tableData.n_rows;
                n_cols = 6;

                % Column layout (proportional widths within [0,1])
                col_widths = [0.08, 0.26, 0.26, 0.12, 0.12, 0.16];
                col_x = [0, cumsum(col_widths)];

                font_data = 10;
                font_header = font_data + 1;

                total_rows = n_rows + 1;
                row_h = 1 / total_rows;

                % --- Page title ---
                if totalPages > 1
                    titleStr = sprintf('Library Fits: %s  (page %d/%d)', ...
                        strrep(scenarioName, '_', ' '), pageNum, totalPages);
                else
                    titleStr = sprintf('Library Fits: %s', ...
                        strrep(scenarioName, '_', ' '));
                end
                text(ax, 0.5, 1.08, titleStr, ...
                    'FontSize', 14, 'FontWeight', 'bold', ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'bottom', 'Units', 'data');

                % --- Header row ---
                header_y_top = 1;
                header_y_mid = header_y_top - row_h / 2;

                % Header background (drawn first so text renders on top)
                fill(ax, [0, 1, 1, 0], ...
                    [header_y_top, header_y_top, header_y_top - row_h, header_y_top - row_h], ...
                    [0.85, 0.85, 0.90], 'EdgeColor', 'none');

                % Header text
                for c = 1:n_cols
                    x_mid = (col_x(c) + col_x(c + 1)) / 2;
                    text(ax, x_mid, header_y_mid, tableData.headers{c}, ...
                        'FontSize', font_header, 'FontWeight', 'bold', ...
                        'HorizontalAlignment', 'center', ...
                        'VerticalAlignment', 'middle', ...
                        'Interpreter', 'tex');
                end

                % Header bottom border
                line(ax, [0, 1], [header_y_top - row_h, header_y_top - row_h], ...
                    'Color', 'k', 'LineWidth', 1.5);

                % --- Data rows ---
                for r = 1:n_rows
                    y_top = header_y_top - r * row_h;
                    y_mid = y_top - row_h / 2;

                    % Alternating row shading
                    if mod(r, 2) == 0
                        fill(ax, [0, 1, 1, 0], ...
                            [y_top, y_top, y_top - row_h, y_top - row_h], ...
                            [0.95, 0.95, 0.97], 'EdgeColor', 'none');
                    end

                    % Cell text
                    for c = 1:n_cols
                        x_mid = (col_x(c) + col_x(c + 1)) / 2;
                        text(ax, x_mid, y_mid, tableData.rows{r, c}, ...
                            'FontSize', font_data, ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle');
                    end
                end

                % --- Gridlines ---
                table_bottom = header_y_top - total_rows * row_h;

                % Vertical column dividers
                for c = 2:n_cols
                    line(ax, [col_x(c), col_x(c)], [header_y_top, table_bottom], ...
                        'Color', [0.7, 0.7, 0.7], 'LineWidth', 0.5);
                end

                % Outer border
                rectangle(ax, 'Position', [0, table_bottom, 1, header_y_top - table_bottom], ...
                    'EdgeColor', 'k', 'LineWidth', 1.2);

                % Top border (double weight)
                line(ax, [0, 1], [header_y_top, header_y_top], 'Color', 'k', 'LineWidth', 1.2);

                xlim(ax, [-0.05, 1.05]);
                ylim(ax, [table_bottom - 0.03, 1.12]);
                hold(ax, 'off');
            end
        end
    end
    function renderAndAppendViewPages(fig, renderState, colonySets, pdfPath)
    % SUB-CONTROLLER: Render all view mode pages and append to PDF
    viewNames = {'Trajectory', 'Histogram', 'Mixture Model', 'Composition', 'KDE'};
    renderers = {@renderTrajectoryCell, @renderHistogramCell, ...
                 @renderMixtureCell, @renderCompositionCell, @renderKDECell};

    n_sets = length(colonySets);
    n_per_page = 4;

    for v = 1:length(viewNames)
        n_pages = ceil(n_sets / n_per_page);
        for p = 1:n_pages
            startIdx = (p - 1) * n_per_page + 1;
            endIdx = min(p * n_per_page, n_sets);

            preparePage(fig, viewNames{v}, p, n_pages);
            populatePageCells(fig, renderState, colonySets, ...
                renderers{v}, viewNames{v}, startIdx, endIdx);

            exportgraphics(fig, pdfPath, 'ContentType', 'vector', 'Append', true);
        end
    end

    function preparePage(fig, viewName, pageNum, totalPages)
        % VIEW: Clear figure and add page title (TERMINAL)
        clf(fig);
        if totalPages > 1
            titleStr = sprintf('%s  (page %d/%d)', viewName, pageNum, totalPages);
        else
            titleStr = viewName;
        end
        annotation(fig, 'textbox', [0, 0.92, 1, 0.07], ...
            'String', titleStr, ...
            'FontSize', 16, 'FontWeight', 'bold', ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'middle', ...
            'EdgeColor', 'none', 'BackgroundColor', 'w');
    end

    function populatePageCells(fig, renderState, colonySets, renderer, viewName, startIdx, endIdx)
        % SUB-CONTROLLER: Create axes and render each cell on the page

        for i = startIdx:endIdx
            slotIdx = i - startIdx + 1;
            axPos = computeSubplotPosition(slotIdx);
            ax = createCellAxes(fig, axPos);

            cs = colonySets(i);
            renderer(ax, renderState, cs.ord_idx, cs.nom_idx);

            titleCellAxes(ax, cs);
            labelCellAxes(ax, cs.letter);

            if strcmp(viewName, 'Trajectory')
                annotateTrajectoryLibraryFit(ax, renderState, cs);
            end
        end

        function pos = computeSubplotPosition(slotIdx)
            % MODEL: Calculate axes position for 2x2 grid slot (TERMINAL)
            row = ceil(slotIdx / 2);
            col = mod(slotIdx - 1, 2) + 1;

            x_origins = [0.08, 0.54];
            y_origins = [0.52, 0.09];
            plot_w = 0.40;
            plot_h = 0.33;

            pos = [x_origins(col), y_origins(row), plot_w, plot_h];
        end

        function ax = createCellAxes(fig, pos)
            % VIEW: Create axes at specified position (TERMINAL)
            ax = axes(fig, 'Position', pos, 'Box', 'on');
        end

        function titleCellAxes(ax, cs)
            % VIEW: Set axes title to nominal and ordinal labels (TERMINAL)
            title(ax, sprintf('%s, %s', cs.nom_label, cs.ord_label), ...
                'FontSize', 10, 'FontWeight', 'normal');
        end

        function labelCellAxes(ax, letter)
            % VIEW: Add letter label just outside top-left of axes (TERMINAL)
            text(ax, -0.06, 1.04, letter, ...
                'Units', 'normalized', ...
                'HorizontalAlignment', 'right', ...
                'VerticalAlignment', 'bottom', ...
                'FontSize', 11, ...
                'FontWeight', 'bold', ...
                'Clipping', 'off');
        end

        function annotateTrajectoryLibraryFit(ax, renderState, cs)
            % SUB-CONTROLLER: Add library fit annotation beside trajectory axes
            libInfo = extractCellLibraryInfo(renderState, cs);
            if ~libInfo.present
                return;
            end
            drawLibraryAnnotation(ax, libInfo);

            function libInfo = extractCellLibraryInfo(renderState, cs)
                % MODEL: Extract library adequacy for one cell (TERMINAL)
                nom_field = renderState.results.scenario.nominal_fields{cs.nom_idx};
                colonySet = renderState.results.analysisResults ...
                    .SubpopulationAnalysis(cs.ord_idx).(nom_field).ColonySet;
                lib = extractLibraryAdequacy(colonySet);
                libInfo = struct();
                libInfo.present = lib.present && ~isnan(lib.phi) && ~isnan(lib.eps);
                if libInfo.present
                    libInfo.phi = lib.phi;
                    libInfo.eps = lib.eps;
                    libInfo.q_shape = lib.quality_shape;
                else
                    libInfo.phi = NaN;
                    libInfo.eps = NaN;
                    libInfo.q_shape = NaN;
                end
            end

            function drawLibraryAnnotation(ax, libInfo)
                % VIEW: Draw library fit annotation inside axes (TERMINAL)

                % Title line
                text(ax, 0.98, 0.97, 'Library Fit', ...
                    'Units', 'normalized', ...
                    'HorizontalAlignment', 'right', ...
                    'VerticalAlignment', 'top', ...
                    'FontSize', 7, ...
                    'FontWeight', 'bold');

                % Values line
                if ~isnan(libInfo.q_shape)
                    valStr = sprintf('\\phi=%.2f, \\epsilon=%.2f, Q=%.2f', ...
                        libInfo.phi, libInfo.eps, libInfo.q_shape);
                else
                    valStr = sprintf('\\phi=%.2f, \\epsilon=%.2f', ...
                        libInfo.phi, libInfo.eps);
                end
                text(ax, 0.98, 0.89, valStr, ...
                    'Units', 'normalized', ...
                    'HorizontalAlignment', 'right', ...
                    'VerticalAlignment', 'top', ...
                    'FontSize', 7, ...
                    'Interpreter', 'tex');
            end
        end
    end
end

end
function imposed_edges = resolveImposedEdges(state)
    % MODEL: Return global edges or empty (TERMINAL)
    if strcmp(state.axis_mode, 'global') && state.global_limits.valid
        imposed_edges = state.global_limits.hist_log_edges;
    else
        imposed_edges = [];
    end
end
function renderTrajectoryCell(ax, state, ord_idx, nom_idx)
    % CONTROLLER: Render trajectory using fork-based design language
    %
    % Branch events are drawn as backward sigmoids that diverge from
    % the source pool line, creating a visual fork. The sigmoid extends
    % backward from the branch round, overlapping the upstream pool
    % line, and arrives at the target pool's starting phi exactly at
    % the branch round.

    td = prepareTrajectoryData(state, ord_idx, nom_idx);
    prepareAxes(ax);
    drawAllPoolTrajectories(ax, td);
    drawBranchForks(ax, td);
    finalizeTrajectoryAxes(ax, td);

    % === SUB-CONTROLLERS ===

    function td = prepareTrajectoryData(state, ord_idx, nom_idx)
        % SUB-CONTROLLER: Extract config and compute derived data
        raw = extractCellConfig(state, ord_idx, nom_idx);
        startRounds = computePoolStartRounds(raw.pools, raw.branch_events);
        td = packTrajectoryData(raw, startRounds);

        function raw = extractCellConfig(state, ord_idx, nom_idx)
            % MODEL: Extract pool and branch config from results (TERMINAL)
            nom_field = state.results.scenario.nominal_fields{nom_idx};
            cellConfig = state.results.scenario.config(ord_idx).(nom_field);
            raw = struct();
            raw.pools = cellConfig.pools;
            raw.branch_events = cellConfig.branch_events;
            raw.v = cellConfig.universal.v;
        end

        function sr = computePoolStartRounds(pools, branch_events)
            % MODEL: Determine when each pool first appears (TERMINAL)
            n = length(pools);
            sr = nan(1, n);
            for i = 1:n
                if pools(i).initial_S > 0, sr(i) = 1; end
            end
            for e = 1:length(branch_events)
                tgt = branch_events(e).target_pool;
                er = branch_events(e).eligible_rounds(1);
                if isnan(sr(tgt)) || er < sr(tgt), sr(tgt) = er; end
            end
        end

        function td = packTrajectoryData(raw, startRounds)
            % MODEL: Combine config with computed start rounds (TERMINAL)
            td = struct();
            td.pools = raw.pools;
            td.branch_events = raw.branch_events;
            td.v = raw.v;
            td.start_rounds = startRounds;
        end
    end

    function prepareAxes(ax)
        % VIEW: Clear axes and enable hold (TERMINAL)
        cla(ax);
        hold(ax, 'on');
        set(ax, 'Visible', 'on');
    end

    function drawAllPoolTrajectories(ax, td)
        % SUB-CONTROLLER: Draw each pool's epsilon band and trajectory line
        for i = 1:length(td.pools)
            sr = td.start_rounds(i);
            if isnan(sr), continue; end
            drawSinglePool(ax, td.pools(i), sr, td.v, i);
        end
        drawPhaseBoundaries(ax, td.pools);

        function drawSinglePool(ax, pool, sr, v, poolIndex)
            % SUB-CONTROLLER: Render one pool's band and line
            plotData = computePoolPlotData(pool, sr, v);
            style = computePoolStyle(pool, poolIndex);
            renderEpsilonBand(ax, plotData, style);
            renderPoolLine(ax, plotData, style);

            function plotData = computePoolPlotData(pool, sr, v)
                % MODEL: Compute trajectory coordinates and epsilon band (TERMINAL)
                draw_range = sr:v;
                plotData = struct();
                plotData.x = draw_range;
                plotData.y = pool.p_traj(draw_range);
                eps_vals = pool.eps_traj(draw_range);
                plotData.band_upper = min(1, plotData.y + 2 * eps_vals);
                plotData.band_lower = max(0, plotData.y - 2 * eps_vals);
            end

            function style = computePoolStyle(pool, poolIndex)
                % MODEL: Determine visual properties for a pool (TERMINAL)
                style = struct();
                style.color = pool.color;
                style.bandAlpha = 0.15;
                if poolIndex == 1
                    style.lineWidth = 2.5;
                else
                    style.lineWidth = 2.0;
                end
            end

            function renderEpsilonBand(ax, plotData, style)
                % VIEW: Draw the epsilon shaded band (TERMINAL)
                if isempty(plotData.x), return; end
                if all(plotData.band_upper == plotData.band_lower), return; end
                band_x = [plotData.x, fliplr(plotData.x)];
                band_y = [plotData.band_upper, fliplr(plotData.band_lower)];
                fill(ax, band_x, band_y, style.color, ...
                    'EdgeColor', 'none', 'FaceAlpha', style.bandAlpha, ...
                    'HitTest', 'off', 'PickableParts', 'none');
            end

            function renderPoolLine(ax, plotData, style)
                % VIEW: Draw the pool trajectory line (TERMINAL)
                if isempty(plotData.x), return; end
                h = plot(ax, plotData.x, plotData.y, '-', ...
                    'Color', style.color, 'LineWidth', style.lineWidth);
                uistack(h, 'top');
            end
        end

        function drawPhaseBoundaries(ax, pools)
            % VIEW: Draw phase boundary lines for all pools (TERMINAL)
            for i = 1:length(pools)
                for pb = pools(i).phase_boundaries
                    xline(ax, pb + 0.5, ':', ...
                        'Color', [0.75, 0.75, 0.75], 'LineWidth', 0.6);
                end
            end
        end
    end

    function drawBranchForks(ax, td)
        % SUB-CONTROLLER: Draw backward sigmoid forks at each branch event
        for e = 1:length(td.branch_events)
            drawSingleFork(ax, td.branch_events(e), td.pools);
        end

        function drawSingleFork(ax, ev, pools)
            % SUB-CONTROLLER: Render one backward sigmoid fork arm
            forkConfig = computeForkConfig(ev, pools);
            sigmoidData = computeSigmoidCurve(forkConfig);
            armStyle = computeArmStyle(pools, ev);
            renderSigmoidArm(ax, sigmoidData, armStyle);
            renderEligibleWindow(ax, ev, pools);

            function config = computeForkConfig(ev, pools)
                % MODEL: Compute fork geometry for one branch event (TERMINAL)
                config = struct();
                er = ev.eligible_rounds(1);
                config.branchRound = er;
                config.spread = 2;
                config.startX = max(er - config.spread, 0);
                config.originY = pools(ev.source_pool).p_traj(er);
                config.targetY = pools(ev.target_pool).p_traj(er);
                config.sigmoid_k = 10;
                config.n_points = 50;
            end

            function data = computeSigmoidCurve(config)
                % MODEL: Compute backward sigmoid from startX to branch round (TERMINAL)
                t = linspace(0, 1, config.n_points);
                s = 1 ./ (1 + exp(-config.sigmoid_k * (t - 0.5)));
                s = (s - s(1)) / (s(end) - s(1));
                data = struct();
                data.x = config.startX + t * (config.branchRound - config.startX);
                data.y = config.originY + (config.targetY - config.originY) * s;
            end

            function style = computeArmStyle(pools, ev)
                % MODEL: Determine fork arm visual properties (TERMINAL)
                style = struct();
                style.color = pools(ev.target_pool).color;
                style.lineWidth = 1.5;
            end

            function renderSigmoidArm(ax, data, style)
                % VIEW: Draw one sigmoid fork arm (TERMINAL)
                plot(ax, data.x, data.y, '-', ...
                    'Color', style.color, ...
                    'LineWidth', style.lineWidth, ...
                    'HitTest', 'off', 'PickableParts', 'none');
            end

            function renderEligibleWindow(ax, ev, pools)
                % VIEW: Draw eligible round indicator bar if multi-round (TERMINAL)
                if length(ev.eligible_rounds) <= 1 && ...
                        ev.eligible_rounds(end) <= ev.eligible_rounds(1)
                    return;
                end
                er_start = ev.eligible_rounds(1);
                er_end = ev.eligible_rounds(end);
                tgt_color = pools(ev.target_pool).color;
                patch(ax, ...
                    [er_start, er_end, er_end, er_start], ...
                    [-0.03, -0.03, -0.01, -0.01], ...
                    tgt_color, 'EdgeColor', 'none', 'FaceAlpha', 0.4);
            end
        end
    end

    function finalizeTrajectoryAxes(ax, td)
        % SUB-CONTROLLER: Set axis properties and build legend
        axisConfig = computeAxisConfig(td.v);
        applyAxisFormatting(ax, axisConfig);
        buildPoolLegend(ax, td.pools, td.start_rounds);
        hold(ax, 'off');

        function config = computeAxisConfig(v)
            % MODEL: Determine axis limits and tick values (TERMINAL)
            config = struct();
            config.xLim = [0, v + 1];
            config.yLim = [-0.05, 1.05];
            config.yTicks = [0, 0.25, 0.50, 0.75, 1.0];
        end

        function applyAxisFormatting(ax, config)
            % VIEW: Apply axis limits, labels, and formatting (TERMINAL)
            xlim(ax, config.xLim);
            ylim(ax, config.yLim);
            xlabel(ax, 'Division Round', 'FontSize', 10);
            ylabel(ax, 'p_{success}', 'FontSize', 10);
            set(ax, 'FontSize', 9, 'Box', 'on', 'YTick', config.yTicks);
        end

        function buildPoolLegend(ax, pools, start_rounds)
            % VIEW: Add pool color legend (TERMINAL)
            n_pools = length(pools);
            legend_handles = gobjects(n_pools, 1);
            legend_labels = cell(n_pools, 1);
            for i = 1:n_pools
                if isnan(start_rounds(i)), continue; end
                legend_handles(i) = plot(ax, NaN, NaN, '-', ...
                    'Color', pools(i).color, 'LineWidth', 2);
                legend_labels{i} = pools(i).label;
            end
            valid = ~isnan(start_rounds);
            if sum(valid) > 1
                legend(ax, legend_handles(valid), legend_labels(valid), ...
                    'Location', 'best', 'FontSize', 8, 'Box', 'off');
            end
        end
    end
end
function renderHistogramCell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render histogram for one cell
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);
    drawHistogram(ax, histData, state);

    function drawHistogram(ax, histData, state)
        % VIEW: Draw log-space histogram (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end
        bar(ax, histData.log_bin_centers, histData.bin_counts, 1, ...
            'FaceColor', [0.30, 0.45, 0.75], 'EdgeColor', [0.20, 0.30, 0.55], ...
            'FaceAlpha', 0.7);
        text(ax, 0.97, 0.95, sprintf('n=%d\n\\mu=%.0f \\mum\nCV=%.2f', ...
            histData.n, histData.mean_r, histData.cv), ...
            'Units', 'normalized', 'FontSize', 8, ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'BackgroundColor', [1, 1, 1, 0.85], 'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);
        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end
end
function renderMixtureCell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render mixture model overlay
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);
    mixtureData = buildMixtureCurves(colonySet, histData);
    drawMixturePanel(ax, histData, mixtureData, state);

    function mixtureData = buildMixtureCurves(colonySet, histData)
        % MODEL: Compute component and total curves (TERMINAL)
        mixtureData = struct();
        mixtureData.success = false;
        mixtureData.library_info = '';

        k = colonySet.gmm_results.optimal_components;
        mixtureData.k = k;
        if histData.empty || k == 0, return; end

        fm = colonySet.gmm_results.fitted_model;
        if any(isnan(fm.GMM_mu)) || any(fm.GMM_mu <= 0), return; end

        % Library info
        if isfield(colonySet, 'selected_method') && ...
                strcmp(char(colonySet.selected_method), 'Library') && ...
                isfield(fm, 'library_blobs') && ~isempty(fm.library_blobs.centroids_phi)
            [~, dom] = max(fm.library_blobs.total_weights);
            phi_str = sprintf('Library: \\phi=%.2f \\epsilon=%.2f', ...
                fm.library_blobs.centroids_phi(dom), fm.library_blobs.centroids_eps(dom));
            quality_str = '';
            if isfield(fm, 'library_quality_shape') && isfield(fm, 'library_quality_scale') && ...
                    ~isnan(fm.library_quality_shape) && ~isnan(fm.library_quality_scale)
                quality_str = sprintf('Q_{shape}=%.2f Q_{scale}=%.2f', ...
                    fm.library_quality_shape, fm.library_quality_scale);
            elseif isfield(fm, 'library_quality_shape') && ~isnan(fm.library_quality_shape)
                quality_str = sprintf('Q_{shape}=%.2f', fm.library_quality_shape);
            elseif isfield(fm, 'library_quality_scale') && ~isnan(fm.library_quality_scale)
                quality_str = sprintf('Q_{scale}=%.2f', fm.library_quality_scale);
            end
            if isempty(quality_str)
                mixtureData.library_info = phi_str;
            else
                mixtureData.library_info = sprintf('%s\n%s', phi_str, quality_str);
            end
        end

        n = histData.n;
        bw = histData.log_bin_width;
        x_log = linspace(histData.log_bin_edges(1), histData.log_bin_edges(end), 300);
        [~, sort_idx] = sort(fm.GMM_mu);

        component_curves = zeros(k, length(x_log));
        total_curve = zeros(1, length(x_log));
        comp_info = cell(k, 1);
        for i = 1:k
            ci = sort_idx(i);
            mu_log = log(fm.GMM_mu(ci));
            sigma_log = fm.GMM_sigma(ci);
            w = fm.GMM_weights(ci);
            if sigma_log <= 0 || ~isfinite(mu_log)
                comp_info{i} = sprintf('k%d: invalid', i); continue;
            end
            curve = w * normpdf(x_log, mu_log, sigma_log) * n * bw;
            component_curves(i, :) = curve;
            total_curve = total_curve + curve;
            dist_type = '';
            if isfield(colonySet, 'subpopulations') && length(colonySet.subpopulations) >= ci
                dist_type = char(colonySet.subpopulations(ci).best_distribution);
            end
            comp_info{i} = sprintf('k%d: \\mu=%.0f, w=%.0f%% [%s]', ...
                i, fm.GMM_mu(ci), w * 100, dist_type);
        end

        mixtureData.x_log = x_log;
        mixtureData.component_curves = component_curves;
        mixtureData.total_curve = total_curve;
        mixtureData.comp_info = comp_info;
        mixtureData.success = true;
    end

    function drawMixturePanel(ax, histData, mixtureData, state)
        % VIEW: Draw histogram with mixture overlay (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end

        bar(ax, histData.log_bin_centers, histData.bin_counts, 1, ...
            'FaceColor', [0.80, 0.80, 0.80], 'EdgeColor', [0.60, 0.60, 0.60], ...
            'FaceAlpha', 0.6);

        if mixtureData.success && mixtureData.k > 0
            comp_colors = [0.12, 0.47, 0.71; 0.89, 0.10, 0.11; ...
                           0.17, 0.63, 0.17; 0.58, 0.40, 0.74];
            for i = 1:mixtureData.k
                color = comp_colors(min(i, size(comp_colors, 1)), :);
                plot(ax, mixtureData.x_log, mixtureData.component_curves(i, :), ...
                    '-', 'Color', color, 'LineWidth', 2);
            end
            plot(ax, mixtureData.x_log, mixtureData.total_curve, 'k--', 'LineWidth', 1.5);

            info_lines = cell(mixtureData.k + 1, 1);
            info_lines{1} = sprintf('k = %d', mixtureData.k);
            for i = 1:mixtureData.k
                info_lines{i + 1} = mixtureData.comp_info{i};
            end
            if ~isempty(mixtureData.library_info)
                info_lines{end + 1} = mixtureData.library_info;
            end

            curve_at_bins = interp1(mixtureData.x_log, mixtureData.total_curve, ...
                histData.log_bin_centers, 'linear', 0);
            envelope = max(histData.bin_counts, curve_at_bins);
            if strcmp(state.axis_mode, 'global') && state.global_limits.valid
                effective_y_max = state.global_limits.hist_y_max;
            else
                effective_y_max = max(envelope) * 1.1;
            end

            placement = findLeastOccludedCorner(histData.log_bin_centers, ...
                envelope, effective_y_max, length(info_lines));
            text(ax, placement.x, placement.y, strjoin(info_lines, '\n'), ...
                'Units', 'normalized', 'FontSize', 7, ...
                'HorizontalAlignment', placement.h_align, ...
                'VerticalAlignment', placement.v_align, ...
                'BackgroundColor', [1, 1, 1, 0.85], ...
                'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);
        end

        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end

    function placement = findLeastOccludedCorner(bin_centers, envelope, y_max, n_lines)
        % MODEL: Score four corners by occlusion (TERMINAL)
        margin = 0.03;
        box_w = 0.35;
        box_h = min(0.045 * n_lines + 0.03, 0.85);
        candidates = struct( ...
            'x', {1-margin, margin, 1-margin, margin}, ...
            'y', {1-margin, 1-margin, margin, margin}, ...
            'h_align', {'right', 'left', 'right', 'left'}, ...
            'v_align', {'top', 'top', 'bottom', 'bottom'}, ...
            'rect', {[1-margin-box_w, 1-margin-box_h, 1-margin, 1-margin], ...
                     [margin, 1-margin-box_h, margin+box_w, 1-margin], ...
                     [1-margin-box_w, margin, 1-margin, margin+box_h], ...
                     [margin, margin, margin+box_w, margin+box_h]});
        x_lo = min(bin_centers); x_hi = max(bin_centers);
        x_range = x_hi - x_lo; y_range = y_max;
        if x_range <= 0 || y_range <= 0
            placement = candidates(1); return;
        end
        scores = zeros(1, 4);
        for cc = 1:4
            r = candidates(cc).rect;
            data_x_min = x_lo + r(1) * x_range;
            data_x_max = x_lo + r(3) * x_range;
            data_y_min = r(2) * y_range;
            data_y_max = r(4) * y_range;
            in_x = bin_centers >= data_x_min & bin_centers <= data_x_max;
            heights = envelope(in_x);
            for h = 1:length(heights)
                overlap = min(heights(h), data_y_max) - data_y_min;
                if overlap > 0, scores(cc) = scores(cc) + overlap; end
            end
        end
        [~, best] = min(scores);
        placement = struct('x', candidates(best).x, 'y', candidates(best).y, ...
            'h_align', candidates(best).h_align, 'v_align', candidates(best).v_align);
    end
end
function renderKDECell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render KDE with histogram backing
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);
    kdeData = computeLogKDE(colonySet.raw_measurements, imposed_edges);
    drawKDEPanel(ax, histData, kdeData, state);

    function drawKDEPanel(ax, histData, kdeData, state)
        % VIEW: Draw KDE with density-normalized histogram backing (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if kdeData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', kdeData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end

        % Density-normalized histogram backing
        if ~histData.empty
            density_counts = histData.bin_counts / (histData.n * histData.log_bin_width);
            bar(ax, histData.log_bin_centers, density_counts, 1, ...
                'FaceColor', [0.75, 0.75, 0.78], 'EdgeColor', [0.60, 0.60, 0.65], ...
                'FaceAlpha', 0.4);
        end

        % KDE curve
        plot(ax, kdeData.eval_x_log, kdeData.density, '-', ...
            'Color', [0.75, 0.20, 0.30], 'LineWidth', 2);

        % Info panel
        text(ax, 0.97, 0.95, sprintf('n=%d\n\\mu=%.0f \\mum\nCV=%.2f\nh=%.3f', ...
            kdeData.n, kdeData.mean_r, kdeData.cv, kdeData.bandwidth), ...
            'Units', 'normalized', 'FontSize', 8, ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'BackgroundColor', [1, 1, 1, 0.85], 'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);

        applyLogTickLabels(ax, histData);

        % Override xlim to encompass full KDE range and apply y-limits
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            xlim(ax, [state.global_limits.hist_log_edges(1), ...
                      state.global_limits.hist_log_edges(end)]);
            ylim(ax, [0, state.global_limits.kde_y_max]);
        else
            xlim(ax, [kdeData.eval_x_log(1), kdeData.eval_x_log(end)]);
        end

        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Density', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end
end
function renderCompositionCell(ax, state, ord_idx, nom_idx)
    % SUB-CONTROLLER: Render composition-stacked histogram from pool tracking
    nom_field = state.results.scenario.nominal_fields{nom_idx};
    colonySet = state.results.analysisResults ...
        .SubpopulationAnalysis(ord_idx).(nom_field).ColonySet;
    cellConfig = state.results.scenario.config(ord_idx).(nom_field);

    imposed_edges = resolveImposedEdges(state);
    histData = computeLogHistogram(colonySet.raw_measurements, imposed_edges);

    n_pools = length(cellConfig.pools);
    hasMultiplePools = n_pools > 1 && isfield(colonySet, 'tracking') && ...
        isfield(colonySet.tracking, 'pool_cells_final') && ...
        size(colonySet.tracking.pool_cells_final, 2) >= n_pools;

    if hasMultiplePools
        poolMeta = extractPoolMeta(cellConfig.pools);
        compData = computeMultiPoolBinComposition(histData, ...
            colonySet.tracking.pool_cells_final, poolMeta);
        drawCompositionHistogram(ax, histData, compData, state);
    else
        drawFallbackHistogram(ax, histData, state);
    end

    function poolMeta = extractPoolMeta(pools)
        % MODEL: Extract colors and labels from pool structs (TERMINAL)
        n = length(pools);
        poolMeta = struct();
        poolMeta.colors = zeros(n, 3);
        poolMeta.labels = cell(1, n);
        for i = 1:n
            poolMeta.colors(i, :) = pools(i).color;
            poolMeta.labels{i} = pools(i).label;
        end
    end

    function compData = computeMultiPoolBinComposition(histData, pool_cells_final, poolMeta)
        % MODEL: Compute per-bin per-pool fractions (TERMINAL)
        compData = struct();
        n_pools = size(pool_cells_final, 2);
        compData.pool_colors = poolMeta.colors;
        compData.pool_labels = poolMeta.labels;

        if histData.empty
            compData.bin_pool_fracs = [];
            return;
        end

        log_radii = log(histData.radii);
        edges = histData.log_bin_edges;
        n_bins = length(edges) - 1;
        bin_pool_fracs = zeros(n_bins, n_pools);
        colony_totals = sum(pool_cells_final, 2);

        for b = 1:n_bins
            if b < n_bins
                in_bin = log_radii >= edges(b) & log_radii < edges(b + 1);
            else
                in_bin = log_radii >= edges(b) & log_radii <= edges(b + 1);
            end
            if any(in_bin)
                totals = colony_totals(in_bin);
                totals(totals == 0) = 1;
                for p = 1:n_pools
                    bin_pool_fracs(b, p) = mean(pool_cells_final(in_bin, p) ./ totals);
                end
            end
        end
        compData.bin_pool_fracs = bin_pool_fracs;
    end

    function drawCompositionHistogram(ax, histData, compData, state)
        % VIEW: Draw stacked histogram with pool coloring (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end

        bc = histData.log_bin_centers;
        counts = histData.bin_counts;
        bw = histData.log_bin_width;
        n_pools = size(compData.bin_pool_fracs, 2);

        for b = 1:length(bc)
            if counts(b) == 0, continue; end
            y_base = 0;
            for p = 1:n_pools
                height = counts(b) * compData.bin_pool_fracs(b, p);
                if height > 0.01
                    rectangle(ax, 'Position', [bc(b) - bw/2, y_base, bw, height], ...
                        'FaceColor', compData.pool_colors(p, :), ...
                        'EdgeColor', compData.pool_colors(p, :) * 0.7, ...
                        'LineWidth', 0.5);
                end
                y_base = y_base + height;
            end
        end

        % Legend
        legend_handles = gobjects(n_pools, 1);
        for p = 1:n_pools
            legend_handles(p) = patch(ax, NaN, NaN, compData.pool_colors(p, :), ...
                'EdgeColor', compData.pool_colors(p, :) * 0.7);
        end
        legend(ax, legend_handles, compData.pool_labels, ...
            'Location', 'northeast', 'FontSize', 8, 'Box', 'off');

        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end

    function drawFallbackHistogram(ax, histData, state)
        % VIEW: Plain histogram when single pool (TERMINAL)
        cla(ax); hold(ax, 'on'); set(ax, 'Visible', 'on');
        if histData.empty
            text(ax, 0.5, 0.5, sprintf('No data (n=%d)', histData.n), ...
                'Units', 'normalized', 'HorizontalAlignment', 'center', 'FontSize', 12);
            hold(ax, 'off'); return;
        end
        bar(ax, histData.log_bin_centers, histData.bin_counts, 1, ...
            'FaceColor', [0.30, 0.45, 0.75], 'EdgeColor', [0.20, 0.30, 0.55], ...
            'FaceAlpha', 0.7);
        text(ax, 0.97, 0.95, sprintf('n=%d\n\\mu=%.0f \\mum\nCV=%.2f\n(single pool)', ...
            histData.n, histData.mean_r, histData.cv), ...
            'Units', 'normalized', 'FontSize', 8, ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'BackgroundColor', [1, 1, 1, 0.85], 'EdgeColor', [0.5, 0.5, 0.5], 'Margin', 3);
        applyLogTickLabels(ax, histData);
        if strcmp(state.axis_mode, 'global') && state.global_limits.valid
            ylim(ax, [0, state.global_limits.hist_y_max]);
        end
        xlabel(ax, 'Colony Radius (\mum)', 'FontSize', 10);
        ylabel(ax, 'Count', 'FontSize', 10);
        set(ax, 'FontSize', 9, 'Box', 'on');
        hold(ax, 'off');
    end
end
function histData = computeLogHistogram(radii, imposed_edges)
    % MODEL: Compute log-space histogram (TERMINAL)
    if nargin < 2, imposed_edges = []; end
    histData = struct();
    histData.radii = radii;
    histData.n = length(radii);
    if histData.n < 2
        histData.empty = true;
        histData.mean_r = NaN; histData.std_r = NaN; histData.cv = NaN;
        histData.log_bin_centers = []; histData.log_bin_edges = [];
        histData.bin_counts = []; histData.log_bin_width = NaN;
        return;
    end
    histData.empty = false;
    histData.mean_r = mean(radii);
    histData.std_r = std(radii);
    histData.cv = histData.std_r / histData.mean_r;
    log_radii = log(radii);
    if isempty(imposed_edges)
        log_min = min(log_radii);
        log_max = max(log_radii);
        log_range = log_max - log_min;
        iqr_log = iqr(log_radii);
        if iqr_log > 0 && log_range > 0
            fd_width = 2 * iqr_log / (histData.n ^ (1/3));
            n_bins = ceil(log_range / fd_width);
        else
            n_bins = 10;
        end
        n_bins = min(100, max(10, n_bins));
        edges = linspace(log_min - 0.1, log_max + 0.1, n_bins + 1);
    else
        edges = imposed_edges;
    end
    [counts, ~] = histcounts(log_radii, edges);
    histData.log_bin_centers = (edges(1:end-1) + edges(2:end)) / 2;
    histData.log_bin_edges = edges;
    histData.bin_counts = counts;
    histData.log_bin_width = edges(2) - edges(1);
end
function applyLogTickLabels(ax, histData)
    % VIEW: Set x-axis ticks with original-unit labels (TERMINAL)
    if histData.empty, return; end
    log_range = [histData.log_bin_edges(1), histData.log_bin_edges(end)];
    candidate_ticks_um = [5, 10, 20, 30, 50, 75, 100, 150, 200, 300, 500, 750, 1000, 2000];
    candidate_ticks_log = log(candidate_ticks_um);
    in_range = candidate_ticks_log >= log_range(1) & candidate_ticks_log <= log_range(2);
    tick_vals = candidate_ticks_log(in_range);
    tick_labels = arrayfun(@(x) sprintf('%.0f', x), candidate_ticks_um(in_range), 'UniformOutput', false);
    set(ax, 'XTick', tick_vals, 'XTickLabel', tick_labels);
    xlim(ax, log_range);
end
function globalLimits = computeGlobalLimits(results)
    % SUB-CONTROLLER: Scan all cells for shared axis limits
    allRadii = collectAllRadii(results);
    globalLimits = buildGlobalLimitStruct(allRadii, results);

    function allRadii = collectAllRadii(results)
        % MODEL: Gather radii from every cell (TERMINAL)
        allRadii = [];
        n_ord = length(results.scenario.ordinal_labels);
        n_nom = length(results.scenario.nominal_labels);
        for ord = 1:n_ord
            for nom = 1:n_nom
                nom_field = results.scenario.nominal_fields{nom};
                cs = results.analysisResults ...
                    .SubpopulationAnalysis(ord).(nom_field).ColonySet;
                r = cs.raw_measurements;
                if ~isempty(r), allRadii = [allRadii; r(:)]; end %#ok<AGROW>
            end
        end
    end

    function gl = buildGlobalLimitStruct(allRadii, results)
        % SUB-CONTROLLER: Compute shared edges and y-maxes for all view modes
        gl = initializeLimitStruct();
        if length(allRadii) < 2
            return;
        end
        gl.valid = true;
        gl.hist_log_edges = computeSharedEdges(allRadii);
        gl.hist_y_max = computeMaxHistCount(results, gl.hist_log_edges) * 1.1;
        gl.kde_y_max = computeMaxKDEDensity(results, gl.hist_log_edges) * 1.1;

        function gl = initializeLimitStruct()
            % MODEL: Default invalid struct (TERMINAL)
            gl = struct();
            gl.valid = false;
            gl.hist_log_edges = [];
            gl.hist_y_max = 1;
            gl.kde_y_max = 1;
        end

        function edges = computeSharedEdges(allRadii)
            % MODEL: Compute log-space bin edges across all data (TERMINAL)
            log_all = log(allRadii);
            n_bins = 50;
            edges = linspace(min(log_all) - 0.1, max(log_all) + 0.1, n_bins + 1);
        end

        function max_count = computeMaxHistCount(results, edges)
            % MODEL: Find max histogram count across all cells (TERMINAL)
            max_count = 0;
            n_ord = length(results.scenario.ordinal_labels);
            n_nom = length(results.scenario.nominal_labels);
            for ord = 1:n_ord
                for nom = 1:n_nom
                    nom_field = results.scenario.nominal_fields{nom};
                    cs = results.analysisResults ...
                        .SubpopulationAnalysis(ord).(nom_field).ColonySet;
                    r = cs.raw_measurements;
                    if length(r) >= 2
                        [counts, ~] = histcounts(log(r), edges);
                        max_count = max(max_count, max(counts));
                    end
                end
            end
        end

        function max_density = computeMaxKDEDensity(results, edges)
            % MODEL: Find max KDE density across all cells (TERMINAL)
            max_density = 0;
            n_ord = length(results.scenario.ordinal_labels);
            n_nom = length(results.scenario.nominal_labels);
            for ord = 1:n_ord
                for nom = 1:n_nom
                    nom_field = results.scenario.nominal_fields{nom};
                    cs = results.analysisResults ...
                        .SubpopulationAnalysis(ord).(nom_field).ColonySet;
                    r = cs.raw_measurements;
                    if length(r) >= 2
                        kde_cell = computeLogKDE(r, edges);
                        if ~kde_cell.empty
                            max_density = max(max_density, max(kde_cell.density));
                        end
                    end
                end
            end
        end
    end
end
function kdeData = computeLogKDE(radii, imposed_edges)
    % MODEL: Compute log-space KDE with shrunk Silverman bandwidth (TERMINAL)
    if nargin < 2, imposed_edges = []; end
    kdeData = struct();
    kdeData.radii = radii;
    kdeData.n = length(radii);
    if kdeData.n < 2
        kdeData.empty = true;
        kdeData.mean_r = NaN; kdeData.std_r = NaN; kdeData.cv = NaN;
        kdeData.eval_x_log = []; kdeData.density = [];
        kdeData.bandwidth = NaN;
        return;
    end
    kdeData.empty = false;
    kdeData.mean_r = mean(radii);
    kdeData.std_r = std(radii);
    kdeData.cv = kdeData.std_r / kdeData.mean_r;
    log_radii = log(radii);

    % Shrunk Silverman robust bandwidth (0.5x for mode preservation)
    sigma_log = std(log_radii);
    iqr_log = iqr(log_radii);
    if iqr_log > 0
        spread = min(sigma_log, iqr_log / 1.34);
    else
        spread = sigma_log;
    end
    if spread <= 0
        spread = 0.1;
    end
    silverman_h = 0.9 * spread * kdeData.n^(-1/5);
    h = 0.9 * silverman_h;
    kdeData.bandwidth = h;

    % Evaluation grid
    if isempty(imposed_edges)
        x_min = min(log_radii) - 3*h;
        x_max = max(log_radii) + 3*h;
    else
        x_min = imposed_edges(1);
        x_max = imposed_edges(end);
    end
    n_eval = 300;
    eval_x_log = linspace(x_min, x_max, n_eval);

    % Compute density (Gaussian kernel)
    density = zeros(1, n_eval);
    norm_factor = 1 / (kdeData.n * h * sqrt(2*pi));
    for i = 1:kdeData.n
        density = density + exp(-0.5 * ((eval_x_log - log_radii(i)) / h).^2);
    end
    density = density * norm_factor;

    kdeData.eval_x_log = eval_x_log;
    kdeData.density = density;
end
