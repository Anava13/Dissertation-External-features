% run_all: Run the full analysis pipeline from a fresh copy of this folder
%
%   1. CompositeBuilder.m downloads Complete Analyses from the GitHub release
%      on the first run, builds every part, fits the stable-phi library, and
%      saves outputs/composite_V40.mat (about 15 minutes after the download).
%   2. LeanFinalAnalysis.m loads that composite and writes the figures and
%      overview PDFs to outputs/Overview PDFs.
%
% Each script also runs on its own. LeanFinalAnalysis.m needs the composite
% file from a previous CompositeBuilder.m run.
%
% run() executes each script from this folder, so a file with the same name
% elsewhere on the MATLAB path or in the current folder cannot take its place.

run(fullfile(fileparts(mfilename('fullpath')), 'CompositeBuilder.m'));
run(fullfile(fileparts(mfilename('fullpath')), 'LeanFinalAnalysis.m'));
