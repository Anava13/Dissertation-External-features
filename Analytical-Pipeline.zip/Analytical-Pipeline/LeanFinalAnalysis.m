clear
clc
% LeanFinalAnalysis: Figures and overview PDFs from the composite bundle
%
% Loads the composite file written by CompositeBuilder.m (run that first, or
% use run_all.m) and writes the overview PDFs to the folder named in
% pipelineConfig.m (outputs/Overview PDFs).

addpath(fileparts(mfilename('fullpath')));
cfg = pipelineConfig();
rng(cfg.rngSeed, 'twister');
if ~isfile(cfg.compositeFile)
    error('LeanFinalAnalysis:NoComposite', ...
        'Composite file not found:\n  %s\nRun CompositeBuilder.m first, or run_all.m.', ...
        cfg.compositeFile);
end
if ~isfolder(cfg.overviewFolder)
    mkdir(cfg.overviewFolder);
end
load(cfg.compositeFile, 'composite');

CountDataset = CountDatasetGenerator(composite.part3);
clc
figureModel = renderDbf4Figure(composite.part3);

%drawRescueBoxplot(composite.part3)
% %% %%% PDF Generation Calls %%%% %%
% 
% %% Crowding Dataset
% generateOverviewPDF(composite.part2, 'Crowding', ...
%     struct('Ordinal', 'none', 'Nominal', 'dilution_factor', 'NominalLabel', 'Dilution Factor'))
% 
% %% Historical
% generateOverviewPDF(composite.historical, 'Historical')
% 
% %% Anbalagan Dataset
% generateOverviewPDF(composite.anbalagan, 'Anbalagan', struct('Block', 'figure'), ...
%     {@() plotSenescenceDecline(composite.anbalagan, struct('scale', 'raw'))})
% 
 %% Rescue Dataset
rescueSpec = struct('NominalLabels', {{'double', 'dbf4-1, cdc13-2'}});
rescueFigures = {@() BeautifulFigure(composite.part3, CountDataset), ...
                 @() BeautifulFigure(composite.part3, CountDataset, struct('selectedOnly', true)), ...
                 @() showWithinStatePredictorsOfSize(composite), ...
                 @() drawRescueBoxplot(composite.part3), ...
                 @() renderDbf4Figure(composite.part3)};
 generateOverviewPDF(CountDataset.Dataset1, 'Rescue', rescueSpec, rescueFigures)
 generateOverviewPDF(composite.part3, 'Rescue', rescueSpec, rescueFigures)




%% Figure Generation Functions
% Crowding Dataset
function showWithinStatePredictorsOfSize(combined)
    % CONTROLLER: which plate-level variable predicts median colony size once the
    % state is fixed. Each predictor is centered within state alongside the size
    % response, removing the between-state trajectory, so the remaining slope is
    % the within-state relationship. Four predictors are compared: HCE, colony
    % count, growth coverage (plate-level), and crowding score (per colony).
    % Filtering is the shared V2 confluency filter; the confluency gate is what
    % makes colony count admissible as competitor number here.

    [plates, stateList, omitted, config] = prepareAnalysis(combined);
    results = computePanels(plates, stateList, config);
    renderPredictorFigure(results, config);
    printPredictorSummary(results, omitted);

    function [plates, stateList, omitted, config] = prepareAnalysis(combined)
        % SUB-CONTROLLER: config with transforms and reference slopes, the
        % filtered plate set, state assignment, and the omitted-state diagnostic.
        config = QC.buildConfig();
        config.yTransform      = 'log';
        config.xTransform      = containers.Map( ...
            {'hce', 'count', 'coverage', 'crowding'}, ...
            {'log', 'log',   'linear',   'linear'});
        config.refSlope        = containers.Map( ...
            {'hce',  'count', 'coverage', 'crowding'}, ...
            {-1/3,   -1/3,    NaN,        NaN});
        config.predictorKeys   = {'hce', 'count', 'coverage', 'crowding'};
        config.predictorLabels = containers.Map(config.predictorKeys, ...
            {'HCE', 'Colony count', 'Growth coverage', 'Crowding score'});

        plates = QC.buildPlateRecords(combined, config);
        [plates, stateList] = QC.assignStates(plates, config.order);
        omitted = QC.findOmittedStates(combined, stateList, config);
    end

    function results = computePanels(plates, stateList, config)
        % SUB-CONTROLLER: the four within-state panels and the count-coverage
        % commonality decomposition.
        blk  = [plates.stateId];
        geno = {plates.genotype};
        med  = [plates.median];

        results = struct();
        results.nstates    = numel(stateList);
        results.nPlates    = numel(plates);
        results.predictors = config.predictorKeys;

        panels(1) = assemblePanel('hce',      [plates.hce],      med, blk, geno, 'plate', config);
        panels(2) = assemblePanel('count',    [plates.count],    med, blk, geno, 'plate', config);
        panels(3) = assemblePanel('coverage', [plates.coverage], med, blk, geno, 'plate', config);

        [cCrowd, cRad, cBlk, cGeno] = QC.gatherColonyData(plates);
        panels(4) = assemblePanel('crowding', cCrowd, cRad, cBlk, cGeno, 'colony', config);

        results.panels      = panels;
        results.plateYLim   = QC.paddedLimits([panels(1).y, panels(2).y, panels(3).y]);
        results.colonyYLim  = QC.paddedLimits(panels(4).y);
        results.commonality = computeCommonality(plates, blk);

        function panel = assemblePanel(key, rawX, rawY, blk, geno, grain, config)
            % SUB-CONTROLLER: center this predictor and the response within
            % state, fit, and decorate with the analysis fields. QC.demeanedFit
            % carries the model work; the decoration is label, grain, reference
            % slope, x limits, and the transforms.
            xT = config.xTransform(key);
            yT = config.yTransform;
            panel = QC.demeanedFit(rawX, rawY, blk, geno, xT, yT, true);
            panel.key        = key;
            panel.label      = config.predictorLabels(key);
            panel.grain      = grain;
            panel.refSlope   = config.refSlope(key);
            panel.xLim       = QC.paddedLimits(panel.x);
            panel.xTransform = xT;
            panel.yTransform = yT;
        end

        function commonality = computeCommonality(plates, blk)
            % SUB-CONTROLLER: how colony count and growth coverage split the
            % within-state variance in size. All three are centered within
            % state; the joint model gives partial slopes, and the single and
            % joint fits give the unique and shared shares.
            ld = QC.applyTransform([plates.median],   'log');
            lc = QC.applyTransform([plates.count],    'log');
            gc = QC.applyTransform([plates.coverage], 'linear');

            ok = isfinite(ld) & isfinite(lc) & isfinite(gc) & isfinite(blk);
            ld = ld(ok); lc = lc(ok); gc = gc(ok); b = blk(ok);

            dy = QC.demeanWithinStates(ld, b);
            dc = QC.demeanWithinStates(lc, b);
            dg = QC.demeanWithinStates(gc, b);

            countFit = QC.fitLine(dc, dy);
            covFit   = QC.fitLine(dg, dy);
            joint    = fitJoint(dc, dg, dy);

            commonality = struct();
            commonality.n          = numel(dy);
            commonality.r2Count    = countFit.r2;
            commonality.r2Cov      = covFit.r2;
            commonality.r2Joint    = joint.r2;
            commonality.slopeCount = joint.bCount;
            commonality.slopeCov   = joint.bCov;
            commonality = decomposeCommonality(commonality);

            function joint = fitJoint(x1, x2, y)
                % MODEL (TERMINAL): two-predictor OLS partial slopes and joint R^2.
                joint = struct('bCount', NaN, 'bCov', NaN, 'r2', NaN);
                X = [ones(numel(y), 1), x1(:), x2(:)];
                if rank(X) < 3 || numel(y) < 4
                    return;
                end
                beta  = X \ y(:);
                yhat  = X * beta;
                ssRes = sum((y(:) - yhat).^2);
                ssTot = sum((y(:) - mean(y)).^2);
                joint.bCount = beta(2);
                joint.bCov   = beta(3);
                if ssTot > 0
                    joint.r2 = 1 - ssRes / ssTot;
                end
            end

            function c = decomposeCommonality(c)
                % MODEL (TERMINAL): unique and shared R^2 shares.
                c.uniqueCount = max(0, c.r2Joint - c.r2Cov);
                c.uniqueCov   = max(0, c.r2Joint - c.r2Count);
                c.shared      = c.r2Joint - c.uniqueCount - c.uniqueCov;
            end
        end
    end

    function renderPredictorFigure(results, config)
        % SUB-CONTROLLER: 2x2 within-state panels with a center legend block.
        fig = figure('Name', 'Within-State Predictors of Size', 'Color', 'w', ...
                     'Position', [100 100 1000 850]);

        positions = {[0.08 0.56 0.36 0.38], [0.56 0.56 0.36 0.38], ...
                     [0.08 0.08 0.36 0.38], [0.56 0.08 0.36 0.38]};

        for k = 1:4
            ax = axes('Parent', fig, 'Position', positions{k}); %#ok<LAXES>
            if strcmp(results.panels(k).grain, 'colony')
                yLim = results.colonyYLim;
            else
                yLim = results.plateYLim;
            end
            drawPredictorPanel(ax, results.panels(k), yLim, config);
        end

        drawCenterLegend(fig, results, config);

        function drawPredictorPanel(ax, panel, yLim, config)
            % SUB-CONTROLLER: one within-state panel. Centered scatter, zero
            % crosshairs, the within-state fit, an optional reference slope, and
            % the slope/R^2 box. View primitives and builtins only.
            if strcmp(panel.grain, 'colony')
                sz = 10; fa = 0.25;
            else
                sz = 45; fa = 0.80;
            end

            QC.scatterByGenotype(ax, panel.x, panel.y, panel.pointGenotype, config, sz, fa);

            xline(ax, 0, 'Color', [0.6 0.6 0.6], 'HandleVisibility', 'off');
            yline(ax, 0, 'Color', [0.6 0.6 0.6], 'HandleVisibility', 'off');

            QC.overlayFitLine(ax, panel, [0.15 0.15 0.15], 2.0);

            if isfinite(panel.refSlope)
                xspan = linspace(panel.xLim(1), panel.xLim(2), 50);
                hr = plot(ax, xspan, panel.refSlope * xspan, '--', ...
                          'Color', [0.85 0.33 0.10], 'LineWidth', 1.2);
                hr.HandleVisibility = 'off';
            end

            xlim(ax, panel.xLim);
            ylim(ax, yLim);

            xlab = sprintf('%s (centered, %s)', panel.label, panel.xTransform);
            ylab = sprintf('median radius (centered, %s)', panel.yTransform);
            QC.formatAxes(ax, xlab, ylab, panel.label, 'linear', 'linear');

            if isfinite(panel.slope)
                if isfinite(panel.refSlope)
                    line1 = sprintf('slope=%.3f (ref %.3f)', panel.slope, panel.refSlope);
                else
                    line1 = sprintf('slope=%.3f', panel.slope);
                end
                lines = {line1, sprintf('R^2=%.3f, n=%d, states=%d', ...
                         panel.r2, panel.nUnits, panel.nstates)};
            else
                lines = {sprintf('n=%d (insufficient)', panel.nUnits)};
            end
            QC.annotationBox(ax, lines, 0.04, 0.96);
        end

        function drawCenterLegend(fig, results, config)
            % VIEW (TERMINAL): genotype swatches and the state count in a center
            % overlay between the four panels.
            ax = axes('Parent', fig, 'Position', [0.45 0.45 0.15 0.10]); %#ok<LAXES>
            axis(ax, 'off');
            hold(ax, 'on');

            present = unique([results.panels(1).pointGenotype, ...
                              results.panels(2).pointGenotype, ...
                              results.panels(3).pointGenotype, ...
                              results.panels(4).pointGenotype]);

            order = config.order;
            yy = 1;
            for gi = 1:numel(order)
                g = order{gi};
                if ~any(strcmp(present, g))
                    continue;
                end
                c = config.colors(g);
                plot(ax, 0.1, yy, 'o', 'MarkerFaceColor', c, 'MarkerEdgeColor', c);
                text(ax, 0.25, yy, config.labels(g), 'FontSize', 8, ...
                     'VerticalAlignment', 'middle');
                yy = yy - 1;
            end
            text(ax, 0.1, yy, sprintf('states = %d', results.nstates), ...
                 'FontSize', 8, 'FontWeight', 'bold', 'VerticalAlignment', 'middle');
            xlim(ax, [0 1]);
            ylim(ax, [yy - 1, 2]);
        end
    end

    function printPredictorSummary(results, omitted)
        % SUB-CONTROLLER: per-predictor fit table, the omitted-state report, the
        % commonality split, and the conclusion.
        fprintf('\n========== Within-State Predictors of Size ==========\n');
        fprintf('Plates: %d, states: %d\n', results.nPlates, results.nstates);

        printPredictorTable(results);
        printOmittedStates(omitted);
        printCommonality(results.commonality);
        printConclusion(results);

        function printPredictorTable(results)
            % VIEW (TERMINAL): within-state slope and R^2 per predictor.
            fprintf('\n--- within-state predictors of median size ---\n');
            fprintf('%-16s %-8s %-8s %-8s %-8s\n', 'Predictor', 'Slope', 'Ref', 'R^2', 'n');
            for k = 1:numel(results.panels)
                p = results.panels(k);
                if isfinite(p.refSlope)
                    refStr = sprintf('%.3f', p.refSlope);
                else
                    refStr = 'n/a';
                end
                if isfinite(p.slope)
                    fprintf('%-16s %-8.3f %-8s %-8.3f %-8d\n', p.label, p.slope, refStr, p.r2, p.nUnits);
                else
                    fprintf('%-16s %-8s %-8s %-8s %-8d\n', p.label, 'n/a', refStr, 'n/a', p.nUnits);
                end
            end
        end

        function printOmittedStates(omitted)
            % VIEW (TERMINAL): states with no plate clearing inclusion, with the
            % dominant failure for filtered cells. The label map covers every
            % inclusion criterion, hasResolved included, so a confluency failure
            % prints a phrase rather than the raw field name.
            labelMap = containers.Map( ...
                {'isStandard', 'isSixDay', 'notExcluded', 'notPooled', ...
                 'hasCount', 'hasHCE', 'hasMedian', 'hasCov', 'okColony', 'hasResolved'}, ...
                {'not standard source', 'not six-day', 'excluded enrichment', ...
                 'pooled replicate', 'no colony count', 'no HCE', ...
                 'no median radius', 'no coverage', 'no aligned colonies', ...
                 'colony coverage below confluency ratio'});

            fprintf('\n--- omitted states ---\n');
            if isempty(omitted)
                fprintf('(none)\n');
                return;
            end
            for i = 1:numel(omitted)
                o = omitted(i);
                if strcmp(o.category, 'absent')
                    fprintf('%-22s absent (no plates collected)\n', o.label);
                else
                    fn = fieldnames(o.failCounts);
                    bestName = ''; bestCount = -1;
                    for k = 1:numel(fn)
                        if o.failCounts.(fn{k}) > bestCount
                            bestCount = o.failCounts.(fn{k});
                            bestName  = fn{k};
                        end
                    end
                    if labelMap.isKey(bestName)
                        reason = labelMap(bestName);
                    else
                        reason = bestName;
                    end
                    fprintf('%-22s filtered (%d plates, dominant: %s)\n', o.label, o.rawCount, reason);
                end
            end
        end

        function printCommonality(c)
            % VIEW (TERMINAL): count vs coverage variance split in within-state size.
            fprintf('\n--- count vs coverage commonality (within-state size) ---\n');
            fprintf('R^2 count alone:        %.3f\n', c.r2Count);
            fprintf('R^2 coverage alone:     %.3f\n', c.r2Cov);
            fprintf('R^2 joint:              %.3f\n', c.r2Joint);
            fprintf('unique to count:        %.3f\n', c.uniqueCount);
            fprintf('unique to coverage:     %.3f\n', c.uniqueCov);
            fprintf('shared:                 %.3f\n', c.shared);
            fprintf('partial slope count:    %.3f\n', c.slopeCount);
            fprintf('partial slope coverage: %.3f\n', c.slopeCov);
        end

        function printConclusion(results)
            % VIEW (TERMINAL): which predictor leads within state.
            best = ''; bestR2 = -Inf;
            for k = 1:numel(results.panels)
                p = results.panels(k);
                if isfinite(p.r2) && p.r2 > bestR2
                    bestR2 = p.r2;
                    best   = p.label;
                end
            end
            fprintf('\nLeading within-state predictor: %s (R^2 = %.3f)\n', best, bestR2);
        end
    end
end
% Anbalagan
function model = plotSenescenceDecline(anbalaganData, options)
    % CONTROLLER: Draw the case for declining colony size and colony count in senescence
    %
    % Two figures open. Each holds one row per metric, colony count on top
    % and median colony radius below. Every panel carries its own legend and
    % a bold serif letter in its top left corner. Letters run in reading
    % order within a figure, so each figure starts again at A.
    %
    % Figure 1, lineages
    %   Column 1  Wild type and rif1 lineages.
    %   Column 2  The telomerase-deficient single mutants over the faded
    %             wild type lineages.
    %
    % Figure 2, rif1 pairs
    %   One panel per telomerase allele: the single mutant against its rif1
    %   double mutant, over the faded wild type (solid gray) and rif1
    %   (dotted gray) lineages grown on the same plates.
    %
    % Extinction is marked at the streak where a lineage produced no
    % colonies. Every line panel carries a shaded wild type band spanning
    % the full streak axis, from the lowest to the highest value reached by
    % any wild type lineage.
    %
    % The scale option selects what the y axis carries.
    %
    %   'relative' (default)  Each lineage is expressed relative to its own
    %                         first streak, so lineages that start at
    %                         different values share one axis. The axis is
    %                         log10 of that ratio, labelled in percent, so a
    %                         halving and a doubling sit the same distance
    %                         from zero.
    %
    %   'raw'                 Median colony radius in micrometres and colony
    %                         count as measured, on a linear axis with
    %                         automatic ticks. The count axis starts at zero.
    %                         Raw values are comparable within a figure of
    %                         the source data. Figure 1 pools lineages across
    %                         source figures, so read across its panels only
    %                         when plating and streak protocol matched.
    %
    % A streak that produced no colonies has no value on either metric in
    % either mode. The line breaks there and a dotted connector runs to the
    % extinction mark.
    %
    % Usage:
    %   model = plotSenescenceDecline(composite.anbalagan);
    %   model = plotSenescenceDecline(composite.anbalagan, struct('scale', 'raw'));
    %   results = analyzeSenescenceTrajectories(composite.anbalagan);
    %   model = plotSenescenceDecline(results);
    %
    % Inputs:
    %   anbalaganData - composite.anbalagan (scalar struct with .composite),
    %                   the bare composite struct array, or the struct
    %                   returned by analyzeSenescenceTrajectories. Composite
    %                   entries carry genotype, figure, generations, and
    %                   Measurements.Radius in micrometres. genotype_display
    %                   is used for labels when present.
    %   options       - optional struct, any subset of:
    %     scale            ('relative')           'relative' or 'raw'
    %     healthyGenotypes ({'Wild_Type','rif1'}) non-senescent genotype keys;
    %                                             the first is wild type
    %     healthyColors    (green; black)         one RGB row per healthy genotype
    %     healthyMarkers   ({'o','s'})            one marker per healthy genotype
    %     healthyFadedStyles ({'-',':'})          line style per healthy genotype
    %                                             when drawn as a faded background
    %     alleleKeys       ({'cdc132','est2'})    telomerase alleles, one color and
    %                                             one panel each in figure 2
    %     alleleColors     (orange; red)          one RGB row per allele key
    %     modifierKey      ('rif1')               marks double mutants, drawn as
    %                                             dashed lines with square markers
    %     fadedColor       ([0.70 0.70 0.70])     background lineages
    %     wtBandColor      (green)                wild type band
    %
    % Returns:
    %   The plot model, holding every value the figures draw.

    if nargin < 2 || isempty(options)
        options = struct();
    end

    % === COORDINATE SUB-CONTROLLERS ===
    model = buildDeclineModel(anbalaganData, options);
    renderDeclineFigures(model);

    % === MODEL SUB-CONTROLLER (models only) ===

    function model = buildDeclineModel(anbalaganData, options)
        % SUB-CONTROLLER: Assemble every value the figures draw

        cfg           = resolveOptions(options);
        quads         = buildQuadrants(anbalaganData);
        lineages      = buildLineages(quads, cfg);
        lineages      = attachSeries(lineages, quads, cfg);
        pairs         = buildAllelePairs(lineages, cfg);
        axisSpec      = buildAxisSpec(lineages, cfg);
        figures       = buildFigureSpecs(pairs, axisSpec, cfg);
        extinctions   = buildExtinctionMarks(lineages, axisSpec);
        healthyLegend = buildHealthyLegend(lineages);
        model         = packModel(cfg, lineages, pairs, axisSpec, figures, extinctions, healthyLegend);

        function cfg = resolveOptions(options)
            % MODEL: Merge options over defaults and validate (TERMINAL)
            cfg = struct();
            cfg.scale            = 'relative';
            cfg.healthyGenotypes = {'Wild_Type', 'rif1'};
            cfg.healthyColors    = [0.13 0.55 0.13; 0.00 0.00 0.00];
            cfg.healthyMarkers   = {'o', 's'};
            cfg.healthyFadedStyles = {'-', ':'};
            cfg.alleleKeys       = {'cdc132', 'est2'};
            cfg.alleleColors     = [0.95 0.55 0.05; 0.85 0.10 0.10];
            cfg.modifierKey      = 'rif1';
            cfg.fadedColor       = [0.70 0.70 0.70];
            cfg.wtBandColor      = [0.13 0.55 0.13];

            names = fieldnames(options);
            for k = 1:numel(names)
                if ~isfield(cfg, names{k})
                    error('plotSenescenceDecline:unknownOption', ...
                        'Unknown option "%s".', names{k});
                end
                cfg.(names{k}) = options.(names{k});
            end

            if ~(ischar(cfg.scale) || isstring(cfg.scale))
                error('plotSenescenceDecline:scale', ...
                    'scale must be ''relative'' or ''raw''.');
            end
            cfg.scale = lower(char(cfg.scale));
            if ~any(strcmp(cfg.scale, {'relative', 'raw'}))
                error('plotSenescenceDecline:scale', ...
                    'scale must be ''relative'' or ''raw'', not "%s".', cfg.scale);
            end

            if size(cfg.alleleColors, 2) ~= 3 || size(cfg.alleleColors, 1) < numel(cfg.alleleKeys)
                error('plotSenescenceDecline:alleleColors', ...
                    'alleleColors needs one RGB row per entry in alleleKeys.');
            end
            if size(cfg.healthyColors, 2) ~= 3 || size(cfg.healthyColors, 1) < numel(cfg.healthyGenotypes)
                error('plotSenescenceDecline:healthyColors', ...
                    'healthyColors needs one RGB row per entry in healthyGenotypes.');
            end
            if numel(cfg.healthyMarkers) < numel(cfg.healthyGenotypes)
                error('plotSenescenceDecline:healthyMarkers', ...
                    'healthyMarkers needs one marker per entry in healthyGenotypes.');
            end
            if numel(cfg.healthyFadedStyles) < numel(cfg.healthyGenotypes)
                error('plotSenescenceDecline:healthyFadedStyles', ...
                    'healthyFadedStyles needs one line style per entry in healthyGenotypes.');
            end
        end

        function quads = buildQuadrants(anbalaganData)
            % MODEL: One record per quadrant with log radii, median, and count (TERMINAL)
            % Accepts the composite (composite.anbalagan or its .composite
            % array) or the struct returned by analyzeSenescenceTrajectories,
            % whose quads already carry log10 radii. A quadrant with no
            % colonies is kept and marked extinct.
            template = struct('genotype', '', 'displayBase', '', 'figure', NaN, ...
                'generation', NaN, 'logR', [], 'n', 0, 'extinct', false, 'logMedian', NaN);

            if isstruct(anbalaganData) && isscalar(anbalaganData) && isfield(anbalaganData, 'quads')
                source = anbalaganData.quads;
                quads  = repmat(template, 1, numel(source));
                for k = 1:numel(source)
                    q = template;
                    q.genotype    = source(k).genotype;
                    q.displayBase = source(k).displayBase;
                    q.figure      = double(source(k).figure);
                    q.generation  = double(source(k).generations);
                    q.logR        = source(k).logR(:);
                    q.logR        = q.logR(isfinite(q.logR));
                    q.n           = numel(q.logR);
                    q.extinct     = q.n == 0;
                    if q.n > 0
                        q.logMedian = median(q.logR);
                    end
                    quads(k) = q;
                end
                return;
            end

            if isstruct(anbalaganData) && isscalar(anbalaganData) && isfield(anbalaganData, 'composite')
                entries = anbalaganData.composite;
            else
                entries = anbalaganData;
            end

            required = {'genotype', 'figure', 'generations', 'Measurements'};
            missing  = required(~isfield(entries, required));
            if ~isempty(missing)
                error('plotSenescenceDecline:missingFields', ...
                    ['Input is missing: %s. Pass composite.anbalagan or the struct ' ...
                     'returned by analyzeSenescenceTrajectories.'], strjoin(missing, ', '));
            end

            quads = repmat(template, 1, numel(entries));

            for k = 1:numel(entries)
                e = entries(k);
                q = template;

                q.genotype   = e.genotype;
                q.figure     = double(e.figure);
                q.generation = double(e.generations);
                if isfield(e, 'genotype_display') && ~isempty(e.genotype_display)
                    q.displayBase = e.genotype_display;
                else
                    q.displayBase = e.genotype;
                end

                radii = [];
                if isstruct(e.Measurements) && isfield(e.Measurements, 'Radius') ...
                        && ~isempty(e.Measurements.Radius)
                    radii = double(e.Measurements.Radius(:));
                end
                radii = radii(isfinite(radii) & radii > 0);

                q.logR    = log10(radii);
                q.n       = numel(radii);
                q.extinct = q.n == 0;
                if q.n > 0
                    q.logMedian = median(q.logR);
                end

                quads(k) = q;
            end
        end

        function lineages = buildLineages(quads, cfg)
            % MODEL: One ordered lineage per genotype and figure, with styles (TERMINAL)
            % Healthy lineages come first (by figure), then telomerase-deficient
            % lineages grouped by allele, single mutant before double mutant.
            genos = {quads.genotype};
            figs  = [quads.figure];
            keys  = strcat(genos, '|', arrayfun(@(f) sprintf('%d', f), figs, ...
                           'UniformOutput', false));
            uKeys = unique(keys, 'stable');

            normHealthy = lower(regexprep(cfg.healthyGenotypes, '[^a-zA-Z0-9]', ''));
            normAlleles = lower(regexprep(cfg.alleleKeys, '[^a-zA-Z0-9]', ''));
            normMod     = lower(regexprep(cfg.modifierKey, '[^a-zA-Z0-9]', ''));

            template = struct('genotype', '', 'displayBase', '', 'display', '', ...
                'figure', NaN, 'generations', [], 'quadIdx', [], 'extinctAt', NaN, ...
                'isHealthy', false, 'healthyIndex', 0, 'isDouble', false, ...
                'isSingle', false, 'alleleIndex', 0, 'color', [0 0 0], ...
                'fadedColor', [0 0 0], 'lineStyle', '-', 'fadedLineStyle', '-', ...
                'marker', 'o', ...
                'sortKey', NaN, 'series', []);
            lineages = repmat(template, 1, numel(uKeys));

            for k = 1:numel(uKeys)
                members = find(strcmp(keys, uKeys{k}));
                [~, order] = sort([quads(members).generation]);
                members = members(order);

                L = template;
                L.genotype    = quads(members(1)).genotype;
                L.displayBase = quads(members(1)).displayBase;
                L.figure      = quads(members(1)).figure;
                L.display     = sprintf('%s (Fig %d)', L.displayBase, L.figure);
                L.generations = [quads(members).generation];
                L.quadIdx     = members;

                extinctMask = [quads(members).extinct];
                if any(extinctMask)
                    L.extinctAt = L.generations(find(extinctMask, 1));
                end

                g = lower(regexprep(L.genotype, '[^a-zA-Z0-9]', ''));
                healthyIndex = find(strcmp(normHealthy, g), 1);
                L.isHealthy  = ~isempty(healthyIndex);
                if L.isHealthy
                    L.healthyIndex = healthyIndex;
                end
                for ai = 1:numel(normAlleles)
                    if contains(g, normAlleles{ai})
                        L.alleleIndex = ai;
                        break;
                    end
                end
                L.isDouble = ~L.isHealthy && contains(g, normMod);
                L.isSingle = ~L.isHealthy && ~L.isDouble;

                if L.isHealthy
                    L.color   = cfg.healthyColors(healthyIndex, :);
                    L.marker  = cfg.healthyMarkers{healthyIndex};
                    L.sortKey = 1000 + 10 * L.figure + healthyIndex;
                elseif L.alleleIndex > 0
                    L.color   = cfg.alleleColors(L.alleleIndex, :);
                    L.sortKey = 2000 + 10 * L.alleleIndex + double(L.isDouble);
                else
                    L.color   = [0 0 0];
                    L.sortKey = 3000 + 10 * L.figure;
                end
                L.fadedColor = cfg.fadedColor;
                if L.isDouble
                    L.lineStyle = '--';
                    L.marker    = 's';
                end
                if L.isHealthy
                    L.fadedLineStyle = cfg.healthyFadedStyles{healthyIndex};
                else
                    L.fadedLineStyle = L.lineStyle;
                end

                lineages(k) = L;
            end

            [~, order] = sort([lineages.sortKey]);
            lineages = lineages(order);
        end

        function lineages = attachSeries(lineages, quads, cfg)
            % MODEL: The plotted value per streak, for size and count (TERMINAL)
            % series(1) is colony size, series(2) is colony count. Under
            % 'relative' the value is log10 of the ratio to the lineage's
            % first streak. Under 'raw' it is the median radius in
            % micrometres and the colony count. A quadrant with no colonies
            % has no value on either metric in either mode.
            seriesTemplate = struct('value', []);
            isRaw = strcmp(cfg.scale, 'raw');

            for k = 1:numel(lineages)
                idx = lineages(k).quadIdx;
                S   = repmat(seriesTemplate, 1, 2);

                counts = [quads(idx).n];

                for m = 1:2
                    if m == 1
                        logv = [quads(idx).logMedian];
                    else
                        logv = nan(size(counts));
                        logv(counts > 0) = log10(counts(counts > 0));
                    end

                    if isRaw
                        if m == 1
                            raw = nan(size(logv));
                            raw(isfinite(logv)) = 10 .^ logv(isfinite(logv));
                        else
                            raw = nan(size(counts));
                            raw(counts > 0) = counts(counts > 0);
                        end
                        S(m).value = raw;
                    else
                        base = logv(find(isfinite(logv), 1));
                        if isempty(base)
                            S(m).value = nan(size(logv));
                        else
                            S(m).value = logv - base;
                        end
                    end
                end

                lineages(k).series = S;
            end
        end

        function pairs = buildAllelePairs(lineages, cfg)
            % MODEL: One panel per allele, single against double mutant (TERMINAL)
            % The background lineages are the wild type and rif1 grown on
            % the same plates, which are the healthy lineages of the same
            % figure.
            isHealthy = [lineages.isHealthy];
            alleleIdx = [lineages.alleleIndex];
            figs      = [lineages.figure];

            template = struct('label', '', 'figure', NaN, ...
                'mask', false(1, numel(lineages)), 'fadedMask', false(1, numel(lineages)));
            pairs = repmat(template, 1, 0);

            for a = 1:numel(cfg.alleleKeys)
                mask = ~isHealthy & alleleIdx == a;
                if ~any(mask)
                    continue;
                end
                members = find(mask);
                p = template;
                p.figure    = lineages(members(1)).figure;
                p.mask      = mask;
                p.fadedMask = isHealthy & figs == p.figure;
                p.label     = sprintf('%s (Fig %d)', ...
                    strjoin({lineages(members).displayBase}, '  vs  '), p.figure);
                pairs(end+1) = p; %#ok<AGROW>
            end
        end

        function axisSpec = buildAxisSpec(lineages, cfg)
            % SUB-CONTROLLER: One axis specification per metric row (models only)

            specs = cell(1, 2);
            for m = 1:2
                range  = computeMetricRange(lineages, m, cfg);
                ticks  = buildTickSpec(range, cfg);
                titles = buildPanelTitles(m, cfg);
                specs{m} = assembleAxisSpec(range, ticks, titles, cfg);
            end
            axisSpec = [specs{:}];

            function range = computeMetricRange(lineages, m, cfg)
                % MODEL: Limits, extinction row, wild type band, streak axis (TERMINAL)
                % Relative padding is in log units so the reference stays in
                % view. Raw padding is a fraction of the data range, and the
                % count axis is floored at zero.
                wtMask = [lineages.healthyIndex] == 1;

                allV = [];
                wtV  = [];
                for k = 1:numel(lineages)
                    v = lineages(k).series(m).value;
                    v = v(isfinite(v));
                    allV = [allV, v]; %#ok<AGROW>
                    if wtMask(k)
                        wtV = [wtV, v]; %#ok<AGROW>
                    end
                end

                range = struct();
                gens = unique([lineages.generations]);
                range.generations = gens;
                range.xLimits     = [min(gens) - 10, max(gens) + 10];
                range.isRaw       = strcmp(cfg.scale, 'raw');

                if range.isRaw
                    if isempty(allV)
                        allV = [0 1];
                    end
                    lo = min(allV);
                    hi = max(allV);
                    if m == 2
                        lo = 0;
                    end
                    spanV = hi - lo;
                    if spanV <= 0
                        spanV = max(abs(hi), 1);
                    end
                    if m == 2
                        hi = hi + 0.07 * spanV;
                    else
                        lo = lo - 0.10 * spanV;
                        hi = hi + 0.07 * spanV;
                    end
                    range.yLimits  = [lo, hi];
                    range.extinctY = lo + 0.05 * (hi - lo);
                else
                    lo = min([allV, 0]) - 0.07;
                    hi = max([allV, 0]) + 0.05;
                    range.yLimits  = [lo, hi];
                    range.extinctY = lo + 0.035;
                end

                range.wtBand = [NaN NaN];
                if ~isempty(wtV)
                    range.wtBand = [min(wtV), max(wtV)];
                end
            end

            function ticks = buildTickSpec(range, cfg)
                % MODEL: Y ticks and their labels (TERMINAL)
                % Relative ticks sit at fixed ratios so the percent labels
                % read directly off a log axis. Raw mode returns no ticks,
                % which leaves the axis on automatic.
                ticks = struct('yTicks', [], 'yTickLabels', {{}});

                if strcmp(cfg.scale, 'raw')
                    return;
                end

                lo = range.yLimits(1);
                hi = range.yLimits(2);

                ratios  = [0.1 0.25 0.5 0.75 1 1.5 2 3];
                tickPos = log10(ratios);
                keep    = tickPos >= lo & tickPos <= hi;
                ratios  = ratios(keep);
                tickPos = tickPos(keep);

                tickLabels = cell(1, numel(ratios));
                for t = 1:numel(ratios)
                    pct = round((ratios(t) - 1) * 100);
                    if pct == 0
                        tickLabels{t} = '0%';
                    else
                        tickLabels{t} = sprintf('%+d%%', pct);
                    end
                end

                ticks.yTicks      = tickPos;
                ticks.yTickLabels = tickLabels;
            end

            function titles = buildPanelTitles(m, cfg)
                % MODEL: Titles and axis label for one metric row (TERMINAL)
                % Panel letters are assigned per figure, so they are not
                % built here.
                delta = char(916);
                um    = [char(181) 'm'];

                metricShort = {'colony size', 'colony count'};

                if strcmp(cfg.scale, 'raw')
                    yLabels = {sprintf('Median colony radius (%s)', um), ...
                               'Colony count'};
                else
                    yLabels = {'Median colony radius, change from first streak', ...
                               'Colony count, change from first streak'};
                end

                titles = struct();
                titles.yLabel       = yLabels{m};
                titles.healthyTitle = sprintf('Wild type and rif1%s, %s', ...
                    delta, metricShort{m});
                titles.singlesTitle = sprintf('Telomerase-deficient single mutants, %s', ...
                    metricShort{m});
            end

            function spec = assembleAxisSpec(range, ticks, titles, cfg)
                % MODEL: Collect one row's axis specification (TERMINAL)
                spec = struct();
                spec.yLimits      = range.yLimits;
                spec.yTicks       = ticks.yTicks;
                spec.yTickLabels  = ticks.yTickLabels;
                spec.extinctY     = range.extinctY;
                spec.yLabel       = titles.yLabel;
                spec.healthyTitle = titles.healthyTitle;
                spec.singlesTitle = titles.singlesTitle;
                spec.wtBand       = range.wtBand;
                spec.wtBandColor  = cfg.wtBandColor;
                spec.bandLabels   = {'Wild type range'};
                spec.generations  = range.generations;
                spec.xLimits      = range.xLimits;
                spec.showKeys     = true;
            end
        end

        function figures = buildFigureSpecs(pairs, axisSpec, cfg)
            % MODEL: Two figure grids, each with its own panels and letters (TERMINAL)
            % Figure 1 holds the healthy lineages and the single mutants.
            % Figure 2 holds one panel per allele. Each figure has one row
            % per metric, count on top, and letters run in reading order
            % within the figure, so both start at A. A run with no allele
            % pairs produces figure 1 alone.
            rowOrder = [2 1];

            if strcmp(cfg.scale, 'raw')
                scaleText = 'measured values';
            else
                scaleText = 'change from first streak';
            end

            panelTemplate = struct('kind', '', 'metric', NaN, 'pairIndex', NaN, ...
                'tile', NaN, 'letter', '', 'title', '', 'yLabel', '');
            figTemplate = struct('name', '', 'title', '', 'rows', 0, 'cols', 0, ...
                'position', [40 40 1240 940], 'panels', repmat(panelTemplate, 1, 0));

            figures = repmat(figTemplate, 1, 0);

            f = figTemplate;
            f.name     = 'Senescence decline, lineages';
            f.title    = sprintf('Senescent single mutants and non-senescent controls, %s', ...
                                 scaleText);
            f.rows     = numel(rowOrder);
            f.cols     = 2;
            f.position = [40 110 1240 940];

            panels = repmat(panelTemplate, 1, 0);
            tile   = 0;
            for r = 1:numel(rowOrder)
                m = rowOrder(r);

                tile = tile + 1;
                q = panelTemplate;
                q.kind   = 'healthy';
                q.metric = m;
                q.tile   = tile;
                q.title  = axisSpec(m).healthyTitle;
                q.yLabel = axisSpec(m).yLabel;
                panels(end+1) = q; %#ok<AGROW>

                tile = tile + 1;
                q = panelTemplate;
                q.kind   = 'singles';
                q.metric = m;
                q.tile   = tile;
                q.title  = axisSpec(m).singlesTitle;
                q.yLabel = axisSpec(m).yLabel;
                panels(end+1) = q; %#ok<AGROW>
            end
            for k = 1:numel(panels)
                panels(k).letter = char('A' + k - 1);
            end
            f.panels = panels;
            figures(end+1) = f;

            if isempty(pairs)
                return;
            end

            f = figTemplate;
            f.name     = sprintf('Senescent alleles, %s pairs', cfg.modifierKey);
            f.title    = sprintf('Senescent alleles, with and without  %s, %s', ...
                                 cfg.modifierKey, scaleText);
            f.rows     = numel(rowOrder);
            f.cols     = numel(pairs);
            f.position = [130 40 1240 940];

            panels = repmat(panelTemplate, 1, 0);
            tile   = 0;
            for r = 1:numel(rowOrder)
                m = rowOrder(r);
                for p = 1:numel(pairs)
                    tile = tile + 1;
                    q = panelTemplate;
                    q.kind      = 'pair';
                    q.metric    = m;
                    q.pairIndex = p;
                    q.tile      = tile;
                    q.title     = pairs(p).label;
                    q.yLabel    = axisSpec(m).yLabel;
                    panels(end+1) = q; %#ok<AGROW>
                end
            end
            for k = 1:numel(panels)
                panels(k).letter = char('A' + k - 1);
            end
            f.panels = panels;
            figures(end+1) = f;
        end

        function extinctions = buildExtinctionMarks(lineages, axisSpec)
            % MODEL: Position of each extinction mark and its connector, per row (TERMINAL)
            markTemplate = struct('lineageIndex', NaN, 'x', NaN, 'y', NaN, ...
                                  'fromX', NaN, 'fromY', NaN, 'color', [0 0 0]);
            extinctions = repmat(struct('marks', repmat(markTemplate, 1, 0)), 1, numel(axisSpec));

            for m = 1:numel(axisSpec)
                marks = repmat(markTemplate, 1, 0);
                for k = 1:numel(lineages)
                    L = lineages(k);
                    if ~isfinite(L.extinctAt)
                        continue;
                    end
                    v = L.series(m).value;
                    e = markTemplate;
                    e.lineageIndex = k;
                    e.x     = L.extinctAt;
                    e.y     = axisSpec(m).extinctY;
                    e.color = L.color;
                    before  = find(isfinite(v) & L.generations < L.extinctAt, 1, 'last');
                    if ~isempty(before)
                        e.fromX = L.generations(before);
                        e.fromY = v(before);
                    end
                    marks(end+1) = e; %#ok<AGROW>
                end
                extinctions(m).marks = marks;
            end
        end

        function healthyLegend = buildHealthyLegend(lineages)
            % MODEL: One key entry per healthy genotype (TERMINAL)
            template = struct('label', '', 'color', [0 0 0], 'marker', 'o', 'lineStyle', '-');
            healthyLegend = repmat(template, 1, 0);
            seen = {};
            for k = 1:numel(lineages)
                L = lineages(k);
                if ~L.isHealthy || any(strcmp(seen, L.genotype))
                    continue;
                end
                seen{end+1} = L.genotype; %#ok<AGROW>
                entry = template;
                entry.label     = L.displayBase;
                entry.color     = L.color;
                entry.marker    = L.marker;
                entry.lineStyle = L.lineStyle;
                healthyLegend(end+1) = entry; %#ok<AGROW>
            end
        end

        function model = packModel(cfg, lineages, pairs, axisSpec, figures, extinctions, healthyLegend)
            % MODEL: Assemble the returned struct (TERMINAL)
            model = struct();
            model.cfg           = cfg;
            model.scale         = cfg.scale;
            model.lineages      = lineages;
            model.healthyMask   = [lineages.isHealthy];
            model.wtMask        = [lineages.healthyIndex] == 1;
            model.singleMask    = [lineages.isSingle];
            model.pairs         = pairs;
            model.axisSpec      = axisSpec;
            model.figures       = figures;
            model.extinctions   = extinctions;
            model.healthyLegend = healthyLegend;
            model.wtLabel       = 'Wild type';
            wtIdx = find([lineages.healthyIndex] == 1, 1);
            if ~isempty(wtIdx)
                model.wtLabel = lineages(wtIdx).displayBase;
            end
        end
    end

    % === RENDER SUB-CONTROLLER (views only) ===

    function renderDeclineFigures(model)
        % SUB-CONTROLLER: One window per figure spec, then its panels in order

        for f = 1:numel(model.figures)
            figSpec = model.figures(f);
            tl = createDeclineFigure(figSpec);
            for q = 1:numel(figSpec.panels)
                panel = figSpec.panels(q);
                switch panel.kind
                    case 'healthy'
                        drawHealthyPanel(tl, model, panel);
                    case 'singles'
                        drawSinglesPanel(tl, model, panel);
                    case 'pair'
                        drawPairPanel(tl, model, panel);
                end
            end
        end

        function tl = createDeclineFigure(figSpec)
            % VIEW: Figure window and tile grid (TERMINAL)
            fig = figure('Name', figSpec.name, 'NumberTitle', 'off', ...
                         'Color', 'w', 'Position', figSpec.position);
            tl = tiledlayout(fig, figSpec.rows, figSpec.cols, ...
                             'TileSpacing', 'compact', 'Padding', 'compact');
            title(tl, figSpec.title, 'FontWeight', 'bold');
        end

        function drawHealthyPanel(tl, model, panel)
            % SUB-CONTROLLER: Healthy lineages over the wild type band

            spec = model.axisSpec(panel.metric);
            ax = createPanelAxes(tl, panel.tile);
            bandHandles = drawBands(ax, spec);
            drawLineageLines(ax, model.lineages, model.healthyMask, 'color', 'lineStyle', 1.4, panel.metric);
            if spec.showKeys
                addHealthyLegend(ax, model.healthyLegend, bandHandles, spec.bandLabels);
            end
            formatPanelAxis(ax, spec, panel.title, panel.yLabel);
            drawPanelLetter(ax, panel.letter);

            function addHealthyLegend(ax, entries, bandHandles, bandLabels)
                % VIEW: One key entry per healthy genotype, then the wild type band (TERMINAL)
                h = gobjects(1, numel(entries));
                for k = 1:numel(entries)
                    e = entries(k);
                    h(k) = plot(ax, NaN, NaN, 'Color', e.color, 'LineStyle', e.lineStyle, ...
                        'LineWidth', 1.4, 'Marker', e.marker, 'MarkerSize', 5, ...
                        'MarkerFaceColor', e.color, 'MarkerEdgeColor', e.color);
                end
                labels = {entries.label};
                if ~isempty(bandHandles)
                    h      = [h, bandHandles];
                    labels = [labels, bandLabels];
                end
                if ~isempty(h)
                    legend(ax, h, labels, 'Location', 'southwest', 'Box', 'off', ...
                        'FontSize', 16, 'Interpreter', 'none');
                end
            end
        end

        function drawSinglesPanel(tl, model, panel)
            % SUB-CONTROLLER: Single mutants over faded wild type lineages

            spec = model.axisSpec(panel.metric);
            ax = createPanelAxes(tl, panel.tile);
            drawBands(ax, spec);
            hWt = drawLineageLines(ax, model.lineages, model.wtMask, 'fadedColor', 'fadedLineStyle', 1.0, panel.metric);
            [h, labels] = drawLineageLines(ax, model.lineages, model.singleMask, 'color', 'lineStyle', 2.0, panel.metric);
            drawExtinctionMarks(ax, model.extinctions(panel.metric).marks, model.singleMask);
            formatPanelAxis(ax, spec, panel.title, panel.yLabel);
            drawPanelLetter(ax, panel.letter);
            if spec.showKeys
                % The faded wild type lineages share one styling, so one
                % handle stands for all of them.
                if ~isempty(hWt)
                    addLineageLegend(ax, [h, hWt(1)], [labels, {model.wtLabel}]);
                else
                    addLineageLegend(ax, h, labels);
                end
            end
        end

        function drawPairPanel(tl, model, panel)
            % SUB-CONTROLLER: One allele's single and double mutant over its plates' healthy lineages

            spec = model.axisSpec(panel.metric);
            pair = model.pairs(panel.pairIndex);
            ax = createPanelAxes(tl, panel.tile);
            drawBands(ax, spec);
            [hFaded, lFaded] = drawLineageLines(ax, model.lineages, pair.fadedMask, 'fadedColor', 'fadedLineStyle', 1.2, panel.metric);
            [h, labels] = drawLineageLines(ax, model.lineages, pair.mask, 'color', 'lineStyle', 2.0, panel.metric);
            drawExtinctionMarks(ax, model.extinctions(panel.metric).marks, pair.mask);
            formatPanelAxis(ax, spec, panel.title, panel.yLabel);
            drawPanelLetter(ax, panel.letter);
            if spec.showKeys
                addLineageLegend(ax, [h, hFaded], [labels, lFaded]);
            end
        end
    end

    % === SHARED FUNCTIONS (2+ call sites) ===

    function ax = createPanelAxes(tl, tileIndex)
        % VIEW: Tile at a given position, with hold on (TERMINAL)
        % Called by all three panel sub-controllers.
        ax = nexttile(tl, tileIndex);
        hold(ax, 'on');
    end

    function drawPanelLetter(ax, letter)
        % VIEW: Bold serif panel letter in the top left corner (TERMINAL)
        % Called by all three panel sub-controllers. Legends sit southwest,
        % so the corner stays clear.
        text(ax, 0.015, 0.985, letter, ...
            'Units', 'normalized', ...
            'FontName', 'Times New Roman', ...
            'FontWeight', 'bold', ...
            'FontSize', 15, ...
            'HorizontalAlignment', 'left', ...
            'VerticalAlignment', 'top', ...
            'Interpreter', 'none', ...
            'HandleVisibility', 'off');
    end

    function h = drawBands(ax, spec)
        % VIEW: Wild type band across the full streak axis (TERMINAL)
        % Called by every line panel. Returns the band handle for the
        % healthy panel legend.
        h  = gobjects(0);
        xl = spec.xLimits;
        if all(isfinite(spec.wtBand))
            wt = spec.wtBand;
            h = patch(ax, [xl(1), xl(2), xl(2), xl(1)], [wt(1), wt(1), wt(2), wt(2)], ...
                spec.wtBandColor, 'EdgeColor', 'none', 'FaceAlpha', 0.18);
        end
    end

    function [h, labels] = drawLineageLines(ax, lineages, mask, colorField, styleField, lineWidth, m)
        % VIEW: One line per selected lineage on metric m (TERMINAL)
        % Called for background and foreground lineages in every line panel.
        % colorField and styleField select foreground or faded styling.
        h = gobjects(0);
        labels = {};
        for k = find(mask)
            L   = lineages(k);
            v   = L.series(m).value;
            fin = isfinite(v);
            if ~any(fin)
                continue;
            end
            c = L.(colorField);
            h(end+1) = plot(ax, L.generations(fin), v(fin), 'Color', c, ...
                'LineStyle', L.(styleField), 'LineWidth', lineWidth, 'Marker', L.marker, ...
                'MarkerSize', 5, 'MarkerFaceColor', c, 'MarkerEdgeColor', c); %#ok<AGROW>
            labels{end+1} = L.display; %#ok<AGROW>
        end
    end

    function drawExtinctionMarks(ax, marks, mask)
        % VIEW: Dotted connector and x at the streak with no colonies (TERMINAL)
        % Called by the singles and pair panels, for the lineages each shows.
        % The label is anchored at the marker and runs rightward, so the
        % padding sits at the front of the string.
        for k = 1:numel(marks)
            e = marks(k);
            if ~mask(e.lineageIndex)
                continue;
            end
            if isfinite(e.fromX)
                plot(ax, [e.fromX, e.x], [e.fromY, e.y], ':', ...
                    'Color', e.color, 'LineWidth', 1.5, 'HandleVisibility', 'off');
            end
            plot(ax, e.x, e.y, 'x', 'Color', e.color, 'MarkerSize', 13, ...
                'LineWidth', 2.2, 'HandleVisibility', 'off');
            text(ax, e.x, e.y, '   extinct', 'Color', e.color, 'FontSize', 9, ...
                'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle');
        end
    end
    function addLineageLegend(ax, h, labels)
        % VIEW: Legend listing the lineages drawn in a panel (TERMINAL)
        % Called by the singles and pair panels.
        if ~isempty(h)
            legend(ax, h, labels, 'Location', 'southwest', 'Box', 'off', ...
                'FontSize', 13, 'Interpreter', 'none');
        end
    end

    function formatPanelAxis(ax, spec, titleText, yLabelText)
        % VIEW: Shared limits, ticks, and labels for every line panel of a row (TERMINAL)
        % An empty yTicks leaves the y axis on automatic ticks, which is how
        % raw mode is drawn.
        xlim(ax, spec.xLimits);
        ylim(ax, spec.yLimits);
        if isempty(spec.yTicks)
            set(ax, 'XTick', spec.generations, 'YTickMode', 'auto', ...
                'YTickLabelMode', 'auto', 'TickLabelInterpreter', 'none', 'Layer', 'top');
        else
            set(ax, 'XTick', spec.generations, 'YTick', spec.yTicks, ...
                'YTickLabel', spec.yTickLabels, 'TickLabelInterpreter', 'none', 'Layer', 'top');
        end
        xlabel(ax, 'Generations','FontSize',16);
        ylabel(ax, yLabelText,'FontSize',16);
        title(ax, titleText, 'FontWeight', 'normal', 'Interpreter', 'none', 'FontSize',16);
        grid(ax, 'off');
        box(ax, 'on');
        hold(ax, 'off');
    end
end
% Rescue Dataset
function results = BeautifulFigure(Part3CompleteData, selectionDatasets, overlays)
    % CONTROLLER: Generate central Part 3 figure with statistically-derived
    % annotations per genotype. Each genotype receives its own analysis
    % matched to its biological claim:
    %   - dbf4-1: pooled high/low component coordinates (stable bimodal boxes)
    %   - cdc13-2: per-passage geometric mean of dominant components
    %     (single descending senescence trajectory)
    %   - Double: per-passage BIC model selection between k=1 and k=2 GMM
    %     fits on dominant component positions (bifurcating trajectory)
    %
    % Wild type receives no overlay; the chapter's annotations are about
    % the mutant signatures only.
    %
    % Plate eligibility is delegated to the shared QC inclusion predicates,
    % so the figure pool is the QC-eligible set. selectionDatasets is the
    % struct returned by CountDatasetGenerator. Plates in its Dataset1 grid
    % are drawn opaque while the rest of each crowding sweep is faded back
    % (see the emphasis tweak block in drawSinglePlateRow). Selections are
    % matched to figure rows by filename. When selectionDatasets is omitted
    % or empty, CountDatasetGenerator runs on Part3CompleteData with its
    % default target.
    %
    % CountDatasetGenerator draws from its own pool (6-day Standard, Rep A
    % or B, separable), which differs from the QC pool. A selected plate
    % excluded by QC, or kept by QC without a usable mixture fit, has no row
    % to highlight. The coverage check after plotting lists each such plate
    % and raises a warning for it.
    %
    % Figure orientation: plate rows run left to right along the x axis,
    % grouped by genotype and passage with labels in the bottom gutter, and
    % component median radius runs up the log-scaled y axis. A legend in
    % the left margin decodes circle size (component weight), selected vs
    % faded plates, the IQR whisker, and whichever overlays are drawn.
    % Glyph styling and panel geometry live in getComponentStyle.
    %
    % overlays selects between two overlay families and the plate set
    % through a struct with optional logical fields. Omitted or empty fields
    % keep their defaults.
    %   trajectory (default true): the trajectory overlay. Each highlighted
    %     plate contributes one or two subpopulation nodes (its LogNormal
    %     components at or above 0.01 weight, renormalized to sum to 1). With
    %     two nodes, the larger median is the large class. Consecutive
    %     generations connect large to large and small to small; a single
    %     node converges or diverges with its neighbor. A passage with no
    %     highlighted row is bridged with dotted lines. Lines take the
    %     genotype color, and line width scales with the mean weight of the
    %     two connected nodes. Applies to all four genotypes.
    %   manual (default false): the manual annotation overlay (dbf4-1 IQR
    %     boxes, cdc13-2 trajectory, Double bifurcation). Its fields dbf4,
    %     cdc13, and double (each default true) select which of the three
    %     manual annotations draw when manual is on.
    %   selectedOnly (default false): draw only the Dataset1 selections.
    %     Each cluster collapses to its highlighted row, and a cluster with
    %     no selection drops out along with its bracket and passage label.
    %     Statistics and the coverage check are unaffected.
    % Examples: struct('manual', true) draws both families;
    % struct('trajectory', false) draws neither; struct('selectedOnly',
    % true) draws only the selected plates, with trajectory lines. Toggling
    % is display-only: every analysis still runs, still prints, and still
    % lands in results, with the trajectory segments in results.trajectory.

    if nargin < 2 || isempty(selectionDatasets)
        selectionDatasets = CountDatasetGenerator(Part3CompleteData);
    end
    if nargin < 3
        overlays = struct();
    end
    overlayToggles = normalizeOverlayToggles(overlays);

    plateSet     = filterAnalysisPlates(Part3CompleteData);
    dataset1Keys = buildSelectionKeys(selectionDatasets);

    printSectionHeader('Mixture decomposition with statistically backed annotations');
    results = runShapeDecompositionAnalysis(plateSet, dataset1Keys, overlayToggles);

    coverage = checkSelectionCoverage(dataset1Keys, plateSet, results.layout);
    reportSelectionCoverage(coverage);
    results.selectionCoverage = coverage;

    proveDbf4Discrimination(results.decompData);

    % === SHARED HELPERS ===

    function toggles = normalizeOverlayToggles(overlays)
        % MODEL (TERMINAL): fill the overlay toggle struct with defaults so
        % the rest of the figure always sees logical trajectory, manual,
        % dbf4, cdc13, double, and selectedOnly fields. Defaults: trajectory
        % on, manual off, the three manual sub-toggles on, and selectedOnly
        % off. A missing, empty, or non-struct input keeps every default;
        % any field present overrides its default. A field absent from the
        % defaults below is ignored.
        toggles = struct('trajectory', true, 'manual', false, ...
                         'dbf4', true, 'cdc13', true, 'double', true, ...
                         'selectedOnly', false);
        if isempty(overlays) || ~isstruct(overlays)
            return;
        end
        fn = fieldnames(toggles);
        for k = 1:numel(fn)
            if isfield(overlays, fn{k}) && ~isempty(overlays.(fn{k}))
                toggles.(fn{k}) = logical(overlays.(fn{k}));
            end
        end
    end

    function plateSet = filterAnalysisPlates(Part3Data)
        % MODEL CONTROLLER: Filter to QC-eligible plates by delegating to the
        % shared QC inclusion predicates. Each composite entry is gated by
        % QC.evaluatePart3Inclusion with okColony dropped (a plate missing
        % its aligned crowding vector is still a valid analysis plate). The
        % cdc13-2 P4 carveout falls out on its own: the source exception
        % admits the large-enriched plate and the collapsed Standard plate is
        % Excluded. Calls QC model terminals and the nested datasetEligible
        % terminal.
        config = QC.buildConfig();
        C   = Part3Data.composite;
        raw = QC.extractPart3Fields(Part3Data, config);

        keepMask = false(1, numel(C));
        for i = 1:numel(raw)
            crit = QC.evaluatePart3Inclusion(raw(i), true, config);
            keepMask(i) = datasetEligible(crit);
        end
        plateSet = C(keepMask);

        function tf = datasetEligible(crit)
            % MODEL (TERMINAL): AND every inclusion predicate except
            % okColony. Iterating the fields keeps this in step with
            % whatever QC.evaluatePart3Inclusion returns.
            applied = crit;
            if isfield(applied, 'okColony')
                applied = rmfield(applied, 'okColony');
            end
            tf = true;
            fn = fieldnames(applied);
            for k = 1:numel(fn)
                tf = tf && applied.(fn{k});
            end
        end
    end

    function keys = buildSelectionKeys(datasets)
        % MODEL (TERMINAL): one key per filled cell of the Dataset1 grid in
        % the supplied datasets struct. The filename is the match key;
        % genotype and passage ride along for the coverage report. The
        % dataset generator owns the selection, so the highlight cannot
        % drift from the dataset.
        if ~isstruct(datasets) || ~isfield(datasets, 'Dataset1')
            error('BeautifulFigure:noDataset1', ...
                  'selectionDatasets must be a struct with a Dataset1 grid.');
        end
        selGrid    = datasets.Dataset1;
        gridFields = {'wild_type', 'dbf4_1', 'cdc13_2', 'double'};
        keys = struct('genotype', {}, 'passage', {}, 'filename', {});
        for p = 1:numel(selGrid)
            for fi = 1:numel(gridFields)
                entry = selGrid(p).(gridFields{fi});
                if isempty(entry); continue; end
                key.genotype = char(entry.genotype);
                key.passage  = double(entry.passage);
                key.filename = char(entry.filename);
                keys(end+1) = key; %#ok<AGROW>
            end
        end
    end

    function printSectionHeader(title)
        % VIEW: Print section header to command window (TERMINAL)
        fprintf('\n');
        fprintf('================================================================\n');
        fprintf('  %s\n', title);
        fprintf('================================================================\n');
    end

    function coverage = checkSelectionCoverage(keys, plateSet, layout)
        % MODEL (TERMINAL): classify every Dataset1 selection by whether the
        % figure drew a highlighted row for it. 'drawn' means a highlighted
        % row exists; 'noMixtureFit' means QC kept the plate but it had no
        % usable LogNormal decomposition, so no row was built; 'notInQCPool'
        % means QC inclusion removed the plate. nHighlightedRows counts
        % highlighted rows in the layout; a value above nDrawn means a
        % selected filename matched more than one plate.
        poolNames = cell(1, numel(plateSet));
        for i = 1:numel(plateSet)
            poolNames{i} = char(plateSet(i).filename);
        end

        drawnNames = {};
        for ci = 1:numel(layout.clusters)
            recs = layout.clusters(ci).records;
            for ri = 1:numel(recs)
                if recs(ri).isDataset1
                    drawnNames{end+1} = recs(ri).filename; %#ok<AGROW>
                end
            end
        end

        nKeys = numel(keys);
        coverage.genotype = cell(1, nKeys);
        coverage.passage  = nan(1, nKeys);
        coverage.filename = cell(1, nKeys);
        coverage.status   = cell(1, nKeys);
        for ki = 1:nKeys
            coverage.genotype{ki} = keys(ki).genotype;
            coverage.passage(ki)  = keys(ki).passage;
            coverage.filename{ki} = keys(ki).filename;
            if any(strcmp(keys(ki).filename, drawnNames))
                coverage.status{ki} = 'drawn';
            elseif any(strcmp(keys(ki).filename, poolNames))
                coverage.status{ki} = 'noMixtureFit';
            else
                coverage.status{ki} = 'notInQCPool';
            end
        end
        coverage.nSelected        = nKeys;
        coverage.nDrawn           = sum(strcmp(coverage.status, 'drawn'));
        coverage.nHighlightedRows = numel(drawnNames);
    end

    function reportSelectionCoverage(coverage)
        % VIEW (TERMINAL): print how many Dataset1 selections received a
        % highlighted row, list each selection without one and the reason,
        % and warn for each, so a missing highlight is never silent.
        fprintf('\nDataset1 highlight coverage: %d of %d selected plates drawn.\n', ...
                coverage.nDrawn, coverage.nSelected);
        for ki = 1:coverage.nSelected
            switch coverage.status{ki}
                case 'notInQCPool'
                    reason = 'excluded by QC inclusion';
                case 'noMixtureFit'
                    reason = 'kept by QC, no usable LogNormal decomposition';
                otherwise
                    continue;
            end
            fprintf('  %-10s P%d  %s  (%s)\n', coverage.genotype{ki}, ...
                    coverage.passage(ki), coverage.filename{ki}, reason);
            warning('BeautifulFigure:selectionNotDrawn', ...
                    '%s P%d (%s): %s; no highlighted row.', ...
                    coverage.genotype{ki}, coverage.passage(ki), ...
                    coverage.filename{ki}, reason);
        end
        if coverage.nHighlightedRows > coverage.nDrawn
            fprintf(['  %d highlighted rows for %d drawn selections: a ' ...
                     'selected filename matches more than one plate.\n'], ...
                    coverage.nHighlightedRows, coverage.nDrawn);
            warning('BeautifulFigure:duplicateFilename', ...
                    '%d highlighted rows for %d drawn selections; filenames are not unique.', ...
                    coverage.nHighlightedRows, coverage.nDrawn);
        end
        fprintf('\n');
    end

    % === SUB-CONTROLLER ===

    function out = runShapeDecompositionAnalysis(plateSet, dataset1Keys, overlayToggles)
        % SUB-CONTROLLER: Orchestrate shared decomposition, per-genotype
        % statistical analyses, and figure plotting with overlays. Returns
        % the plot layout so the caller can check highlight coverage, and
        % the trajectory segments built from the highlighted plates.

        decompData = collectMixtureComponents(plateSet, dataset1Keys);
        reportDecompositionResults(decompData);

        out.dbf4Stats   = analyzeDbf4Signature(decompData);
        out.cdc13Stats  = analyzeCdc13Trajectory(decompData);
        out.doubleStats = analyzeDoubleBifurcation(decompData);

        [out.layout, out.trajectory] = plotComponentLocations(decompData, ...
                                            out.dbf4Stats, out.cdc13Stats, ...
                                            out.doubleStats, overlayToggles);

        out.decompData = decompData;

        % === SHARED DATA COLLECTION ===

        function dData = collectMixtureComponents(plateSet, dataset1Keys)
            % MODEL CONTROLLER: Pull LogNormal mixture assignments and
            % compute per-component radius statistics. Each record also
            % carries its colony count (the cluster sort key), its filename
            % (the Dataset1 match key), and an isDataset1 flag set by
            % testing the filename against the Dataset1 selection. Calls
            % computeComponentStats and the nested matchesDataset1 terminal.
            genotypes = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
            dData.genotypes  = genotypes;
            dData.byGenotype = cell(1, numel(genotypes));

            for gi = 1:numel(genotypes)
                mask = strcmp({plateSet.genotype}, genotypes{gi});
                plates = plateSet(mask);

                records = struct('plateIdx', {}, 'passage', {}, 'hce', {}, ...
                                 'colony_count', {}, 'filename', {}, ...
                                 'isDataset1', {}, ...
                                 'nKde', {}, 'nLogNormal', {}, ...
                                 'componentMedians', {}, 'componentWeights', {}, ...
                                 'componentP25', {}, 'componentP75', {});

                for pIdx = 1:numel(plates)
                    e = plates(pIdx);
                    rec.plateIdx     = pIdx;
                    rec.passage      = e.passage;
                    rec.hce          = e.hce;
                    rec.colony_count = double(e.colony_count);
                    rec.filename     = char(e.filename);
                    rec.isDataset1   = matchesDataset1(rec.filename, dataset1Keys);

                    if ~isempty(e.mode_detection) && ...
                       isfield(e.mode_detection, 'n_modes') && ...
                       isfinite(e.mode_detection.n_modes)
                        rec.nKde = e.mode_detection.n_modes;
                    else
                        rec.nKde = NaN;
                    end

                    [rec.nLogNormal, rec.componentMedians, ...
                     rec.componentWeights, rec.componentP25, rec.componentP75] = ...
                        computeComponentStats(e);

                    records(end+1) = rec; %#ok<AGROW>
                end

                dData.byGenotype{gi} = records;
            end

            function tf = matchesDataset1(filename, keys)
                % MODEL (TERMINAL): is this plate one of the Dataset1
                % selections, by filename?
                tf = any(strcmp(filename, {keys.filename}));
            end
        end

        function [k, medians, weights, p25s, p75s] = computeComponentStats(entry)
            % MODEL: Hard-assign colonies to components, compute per-
            % component median, weight, P25, P75 in raw radius (TERMINAL)
            k = NaN; medians = []; weights = []; p25s = []; p75s = [];

            if isempty(entry.full_colony_set) || ...
               ~isfield(entry.full_colony_set, 'alternative_fits')
                return;
            end
            altFits = entry.full_colony_set.alternative_fits;
            if ~isfield(altFits, 'LogNormal')
                return;
            end
            lnFit = altFits.LogNormal;

            if isfield(lnFit, 'optimal_components')
                k = lnFit.optimal_components;
            end
            if isnan(k) || k < 1
                return;
            end

            if isempty(entry.Measurements) || ...
               ~isfield(entry.Measurements, 'Radius')
                return;
            end
            radii = entry.Measurements.Radius(:);
            radii = radii(isfinite(radii));

            if isempty(radii); return; end

            hardAssign = extractHardAssignments(lnFit, numel(radii));
            if isempty(hardAssign) || numel(hardAssign) ~= numel(radii)
                return;
            end

            medians = nan(1, k);
            weights = nan(1, k);
            p25s    = nan(1, k);
            p75s    = nan(1, k);
            for ci = 1:k
                compRadii = radii(hardAssign == ci);
                if ~isempty(compRadii)
                    medians(ci) = median(compRadii);
                    weights(ci) = numel(compRadii) / numel(radii);
                    p25s(ci)    = prctile(compRadii, 25);
                    p75s(ci)    = prctile(compRadii, 75);
                end
            end
        end

        function hardIDs = extractHardAssignments(lnFit, nExpected)
            % MODEL: Extract hard component assignments robust to format
            % variations (TERMINAL)
            hardIDs = [];

            if ~isfield(lnFit, 'gmm_results'); return; end
            gr = lnFit.gmm_results;
            if ~isfield(gr, 'component_assignments'); return; end
            ca = gr.component_assignments;

            if isnumeric(ca)
                if numel(ca) == nExpected && (isvector(ca) || size(ca, 2) == 1)
                    hardIDs = ca(:);
                    return;
                end
                if size(ca, 1) == nExpected && size(ca, 2) > 1
                    [~, hardIDs] = max(ca, [], 2);
                    return;
                end
            end

            if isstruct(ca)
                hardCandidates = {'hard', 'hard_assignments', 'cluster', ...
                                  'idx', 'labels'};
                for ci = 1:numel(hardCandidates)
                    if isfield(ca, hardCandidates{ci})
                        v = ca.(hardCandidates{ci});
                        if isnumeric(v) && numel(v) == nExpected
                            hardIDs = v(:);
                            return;
                        end
                    end
                end

                postCandidates = {'posterior', 'posteriors', 'P', ...
                                  'probabilities', 'soft'};
                for ci = 1:numel(postCandidates)
                    if isfield(ca, postCandidates{ci})
                        P = ca.(postCandidates{ci});
                        if isnumeric(P) && size(P, 1) == nExpected
                            [~, hardIDs] = max(P, [], 2);
                            return;
                        end
                    end
                end
            end
        end

        % === GENERAL DESCRIPTIVE REPORT ===

        function reportDecompositionResults(dData)
            % SUB-CONTROLLER: General descriptive output
            printGenotypeKSummary(dData);
            printMultiComponentDetails(dData);
            printLowestComponentSummary(dData);

            function printGenotypeKSummary(dData)
                % VIEW: Print k counts per genotype (TERMINAL)
                fprintf('LogNormal mixture decomposition (raw-radius stats):\n\n');
                fprintf('  Note: library_fit selected k=1 for all plates.\n');
                fprintf('  LogNormal-mixture k selections preserved as alternatives.\n\n');

                fprintf('  %-12s  %-12s  %s\n', 'Genotype', 'k=1/2/3+', 'mean k');
                for gi = 1:numel(dData.genotypes)
                    records = dData.byGenotype{gi};
                    kValues = [records.nLogNormal];
                    kValid  = kValues(isfinite(kValues));
                    if isempty(kValid)
                        fprintf('  %-12s  no data\n', dData.genotypes{gi});
                        continue;
                    end
                    n1  = sum(kValid == 1);
                    n2  = sum(kValid == 2);
                    n3p = sum(kValid >= 3);
                    fprintf('  %-12s  %3d/%2d/%2d    %.2f\n', ...
                            dData.genotypes{gi}, n1, n2, n3p, mean(kValid));
                end
            end

            function printMultiComponentDetails(dData)
                % VIEW: Print per-plate component details for k>=2 plates
                % in WT and dbf4-1 (TERMINAL)
                fprintf('\nMulti-component plate details (k >= 2), WT and dbf4-1:\n');
                fprintf('Components listed as: median (weight), sorted by median.\n\n');

                for gi = 1:2
                    records = dData.byGenotype{gi};
                    multiIdx = find([records.nLogNormal] >= 2);
                    if isempty(multiIdx)
                        fprintf('  %s: no multi-component plates\n\n', ...
                                dData.genotypes{gi});
                        continue;
                    end

                    fprintf('  %s (%d plates):\n', dData.genotypes{gi}, ...
                            numel(multiIdx));
                    fprintf('    %3s  %6s  %5s  %4s  %s\n', ...
                            'P', 'HCE', 'k_KDE', 'k_LN', ...
                            'components: median (weight)');
                    for k = 1:numel(multiIdx)
                        r = records(multiIdx(k));
                        meds = r.componentMedians;
                        wts  = r.componentWeights;
                        if isempty(meds) || all(isnan(meds))
                            fprintf('    %3d  %6.1f  %5g  %4d  (unavailable)\n', ...
                                    r.passage, r.hce, r.nKde, r.nLogNormal);
                            continue;
                        end
                        valid = ~isnan(meds);
                        meds = meds(valid);
                        wts  = wts(valid);
                        [meds, sortIdx] = sort(meds);
                        wts = wts(sortIdx);
                        compStrs = arrayfun(@(m, w) sprintf('%4.0f (%.2f)', m, w), ...
                                            meds, wts, 'UniformOutput', false);
                        fprintf('    %3d  %6.1f  %5g  %4d  %s\n', ...
                                r.passage, r.hce, r.nKde, r.nLogNormal, ...
                                strjoin(compStrs, ', '));
                    end
                    fprintf('\n');
                end
            end

            function printLowestComponentSummary(dData)
                % VIEW: Print lowest-component summary (TERMINAL)
                fprintf('Lowest-component summary (k>=2 plates only):\n');
                fprintf('  Smallest-median component represents the shoulder.\n\n');

                for gi = 1:2
                    records = dData.byGenotype{gi};
                    multiIdx = find([records.nLogNormal] >= 2);
                    if isempty(multiIdx); continue; end

                    lowMeds = [];
                    lowWts  = [];
                    for k = 1:numel(multiIdx)
                        r = records(multiIdx(k));
                        meds = r.componentMedians;
                        wts  = r.componentWeights;
                        valid = ~isnan(meds);
                        if ~any(valid); continue; end
                        meds = meds(valid);
                        wts  = wts(valid);
                        [meds, sortIdx] = sort(meds);
                        wts = wts(sortIdx);
                        lowMeds(end+1) = meds(1); %#ok<AGROW>
                        lowWts(end+1)  = wts(1); %#ok<AGROW>
                    end

                    if isempty(lowMeds); continue; end
                    fprintf(['  %-12s  lowest-comp median: %4.0f um ' ...
                             '(range %4.0f - %4.0f), mean weight = %.2f\n'], ...
                            dData.genotypes{gi}, median(lowMeds), ...
                            min(lowMeds), max(lowMeds), mean(lowWts));
                end
            end
        end

        % === GENOTYPE-SPECIFIC STATISTICAL ANALYSES ===

        function stats = analyzeDbf4Signature(dData)
            % SUB-CONTROLLER: dbf4-1 bimodal structure characterization
            %
            % Biological claim: dbf4-1 produces a bimodal structure on most
            % plates. On k>=2 plates, the dominant (highest-weight) component
            % lives in a "large colony" band and shoulder (lower-weight)
            % components live in a "small colony" band. k=1 plates occupy a
            % middle zone between the two bands and are excluded from both
            % box calculations.
            %
            % Method: for each k>=2 dbf4-1 plate, apply a weight threshold
            % (>=0.10) to remove GMM artifact components representing very
            % small minorities. Among surviving components, the highest-weight
            % component enters the dominant pool; all others enter the
            % shoulder pool. Boxes are reported as the IQR of each pool. Per-
            % passage geometric means are checked against the pooled IQR as
            % a stability diagnostic.

            stats = computeDbf4Boxes(dData);
            reportDbf4Boxes(stats);

            function stats = computeDbf4Boxes(dData)
                % MODEL: Apply weight-rank classification with threshold,
                % compute IQR box coordinates and per-passage stability
                % (TERMINAL)
                records = dData.byGenotype{2};  % dbf4-1
                weightThreshold = 0.10;

                dominantMedians  = [];
                shoulderMedians  = [];
                dominantPassages = [];
                shoulderPassages = [];

                for ri = 1:numel(records)
                    r = records(ri);

                    % Skip k=1 plates entirely
                    if isnan(r.nLogNormal) || r.nLogNormal < 2
                        continue;
                    end
                    if isempty(r.componentMedians) || isempty(r.componentWeights)
                        continue;
                    end

                    meds = r.componentMedians;
                    wts  = r.componentWeights;

                    % Drop NaN components
                    valid = ~isnan(meds) & ~isnan(wts);
                    if ~any(valid); continue; end
                    meds = meds(valid);
                    wts  = wts(valid);

                    % Apply weight threshold
                    aboveThreshold = wts >= weightThreshold;
                    if ~any(aboveThreshold); continue; end
                    meds = meds(aboveThreshold);
                    wts  = wts(aboveThreshold);

                    % Classify surviving components by weight rank
                    [~, sortIdx] = sort(wts, 'descend');
                    meds = meds(sortIdx);

                    % Highest-weight survivor goes to dominant pool
                    dominantMedians(end+1)  = meds(1); %#ok<AGROW>
                    dominantPassages(end+1) = r.passage; %#ok<AGROW>

                    % Remaining survivors (if any) go to shoulder pool
                    for si = 2:numel(meds)
                        shoulderMedians(end+1)  = meds(si); %#ok<AGROW>
                        shoulderPassages(end+1) = r.passage; %#ok<AGROW>
                    end
                end

                stats.weightThreshold  = weightThreshold;
                stats.dominantMedians  = dominantMedians;
                stats.shoulderMedians  = shoulderMedians;
                stats.dominantPassages = dominantPassages;
                stats.shoulderPassages = shoulderPassages;
                stats.nDominantTotal   = numel(dominantMedians);
                stats.nShoulderTotal   = numel(shoulderMedians);

                if isempty(dominantMedians)
                    stats.dominantBox    = [NaN NaN];
                    stats.dominantMedian = NaN;
                    stats.dominantIQR    = [NaN NaN];
                else
                    stats.dominantIQR    = [prctile(dominantMedians, 25), ...
                                            prctile(dominantMedians, 75)];
                    stats.dominantBox    = stats.dominantIQR;
                    stats.dominantMedian = median(dominantMedians);
                end

                if isempty(shoulderMedians)
                    stats.shoulderBox    = [NaN NaN];
                    stats.shoulderMedian = NaN;
                    stats.shoulderIQR    = [NaN NaN];
                else
                    stats.shoulderIQR    = [prctile(shoulderMedians, 25), ...
                                            prctile(shoulderMedians, 75)];
                    stats.shoulderBox    = stats.shoulderIQR;
                    stats.shoulderMedian = median(shoulderMedians);
                end

                passages = 1:5;
                stats.passages               = passages;
                stats.dominantMeanByPassage  = nan(1, 5);
                stats.shoulderMeanByPassage  = nan(1, 5);
                stats.dominantCountByPassage = zeros(1, 5);
                stats.shoulderCountByPassage = zeros(1, 5);

                for pi = 1:5
                    domInP = dominantMedians(dominantPassages == passages(pi));
                    shoInP = shoulderMedians(shoulderPassages == passages(pi));
                    stats.dominantCountByPassage(pi) = numel(domInP);
                    stats.shoulderCountByPassage(pi) = numel(shoInP);
                    if ~isempty(domInP)
                        stats.dominantMeanByPassage(pi) = exp(mean(log(domInP)));
                    end
                    if ~isempty(shoInP)
                        stats.shoulderMeanByPassage(pi) = exp(mean(log(shoInP)));
                    end
                end

                % Stability check: per-passage geom means within pooled IQR
                dominantValid = ~isnan(stats.dominantMeanByPassage);
                if any(dominantValid) && all(isfinite(stats.dominantIQR))
                    stats.dominantStable = all( ...
                        stats.dominantMeanByPassage(dominantValid) >= stats.dominantIQR(1) & ...
                        stats.dominantMeanByPassage(dominantValid) <= stats.dominantIQR(2));
                else
                    stats.dominantStable = NaN;
                end

                shoulderValid = ~isnan(stats.shoulderMeanByPassage);
                if any(shoulderValid) && all(isfinite(stats.shoulderIQR))
                    stats.shoulderStable = all( ...
                        stats.shoulderMeanByPassage(shoulderValid) >= stats.shoulderIQR(1) & ...
                        stats.shoulderMeanByPassage(shoulderValid) <= stats.shoulderIQR(2));
                else
                    stats.shoulderStable = NaN;
                end
            end

            function reportDbf4Boxes(stats)
                % VIEW: Print dbf4-1 bimodal structure statistics (TERMINAL)
                fprintf('\n--- dbf4-1 BIMODAL STRUCTURE ---\n');
                fprintf('Claim: dbf4-1 produces a bimodal structure on k>=2 plates,\n');
                fprintf('with the majority (dominant) component in a large-colony\n');
                fprintf('band and minority (shoulder) components in a small-colony\n');
                fprintf('band. k=1 plates occupy the middle zone and are excluded.\n');
                fprintf('Method: classify k>=2 plate components by weight rank\n');
                fprintf('after applying a weight threshold (>= %.2f). Highest-weight\n', ...
                        stats.weightThreshold);
                fprintf('component enters dominant pool; remaining components enter\n');
                fprintf('shoulder pool. Boxes reported as pooled IQR. Stability check:\n');
                fprintf('per-passage geom means inside pooled IQR.\n\n');

                if isfinite(stats.dominantMedian)
                    fprintf('DOMINANT band (large-colony, majority components):\n');
                    fprintf('  n = %d components, pooled median = %.0f um\n', ...
                            stats.nDominantTotal, stats.dominantMedian);
                    fprintf('  Pooled IQR = [%.0f, %.0f] um  (figure overlay)\n', ...
                            stats.dominantIQR(1), stats.dominantIQR(2));
                    fprintf('  Per-passage geom means: ');
                    for pi = 1:5
                        if ~isnan(stats.dominantMeanByPassage(pi))
                            fprintf('P%d=%.0f (n=%d) ', pi, ...
                                    stats.dominantMeanByPassage(pi), ...
                                    stats.dominantCountByPassage(pi));
                        end
                    end
                    fprintf('\n');
                    if isequal(stats.dominantStable, true)
                        fprintf('  Stability: PASS (all per-passage means within pooled IQR)\n\n');
                    elseif isequal(stats.dominantStable, false)
                        fprintf('  Stability: FAIL (at least one passage outside pooled IQR)\n\n');
                    end
                end

                if isfinite(stats.shoulderMedian)
                    fprintf('SHOULDER band (small-colony, minority components):\n');
                    fprintf('  n = %d components, pooled median = %.0f um\n', ...
                            stats.nShoulderTotal, stats.shoulderMedian);
                    fprintf('  Pooled IQR = [%.0f, %.0f] um  (figure overlay)\n', ...
                            stats.shoulderIQR(1), stats.shoulderIQR(2));
                    fprintf('  Per-passage geom means: ');
                    for pi = 1:5
                        if ~isnan(stats.shoulderMeanByPassage(pi))
                            fprintf('P%d=%.0f (n=%d) ', pi, ...
                                    stats.shoulderMeanByPassage(pi), ...
                                    stats.shoulderCountByPassage(pi));
                        end
                    end
                    fprintf('\n');
                    if isequal(stats.shoulderStable, true)
                        fprintf('  Stability: PASS (all per-passage means within pooled IQR)\n\n');
                    elseif isequal(stats.shoulderStable, false)
                        fprintf('  Stability: FAIL (at least one passage outside pooled IQR)\n\n');
                    end
                end
            end
        end

        function stats = analyzeCdc13Trajectory(dData)
            % SUB-CONTROLLER: cdc13-2 senescence trajectory
            %
            % Biological claim: cdc13-2 produces a single, monotonically
            % descending trajectory in dominant component position across
            % passages. Statistic is per-passage geometric mean of dominant
            % (highest-weight) component medians.

            stats = computeCdc13Trajectory(dData);
            reportCdc13Trajectory(stats);

            function stats = computeCdc13Trajectory(dData)
                % MODEL: Per-passage geometric mean of dominant component
                % positions (TERMINAL)
                records = dData.byGenotype{3};  % cdc13-2
                passages = 1:5;

                stats.passages              = passages;
                stats.dominantByPassage     = nan(1, 5);
                stats.iqrLowByPassage       = nan(1, 5);
                stats.iqrHighByPassage      = nan(1, 5);
                stats.nPlatesByPassage      = zeros(1, 5);
                stats.allDominantPositions  = cell(1, 5);

                for pi = 1:5
                    doms = [];
                    for ri = 1:numel(records)
                        r = records(ri);
                        if r.passage ~= passages(pi); continue; end
                        if isnan(r.nLogNormal) || isempty(r.componentMedians)
                            continue;
                        end
                        meds = r.componentMedians;
                        wts  = r.componentWeights;
                        valid = ~isnan(meds);
                        if ~any(valid); continue; end
                        meds = meds(valid);
                        wts  = wts(valid);

                        % Dominant component = highest weight
                        [~, domIdx] = max(wts);
                        doms(end+1) = meds(domIdx); %#ok<AGROW>
                    end

                    if ~isempty(doms)
                        stats.dominantByPassage(pi) = exp(mean(log(doms)));
                        stats.iqrLowByPassage(pi)   = prctile(doms, 25);
                        stats.iqrHighByPassage(pi)  = prctile(doms, 75);
                        stats.nPlatesByPassage(pi)  = numel(doms);
                        stats.allDominantPositions{pi} = doms;
                    end
                end

                % Decline magnitude
                p1 = stats.dominantByPassage(1);
                p5 = stats.dominantByPassage(5);
                if isfinite(p1) && isfinite(p5)
                    stats.declineRatio   = p1 / p5;
                    stats.declineLog10   = log10(stats.declineRatio);
                else
                    stats.declineRatio   = NaN;
                    stats.declineLog10   = NaN;
                end

                % Monotonicity test (each passage <= previous)
                finiteVals = stats.dominantByPassage( ...
                    isfinite(stats.dominantByPassage));
                if numel(finiteVals) >= 2
                    stats.monotonicDecline = all(diff(finiteVals) <= 0);
                else
                    stats.monotonicDecline = NaN;
                end
            end

            function reportCdc13Trajectory(stats)
                % VIEW: Print cdc13-2 trajectory statistics (TERMINAL)
                fprintf('\n--- cdc13-2 SENESCENCE TRAJECTORY ---\n');
                fprintf('Claim: cdc13-2 produces a single, monotonically\n');
                fprintf('descending trajectory across passages.\n');
                fprintf('Method: per-passage geometric mean of dominant\n');
                fprintf('(highest-weight) component medians, one value per\n');
                fprintf('passage, connected through 5 trajectory points.\n\n');

                fprintf('Per-passage trajectory points (figure overlay):\n');
                fprintf('  %3s   %s   %s   %s\n', ...
                        'P', 'n plates', 'geom mean (um)', 'IQR [25, 75]');
                for pi = 1:5
                    if isfinite(stats.dominantByPassage(pi))
                        fprintf('  P%d    %3d        %6.0f         [%.0f, %.0f]\n', ...
                                pi, stats.nPlatesByPassage(pi), ...
                                stats.dominantByPassage(pi), ...
                                stats.iqrLowByPassage(pi), ...
                                stats.iqrHighByPassage(pi));
                    else
                        fprintf('  P%d    %3d        (no data)\n', ...
                                pi, stats.nPlatesByPassage(pi));
                    end
                end

                fprintf('\nDecline magnitude:\n');
                if isfinite(stats.declineRatio)
                    fprintf('  P1 / P5 ratio = %.2f (log10 = %.2f)\n', ...
                            stats.declineRatio, stats.declineLog10);
                    fprintf('  Dominant component is %.1fx smaller at P5 than P1.\n', ...
                            stats.declineRatio);
                end
                if isequal(stats.monotonicDecline, true)
                    fprintf('  Monotonicity: PASS (each passage <= previous)\n\n');
                elseif isequal(stats.monotonicDecline, false)
                    fprintf('  Monotonicity: FAIL (non-monotonic sequence)\n\n');
                end
            end
        end

        function stats = analyzeDoubleBifurcation(dData)
            % SUB-CONTROLLER: Double mutant bifurcating trajectory
            %
            % Biological claim: Double mutant follows a single trajectory
            % at early passages that bifurcates at late passages into a
            % low (collapse) trajectory and a high (rescue) trajectory.
            % Detection by BIC model selection between k=1 and k=2 GMM
            % fits on per-passage dominant component positions.

            stats = computeDoubleBifurcation(dData);
            reportDoubleBifurcation(stats);

            function stats = computeDoubleBifurcation(dData)
                % MODEL: Per-passage BIC model selection between k=1 and
                % k=2 GMM fits on dominant component positions (TERMINAL)
                records = dData.byGenotype{4};  % Double
                passages = 1:5;

                stats.passages             = passages;
                stats.k                    = nan(1, 5);
                stats.singleCentroid       = nan(1, 5);
                stats.lowCentroid          = nan(1, 5);
                stats.highCentroid         = nan(1, 5);
                stats.lowWeight            = nan(1, 5);
                stats.highWeight           = nan(1, 5);
                stats.nPlatesByPassage     = zeros(1, 5);
                stats.bicK1                = nan(1, 5);
                stats.bicK2                = nan(1, 5);
                stats.allDominantPositions = cell(1, 5);

                for pi = 1:5
                    doms = [];
                    for ri = 1:numel(records)
                        r = records(ri);
                        if r.passage ~= passages(pi); continue; end
                        if isnan(r.nLogNormal) || isempty(r.componentMedians)
                            continue;
                        end
                        meds = r.componentMedians;
                        wts  = r.componentWeights;
                        valid = ~isnan(meds);
                        if ~any(valid); continue; end
                        meds = meds(valid);
                        wts  = wts(valid);
                        [~, domIdx] = max(wts);
                        doms(end+1) = meds(domIdx); %#ok<AGROW>
                    end

                    stats.nPlatesByPassage(pi)     = numel(doms);
                    stats.allDominantPositions{pi} = doms;

                    if numel(doms) < 4; continue; end

                    % Work in log space (component positions are
                    % approximately log-normally distributed)
                    logDoms = log(doms(:));

                    % Fit k=1 GMM
                    gm1 = [];
                    try
                        gm1 = fitgmdist(logDoms, 1, 'Replicates', 5);
                        stats.bicK1(pi) = gm1.BIC;
                    catch
                        stats.bicK1(pi) = Inf;
                    end

                    % Fit k=2 GMM if enough data
                    gm2 = [];
                    if numel(doms) >= 6
                        try
                            gm2 = fitgmdist(logDoms, 2, ...
                                            'Replicates', 10, ...
                                            'RegularizationValue', 0.01);
                            stats.bicK2(pi) = gm2.BIC;
                        catch
                            stats.bicK2(pi) = Inf;
                        end
                    end

                    % BIC model selection (lower BIC wins)
                    chooseK2 = isfinite(stats.bicK2(pi)) && ...
                               stats.bicK2(pi) < stats.bicK1(pi);

                    if chooseK2 && ~isempty(gm2)
                        stats.k(pi) = 2;
                        mus = exp(gm2.mu(:));
                        [mus, sortIdx] = sort(mus);
                        compWts = gm2.ComponentProportion(sortIdx);
                        stats.lowCentroid(pi)  = mus(1);
                        stats.highCentroid(pi) = mus(2);
                        stats.lowWeight(pi)    = compWts(1);
                        stats.highWeight(pi)   = compWts(2);
                    elseif ~isempty(gm1)
                        stats.k(pi) = 1;
                        stats.singleCentroid(pi) = exp(gm1.mu);
                    end
                end

                % Unified low/high trajectory arrays for the figure overlay
                stats.lowTrajectory  = nan(1, 5);
                stats.highTrajectory = nan(1, 5);
                for pi = 1:5
                    if stats.k(pi) == 1
                        stats.lowTrajectory(pi)  = stats.singleCentroid(pi);
                        stats.highTrajectory(pi) = stats.singleCentroid(pi);
                    elseif stats.k(pi) == 2
                        stats.lowTrajectory(pi)  = stats.lowCentroid(pi);
                        stats.highTrajectory(pi) = stats.highCentroid(pi);
                    end
                end

                % Bifurcation detection
                bifPassages = find(stats.k == 2);
                if ~isempty(bifPassages)
                    stats.bifurcationOnset = bifPassages(1);
                    stats.bifurcated       = true;
                else
                    stats.bifurcationOnset = NaN;
                    stats.bifurcated       = false;
                end
            end

            function reportDoubleBifurcation(stats)
                % VIEW: Print Double bifurcation statistics (TERMINAL)
                fprintf('\n--- Double mutant BIFURCATING TRAJECTORY ---\n');
                fprintf('Claim: Double mutant follows a single trajectory at\n');
                fprintf('early passages that bifurcates at late passages into\n');
                fprintf('a low (collapse) and a high (rescue) trajectory.\n');
                fprintf('Method: per-passage BIC model selection between k=1\n');
                fprintf('and k=2 GMM fits on dominant component positions\n');
                fprintf('(log scale). Where k=2 wins, the population is bimodal.\n\n');

                fprintf('Per-passage model selection (figure overlay):\n');
                fprintf('  %3s   %s   %3s   %9s   %9s   %s\n', ...
                        'P', 'n plates', 'k*', 'BIC(k=1)', 'BIC(k=2)', ...
                        'centroids (um)');

                for pi = 1:5
                    nP = stats.nPlatesByPassage(pi);
                    if nP == 0
                        fprintf('  P%d    %3d        --    --          --          (no plates)\n', ...
                                pi, nP);
                        continue;
                    end
                    if isnan(stats.k(pi))
                        fprintf('  P%d    %3d        --    --          --          (n < 4, skipped)\n', ...
                                pi, nP);
                        continue;
                    end

                    bic1Str = sprintf('%9.2f', stats.bicK1(pi));
                    if isfinite(stats.bicK2(pi))
                        bic2Str = sprintf('%9.2f', stats.bicK2(pi));
                    else
                        bic2Str = '       --';
                    end

                    if stats.k(pi) == 1
                        centStr = sprintf('%4.0f (single)', ...
                                          stats.singleCentroid(pi));
                    else
                        centStr = sprintf('%4.0f / %4.0f  w=%.2f/%.2f', ...
                                          stats.lowCentroid(pi), ...
                                          stats.highCentroid(pi), ...
                                          stats.lowWeight(pi), ...
                                          stats.highWeight(pi));
                    end

                    fprintf('  P%d    %3d        %d     %s   %s   %s\n', ...
                            pi, nP, stats.k(pi), bic1Str, bic2Str, centStr);
                end

                fprintf('\n');
                if stats.bifurcated
                    fprintf('Bifurcation onset: P%d ', stats.bifurcationOnset);
                    fprintf('(first passage where k=2 beats k=1 by BIC)\n');
                    lastBif = find(stats.k == 2, 1, 'last');
                    if ~isempty(lastBif)
                        sep = stats.highCentroid(lastBif) / ...
                              stats.lowCentroid(lastBif);
                        fprintf('Centroid separation at P%d: %.0f um -> %.0f um ', ...
                                lastBif, stats.lowCentroid(lastBif), ...
                                stats.highCentroid(lastBif));
                        fprintf('(ratio = %.2fx)\n', sep);
                    end
                else
                    fprintf('No bifurcation detected (k=1 won at every passage).\n');
                end
                fprintf('\n');
            end
        end

        % === FIGURE WITH STATISTICAL OVERLAYS ===

        function [layout, trajectory] = plotComponentLocations(dData, ...
                                            dbf4Stats, cdc13Stats, doubleStats, overlayToggles)
            % SUB-CONTROLLER: Plot mixture components with the trajectory
            % overlay and the manual annotation overlay. Dataset1 selections
            % are drawn opaque; the rest of each sweep is faded, or left out
            % of the layout entirely when overlayToggles.selectedOnly is on.
            % Trajectory lines draw before the markers so the highlighted
            % circles cover the line ends. Trajectory segments are built
            % whether or not the overlay draws. A legend in the left margin
            % decodes the glyphs; it reads the same style values as the
            % plot, so the two cannot drift apart. Returns the layout so
            % highlight coverage can be checked, and the trajectory segments.

            style      = getComponentStyle();
            layout     = buildClusteredLayout(dData, overlayToggles.selectedOnly);
            trajectory = buildTrajectorySegments(layout);
            fig = createComponentFigure();
            ax  = setupComponentAxes(fig, layout, style);
            if overlayToggles.trajectory
                drawTrajectorySegments(ax, trajectory, style);
            end
            drawComponentMarkers(ax, layout, style);
            if overlayToggles.manual
                drawAnnotationOverlays(ax, layout, dbf4Stats, ...
                                       cdc13Stats, doubleStats, overlayToggles, style);
            end
            drawClusterBrackets(ax, layout);
            finalizeComponentPlot(ax, layout);
            drawComponentLegend(fig, ax, overlayToggles, style);

            function style = getComponentStyle()
                % MODEL (TERMINAL): single source for glyph styling and
                % panel geometry, read by the plot and the legend.
                %
                % === TWEAK: Dataset1 emphasis (selected vs faded) ===
                style.selFaceAlpha      = 0.90;  % marker fill,  Dataset1 row
                style.selEdgeAlpha      = 1.00;  % marker edge,  Dataset1 row
                style.selWhiskerWidth   = 2.50;  % IQR whisker,  Dataset1 row
                style.otherFaceAlpha    = 0.20;  % marker fill,  other rows
                style.otherEdgeAlpha    = 0.20;  % marker edge,  other rows
                style.otherWhiskerWidth = 1.50;  % IQR whisker,  other rows
                style.otherWhiskerFade  = 0.65;  % whisker blend toward white, other rows
                % === TWEAK: marker area (points^2) = sizeBase + sizeScale * weight ===
                style.sizeBase  = 30;
                style.sizeScale = 250;
                % === TWEAK: trajectory line width ===
                style.trajMinWidth = 1.0;  % width at mean weight 0
                style.trajMaxWidth = 4.0;  % width at mean weight 1
                % === TWEAK: manual annotation overlay ===
                style.manualLineWidth  = 2.5;
                style.manualMarkerSize = 100;
                % === TWEAK: panel geometry (normalized figure units) ===
                style.axesPosition   = [0.21 0.08 0.77 0.84];
                style.legendPosition = [0.005 0.08 0.145 0.84];
                % === TWEAK: legend appearance ===
                style.legendGlyphColor   = [0.45 0.45 0.45];
                style.legendFontSize     = 12;
                style.legendHeaderSize   = 13;
                style.legendRowStep      = 0.052;  % normalized legend height per row
                style.legendHeaderGap    = 0.025;  % extra space above each header
                % === END TWEAK ===
            end

            function segments = buildTrajectorySegments(layout)
                % MODEL: Build trajectory overlay segments from the
                % highlighted (Dataset1) plates (TERMINAL). Per genotype,
                % each passage with a highlighted row becomes a generation
                % holding one or two nodes: the plate's components with
                % weight >= WEIGHT_THRESHOLD, weights renormalized to sum
                % to 1, sorted by median so node 1 is the small class and
                % node 2 the large class. Consecutive generations connect
                % small to small and large to large when both hold two
                % nodes; otherwise every node of one connects to every
                % node of the other (convergence or divergence). A pair of
                % generations separated by a passage with no highlighted
                % row is marked dotted. A plate with more than two
                % components at or above threshold raises an error.
                % Segment x holds plate-row positions; segment y holds
                % component median radii.
                WEIGHT_THRESHOLD = 0.01;

                segments = struct('genotypeIdx', {}, 'fromPassage', {}, ...
                                  'toPassage', {}, 'x', {}, 'y', {}, ...
                                  'meanWeight', {}, 'dotted', {}, 'color', {});
                if isempty(layout.clusters); return; end

                clusterGenotypes = [layout.clusters.genotypeIdx];
                clusterPassages  = [layout.clusters.passage];

                for gi = unique(clusterGenotypes)
                    gens = struct('passage', {}, 'row', {}, 'radius', {}, ...
                                  'w', {}, 'color', {});
                    for p = 1:5
                        ci = find(clusterGenotypes == gi & ...
                                  clusterPassages == p, 1);
                        if isempty(ci); continue; end
                        cluster = layout.clusters(ci);
                        recs = cluster.records;
                        selIdx = find([recs.isDataset1], 1);
                        if isempty(selIdx); continue; end
                        r = recs(selIdx);

                        meds = r.componentMedians;
                        wts  = r.componentWeights;
                        keep = ~isnan(meds) & ~isnan(wts) & ...
                               wts >= WEIGHT_THRESHOLD;
                        if ~any(keep); continue; end
                        meds = meds(keep);
                        wts  = wts(keep);
                        if numel(meds) > 2
                            error('BeautifulFigure:tooManySubpopulations', ...
                                  ['%s: %d components at or above weight %.2f; ' ...
                                   'the trajectory overlay supports one or two.'], ...
                                  r.filename, numel(meds), WEIGHT_THRESHOLD);
                        end
                        wts = wts / sum(wts);
                        [meds, order] = sort(meds);
                        wts = wts(order);

                        g.passage = p;
                        g.row     = r.rowPos;
                        g.radius  = meds;
                        g.w       = wts;
                        g.color   = cluster.color;
                        gens(end+1) = g; %#ok<AGROW>
                    end

                    for k = 1:numel(gens) - 1
                        a = gens(k);
                        b = gens(k + 1);
                        isBridge = (b.passage - a.passage) > 1;

                        if numel(a.radius) == 2 && numel(b.radius) == 2
                            pairs = [1 1; 2 2];
                        else
                            [ia, ib] = ndgrid(1:numel(a.radius), 1:numel(b.radius));
                            pairs = [ia(:), ib(:)];
                        end

                        for q = 1:size(pairs, 1)
                            seg.genotypeIdx = gi;
                            seg.fromPassage = a.passage;
                            seg.toPassage   = b.passage;
                            seg.x           = [a.row, b.row];
                            seg.y           = [a.radius(pairs(q, 1)), ...
                                               b.radius(pairs(q, 2))];
                            seg.meanWeight  = (a.w(pairs(q, 1)) + ...
                                               b.w(pairs(q, 2))) / 2;
                            seg.dotted      = isBridge;
                            seg.color       = a.color;
                            segments(end+1) = seg; %#ok<AGROW>
                        end
                    end
                end
            end

            function drawTrajectorySegments(ax, segments, style)
                % VIEW: Draw trajectory overlay segments in the genotype
                % color (TERMINAL). Solid within consecutive passages,
                % dotted across a missing passage. Line width is linear in
                % the mean weight of the two connected nodes, between
                % style.trajMinWidth and style.trajMaxWidth.
                for si = 1:numel(segments)
                    s = segments(si);
                    if s.dotted
                        lineStyle = ':';
                    else
                        lineStyle = '-';
                    end
                    lineWidth = style.trajMinWidth + ...
                                (style.trajMaxWidth - style.trajMinWidth) * s.meanWeight;
                    plot(ax, s.x, s.y, lineStyle, 'Color', s.color, ...
                         'LineWidth', lineWidth);
                end
            end

            function layout = buildClusteredLayout(dData, selectedOnly)
                % MODEL: Build ordered plate-row positions grouped by ON
                % index, count-descending within cluster (TERMINAL). Rows
                % run left to right along x; radius limits and the bottom
                % label gutter apply to the log-scaled y axis. With
                % selectedOnly true, filterClusterRecords keeps only the
                % Dataset1 rows, so each cluster collapses to its selection
                % and a cluster with no selection is skipped.
                clusterGap     = 1.5;
                passages       = 1:5;
                colors         = {[0.20 0.40 0.85], [0.95 0.55 0.10], ...
                                  [0.20 0.65 0.30], [0.85 0.40 0.65]};
                genotypeLabels = {'Wild Type', 'dbf4-1', 'cdc13-2', 'Double'};

                layout.clusters = struct('genotypeIdx', {}, 'passage', {}, ...
                                         'color', {}, 'label', {}, ...
                                         'passageLabel', {}, ...
                                         'genotypeLabel', {}, ...
                                         'rowStart', {}, 'rowEnd', {}, ...
                                         'records', {});

                rowOffset = 0;
                for gi = 1:numel(dData.genotypes)
                    records = dData.byGenotype{gi};
                    for pi = 1:numel(passages)
                        passage = passages(pi);
                        clusterRecords = filterClusterRecords(records, ...
                                                              passage, selectedOnly);
                        if isempty(clusterRecords); continue; end

                        rowOffset = rowOffset + 1;
                        rowStart = rowOffset;
                        for ri = 1:numel(clusterRecords)
                            clusterRecords(ri).rowPos = rowOffset;
                            if ri < numel(clusterRecords)
                                rowOffset = rowOffset + 1;
                            end
                        end
                        rowEnd = rowOffset;

                        cluster = struct( ...
                            'genotypeIdx', gi, ...
                            'passage', passage, ...
                            'color', colors{gi}, ...
                            'label', sprintf('%s, P%d', ...
                                             genotypeLabels{gi}, passage), ...
                            'passageLabel', sprintf('P%d', passage), ...
                            'genotypeLabel', genotypeLabels{gi}, ...
                            'rowStart', rowStart, ...
                            'rowEnd', rowEnd, ...
                            'records', clusterRecords);
                        layout.clusters(end+1) = cluster;

                        rowOffset = rowOffset + clusterGap;
                    end
                end

                layout.maxRow          = rowOffset;
                layout.radiusMin       = 50;
                layout.radiusMax       = 5000;
                layout.gutterFrac      = 0.18;
                [layout.radiusAxisMin, layout.radiusLabelEdge] = ...
                    computeGutterBounds(layout.radiusMin, ...
                                        layout.radiusMax, ...
                                        layout.gutterFrac);
            end

            function clusterRecords = filterClusterRecords(records, passage, selectedOnly)
                % MODEL: Select records for a single ON index, sort by
                % colony count descending (TERMINAL). With selectedOnly
                % true, records outside the Dataset1 selection are dropped.
                clusterRecords = struct('plateIdx', {}, 'passage', {}, ...
                                        'hce', {}, 'colony_count', {}, ...
                                        'filename', {}, ...
                                        'isDataset1', {}, 'nKde', {}, ...
                                        'nLogNormal', {}, ...
                                        'componentMedians', {}, ...
                                        'componentWeights', {}, ...
                                        'componentP25', {}, ...
                                        'componentP75', {}, 'rowPos', {});
                for ri = 1:numel(records)
                    r = records(ri);
                    if r.passage ~= passage; continue; end
                    if selectedOnly && ~r.isDataset1; continue; end
                    if isnan(r.nLogNormal) || isempty(r.componentMedians)
                        continue;
                    end
                    if ~any(~isnan(r.componentMedians)); continue; end

                    r.rowPos = NaN;
                    clusterRecords(end+1) = r; %#ok<AGROW>
                end

                if numel(clusterRecords) > 1
                    counts = [clusterRecords.colony_count];
                    [~, sortIdx] = sort(counts, 'descend');
                    clusterRecords = clusterRecords(sortIdx);
                end
            end

            function [axisMin, labelEdge] = ...
                    computeGutterBounds(dataMin, dataMax, frac)
                % MODEL: Extend the radius axis downward in log space so
                % the bottom gutter takes frac of the axis height (TERMINAL)
                logMin = log10(dataMin);
                logMax = log10(dataMax);
                logSpan = logMax - logMin;
                logAxisMin = logMin - frac / (1 - frac) * logSpan;
                axisMin    = 10 ^ logAxisMin;
                logEdge    = logAxisMin + frac * (logMax - logAxisMin);
                labelEdge  = 10 ^ logEdge;
            end

            function fig = createComponentFigure()
                % VIEW: Create figure window (TERMINAL). Figure-level
                % defaults set Times New Roman at 12 pt for every axes and
                % text object created in it (tick labels, axis labels,
                % title, and gutter labels). Objects with an explicit size
                % (title 16 pt, genotype labels 14 pt) override the default.
                fig = figure('Name', ...
                             'Subpopulation Analysis Across Selected Plates', ...
                             'Position', [150, 200, 1500, 750], ...
                             'Color', 'w', ...
                             'DefaultAxesFontName', 'Times New Roman', ...
                             'DefaultTextFontName', 'Times New Roman', ...
                             'DefaultAxesFontSize', 16, ...
                             'DefaultTextFontSize', 16);
            end

            function ax = setupComponentAxes(fig, layout, style)
                % VIEW: Configure axes properties and limits (TERMINAL).
                % SortMethod childorder renders objects in draw order, so
                % trajectory lines drawn first stay beneath the markers.
                % The axes sits right of the legend margin.
                ax = axes(fig, 'Position', style.axesPosition);
                ax.SortMethod = 'childorder';
                ax.FontSize   = 12;
                hold(ax, 'on');
                set(ax, 'YScale', 'log');
                xlim(ax, [0, layout.maxRow + 1]);
                ylim(ax, [layout.radiusAxisMin, layout.radiusMax]);
                set(ax, 'XTick', [], 'TickDir', 'out', 'Box', 'on');
            end

            function drawComponentMarkers(ax, layout, style)
                % SUB-CONTROLLER: Draw IQR whiskers and component markers
                for ci = 1:numel(layout.clusters)
                    cluster = layout.clusters(ci);
                    for ri = 1:numel(cluster.records)
                        r = cluster.records(ri);
                        drawSinglePlateRow(ax, r, cluster.color, style);
                    end
                end

                function drawSinglePlateRow(ax, r, color, style)
                    % VIEW: Draw vertical IQR whiskers + component circles
                    % at the plate's row position (TERMINAL).
                    % Dataset1-selected plates are drawn opaque; the rest of
                    % the crowding sweep is faded back. Emphasis values come
                    % from getComponentStyle.

                    meds = r.componentMedians;
                    wts  = r.componentWeights;
                    p25s = r.componentP25;
                    p75s = r.componentP75;

                    validC = ~isnan(meds);
                    meds = meds(validC);
                    wts  = wts(validC);
                    p25s = p25s(validC);
                    p75s = p75s(validC);

                    rowPos = r.rowPos * ones(size(meds));
                    baseWhisker = color * 0.5 + [0.5 0.5 0.5];

                    isSel = isfield(r, 'isDataset1') && r.isDataset1;
                    if isSel
                        faceAlpha    = style.selFaceAlpha;
                        edgeAlpha    = style.selEdgeAlpha;
                        whiskerColor = baseWhisker;
                        whiskerWidth = style.selWhiskerWidth;
                    else
                        faceAlpha    = style.otherFaceAlpha;
                        edgeAlpha    = style.otherEdgeAlpha;
                        whiskerColor = baseWhisker * (1 - style.otherWhiskerFade) + ...
                                       [1 1 1] * style.otherWhiskerFade;
                        whiskerWidth = style.otherWhiskerWidth;
                    end

                    for ci = 1:numel(meds)
                        plot(ax, [rowPos(ci), rowPos(ci)], ...
                             [p25s(ci), p75s(ci)], ...
                             '-', 'Color', whiskerColor, 'LineWidth', whiskerWidth);
                    end

                    sizes = style.sizeBase + style.sizeScale * wts;
                    scatter(ax, rowPos, meds, sizes, color, 'filled', ...
                            'MarkerFaceAlpha', faceAlpha, ...
                            'MarkerEdgeAlpha', edgeAlpha, ...
                            'MarkerEdgeColor', 'k', 'LineWidth', 0.5);
                end
            end

            function drawAnnotationOverlays(ax, layout, dbf4Stats, ...
                                            cdc13Stats, doubleStats, overlayToggles, style)
                % SUB-CONTROLLER: Manual annotation overlay. Draws the
                % per-genotype annotations that the dbf4, cdc13, and double
                % toggles enable. Each is structurally different because each
                % genotype's claim is categorically different.

                if overlayToggles.dbf4
                    drawDbf4Boxes(ax, layout, dbf4Stats, style);
                end
                if overlayToggles.cdc13
                    drawCdc13TrajectoryLine(ax, layout, cdc13Stats, style);
                end
                if overlayToggles.double
                    drawDoubleBifurcationLines(ax, layout, doubleStats, style);
                end

                function drawDbf4Boxes(ax, layout, stats, style)
                    % VIEW: Draw two dashed rectangles spanning the dbf4-1
                    % cluster rows, at the pooled IQR radius ranges (TERMINAL)
                    dbf4Idx = find([layout.clusters.genotypeIdx] == 2);
                    if isempty(dbf4Idx); return; end

                    rowMin = min([layout.clusters(dbf4Idx).rowStart]) - 0.5;
                    rowMax = max([layout.clusters(dbf4Idx).rowEnd]) + 0.5;

                    edgeColor = layout.clusters(dbf4Idx(1)).color * 0.5;

                    if all(isfinite(stats.dominantBox))
                        r1 = stats.dominantBox(1);
                        r2 = stats.dominantBox(2);
                        patch(ax, [rowMin rowMax rowMax rowMin], ...
                              [r1 r1 r2 r2], ...
                              edgeColor, ...
                              'FaceAlpha', 0, ...
                              'EdgeColor', edgeColor, ...
                              'LineWidth', style.manualLineWidth, ...
                              'LineStyle', '--');
                    end

                    if all(isfinite(stats.shoulderBox))
                        r1 = stats.shoulderBox(1);
                        r2 = stats.shoulderBox(2);
                        patch(ax, [rowMin rowMax rowMax rowMin], ...
                              [r1 r1 r2 r2], ...
                              edgeColor, ...
                              'FaceAlpha', 0, ...
                              'EdgeColor', edgeColor, ...
                              'LineWidth', style.manualLineWidth, ...
                              'LineStyle', '--');
                    end
                end

                function drawCdc13TrajectoryLine(ax, layout, stats, style)
                    % VIEW: Draw single descending dashed curve through
                    % cdc13-2 passage cluster centers (TERMINAL)
                    rows  = [];
                    radii = [];
                    color = [];

                    for pi = 1:5
                        if ~isfinite(stats.dominantByPassage(pi)); continue; end
                        clusterIdx = find( ...
                            [layout.clusters.genotypeIdx] == 3 & ...
                            [layout.clusters.passage] == pi);
                        if isempty(clusterIdx); continue; end
                        cluster = layout.clusters(clusterIdx);
                        rowCenter = (cluster.rowStart + cluster.rowEnd) / 2;
                        rows(end+1)  = rowCenter; %#ok<AGROW>
                        radii(end+1) = stats.dominantByPassage(pi); %#ok<AGROW>
                        if isempty(color)
                            color = cluster.color * 0.5;
                        end
                    end

                    if numel(rows) >= 2
                        plot(ax, rows, radii, '--', 'Color', color, ...
                             'LineWidth', style.manualLineWidth);
                        scatter(ax, rows, radii, style.manualMarkerSize, color, 'd', 'filled', ...
                                'MarkerEdgeColor', 'k', 'LineWidth', 1);
                    end
                end

                function drawDoubleBifurcationLines(ax, layout, stats, style)
                    % VIEW: Draw bifurcating trajectory through Double
                    % cluster centers (TERMINAL). Rad arrays hold radii and
                    % Row arrays hold cluster-center row positions.
                    % At k=1 passages, both lines share the same point.
                    % At k=2 passages, the lines occupy distinct points.
                    lowRad = []; lowRow = [];
                    highRad = []; highRow = [];
                    singleMarkerRad = []; singleMarkerRow = [];
                    splitMarkerRad  = []; splitMarkerRow  = [];
                    color = [];

                    for pi = 1:5
                        if isnan(stats.k(pi)); continue; end
                        clusterIdx = find( ...
                            [layout.clusters.genotypeIdx] == 4 & ...
                            [layout.clusters.passage] == pi);
                        if isempty(clusterIdx); continue; end
                        cluster = layout.clusters(clusterIdx);
                        rowCenter = (cluster.rowStart + cluster.rowEnd) / 2;
                        if isempty(color)
                            color = cluster.color * 0.5;
                        end

                        if stats.k(pi) == 1
                            lowRad(end+1)  = stats.singleCentroid(pi); %#ok<AGROW>
                            lowRow(end+1)  = rowCenter; %#ok<AGROW>
                            highRad(end+1) = stats.singleCentroid(pi); %#ok<AGROW>
                            highRow(end+1) = rowCenter; %#ok<AGROW>
                            singleMarkerRad(end+1) = stats.singleCentroid(pi); %#ok<AGROW>
                            singleMarkerRow(end+1) = rowCenter; %#ok<AGROW>
                        else
                            lowRad(end+1)  = stats.lowCentroid(pi); %#ok<AGROW>
                            lowRow(end+1)  = rowCenter; %#ok<AGROW>
                            highRad(end+1) = stats.highCentroid(pi); %#ok<AGROW>
                            highRow(end+1) = rowCenter; %#ok<AGROW>
                            splitMarkerRad(end+1) = stats.lowCentroid(pi); %#ok<AGROW>
                            splitMarkerRow(end+1) = rowCenter; %#ok<AGROW>
                            splitMarkerRad(end+1) = stats.highCentroid(pi); %#ok<AGROW>
                            splitMarkerRow(end+1) = rowCenter; %#ok<AGROW>
                        end
                    end

                    if numel(lowRad) >= 2
                        plot(ax, lowRow, lowRad, '--', 'Color', color, ...
                             'LineWidth', style.manualLineWidth);
                    end
                    if numel(highRad) >= 2 && any(highRad ~= lowRad)
                        plot(ax, highRow, highRad, '--', 'Color', color, ...
                             'LineWidth', style.manualLineWidth);
                    end

                    if ~isempty(singleMarkerRad)
                        scatter(ax, singleMarkerRow, singleMarkerRad, style.manualMarkerSize, ...
                                color, 'd', 'filled', ...
                                'MarkerEdgeColor', 'k', 'LineWidth', 1);
                    end
                    if ~isempty(splitMarkerRad)
                        scatter(ax, splitMarkerRow, splitMarkerRad, style.manualMarkerSize, ...
                                color, 'd', 'filled', ...
                                'MarkerEdgeColor', 'k', 'LineWidth', 1);
                    end
                end
            end

            function drawClusterBrackets(ax, layout)
                % VIEW: Draw cluster brackets, passage labels, and genotype
                % labels in the bottom gutter (TERMINAL). Each cluster gets
                % a horizontal bracket with upward end ticks and its passage
                % label beneath; each genotype label is centered beneath
                % all of that genotype's clusters.
                logGutter = log10(layout.radiusAxisMin);
                logEdge   = log10(layout.radiusLabelEdge);
                span      = logEdge - logGutter;

                bracketY      = 10 ^ (logEdge - 0.15 * span);
                bracketTickY  = 10 ^ (logEdge - 0.05 * span);
                passageLabelY = 10 ^ (logEdge - 0.40 * span);
                genotypeLabelY = 10 ^ (logEdge - 0.75 * span);

                for ci = 1:numel(layout.clusters)
                    cluster = layout.clusters(ci);
                    x1 = cluster.rowStart - 0.4;
                    x2 = cluster.rowEnd   + 0.4;

                    plot(ax, [x1, x2], [bracketY, bracketY], ...
                         '-', 'Color', cluster.color, 'LineWidth', 2);
                    plot(ax, [x1, x1], [bracketY, bracketTickY], ...
                         '-', 'Color', cluster.color, 'LineWidth', 2);
                    plot(ax, [x2, x2], [bracketY, bracketTickY], ...
                         '-', 'Color', cluster.color, 'LineWidth', 2);

                    text(ax, (x1 + x2) / 2, passageLabelY, cluster.passageLabel, ...
                         'HorizontalAlignment', 'center', ...
                         'VerticalAlignment', 'middle', ...
                         'FontSize', 16, 'FontWeight', 'bold', ...
                         'Color', cluster.color * 0.6, ...
                         'Interpreter', 'none');
                end

                genotypeIdxs = unique([layout.clusters.genotypeIdx]);
                for gk = 1:numel(genotypeIdxs)
                    members = layout.clusters( ...
                        [layout.clusters.genotypeIdx] == genotypeIdxs(gk));
                    xCenter = (min([members.rowStart]) + ...
                               max([members.rowEnd])) / 2;
                    text(ax, xCenter, genotypeLabelY, members(1).genotypeLabel, ...
                         'HorizontalAlignment', 'center', ...
                         'VerticalAlignment', 'middle', ...
                         'FontSize', 14, 'FontWeight', 'bold', ...
                         'Color', members(1).color * 0.6, ...
                         'Interpreter', 'none');
                end
            end

            function finalizeComponentPlot(ax, layout)
                % VIEW: Apply axis labels, title, gutter separator (TERMINAL).
                % The title is fixed and independent of the overlay toggles.
                yline(ax, layout.radiusMin, 'k-', 'LineWidth', 0.5, ...
                      'Alpha', 0.3);

                tickValues = [100, 200, 500, 1000, 2000, 5000];
                tickValues = tickValues(tickValues >= layout.radiusMin & ...
                                        tickValues <= layout.radiusMax);
                set(ax, 'YTick', tickValues);

                ylabel(ax, 'Component median radius (\mum)','FontSize',16);
                xlabel(ax, '');

                title(ax, 'Subpopulation Analysis Across Selected Plates', ...
                      'FontSize', 20, 'FontName', 'Times New Roman');

                grid(ax, 'on');
                ax.GridAlpha = 0.2;
            end

            function drawComponentLegend(fig, ax, overlayToggles, style)
                % SUB-CONTROLLER: Build the legend entry list from the
                % overlay toggles and style, then draw it in the left
                % margin. Genotype colors carry no entries; the gutter
                % labels name them.

                entries = buildLegendEntries(overlayToggles, style);
                renderLegendPanel(fig, ax, entries, style);

                function entries = buildLegendEntries(overlayToggles, style)
                    % MODEL (TERMINAL): ordered legend entries with their
                    % vertical positions in normalized legend units. Each
                    % entry has a kind (header, circle, whisker, line, box,
                    % diamondLine) and the glyph values it draws with.
                    % Sections follow the toggles: the faded circle drops
                    % out under selectedOnly, the trajectory section under
                    % trajectory off, and the annotation section appears
                    % only when manual is on with at least one sub-toggle.
                    mk = @(kind, label, sz, fa, ea, ls, lw) struct( ...
                        'kind', kind, 'label', label, 'y', NaN, ...
                        'size', sz, 'faceAlpha', fa, 'edgeAlpha', ea, ...
                        'lineStyle', ls, 'lineWidth', lw);
                    areaAt  = @(w) style.sizeBase + style.sizeScale * w;
                    widthAt = @(w) style.trajMinWidth + ...
                                   (style.trajMaxWidth - style.trajMinWidth) * w;

                    entries = mk('header', 'Component weight', NaN, NaN, NaN, '', NaN);
                    for w = [0.1, 0.5, 1.0]
                        entries(end+1) = mk('circle', sprintf('Weight %.1f', w), ...
                                            areaAt(w), style.selFaceAlpha, ...
                                            style.selEdgeAlpha, '', 0.5); %#ok<AGROW>
                    end

                    entries(end+1) = mk('header', 'Plates', NaN, NaN, NaN, '', NaN);
                    entries(end+1) = mk('circle', 'Selected plate', areaAt(0.5), ...
                                        style.selFaceAlpha, style.selEdgeAlpha, '', 0.5);
                    if ~overlayToggles.selectedOnly
                        entries(end+1) = mk('circle', 'Other plates', areaAt(0.5), ...
                                            style.otherFaceAlpha, ...
                                            style.otherEdgeAlpha, '', 0.5);
                    end
                    entries(end+1) = mk('whisker', 'Component IQR', NaN, NaN, NaN, ...
                                        '-', style.selWhiskerWidth);

                    if overlayToggles.trajectory
                        entries(end+1) = mk('header', 'Trajectory', NaN, NaN, NaN, '', NaN);
                        entries(end+1) = mk('line', 'Consecutive passages', NaN, ...
                                            NaN, NaN, '-', widthAt(0.5));
                        entries(end+1) = mk('line', 'Skipped passage', NaN, ...
                                            NaN, NaN, ':', widthAt(0.5));
                        entries(end+1) = mk('line', 'Mean weight 0.1', NaN, ...
                                            NaN, NaN, '-', widthAt(0.1));
                        entries(end+1) = mk('line', 'Mean weight 0.9', NaN, ...
                                            NaN, NaN, '-', widthAt(0.9));
                    end

                    showManual = overlayToggles.manual && ...
                                 (overlayToggles.dbf4 || overlayToggles.cdc13 || ...
                                  overlayToggles.double);
                    if showManual
                        entries(end+1) = mk('header', 'Annotations', NaN, NaN, NaN, '', NaN);
                        if overlayToggles.dbf4
                            entries(end+1) = mk('box', 'dbf4-1 IQR band', NaN, ...
                                                NaN, NaN, '--', style.manualLineWidth);
                        end
                        if overlayToggles.cdc13 || overlayToggles.double
                            entries(end+1) = mk('diamondLine', 'Passage centroid', ...
                                                style.manualMarkerSize, NaN, NaN, ...
                                                '--', style.manualLineWidth);
                        end
                    end

                    y = 0.97;
                    for ei = 1:numel(entries)
                        if strcmp(entries(ei).kind, 'header') && ei > 1
                            y = y - style.legendHeaderGap;
                        end
                        entries(ei).y = y;
                        y = y - style.legendRowStep;
                    end
                end

                function renderLegendPanel(fig, ax, entries, style)
                    % VIEW (TERMINAL): create a hidden axes in the left
                    % margin and draw each entry's glyph and label. Marker
                    % areas and line widths are absolute (points^2 and
                    % points), so the glyphs match the plot one to one.
                    % The main axes is restored as current afterward.
                    GLYPH_X = 0.14;
                    LINE_X  = [0.03, 0.25];
                    TEXT_X  = 0.30;
                    HALF_H  = 0.018;
                    gray    = style.legendGlyphColor;
                    whiskerGray = gray * 0.5 + [0.5 0.5 0.5];

                    lax = axes(fig, 'Position', style.legendPosition, ...
                               'XLim', [0 1], 'YLim', [0 1], 'Visible', 'off');
                    hold(lax, 'on');

                    for ei = 1:numel(entries)
                        e = entries(ei);
                        switch e.kind
                            case 'header'
                                text(lax, 0.02, e.y, e.label, ...
                                     'FontSize', style.legendHeaderSize, ...
                                     'FontWeight', 'bold', ...
                                     'VerticalAlignment', 'middle', ...
                                     'Interpreter', 'none');
                                continue;
                            case 'circle'
                                scatter(lax, GLYPH_X, e.y, e.size, gray, 'filled', ...
                                        'MarkerFaceAlpha', e.faceAlpha, ...
                                        'MarkerEdgeAlpha', e.edgeAlpha, ...
                                        'MarkerEdgeColor', 'k', ...
                                        'LineWidth', e.lineWidth);
                            case 'whisker'
                                plot(lax, [GLYPH_X, GLYPH_X], ...
                                     [e.y - HALF_H, e.y + HALF_H], ...
                                     e.lineStyle, 'Color', whiskerGray, ...
                                     'LineWidth', e.lineWidth);
                            case 'line'
                                plot(lax, LINE_X, [e.y, e.y], e.lineStyle, ...
                                     'Color', gray, 'LineWidth', e.lineWidth);
                            case 'box'
                                patch(lax, [LINE_X(1) LINE_X(2) LINE_X(2) LINE_X(1)], ...
                                      [e.y - 0.8 * HALF_H, e.y - 0.8 * HALF_H, ...
                                       e.y + 0.8 * HALF_H, e.y + 0.8 * HALF_H], ...
                                      gray, 'FaceAlpha', 0, 'EdgeColor', gray * 0.6, ...
                                      'LineStyle', e.lineStyle, ...
                                      'LineWidth', e.lineWidth);
                            case 'diamondLine'
                                plot(lax, LINE_X, [e.y, e.y], e.lineStyle, ...
                                     'Color', gray * 0.6, 'LineWidth', e.lineWidth);
                                scatter(lax, GLYPH_X, e.y, e.size, gray * 0.6, 'd', ...
                                        'filled', 'MarkerEdgeColor', 'k', ...
                                        'LineWidth', 1);
                        end
                        text(lax, TEXT_X, e.y, e.label, ...
                             'FontSize', style.legendFontSize, ...
                             'VerticalAlignment', 'middle', ...
                             'Interpreter', 'none');
                    end

                    set(fig, 'CurrentAxes', ax);
                end
            end
        end
    end

    function results = proveDbf4Discrimination(decompData)
    % CONTROLLER: Standalone analysis demonstrating that the dbf4-1
    % shoulder and dominant component boxes have near-perfect
    % discriminatory power within a moderate HCE band (9 to 250).
    %
    % The full-dataset analysis shows 12 cross-band contaminations
    % (4 shoulders cross into the dominant band from below, 8 dominants
    % compress into the shoulder band from above). Most of the 8 downward
    % crossovers come from extreme-HCE plates (HCE 1020 and 5100), where
    % crowding compresses the dominant population. Restricting analysis
    % to HCE 9-250 removes those extreme cases and tests whether the
    % residual discrimination is clean.
    %
    % Input:
    %   decompData - the struct produced by collectMixtureComponents
    %                inside BeautifulFigure. Available at runtime as
    %                BeautifulFigure_outputs_V40.decompData (where V40
    %                is whatever rounds tag is in use).
    %
    % Output:
    %   results - struct containing band-restricted box coordinates,
    %             confusion table, crossover details, and discrimination
    %             rate.

    bandConfig = defineBandConfig();

    printAnalysisHeader(bandConfig);

    results = runDiscriminationAnalysis(decompData, bandConfig);

    % === SHARED HELPERS ===

    function bandConfig = defineBandConfig()
        % MODEL: Define HCE band bounds and weight threshold (TERMINAL)
        bandConfig.hceMin = 9;
        bandConfig.hceMax = 250;
        bandConfig.weightThreshold = 0.10;
        bandConfig.genotypeIdx = 2;  % dbf4-1 in decompData
    end

    function printAnalysisHeader(bandConfig)
        % VIEW: Print analysis header (TERMINAL)
        fprintf('\n');
        fprintf('================================================================\n');
        fprintf('  dbf4-1 BAND DISCRIMINATION ANALYSIS\n');
        fprintf('================================================================\n');
        fprintf('Goal: demonstrate that the dbf4-1 dominant and shoulder boxes\n');
        fprintf('discriminate cleanly between majority and minority components\n');
        fprintf('within a moderate HCE band where the inverse HCE-radius\n');
        fprintf('relationship is not compressing or lifting components\n');
        fprintf('out of their characteristic positions.\n\n');
        fprintf('HCE band: %d to %d (inclusive)\n', ...
                bandConfig.hceMin, bandConfig.hceMax);
        fprintf('Weight threshold: components with weight < %.2f excluded\n', ...
                bandConfig.weightThreshold);
        fprintf('Genotype: dbf4-1, k>=2 plates only\n\n');
    end

    % === SUB-CONTROLLER ===

    function results = runDiscriminationAnalysis(decompData, bandConfig)
        % SUB-CONTROLLER: Classify within-band components, compute
        % band-restricted boxes, build confusion table, report results

        classified = classifyBandComponents(decompData, bandConfig);

        boxes = computeBandBoxes(classified);

        confusion = buildConfusionTable(classified, boxes);

        reportBoxes(boxes, classified);

        reportConfusionTable(confusion);

        reportCrossovers(confusion);

        reportDiscriminationSummary(confusion);

        results.bandConfig    = bandConfig;
        results.classified    = classified;
        results.boxes         = boxes;
        results.confusion     = confusion;

        % === MODEL FUNCTIONS ===

        function classified = classifyBandComponents(decompData, bandConfig)
            % MODEL: Pull dbf4-1 k>=2 components within HCE band,
            % classify each by plate-level weight rank (TERMINAL)
            records = decompData.byGenotype{bandConfig.genotypeIdx};

            dominants = struct('median', {}, 'weight', {}, ...
                               'passage', {}, 'hce', {}, 'k', {});
            shoulders = struct('median', {}, 'weight', {}, ...
                               'passage', {}, 'hce', {}, 'k', {});

            for ri = 1:numel(records)
                r = records(ri);

                % Restrict to k>=2 plates within HCE band
                if isnan(r.nLogNormal) || r.nLogNormal < 2
                    continue;
                end
                if r.hce < bandConfig.hceMin || r.hce > bandConfig.hceMax
                    continue;
                end
                if isempty(r.componentMedians) || isempty(r.componentWeights)
                    continue;
                end

                meds = r.componentMedians;
                wts  = r.componentWeights;

                valid = ~isnan(meds) & ~isnan(wts);
                if ~any(valid); continue; end
                meds = meds(valid);
                wts  = wts(valid);

                % Apply weight threshold
                aboveThreshold = wts >= bandConfig.weightThreshold;
                if ~any(aboveThreshold); continue; end
                meds = meds(aboveThreshold);
                wts  = wts(aboveThreshold);

                % Rank by weight descending
                [~, sortIdx] = sort(wts, 'descend');
                meds = meds(sortIdx);
                wts  = wts(sortIdx);

                % Highest-weight component = dominant
                entry.median  = meds(1);
                entry.weight  = wts(1);
                entry.passage = r.passage;
                entry.hce     = r.hce;
                entry.k       = r.nLogNormal;
                dominants(end+1) = entry; %#ok<AGROW>

                % Remaining components = shoulders
                for si = 2:numel(meds)
                    entry.median  = meds(si);
                    entry.weight  = wts(si);
                    entry.passage = r.passage;
                    entry.hce     = r.hce;
                    entry.k       = r.nLogNormal;
                    shoulders(end+1) = entry; %#ok<AGROW>
                end
            end

            classified.dominants = dominants;
            classified.shoulders = shoulders;
            classified.nDominants = numel(dominants);
            classified.nShoulders = numel(shoulders);
            classified.nTotal     = classified.nDominants + ...
                                    classified.nShoulders;
        end

        function boxes = computeBandBoxes(classified)
            % MODEL: Compute pooled IQR for each rank class within band
            % (TERMINAL)
            dominantMeds = [classified.dominants.median];
            shoulderMeds = [classified.shoulders.median];

            if isempty(dominantMeds)
                boxes.dominantBox = [NaN NaN];
                boxes.dominantMedian = NaN;
            else
                boxes.dominantBox = [prctile(dominantMeds, 25), ...
                                     prctile(dominantMeds, 75)];
                boxes.dominantMedian = median(dominantMeds);
            end

            if isempty(shoulderMeds)
                boxes.shoulderBox = [NaN NaN];
                boxes.shoulderMedian = NaN;
            else
                boxes.shoulderBox = [prctile(shoulderMeds, 25), ...
                                     prctile(shoulderMeds, 75)];
                boxes.shoulderMedian = median(shoulderMeds);
            end

            % Middle gap
            if all(isfinite([boxes.dominantBox, boxes.shoulderBox]))
                boxes.middleGap = [boxes.shoulderBox(2), ...
                                   boxes.dominantBox(1)];
                boxes.middleGapWidth = boxes.dominantBox(1) - ...
                                       boxes.shoulderBox(2);
            else
                boxes.middleGap = [NaN NaN];
                boxes.middleGapWidth = NaN;
            end
        end

        function confusion = buildConfusionTable(classified, boxes)
            % MODEL: Classify each component by which box it falls into,
            % build 2x3 confusion table (TERMINAL)

            % Initialize counts: rows = rank class, cols = box location
            % Columns: 1=in dominant box, 2=in shoulder box, 3=in middle
            confusion.counts = zeros(2, 3);

            % Track which components landed where
            confusion.dominantInDominantBox = [];
            confusion.dominantInShoulderBox = [];
            confusion.dominantInMiddle      = [];
            confusion.shoulderInDominantBox = [];
            confusion.shoulderInShoulderBox = [];
            confusion.shoulderInMiddle      = [];

            % Classify dominants
            for di = 1:numel(classified.dominants)
                d = classified.dominants(di);
                location = classifyBoxLocation(d.median, boxes);
                confusion.counts(1, location) = ...
                    confusion.counts(1, location) + 1;
                if location == 1
                    confusion.dominantInDominantBox(end+1) = di; %#ok<AGROW>
                elseif location == 2
                    confusion.dominantInShoulderBox(end+1) = di; %#ok<AGROW>
                else
                    confusion.dominantInMiddle(end+1) = di; %#ok<AGROW>
                end
            end

            % Classify shoulders
            for si = 1:numel(classified.shoulders)
                s = classified.shoulders(si);
                location = classifyBoxLocation(s.median, boxes);
                confusion.counts(2, location) = ...
                    confusion.counts(2, location) + 1;
                if location == 1
                    confusion.shoulderInDominantBox(end+1) = si; %#ok<AGROW>
                elseif location == 2
                    confusion.shoulderInShoulderBox(end+1) = si; %#ok<AGROW>
                else
                    confusion.shoulderInMiddle(end+1) = si; %#ok<AGROW>
                end
            end

            % Discrimination rate
            nCorrect = confusion.counts(1, 1) + confusion.counts(2, 2);
            confusion.discriminationRate = nCorrect / classified.nTotal;

            % Crossover counts
            confusion.nDominantsInShoulderBox = confusion.counts(1, 2);
            confusion.nShouldersInDominantBox = confusion.counts(2, 1);
            confusion.nTotalCrossovers = confusion.nDominantsInShoulderBox + ...
                                         confusion.nShouldersInDominantBox;
        end

        function location = classifyBoxLocation(medianValue, boxes)
            % MODEL: Determine which box (or middle) a component falls
            % into. Returns 1=dominant, 2=shoulder, 3=middle (TERMINAL)
            inDominantBox = medianValue >= boxes.dominantBox(1) && ...
                            medianValue <= boxes.dominantBox(2);
            inShoulderBox = medianValue >= boxes.shoulderBox(1) && ...
                            medianValue <= boxes.shoulderBox(2);

            % Handle the edge case where boxes touch or overlap: if a
            % component sits in both, assign to whichever box's median
            % it is closer to.
            if inDominantBox && inShoulderBox
                distToDominant = abs(medianValue - boxes.dominantMedian);
                distToShoulder = abs(medianValue - boxes.shoulderMedian);
                if distToDominant <= distToShoulder
                    location = 1;
                else
                    location = 2;
                end
            elseif inDominantBox
                location = 1;
            elseif inShoulderBox
                location = 2;
            else
                location = 3;
            end
        end

        % === VIEW FUNCTIONS ===

        function reportBoxes(boxes, classified)
            % VIEW: Print band-restricted box coordinates (TERMINAL)
            fprintf('Band-restricted box coordinates (recomputed within band):\n\n');
            fprintf('  DOMINANT band: pooled IQR = [%.0f, %.0f] um  (n = %d)\n', ...
                    boxes.dominantBox(1), boxes.dominantBox(2), ...
                    classified.nDominants);
            fprintf('    Pooled median = %.0f um\n', boxes.dominantMedian);
            fprintf('  SHOULDER band: pooled IQR = [%.0f, %.0f] um  (n = %d)\n', ...
                    boxes.shoulderBox(1), boxes.shoulderBox(2), ...
                    classified.nShoulders);
            fprintf('    Pooled median = %.0f um\n', boxes.shoulderMedian);
            if isfinite(boxes.middleGapWidth)
                if boxes.middleGapWidth > 0
                    fprintf('  Middle gap: [%.0f, %.0f] um (width = %.0f um)\n\n', ...
                            boxes.middleGap(1), boxes.middleGap(2), ...
                            boxes.middleGapWidth);
                else
                    fprintf('  Boxes touch or overlap: shoulder upper = %.0f, ', ...
                            boxes.shoulderBox(2));
                    fprintf('dominant lower = %.0f\n\n', boxes.dominantBox(1));
                end
            end
        end

        function reportConfusionTable(confusion)
            % VIEW: Print 2x3 confusion table (TERMINAL)
            fprintf('Confusion table (rows: rank class, cols: box location):\n\n');
            fprintf('                          in dominant   in shoulder   in middle\n');
            fprintf('                          box           box           gap\n');
            fprintf('  -----------------------------------------------------------------\n');
            fprintf('  dominant by weight rank   %3d           %3d           %3d\n', ...
                    confusion.counts(1, 1), confusion.counts(1, 2), ...
                    confusion.counts(1, 3));
            fprintf('  shoulder by weight rank   %3d           %3d           %3d\n', ...
                    confusion.counts(2, 1), confusion.counts(2, 2), ...
                    confusion.counts(2, 3));
            fprintf('\n');
        end

        function reportCrossovers(confusion)
            % VIEW: Print details of any cross-band contaminations
            % (TERMINAL)
            if confusion.nTotalCrossovers == 0
                fprintf('Crossover details: NONE. Every component sits in its\n');
                fprintf('expected box or the middle gap.\n\n');
                return;
            end

            fprintf('Crossover details:\n\n');

            if confusion.nShouldersInDominantBox > 0
                fprintf('  Shoulders crossing UP into dominant box (n = %d):\n', ...
                        confusion.nShouldersInDominantBox);
                fprintf('    %-8s  %-8s  %-3s  %-5s  %-3s\n', ...
                        'median', 'weight', 'P', 'HCE', 'k');
                for idx = confusion.shoulderInDominantBox
                    s = classified.shoulders(idx);
                    fprintf('    %4.0f um   %.2f      P%d   %4.0f   %d\n', ...
                            s.median, s.weight, s.passage, s.hce, s.k);
                end
                fprintf('\n');
            end

            if confusion.nDominantsInShoulderBox > 0
                fprintf('  Dominants crossing DOWN into shoulder box (n = %d):\n', ...
                        confusion.nDominantsInShoulderBox);
                fprintf('    %-8s  %-8s  %-3s  %-5s  %-3s\n', ...
                        'median', 'weight', 'P', 'HCE', 'k');
                for idx = confusion.dominantInShoulderBox
                    d = classified.dominants(idx);
                    fprintf('    %4.0f um   %.2f      P%d   %4.0f   %d\n', ...
                            d.median, d.weight, d.passage, d.hce, d.k);
                end
                fprintf('\n');
            end
        end

        function reportDiscriminationSummary(confusion)
            % VIEW: Print final discrimination rate and verdict (TERMINAL)
            fprintf('Discrimination summary:\n');
            fprintf('  Total within-band components: %d\n', ...
                    classified.nTotal);
            fprintf('  Correctly placed:             %d\n', ...
                    confusion.counts(1, 1) + confusion.counts(2, 2));
            fprintf('  In middle gap:                %d\n', ...
                    confusion.counts(1, 3) + confusion.counts(2, 3));
            fprintf('  Crossovers (contamination):   %d\n', ...
                    confusion.nTotalCrossovers);
            fprintf('  Discrimination rate:          %.1f%%\n', ...
                    confusion.discriminationRate * 100);
            fprintf('  (Discrimination rate = correctly placed / total)\n\n');

            crossRate = confusion.nTotalCrossovers / classified.nTotal;
            if crossRate < 0.05
                fprintf('VERDICT: NEAR-PERFECT DISCRIMINATION ');
                fprintf('(<5%% contamination)\n');
            elseif crossRate < 0.10
                fprintf('VERDICT: STRONG DISCRIMINATION ');
                fprintf('(<10%% contamination)\n');
            elseif crossRate < 0.20
                fprintf('VERDICT: MODERATE DISCRIMINATION ');
                fprintf('(<20%% contamination)\n');
            else
                fprintf('VERDICT: WEAK DISCRIMINATION ');
                fprintf('(>=20%% contamination)\n');
            end
            fprintf('\n');
        end
    end
    end
end
function figureModel = renderDbf4Figure(Part3CompleteData)
    % CONTROLLER: Render the four-panel dbf4-1 phenotype figure
    % Reads from Part3CompleteData struct (see schema reference).
    % Returns the figure model so the classifier counts can be read after
    % the call (figureModel.panelD).
    % Panels:
    %   A. Passage stability - CV (CV by passage, WT vs dbf4-1)
    %   B. Passage stability - Skew (Skew by passage, WT vs dbf4-1)
    %   C. Distribution shape (KDE pair at matched colony count, P2)
    %   D. Classifier (CV-skew scatter, all genotypes, decision boundary)

    % === COORDINATE SUB-CONTROLLERS ===

    % Build the figure model: all filtered data and computed values
    figureModel = buildFigureModel(Part3CompleteData);

    % Set up the figure window and panel layout
    figureHandles = setupFigureLayout();

    % Render each panel
    renderPanelA_CVbyPassage(figureHandles.panelA, figureModel);
    renderPanelB_SkewByPassage(figureHandles.panelB, figureModel);
    renderPanelC_KdeOverlay(figureHandles.panelC, figureModel);
    renderPanelD_Classifier(figureHandles.panelD, figureModel);

    % Report the classifier counts quoted in the text
    reportClassifierSummary(figureModel);

    % === SUB-CONTROLLERS ===

    function figureModel = buildFigureModel(data)
        % SUB-CONTROLLER: Build the complete data model for all panels

        % Get the genotype color scheme
        colorScheme = getColorScheme();

        % Get the font scheme, in points at print size
        fontScheme = getFontScheme();

        % Filter the composite struct to the analytical population
        filteredData = filterCompositeStruct(data);

        % Build per-panel data structures
        panelAData = buildPanelAData(filteredData);
        panelBData = buildPanelBData(filteredData);
        panelCData = buildPanelCData(data);
        panelDData = buildPanelDData(filteredData, data);

        % Assemble the figure model
        figureModel = struct();
        figureModel.colorScheme = colorScheme;
        figureModel.fonts = fontScheme;
        figureModel.panelA = panelAData;
        figureModel.panelB = panelBData;
        figureModel.panelC = panelCData;
        figureModel.panelD = panelDData;

        function colorScheme = getColorScheme()
            % MODEL: Define the genotype color scheme (TERMINAL)
            colorScheme = struct();
            colorScheme.wild_type = [0.20, 0.45, 0.85];   % Blue
            colorScheme.dbf4_1    = [0.95, 0.55, 0.20];   % Orange
            colorScheme.cdc13_2   = [0.30, 0.70, 0.40];   % Green
            colorScheme.double    = [0.85, 0.45, 0.75];   % Pink/magenta
            colorScheme.tier_low      = [0.30, 0.65, 0.85];   % Light blue
            colorScheme.tier_moderate = [0.50, 0.50, 0.55];   % Gray
            colorScheme.tier_high     = [0.85, 0.30, 0.30];   % Red
            colorScheme.day6          = [0.20, 0.45, 0.85];   % Blue
            colorScheme.day21         = [0.85, 0.30, 0.30];   % Red
            colorScheme.boundary      = [0.20, 0.20, 0.20];   % Dark gray
        end

        function fontScheme = getFontScheme()
            % MODEL: Define font sizes in points (TERMINAL)
            % The figure is drawn at its printed size (see
            % computeLayoutConfiguration), so these values are the sizes
            % that appear on the page.
            fontScheme = struct();
            fontScheme.axes       = 9;    % Tick labels and axis labels
            fontScheme.title      = 10;   % Panel titles
            fontScheme.legend     = 8;    % Legend entries
            fontScheme.annotation = 8;    % Skew values in Panel C
            fontScheme.accuracy   = 8;    % Accuracy box in Panel D
        end

        function filteredData = filterCompositeStruct(data)
            % MODEL: Filter composite to Standard source, 6-day, A and B reps only (TERMINAL)
            comp = data.composite;
            nEntries = length(comp);

            keepMask = false(1, nEntries);
            for k = 1:nEntries
                isStandard = strcmp(comp(k).source_type, 'Standard');
                is6Day = (comp(k).incubation_days == 6);
                isABRep = ismember(comp(k).replicate, {'A', 'B'});
                hasData = ~isempty(comp(k).Measurements) && ...
                          isfield(comp(k).Measurements, 'Radius') && ...
                          ~isempty(comp(k).Measurements.Radius);
                keepMask(k) = isStandard && is6Day && isABRep && hasData;
            end

            filteredData = comp(keepMask);
        end

        function panelAData = buildPanelAData(filteredData)
            % MODEL: Build CV-by-passage data for WT and dbf4-1 (TERMINAL)
            nPlates = length(filteredData);
            genotypeList = cell(nPlates, 1);
            passageList = zeros(nPlates, 1);
            cvList = zeros(nPlates, 1);

            for k = 1:nPlates
                genotypeList{k} = filteredData(k).genotype;
                passageList(k) = filteredData(k).passage;
                if isfield(filteredData(k), 'summary_stats') && ...
                   ~isempty(filteredData(k).summary_stats) && ...
                   isfield(filteredData(k).summary_stats, 'cv')
                    cvList(k) = filteredData(k).summary_stats.cv;
                else
                    radii = filteredData(k).Measurements.Radius;
                    radii = radii(isfinite(radii));
                    cvList(k) = std(radii) / mean(radii);
                end
            end

            isWT  = strcmp(genotypeList, 'wild_type');
            isDbf = strcmp(genotypeList, 'dbf4-1');

            panelAData = struct();
            panelAData.passages = 1:5;
            panelAData.wt_passage = passageList(isWT);
            panelAData.wt_cv      = cvList(isWT);
            panelAData.dbf_passage = passageList(isDbf);
            panelAData.dbf_cv      = cvList(isDbf);
        end

        function panelBData = buildPanelBData(filteredData)
            % MODEL: Build skew-by-passage data for WT and dbf4-1 (TERMINAL)
            nPlates = length(filteredData);
            genotypeList = cell(nPlates, 1);
            passageList = zeros(nPlates, 1);
            skewList = zeros(nPlates, 1);

            for k = 1:nPlates
                genotypeList{k} = filteredData(k).genotype;
                passageList(k) = filteredData(k).passage;
                if isfield(filteredData(k), 'summary_stats') && ...
                   ~isempty(filteredData(k).summary_stats) && ...
                   isfield(filteredData(k).summary_stats, 'skew')
                    skewList(k) = filteredData(k).summary_stats.skew;
                else
                    radii = filteredData(k).Measurements.Radius;
                    radii = radii(isfinite(radii));
                    skewList(k) = skewness(radii);
                end
            end

            isWT  = strcmp(genotypeList, 'wild_type');
            isDbf = strcmp(genotypeList, 'dbf4-1');

            panelBData = struct();
            panelBData.passages = 1:5;
            panelBData.wt_passage = passageList(isWT);
            panelBData.wt_skew    = skewList(isWT);
            panelBData.dbf_passage = passageList(isDbf);
            panelBData.dbf_skew    = skewList(isDbf);
        end

        function panelCData = buildPanelCData(allData)
            % SUB-CONTROLLER: Select and extract the Panel C KDE pair
            %
            % Panel C compares distribution shape between wild type and dbf4-1
            % at one passage, using the pooled A+B plates. The pair is chosen by
            % colony count: among the eligible candidates of each genotype, the
            % WT and dbf4-1 plates whose counts agree most closely. Matching on
            % count keeps KDE sampling noise comparable between the two curves,
            % so a difference in curve shape is not a difference in how many
            % colonies built each curve.
            %
            % Selection diagnostics travel out with the data (both HCE values,
            % both counts, the relative count difference), so the panel title
            % and legend can state which plates were drawn rather than carry a
            % hardcoded value that drifts from the data.
            %
            % The y limits leave headroom above the taller curve, so the
            % legend and the skew annotations in the upper left sit in empty
            % space above the KDEs.

            targetPassage = 2;

            wtCandidates  = collectPooledCandidates(allData.composite, 'wild_type', targetPassage);
            dbfCandidates = collectPooledCandidates(allData.composite, 'dbf4-1', targetPassage);

            pairing = pickMatchedPair(wtCandidates, dbfCandidates);

            wtKde  = extractKdeAndStats(pairing.wtPlate);
            dbfKde = extractKdeAndStats(pairing.dbfPlate);

            panelCData = struct();
            panelCData.wt        = wtKde;
            panelCData.dbf       = dbfKde;
            panelCData.passage   = targetPassage;
            panelCData.selection = pairing.diagnostics;
            panelCData.yLimits   = computeKdeYLimits(wtKde, dbfKde);

            function yLimits = computeKdeYLimits(wtKde, dbfKde)
                % MODEL (TERMINAL): y limits that place the taller KDE peak
                % at 60% of the axis height
                %
                % The upper 40% holds the two-entry legend and the two skew
                % lines stacked beneath it.
                peakFraction = 0.60;
                peak = max([wtKde.density(:); dbfKde.density(:); 0]);
                if peak > 0
                    yLimits = [0, peak / peakFraction];
                else
                    yLimits = [0, 1];
                end
            end

            % === SHARED FUNCTIONS ===

            function candidates = collectPooledCandidates(comp, genotypeName, passageNumber)
                % MODEL (TERMINAL): eligible pooled plates for one genotype cell
                %
                % A candidate is a Standard-source, 6-day, A+B pooled plate at
                % the target passage that already carries a usable KDE and the
                % three summary statistics the panel reads. Screening for the
                % KDE here means the pair chosen downstream is guaranteed to
                % plot; a plate that passes selection but has no curve would
                % reproduce the blank panel this selection replaces.

                nEntries = numel(comp);
                keepMask = false(1, nEntries);

                for k = 1:nEntries
                    e = comp(k);

                    isGenotype = strcmp(e.genotype, genotypeName);
                    isPassage  = isnumeric(e.passage) && isscalar(e.passage) && ...
                                 e.passage == passageNumber;
                    isStandard = strcmp(e.source_type, 'Standard');
                    isSixDay   = isequal(e.incubation_days, 6);
                    isPooled   = strcmp(e.replicate, 'A+B');
                    hasCount   = isnumeric(e.colony_count) && isscalar(e.colony_count) && ...
                                 isfinite(e.colony_count) && e.colony_count >= 2;

                    hasKde = false;
                    if isfield(e, 'kde') && ~isempty(e.kde) && isstruct(e.kde) && ...
                       isfield(e.kde, 'eval_x_log') && isfield(e.kde, 'density')
                        hasKde = ~isempty(e.kde.eval_x_log) && ...
                                 numel(e.kde.density) == numel(e.kde.eval_x_log);
                    end

                    hasStats = false;
                    if isfield(e, 'summary_stats') && ~isempty(e.summary_stats) && ...
                       isfield(e.summary_stats, 'skew') && ...
                       isfield(e.summary_stats, 'cv') && ...
                       isfield(e.summary_stats, 'median')
                        hasStats = isfinite(e.summary_stats.skew) && ...
                                   isfinite(e.summary_stats.cv) && ...
                                   isfinite(e.summary_stats.median);
                    end

                    keepMask(k) = isGenotype && isPassage && isStandard && ...
                                  isSixDay && isPooled && hasCount && ...
                                  hasKde && hasStats;
                end

                candidates = comp(keepMask);
            end

            function pairing = pickMatchedPair(wtCandidates, dbfCandidates)
                % MODEL (TERMINAL): the WT and dbf4-1 candidates with the
                % closest colony counts
                %
                % Score is the count difference relative to the smaller count,
                % so a 3-colony gap between plates of 286 and 289 ranks ahead of
                % the same gap between plates of 20 and 23. Exact ties break on
                % HCE proximity. Either candidate list being empty leaves the
                % plates empty and found false; the caller's extraction handles
                % that case without erroring.

                pairing = struct();
                pairing.wtPlate  = [];
                pairing.dbfPlate = [];

                diagnostics = struct();
                diagnostics.found        = false;
                diagnostics.wtHce        = NaN;
                diagnostics.dbfHce       = NaN;
                diagnostics.wtCount      = NaN;
                diagnostics.dbfCount     = NaN;
                diagnostics.countDiff    = NaN;
                diagnostics.relCountDiff = NaN;
                diagnostics.hceRatio     = NaN;
                diagnostics.nWtOptions   = numel(wtCandidates);
                diagnostics.nDbfOptions  = numel(dbfCandidates);

                pairing.diagnostics = diagnostics;

                if isempty(wtCandidates) || isempty(dbfCandidates)
                    return;
                end

                bestScore    = Inf;
                bestHceRatio = Inf;
                bestI = 0;
                bestJ = 0;

                for i = 1:numel(wtCandidates)
                    nWt = double(wtCandidates(i).colony_count);
                    hWt = double(wtCandidates(i).hce);

                    for j = 1:numel(dbfCandidates)
                        nDbf = double(dbfCandidates(j).colony_count);
                        hDbf = double(dbfCandidates(j).hce);

                        score = abs(nWt - nDbf) / min(nWt, nDbf);

                        if isfinite(hWt) && isfinite(hDbf) && hWt > 0 && hDbf > 0
                            hceRatio = max(hWt, hDbf) / min(hWt, hDbf);
                        else
                            hceRatio = Inf;
                        end

                        isBetter = score < bestScore || ...
                                   (score == bestScore && hceRatio < bestHceRatio);

                        if isBetter
                            bestScore    = score;
                            bestHceRatio = hceRatio;
                            bestI = i;
                            bestJ = j;
                        end
                    end
                end

                if bestI == 0 || bestJ == 0
                    return;
                end

                wtPick  = wtCandidates(bestI);
                dbfPick = dbfCandidates(bestJ);

                pairing.wtPlate  = wtPick;
                pairing.dbfPlate = dbfPick;

                diagnostics.found        = true;
                diagnostics.wtHce        = double(wtPick.hce);
                diagnostics.dbfHce       = double(dbfPick.hce);
                diagnostics.wtCount      = double(wtPick.colony_count);
                diagnostics.dbfCount     = double(dbfPick.colony_count);
                diagnostics.countDiff    = abs(diagnostics.wtCount - diagnostics.dbfCount);
                diagnostics.relCountDiff = bestScore;
                diagnostics.hceRatio     = bestHceRatio;

                pairing.diagnostics = diagnostics;
            end

            function out = extractKdeAndStats(plate)
                % MODEL (TERMINAL): pull KDE and key stats from a plate entry
                %
                % An empty plate returns the same field set with empty curves
                % and NaN statistics, so the plotting and annotation terminals
                % downstream read a consistent shape whether or not a pair was
                % found.

                out = struct();
                if isempty(plate)
                    out.eval_x_log = [];
                    out.density    = [];
                    out.skew       = NaN;
                    out.cv         = NaN;
                    out.median     = NaN;
                    out.hce        = NaN;
                    out.count      = 0;
                    return;
                end

                out.eval_x_log = plate.kde.eval_x_log;
                out.density    = plate.kde.density;
                out.skew       = plate.summary_stats.skew;
                out.cv         = plate.summary_stats.cv;
                out.median     = plate.summary_stats.median;
                out.hce        = double(plate.hce);
                out.count      = double(plate.colony_count);
            end
        end

        function panelDData = buildPanelDData(filteredData, allData)
            % MODEL: Build classifier data for all four genotypes (TERMINAL)
            % Filter: Standard, 6-day, A and B reps only
            % Includes all four genotypes (not just WT and dbf4-1)
            %
            % Centroids and scaling come from WT and dbf4-1 plates only. Every
            % plate is then assigned to the nearer centroid, and accuracy is
            % binary: dbf4-1 single mutant or not. Three reference numbers
            % travel out with the accuracy so the text can report it fairly:
            %   baseline_accuracy  accuracy of assigning every plate to the
            %                      more common class (dbf4-1 or not dbf4-1)
            %   wtdbf_accuracy     accuracy on WT and dbf4-1 plates alone,
            %                      the two genotypes that set the centroids
            %   per_genotype       plates and correct assignments per genotype

            comp = allData.composite;
            nAll = length(comp);
            keepMask = false(1, nAll);
            for k = 1:nAll
                isStandard = strcmp(comp(k).source_type, 'Standard');
                is6Day = (comp(k).incubation_days == 6);
                isABRep = ismember(comp(k).replicate, {'A', 'B'});
                hasData = ~isempty(comp(k).Measurements) && ...
                          isfield(comp(k).Measurements, 'Radius') && ...
                          ~isempty(comp(k).Measurements.Radius);
                hasStats = isfield(comp(k), 'summary_stats') && ...
                           ~isempty(comp(k).summary_stats) && ...
                           isfield(comp(k).summary_stats, 'cv') && ...
                           isfinite(comp(k).summary_stats.cv) && ...
                           isfield(comp(k).summary_stats, 'skew') && ...
                           isfinite(comp(k).summary_stats.skew);
                keepMask(k) = isStandard && is6Day && isABRep && hasData && hasStats;
            end
            classifierData = comp(keepMask);

            nPlates = length(classifierData);
            cvVals = zeros(nPlates, 1);
            skewVals = zeros(nPlates, 1);
            genotypes = cell(nPlates, 1);
            for k = 1:nPlates
                cvVals(k) = classifierData(k).summary_stats.cv;
                skewVals(k) = classifierData(k).summary_stats.skew;
                genotypes{k} = classifierData(k).genotype;
            end

            % Compute centroids on dbf4-1 and WT
            isWT = strcmp(genotypes, 'wild_type');
            isDbf = strcmp(genotypes, 'dbf4-1');

            wt_centroid_cv = mean(cvVals(isWT));
            wt_centroid_skew = mean(skewVals(isWT));
            dbf_centroid_cv = mean(cvVals(isDbf));
            dbf_centroid_skew = mean(skewVals(isDbf));

            % Pooled standard deviations for normalization
            sd_cv = std([cvVals(isWT); cvVals(isDbf)]);
            sd_skew = std([skewVals(isWT); skewVals(isDbf)]);

            % Classify every plate
            classification = cell(nPlates, 1);
            for k = 1:nPlates
                d_dbf = sqrt(((cvVals(k) - dbf_centroid_cv)/sd_cv)^2 + ...
                             ((skewVals(k) - dbf_centroid_skew)/sd_skew)^2);
                d_wt = sqrt(((cvVals(k) - wt_centroid_cv)/sd_cv)^2 + ...
                            ((skewVals(k) - wt_centroid_skew)/sd_skew)^2);
                if d_dbf < d_wt
                    classification{k} = 'dbf4-1';
                else
                    classification{k} = 'wild_type';
                end
            end

            % Compute binary accuracy
            isCorrect = false(nPlates, 1);
            for k = 1:nPlates
                isDbfPlate = strcmp(genotypes{k}, 'dbf4-1');
                isDbfClass = strcmp(classification{k}, 'dbf4-1');
                isCorrect(k) = (isDbfPlate == isDbfClass);
            end
            nCorrect = sum(isCorrect);
            accuracy = nCorrect / nPlates;

            % Baseline: assign every plate to the more common class
            nDbf = sum(isDbf);
            nNotDbf = nPlates - nDbf;
            baseline_accuracy = max(nDbf, nNotDbf) / nPlates;

            % Accuracy on the two genotypes that set the centroids
            isWtOrDbf = isWT | isDbf;
            wtdbf_n = sum(isWtOrDbf);
            wtdbf_correct = sum(isCorrect(isWtOrDbf));
            wtdbf_accuracy = wtdbf_correct / wtdbf_n;
            wtdbf_baseline = max(sum(isWT), sum(isDbf)) / wtdbf_n;

            % Plates and correct assignments per genotype
            genotypeNames = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
            per_genotype = struct('genotype', genotypeNames, ...
                                  'n_plates', 0, 'n_correct', 0);
            for g = 1:length(genotypeNames)
                mask = strcmp(genotypes, genotypeNames{g});
                per_genotype(g).n_plates = sum(mask);
                per_genotype(g).n_correct = sum(isCorrect(mask));
            end

            panelDData = struct();
            panelDData.cv = cvVals;
            panelDData.skew = skewVals;
            panelDData.genotype = genotypes;
            panelDData.classification = classification;
            panelDData.wt_centroid = [wt_centroid_cv, wt_centroid_skew];
            panelDData.dbf_centroid = [dbf_centroid_cv, dbf_centroid_skew];
            panelDData.sd_cv = sd_cv;
            panelDData.sd_skew = sd_skew;
            panelDData.n_plates = nPlates;
            panelDData.n_correct = nCorrect;
            panelDData.accuracy = accuracy;
            panelDData.n_dbf = nDbf;
            panelDData.baseline_accuracy = baseline_accuracy;
            panelDData.wtdbf_n = wtdbf_n;
            panelDData.wtdbf_correct = wtdbf_correct;
            panelDData.wtdbf_accuracy = wtdbf_accuracy;
            panelDData.wtdbf_baseline = wtdbf_baseline;
            panelDData.per_genotype = per_genotype;
        end
    end

    function figureHandles = setupFigureLayout()
        % SUB-CONTROLLER: Create the figure window and layout panels in 2x2 grid

        % Compute layout positions
        layoutConfig = computeLayoutConfiguration();

        % Create the figure window
        figHandle = createFigureWindow(layoutConfig);

        % Create each panel's axes
        figureHandles = createPanelAxes(figHandle, layoutConfig);

        function layoutConfig = computeLayoutConfiguration()
            % MODEL: Compute positions for 2x2 grid (TERMINAL)
            % The figure is sized in inches at its printed width, so the
            % font sizes in getFontScheme print at their stated point size.
            layoutConfig = struct();
            layoutConfig.figureUnits = 'inches';
            layoutConfig.figureSize = [1, 1, 6.5, 5.4];   % [left, bottom, width, height]
            layoutConfig.figureColor = [1, 1, 1];
            layoutConfig.fontName = 'Times New Roman';

            % Margins (normalized)
            leftMargin = 0.09;
            rightMargin = 0.03;
            topMargin = 0.05;
            bottomMargin = 0.09;
            hGap = 0.10;
            vGap = 0.12;

            % Cell dimensions
            cellW = (1 - leftMargin - rightMargin - hGap) / 2;
            cellH = (1 - topMargin - bottomMargin - vGap) / 2;

            % Row Y coordinates
            topRowY = bottomMargin + cellH + vGap;
            bottomRowY = bottomMargin;

            % Panel positions: [left, bottom, width, height]
            layoutConfig.panelAPos = [leftMargin,                topRowY,    cellW, cellH];
            layoutConfig.panelBPos = [leftMargin + cellW + hGap, topRowY,    cellW, cellH];
            layoutConfig.panelCPos = [leftMargin,                bottomRowY, cellW, cellH];
            layoutConfig.panelDPos = [leftMargin + cellW + hGap, bottomRowY, cellW, cellH];
        end

        function figHandle = createFigureWindow(layoutConfig)
            % VIEW: Create the figure window at printed size (TERMINAL)
            % Paper size matches the figure, so a print or export keeps the
            % same dimensions. Figure-level defaults set the font family for
            % every axes, text object, and legend created inside it.
            figHandle = figure('Units', layoutConfig.figureUnits, ...
                               'Position', layoutConfig.figureSize, ...
                               'PaperUnits', layoutConfig.figureUnits, ...
                               'PaperSize', layoutConfig.figureSize(3:4), ...
                               'PaperPosition', [0, 0, layoutConfig.figureSize(3:4)], ...
                               'Color', layoutConfig.figureColor, ...
                               'Name', 'dbf4-1 Phenotype Figure', ...
                               'NumberTitle', 'off', ...
                               'DefaultAxesFontName', layoutConfig.fontName, ...
                               'DefaultTextFontName', layoutConfig.fontName, ...
                               'DefaultLegendFontName', layoutConfig.fontName);
        end

        function figureHandles = createPanelAxes(figHandle, layoutConfig)
            % VIEW: Create the axes for each panel (TERMINAL)
            figureHandles = struct();
            figureHandles.fig = figHandle;
            figureHandles.panelA = axes('Parent', figHandle, 'Position', layoutConfig.panelAPos);
            figureHandles.panelB = axes('Parent', figHandle, 'Position', layoutConfig.panelBPos);
            figureHandles.panelC = axes('Parent', figHandle, 'Position', layoutConfig.panelCPos);
            figureHandles.panelD = axes('Parent', figHandle, 'Position', layoutConfig.panelDPos);
        end
    end

    function renderPanelA_CVbyPassage(ax, model)
        % SUB-CONTROLLER: Render CV-by-passage strip plot, WT vs dbf4-1

        % Prepare the axes
        prepareAxes(ax);

        % Plot the strip points
        plotPassageStripPoints(ax, model);

        % Plot the per-passage mean lines
        plotPassageMeanLines(ax, model);

        % Configure axes labels and title
        configurePanelALabels(ax, model);

        % Add the legend
        addPanelALegend(ax, model);

        function plotPassageStripPoints(ax, model)
            % SUB-CONTROLLER: Plot CV values for each plate, jittered by genotype

            d = model.panelA;
            colors = model.colorScheme;

            % Plot WT points
            plotGenotypeStrip(ax, d.wt_passage, d.wt_cv, -0.15, colors.wild_type);

            % Plot dbf4-1 points
            plotGenotypeStrip(ax, d.dbf_passage, d.dbf_cv, +0.15, colors.dbf4_1);

            function plotGenotypeStrip(ax, passages, cvs, xOffset, color)
                % VIEW: Plot one genotype's CV strip with horizontal offset (TERMINAL)
                jitter = (rand(size(passages)) - 0.5) * 0.08;
                xVals = passages + xOffset + jitter;
                scatter(ax, xVals, cvs, 20, color, 'filled', ...
                        'MarkerFaceAlpha', 0.7, 'MarkerEdgeColor', 'none');
            end
        end

        function plotPassageMeanLines(ax, model)
            % SUB-CONTROLLER: Plot mean CV lines for each genotype across passages

            d = model.panelA;
            colors = model.colorScheme;

            % WT mean line
            wtMeans = computeMeanByPassage(d.wt_passage, d.wt_cv, d.passages);
            plotMeanLine(ax, d.passages, wtMeans, colors.wild_type);

            % dbf4-1 mean line
            dbfMeans = computeMeanByPassage(d.dbf_passage, d.dbf_cv, d.passages);
            plotMeanLine(ax, d.passages, dbfMeans, colors.dbf4_1);

            function means = computeMeanByPassage(passages, values, passageRange)
                % MODEL: Compute mean value at each passage (TERMINAL)
                means = nan(size(passageRange));
                for p = 1:length(passageRange)
                    mask = (passages == passageRange(p));
                    if any(mask)
                        means(p) = mean(values(mask));
                    end
                end
            end

            function plotMeanLine(ax, xVals, yVals, color)
                % VIEW: Plot the mean trajectory line (TERMINAL)
                plot(ax, xVals, yVals, '-', 'Color', color, ...
                     'LineWidth', 1.5);
            end
        end

        function configurePanelALabels(ax, model)
            % VIEW: Set Panel A labels and limits (TERMINAL)
            fonts = model.fonts;
            set(ax, 'XTick', 1:5, 'Box', 'on', 'FontSize', fonts.axes);
            xlabel(ax, 'Passage', 'FontSize', fonts.axes);
            ylabel(ax, 'CV', 'FontSize', fonts.axes);
            title(ax, 'A. CV across passages', 'FontWeight', 'bold', ...
                  'FontSize', fonts.title);
            xlim(ax, [0.5, 5.5]);
            ylim(ax, [0, 0.7]);
        end

        function addPanelALegend(ax, model)
            % VIEW: Add manual legend for genotypes (TERMINAL)
            colors = model.colorScheme;
            hold(ax, 'on');
            h1 = scatter(ax, NaN, NaN, 20, colors.wild_type, 'filled');
            h2 = scatter(ax, NaN, NaN, 20, colors.dbf4_1, 'filled');
            legend(ax, [h1, h2], {'Wild type', 'dbf4-1'}, ...
                   'Location', 'northwest', 'Box', 'off', ...
                   'FontSize', model.fonts.legend);
        end

        function prepareAxes(ax)
            % VIEW: Prepare axes for plotting (TERMINAL)
            axes(ax);
            cla(ax);
            hold(ax, 'on');
        end
    end

    function renderPanelB_SkewByPassage(ax, model)
        % SUB-CONTROLLER: Render skew-by-passage strip plot, WT vs dbf4-1

        % Prepare the axes
        prepareAxes(ax);

        % Draw the zero-skew reference line
        drawZeroLine(ax);

        % Plot the strip points
        plotPassageStripPoints(ax, model);

        % Plot the per-passage mean lines
        plotPassageMeanLines(ax, model);

        % Configure axes labels and title
        configurePanelBLabels(ax, model);

        % Add the legend
        addPanelBLegend(ax, model);

        function prepareAxes(ax)
            % VIEW: Prepare axes for plotting (TERMINAL)
            axes(ax);
            cla(ax);
            hold(ax, 'on');
        end

        function drawZeroLine(ax)
            % VIEW: Draw horizontal reference line at skew = 0 (TERMINAL)
            plot(ax, [0.5, 5.5], [0, 0], '-', ...
                 'Color', [0.6, 0.6, 0.6], 'LineWidth', 0.8);
        end

        function plotPassageStripPoints(ax, model)
            % SUB-CONTROLLER: Plot skew values for each plate, jittered by genotype

            d = model.panelB;
            colors = model.colorScheme;

            % Plot WT points
            plotGenotypeStrip(ax, d.wt_passage, d.wt_skew, -0.15, colors.wild_type);

            % Plot dbf4-1 points
            plotGenotypeStrip(ax, d.dbf_passage, d.dbf_skew, +0.15, colors.dbf4_1);

            function plotGenotypeStrip(ax, passages, skews, xOffset, color)
                % VIEW: Plot one genotype's skew strip with horizontal offset (TERMINAL)
                jitter = (rand(size(passages)) - 0.5) * 0.08;
                xVals = passages + xOffset + jitter;
                scatter(ax, xVals, skews, 20, color, 'filled', ...
                        'MarkerFaceAlpha', 0.7, 'MarkerEdgeColor', 'none');
            end
        end

        function plotPassageMeanLines(ax, model)
            % SUB-CONTROLLER: Plot mean skew lines for each genotype across passages

            d = model.panelB;
            colors = model.colorScheme;

            % WT mean line
            wtMeans = computeMeanByPassage(d.wt_passage, d.wt_skew, d.passages);
            plotMeanLine(ax, d.passages, wtMeans, colors.wild_type);

            % dbf4-1 mean line
            dbfMeans = computeMeanByPassage(d.dbf_passage, d.dbf_skew, d.passages);
            plotMeanLine(ax, d.passages, dbfMeans, colors.dbf4_1);

            function means = computeMeanByPassage(passages, values, passageRange)
                % MODEL: Compute mean value at each passage (TERMINAL)
                means = nan(size(passageRange));
                for p = 1:length(passageRange)
                    mask = (passages == passageRange(p));
                    if any(mask)
                        means(p) = mean(values(mask));
                    end
                end
            end

            function plotMeanLine(ax, xVals, yVals, color)
                % VIEW: Plot the mean trajectory line (TERMINAL)
                plot(ax, xVals, yVals, '-', 'Color', color, ...
                     'LineWidth', 1.5);
            end
        end

        function configurePanelBLabels(ax, model)
            % VIEW: Set Panel B labels and limits (TERMINAL)
            fonts = model.fonts;
            set(ax, 'XTick', 1:5, 'Box', 'on', 'FontSize', fonts.axes);
            xlabel(ax, 'Passage', 'FontSize', fonts.axes);
            ylabel(ax, 'Skew', 'FontSize', fonts.axes);
            title(ax, 'B. Skew across passages', 'FontWeight', 'bold', ...
                  'FontSize', fonts.title);
            xlim(ax, [0.5, 5.5]);
            ylim(ax, [-1.5, 2.0]);
        end

        function addPanelBLegend(ax, model)
            % VIEW: Add manual legend for genotypes (TERMINAL)
            colors = model.colorScheme;
            hold(ax, 'on');
            h1 = scatter(ax, NaN, NaN, 20, colors.wild_type, 'filled');
            h2 = scatter(ax, NaN, NaN, 20, colors.dbf4_1, 'filled');
            legend(ax, [h1, h2], {'Wild type', 'dbf4-1'}, ...
                   'Location', 'northwest', 'Box', 'off', ...
                   'FontSize', model.fonts.legend);
        end
    end

    function renderPanelC_KdeOverlay(ax, model)
        % SUB-CONTROLLER: Render KDE overlay of WT vs dbf4-1 at matched colony count

        % Prepare the axes
        preparePanelCAxes(ax);

        % Plot the two KDEs
        plotMatchedKdes(ax, model);

        % Configure labels, scale, and limits
        configurePanelCLabels(ax, model);

        % Add the legend; its handle positions the skew annotations
        legendHandle = addPanelCLegend(ax, model);

        % Annotate skew values directly beneath the legend
        annotateSkewValues(ax, model, legendHandle);

        function preparePanelCAxes(ax)
            % VIEW: Prepare axes for Panel C (TERMINAL)
            axes(ax);
            cla(ax);
            hold(ax, 'on');
        end

        function plotMatchedKdes(ax, model)
            % SUB-CONTROLLER: Plot the WT and dbf4-1 KDE curves

            d = model.panelC;
            colors = model.colorScheme;

            % Plot WT KDE
            plotSingleKde(ax, d.wt, colors.wild_type);

            % Plot dbf4-1 KDE
            plotSingleKde(ax, d.dbf, colors.dbf4_1);

            function plotSingleKde(ax, kdeData, color)
                % VIEW: Plot one KDE curve (TERMINAL)
                if isempty(kdeData.eval_x_log), return; end
                xVals = exp(kdeData.eval_x_log);  % Convert back to linear radius
                plot(ax, xVals, kdeData.density, '-', ...
                     'Color', color, 'LineWidth', 1.5);
            end
        end

        function annotateSkewValues(ax, model, legendHandle)
            % VIEW: Add skew value text directly beneath the legend (TERMINAL)
            % The legend and axes positions are both in figure-normalized
            % units, so the legend's lower-left corner converts to
            % axes-normalized coordinates by offset and scale. Placing the
            % text in normalized units keeps it independent of the log
            % x scale and the data limits. Line spacing is 1.3 times the
            % font size, converted from points to a fraction of the axes
            % height using the printed figure height in inches.
            d = model.panelC;
            colors = model.colorScheme;
            fontSize = model.fonts.annotation;

            drawnow;
            axPos  = get(ax, 'Position');
            legPos = get(legendHandle, 'Position');
            figPos = get(ancestor(ax, 'figure'), 'Position');

            axHeightInches = figPos(4) * axPos(4);
            lineStep = 1.3 * (fontSize / 72) / axHeightInches;

            xN = (legPos(1) - axPos(1)) / axPos(3) + 0.03;
            yN = (legPos(2) - axPos(2)) / axPos(4);

            text(ax, xN, yN, sprintf('WT skew: %+.2f', d.wt.skew), ...
                 'Units', 'normalized', 'VerticalAlignment', 'top', ...
                 'Color', colors.wild_type, 'FontSize', fontSize, 'FontWeight', 'bold');
            text(ax, xN, yN - lineStep, sprintf('dbf4-1 skew: %+.2f', d.dbf.skew), ...
                 'Units', 'normalized', 'VerticalAlignment', 'top', ...
                 'Color', colors.dbf4_1, 'FontSize', fontSize, 'FontWeight', 'bold');
        end

        function configurePanelCLabels(ax, model)
            % VIEW (TERMINAL): Set Panel C labels, scale, tick marks, and y limits
            %
            % The x axis stays logarithmic. Automatic log ticks fall on decades,
            % and the colony radii span less than one decade, so only 10^3 lands
            % inside the data range and the axis reads as a single unlabeled
            % sweep. The ticks below are placed at fixed linear radii across the
            % occupied range and labeled with plain integers. Spacing is uneven
            % in axis coordinates because the scale is logarithmic; that is the
            % intended appearance, since the reference values the reader needs
            % are radii, not powers of ten.
            %
            % Minor ticks are turned off. MATLAB continues to subdivide log
            % decades regardless of the major tick positions, which would leave
            % minor marks at 200, 300, 400 and so on with no relationship to the
            % labeled values.
            %
            % The y limits come from the model and leave headroom above the
            % curves for the legend and skew annotations.

            fonts = model.fonts;

            set(ax, 'XScale', 'log', 'Box', 'on', 'FontSize', fonts.axes);

            xlabel(ax, 'Colony radius (\mum)', 'FontSize', fonts.axes);
            ylabel(ax, 'Density', 'FontSize', fonts.axes);
            % The title reports the colony count the pair was matched on,
            % taken as the rounded mean of the two plates' counts.
            d = model.panelC;
            matchedCount = round(mean([d.wt.count, d.dbf.count]));
            title(ax, sprintf('C. Distribution shape, P%d, ~%d colonies', ...
                              d.passage, matchedCount), ...
                  'FontWeight', 'bold', 'FontSize', fonts.title);

            set(ax, 'XTick', [250, 500, 750, 1000, 1500], ...
                    'XTickLabel', {'250', '500', '750', '1000', '1500'}, ...
                    'XMinorTick', 'off');

            ylim(ax, model.panelC.yLimits);

        end

        function legendHandle = addPanelCLegend(ax, model)
            % VIEW: Add legend and return its handle (TERMINAL)
            colors = model.colorScheme;
            d = model.panelC;
            wtLabel = sprintf('Wild type (n=%d)', d.wt.count);
            dbfLabel = sprintf('dbf4-1 (n=%d)', d.dbf.count);
            h1 = plot(ax, NaN, NaN, '-', 'Color', colors.wild_type, 'LineWidth', 1.5);
            h2 = plot(ax, NaN, NaN, '-', 'Color', colors.dbf4_1, 'LineWidth', 1.5);
            legendHandle = legend(ax, [h1, h2], {wtLabel, dbfLabel}, ...
                                  'Location', 'northwest', 'Box', 'off', ...
                                  'FontSize', model.fonts.legend);
        end
    end

    function renderPanelD_Classifier(ax, model)
        % SUB-CONTROLLER: Render the (CV, skew) classifier scatter

        % Prepare the axes
        preparePanelDAxes(ax);

        % Plot the data points by genotype
        plotClassifierPoints(ax, model);

        % Draw the decision boundary
        drawDecisionBoundary(ax, model);

        % Mark the centroids
        markCentroids(ax, model);

        % Configure labels and title before annotating, so the annotation
        % position is computed from the final axis limits
        configurePanelDLabels(ax, model);

        % Annotate the accuracy
        annotateAccuracy(ax, model);

        % Add the legend
        addPanelDLegend(ax, model);

        function preparePanelDAxes(ax)
            % VIEW: Prepare axes for Panel D (TERMINAL)
            axes(ax);
            cla(ax);
            hold(ax, 'on');
        end

        function plotClassifierPoints(ax, model)
            % SUB-CONTROLLER: Plot each genotype's plates in (CV, skew) space

            d = model.panelD;
            colors = model.colorScheme;

            genotypeNames = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
            colorList = {colors.wild_type, colors.dbf4_1, colors.cdc13_2, colors.double};

            for g = 1:length(genotypeNames)
                mask = strcmp(d.genotype, genotypeNames{g});
                if ~any(mask), continue; end
                plotOneGenotypeScatter(ax, d.cv(mask), d.skew(mask), colorList{g});
            end

            function plotOneGenotypeScatter(ax, cvs, skews, color)
                % VIEW: Plot scatter for one genotype (TERMINAL)
                scatter(ax, cvs, skews, 20, color, 'filled', ...
                        'MarkerFaceAlpha', 0.70, 'MarkerEdgeColor', 'k', ...
                        'LineWidth', 0.3);
            end
        end

        function drawDecisionBoundary(ax, model)
            % SUB-CONTROLLER: Compute and draw the decision boundary line

            % Compute boundary endpoints in raw (CV, skew) space
            boundaryPoints = computeDecisionBoundary(model);

            % Draw the boundary line
            renderBoundaryLine(ax, boundaryPoints, model);

            function bp = computeDecisionBoundary(model)
                % MODEL: Compute boundary line endpoints (TERMINAL)
                % The decision boundary in normalized space is the perpendicular
                % bisector of the segment between centroids; transform back to raw space.

                d = model.panelD;
                wt = d.wt_centroid;
                df = d.dbf_centroid;
                sd_cv = d.sd_cv;
                sd_skew = d.sd_skew;

                % Midpoint in raw space
                midRaw = (wt + df) / 2;

                % Direction vector from WT to dbf4-1 in normalized space
                dirNorm = [(df(1) - wt(1))/sd_cv, (df(2) - wt(2))/sd_skew];
                dirNorm = dirNorm / norm(dirNorm);

                % Perpendicular in normalized space
                perpNorm = [-dirNorm(2), dirNorm(1)];

                % Convert perpendicular back to raw space
                perpRaw = [perpNorm(1) * sd_cv, perpNorm(2) * sd_skew];

                % Extend the boundary line a long distance in both directions
                tRange = 5;
                t = linspace(-tRange, tRange, 100);
                bp = struct();
                bp.cv = midRaw(1) + t * perpRaw(1);
                bp.skew = midRaw(2) + t * perpRaw(2);
            end

            function renderBoundaryLine(ax, boundaryPoints, model)
                % VIEW: Draw the boundary line (TERMINAL)
                color = model.colorScheme.boundary;
                plot(ax, boundaryPoints.cv, boundaryPoints.skew, '--', ...
                     'Color', color, 'LineWidth', 1.0);
            end
        end

        function markCentroids(ax, model)
            % VIEW: Mark the two centroids (TERMINAL)
            d = model.panelD;
            colors = model.colorScheme;

            scatter(ax, d.wt_centroid(1), d.wt_centroid(2), 110, colors.wild_type, ...
                    'p', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 0.8);
            scatter(ax, d.dbf_centroid(1), d.dbf_centroid(2), 110, colors.dbf4_1, ...
                    'p', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 0.8);
        end

        function annotateAccuracy(ax, model)
            % VIEW: Add accuracy and baseline text to the panel (TERMINAL)
            % The baseline is the accuracy of assigning every plate to the
            % more common class, so the reader can judge the accuracy
            % against it.
            d = model.panelD;
            accuracyText = sprintf('Accuracy: %.1f%% (%d/%d)\nBaseline: %.1f%%', ...
                                   100 * d.accuracy, d.n_correct, d.n_plates, ...
                                   100 * d.baseline_accuracy);

            xLim = get(ax, 'XLim');
            yLim = get(ax, 'YLim');
            xPos = xLim(1) + 0.05 * (xLim(2) - xLim(1));
            yPos = yLim(1) + 0.12 * (yLim(2) - yLim(1));

            text(ax, xPos, yPos, accuracyText, ...
                 'FontSize', model.fonts.accuracy, 'FontWeight', 'bold', ...
                 'BackgroundColor', [1, 1, 1, 0.8], ...
                 'EdgeColor', 'k', 'Margin', 2, ...
                 'VerticalAlignment', 'bottom');
        end

        function configurePanelDLabels(ax, model)
            % VIEW: Set Panel D labels (TERMINAL)
            fonts = model.fonts;
            set(ax, 'Box', 'on', 'FontSize', fonts.axes);
            xlabel(ax, 'CV', 'FontSize', fonts.axes);
            ylabel(ax, 'Skew', 'FontSize', fonts.axes);
            title(ax, 'D. dbf4-1 classifier in (CV, skew) space', 'FontWeight', 'bold', ...
                  'FontSize', fonts.title);
            xlim(ax, [0, 0.7]);
            ylim(ax, [-2.0, 2.5]);
        end

        function addPanelDLegend(ax, model)
            % VIEW: Add the genotype legend in the lower right corner (TERMINAL)
            % The legend sits on an opaque white box with a thin black edge,
            % so points beneath it are hidden and the entries stay legible.
            colors = model.colorScheme;
            h1 = scatter(ax, NaN, NaN, 20, colors.wild_type, 'filled', 'MarkerEdgeColor', 'k');
            h2 = scatter(ax, NaN, NaN, 20, colors.dbf4_1, 'filled', 'MarkerEdgeColor', 'k');
            h3 = scatter(ax, NaN, NaN, 20, colors.cdc13_2, 'filled', 'MarkerEdgeColor', 'k');
            h4 = scatter(ax, NaN, NaN, 20, colors.double, 'filled', 'MarkerEdgeColor', 'k');
            legend(ax, [h1, h2, h3, h4], ...
                   {'Wild type', 'dbf4-1', 'cdc13-2', 'double'}, ...
                   'Location', 'southeast', 'Box', 'on', ...
                   'Color', [1, 1, 1], 'EdgeColor', [0, 0, 0], ...
                   'LineWidth', 0.5, ...
                   'FontSize', model.fonts.legend);
        end
    end

    function reportClassifierSummary(model)
        % SUB-CONTROLLER: Report the classifier counts to the command window

        % Print the summary table
        printClassifierSummary(model.panelD);

        function printClassifierSummary(d)
            % VIEW: Print classifier accuracy, baselines, and per-genotype counts (TERMINAL)
            fprintf('\n=== dbf4-1 classifier (dbf4-1 single mutant or not) ===\n');
            fprintf('All four genotypes: %d of %d correct, accuracy %.1f%%\n', ...
                    d.n_correct, d.n_plates, 100 * d.accuracy);
            fprintf('  dbf4-1 plates: %d of %d; baseline (more common class) %.1f%%\n', ...
                    d.n_dbf, d.n_plates, 100 * d.baseline_accuracy);
            fprintf('Wild type and dbf4-1 only: %d of %d correct, accuracy %.1f%%; baseline %.1f%%\n', ...
                    d.wtdbf_correct, d.wtdbf_n, 100 * d.wtdbf_accuracy, ...
                    100 * d.wtdbf_baseline);
            fprintf('Per genotype (correct means dbf4-1 for dbf4-1, not dbf4-1 otherwise):\n');
            for g = 1:numel(d.per_genotype)
                fprintf('  %-10s %3d of %3d correct\n', d.per_genotype(g).genotype, ...
                        d.per_genotype(g).n_correct, d.per_genotype(g).n_plates);
            end
            fprintf('\n');
        end
    end
end
function drawRescueBoxplot(part3)
    % CONTROLLER (base): two-panel P4 rescue plot, one glyph per surviving
    % plate. Filter is passage 4, 6-day incubation, genotype cdc13-2 or double,
    % with pooled replicate entries dropped. Plates are
    % ordered genotype outermost (config order), enrichment inside each genotype
    % (Small, Standard, Large), and plates inside a group by colony count
    % ascending. The figure is split into two panels that share one y axis so
    % they read as a single plot: the left panel holds the selection enrichments
    % (Small and Large for both genotypes), the right panel holds the Standard
    % enrichment for both genotypes. Panel widths are proportional to column
    % count with a fixed gap, the y axis is log scaled with round tick values
    % placed inside the data extent, and the y label and tick labels appear only
    % on the left panel. Within each panel, plates in a group sit at adjacent
    % columns, one NaN spacer separates enrichment groups within a genotype, two
    % separate genotypes. A plate with config.violin_min_colonies or more
    % measured radii is drawn as a violin: a genotype-colored density outline
    % estimated in log radius and trimmed to the plate's data range, with the
    % compact box's median marker kept on top and its IQR bar thinned and
    % darkened. Plates below the cutoff keep the compact box plot. The x axis
    % labels each group by its enrichment name (collapsing to a single axis
    % label when every group in a panel shares one name) and a colored genotype
    % header bookends that genotype's groups. Every plate carries its own colony
    % count above its column, and a "Colony count" row label sits at the far
    % left of the count band. A 140 mm plate carries a single black star above
    % its glyph top. The legend lists the plate flags and the violin cutoff. All
    % per-column decorations are drawn in axes data coordinates so they stay
    % aligned with the glyphs. On-screen figure.

    config = getAnalysisConfig();
    model = buildRescueModel(part3, config);
    drawRescueView(model, config);

    % ============================================================
    % MODEL BRANCH
    % ============================================================

    function model = buildRescueModel(part3, config)
        % SUB-CONTROLLER (model): filter and order the survivors, split them into
        % the left (selection) and right (standard) panels, build a radius matrix
        % and maps per panel, compute the shared y log extent, derive the y ticks
        % and the decoration y levels from that extent, resolve the flag marks
        % and violin shapes per panel, and build the combined mark list, the
        % legend shape note, and the panel positions.
        survivors = filterRescueEntries(part3);
        groups = orderRescuePlates(survivors, config);
        [leftGroups, rightGroups] = splitGroupsByPanel(groups);

        leftPanel = buildRescuePanel(leftGroups);
        rightPanel = buildRescuePanel(rightGroups);

        yLogExtent = computeRescueYLogExtent({leftPanel.matrix, rightPanel.matrix});
        yTicks = deriveRescueYTicks(yLogExtent);
        decorLevels = computeRescueDecorLevels(yLogExtent);
        layout = computeRescuePanelPositions(leftPanel.matrix, rightPanel.matrix);

        leftPanel.marks = detectRescueFlags(leftPanel.flagInputs, yLogExtent);
        rightPanel.marks = detectRescueFlags(rightPanel.flagInputs, yLogExtent);

        leftPanel.violins = computeRescueViolinShapes(leftPanel.matrix, ...
            leftPanel.positionMap, config);
        rightPanel.violins = computeRescueViolinShapes(rightPanel.matrix, ...
            rightPanel.positionMap, config);

        shapeNote = buildRescueShapeNote([leftPanel.violins, rightPanel.violins], config);

        model.leftPanel = leftPanel;
        model.rightPanel = rightPanel;
        model.yLogExtent = yLogExtent;
        model.yTicks = yTicks;
        model.decorLevels = decorLevels;
        model.layout = layout;
        model.allMarks = [leftPanel.marks, rightPanel.marks];
        model.shapeNote = shapeNote;

        function survivors = filterRescueEntries(part3)
            % MODEL: unwrap the Part3CompleteData dataset struct to its flat
            % composite array (an already-flat array is accepted unchanged), then
            % keep P4 6-day cdc13-2/double per-plate entries. Pooled replicate
            % entries (replicate label carrying '+') are dropped so each glyph is
            % one real plate. Entries with an Excluded enrichment label are kept.
            % (TERMINAL)
            if isfield(part3, 'composite')
                entries = part3.composite;
            else
                entries = part3;
            end
            mask = [entries.passage] == 4 & ...
                [entries.incubation_days] == 6 & ...
                (strcmp({entries.genotype}, 'cdc13-2') | ...
                strcmp({entries.genotype}, 'double')) & ...
                ~contains({entries.replicate}, '+');
            survivors = entries(mask);
        end

        function groups = orderRescuePlates(survivors, config)
            % MODEL: build the left-to-right group order. Genotype outer loop
            % follows config.genotype_order (present genotypes only). Within a
            % genotype the enrichment order is SmallSourced, Standard,
            % LargeSourced, with any other source type appended after. Plates
            % inside a group sort by colony count ascending so the smallest-count
            % plate is leftmost. Each group records its genotype, source_type,
            % display name, and ordered entry array. (TERMINAL)
            groups = struct('genotype', {}, 'source_type', {}, ...
                'displayName', {}, 'entries', {});
            if isempty(survivors)
                return;
            end

            enrichOrder = {'SmallSourced', 'Standard', 'LargeSourced'};
            enrichNames = {'Small Enrichment', 'Standard Enrichment', 'Large Enrichment'};

            for gi = 1:length(config.genotype_order)
                gt = config.genotype_order{gi};
                inGeno = survivors(strcmp({survivors.genotype}, gt));
                if isempty(inGeno)
                    continue;
                end

                presentSrc = unique({inGeno.source_type}, 'stable');
                orderedSrc = {};
                srcNames = {};
                for si = 1:length(enrichOrder)
                    if any(strcmp(presentSrc, enrichOrder{si}))
                        orderedSrc{end+1} = enrichOrder{si}; %#ok<AGROW>
                        srcNames{end+1} = enrichNames{si};   %#ok<AGROW>
                    end
                end
                for si = 1:length(presentSrc)
                    if ~any(strcmp(enrichOrder, presentSrc{si}))
                        orderedSrc{end+1} = presentSrc{si};  %#ok<AGROW>
                        srcNames{end+1} = presentSrc{si};    %#ok<AGROW>
                    end
                end

                for si = 1:length(orderedSrc)
                    src = orderedSrc{si};
                    sel = inGeno(strcmp({inGeno.source_type}, src));
                    if isempty(sel)
                        continue;
                    end
                    counts = zeros(1, numel(sel));
                    for k = 1:numel(sel)
                        e = sel(k);
                        if isfield(e, 'colony_count') && isnumeric(e.colony_count) && ...
                                ~isempty(e.colony_count)
                            counts(k) = double(e.colony_count);
                        else
                            r = e.Measurements.Radius;
                            counts(k) = sum(isfinite(r) & r > 0);
                        end
                    end
                    [~, ord] = sort(counts, 'ascend');
                    sel = sel(ord);
                    groups(end+1) = struct('genotype', gt, 'source_type', src, ...
                        'displayName', srcNames{si}, 'entries', {sel}); %#ok<AGROW>
                end
            end
        end

        function [leftGroups, rightGroups] = splitGroupsByPanel(groups)
            % MODEL: route Standard groups to the right panel and every other
            % source type to the left panel, preserving the genotype-outer order
            % from orderRescuePlates within each panel. (TERMINAL)
            leftGroups = struct('genotype', {}, 'source_type', {}, ...
                'displayName', {}, 'entries', {});
            rightGroups = leftGroups;
            for gi = 1:numel(groups)
                if strcmp(groups(gi).source_type, 'Standard')
                    rightGroups(end+1) = groups(gi); %#ok<AGROW>
                else
                    leftGroups(end+1) = groups(gi); %#ok<AGROW>
                end
            end
        end

        function ext = computeRescueYLogExtent(matrices)
            % MODEL: y limits from the radii of every panel, padded in log space,
            % so both panels share one extent. Falls back to a fixed window when
            % no radii are present. matrices is a cell array of panel matrices.
            % (TERMINAL)
            yPadLog = 0.15;
            vals = [];
            for mi = 1:numel(matrices)
                m = matrices{mi};
                if isempty(m)
                    continue;
                end
                v = m(:);
                v = v(isfinite(v) & v > 0);
                vals = [vals; v]; %#ok<AGROW>
            end
            if isempty(vals)
                ext = [log(10), log(2000)];
                return;
            end
            logVals = log(vals);
            ext = [min(logVals) - yPadLog, max(logVals) + yPadLog];
        end

        function ticks = deriveRescueYTicks(yLogExtent)
            % MODEL: choose round radius tick values that fall inside the data
            % extent. A pool of round values is filtered to the extent; when fewer
            % than two survive, the rounded extent endpoints are used so the axis
            % always carries at least two ticks. The log scale renders these at
            % uneven screen spacing while the labels stay round. (TERMINAL)
            lo = exp(yLogExtent(1));
            hi = exp(yLogExtent(2));
            pool = [10 20 25 50 75 100 150 200 250 300 400 500 ...
                600 750 1000 1250 1500 2000 2500 3000 4000 5000];
            ticks = pool(pool >= lo & pool <= hi);
            if numel(ticks) < 2
                ticks = unique(round([lo, hi]));
            end
        end

        function levels = computeRescueDecorLevels(yLogExtent)
            % MODEL: y positions, in radius units, for the decorations that sit
            % above the plotted glyphs. The count band and the genotype header are
            % placed at fixed fractions of the y log span above the top of the
            % data so the same vertical offsets hold across every range.
            % countFrac is kept for placing the figure-level row label at the
            % matching height. (TERMINAL)
            countFrac = 0.06;
            headerFrac = 0.16;
            span = yLogExtent(2) - yLogExtent(1);
            levels.countY = exp(yLogExtent(2) + countFrac * span);
            levels.headerY = exp(yLogExtent(2) + headerFrac * span);
            levels.countFrac = countFrac;
            levels.headerFrac = headerFrac;
        end

        function layout = computeRescuePanelPositions(leftMatrix, rightMatrix)
            % MODEL: normalized figure rectangles for the two panels. Panel widths
            % are proportional to each panel's data-column count plus one, so the
            % per-column pitch matches across the seam, separated by a fixed gap.
            % An empty panel surrenders its width to the other; if both are empty
            % the left rectangle spans the full width for a placeholder. (TERMINAL)
            xLeft = 0.08;
            xRight = 0.94;
            yBottom = 0.18;
            height = 0.62;
            gap = 0.04;

            nL = size(leftMatrix, 2);
            nR = size(rightMatrix, 2);
            uL = nL + 1;
            uR = nR + 1;
            hasL = nL > 0;
            hasR = nR > 0;

            layout.yBottom = yBottom;
            layout.height = height;
            layout.gap = gap;

            if hasL && hasR
                usable = (xRight - xLeft) - gap;
                wL = usable * uL / (uL + uR);
                wR = usable * uR / (uL + uR);
                layout.leftPos = [xLeft, yBottom, wL, height];
                layout.rightPos = [xLeft + wL + gap, yBottom, wR, height];
                layout.hasLeft = true;
                layout.hasRight = true;
            elseif hasL
                layout.leftPos = [xLeft, yBottom, xRight - xLeft, height];
                layout.rightPos = [];
                layout.hasLeft = true;
                layout.hasRight = false;
            elseif hasR
                layout.leftPos = [];
                layout.rightPos = [xLeft, yBottom, xRight - xLeft, height];
                layout.hasLeft = false;
                layout.hasRight = true;
            else
                layout.leftPos = [xLeft, yBottom, xRight - xLeft, height];
                layout.rightPos = [];
                layout.hasLeft = true;
                layout.hasRight = false;
            end
        end

        function note = buildRescueShapeNote(violins, config)
            % MODEL: legend text stating the violin cutoff. Empty when no plate
            % in either panel reaches the cutoff, so the legend omits the line.
            % (TERMINAL)
            if isempty(violins)
                note = '';
                return;
            end
            n = config.violin_min_colonies;
            note = sprintf('Violin: plates with %d or more colonies. Box: fewer than %d.', n, n);
        end
    end

    % ============================================================
    % VIEW BRANCH
    % ============================================================

    function drawRescueView(model, config)
        % SUB-CONTROLLER (view): open the figure, render each present panel
        % against its rectangle (left panel carries the y label and tick labels;
        % right panel hides them), then draw the shared "Colony count" row label
        % and the shared legend.
        fig = createRescueFigure();

        if model.layout.hasLeft
            renderRescuePanel(fig, model.leftPanel, model.layout.leftPos, ...
                config, true, model.yLogExtent, model.yTicks, model.decorLevels);
        end
        if model.layout.hasRight
            renderRescuePanel(fig, model.rightPanel, model.layout.rightPos, ...
                config, ~model.layout.hasLeft, model.yLogExtent, model.yTicks, ...
                model.decorLevels);
        end

        drawColonyCountRowLabel(fig, model.layout, model.decorLevels);
        drawRescueLegend(fig, model.allMarks, model.shapeNote);

        function fig = createRescueFigure()
            % VIEW: open an on-screen figure window (TERMINAL)
            fig = figure('Name', 'P4 Rescue Plot', 'NumberTitle', 'off', ...
                'Color', 'w', 'Position', [100 100 1100 560]);
        end

        function drawColonyCountRowLabel(fig, layout, decorLevels)
            % VIEW: place a "Colony count" label at the far left, at the figure
            % height of the count band, so the per-plate numbers read as colony
            % counts. The height is derived from the panel geometry and the count
            % fraction since the band sits that fraction of the axis height above
            % the data top. (TERMINAL)
            figY = layout.yBottom + layout.height * (1 + decorLevels.countFrac);
            annotation(fig, 'textbox', [0.0, figY - 0.02, 0.072, 0.04], ...
                'String', 'Colony count', 'EdgeColor', 'none', ...
                'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle', ...
                'FontSize', 8, 'FontWeight', 'bold', 'Color', [0.35 0.35 0.35]);
        end

        function drawRescueLegend(fig, marks, shapeNote)
            % VIEW: lower-left legend below the axes. One stacked row per unique
            % flag label under a "Plate flags:" header, built from the combined
            % marks of both panels, with the violin cutoff note on the bottom row
            % when any violin is drawn. Draws nothing when both are absent.
            % (TERMINAL)
            seen = {};
            uniqMarks = struct('symbol', {}, 'label', {}, 'color', {});
            for i = 1:numel(marks)
                if ~any(strcmp(seen, marks(i).label))
                    seen{end+1} = marks(i).label; %#ok<AGROW>
                    uniqMarks(end+1) = struct('symbol', marks(i).symbol, ...
                        'label', marks(i).label, 'color', marks(i).color); %#ok<AGROW>
                end
            end

            hasNote = ~isempty(shapeNote);
            nU = numel(uniqMarks);
            if nU == 0 && ~hasNote
                return;
            end

            baseX = 0.04;
            baseY = 0.01;
            lineH = 0.025;
            width = 0.6;

            if hasNote
                annotation(fig, 'textbox', [baseX, baseY, width, lineH], ...
                    'String', shapeNote, 'EdgeColor', 'none', 'Interpreter', 'none', ...
                    'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
                    'FontSize', 9, 'FontWeight', 'normal', 'Color', [0 0 0]);
            end

            if nU == 0
                return;
            end

            flagBaseY = baseY + double(hasNote) * lineH;

            annotation(fig, 'textbox', ...
                [baseX, flagBaseY + nU * lineH, width, lineH], ...
                'String', 'Plate flags:', 'EdgeColor', 'none', ...
                'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
                'FontSize', 9, 'FontWeight', 'bold', 'Color', [0 0 0]);

            for i = 1:nU
                y = flagBaseY + (nU - i) * lineH;
                str = sprintf('%s  %s', uniqMarks(i).symbol, uniqMarks(i).label);
                annotation(fig, 'textbox', [baseX, y, width, lineH], ...
                    'String', str, 'EdgeColor', 'none', 'Interpreter', 'none', ...
                    'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
                    'FontSize', 9, 'FontWeight', 'normal', 'Color', uniqMarks(i).color);
            end
        end
    end

    % ============================================================
    % SHARED FUNCTIONS (called once per panel)
    % ============================================================

    function panel = buildRescuePanel(groups)
        % MODEL (shared): column-major NaN-padded radius matrix for one panel's
        % groups, laid out left to right in group order. Plates inside a group
        % occupy adjacent columns. One NaN spacer column separates enrichment
        % groups within a genotype, two separate genotypes. positionMap carries
        % (col, genotype) per data column for the recolor and violin passes.
        % flagInputs carries (col, plateDiameterMm, maxRadius) per data column
        % for the size-flag detector, with plate diameter resolved inline.
        % groupMap carries one record per group (genotype, source_type,
        % displayName, firstCol, lastCol, centerCol, minCount, maxCount,
        % nEntries, counts) for the group x labels, genotype headers, and count
        % annotations. An empty group list yields an empty matrix and empty
        % maps. (TERMINAL)
        nSpacerEnrichment = 1;
        nSpacerGenotype = 2;

        panel.matrix = [];
        panel.positionMap = struct('col', {}, 'genotype', {});
        panel.flagInputs = struct('col', {}, 'plateDiameterMm', {}, 'maxRadius', {});
        panel.groupMap = struct('genotype', {}, 'source_type', {}, 'displayName', {}, ...
            'firstCol', {}, 'lastCol', {}, 'centerCol', {}, ...
            'minCount', {}, 'maxCount', {}, 'nEntries', {}, 'counts', {});

        if isempty(groups)
            return;
        end

        maxN = 0;
        for gi = 1:numel(groups)
            entries = groups(gi).entries;
            for k = 1:numel(entries)
                r = entries(k).Measurements.Radius;
                r = r(isfinite(r) & r > 0);
                maxN = max(maxN, numel(r));
            end
        end
        if maxN == 0
            return;
        end

        nData = 0;
        for gi = 1:numel(groups)
            nData = nData + numel(groups(gi).entries);
        end
        nSpace = 0;
        for gi = 2:numel(groups)
            if strcmp(groups(gi).genotype, groups(gi-1).genotype)
                nSpace = nSpace + nSpacerEnrichment;
            else
                nSpace = nSpace + nSpacerGenotype;
            end
        end
        nCols = nData + nSpace;

        matrix = nan(maxN, nCols);
        positionMap = struct('col', {}, 'genotype', {});
        flagInputs = struct('col', {}, 'plateDiameterMm', {}, 'maxRadius', {});
        groupMap = struct('genotype', {}, 'source_type', {}, 'displayName', {}, ...
            'firstCol', {}, 'lastCol', {}, 'centerCol', {}, ...
            'minCount', {}, 'maxCount', {}, 'nEntries', {}, 'counts', {});

        col = 1;
        for gi = 1:numel(groups)
            if gi > 1
                if strcmp(groups(gi).genotype, groups(gi-1).genotype)
                    col = col + nSpacerEnrichment;
                else
                    col = col + nSpacerGenotype;
                end
            end

            entries = groups(gi).entries;
            gt = groups(gi).genotype;
            firstCol = col;
            groupCounts = zeros(1, numel(entries));
            for k = 1:numel(entries)
                e = entries(k);
                r = e.Measurements.Radius;
                r = r(isfinite(r) & r > 0);
                if ~isempty(r)
                    matrix(1:numel(r), col) = r;
                end

                positionMap(end+1) = struct('col', col, 'genotype', gt); %#ok<AGROW>

                if isfield(e, 'plate_diameter_mm') && ~isempty(e.plate_diameter_mm)
                    d = e.plate_diameter_mm;
                elseif isfield(e, 'plate_type') && isstruct(e.plate_type) && ...
                        isfield(e.plate_type, 'plate_radius_cm') && ...
                        ~isempty(e.plate_type.plate_radius_cm)
                    d = e.plate_type.plate_radius_cm * 20;
                else
                    d = NaN;
                end
                if isempty(r)
                    mr = NaN;
                else
                    mr = max(r);
                end
                flagInputs(end+1) = struct('col', col, ...
                    'plateDiameterMm', d, 'maxRadius', mr); %#ok<AGROW>

                if isfield(e, 'colony_count') && isnumeric(e.colony_count) && ...
                        ~isempty(e.colony_count)
                    groupCounts(k) = double(e.colony_count);
                else
                    groupCounts(k) = numel(r);
                end

                col = col + 1;
            end
            lastCol = col - 1;

            groupMap(end+1) = struct('genotype', gt, ...
                'source_type', groups(gi).source_type, ...
                'displayName', groups(gi).displayName, ...
                'firstCol', firstCol, 'lastCol', lastCol, ...
                'centerCol', (firstCol + lastCol) / 2, ...
                'minCount', min(groupCounts), 'maxCount', max(groupCounts), ...
                'nEntries', numel(entries), 'counts', groupCounts); %#ok<AGROW>
        end

        panel.matrix = matrix;
        panel.positionMap = positionMap;
        panel.flagInputs = flagInputs;
        panel.groupMap = groupMap;
    end

    function marks = detectRescueFlags(flagInputs, yLogExtent)
        % MODEL (shared): one star per 140 mm plate for one panel. The glyph
        % floats above the plate's largest radius by a fixed fraction of the y
        % log-span, so the float distance matches across panels and ranges. The
        % star spec and clearance fraction are local constants since the
        % analysis config carries no flag registry. Returns a struct array (x, y,
        % symbol, label, color), with x in the panel's column coordinate; empty
        % when nothing fires. (TERMINAL)
        starSymbol = char(9733);
        starColor = [0 0 0];
        starLabel = '140 mm plate';
        clearanceFrac = 0.025;

        marks = struct('x', {}, 'y', {}, 'symbol', {}, ...
            'label', {}, 'color', {});
        if isempty(flagInputs)
            return;
        end

        span = yLogExtent(2) - yLogExtent(1);
        clearance = clearanceFrac * span;

        for bi = 1:numel(flagInputs)
            fin = flagInputs(bi);
            if ~isfinite(fin.maxRadius) || fin.maxRadius <= 0
                continue;
            end
            if isfinite(fin.plateDiameterMm) && abs(fin.plateDiameterMm - 140) < 0.5
                yLog = log(fin.maxRadius) + clearance;
                marks(end+1) = struct('x', fin.col, 'y', exp(yLog), ...
                    'symbol', starSymbol, 'label', starLabel, ...
                    'color', starColor); %#ok<AGROW>
            end
        end
    end

    function violins = computeRescueViolinShapes(matrix, positionMap, config)
        % MODEL (shared): violin outlines for one panel's plates that reach the
        % colony cutoff. The cutoff tests the count of finite, positive radii in
        % the plate's matrix column, since those radii feed the density. The
        % kernel density is estimated on log radius over a grid spanning the
        % plate's own min to max, so each violin is trimmed to its data range and
        % keeps its shape on the log axis. Half-width is scaled so every violin's
        % widest point is halfWidthMax columns. A plate with zero radius spread
        % keeps its box. Returns a struct array (col, x, y, color, barColor),
        % with x in the panel's column coordinate and y in radius units; barColor
        % is the darkened genotype color used for the thinned IQR bar. (TERMINAL)
        halfWidthMax = 0.4;
        nGrid = 120;

        violins = struct('col', {}, 'x', {}, 'y', {}, 'color', {}, 'barColor', {});
        if isempty(matrix) || isempty(positionMap)
            return;
        end

        for i = 1:numel(positionMap)
            pe = positionMap(i);
            r = matrix(:, pe.col);
            r = r(isfinite(r) & r > 0);
            if numel(r) < config.violin_min_colonies
                continue;
            end

            logR = log(r);
            lo = min(logR);
            hi = max(logR);
            if hi - lo <= 0
                continue;
            end

            grid = linspace(lo, hi, nGrid);
            f = ksdensity(logR, grid);
            f = f(:)';
            if ~any(f > 0)
                continue;
            end
            hw = halfWidthMax * f / max(f);

            color = config.colors(pe.genotype);
            violins(end+1) = struct('col', pe.col, ...
                'x', [pe.col - hw, fliplr(pe.col + hw)], ...
                'y', exp([grid, fliplr(grid)]), ...
                'color', color, ...
                'barColor', max(color * 0.4, 0)); %#ok<AGROW>
        end
    end

    function renderRescuePanel(fig, panel, axesPos, config, showY, yLogExtent, yTicks, decorLevels)
        % SUB-CONTROLLER (view, shared): create the panel axes, draw the compact
        % box plot, recolor by genotype, convert the qualifying columns to
        % violins, configure the shared log-y axes and the per-group x labels (y
        % label and tick labels only when showY is true), then overlay the
        % genotype headers, the per-plate count annotations, and the flag marks.
        % All overlays are drawn in axes data coordinates so they track the
        % glyphs exactly.
        ax = createRescueAxes(fig, axesPos);
        drawRescueBoxes(ax, panel.matrix);
        recolorRescueBoxes(ax, panel.positionMap, config);
        drawRescueViolins(ax, panel.violins);
        configureRescueAxes(ax, panel.matrix, panel.groupMap, yLogExtent, yTicks, showY);
        drawRescueGenotypeHeaders(ax, panel.groupMap, config, decorLevels);
        drawRescueCountAnnotations(ax, panel.groupMap, decorLevels);
        drawRescueFlagMarks(ax, panel.marks);

        function ax = createRescueAxes(fig, axesPos)
            % VIEW: single panel axes at the supplied normalized position (TERMINAL)
            ax = axes('Parent', fig, 'Position', axesPos);
        end

        function drawRescueBoxes(ax, matrix)
            % VIEW: compact-style box plot on the radius matrix; placeholder text
            % when there is nothing to draw. Every plate gets a box here; the
            % violin pass then strips the box elements a violin replaces.
            % (TERMINAL)
            if isempty(matrix)
                text(ax, 0.5, 0.5, 'No data', 'Units', 'normalized', ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', 12, 'Color', [0.5 0.5 0.5]);
                set(ax, 'XTick', [], 'YTick', [], 'Box', 'on');
                return;
            end
            boxplot(ax, matrix, 'PlotStyle', 'compact');
        end

        function recolorRescueBoxes(ax, positionMap, config)
            % VIEW: recolor box, whisker, median, and outlier elements by genotype
            % using rounded column position. Spacer columns carry no mapping and
            % are skipped. This depends on the internal line tags boxplot sets, so
            % it is the faithful way to match the existing box pages. (TERMINAL)
            if isempty(positionMap)
                return;
            end
            colToColor = containers.Map('KeyType', 'int32', 'ValueType', 'any');
            for i = 1:numel(positionMap)
                pe = positionMap(i);
                colToColor(int32(pe.col)) = config.colors(pe.genotype);
            end

            lineObjects = findobj(ax, 'Type', 'line');
            for i = 1:numel(lineObjects)
                try
                    xData = get(lineObjects(i), 'XData');
                    if isempty(xData), continue; end
                    col = round(xData(1));
                    if ~isKey(colToColor, int32(col)), continue; end
                    colColor = colToColor(int32(col));
                    tag = get(lineObjects(i), 'Tag');
                    darkEdge = max(colColor * 0.4, 0);
                    if strcmp(tag, 'Outliers')
                        set(lineObjects(i), 'Color', colColor, ...
                            'MarkerFaceColor', colColor, ...
                            'MarkerEdgeColor', darkEdge);
                    elseif strcmp(tag, 'MedianInner') || strcmp(tag, 'MedianOuter')
                        set(lineObjects(i), 'Color', colColor, ...
                            'MarkerFaceColor', 'white', ...
                            'MarkerEdgeColor', darkEdge, 'LineWidth', 1.5);
                    elseif strcmp(tag, 'Box') || strcmp(tag, 'Whisker')
                        set(lineObjects(i), 'Color', colColor);
                    else
                        set(lineObjects(i), 'Color', colColor);
                    end
                catch
                    continue;
                end
            end

            patchObjects = findobj(ax, 'Type', 'patch');
            for j = 1:numel(patchObjects)
                try
                    vertices = get(patchObjects(j), 'Vertices');
                    if isempty(vertices), continue; end
                    col = round(mean(vertices(:, 1)));
                    if ~isKey(colToColor, int32(col)), continue; end
                    colColor = colToColor(int32(col));
                    set(patchObjects(j), 'FaceColor', colColor, 'FaceAlpha', 0.7);
                catch
                    continue;
                end
            end
        end

        function drawRescueViolins(ax, violins)
            % VIEW: convert each violin column from box to violin. The whisker
            % and outlier lines boxplot drew in that column are deleted, since
            % the trimmed violin spans the same min to max. The box line is
            % thinned and darkened into an IQR bar, and the recolored median
            % markers are left as drawn. The violin patch is then drawn in the
            % genotype color at the box face alpha and sent to the bottom of the
            % stack so the IQR bar and median sit on top. (TERMINAL)
            if isempty(violins)
                return;
            end
            violinCols = [violins.col];

            lineObjects = findobj(ax, 'Type', 'line');
            for i = 1:numel(lineObjects)
                try
                    xData = get(lineObjects(i), 'XData');
                    if isempty(xData), continue; end
                    vi = find(violinCols == round(xData(1)), 1);
                    if isempty(vi), continue; end
                    tag = get(lineObjects(i), 'Tag');
                    if strcmp(tag, 'Whisker') || strcmp(tag, 'Outliers')
                        delete(lineObjects(i));
                    elseif strcmp(tag, 'Box')
                        set(lineObjects(i), 'Color', violins(vi).barColor, ...
                            'LineWidth', 1.5);
                    end
                catch
                    continue;
                end
            end

            hold(ax, 'on');
            hPatch = gobjects(1, numel(violins));
            for v = 1:numel(violins)
                hPatch(v) = patch(ax, 'XData', violins(v).x, 'YData', violins(v).y, ...
                    'FaceColor', violins(v).color, 'FaceAlpha', 0.7, ...
                    'EdgeColor', violins(v).color, 'LineWidth', 0.75);
            end
            uistack(hPatch, 'bottom');
            hold(ax, 'off');
        end

        function configureRescueAxes(ax, matrix, groupMap, yLogExtent, yTicks, showY)
            % VIEW: log-y scale shared across panels, y limits from the shared
            % padded radius extent, and round y tick values labeled as integers.
            % The log scale keeps the distribution shape while the ticks land at
            % round radii. One x-tick per group sits at the group center labeled
            % with the enrichment name, except when every group in the panel
            % shares one enrichment name, in which case the per-group ticks are
            % dropped and that name becomes the single x-axis label. The y label
            % and y tick labels appear only when showY is true; the y grid stays
            % on in both panels so the gridlines line up across the seam.
            % (TERMINAL)
            if isempty(matrix)
                return;
            end
            set(ax, 'YScale', 'log');
            ylim(ax, exp(yLogExtent));
            set(ax, 'YTick', yTicks, ...
                'YTickLabel', arrayfun(@(v) sprintf('%d', round(v)), yTicks, ...
                'UniformOutput', false));
            if showY
                ylabel(ax, 'Colony Radius (\mum)', 'Interpreter', 'tex', 'FontSize', 11);
            else
                set(ax, 'YTickLabel', []);
            end

            if ~isempty(groupMap)
                centers = [groupMap.centerCol];
                names = {groupMap.displayName};
                uniqueNames = unique(names, 'stable');
                if numel(uniqueNames) == 1
                    set(ax, 'XTick', []);
                    xlabel(ax, uniqueNames{1}, 'FontSize', 11);
                else
                    set(ax, 'XTick', centers, 'XTickLabel', names);
                end
            end
            xlim(ax, [0, size(matrix, 2) + 1]);

            set(ax, 'FontSize', 9);
            box(ax, 'on');
            set(ax, 'XGrid', 'off', 'YGrid', 'on');
        end

        function drawRescueGenotypeHeaders(ax, groupMap, config, decorLevels)
            % VIEW: colored genotype label centered over the full run of that
            % genotype's groups, drawn in axes data coordinates at the header y
            % level with clipping off so it sits above the glyphs (TERMINAL)
            if isempty(groupMap)
                return;
            end
            hold(ax, 'on');
            genos = {groupMap.genotype};
            uniqueG = unique(genos, 'stable');
            for gi = 1:numel(uniqueG)
                gt = uniqueG{gi};
                mask = strcmp(genos, gt);
                firstCols = [groupMap(mask).firstCol];
                lastCols = [groupMap(mask).lastCol];
                centerCol = (min(firstCols) + max(lastCols)) / 2;
                label = config.genotype_labels(gt);
                color = config.colors(gt);
                text(ax, centerCol, decorLevels.headerY, label, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', 12, 'FontWeight', 'bold', 'Color', color, ...
                    'Clipping', 'off');
            end
            hold(ax, 'off');
        end

        function drawRescueCountAnnotations(ax, groupMap, decorLevels)
            % VIEW: each plate's colony count centered over its own column at the
            % count band height, in axes data coordinates with clipping off. Every
            % plate shows its number so a reader can match each box or violin to
            % the count that decided its glyph. (TERMINAL)
            if isempty(groupMap)
                return;
            end
            textColor = [0.35 0.35 0.35];
            yBand = decorLevels.countY;

            hold(ax, 'on');
            for gi = 1:numel(groupMap)
                g = groupMap(gi);
                for k = 1:g.nEntries
                    ccol = g.firstCol + (k - 1);
                    text(ax, ccol, yBand, sprintf('%d', round(g.counts(k))), ...
                        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                        'FontSize', 8, 'Color', textColor, 'Clipping', 'off');
                end
            end
            hold(ax, 'off');
        end

        function drawRescueFlagMarks(ax, marks)
            % VIEW: drop each star glyph over its plate at the precomputed (x, y),
            % bottom-aligned so it sits above the glyph top (TERMINAL)
            if isempty(marks)
                return;
            end
            hold(ax, 'on');
            for i = 1:numel(marks)
                text(ax, marks(i).x, marks(i).y, marks(i).symbol, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                    'FontSize', 14, 'FontWeight', 'bold', 'Color', marks(i).color, ...
                    'Interpreter', 'none', 'Clipping', 'off');
            end
            hold(ax, 'off');
        end
    end

function config = getAnalysisConfig()
    % MODEL: Analysis-wide configuration constants (TERMINAL)
    config.genotype_order = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
    config.genotype_labels = containers.Map( ...
        {'wild_type', 'dbf4-1', 'cdc13-2', 'double'}, ...
        {'Wild Type', 'dbf4-1', 'cdc13-2', 'dbf4-1 cdc13-2'});
    config.colors = containers.Map( ...
        {'wild_type', 'dbf4-1', 'cdc13-2', 'double'}, ...
        {[0.20 0.40 0.85], [0.95 0.55 0.10], [0.20 0.65 0.30], [0.85 0.40 0.65]});
    config.jitter = containers.Map( ...
        {'wild_type', 'dbf4-1', 'cdc13-2', 'double'}, ...
        {-0.225, -0.075, 0.075, 0.225});
    config.passages = 1:5;
    config.violin_min_colonies = 50;
end
end
%General Purpose
function fidelityStats = analyzeMeasurementFidelity(dataInput, datasetName, displayName, axisSpec)
    % CONTROLLER: Compute pixel-space measurement fidelity for a colony dataset
    %             and render the two-panel fidelity figure
    %
    %   fidelityStats = analyzeMeasurementFidelity(composite, 'anbalagan')
    %   fidelityStats = analyzeMeasurementFidelity(composite, 'anbalagan', 'Anbalagan 2011')
    %   fidelityStats = analyzeMeasurementFidelity(composite, 'part3', 'Part 3 All Plates')
    %   fidelityStats = analyzeMeasurementFidelity(CountDataset.Dataset1, 'part3', 'Rescue Dataset')
    %
    %   Custom axes (same struct generateOverviewPDF accepts):
    %
    %   spec = struct('Nominal', 'genotype', 'Ordinal', 'dilution_factor', ...
    %                 'OrdinalLabel', 'Dilution Factor');
    %   fidelityStats = analyzeMeasurementFidelity(composite, 'part2', 'Dilution Series', spec)
    %
    %   Multi-row call: a cell array with one row per histogram and heatmap pair,
    %   {dataInput, datasetName, displayName, axisSpec}, stacked top to bottom with
    %   panel letters A, B, C, D, and so on. displayName and axisSpec are optional
    %   columns; an empty cell takes the default.
    %
    %   fidelityStats = analyzeMeasurementFidelity({ ...
    %       CountDataset.Dataset1, 'part3', 'Rescue Dataset',  []; ...
    %       composite,             'part2', 'Dilution Series', spec});
    %
    %   Parameters:
    %       dataInput   - One of two input shapes, identified by structure:
    %
    %                     Composite mode: a scalar struct holding a field named
    %                     datasetName (e.g. composite.anbalagan.composite). The
    %                     Colony Set fields select one of two schemas:
    %
    %                       Figure schema (Anbalagan): rows key on the compound
    %                       (figure, genotype_display) pair because the same genotype
    %                       appears in more than one figure block. Columns are
    %                       generations. Figure blocks are separated by dividers.
    %                       axisSpec is ignored.
    %
    %                       Axis schema (Part 3, Part 2): rows key on the axisSpec
    %                       nominal field, columns on the axisSpec ordinal field.
    %                       Under the default genotype nominal, rows follow the order
    %                       wild_type, dbf4-1, cdc13-2, double. Pooled entries
    %                       (replicate label joined with '+') are omitted; every
    %                       other plate is included. No blocks.
    %
    %                     Grid mode: a passage-indexed dataset grid from
    %                     CountDatasetGenerator. Every element holds one field per
    %                     genotype, and every field holds one composite entry or [].
    %                     Rows key on the genotype field, ordered wild_type, dbf4-1,
    %                     cdc13-2, double, then any other genotype in grid field
    %                     order. Columns are the grid index, which is the passage.
    %                     No blocks. Only NominalLabels in axisSpec applies, since
    %                     the grid encodes its axes in its shape.
    %
    %       datasetName - Composite mode: field name of the dataset to analyze.
    %                     Grid mode: a label stored in fidelityStats.dataset_name.
    %
    %       displayName - Optional. Name shown in the figure title and window,
    %                     used verbatim. When omitted or empty, the title-cased
    %                     datasetName is shown.
    %
    %       axisSpec    - Optional. Struct naming the Colony Set fields used as the
    %                     heatmap axes in the axis schema:
    %                       Nominal      - row field, char, string, or numeric scalar
    %                                      (default 'genotype'). Numeric values sort
    %                                      rows ascending.
    %                       Ordinal      - column field, numeric scalar (default 'passage')
    %                       OrdinalLabel - heatmap x label (default: the ordinal
    %                                      field with underscores as spaces and the
    %                                      first letter capitalized)
    %                       NominalLabel - heatmap y label, drawn only when supplied
    %                       NominalLabels - {key, label} pairs that replace row
    %                                      labels by nominal key, in every input
    %                                      shape, e.g. {'double', 'dbf4-1, cdc13-2'}
    %                     Either axis may be 'none', a null axis: every plate falls
    %                     in one unlabeled heatmap row (null Nominal) or column (null
    %                     Ordinal), for experiments that vary one factor, e.g. a
    %                     dilution series. Both axes null is an error.
    %                     Row labels read <Nominal>_display when every kept entry
    %                     carries one.
    %
    %   Returns:
    %       fidelityStats - Struct array, one element per panel row, holding pooled
    %                       fidelity statistics, per-cell ONA matrices, grid labels,
    %                       and handles to that row's axes. Every row shares one
    %                       histogram y-limit (percent of colonies) and one heatmap
    %                       color scale.
    %
    %   Fidelity is computed on every detected colony in Measurements.Radius_Pixels.
    %   The filter subsets are not applied: this figure reports what the imaging
    %   resolved, which is what justifies a downstream size threshold.
    %
    %   The histogram pools every colony. Each heatmap cell reports the mean of per-plate
    %   median uncertainties, so every plate in a cell carries equal weight; a cell
    %   holding one plate reports that plate's median.
    %
    %   Each heatmap cell also names its fidelity zone (High, Good, Moderate, Low,
    %   Sub-pixel). The zone is assigned from the cell value rounded to the one
    %   decimal place the cell prints, so the label always agrees with the printed
    %   percentage. fidelityStats.ona_zone_index holds the zone number per cell.

    if nargin < 2
        datasetName = '';
    end

    if nargin < 3
        displayName = '';
    end

    if nargin < 4
        axisSpec = struct();
    end

    % === COORDINATE SUB-CONTROLLERS ===

    % Compute fidelity statistics for every panel row
    fidelityStats = computeAllFidelityStatistics(dataInput, datasetName, displayName, axisSpec);

    % Render one histogram and heatmap pair per row
    figureHandles = renderFidelityFigure(fidelityStats);

    % Attach handles to each row of the returned struct array
    for k = 1:numel(fidelityStats)
        fidelityStats(k).figure_handle = figureHandles.figure;
        fidelityStats(k).hist_axes = figureHandles.rows(k).histAxes;
        fidelityStats(k).pixel_area_axes = figureHandles.rows(k).pixelAreaAxes;
        fidelityStats(k).heatmap_axes = figureHandles.rows(k).heatAxes;
    end

    % =========================================================
    % SUB-CONTROLLERS
    % =========================================================

    function allStats = computeAllFidelityStatistics(dataInput, datasetName, displayName, axisSpec)
        % SUB-CONTROLLER: Build the statistics for every panel row

        % One spec per row: a cell array gives several rows, any other input one
        rowSpecs = buildRowSpecs(dataInput, datasetName, displayName, axisSpec);

        % Statistics for each row, in call order
        rowStats = cell(numel(rowSpecs), 1);
        for k = 1:numel(rowSpecs)
            rowStats{k} = computeFidelityStatistics( ...
                rowSpecs(k).dataInput, rowSpecs(k).datasetName, ...
                rowSpecs(k).displayName, rowSpecs(k).axisSpec);
        end
        allStats = vertcat(rowStats{:});

        function rowSpecs = buildRowSpecs(dataInput, datasetName, displayName, axisSpec)
            % MODEL: Normalize either call form into one spec per panel row (TERMINAL)
            %
            % axisSpec is wrapped in a cell when stored so a struct value is held
            % as one field value per row and never expands the struct array.

            if iscell(dataInput)
                if isempty(dataInput) || size(dataInput, 2) < 2
                    error('analyzeMeasurementFidelity:BadRowSpec', ...
                        ['A multi-row call takes one row per panel pair: ' ...
                         '{input, datasetName, displayName, axisSpec; ...}. ' ...
                         'displayName and axisSpec are optional.']);
                end

                numPanelRows = size(dataInput, 1);
                rowSpecs = struct('dataInput', cell(numPanelRows, 1), ...
                    'datasetName', '', ...
                    'displayName', '', ...
                    'axisSpec', {struct()});

                for k = 1:numPanelRows
                    rowSpecs(k).dataInput = dataInput{k, 1};
                    rowSpecs(k).datasetName = dataInput{k, 2};

                    if size(dataInput, 2) >= 3
                        rowSpecs(k).displayName = dataInput{k, 3};
                    end

                    if size(dataInput, 2) >= 4 && ~isempty(dataInput{k, 4})
                        rowSpecs(k).axisSpec = dataInput{k, 4};
                    end

                    if isempty(rowSpecs(k).datasetName)
                        error('analyzeMeasurementFidelity:MissingDataset', ...
                            'Row %d of the call has no dataset name.', k);
                    end
                end
            else
                if isempty(datasetName)
                    error('analyzeMeasurementFidelity:MissingDataset', ...
                        ['A dataset name is required, e.g. analyzeMeasurementFidelity(composite, ''anbalagan'') ' ...
                         'or analyzeMeasurementFidelity(CountDataset.Dataset1, ''part3'').']);
                end

                rowSpecs = struct('dataInput', {dataInput}, ...
                    'datasetName', datasetName, ...
                    'displayName', displayName, ...
                    'axisSpec', {axisSpec});
            end
        end

        function stats = computeFidelityStatistics(dataInput, datasetName, displayName, axisSpec)
            % SUB-CONTROLLER: Build every statistic one panel row consumes

            % Zone edges, zone labels, and the sparse-data threshold
            config = buildFidelityConfig();

            % Axis field names and ordinal label, defaults filled
            resolvedAxes = resolveAxisSpec(axisSpec);

            % Flatten either input shape into one keyed list of Colony Sets
            colonyList = resolveColonyList(dataInput, datasetName, resolvedAxes);

            % Radii, relative uncertainty, and area for every Colony Set
            measures = measureColonySets(colonyList);

            % Determine the ONA grid shape, labels, and cell assignment
            gridLayout = buildGridLayout(colonyList);

            % Pooled fidelity across every colony in the dataset
            pooledStats = computePooledFidelity(measures, config);

            % Per-cell fidelity and zone assignment placed into the ONA grid
            gridStats = computeGridFidelity(measures, gridLayout, config);

            % Display name: the custom name verbatim, else the title-cased dataset key
            if isempty(displayName)
                displayNames = titleCaseStrings({datasetName});
            else
                displayNames = wrapCustomName(displayName);
            end

            % Merge into the output struct
            stats = assembleFidelityStruct(datasetName, displayNames, colonyList, ...
                pooledStats, gridStats, gridLayout);

            function displayNames = wrapCustomName(displayName)
                % MODEL: Custom display name as a one-element cell of char (TERMINAL)

                displayNames = {char(string(displayName))};
            end

            function config = buildFidelityConfig()
                % MODEL: Fidelity zone edges, zone labels, and sparse-data threshold (TERMINAL)
                %
                % zoneLabels holds one name per zone, in the order of zoneEdges.
                % The histogram bands and the heatmap cell labels both read these.

                config = struct();
                config.zoneEdges = [0, 5, 10, 25, 50, Inf];
                config.zoneLabels = {'High', 'Good', 'Moderate', 'Low', 'Sub-pixel'};
                config.sparseThreshold = 10;
            end

            function resolvedAxes = resolveAxisSpec(axisSpec)
                % MODEL: Fill axisSpec defaults (TERMINAL)
                %
                % Nominal defaults to genotype and Ordinal to passage, so a call
                % without axisSpec reproduces the Part 3 layout. OrdinalLabel
                % defaults to the ordinal field with underscores read as spaces
                % and the first letter capitalized. NominalLabel defaults to
                % blank, so existing calls keep an unlabeled y axis. 'none' on
                % either axis sets its null flag and blanks its label.

                if isstruct(axisSpec) && isscalar(axisSpec)
                    resolvedAxes = axisSpec;
                else
                    resolvedAxes = struct();
                end

                if ~isfield(resolvedAxes, 'Nominal') || isempty(resolvedAxes.Nominal)
                    resolvedAxes.Nominal = 'genotype';
                end
                if ~isfield(resolvedAxes, 'Ordinal') || isempty(resolvedAxes.Ordinal)
                    resolvedAxes.Ordinal = 'passage';
                end

                resolvedAxes.Nominal = char(resolvedAxes.Nominal);
                resolvedAxes.Ordinal = char(resolvedAxes.Ordinal);

                % 'none' names no field; every plate shares one row or column
                resolvedAxes.NominalIsNull = strcmpi(resolvedAxes.Nominal, 'none');
                resolvedAxes.OrdinalIsNull = strcmpi(resolvedAxes.Ordinal, 'none');

                if resolvedAxes.NominalIsNull && resolvedAxes.OrdinalIsNull
                    error('analyzeMeasurementFidelity:BothAxesNull', ...
                        'Nominal and Ordinal cannot both be ''none''; one axis must name a field.');
                end

                if resolvedAxes.OrdinalIsNull
                    resolvedAxes.OrdinalLabel = '';
                elseif ~isfield(resolvedAxes, 'OrdinalLabel') || isempty(resolvedAxes.OrdinalLabel)
                    defaultLabel = strrep(resolvedAxes.Ordinal, '_', ' ');
                    defaultLabel(1) = upper(defaultLabel(1));
                    resolvedAxes.OrdinalLabel = defaultLabel;
                end

                resolvedAxes.OrdinalLabel = char(resolvedAxes.OrdinalLabel);

                if resolvedAxes.NominalIsNull || ~isfield(resolvedAxes, 'NominalLabel') ...
                        || isempty(resolvedAxes.NominalLabel)
                    resolvedAxes.NominalLabel = '';
                end

                resolvedAxes.NominalLabel = char(resolvedAxes.NominalLabel);

                % Per-key relabels as an n-by-2 cell of {key, label}; a flat list
                % of pairs is reshaped
                if ~isfield(resolvedAxes, 'NominalLabels') || isempty(resolvedAxes.NominalLabels)
                    resolvedAxes.NominalLabels = cell(0, 2);
                end
                if ~iscell(resolvedAxes.NominalLabels) || ...
                        (size(resolvedAxes.NominalLabels, 2) ~= 2 && ...
                         mod(numel(resolvedAxes.NominalLabels), 2) ~= 0)
                    error('analyzeMeasurementFidelity:BadNominalLabels', ...
                        'NominalLabels must be a cell of {key, label} pairs, e.g. {''double'', ''dbf4-1, cdc13-2''}.');
                end
                if size(resolvedAxes.NominalLabels, 2) ~= 2
                    resolvedAxes.NominalLabels = reshape(resolvedAxes.NominalLabels, 2, [])';
                end
            end

            function colonyList = resolveColonyList(dataInput, datasetName, resolvedAxes)
                % SUB-CONTROLLER: Flatten the input into a Colony Set list keyed for the grid

                % Identify which input shape was passed
                inputMode = detectInputMode(dataInput, datasetName);

                if strcmp(inputMode, 'grid')
                    % One selected plate per genotype and passage
                    colonyList = flattenDatasetGrid(dataInput);
                else
                    % Every Colony Set stored under the dataset field
                    colonySets = extractCompositeSets(dataInput, datasetName);

                    % Figure schema (Anbalagan) or axis schema (Part 3, Part 2)
                    compositeSchema = detectCompositeSchema(colonySets, datasetName, resolvedAxes);

                    if strcmp(compositeSchema, 'figure')
                        colonyList = flattenFigureComposite(colonySets);
                    else
                        colonyList = flattenAxisComposite(colonySets, datasetName, resolvedAxes);
                    end
                end

                % Rows without display labels take them from the raw nominal strings
                if colonyList.needsRowLabels
                    genotypeLabels = titleCaseStrings(colonyList.rawNames);
                    colonyList = attachRowLabels(colonyList, genotypeLabels);
                end

                % Caller relabels by nominal key, applied last so they take precedence
                colonyList = applyLabelOverrides(colonyList, resolvedAxes.NominalLabels);

                function inputMode = detectInputMode(dataInput, datasetName)
                    % MODEL: Classify the input as a composite or a dataset grid (TERMINAL)

                    if ~isstruct(dataInput)
                        error('analyzeMeasurementFidelity:BadInput', ...
                            'Input must be a composite struct or a dataset grid struct array.');
                    end

                    if isscalar(dataInput) && isfield(dataInput, datasetName)
                        inputMode = 'composite';
                        return;
                    end

                    % Every field of every grid element holds [] or one composite
                    % entry carrying Measurements
                    gridFields = fieldnames(dataInput);
                    isGrid = ~isempty(gridFields);

                    for p = 1:numel(dataInput)
                        for f = 1:numel(gridFields)
                            value = dataInput(p).(gridFields{f});
                            if isempty(value)
                                continue;
                            end
                            if ~isstruct(value) || ~isscalar(value) || ~isfield(value, 'Measurements')
                                isGrid = false;
                            end
                        end
                    end

                    if isGrid
                        inputMode = 'grid';
                    else
                        error('analyzeMeasurementFidelity:UnknownInput', ...
                            ['Input is neither a composite holding dataset "%s" nor a dataset grid. ' ...
                             'Top-level fields: %s'], ...
                            datasetName, strjoin(gridFields', ', '));
                    end
                end

                function colonySets = extractCompositeSets(composite, datasetName)
                    % MODEL: Retrieve and validate the Colony Set struct array (TERMINAL)

                    entry = composite.(datasetName);

                    if isstruct(entry) && isfield(entry, 'composite')
                        colonySets = entry.composite;
                    else
                        colonySets = entry;
                    end

                    if isempty(colonySets)
                        error('analyzeMeasurementFidelity:EmptyDataset', ...
                            'Dataset "%s" contains no Colony Sets.', datasetName);
                    end

                    if ~isstruct(colonySets)
                        error('analyzeMeasurementFidelity:BadComposite', ...
                            'Dataset "%s" must hold a struct array of Colony Sets.', datasetName);
                    end

                    if ~isfield(colonySets, 'Measurements')
                        error('analyzeMeasurementFidelity:MissingField', ...
                            'Colony Sets in "%s" have no Measurements field. Present fields: %s', ...
                            datasetName, strjoin(fieldnames(colonySets)', ', '));
                    end
                end

                function compositeSchema = detectCompositeSchema(colonySets, datasetName, resolvedAxes)
                    % MODEL: Identify the field schema of the Colony Sets (TERMINAL)
                    %
                    % The figure schema is tested first and ignores axisSpec. The
                    % axis schema requires the field of each non-null axis.

                    figureFields = {'genotype_display', 'figure', 'generations'};
                    axisFields = {};
                    if ~resolvedAxes.NominalIsNull
                        axisFields{end+1} = resolvedAxes.Nominal;
                    end
                    if ~resolvedAxes.OrdinalIsNull
                        axisFields{end+1} = resolvedAxes.Ordinal;
                    end

                    if all(isfield(colonySets, figureFields))
                        compositeSchema = 'figure';
                    elseif all(isfield(colonySets, axisFields))
                        compositeSchema = 'axis';
                    else
                        error('analyzeMeasurementFidelity:MissingField', ...
                            ['Colony Sets in "%s" match neither schema. Expected {%s} or {%s}. ' ...
                             'Present fields: %s'], ...
                            datasetName, strjoin(figureFields, ', '), strjoin(axisFields, ', '), ...
                            strjoin(fieldnames(colonySets)', ', '));
                    end
                end

                function colonyList = flattenFigureComposite(colonySets)
                    % MODEL: Colony Sets keyed on (figure, genotype) and generations (TERMINAL)

                    numSets = numel(colonySets);
                    entries = cell(numSets, 1);
                    rowKey = cell(numSets, 1);
                    rowLabel = cell(numSets, 1);
                    rawNames = cell(numSets, 1);
                    colValue = zeros(numSets, 1);
                    blockValue = zeros(numSets, 1);

                    for i = 1:numSets
                        figNumber = double(colonySets(i).figure);
                        genoName = char(string(colonySets(i).genotype_display));

                        entries{i} = colonySets(i);
                        rowKey{i} = sprintf('%d|%s', figNumber, genoName);
                        rowLabel{i} = sprintf('%s (Fig %d)', genoName, figNumber);
                        rawNames{i} = genoName;
                        colValue(i) = double(colonySets(i).generations);
                        blockValue(i) = figNumber;
                    end

                    colonyList = struct( ...
                        'entries', {entries}, ...
                        'rowKey', {rowKey}, ...
                        'rowLabel', {rowLabel}, ...
                        'rawNames', {rawNames}, ...
                        'colValue', colValue, ...
                        'blockValue', blockValue, ...
                        'rowRank', zeros(numSets, 1), ...
                        'ordinalLabel', 'Generations', ...
                        'nominalLabel', '', ...
                        'ordinalIsNull', false, ...
                        'inputMode', 'composite-figure', ...
                        'needsRowLabels', false);
                end

                function colonyList = flattenAxisComposite(colonySets, datasetName, resolvedAxes)
                    % MODEL: Single-replicate plates keyed on the axisSpec nominal
                    % and ordinal fields (TERMINAL)
                    %
                    % Pooled entries (replicate labels joined with '+', e.g. A+B) repeat
                    % the colonies of their source plates, so they are omitted. Entries
                    % whose ordinal value is not a finite numeric scalar are omitted.
                    %
                    % Ordinal values are snapped to 10 significant digits, so float
                    % representation cannot split one logical column. A relative snap
                    % holds for integer factors (10, 100) and fractional factors
                    % (1e-5) alike.
                    %
                    % Under the genotype nominal, rows follow the Part 3 genotype
                    % order, with any other genotype after it in first-appearance
                    % order. Any other nominal field keeps first-appearance order.
                    %
                    % Row labels use <Nominal>_display verbatim when every kept entry
                    % has a non-empty value. Otherwise every label falls back to the
                    % title-cased nominal value, so one heatmap never mixes the two
                    % label formats.
                    %
                    % A null nominal keys every entry to one constant row with a
                    % blank label, which the figure title already names. A null
                    % ordinal places every entry in one column with a blank label.
                    %
                    % A numeric nominal is snapped like the ordinal, keyed by its
                    % printed value, and ranked by its value, so rows sort ascending.
                    %
                    % Every variable here is named so no enclosing function shares it.
                    % A per-entry name called displayName would bind to the displayName
                    % argument of computeFidelityStatistics and overwrite the figure title.

                    nominalIsNull = resolvedAxes.NominalIsNull;
                    ordinalIsNull = resolvedAxes.OrdinalIsNull;
                    nominalField = resolvedAxes.Nominal;
                    ordinalField = resolvedAxes.Ordinal;
                    nominalDisplayField = [nominalField '_display'];

                    useFixedOrder = ~nominalIsNull && strcmp(nominalField, 'genotype');
                    if useFixedOrder
                        nominalOrder = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
                    else
                        nominalOrder = {};
                    end

                    hasReplicate = isfield(colonySets, 'replicate');
                    hasDisplay = ~nominalIsNull && isfield(colonySets, nominalDisplayField);

                    entries = {};
                    rowKey = {};
                    rawNames = {};
                    entryDisplayNames = {};
                    colValue = zeros(0, 1);
                    rowRank = zeros(0, 1);

                    for i = 1:numel(colonySets)
                        entry = colonySets(i);

                        if hasReplicate && ~isempty(entry.replicate) ...
                                && contains(char(string(entry.replicate)), '+')
                            continue;
                        end

                        if ordinalIsNull
                            ordinalValue = 1;
                        else
                            ordinalValue = entry.(ordinalField);
                            if ~isnumeric(ordinalValue) || ~isscalar(ordinalValue) || ~isfinite(ordinalValue)
                                continue;
                            end
                            ordinalValue = round(double(ordinalValue), 10, 'significant');
                        end

                        if nominalIsNull
                            nominalName = 'all';
                            nominalRank = 1;
                        else
                            nominalValue = entry.(nominalField);
                            if isnumeric(nominalValue)
                                if ~isscalar(nominalValue) || ~isfinite(nominalValue)
                                    continue;
                                end
                                nominalValue = round(double(nominalValue), 10, 'significant');
                                nominalName = sprintf('%.10g', nominalValue);
                                nominalRank = nominalValue;
                            else
                                nominalName = char(string(nominalValue));
                                nominalRank = find(strcmp(nominalName, nominalOrder), 1);
                                if isempty(nominalRank)
                                    nominalRank = numel(nominalOrder) + 1;
                                end
                            end
                        end

                        if hasDisplay && ~isempty(entry.(nominalDisplayField))
                            entryDisplayName = char(string(entry.(nominalDisplayField)));
                        else
                            entryDisplayName = '';
                        end

                        entries{end+1, 1} = entry; %#ok<AGROW>
                        rowKey{end+1, 1} = nominalName; %#ok<AGROW>
                        rawNames{end+1, 1} = nominalName; %#ok<AGROW>
                        entryDisplayNames{end+1, 1} = entryDisplayName; %#ok<AGROW>
                        colValue(end+1, 1) = ordinalValue; %#ok<AGROW>
                        rowRank(end+1, 1) = nominalRank; %#ok<AGROW>
                    end

                    if isempty(entries)
                        error('analyzeMeasurementFidelity:EmptyDataset', ...
                            'Dataset "%s" has no single-replicate plates with a numeric %s.', ...
                            datasetName, ordinalField);
                    end

                    numSets = numel(entries);

                    % A null nominal takes a blank label; otherwise display labels
                    % apply only when every kept entry carries one
                    if nominalIsNull
                        rowLabel = repmat({''}, numSets, 1);
                        labelsSupplied = true;
                    elseif ~any(cellfun(@isempty, entryDisplayNames))
                        rowLabel = entryDisplayNames;
                        labelsSupplied = true;
                    else
                        rowLabel = cell(numSets, 1);
                        labelsSupplied = false;
                    end

                    colonyList = struct( ...
                        'entries', {entries}, ...
                        'rowKey', {rowKey}, ...
                        'rowLabel', {rowLabel}, ...
                        'rawNames', {rawNames}, ...
                        'colValue', colValue, ...
                        'blockValue', zeros(numSets, 1), ...
                        'rowRank', rowRank, ...
                        'ordinalLabel', resolvedAxes.OrdinalLabel, ...
                        'nominalLabel', resolvedAxes.NominalLabel, ...
                        'ordinalIsNull', ordinalIsNull, ...
                        'inputMode', 'composite-axis', ...
                        'needsRowLabels', ~labelsSupplied);
                end

                function colonyList = flattenDatasetGrid(grid)
                    % MODEL: Grid entries keyed on genotype field and grid index (TERMINAL)
                    %
                    % Fields form the outer loop, so rows start in grid field order
                    % even when a genotype has no plate at passage 1. Rows then rank
                    % by the Part 3 genotype order (wild_type, dbf4-1, cdc13-2,
                    % double), the order the axis schema uses, so the double mutant
                    % sits last whatever the grid's field order; any genotype
                    % outside that list follows in field order. The grid index is
                    % the passage by construction in CountDatasetGenerator.

                    genotypeOrder = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
                    gridFields = fieldnames(grid);
                    entries = {};
                    rowKey = {};
                    rawNames = {};
                    colValue = zeros(0, 1);
                    rowRank = zeros(0, 1);

                    for f = 1:numel(gridFields)
                        for p = 1:numel(grid)
                            value = grid(p).(gridFields{f});
                            if isempty(value)
                                continue;
                            end

                            entries{end+1, 1} = value; %#ok<AGROW>
                            rowKey{end+1, 1} = gridFields{f}; %#ok<AGROW>

                            if isfield(value, 'genotype') && ~isempty(value.genotype)
                                rawNames{end+1, 1} = char(string(value.genotype)); %#ok<AGROW>
                            else
                                rawNames{end+1, 1} = gridFields{f}; %#ok<AGROW>
                            end

                            colValue(end+1, 1) = p; %#ok<AGROW>

                            genotypeRank = find(strcmp(rawNames{end}, genotypeOrder), 1);
                            if isempty(genotypeRank)
                                genotypeRank = numel(genotypeOrder) + 1;
                            end
                            rowRank(end+1, 1) = genotypeRank; %#ok<AGROW>
                        end
                    end

                    if isempty(entries)
                        error('analyzeMeasurementFidelity:EmptyDataset', ...
                            'The dataset grid contains no plates.');
                    end

                    numSets = numel(entries);

                    colonyList = struct( ...
                        'entries', {entries}, ...
                        'rowKey', {rowKey}, ...
                        'rowLabel', {cell(numSets, 1)}, ...
                        'rawNames', {rawNames}, ...
                        'colValue', colValue, ...
                        'blockValue', zeros(numSets, 1), ...
                        'rowRank', rowRank, ...
                        'ordinalLabel', 'Passage', ...
                        'nominalLabel', '', ...
                        'ordinalIsNull', false, ...
                        'inputMode', 'grid', ...
                        'needsRowLabels', true);
                end

                function colonyList = attachRowLabels(colonyList, genotypeLabels)
                    % MODEL: Store the display label for every entry (TERMINAL)

                    colonyList.rowLabel = genotypeLabels(:);
                end

                function colonyList = applyLabelOverrides(colonyList, labelPairs)
                    % MODEL: Replace row labels for the nominal keys the caller names (TERMINAL)
                    %
                    % Each entry's raw nominal name is compared to the pair keys in
                    % normalized form (lowercase, alphanumerics only), so 'double'
                    % and 'Double' both hit. Figure-schema rows keep their
                    % "(Fig N)" suffix, since the same genotype recurs across
                    % figure blocks. A key absent from the data changes nothing.

                    if isempty(labelPairs)
                        return;
                    end

                    normalizeKey = @(s) regexprep(lower(char(s)), '[^a-z0-9]', '');
                    pairKeys = cell(size(labelPairs, 1), 1);
                    for p = 1:size(labelPairs, 1)
                        pairKeys{p} = normalizeKey(labelPairs{p, 1});
                    end

                    isFigureSchema = strcmp(colonyList.inputMode, 'composite-figure');

                    for i = 1:numel(colonyList.rawNames)
                        hit = find(strcmp(pairKeys, normalizeKey(colonyList.rawNames{i})), 1);
                        if isempty(hit)
                            continue;
                        end
                        newLabel = char(labelPairs{hit, 2});
                        if isFigureSchema
                            newLabel = sprintf('%s (Fig %d)', newLabel, colonyList.blockValue(i));
                        end
                        colonyList.rowLabel{i} = newLabel;
                    end
                end
            end

            function measures = measureColonySets(colonyList)
                % MODEL: Valid pixel radii, relative uncertainty, and area per Colony Set (TERMINAL)
                %
                % Uncertainty follows from +/-0.5 pixel edge localization, expressed as
                % a percentage of colony radius: 100 * 0.5 / r.

                numSets = numel(colonyList.entries);
                radii = cell(numSets, 1);
                uncertainty = cell(numSets, 1);
                areas = cell(numSets, 1);

                for i = 1:numSets
                    entry = colonyList.entries{i};
                    validRadii = zeros(0, 1);

                    if isfield(entry, 'Measurements') ...
                            && isstruct(entry.Measurements) ...
                            && isscalar(entry.Measurements) ...
                            && isfield(entry.Measurements, 'Radius_Pixels') ...
                            && ~isempty(entry.Measurements.Radius_Pixels)
                        rawRadii = double(entry.Measurements.Radius_Pixels(:));
                        validRadii = rawRadii(isfinite(rawRadii) & rawRadii > 0);
                    end

                    radii{i} = validRadii;
                    uncertainty{i} = (0.5 ./ validRadii) * 100;
                    areas{i} = pi * validRadii .^ 2;
                end

                measures = struct( ...
                    'radii', {radii}, ...
                    'uncertainty', {uncertainty}, ...
                    'areas', {areas});
            end

            function gridLayout = buildGridLayout(colonyList)
                % MODEL: Build the ONA grid from the keyed Colony Set list (TERMINAL)
                %
                % Rows sort by block value, then by nominal rank, then by first
                % appearance. Only the figure schema sets block values, so only it
                % produces block boundaries. The axis schema under the genotype
                % nominal and grid mode set Part 3 genotype ranks; the other inputs
                % keep first-appearance order.

                [uniqueKeys, firstIdx] = unique(colonyList.rowKey, 'stable');
                rowBlocks = colonyList.blockValue(firstIdx);
                rowRanks = colonyList.rowRank(firstIdx);

                [~, rowOrder] = sortrows([rowBlocks(:), rowRanks(:), firstIdx(:)]);
                uniqueKeys = uniqueKeys(rowOrder);
                firstIdx = firstIdx(rowOrder);
                rowBlocks = rowBlocks(rowOrder);

                numRows = numel(uniqueKeys);
                rowLabels = colonyList.rowLabel(firstIdx);
                rowLabels = rowLabels(:);

                % Ordinal axis sorted numerically
                colValues = unique(colonyList.colValue);
                colValues = colValues(:)';
                numCols = numel(colValues);
                colLabels = cell(1, numCols);
                if colonyList.ordinalIsNull
                    colLabels(:) = {''};
                else
                    for c = 1:numCols
                        colLabels{c} = sprintf('%g', colValues(c));
                    end
                end

                % Cell assignment for every Colony Set
                [~, rowIndex] = ismember(colonyList.rowKey, uniqueKeys);
                [~, colIndex] = ismember(colonyList.colValue, colValues);

                % Row indices after which a block divider belongs
                blockBoundaries = find(diff(rowBlocks(:)) ~= 0);
                blockBoundaries = blockBoundaries(:)';

                gridLayout = struct( ...
                    'rowIndex', rowIndex(:), ...
                    'colIndex', colIndex(:), ...
                    'numRows', numRows, ...
                    'numCols', numCols, ...
                    'rowLabels', {rowLabels}, ...
                    'colLabels', {colLabels}, ...
                    'colValues', colValues, ...
                    'rowBlocks', rowBlocks(:), ...
                    'blockBoundaries', blockBoundaries, ...
                    'xLabel', colonyList.ordinalLabel, ...
                    'yLabel', colonyList.nominalLabel);
            end

            function pooledStats = computePooledFidelity(measures, config)
                % MODEL: Pooled relative uncertainty and fidelity zone counts (TERMINAL)

                allRadii = vertcat(measures.radii{:});
                allUncertainty = vertcat(measures.uncertainty{:});
                allAreas = vertcat(measures.areas{:});

                zoneCounts = histcounts(allUncertainty, config.zoneEdges);
                total = sum(zoneCounts);

                if total > 0
                    zonePercentages = (zoneCounts / total) * 100;
                else
                    zonePercentages = zeros(size(zoneCounts));
                end

                if total < config.sparseThreshold
                    warning('analyzeMeasurementFidelity:SparseData', ...
                        'Only %d valid colony radii available. Fidelity statistics may be unreliable.', total);
                end

                pooledStats = struct( ...
                    'pixel_radii', allRadii, ...
                    'pixel_areas', allAreas, ...
                    'relative_uncertainty_pct', allUncertainty, ...
                    'zone_edges_pct', config.zoneEdges, ...
                    'zone_labels', {config.zoneLabels}, ...
                    'zone_counts', zoneCounts, ...
                    'zone_percentages', zonePercentages, ...
                    'total_colonies', total);
            end

            function gridStats = computeGridFidelity(measures, gridLayout, config)
                % MODEL: Per-cell mean of per-plate medians, counts, zone mix,
                % and zone assignment (TERMINAL)
                %
                % Each plate contributes its median uncertainty and median area; a cell
                % reports the mean of those medians. Plates with no valid radii do not
                % enter the mean or the plate count. Zone fractions pool the colonies of
                % every plate in the cell.
                %
                % The zone index classifies each cell's value rounded to one decimal,
                % the precision the heatmap prints, so a cell printed as 5.0% falls in
                % the 5-10% zone. discretize places a value on an edge in the upper
                % zone, as histcounts does for the pooled histogram. Empty cells hold NaN.

                numZones = numel(config.zoneEdges) - 1;
                numRows = gridLayout.numRows;
                numCols = gridLayout.numCols;

                plateUncertaintyBucket = cell(numRows, numCols);
                plateAreaBucket = cell(numRows, numCols);
                colonyUncertaintyBucket = cell(numRows, numCols);

                for i = 1:numel(measures.uncertainty)
                    plateUncertainty = measures.uncertainty{i};
                    if isempty(plateUncertainty)
                        continue;
                    end

                    r = gridLayout.rowIndex(i);
                    c = gridLayout.colIndex(i);

                    plateUncertaintyBucket{r, c} = [plateUncertaintyBucket{r, c}; median(plateUncertainty)];
                    plateAreaBucket{r, c} = [plateAreaBucket{r, c}; median(measures.areas{i})];
                    colonyUncertaintyBucket{r, c} = [colonyUncertaintyBucket{r, c}; plateUncertainty];
                end

                onaMatrix = NaN(numRows, numCols);
                onaAreaMatrix = NaN(numRows, numCols);
                onaCountMatrix = zeros(numRows, numCols);
                onaPlateCountMatrix = zeros(numRows, numCols);
                onaZoneFractions = NaN(numRows, numCols, numZones);

                for r = 1:numRows
                    for c = 1:numCols
                        plateMedians = plateUncertaintyBucket{r, c};
                        cellColonies = colonyUncertaintyBucket{r, c};

                        onaPlateCountMatrix(r, c) = numel(plateMedians);
                        onaCountMatrix(r, c) = numel(cellColonies);

                        if isempty(plateMedians)
                            continue;
                        end

                        onaMatrix(r, c) = mean(plateMedians);
                        onaAreaMatrix(r, c) = mean(plateAreaBucket{r, c});

                        zoneCounts = histcounts(cellColonies, config.zoneEdges);
                        onaZoneFractions(r, c, :) = zoneCounts / sum(zoneCounts);
                    end
                end

                onaZoneIndex = discretize(round(onaMatrix, 1), config.zoneEdges);

                gridStats = struct( ...
                    'ona_matrix', onaMatrix, ...
                    'ona_area_matrix', onaAreaMatrix, ...
                    'ona_count_matrix', onaCountMatrix, ...
                    'ona_plate_count_matrix', onaPlateCountMatrix, ...
                    'ona_zone_fractions', onaZoneFractions, ...
                    'ona_zone_index', onaZoneIndex);
            end

            function stats = assembleFidelityStruct(datasetName, displayNames, colonyList, ...
                    pooledStats, gridStats, gridLayout)
                % MODEL: Merge component statistics into the output struct (TERMINAL)

                stats = struct();

                stats.dataset_name = datasetName;
                stats.display_name = displayNames{1};
                stats.input_mode = colonyList.inputMode;
                stats.num_colony_sets = numel(colonyList.entries);

                stats.pixel_radii = pooledStats.pixel_radii;
                stats.pixel_areas = pooledStats.pixel_areas;
                stats.relative_uncertainty_pct = pooledStats.relative_uncertainty_pct;
                stats.zone_edges_pct = pooledStats.zone_edges_pct;
                stats.zone_labels = pooledStats.zone_labels;
                stats.zone_counts = pooledStats.zone_counts;
                stats.zone_percentages = pooledStats.zone_percentages;
                stats.total_colonies = pooledStats.total_colonies;

                stats.ona_matrix = gridStats.ona_matrix;
                stats.ona_area_matrix = gridStats.ona_area_matrix;
                stats.ona_count_matrix = gridStats.ona_count_matrix;
                stats.ona_plate_count_matrix = gridStats.ona_plate_count_matrix;
                stats.ona_zone_fractions = gridStats.ona_zone_fractions;
                stats.ona_zone_index = gridStats.ona_zone_index;

                stats.ona_row_labels = gridLayout.rowLabels;
                stats.ona_col_labels = gridLayout.colLabels;
                stats.ona_col_values = gridLayout.colValues;
                stats.ona_block_boundaries = gridLayout.blockBoundaries;
                stats.ona_x_label = gridLayout.xLabel;
                stats.ona_y_label = gridLayout.yLabel;
                stats.num_rows = gridLayout.numRows;
                stats.num_cols = gridLayout.numCols;
            end
        end
    end

    function handles = renderFidelityFigure(allStats)
        % SUB-CONTROLLER: Render one histogram and heatmap pair per panel row

        % Histogram and color scales shared by every row so the rows compare directly
        sharedScales = calculateSharedScales(allStats);

        % Create the figure and every row's axes
        handles = createFigureShell(allStats);

        for k = 1:numel(allStats)
            % Left panel: pooled uncertainty histogram with pixel area scale on top
            handles.rows(k).pixelAreaAxes = renderUncertaintyHistogram( ...
                handles.rows(k), allStats(k), sharedScales);

            % Right panel: per-cell fidelity heatmap
            renderFidelityHeatmap(handles.rows(k), allStats(k), sharedScales);
        end

        function sharedScales = calculateSharedScales(allStats)
            % MODEL: Histogram bins and y-limit, heatmap color limits (TERMINAL)
            %
            % The histogram y-axis is percent of each row's colonies, so rows with
            % different colony totals share one y-limit. Heatmap color limits span
            % the largest cell value in any row.

            xMax = 60;
            edges = 0:1:xMax;
            maxPercent = 0;
            observedMax = NaN;

            for k = 1:numel(allStats)
                values = allStats(k).relative_uncertainty_pct;
                if ~isempty(values)
                    counts = histcounts(min(values, xMax - 0.5), edges);
                    maxPercent = max(maxPercent, max(counts) / numel(values) * 100);
                end
                observedMax = max([observedMax, max(allStats(k).ona_matrix(:))]);
            end

            if maxPercent > 0
                histYMax = maxPercent * 1.15;
            else
                histYMax = 1;
            end

            if isnan(observedMax)
                upperLimit = 25;
            else
                upperLimit = max(25, ceil(observedMax));
            end

            sharedScales = struct( ...
                'histXMax', xMax, ...
                'histEdges', edges, ...
                'histYMax', histYMax, ...
                'colorLimits', [0, upperLimit]);
        end

        function handles = createFigureShell(allStats)
            % SUB-CONTROLLER: Build the figure window and every row's axes

            % Stack the rows and size each to its heatmap row count
            geometry = calculateFigureGeometry(allStats);

            % Create the figure, axes, titles, and panel letters
            handles = buildFigureAndAxes(geometry);

            function geometry = calculateFigureGeometry(allStats)
                % MODEL: Figure size and per-row positions (TERMINAL)
                %
                % Heights are laid out in pixels from the top, then normalized.
                % Each row stacks a title band (multi-row figures only), clearance
                % for the pixel area scale, the axes, and clearance for x labels.

                numPanelRows = numel(allStats);
                isMultiRow = numPanelRows > 1;

                figureTitleHeight = 50;
                rowTitleHeight = 30 * isMultiRow;
                topScaleHeight = 55;
                bottomLabelHeight = 60;
                bottomMargin = 10;

                axesHeights = zeros(numPanelRows, 1);
                for k = 1:numPanelRows
                    axesHeights(k) = 196 + 35 * allStats(k).num_rows;
                end

                figureHeight = figureTitleHeight + bottomMargin + ...
                    sum(rowTitleHeight + topScaleHeight + axesHeights + bottomLabelHeight);

                geometry = struct();
                geometry.figureWidth = 1180;
                geometry.figureHeight = figureHeight;
                geometry.backgroundColor = [1, 1, 1];

                % One typeface for every text element in the figure
                geometry.fontName = 'Times New Roman';

                rowTitles = cell(numPanelRows, 1);
                displayNames = cell(1, numPanelRows);
                for k = 1:numPanelRows
                    displayNames{k} = allStats(k).display_name;
                    rowTitles{k} = sprintf('%s  (%d colonies, %d Colony Sets)', ...
                        allStats(k).display_name, allStats(k).total_colonies, ...
                        allStats(k).num_colony_sets);
                end

                geometry.windowName = sprintf('Measurement Fidelity: %s', ...
                    strjoin(displayNames, ' vs '));

                % A single row carries its name in the figure title
                if isMultiRow
                    geometry.titleString = 'Measurement Fidelity';
                else
                    geometry.titleString = sprintf('Measurement Fidelity: %s', rowTitles{1});
                end

                % Title spans both panels and is centered across them
                geometry.titlePosition = [0.060, ...
                    (figureHeight - figureTitleHeight + 5) / figureHeight, ...
                    0.810, (figureTitleHeight - 10) / figureHeight];

                rows = struct( ...
                    'histPosition', cell(numPanelRows, 1), ...
                    'heatPosition', [], ...
                    'colorbarPosition', [], ...
                    'showTitle', isMultiRow, ...
                    'titlePosition', [], ...
                    'titleString', '', ...
                    'letterLeft', '', ...
                    'letterRight', '', ...
                    'letterLeftPosition', [], ...
                    'letterRightPosition', []);

                % Pixel height measured from the figure bottom, walked downward
                cursor = figureHeight - figureTitleHeight;

                for k = 1:numPanelRows
                    cursor = cursor - rowTitleHeight;
                    rowTitleBottom = cursor;
                    cursor = cursor - topScaleHeight;
                    axesTop = cursor;
                    cursor = cursor - axesHeights(k);
                    axesBottom = cursor;
                    cursor = cursor - bottomLabelHeight;

                    yAxes = axesBottom / figureHeight;
                    hAxes = axesHeights(k) / figureHeight;

                    rows(k).histPosition = [0.060, yAxes, 0.360, hAxes];
                    rows(k).heatPosition = [0.570, yAxes, 0.300, hAxes];
                    rows(k).colorbarPosition = [0.895, yAxes, 0.018, hAxes];

                    rows(k).titlePosition = [0.060, rowTitleBottom / figureHeight, ...
                        0.810, max(rowTitleHeight, 1) / figureHeight];
                    rows(k).titleString = rowTitles{k};

                    % Panel letters sit outboard of each panel's left edge, above the axes
                    letterBottom = (axesTop + 10) / figureHeight;
                    letterHeight = 30 / figureHeight;
                    rows(k).letterLeft = char('A' + 2 * (k - 1));
                    rows(k).letterRight = char('A' + 2 * (k - 1) + 1);
                    rows(k).letterLeftPosition = [0.012, letterBottom, 0.040, letterHeight];
                    rows(k).letterRightPosition = [0.522, letterBottom, 0.040, letterHeight];
                end

                geometry.rows = rows;
            end

            function handles = buildFigureAndAxes(geometry)
                % VIEW: Create the figure window, every row's axes, titles, and letters (TERMINAL)

                screenSize = get(0, 'ScreenSize');
                figLeft = max(20, (screenSize(3) - geometry.figureWidth) / 2);
                figBottom = max(50, (screenSize(4) - geometry.figureHeight) / 2);

                handles = struct();

                % Figure-level defaults reach every axes, tick label, axis label,
                % and text object created inside this figure
                handles.figure = figure( ...
                    'Name', geometry.windowName, ...
                    'NumberTitle', 'off', ...
                    'Color', geometry.backgroundColor, ...
                    'Position', [figLeft, figBottom, geometry.figureWidth, geometry.figureHeight], ...
                    'DefaultAxesFontName', geometry.fontName, ...
                    'DefaultTextFontName', geometry.fontName);

                annotation(handles.figure, 'textbox', geometry.titlePosition, ...
                    'String', geometry.titleString, ...
                    'EdgeColor', 'none', ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'middle', ...
                    'FontName', geometry.fontName, ...
                    'FontSize', 13, ...
                    'FontWeight', 'bold', ...
                    'Interpreter', 'none');

                numPanelRows = numel(geometry.rows);
                rows = struct( ...
                    'figure', cell(numPanelRows, 1), ...
                    'histAxes', [], ...
                    'heatAxes', [], ...
                    'pixelAreaAxes', [], ...
                    'colorbarPosition', [], ...
                    'fontName', geometry.fontName);

                for k = 1:numPanelRows
                    rowGeometry = geometry.rows(k);

                    rows(k).figure = handles.figure;
                    rows(k).colorbarPosition = rowGeometry.colorbarPosition;

                    rows(k).histAxes = axes( ...
                        'Parent', handles.figure, ...
                        'Units', 'normalized', ...
                        'Position', rowGeometry.histPosition, ...
                        'Box', 'off', ...
                        'TickDir', 'out', ...
                        'FontSize', 10);

                    rows(k).heatAxes = axes( ...
                        'Parent', handles.figure, ...
                        'Units', 'normalized', ...
                        'Position', rowGeometry.heatPosition, ...
                        'FontSize', 10);

                    if rowGeometry.showTitle
                        annotation(handles.figure, 'textbox', rowGeometry.titlePosition, ...
                            'String', rowGeometry.titleString, ...
                            'EdgeColor', 'none', ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle', ...
                            'FontName', geometry.fontName, ...
                            'FontSize', 12, ...
                            'FontWeight', 'bold', ...
                            'Interpreter', 'none');
                    end

                    annotation(handles.figure, 'textbox', rowGeometry.letterLeftPosition, ...
                        'String', rowGeometry.letterLeft, ...
                        'EdgeColor', 'none', ...
                        'HorizontalAlignment', 'left', ...
                        'VerticalAlignment', 'middle', ...
                        'FontName', geometry.fontName, ...
                        'FontSize', 20, ...
                        'FontWeight', 'bold', ...
                        'Interpreter', 'none');

                    annotation(handles.figure, 'textbox', rowGeometry.letterRightPosition, ...
                        'String', rowGeometry.letterRight, ...
                        'EdgeColor', 'none', ...
                        'HorizontalAlignment', 'left', ...
                        'VerticalAlignment', 'middle', ...
                        'FontName', geometry.fontName, ...
                        'FontSize', 20, ...
                        'FontWeight', 'bold', ...
                        'Interpreter', 'none');
                end

                handles.rows = rows;
            end
        end

        function pixelAreaAxes = renderUncertaintyHistogram(handles, stats, sharedScales)
            % SUB-CONTROLLER: Draw the pooled uncertainty distribution

            % Bin the data and derive the pixel area tick mapping
            histModel = buildHistogramModel(stats, sharedScales);

            % Shade the five fidelity zones behind the bars
            drawZoneBands(handles, histModel);

            % Draw the uncertainty histogram
            drawHistogramBars(handles, histModel);

            % Mark the zone boundaries and the pooled median
            drawHistogramMarkers(handles, histModel);

            % Label the histogram axes
            labelHistogramAxes(handles, histModel);

            % Add the pixel area scale along the top
            pixelAreaAxes = drawPixelAreaAxis(handles, histModel);

            function histModel = buildHistogramModel(stats, sharedScales)
                % MODEL: Histogram bins, zone bands, and pixel area ticks (TERMINAL)
                %
                % Bar heights are percent of this row's colonies; the y-limit is
                % shared across rows. Band edges and labels come from the zone
                % definition in stats, with the open upper edge closed at the
                % histogram's x-limit for shading.

                xMax = sharedScales.histXMax;
                edges = sharedScales.histEdges;
                values = stats.relative_uncertainty_pct;

                % Fold the tail into the final bin so the axis stays readable
                clamped = min(values, xMax - 0.5);
                counts = histcounts(clamped, edges);
                centers = edges(1:end-1) + diff(edges) / 2;

                if isempty(values)
                    percents = zeros(size(counts));
                else
                    percents = counts / numel(values) * 100;
                end

                yMax = sharedScales.histYMax;

                % Finite band edges for shading (the stored zone edges end at Inf)
                bandEdges = stats.zone_edges_pct;
                bandEdges(~isfinite(bandEdges)) = xMax;

                bandColors = [ ...
                    0.87, 0.94, 0.88; ...   % Zone 1  0-5%    high fidelity
                    0.93, 0.96, 0.85; ...   % Zone 2  5-10%   good fidelity
                    1.00, 0.96, 0.82; ...   % Zone 3  10-25%  moderate fidelity
                    0.99, 0.90, 0.83; ...   % Zone 4  25-50%  low fidelity
                    0.98, 0.86, 0.86];      % Zone 5  50%+    sub-pixel

                bandLabels = stats.zone_labels;

                % Pixel area scale: uncertainty u implies radius 50/u, area pi*r^2.
                % Ticks start at the 5% boundary; the 2.5% tick crowded its neighbor
                % and covered a colony size range the data does not reach.
                tickUncertainty = [5, 10, 25, 50];
                tickArea = pi * (50 ./ tickUncertainty) .^ 2;

                if isempty(values)
                    medianValue = NaN;
                    medianArea = NaN;
                else
                    medianValue = median(values);
                    medianArea = median(stats.pixel_areas);
                end

                histModel = struct( ...
                    'edges', edges, ...
                    'percents', percents, ...
                    'centers', centers, ...
                    'xLimits', [0, xMax], ...
                    'yLimits', [0, yMax], ...
                    'bandEdges', bandEdges, ...
                    'bandColors', bandColors, ...
                    'bandLabels', {bandLabels}, ...
                    'bandLabelFraction', 0.945, ...
                    'medianGapFraction', [0.920, 0.95], ...
                    'boundaries', bandEdges(2:end-1), ...
                    'tickUncertainty', tickUncertainty, ...
                    'tickArea', tickArea(:)', ...
                    'medianValue', medianValue, ...
                    'medianArea', medianArea, ...
                    'totalColonies', stats.total_colonies);
            end

            function drawZoneBands(handles, histModel)
                % VIEW: Shade the five fidelity zones (TERMINAL)

                ax = handles.histAxes;
                cla(ax);
                hold(ax, 'on');

                yTop = histModel.yLimits(2);

                for b = 1:size(histModel.bandColors, 1)
                    xLeft = histModel.bandEdges(b);
                    xRight = histModel.bandEdges(b + 1);

                    patch(ax, ...
                        [xLeft, xRight, xRight, xLeft], ...
                        [0, 0, yTop, yTop], ...
                        histModel.bandColors(b, :), ...
                        'EdgeColor', 'none');

                    text(ax, (xLeft + xRight) / 2, yTop * histModel.bandLabelFraction, ...
                        histModel.bandLabels{b}, ...
                        'HorizontalAlignment', 'center', ...
                        'VerticalAlignment', 'top', ...
                        'FontSize', 8, ...
                        'Color', [0.35, 0.35, 0.35], ...
                        'Interpreter', 'none');
                end
            end

            function drawHistogramBars(handles, histModel)
                % VIEW: Draw the uncertainty histogram bars (TERMINAL)

                ax = handles.histAxes;

                bar(ax, histModel.centers, histModel.percents, 1.0, ...
                    'FaceColor', [0.24, 0.26, 0.30], ...
                    'EdgeColor', 'none', ...
                    'FaceAlpha', 0.85);
            end

            function drawHistogramMarkers(handles, histModel)
                % VIEW: Draw zone boundary lines and the pooled median (TERMINAL)

                ax = handles.histAxes;
                yTop = histModel.yLimits(2);

                for b = 1:numel(histModel.boundaries)
                    xBoundary = histModel.boundaries(b);
                    line(ax, [xBoundary, xBoundary], [0, yTop], ...
                        'Color', [0.55, 0.55, 0.55], ...
                        'LineStyle', '--', ...
                        'LineWidth', 0.8);
                end

                if ~isnan(histModel.medianValue)
                    % Two segments with a gap at the band label height
                    gapBottom = yTop * histModel.medianGapFraction(1);
                    gapTop = yTop * histModel.medianGapFraction(2);

                    line(ax, [histModel.medianValue, histModel.medianValue], [0, gapBottom], ...
                        'Color', [0.75, 0.10, 0.10], ...
                        'LineStyle', '-', ...
                        'LineWidth', 1.8);

                    line(ax, [histModel.medianValue, histModel.medianValue], [gapTop, yTop], ...
                        'Color', [0.75, 0.10, 0.10], ...
                        'LineStyle', '-', ...
                        'LineWidth', 1.8);

                    text(ax, histModel.medianValue + 2, yTop * 0.80, ...
                        sprintf('median %.1f%%  (%d px)', ...
                            histModel.medianValue, round(histModel.medianArea)), ...
                        'Color', [0.75, 0.10, 0.10], ...
                        'FontSize', 9, ...
                        'FontWeight', 'bold', ...
                        'HorizontalAlignment', 'left', ...
                        'Interpreter', 'none');
                end
            end

            function labelHistogramAxes(handles, histModel)
                % VIEW: Set histogram limits, labels, and tick style (TERMINAL)

                ax = handles.histAxes;

                set(ax, ...
                    'XLim', histModel.xLimits, ...
                    'YLim', histModel.yLimits, ...
                    'Box', 'off', ...
                    'TickDir', 'out', ...
                    'Layer', 'top', ...
                    'FontSize', 10);

                xlabel(ax, 'Measurement uncertainty (% of colony radius)', 'FontSize', 11);
                ylabel(ax, 'Colonies (%)', 'FontSize', 11);

                hold(ax, 'off');
            end

            function pixelAreaAxes = drawPixelAreaAxis(handles, histModel)
                % VIEW: Overlay a pixel area scale on the top edge (TERMINAL)

                axesPosition = get(handles.histAxes, 'Position');
                scaleColor = [0.18, 0.30, 0.55];

                tickLabels = cell(1, numel(histModel.tickArea));
                for t = 1:numel(histModel.tickArea)
                    tickLabels{t} = sprintf('%d', round(histModel.tickArea(t)));
                end

                pixelAreaAxes = axes( ...
                    'Parent', handles.figure, ...
                    'Units', 'normalized', ...
                    'Position', axesPosition, ...
                    'Color', 'none', ...
                    'XAxisLocation', 'top', ...
                    'XLim', histModel.xLimits, ...
                    'YLim', [0, 1], ...
                    'XTick', histModel.tickUncertainty, ...
                    'XTickLabel', tickLabels, ...
                    'YTick', [], ...
                    'Box', 'off', ...
                    'TickDir', 'out', ...
                    'XColor', scaleColor, ...
                    'YColor', 'none', ...
                    'FontSize', 10, ...
                    'HitTest', 'off');

                xlabel(pixelAreaAxes, 'Colony area (pixels)', ...
                    'Color', scaleColor, ...
                    'FontSize', 11);
            end
        end

        function renderFidelityHeatmap(handles, stats, sharedScales)
            % SUB-CONTROLLER: Draw the per-cell fidelity heatmap

            % Build the color scale and the cell label strings
            heatModel = buildHeatmapModel(handles, stats, sharedScales);

            % Draw the heatmap surface and its color scale
            drawHeatmapSurface(handles, heatModel);

            % Write the per-cell uncertainty, pixel area, and zone labels
            drawHeatmapCellLabels(handles, heatModel);

            % Separate the blocks and outline the cells
            drawHeatmapDividers(handles, heatModel);

            function heatModel = buildHeatmapModel(handles, stats, sharedScales)
                % MODEL: Colormap and cell label text on the shared color limits (TERMINAL)
                %
                % Each cell with data carries, top to bottom: the uncertainty
                % percentage, the pixel area in parentheses, the fidelity zone
                % name, and the plate count when any cell holds more than one plate.

                uncertaintyMatrix = stats.ona_matrix;
                areaMatrix = stats.ona_area_matrix;
                countMatrix = stats.ona_count_matrix;
                zoneIndexMatrix = stats.ona_zone_index;
                zoneLabels = stats.zone_labels;

                colorLimits = sharedScales.colorLimits;

                % Green to yellow to red, built without toolbox dependencies
                halfLength = 128;
                lowColor = [0.16, 0.50, 0.32];
                midColor = [0.96, 0.82, 0.26];
                highColor = [0.72, 0.13, 0.13];

                lowHalf = [linspace(lowColor(1), midColor(1), halfLength)', ...
                           linspace(lowColor(2), midColor(2), halfLength)', ...
                           linspace(lowColor(3), midColor(3), halfLength)'];
                highHalf = [linspace(midColor(1), highColor(1), halfLength)', ...
                            linspace(midColor(2), highColor(2), halfLength)', ...
                            linspace(midColor(3), highColor(3), halfLength)'];
                colorMap = [lowHalf; highHalf];

                numRows = stats.num_rows;
                numCols = stats.num_cols;
                cellLabels = cell(numRows, numCols);
                cellColors = cell(numRows, numCols);

                % Plate counts and the mean label appear only when a cell holds
                % more than one plate
                plateCountMatrix = stats.ona_plate_count_matrix;
                showPlateCount = max(plateCountMatrix(:)) > 1;
                if showPlateCount
                    colorbarLabel = 'Mean median uncertainty (%)';
                else
                    colorbarLabel = 'Median uncertainty (%)';
                end

                for r = 1:numRows
                    for c = 1:numCols
                        if isnan(uncertaintyMatrix(r, c)) || countMatrix(r, c) == 0
                            cellLabels{r, c} = {'no data'};
                            cellColors{r, c} = [0.45, 0.45, 0.45];
                        else
                            cellLabels{r, c} = { ...
                                sprintf('%.1f%%', uncertaintyMatrix(r, c)); ...
                                sprintf('(%d px)', round(areaMatrix(r, c))); ...
                                zoneLabels{zoneIndexMatrix(r, c)}};

                            if showPlateCount
                                cellLabels{r, c}{end+1, 1} = ...
                                    sprintf('n = %d', plateCountMatrix(r, c));
                            end

                            normalized = (uncertaintyMatrix(r, c) - colorLimits(1)) / ...
                                         (colorLimits(2) - colorLimits(1));
                            if normalized > 0.62
                                cellColors{r, c} = [1, 1, 1];
                            else
                                cellColors{r, c} = [0.10, 0.10, 0.10];
                            end
                        end
                    end
                end

                heatModel = struct( ...
                    'matrix', uncertaintyMatrix, ...
                    'alphaData', double(~isnan(uncertaintyMatrix)), ...
                    'colorLimits', colorLimits, ...
                    'colorMap', colorMap, ...
                    'cellLabels', {cellLabels}, ...
                    'cellColors', {cellColors}, ...
                    'rowLabels', {stats.ona_row_labels}, ...
                    'colLabels', {stats.ona_col_labels}, ...
                    'xLabel', stats.ona_x_label, ...
                    'yLabel', stats.ona_y_label, ...
                    'blockBoundaries', stats.ona_block_boundaries, ...
                    'numRows', numRows, ...
                    'numCols', numCols, ...
                    'fontName', handles.fontName, ...
                    'colorbarLabel', colorbarLabel, ...
                    'colorbarPosition', handles.colorbarPosition);
            end

            function drawHeatmapSurface(handles, heatModel)
                % VIEW: Draw the heatmap image, ticks, and colorbar (TERMINAL)

                ax = handles.heatAxes;
                axesPosition = get(ax, 'Position');
                cla(ax);

                imagesc(ax, heatModel.matrix, 'AlphaData', heatModel.alphaData);

                colormap(ax, heatModel.colorMap);
                caxis(ax, heatModel.colorLimits);

                set(ax, ...
                    'XTick', 1:heatModel.numCols, ...
                    'XTickLabel', heatModel.colLabels, ...
                    'YTick', 1:heatModel.numRows, ...
                    'YTickLabel', heatModel.rowLabels, ...
                    'TickLabelInterpreter', 'none', ...
                    'XLim', [0.5, heatModel.numCols + 0.5], ...
                    'YLim', [0.5, heatModel.numRows + 0.5], ...
                    'TickDir', 'out', ...
                    'TickLength', [0, 0], ...
                    'Box', 'on', ...
                    'Layer', 'top', ...
                    'FontSize', 10);

                xlabel(ax, heatModel.xLabel, 'FontSize', 11);

                % Y label only when NominalLabel was supplied
                if ~isempty(heatModel.yLabel)
                    ylabel(ax, heatModel.yLabel, 'FontSize', 11);
                end

                colorHandle = colorbar(ax, ...
                    'Units', 'normalized', ...
                    'Position', heatModel.colorbarPosition, ...
                    'FontName', heatModel.fontName);
                ylabel(colorHandle, heatModel.colorbarLabel, 'FontSize', 10);

                % Creating a colorbar resizes the axes; restore the intended position
                set(ax, 'Units', 'normalized', 'Position', axesPosition);
            end

            function drawHeatmapCellLabels(handles, heatModel)
                % VIEW: Write uncertainty, pixel area, and zone into every cell (TERMINAL)

                ax = handles.heatAxes;
                hold(ax, 'on');

                for r = 1:heatModel.numRows
                    for c = 1:heatModel.numCols
                        text(ax, c, r, heatModel.cellLabels{r, c}, ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle', ...
                            'Color', heatModel.cellColors{r, c}, ...
                            'FontSize', 9, ...
                            'FontWeight', 'bold', ...
                            'Interpreter', 'none');
                    end
                end
            end

            function drawHeatmapDividers(handles, heatModel)
                % VIEW: Outline cells and separate the blocks (TERMINAL)

                ax = handles.heatAxes;
                xSpan = [0.5, heatModel.numCols + 0.5];
                ySpan = [0.5, heatModel.numRows + 0.5];

                % Light cell outlines
                for r = 1:(heatModel.numRows - 1)
                    line(ax, xSpan, [r + 0.5, r + 0.5], ...
                        'Color', [1, 1, 1], 'LineWidth', 0.75);
                end
                for c = 1:(heatModel.numCols - 1)
                    line(ax, [c + 0.5, c + 0.5], ySpan, ...
                        'Color', [1, 1, 1], 'LineWidth', 0.75);
                end

                % Heavy divider between blocks (none in grid mode)
                for b = 1:numel(heatModel.blockBoundaries)
                    yDivider = heatModel.blockBoundaries(b) + 0.5;
                    line(ax, xSpan, [yDivider, yDivider], ...
                        'Color', [0, 0, 0], 'LineWidth', 2.5);
                end

                hold(ax, 'off');
            end
        end
    end

    % =========================================================
    % SHARED FUNCTIONS
    % =========================================================

    function titled = titleCaseStrings(names)
        % MODEL: Title Case each string, reading underscores as spaces (TERMINAL)

        titled = cell(size(names));

        for n = 1:numel(names)
            rawName = char(string(names{n}));
            nameParts = strsplit(strtrim(strrep(rawName, '_', ' ')));

            for p = 1:numel(nameParts)
                word = nameParts{p};
                if isempty(word)
                    continue;
                end
                word(1) = upper(word(1));
                nameParts{p} = word;
            end

            titled{n} = strjoin(nameParts, ' ');
        end
    end
end
function generateOverviewPDF(data, datasetName, axisSpec, figureCalls)
    % CONTROLLER: Generate a multi-page PDF overview of one dataset. Two things
    % are decided up front and kept independent: the input FORMAT (a DatasetCreator
    % passage struct array, "datasets"; or a composite struct array, bare or
    % wrapped in a .composite field, "composite") and the layout MODE ("selected"
    % vs "full"). Mode is decided by multiplicity: the eligible plates are grouped
    % by (nominal, ordinal) index, and if any index holds more than one plate the
    % data carries an uncollapsed third dimension and runs the "full" pipeline (one
    % ON index per page, plates laid out within the index); otherwise it runs the
    % "selected" pipeline (one cell per index, in a nominal-by-ordinal grid). A
    % datasets array can hold at most one plate per index by construction, so it is
    % always "selected".
    %
    % axisSpec names the composite fields used as the nominal and ordinal axes, so
    % the generator is not tied to genotype/passage:
    %   struct('Nominal','genotype','Ordinal','passage')   (default)
    %   struct('Nominal','genotype','Ordinal','hce')       (e.g. a dilution series)
    % Optional 'NominalLabel'/'OrdinalLabel' fields set the display names; they
    % default to the capitalized field name. Optional 'NominalLabels' relabels
    % individual nominal values by key, e.g.
    %   struct('NominalLabels', {{'double', 'dbf4-1, cdc13-2'}})
    % and applies to datasets input as well as composite input; a label naming
    % two mutations also places an opaque key in the double-mutant slot of the
    % structural order. The same spec reaches the fidelity page, which applies
    % the same relabeling. The axisSpec applies to composite
    % input only: a datasets array encodes its axes in its shape (genotype as field
    % name, passage as array index), so axisSpec is ignored there. Because the
    % axisSpec defines the index over which multiplicity is counted, it determines
    % routing: the same composite can land in either pipeline depending on which
    % field is the ordinal. Full mode's standard-vs-protocol-mod split rests on a
    % dataset-specific definition of the canonical plate per index, so full mode
    % is supported under default genotype/passage axes only; a non-default axisSpec
    % that would route to full raises a directed error.
    %
    % Either axis may be 'none', a null axis, for experiments that vary one factor:
    %   struct('Nominal','none','Ordinal','dilution_factor','OrdinalLabel','Dilution Factor')
    % normalizeAxes gives a null axis a constant synthetic field, so the grouping
    % code sees one value, and the views that would print that value (column or
    % row headers, the reflow nominal label, box plot group labels or ticks) are
    % skipped. A null ordinal over a numeric nominal is transposed to a null
    % nominal over that field as the ordinal, since the ordinal is the axis the
    % layouts sequence (reflow wraps it, box plots tick it). A numeric nominal
    % that stays nominal is keyed by its printed value and sorted ascending. Both
    % axes null is an error. Null and numeric nominals take one neutral color in
    % place of the genotype palette.
    %
    % Ordinal values are snapped to 10 significant digits before keying, so float
    % representation cannot split one logical index; the relative snap holds for
    % integer and fractional factors alike.
    %
    % An optional 'Block' field names a third dimension that splits a composite
    % into studies rendered one after another, e.g. the two figures of the
    % Anbalagan set:
    %   struct('Block','figure')
    % Each block gets its own config (nominal order, labels, ordinal values,
    % colors), so each figure forms its own grid; one scaling spans every block,
    % so all pages share axes. Within each figure type, pages run block by block
    % (Figure 2, then Figure 8), and each block gets its own box plot page. Page
    % titles carry the block as BlockLabel plus value ('BlockLabel' defaults to
    % the capitalized field name). Multiplicity is counted per (block, nominal,
    % ordinal) index. The Block axis applies to selected mode on composite input:
    % a block routing to full raises an error, and datasets input ignores it.
    %
    % Each cell carries a stat block below it: one value per line, centered
    % under the plot, with the row names printed once per page row in gray,
    % left of the first column. Image pages and distribution pages carry
    % different fields. Image pages list what a reader checks against the
    % photo: colony count, the colony-to-growth capture ratio, and replicate,
    % HCE, and plate diameter where they vary. Distribution pages list what
    % summarizes the plotted distribution: median radius and the q1-q3 range.
    % A registry in the config names each candidate field, its path into the
    % entry, its format, and its page type, and each block's eligible entries
    % sort every candidate into one of three classes. A field missing on every
    % entry (empty, NaN, or a placeholder such as 'N/A') is omitted. A field
    % holding one value across every entry that records it moves to a footnote
    % at the lower right of the pages of its type, with "(where recorded)"
    % appended when some entries lack it. A field whose value varies prints in
    % each cell, with an en dash where an entry lacks it, so every line stays
    % level with its row name. Colony count always prints, and a field that is
    % also an axis is omitted, since the headers already print it. Values are
    % formatted by type, so a text value never reaches a numeric conversion.
    % Photo axes are fit to the image aspect with their bottom edge fixed, so
    % the stat block sits directly under each photo and holds one level across
    % a page row. Ordinal row headers are drawn rotated beside the first
    % column, leaving the left margin below them for the row names.
    %
    % Both pipelines share one scaling computation, one set of cell renderers, and
    % one plate-flag system. Flags mark non-standard enrichment plates (dagger,
    % tier 1) and 140 mm plates (double dagger, tier 2) over their box, with a key
    % listing the event types that fired; a plate that trips both rules gets two
    % glyphs at different log-radius tiers so they never overlap.
    %
    % Every page is typeset in config.font_name (Times New Roman) by way of
    % figure-level Default*FontName properties set at figure creation, so axes,
    % text, and annotation objects all inherit it without per-call-site font
    % arguments. Two consequences shape the code: the micron sign is written as
    % char(956) with Interpreter 'none', because the TeX interpreter draws its
    % symbols from MATLAB's own symbol font and would not match the surrounding
    % text; and the 140 mm flag uses a double dagger, because Times New Roman
    % carries no star glyph and the vector export would embed a missing-glyph box.
    %
    % Every box plot page carries a two-row summary band above the axes: colony
    % count on the upper row, median colony radius in whole microns on the lower
    % row, one pair of numbers per box, with row labels in the left margin. The
    % numbers hold one uniform line across the page, because both row heights are
    % fixed fractions of the axis span.
    %
    % The band is drawn into the box axes itself, at data x-coordinates with
    % clipping off, the same way the flag glyphs are. A second axes positioned
    % from computeBoxAxesRect will not line up: boxplot adjusts the axes after its
    % Position is set, so the rectangle the config predicts is not the rectangle
    % the boxes are drawn on, and per-box numbers show that drift immediately.
    % Sharing one ruler makes the x alignment exact by construction. Both box plot
    % pages still reserve vertical room for the band by shrinking the axes from
    % the top, so the unclipped text has somewhere to sit.
    %
    % The ordinal axis name under each box plot is drawn the same way, as in-axes
    % text at a computed y below the tick or passage labels. The axes XLabel is
    % not used: boxplot's compact style repositions axis decorations after they
    % are set, and an XLabel pushed off the figure is cropped away on export.
    %
    % Box plot y axes carry explicit ticks from config.y_ticks_um in place of the
    % decade ticks a log scale defaults to, since the radius range spans well under
    % one decade and would otherwise label a single value.
    %
    % The selected pipeline paginates: each grid page holds at most config.max_cols
    % nominal columns and config.max_rows_selected ordinal rows (4 x 5 = 20 cells),
    % tiling wider/taller datasets across pages per figure type, with box plot
    % pages chunked on the nominal axis. A nominal chunk narrower than the page
    % layout is centered, keeping the slot width of a full page.
    %
    % Every page exports at the figure's own dimensions (exportgraphics Padding
    % 'figure'), so pages with content past their axes match the grid pages in
    % size.
    %
    % The first page is the measurement fidelity figure from
    % analyzeMeasurementFidelity, so the reader sees whether the colonies were
    % resolvable before any distribution built on them. It receives the input as
    % supplied and the caller's axisSpec as supplied, before normalizeAxes
    % rewrites either, since that function handles null and numeric axes itself.
    % Its figure is sized in pixels by its own layout, so this page exports at a
    % different size from the rest; PDF viewers handle mixed page sizes. A
    % fidelity error skips the page with a warning, and the overview is written
    % without it.
    %
    % The output file name is <datasetName>_Overview_<Mode>.pdf, e.g.
    %   generateOverviewPDF(composite.anbalagan, 'anbalagan')
    %     -> anbalagan_Overview_Selected.pdf
    % datasetName is supplied explicitly by the caller because inputname cannot
    % resolve a field reference. If omitted, it falls back to 'UnknownDataset'.
    %
    % figureCalls (optional, fourth argument) appends project figures after the
    % overview pages. It is a cell array of zero-argument function handles, each
    % carrying its own arguments:
    %   {@() plotSenescenceDecline(composite.anbalagan, struct('scale', 'raw')), ...
    %    @() showWithinStatePredictorsOfSize(composite)}
    % Pass [] as axisSpec to supply figureCalls without a spec. Each handle runs
    % in list order with new figures kept off screen; every figure it creates is
    % exported as its own page, in creation order, then closed. A call may create
    % any number of figures. The capture sees figures a call creates, so a call
    % that draws into an already open figure, or saves and closes its own figure,
    % adds no page. Return values are discarded. A failed call warns and the PDF
    % continues with the next handle.

    % === RESOLVE ARGUMENTS ===
    if nargin < 2 || isempty(datasetName)
        datasetName = 'UnknownDataset';
    end
    if nargin < 3 || isempty(axisSpec)
        axisSpec = struct();
    end
    if nargin < 4
        figureCalls = {};
    end
    figureCalls = resolveFigureCalls(figureCalls);
    rawData = data;
    userAxisSpec = axisSpec;
    axisSpec = resolveAxisSpec(axisSpec);
    [data, axisSpec] = normalizeAxes(data, axisSpec);

    % === COORDINATE PIPELINE ===
    [mode, format] = classifyInput(data, axisSpec);

    % One config per block; a dataset without a Block axis is one block
    overviewBlocks = partitionBlocks(data, format, axisSpec);
    blockConfigs = cell(1, numel(overviewBlocks));
    for blockIdx = 1:numel(overviewBlocks)
        blockConfigs{blockIdx} = getOverviewConfig(mode, format, overviewBlocks(blockIdx).data, axisSpec);
        blockConfigs{blockIdx}.block_title = overviewBlocks(blockIdx).title;
    end
    config = blockConfigs{1};

    pipelineSettings = pipelineConfig();
    outputPath = fullfile( ...
        pipelineSettings.overviewFolder, ...
        sprintf('%s_Overview_%s.pdf', datasetName, capitalizeFirst(mode)) ...
    );

    clearExistingOutput(outputPath);
    pageOffset = renderFidelityPage(rawData, format, datasetName, userAxisSpec, outputPath);

    switch mode
        case 'selected'
            lastPage = runSelectedPipeline(overviewBlocks, format, blockConfigs, outputPath, pageOffset);
        case 'full'
            % Full reads data.composite; a bare composite is wrapped so the same
            % entry point serves both wrapped (Part3CompleteData) and bare input.
            % Full mode never carries a Block axis, so config is its one config.
            if ~isfield(data, 'composite')
                data = struct('composite', data);
            end
            lastPage = runFullPipeline(data, config, outputPath, pageOffset);
    end

    appendSupplementalFigures(figureCalls, outputPath, lastPage);

    fprintf('Overview PDF (%s) written to: %s\n', mode, outputPath);


    % ============================================================
    % OUTPUT FILE AND FIDELITY PAGE
    % ============================================================
    function calls = resolveFigureCalls(figureCalls)
        % MODEL: Normalize figureCalls to a row cell of function handles. Empty
        % gives no calls; a lone handle is wrapped in a cell. Anything else that
        % is not a cell of handles raises an error before any page is written,
        % so a malformed list cannot leave a partial PDF. (TERMINAL)
        if isempty(figureCalls)
            calls = {};
            return;
        end
        if isa(figureCalls, 'function_handle')
            calls = {figureCalls};
            return;
        end
        if ~iscell(figureCalls) || ~all(cellfun(@(h) isa(h, 'function_handle'), figureCalls))
            error('generateOverviewPDF:badFigureCalls', ...
                ['figureCalls must be a cell array of zero-argument function ' ...
                 'handles, e.g. {@() myFigure(composite.part3)}.']);
        end
        calls = figureCalls(:)';
    end

    function appendSupplementalFigures(figureCalls, outputPath, lastPage)
        % SUB-CONTROLLER: Run each figure call in list order and append every
        % figure it creates as its own page, numbering on from the overview's
        % last page. Each call's figures export in creation order and close
        % after export, so the next call's capture starts clean.
        appendPage = lastPage;
        for callIdx = 1:numel(figureCalls)
            newFigures = captureCallFigures(figureCalls{callIdx}, callIdx);
            for figIdx = 1:numel(newFigures)
                appendPage = appendPage + 1;
                exportPageToPDF(newFigures(figIdx), outputPath, appendPage);
                close(newFigures(figIdx));
            end
        end

        function newFigures = captureCallFigures(figureCall, callIdx)
            % VIEW: Run one figure call off screen and return the figures it
            % created, ordered by figure Number (creation order; a figure with no
            % Number sorts last). The root DefaultFigureVisible is off for the
            % call and onCleanup restores it on every exit path. Figures are
            % compared by handle equality against a snapshot taken before the
            % call. A failed call warns, closes whatever it left open, and
            % returns no figures. (TERMINAL: the one call is the caller's figure
            % function)
            previousVisibility = get(groot, 'DefaultFigureVisible');
            restoreVisibility = onCleanup(@() set(groot, 'DefaultFigureVisible', previousVisibility)); %#ok<NASGU>
            set(groot, 'DefaultFigureVisible', 'off');
            figuresBefore = findall(groot, 'Type', 'figure');

            callFailed = false;
            try
                figureCall();
            catch callError
                callFailed = true;
                warning('generateOverviewPDF:supplementalFigureFailed', ...
                    'Figure call %d (%s) failed and was skipped: %s', ...
                    callIdx, func2str(figureCall), callError.message);
            end

            figuresAfter = findall(groot, 'Type', 'figure');
            isNew = arrayfun(@(h) ~any(h == figuresBefore), figuresAfter);
            created = figuresAfter(isNew);

            if callFailed
                close(created);
                newFigures = gobjects(0);
                return;
            end

            figureNumbers = inf(numel(created), 1);
            for k = 1:numel(created)
                if ~isempty(created(k).Number)
                    figureNumbers(k) = created(k).Number;
                end
            end
            [~, creationOrder] = sort(figureNumbers);
            newFigures = created(creationOrder);
        end
    end

    function blocks = partitionBlocks(data, format, axisSpec)
        % MODEL: Split the input into the blocks the selected pipeline renders
        % one after another. Without a Block axis, or on datasets input, the
        % whole input is one untitled block. With one, the composite is split by
        % the block field's values: numeric values in ascending order, text in
        % first-appearance order. Each block holds a bare composite subset and a
        % title of BlockLabel plus the value, e.g. "Figure 2". (TERMINAL)
        if strcmp(format, 'datasets') || isempty(axisSpec.Block)
            blocks = struct('data', {data}, 'title', {''});
            return;
        end

        if isstruct(data) && isscalar(data) && isfield(data, 'composite')
            composite = data.composite;
        else
            composite = data;
        end

        blockField = axisSpec.Block;
        rawValues = {composite.(blockField)};
        isNumericBlock = all(cellfun(@(v) isnumeric(v) && isscalar(v), rawValues));
        if isNumericBlock
            numericValues = cell2mat(rawValues);
            blockValues = num2cell(unique(numericValues));   % sorted ascending
            valueText = cellfun(@(v) sprintf('%g', v), blockValues, 'UniformOutput', false);
            entryText = cellfun(@(v) sprintf('%g', v), rawValues, 'UniformOutput', false);
        else
            entryText = cellfun(@(v) char(v), rawValues, 'UniformOutput', false);
            valueText = unique(entryText, 'stable');
        end

        blocks = struct('data', {}, 'title', {});
        for k = 1:numel(valueText)
            mask = strcmp(entryText, valueText{k});
            blocks(end+1).data = composite(mask); %#ok<AGROW>
            blocks(end).title = sprintf('%s %s', axisSpec.BlockLabel, valueText{k});
        end
    end

    function clearExistingOutput(outputPath)
        % VIEW: Delete a previous PDF at the output path, so the first exported
        % page starts a new file (TERMINAL)
        if exist(outputPath, 'file')
            delete(outputPath);
        end
    end

    function pagesWritten = renderFidelityPage(rawData, format, datasetName, userAxisSpec, outputPath)
        % SUB-CONTROLLER: Render the measurement fidelity figure and export it as
        % page 1. Returns the number of pages written (1, or 0 when the figure
        % could not be produced), which the pipelines take as their page offset.
        fidelityInput = buildFidelityInput(rawData, format, datasetName);
        fig = drawFidelityFigure(fidelityInput, userAxisSpec);
        if isempty(fig)
            pagesWritten = 0;
            return;
        end
        exportPageToPDF(fig, outputPath, 1);
        close(fig);
        pagesWritten = 1;

        function fidelityInput = buildFidelityInput(rawData, format, datasetName)
            % MODEL: Shape the input for analyzeMeasurementFidelity (TERMINAL)
            %   composite: fidelity expects a parent struct and a field name, so
            %              the dataset is wrapped under a valid-name key. The
            %              cell braces keep a struct array as one field value.
            %              A .composite-wrapped dataset passes through the same
            %              way, since fidelity unwraps it.
            %   datasets:  a grid passes as is, with the key as its label.
            % An empty display name makes fidelity title-case the key, so
            % 'Crowding_Dataset' is titled "Crowding Dataset".
            key = matlab.lang.makeValidName(datasetName);
            switch format
                case 'composite'
                    fidelityInput.data = struct(key, {rawData});
                case 'datasets'
                    fidelityInput.data = rawData;
            end
            fidelityInput.key = key;
        end

        function fig = drawFidelityFigure(fidelityInput, userAxisSpec)
            % VIEW: Draw the fidelity figure off screen and return its handle, or
            % [] on failure. analyzeMeasurementFidelity creates its figure without
            % a Visible setting, so the root default is turned off for the call;
            % onCleanup restores the previous default on every exit path. Any
            % figure a failed call left open is closed. (TERMINAL: the one call is
            % the external figure generator)
            previousVisibility = get(groot, 'DefaultFigureVisible');
            restoreVisibility = onCleanup(@() set(groot, 'DefaultFigureVisible', previousVisibility)); %#ok<NASGU>
            set(groot, 'DefaultFigureVisible', 'off');
            figuresBefore = findall(groot, 'Type', 'figure');
            try
                fidelityStats = analyzeMeasurementFidelity( ...
                    fidelityInput.data, fidelityInput.key, '', userAxisSpec);
                fig = fidelityStats(1).figure_handle;
            catch fidelityError
                warning('generateOverviewPDF:fidelitySkipped', ...
                    'Measurement fidelity page skipped: %s', fidelityError.message);
                figuresAfter = findall(groot, 'Type', 'figure');
                isStray = arrayfun(@(h) ~any(h == figuresBefore), figuresAfter);
                close(figuresAfter(isStray));
                fig = [];
            end
        end
    end


    % ============================================================
    % AXIS SPEC RESOLUTION
    % ============================================================
    function spec = resolveAxisSpec(axisSpec)
        % MODEL: Fill axisSpec defaults. Nominal/Ordinal are composite field names;
        % NominalLabel/OrdinalLabel are display names defaulting to the capitalized
        % field name. The ordering fields drive applyNominalOrder: NominalOrder, an
        % explicit left-to-right list of nominal keys (empty by default, which
        % selects the structural rule), and the two structural anchors,
        % WildTypeToken (sorts first) and AnchorGene (the senescent allele, which
        % sorts last within a mutation-count tier). NominalLabels is an n-by-2 cell
        % of {key, label} pairs that replace display labels by nominal key; a flat
        % list of pairs is reshaped to n-by-2. Block names a composite field that
        % splits the data into separately rendered blocks (empty by default);
        % BlockLabel prefixes each block's value in page titles and defaults to
        % the capitalized field name. (TERMINAL)
        spec = axisSpec;
        if ~isfield(spec, 'Nominal') || isempty(spec.Nominal)
            spec.Nominal = 'genotype';
        end
        if ~isfield(spec, 'Ordinal') || isempty(spec.Ordinal)
            spec.Ordinal = 'passage';
        end
        spec.Nominal = char(spec.Nominal);
        spec.Ordinal = char(spec.Ordinal);
        if ~isfield(spec, 'NominalLabel') || isempty(spec.NominalLabel)
            spec.NominalLabel = capitalizeFirst(spec.Nominal);
        end
        if ~isfield(spec, 'OrdinalLabel') || isempty(spec.OrdinalLabel)
            spec.OrdinalLabel = capitalizeFirst(spec.Ordinal);
        end
        if ~isfield(spec, 'WildTypeToken') || isempty(spec.WildTypeToken)
            spec.WildTypeToken = 'wild_type';
        end
        if ~isfield(spec, 'AnchorGene') || isempty(spec.AnchorGene)
            spec.AnchorGene = 'cdc13-2';
        end
        if ~isfield(spec, 'NominalOrder')
            spec.NominalOrder = {};
        end
        if ~isfield(spec, 'Block') || isempty(spec.Block)
            spec.Block = '';
        end
        spec.Block = char(spec.Block);
        if ~isfield(spec, 'BlockLabel') || isempty(spec.BlockLabel)
            spec.BlockLabel = capitalizeFirst(spec.Block);
        end
        spec.BlockLabel = char(spec.BlockLabel);
        if ~isfield(spec, 'NominalLabels') || isempty(spec.NominalLabels)
            spec.NominalLabels = cell(0, 2);
        end
        if ~iscell(spec.NominalLabels) || ...
                (size(spec.NominalLabels, 2) ~= 2 && mod(numel(spec.NominalLabels), 2) ~= 0)
            error('generateOverviewPDF:badNominalLabels', ...
                'NominalLabels must be a cell of {key, label} pairs, e.g. {''double'', ''dbf4-1, cdc13-2''}.');
        end
        if size(spec.NominalLabels, 2) ~= 2
            spec.NominalLabels = reshape(spec.NominalLabels, 2, [])';
        end
    end

    function [data, spec] = normalizeAxes(data, axisSpec)
        % MODEL: Rewrite null and numeric axes into the char-nominal /
        % numeric-ordinal shape every downstream function expects, and record
        % what was rewritten as flags on the spec. (TERMINAL)
        %
        %   Null ordinal over a numeric nominal: transposed, so the numeric field
        %     becomes the ordinal (carrying NominalLabel as its label) and the
        %     nominal becomes null.
        %   Null nominal: every entry gets null_nominal_key = 'all'; the label is
        %     blanked and NominalIsNull is set.
        %   Numeric nominal: every entry gets nominal_key, the snapped value
        %     printed with %.10g ('NaN' when missing); NominalIsNumeric is set.
        %   Null ordinal (char nominal): every entry gets null_ordinal_key = 1;
        %     the label is blanked and OrdinalIsNull is set.
        %
        % NominalSourceField records the nominal field as supplied, before any
        % rewrite, so the cell header classifier can recognize an axis field
        % that normalization renamed (a numeric nominal becomes nominal_key).
        %
        % The fields are added to the local copy only. A datasets array encodes
        % its axes in its shape, so it returns with all flags false.
        spec = axisSpec;
        spec.NominalIsNull = false;
        spec.OrdinalIsNull = false;
        spec.NominalIsNumeric = false;
        spec.NominalSourceField = char(axisSpec.Nominal);

        nominalNull = strcmpi(spec.Nominal, 'none');
        ordinalNull = strcmpi(spec.Ordinal, 'none');
        if nominalNull && ordinalNull
            error('generateOverviewPDF:bothAxesNull', ...
                'Nominal and Ordinal cannot both be ''none''; one axis must name a field.');
        end

        if isstruct(data) && isscalar(data) && isfield(data, 'composite')
            entries = data.composite;
            wrapped = true;
        elseif isstruct(data) && isfield(data, 'Measurements')
            entries = data;
            wrapped = false;
        else
            return;
        end
        if isempty(entries)
            return;
        end

        if ordinalNull && isfield(entries, spec.Nominal) && ...
                isnumeric(entries(1).(spec.Nominal))
            spec.Ordinal = spec.Nominal;
            spec.OrdinalLabel = spec.NominalLabel;
            spec.Nominal = 'none';
            nominalNull = true;
            ordinalNull = false;
        end

        if nominalNull
            [entries.null_nominal_key] = deal('all');
            spec.Nominal = 'null_nominal_key';
            spec.NominalLabel = '';
            spec.NominalIsNull = true;
        elseif isfield(entries, spec.Nominal) && isnumeric(entries(1).(spec.Nominal))
            numericField = spec.Nominal;
            for i = 1:numel(entries)
                v = entries(i).(numericField);
                if isnumeric(v) && isscalar(v) && isfinite(v)
                    entries(i).nominal_key = sprintf('%.10g', round(double(v), 10, 'significant'));
                else
                    entries(i).nominal_key = 'NaN';
                end
            end
            spec.Nominal = 'nominal_key';
            spec.NominalIsNumeric = true;
        end

        if ordinalNull
            [entries.null_ordinal_key] = deal(1);
            spec.Ordinal = 'null_ordinal_key';
            spec.OrdinalLabel = '';
            spec.OrdinalIsNull = true;
        end

        if wrapped
            data.composite = entries;
        else
            data = entries;
        end
    end
    % ============================================================
    % CLASSIFICATION (FORMAT + MODE)
    % ============================================================
    function [mode, format] = classifyInput(data, axisSpec)
        % SUB-CONTROLLER: Recover the input format from its shape, then the layout
        % mode. A datasets array is always selected. A composite is routed by the
        % maximum number of eligible plates at any (nominal, ordinal) index: more
        % than one means an uncollapsed third dimension and runs full. A non-default
        % axisSpec that routes to full is rejected, because full mode assumes
        % genotype/passage.
        if ~isstruct(data)
            error('generateOverviewPDF:unrecognizedInput', ...
                'Input must be a struct or struct array.');
        end

        format = detectFormat(data);

        switch format
            case 'datasets'
                mode = 'selected';
                if ~isDefaultAxis(axisSpec)
                    warning('generateOverviewPDF:axisSpecIgnored', ...
                        ['A datasets array encodes its axes in its shape; the ' ...
                         'supplied axisSpec is ignored (genotype/passage used).']);
                end
                if ~isempty(axisSpec.Block)
                    warning('generateOverviewPDF:blockIgnored', ...
                        'A datasets array holds one block; the Block axis "%s" is ignored.', ...
                        axisSpec.Block);
                end
            case 'composite'
                composite = extractComposite(data);
                validateAxisFields(composite, axisSpec);
                eligibleMask = buildEligibleMask(composite);
                if maxPlatesPerIndex(composite, eligibleMask, axisSpec) > 1
                    mode = 'full';
                else
                    mode = 'selected';
                end
                if strcmp(mode, 'full') && ~isempty(axisSpec.Block)
                    error('generateOverviewPDF:blockFull', ...
                        ['More than one plate shares a (block, nominal, ordinal) ' ...
                         'index, which routes to the full pipeline. The Block axis ' ...
                         'is supported in selected mode only.']);
                end
                if strcmp(mode, 'full') && ~isDefaultAxis(axisSpec)
                    error('generateOverviewPDF:customAxisFull', ...
                        ['The supplied axisSpec produced more than one plate per ' ...
                         '(nominal, ordinal) index, which routes to the full ' ...
                         'pipeline. Full mode is supported only under default ' ...
                         'genotype/passage axes. Choose axes that yield one plate ' ...
                         'per index (so the data runs selected), or run with ' ...
                         'default axes.']);
                end
        end

        % === MODELS ===

        function format = detectFormat(data)
            % MODEL: Recover the input format structurally. (TERMINAL)
            %   composite: a scalar struct carrying a .composite field
            %              (Part3CompleteData / Part2CompleteData), or a bare
            %              composite struct array whose entries carry Measurements.
            %   datasets:  a passage struct array with no top-level Measurements
            %              field and at least one field holding a non-empty entry
            %              struct (DatasetCreator output).
            if isscalar(data) && isfield(data, 'composite')
                format = 'composite';
                return;
            end
            if isfield(data, 'Measurements')
                format = 'composite';
                return;
            end
            if hasEntryValuedField(data)
                format = 'datasets';
                return;
            end
            error('generateOverviewPDF:unrecognizedInput', ...
                ['Input is neither a composite (a .composite-bearing struct or a ' ...
                 'struct array with Measurements) nor a datasets array (a passage ' ...
                 'struct array with genotype fields holding entries).']);
        end

        function tf = hasEntryValuedField(dataset)
            % MODEL: True if any field, anywhere in the array, holds a non-empty
            % struct entry (TERMINAL)
            tf = false;
            fns = fieldnames(dataset);
            for f = 1:numel(fns)
                for pidx = 1:numel(dataset)
                    val = dataset(pidx).(fns{f});
                    if isstruct(val) && ~isempty(val)
                        tf = true;
                        return;
                    end
                end
            end
        end

        function validateAxisFields(composite, axisSpec)
            % MODEL: The nominal/ordinal fields must exist on the entries; nominal
            % must be char/string (used as map key, color key, and label); ordinal
            % must be a numeric scalar (grouped and sorted). Null and numeric axes
            % arrive here already rewritten by normalizeAxes into that shape. (TERMINAL)
            if isempty(composite)
                error('generateOverviewPDF:emptyComposite', ...
                    'Composite is empty; nothing to render.');
            end
            nf = axisSpec.Nominal;
            of = axisSpec.Ordinal;
            if ~isfield(composite, nf)
                error('generateOverviewPDF:missingNominalField', ...
                    'Nominal field "%s" is not present on the composite entries.', nf);
            end
            if ~isfield(composite, of)
                error('generateOverviewPDF:missingOrdinalField', ...
                    'Ordinal field "%s" is not present on the composite entries.', of);
            end
            if ~isempty(axisSpec.Block) && ~isfield(composite, axisSpec.Block)
                error('generateOverviewPDF:missingBlockField', ...
                    'Block field "%s" is not present on the composite entries.', axisSpec.Block);
            end
            sampleNom = composite(1).(nf);
            if ~(ischar(sampleNom) || isstring(sampleNom))
                error('generateOverviewPDF:nonCharNominal', ...
                    'Nominal field "%s" must be char or string; got %s.', ...
                    nf, class(sampleNom));
            end
            sampleOrd = composite(1).(of);
            if ~(isnumeric(sampleOrd) && isscalar(sampleOrd))
                error('generateOverviewPDF:nonNumericOrdinal', ...
                    'Ordinal field "%s" must be a numeric scalar; got %s.', ...
                    of, class(sampleOrd));
            end
        end

        function tf = isDefaultAxis(axisSpec)
            % MODEL: True when the axes are the default genotype/passage (TERMINAL)
            tf = strcmp(axisSpec.Nominal, 'genotype') && ...
                 strcmp(axisSpec.Ordinal, 'passage');
        end

        function n = maxPlatesPerIndex(composite, eligibleMask, axisSpec)
            % MODEL: Maximum count of eligible plates sharing one (block, nominal,
            % ordinal) index; the block part is empty without a Block axis.
            % Ordinal values are snapped to 10 significant digits before keying
            % so float identity does not split a logical index. Returns 0 when no
            % eligible plate is present. (TERMINAL)
            nf = axisSpec.Nominal;
            of = axisSpec.Ordinal;
            bf = axisSpec.Block;
            keys = {};
            counts = [];
            n = 0;
            for i = 1:numel(composite)
                if ~eligibleMask(i)
                    continue;
                end
                if isempty(bf)
                    blockVal = '';
                elseif isnumeric(composite(i).(bf))
                    blockVal = sprintf('%.10g', composite(i).(bf));
                else
                    blockVal = char(composite(i).(bf));
                end
                nomVal = char(composite(i).(nf));
                ordVal = round(double(composite(i).(of)), 10, 'significant');
                key = sprintf('%s|%s|%.10g', blockVal, nomVal, ordVal);
                hit = strcmp(keys, key);
                if any(hit)
                    counts(hit) = counts(hit) + 1; %#ok<AGROW>
                else
                    keys{end+1} = key;     %#ok<AGROW>
                    counts(end+1) = 1;     %#ok<AGROW>
                end
            end
            if ~isempty(counts)
                n = max(counts);
            end
        end
    end


    % ============================================================
    % CONFIG
    % ============================================================
    function config = getOverviewConfig(mode, format, data, axisSpec)
        % MODEL: Shared constants, the two-tier flag registry, the cell header
        % field registry, axis facts derived from the data, the cell header field
        % classes derived from the data, and a mode-specific layout block. The
        % selected path reads nominal_* / ordinal_* fields; the full path reads the
        % genotype_order / passages / genotype_labels aliases, which equal the
        % nominal/ordinal facts (full mode runs only under default axes, where
        % nominal is genotype and ordinal is passage). Colors come from
        % QC.getGenotypeColors keyed on the nominal values, except under a null or
        % numeric nominal, whose keys are not genotypes and take one neutral color.
        % (TERMINAL except for the facts and cell field sub-controllers)

        facts = deriveAxisFacts(format, data, axisSpec);
        facts.nominal_labels = applyNominalLabelOverrides(facts.nominal_labels, axisSpec.NominalLabels);
        config.nominal_order  = applyNominalOrder(facts.nominal_order, axisSpec, facts.nominal_labels);
        config.ordinal_values = facts.ordinal_values;
        config.nominal_labels = facts.nominal_labels;

        switch format
            case 'datasets'
                config.nominal_field      = 'genotype';
                config.ordinal_field      = 'passage';
                config.nominal_axis_label = 'Genotype';
                config.ordinal_axis_label = 'Passage';
                config.nominal_is_null    = false;
                config.ordinal_is_null    = false;
                config.nominal_is_numeric = false;
                config.axis_fields        = {'genotype', 'passage'};
            case 'composite'
                config.nominal_field      = axisSpec.Nominal;
                config.ordinal_field      = axisSpec.Ordinal;
                config.nominal_axis_label = axisSpec.NominalLabel;
                config.ordinal_axis_label = axisSpec.OrdinalLabel;
                config.nominal_is_null    = axisSpec.NominalIsNull;
                config.ordinal_is_null    = axisSpec.OrdinalIsNull;
                config.nominal_is_numeric = axisSpec.NominalIsNumeric;
                config.axis_fields        = unique({axisSpec.Nominal, ...
                    axisSpec.Ordinal, axisSpec.NominalSourceField});
        end

        if config.nominal_is_null || config.nominal_is_numeric
            neutralColor = [0.25 0.40 0.65];
            config.colors = containers.Map(config.nominal_order, ...
                repmat({neutralColor}, 1, numel(config.nominal_order)));
        else
            config.colors = QC.getGenotypeColors(config.nominal_order);
        end

        % Aliases consumed by the full pipeline (default axes only reach full).
        config.genotype_order  = config.nominal_order;
        config.passages        = config.ordinal_values;
        config.genotype_labels = config.nominal_labels;

        % Block title for page titles; the main controller sets it per block
        config.block_title = '';

        % Typeface applied to every figure through Default*FontName properties at
        % figure creation, so axes, text, and annotation objects inherit it.
        config.font_name = 'Times New Roman';

        config.n_bins = 30;
        config.x_pad_log = 0.15;
        config.y_headroom_factor = 1.5;
        config.hist_alpha_solo = 0.6;
        config.hist_alpha_backing = 0.15;
        config.lmm_component_colors = {[0.20 0.65 0.30], ...   % rank 1: green
                                       [0.95 0.55 0.10], ...   % rank 2: orange
                                       [0.85 0.20 0.20]};      % rank 3+: red
        config.fig_position = [50 50 900 1200];
        config.cell_pad_x = 0.04;
        config.cell_pad_y = 0.12;

        % Selected-mode pagination caps: at most max_cols nominal columns and
        % max_rows_selected ordinal rows per page (4 x 5 = 20 cells).
        config.max_cols = 4;
        config.max_rows_selected = 5;

        % --- Box plot y-axis ticks (data, not logic) ---
        % The radius range spans well under one decade, so the log scale's own
        % decade ticks would label a single value. These are requested ticks:
        % applyLogRadiusTicks keeps only the ones inside the current limits, which
        % stay tied to the distribution pages instead of expanding to fit a tick.
        config.y_ticks_um = [250 500 750 1000 1500];

        % --- Box plot summary band (colony count + median radius per box) ---
        config.box_stats_row_h = 0.022;    % height of one number row, normalized
        config.box_stats_gap = 0.008;      % gap between band bottom and axes top
        config.box_stats_band_h = 2 * config.box_stats_row_h + config.box_stats_gap;
        config.box_stats_font = 9;
        config.box_stats_rotation = 0;     % set to 90 if columns crowd
        config.box_stats_empty_mark = char(8211);   % en dash for a plate with no colonies
        config.box_stats_label_offset = 0.25;  % row labels, column widths left of the axis line

        % Floor for every label on a box plot page other than the summary rows,
        % which carry their own smaller size above.
        config.box_font = 14;
        config.box_axis_name_font = 16;        % x and y axis names on box plot pages
        config.box_passage_label_drop = 0.03;  % passage labels, normalized below the axes
        config.box_axis_label_drop = 0.028;    % ordinal axis name, normalized below the passage labels

        % --- Two-tier plate-flag registry (data, not logic) ---
        config.flagMarks = containers.Map('KeyType', 'char', 'ValueType', 'any');
        config.flagMarks('LargeSourced') = struct( ...
            'symbol', char(8224), ...                 % dagger
            'label',  'Large-sourced plate', ...
            'color',  [0 0 0], ...
            'tier',   1);
        config.flagMarkDefault = struct( ...
            'symbol', char(8224), ...                 % dagger
            'label',  'Non-standard enrichment', ...
            'color',  [0 0 0], ...
            'tier',   1);
        config.flag140 = struct( ...
            'symbol', char(8225), ...                 % double dagger (Times carries no star)
            'label',  '140 mm plate', ...
            'color',  [0 0 0], ...
            'tier',   2, ...
            'key',    'Plate140mm');
        config.flag_clearance_frac = 0.025; % box-top clearance, fraction of log-span
        config.flag_gap_frac = 0.06;        % tier separation, fraction of log-span
        config.flag_min_gap_frac = 0.035;   % compressed-gap floor, fraction of log-span
        config.flag_clamp_factor = 0.97;    % ceiling as fraction of x extent top

        % --- Cell stat field registry (data, not logic) ---
        % Candidate fields for the stat block under each cell, in print order.
        %   key:         unique id, listed in config.cell_fields when per-cell
        %   label:       row name printed in the left margin
        %   foot_label:  name used when the field moves to the footnote
        %   paths:       one field path per value, each a cell of nested field
        %                names; um_range reads two paths (q1, q3). The path
        %                {'plate_diameter_mm'} takes the diameter resolved from
        %                either entry shape.
        %   kind:        format: count, percent, um, um_range, mm, or text
        %   page:        'image' or 'distribution', the page type it prints on
        %   always_cell: print in every cell regardless of its values
        % Adding a field means adding one entry here; the classifier decides
        % whether it prints per cell, in the footnote, or not at all.
        config.cell_field_registry = struct( ...
            'key',         {'colony_count', 'capture_ratio', 'replicate', 'hce', ...
                            'plate_diameter_mm', 'median_radius', 'iqr_radius'}, ...
            'label',       {'Colonies', 'Capture Ratio', 'Rep', 'HCE', ...
                            'Plate', 'Median r', 'IQR'}, ...
            'foot_label',  {'Colonies', 'Colony/growth', 'Replicate', 'HCE', ...
                            'Plate diameter', 'Median radius', 'IQR'}, ...
            'paths',       {{{'colony_count'}}, ...
                            {{'biomass_occupation', 'CaptureRatio'}}, ...
                            {{'replicate'}}, ...
                            {{'hce'}}, ...
                            {{'plate_diameter_mm'}}, ...
                            {{'summary_stats', 'median'}}, ...
                            {{'summary_stats', 'q1'}, {'summary_stats', 'q3'}}}, ...
            'kind',        {'count', 'percent', 'text', 'text', ...
                            'mm', 'um', 'um_range'}, ...
            'page',        {'image', 'image', 'image', 'image', ...
                            'image', 'distribution', 'distribution'}, ...
            'always_cell', {true, false, false, false, false, false, false});
        config.missing_tokens = {'', 'n/a', 'na', 'nan', 'none'};  % compared case-insensitively
        config.partial_suffix = ' (where recorded)';

        % --- Stat block layout, in figure pixels (converted per axes) ---
        config.stat_font = 12;
        config.stat_line_px = 19;          % one 12 pt line with leading
        config.stat_label_color = [0.45 0.45 0.45];
        config.stat_label_gap_px = 8;      % row names, left of the first column
        config.stat_gap_px = struct( ...   % block top below the axes bottom
            'image', 4, ...                % photos carry no tick labels
            'distribution', 16);           % clears the x tick labels
        config.row_header_gap_px = struct( ... % rotated row header, left of the axes
            'image', 6, ...
            'distribution', 30);           % clears the y tick labels
        config.row_header_font = 12;

        % --- Photo cell spacing ---
        % Grid and full-mode photo cells carry no title, so they take no top
        % padding; the only vertical gap is image_row_gap_px, between one row's
        % stat block and the next row's photo. The selected grid's bottom edge
        % sits grid_bottom_gap above the page footnote, so the cells take every
        % row of height the footnote leaves.
        config.image_row_gap_px = 10;
        config.grid_bottom_gap = 0.008;

        % --- Page footnote (block-wide cell fields), lower right ---
        config.footnote_x = 0.58;
        config.footnote_w = 0.41;
        config.footnote_line_h = 0.018;
        config.footnote_font = 10;

        switch mode
            case 'selected'
                config.grid_x = 0.12;       % left margin for row headers and row names
                config.grid_y = 0.1;        % bottom margin of box plot pages; grid pages run to the footnote
                config.grid_w = 0.86;       % grid width
                config.grid_h = 0.85;       % grid height
                config.title_y = 0.965;     % page title bottom on box plot pages
                config.page_top_margin = 0.008;   % grid/reflow pages: space above the first header line
                config.title_band_h = 0.03;       % grid/reflow pages: page title line, when the title is non-empty
                config.header_band_h = 0.028;     % grid/reflow pages: column headers or reflow nominal label
                config.header_grid_gap = 0.006;   % grid/reflow pages: gap between the last header line and the grid
                config.reflow_title_px = 16;      % reflow photo cells: room for the 8 pt ordinal title above the photo
                config.box_axes_y_offset = 0.03;  % box axes bottom above grid_y
                config.box_axes_h_shrink = 0.06;  % box axes height taken off grid_h
                config.footnote_y = 0.01;   % bottom of the footnote stack
            case 'full'
                config.col_count = 4;
                config.max_rows = 4;
                config.standard_box_alpha = 0.70;
                config.protocol_mod_box_alpha = 0.35;
                config.grid_x = 0.10;
                config.grid_y = 0.04;
                config.grid_w = 0.88;
                config.grid_h = 0.82;
                config.title_y = 0.955;
                config.subtitle_y = 0.91;
                config.subgroup_label_x = 0.005;
                config.subgroup_label_width = 0.085;
                config.box_axes_y_offset = 0.04;
                config.box_axes_h_shrink = 0.06;
                config.footnote_y = 0.004;  % below the grid's bottom cell padding
        end

        [config.cell_fields, config.footnote_lines] = classifyCellFields(format, data, config);

        % === MODEL ===

        function labels = applyNominalLabelOverrides(labels, labelPairs)
            % MODEL: Replace display labels for the nominal keys the caller names.
            % Keys match in normalized form (lowercase, alphanumerics only), the
            % same comparison NominalOrder uses, so 'double' and 'Double' both hit.
            % A pair naming a key absent from the data changes nothing. (TERMINAL)
            if isempty(labelPairs)
                return;
            end
            normalizeKey = @(s) regexprep(lower(char(s)), '[^a-z0-9]', '');
            dataKeys = keys(labels);
            for p = 1:size(labelPairs, 1)
                target = normalizeKey(labelPairs{p, 1});
                for k = 1:numel(dataKeys)
                    if strcmp(normalizeKey(dataKeys{k}), target)
                        labels(dataKeys{k}) = char(labelPairs{p, 2});
                    end
                end
            end
        end

        % === SUB-CONTROLLERS ===

        function facts = deriveAxisFacts(format, data, axisSpec)
            % SUB-CONTROLLER: Derive nominal order, display labels, and ordinal
            % values from the input, branching on the format each path supplies.
            switch format
                case 'datasets'
                    facts = deriveFromSelectedDataset(data);
                case 'composite'
                    facts = deriveFromComposite(extractComposite(data), axisSpec);
            end

            function facts = deriveFromSelectedDataset(dataset)
                % MODEL: Nominal (genotype) order and labels from the genotype
                % fields of the passage struct array; the canonical key per field
                % is read from an entry's genotype field so collectDatasetEntries'
                % hyphen-to-underscore mapping lands back on the actual field name.
                % Ordinal values are the array positions, matching the index-based
                % access in collectDatasetEntries. (TERMINAL)
                fns = fieldnames(dataset);
                orderKeys = {};
                labels = {};
                for f = 1:numel(fns)
                    field = fns{f};
                    entry = firstNonEmptyAcrossPassages(dataset, field);
                    if isempty(entry)
                        continue;
                    end
                    orderKeys{end+1} = entry.genotype;                 %#ok<AGROW>
                    labels{end+1}    = resolveLabel(entry, 'genotype'); %#ok<AGROW>
                end
                facts.nominal_order  = orderKeys;
                facts.nominal_labels = containers.Map(orderKeys, labels);
                facts.ordinal_values = 1:numel(dataset);

                function entry = firstNonEmptyAcrossPassages(dataset, field)
                    % MODEL: First non-empty entry in a genotype column (TERMINAL)
                    entry = [];
                    for pidx = 1:numel(dataset)
                        val = dataset(pidx).(field);
                        if ~isempty(val)
                            entry = val;
                            return;
                        end
                    end
                end
            end

            function facts = deriveFromComposite(composite, axisSpec)
                % MODEL: Nominal order and labels from the nominal field values in
                % first-appearance order; ordinal values are the distinct ordinal
                % field values, snapped to 10 significant digits and sorted
                % ascending so they serve as match targets downstream. (TERMINAL)
                nomField = axisSpec.Nominal;
                ordField = axisSpec.Ordinal;

                nomVals = {composite.(nomField)};
                [orderKeys, firstIdx] = unique(nomVals, 'stable');
                orderKeys = orderKeys(:)';
                firstIdx  = firstIdx(:)';
                labels = cell(1, numel(orderKeys));
                for k = 1:numel(orderKeys)
                    labels{k} = resolveLabel(composite(firstIdx(k)), nomField);
                end
                facts.nominal_order  = orderKeys;
                facts.nominal_labels = containers.Map(orderKeys, labels);

                ordRaw = double([composite.(ordField)]);
                ordSnapped = round(ordRaw, 10, 'significant');
                ordVals = unique(ordSnapped);
                facts.ordinal_values = sort(ordVals(:)');
            end

            function lbl = resolveLabel(entry, nomField)
                % MODEL: Prefer the registry display field (<field>_display), fall
                % back to the machine value when no display field is present (TERMINAL)
                dispField = [nomField '_display'];
                if isfield(entry, dispField) && ~isempty(entry.(dispField))
                    lbl = char(entry.(dispField));
                else
                    lbl = char(entry.(nomField));
                end
            end
        end

        function [cellFields, footnoteLines] = classifyCellFields(format, data, config)
            % SUB-CONTROLLER: Sort every registry field into omitted, footnote, or
            % per-cell over the block's entries (eligible plates for a composite,
            % every entry for a datasets grid). Each entry's field is reduced to
            % display text first, with missing values as '', so the class rules
            % compare text. cellFields holds the per-cell keys by page type
            % (.image, .distribution); footnoteLines holds the formatted footnote
            % strings by page type plus .all for the box plot pages, each in
            % registry order.
            switch format
                case 'datasets'
                    headerEntries = gatherDatasetEntries(data);
                case 'composite'
                    composite = extractComposite(data);
                    eligibleMask = buildEligibleMask(composite);
                    headerEntries = num2cell(composite(eligibleMask));
            end
            textTable = readHeaderTexts(headerEntries, config);
            [cellFields, footnoteLines] = assignFieldClasses(textTable, config);

            function entries = gatherDatasetEntries(dataset)
                % MODEL: Every non-empty entry struct in a DatasetCreator passage
                % array, as a cell array (TERMINAL)
                entries = {};
                fns = fieldnames(dataset);
                for pidx = 1:numel(dataset)
                    for f = 1:numel(fns)
                        val = dataset(pidx).(fns{f});
                        if isstruct(val) && ~isempty(val)
                            entries{end+1} = val; %#ok<AGROW>
                        end
                    end
                end
            end

            function textTable = readHeaderTexts(entries, config)
                % SUB-CONTROLLER: One row per entry, one column per registry
                % field, each cell the field's display text ('' when missing).
                % Plate diameter is resolved from whichever shape the entry uses.
                registry = config.cell_field_registry;
                textTable = cell(numel(entries), numel(registry));
                for e = 1:numel(entries)
                    diameter = resolvePlateDiameterMm(entries{e});
                    for k = 1:numel(registry)
                        textTable{e, k} = cellFieldText(entries{e}, registry(k), ...
                            diameter, config.missing_tokens);
                    end
                end
            end

            function [cellFields, footnoteLines] = assignFieldClasses(textTable, config)
                % MODEL: Apply the class rules to each registry column and file
                % the result under the field's page type. An always_cell field
                % is per-cell. A single-name field that is also an axis is
                % omitted. A column with no text is omitted. A column with one
                % distinct text becomes a footnote line, suffixed when some
                % entries lack it; footnote lines also collect in .all for the
                % box plot pages. A column with more than one distinct text is
                % per-cell. (TERMINAL)
                registry = config.cell_field_registry;
                cellFields = struct('image', {{}}, 'distribution', {{}});
                footnoteLines = struct('image', {{}}, 'distribution', {{}}, 'all', {{}});
                for k = 1:numel(registry)
                    field = registry(k);
                    page = field.page;
                    if field.always_cell
                        cellFields.(page){end+1} = field.key;
                        continue;
                    end
                    isSingleName = isscalar(field.paths) && isscalar(field.paths{1});
                    if isSingleName && any(strcmp(config.axis_fields, field.paths{1}{1}))
                        continue;
                    end
                    column = textTable(:, k);
                    present = column(~cellfun(@isempty, column));
                    if isempty(present)
                        continue;
                    end
                    distinct = unique(present);
                    if numel(distinct) > 1
                        cellFields.(page){end+1} = field.key;
                    else
                        footLine = sprintf('%s: %s', field.foot_label, distinct{1});
                        if numel(present) < numel(column)
                            footLine = [footLine config.partial_suffix]; %#ok<AGROW>
                        end
                        footnoteLines.(page){end+1} = footLine;
                        footnoteLines.all{end+1} = footLine;
                    end
                end
            end
        end
    end


    % ============================================================
    % SELECTED PIPELINE
    % ============================================================

    function selectedLastPage = runSelectedPipeline(blocks, format, blockConfigs, outputPath, pageOffset)
        % SUB-CONTROLLER: Build one ordinal-by-nominal cell grid per block from
        % whichever format was supplied, compute one scaling over every block so
        % all pages share axes, and render the paginated grid pages plus box plot
        % pages. A dataset without a Block axis arrives as one block. Pages number
        % from pageOffset + 1, after the fidelity page; the last page number is
        % returned so appended figures continue the count.
        nBlocks = numel(blocks);
        blockEntries = cell(1, nBlocks);
        pooledEntries = {};
        for blockNum = 1:nBlocks
            collectConfig = blockConfigs{blockNum};
            switch format
                case 'datasets'
                    blockGrid = collectDatasetEntries(blocks(blockNum).data, collectConfig);
                case 'composite'
                    blockComposite = extractComposite(blocks(blockNum).data);
                    blockMask = buildEligibleMask(blockComposite);
                    blockGrid = collectCompositeEntries(blockComposite, blockMask, collectConfig);
            end
            blockEntries{blockNum} = blockGrid;
            blockValid = blockGrid(~cellfun(@isempty, blockGrid));
            pooledEntries = [pooledEntries, blockValid(:)']; %#ok<AGROW>
        end
        scaling = computeGlobalScaling(pooledEntries, blockConfigs{1});
        selectedLastPage = renderSelectedPages(blockEntries, scaling, blockConfigs, outputPath, pageOffset);

        function entries = collectDatasetEntries(dataset, config)
            % MODEL: Reshape a DatasetCreator grid into an ordinal-by-nominal cell
            % array indexed (pi, gi). Nominal fields follow DatasetCreator's
            % field naming (hyphens to underscores); ordinal values are array
            % positions. Empty cells stay [] and route to the missing-cell
            % renderer downstream. (TERMINAL)
            nOrd = numel(config.ordinal_values);
            nNom = numel(config.nominal_order);
            entries = cell(nOrd, nNom);
            for pi = 1:nOrd
                position = config.ordinal_values(pi);
                for gi = 1:nNom
                    field = strrep(config.nominal_order{gi}, '-', '_');
                    entries{pi, gi} = dataset(position).(field);
                end
            end
        end

        function entries = collectCompositeEntries(composite, eligibleMask, config)
            % MODEL: Group eligible composite entries into the ordinal-by-nominal
            % cell grid indexed (pi, gi) by matching the nominal field (string) and
            % the ordinal field (numeric, snapped to 10 significant digits) against
            % the axis values. Selected routing guarantees at most one eligible
            % entry per index; if more are present the first is taken. Empty
            % indices stay [] and route to the missing-cell renderer
            % downstream. (TERMINAL)
            nomField = config.nominal_field;
            ordField = config.ordinal_field;
            nOrd = numel(config.ordinal_values);
            nNom = numel(config.nominal_order);
            entries = cell(nOrd, nNom);
            for pi = 1:nOrd
                ordTarget = config.ordinal_values(pi);
                for gi = 1:nNom
                    nomTarget = config.nominal_order{gi};
                    chosen = [];
                    for i = 1:numel(composite)
                        if ~eligibleMask(i)
                            continue;
                        end
                        nomVal = char(composite(i).(nomField));
                        ordVal = round(double(composite(i).(ordField)), 10, 'significant');
                        if strcmp(nomVal, nomTarget) && ordVal == ordTarget
                            chosen = composite(i);
                            break;
                        end
                    end
                    entries{pi, gi} = chosen;
                end
            end
        end

        function pageNum = renderSelectedPages(blockEntries, scaling, blockConfigs, outputPath, pageOffset)
            % SUB-CONTROLLER: Tile each block's grid into pages, one set per figure
            % type with the blocks in order inside each type, then render one box
            % plot page per nominal chunk of each block. Each block brings its own
            % config (nominal order, ordinal values, labels, colors, block title,
            % cell header fields), so every page builder below reads the config of
            % the block it draws. Two grid layouts are supported:
            %
            %   'grid'   (default): ordinal down, nominal across; both axes
            %            paginate independently (max_rows_selected rows, max_cols
            %            columns per page).
            %
            %   'reflow' (nominal-degenerate): a single nominal value with more
            %            ordinal values than fit one column. Position no longer
            %            needs to encode the nominal, so the ordinal sequence wraps
            %            column-major into the cell grid, reclaiming the
            %            otherwise-empty nominal direction. The lone nominal value is
            %            drawn once as a colored label below the title (skipped
            %            under a null nominal), and each cell carries its ordinal
            %            value as the first line of its sub-header.
            %
            % planSelectedLayout decides the kind and always returns the nominal
            % chunks the box plot page consumes, so the box plot path is identical
            % for both kinds (a degenerate nominal collapses to one group spanning
            % the axis, which renderSelectedBoxPlotPage already handles).
            %
            % Four helpers (drawSelectedPageTitle, computeSelectedHeaderLayout,
            % computeSelectedCellPosition, renderMissingCell) are shared by the
            % grid, reflow, and box builders and live in the SHARED FUNCTIONS
            % block below.
            nBlocks = numel(blockConfigs);
            blockLayouts = cell(1, nBlocks);
            for bi = 1:nBlocks
                blockLayouts{bi} = planSelectedLayout(blockConfigs{bi});
            end
            pageSpecs = defineSelectedPageSpecs();

            % The main controller cleared the file and may have written page 1.
            % Figure type is the outer loop, so each type's pages run block by
            % block (Figure 2, then Figure 8) before the next type begins.
            pageNum = pageOffset;
            for s = 1:length(pageSpecs)
                for bi = 1:nBlocks
                    pageLayout = blockLayouts{bi};
                    pageConfig = blockConfigs{bi};
                    pageEntries = blockEntries{bi};
                    switch pageLayout.kind
                        case 'grid'
                            for nc = 1:numel(pageLayout.nomChunks)
                                for oc = 1:numel(pageLayout.ordChunks)
                                    pagePlan = struct( ...
                                        'nomIdx',      pageLayout.nomChunks{nc}, ...
                                        'ordIdx',      pageLayout.ordChunks{oc}, ...
                                        'nColsLayout', pageLayout.nColsLayout, ...
                                        'nRowsLayout', pageLayout.nRowsLayout, ...
                                        'nNomChunks',  numel(pageLayout.nomChunks), ...
                                        'nOrdChunks',  numel(pageLayout.ordChunks));
                                    fig = buildSelectedGridPage(pageSpecs(s), pagePlan, pageEntries, scaling, pageConfig);
                                    pageNum = pageNum + 1;
                                    exportPageToPDF(fig, outputPath, pageNum);
                                    close(fig);
                                end
                            end
                        case 'reflow'
                            for sc = 1:numel(pageLayout.seqChunks)
                                pagePlan = struct( ...
                                    'seqIdx',      pageLayout.seqChunks{sc}, ...
                                    'nColsLayout', pageLayout.nColsLayout, ...
                                    'nRowsLayout', pageLayout.nRowsLayout, ...
                                    'nSeqChunks',  numel(pageLayout.seqChunks));
                                fig = buildSelectedReflowPage(pageSpecs(s), pagePlan, pageEntries, scaling, pageConfig);
                                pageNum = pageNum + 1;
                                exportPageToPDF(fig, outputPath, pageNum);
                                close(fig);
                            end
                    end
                end
            end

            % One box plot page per nominal chunk, block by block
            for bi = 1:nBlocks
                pageLayout = blockLayouts{bi};
                pageConfig = blockConfigs{bi};
                pageEntries = blockEntries{bi};
                for nc = 1:numel(pageLayout.nomChunks)
                    pagePlan = struct( ...
                        'nomIdx',     pageLayout.nomChunks{nc}, ...
                        'nNomChunks', numel(pageLayout.nomChunks));
                    fig = renderSelectedBoxPlotPage(pagePlan, pageEntries, scaling, pageConfig);
                    pageNum = pageNum + 1;
                    exportPageToPDF(fig, outputPath, pageNum);
                    close(fig);
                end
            end

            % ====================================================================
            % LAYOUT PLAN
            % ====================================================================
            function layout = planSelectedLayout(config)
                % MODEL: Decide the grid layout and the pagination chunks. The
                % nominal axis is always chunked into <=max_cols groups for the box
                % plot page (returned as layout.nomChunks regardless of kind). The
                % grid figure pages use one of two kinds:
                %
                %   'grid'   (default): ordinal split into <=max_rows_selected
                %            chunks, nominal into <=max_cols chunks; the two
                %            paginate independently. When an axis fits one chunk
                %            its cells are sized to the actual count; when it chunks
                %            they are sized to the cap so every page in the run is
                %            uniform.
                %
                %   'reflow' (single nominal value with more ordinal values than
                %            fit one column): the ordinal sequence wraps
                %            column-major into a grid of <=max_cols columns by
                %            max_rows_selected rows. The sequence is split into
                %            page-sized chunks of max_cols*max_rows_selected; a
                %            single chunk sizes columns to the actual fill, multiple
                %            chunks size to max_cols. Reflow is gated to
                %            nOrd > max_rows_selected, the same threshold above
                %            which 'grid' would paginate the lone column, so small
                %            sets are unaffected. (TERMINAL)
                nNom = numel(config.nominal_order);
                nOrd = numel(config.ordinal_values);

                layout.nomChunks = chunkIndices(nNom, config.max_cols);

                reflow = (nNom == 1) && (nOrd > config.max_rows_selected);

                if reflow
                    layout.kind = 'reflow';
                    layout.nRowsLayout = config.max_rows_selected;
                    pageCap = config.max_cols * config.max_rows_selected;
                    layout.seqChunks = chunkIndices(nOrd, pageCap);
                    if numel(layout.seqChunks) > 1
                        layout.nColsLayout = config.max_cols;
                    else
                        layout.nColsLayout = max(ceil(nOrd / config.max_rows_selected), 1);
                    end
                else
                    layout.kind = 'grid';
                    layout.ordChunks = chunkIndices(nOrd, config.max_rows_selected);
                    if numel(layout.nomChunks) > 1
                        layout.nColsLayout = config.max_cols;
                    else
                        layout.nColsLayout = max(nNom, 1);
                    end
                    if numel(layout.ordChunks) > 1
                        layout.nRowsLayout = config.max_rows_selected;
                    else
                        layout.nRowsLayout = max(nOrd, 1);
                    end
                end

                function chunks = chunkIndices(n, capSize)
                    chunks = {};
                    startI = 1;
                    while startI <= n
                        endI = min(startI + capSize - 1, n);
                        chunks{end+1} = startI:endI; %#ok<AGROW>
                        startI = endI + 1;
                    end
                    if isempty(chunks)
                        chunks = {[]};
                    end
                end
            end

            % ====================================================================
            % PAGE SPECS
            % ====================================================================
            function specs = defineSelectedPageSpecs()
                % MODEL: Title, cell-renderer handle, per-page padding, axis-label
                % flag, and a square_cells flag. Header positions are derived per
                % page by computeSelectedHeaderLayout. square_cells marks the image pages, whose
                % cells hold a square plate photo; on a reflow page this triggers
                % the square-pack layout in computeSelectedCellPosition so the
                % photos do not letterbox. stat_page names the registry page type
                % whose fields fill the stat block under each cell. The title gets
                % a chunk suffix at render time when the grid paginates. (TERMINAL)
                specs(1) = struct('title', '', ...
                                  'renderer', @renderCellRawImage, ...
                                  'cell_pad_x', 0.02, 'cell_pad_y', 0.1, ...
                                  'show_axis_labels', false, ...
                                  'square_cells', true, ...
                                  'stat_page', 'image');
                specs(2) = struct('title', '', ...
                                  'renderer', @renderCellImageOverlay, ...
                                  'cell_pad_x', 0.02, 'cell_pad_y', 0.1, ...
                                  'show_axis_labels', false, ...
                                  'square_cells', true, ...
                                  'stat_page', 'image');
                specs(3) = struct('title', 'Density Histograms', ...
                                  'renderer', @renderCellHistogram, ...
                                  'cell_pad_x', NaN, 'cell_pad_y', NaN, ...
                                  'show_axis_labels', true, ...
                                  'square_cells', false, ...
                                  'stat_page', 'distribution');
                specs(4) = struct('title', 'Kernel Density Estimates', ...
                                  'renderer', @renderCellKDE, ...
                                  'cell_pad_x', NaN, 'cell_pad_y', NaN, ...
                                  'show_axis_labels', true, ...
                                  'square_cells', false, ...
                                  'stat_page', 'distribution');
                specs(5) = struct('title', 'LogNormal Mixture Fits', ...
                                  'renderer', @renderCellMixture, ...
                                  'cell_pad_x', NaN, 'cell_pad_y', NaN, ...
                                  'show_axis_labels', true, ...
                                  'square_cells', false, ...
                                  'stat_page', 'distribution');
            end

            % ====================================================================
            % SHARED FUNCTIONS (page builders)
            % Called by more than one of the grid / reflow / box builders, so
            % hoisted out of any single builder to this shared level.
            % ====================================================================
            function drawSelectedPageTitle(fig, pageTitle, yBottom)
                % VIEW: Centered bold page title across the top, its box bottom
                % at yBottom. Shared by the grid, reflow, and box plot page
                % builders; the grid and reflow pages take yBottom from
                % computeSelectedHeaderLayout, the box plot page from
                % config.title_y. An empty title draws nothing. Underscores in the
                % composed title (carried in from nominal labels) are shown as
                % spaces so the TeX interpreter does not read them as subscript
                % commands. (TERMINAL)
                if isempty(pageTitle)
                    return;
                end
                pageTitle = strrep(pageTitle, '_', ' ');
                annotation(fig, 'textbox', [0, yBottom, 1, 0.03], ...
                    'String', pageTitle, 'EdgeColor', 'none', ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', 12, 'FontWeight', 'bold');
            end

            function layout = computeSelectedHeaderLayout(pageTitle, hasHeaderLine, config)
                % MODEL: Stack the header lines a grid or reflow page actually
                % draws down from the top of the page, and put the grid top just
                % below the last one. Lines, top to bottom: the page title when it
                % is non-empty (image pages outside a Block axis have none), then
                % one header line when hasHeaderLine (column headers on a grid
                % page, the nominal label on a reflow page). A line that is not
                % drawn takes no height, so the cells start where the drawn
                % headers end. Returns the bottom edge of each line's box (NaN
                % when absent) and gridTop, all normalized. (TERMINAL)
                top = 1 - config.page_top_margin;
                layout.titleBottom = NaN;
                layout.headerBottom = NaN;
                if ~isempty(pageTitle)
                    top = top - config.title_band_h;
                    layout.titleBottom = top;
                end
                if hasHeaderLine
                    top = top - config.header_band_h;
                    layout.headerBottom = top;
                end
                layout.gridTop = top - config.header_grid_gap;
            end

            function pos = computeSelectedCellPosition(localRow, localCol, pagePlan, config, spec, gridTop)
                % MODEL: Normalized [x y w h] for the cell at local (row, col) over
                % the page layout dims. gridTop is the top edge of the cell grid,
                % from computeSelectedHeaderLayout, so the cells start directly
                % under whatever headers the page draws.
                % Spec padding overrides config when finite. localCol may be
                % fractional: the grid path adds a centering offset to it.
                %
                % Square repack: on a reflow page (pagePlan carries seqIdx) whose
                % spec sets square_cells, the axes is sized to a square on the
                % height-limited side of the padded slot, the columns are packed
                % adjacent, and the block is centered in grid_w. imshow holds the
                % plate square, so an over-wide slot otherwise letterboxes each
                % photo and pools the freed width into a band down the page center;
                % sizing the axes square removes the internal letterbox and packing
                % reclaims the center. Reflow distribution cells (square_cells
                % false) and every grid-mode cell keep the full padded slot, so
                % header-aligned layouts are unaffected.
                %
                % Stat block reserve: the bottom of the padded slot is held for
                % the stat block, one stat line per per-cell field of the spec's
                % page type plus the block's gap below the axes. The axes bottom
                % sits on top of the reserve in both branches, so every cell in a
                % page row shares one axes bottom and one stat block level.
                %
                % Vertical extent: the grid runs from just above the page's
                % footnote (grid_bottom_gap above its top line, or above
                % footnote_y when there is none) up to gridTop, so no page margin
                % sits unused above the first row or below the last. Photo cells
                % leave image_row_gap_px below the stat block as the gap to the
                % next row. In grid mode they carry no title and take no top
                % padding; in reflow mode they take reflow_title_px on top for the
                % 8 pt ordinal title. Distribution cells keep their fractional
                % padding. (TERMINAL)
                nCols = pagePlan.nColsLayout;
                nRows = pagePlan.nRowsLayout;
                figW = config.fig_position(3);
                figH = config.fig_position(4);
                nFootLines = numel(config.footnote_lines.(spec.stat_page));
                gridBottom = config.footnote_y + nFootLines * config.footnote_line_h + ...
                             config.grid_bottom_gap;
                gridH = gridTop - gridBottom;
                cellW_total = config.grid_w / nCols;
                cellH_total = gridH / nRows;
                x_outer = config.grid_x + (localCol - 1) * cellW_total;
                y_outer = gridBottom + (nRows - localRow) * cellH_total;
                if isfield(spec, 'cell_pad_x') && isfinite(spec.cell_pad_x)
                    pad_frac_x = spec.cell_pad_x;
                else
                    pad_frac_x = config.cell_pad_x;
                end
                if isfield(spec, 'cell_pad_y') && isfinite(spec.cell_pad_y)
                    pad_frac_y = spec.cell_pad_y;
                else
                    pad_frac_y = config.cell_pad_y;
                end
                pad_x = pad_frac_x * cellW_total;

                isReflow = isfield(pagePlan, 'seqIdx');
                isPhoto = strcmp(spec.stat_page, 'image');
                if isPhoto && ~isReflow
                    padTop = 0;
                    padBottom = config.image_row_gap_px / figH;
                elseif isPhoto
                    padTop = config.reflow_title_px / figH;
                    padBottom = config.image_row_gap_px / figH;
                else
                    padTop = pad_frac_y * cellH_total;
                    padBottom = padTop;
                end

                nStatLines = numel(config.cell_fields.(spec.stat_page));
                if nStatLines > 0
                    reserve = (config.stat_gap_px.(spec.stat_page) + ...
                               nStatLines * config.stat_line_px) / figH;
                else
                    reserve = 0;
                end
                innerH = max(cellH_total - padTop - padBottom - reserve, 1 / figH);

                squareReflow = isReflow && ...
                               isfield(spec, 'square_cells') && spec.square_cells;
                if squareReflow
                    innerW_px = (cellW_total - 2*pad_x) * figW;
                    innerH_px = innerH * figH;
                    side_px = max(min(innerW_px, innerH_px), 1);
                    w = side_px / figW;
                    h = side_px / figH;
                    colGap = w * 0.1;
                    blockW = nCols * w + (nCols - 1) * colGap;
                    xStart = config.grid_x + (config.grid_w - blockW) / 2;
                    x = xStart + (localCol - 1) * (w + colGap);
                    y = y_outer + padBottom + reserve;
                    pos = [x, y, w, h];
                else
                    pos = [x_outer + pad_x, y_outer + padBottom + reserve, ...
                           cellW_total - 2*pad_x, innerH];
                end
            end

            function renderMissingCell(ax)
                % VIEW: Placeholder for an in-grid cell with no eligible plate.
                % Shared by the grid and reflow cell populators. (TERMINAL)
                text(ax, 0.5, 0.5, 'No data', 'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'middle', 'FontSize', 10, ...
                    'Color', [0.5 0.5 0.5]);
                set(ax, 'XTick', [], 'YTick', [], 'Box', 'on', ...
                    'XLim', [0 1], 'YLim', [0 1]);
            end

            % ====================================================================
            % REFLOW PIPELINE (nominal-degenerate: wrap ordinal sequence column-major)
            % ====================================================================
            function fig = buildSelectedReflowPage(spec, pagePlan, entries, scaling, config)
                % SUB-CONTROLLER: Build one reflow page. The lone nominal value is
                % constant over the page, so it is drawn once as a colored label
                % below the title in place of per-column headers, except under a
                % null nominal, whose constant carries no information; this page's
                % ordinal-sequence chunk wraps column-major into the cell grid, and
                % each cell carries its own ordinal value as a title above it. The
                % header lines stack from the top of the page, and the grid starts
                % directly below the last one drawn. Pages chunk the ordinal
                % sequence; the title gains an ordinal-range suffix when more than
                % one page results. Block-wide cell fields print in the footnote.
                fig = createPageFigure(spec, config);
                pageTitle = composeReflowTitle(spec.title, pagePlan, config);
                headerLayout = computeSelectedHeaderLayout(pageTitle, ~config.nominal_is_null, config);
                drawSelectedPageTitle(fig, pageTitle, headerLayout.titleBottom);
                if ~config.nominal_is_null
                    drawReflowNominalLabel(fig, headerLayout.headerBottom, config);
                end
                if isfield(spec, 'show_axis_labels') && spec.show_axis_labels && ...
                        ~isnan(headerLayout.titleBottom)
                    addAxisLabels(fig, headerLayout.titleBottom);
                end
                populateReflowGridCells(fig, spec, pagePlan, headerLayout.gridTop, entries, scaling, config);
                drawPageFootnote(fig, config.footnote_lines.(spec.stat_page), config);

                function t = composeReflowTitle(baseTitle, pagePlan, config)
                    % MODEL: Append a parenthesized suffix naming the block, when
                    % one is set, and the ordinal range when the sequence
                    % paginates, so repeated figure titles disambiguate across
                    % pages. (TERMINAL)
                    parts = {};
                    if ~isempty(config.block_title)
                        parts{end+1} = config.block_title;
                    end
                    if pagePlan.nSeqChunks > 1
                        ordFirst = config.ordinal_values(pagePlan.seqIdx(1));
                        ordLast  = config.ordinal_values(pagePlan.seqIdx(end));
                        if numel(pagePlan.seqIdx) > 1
                            parts{end+1} = sprintf('%s %g-%g', config.ordinal_axis_label, ordFirst, ordLast);
                        else
                            parts{end+1} = sprintf('%s %g', config.ordinal_axis_label, ordFirst);
                        end
                    end
                    if isempty(parts)
                        t = baseTitle;
                    elseif isempty(baseTitle)
                        t = ['(' strjoin(parts, ', ') ')'];
                    else
                        t = [baseTitle ' (' strjoin(parts, ', ') ')'];
                    end
                end

                function drawReflowNominalLabel(fig, yBottom, config)
                    % VIEW: Single colored label for the constant nominal value,
                    % centered across the page in the header line whose box
                    % bottom is yBottom. Stated once because position no longer
                    % encodes the nominal. (TERMINAL)
                    nominal = config.nominal_order{1};
                    label = strrep(config.nominal_labels(nominal), '_', ' ');
                    color = config.colors(nominal);
                    annotation(fig, 'textbox', [0, yBottom, 1, config.header_band_h], ...
                        'String', label, 'EdgeColor', 'none', ...
                        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                        'FontSize', 16, 'FontWeight', 'bold', 'Color', color);
                end

                function populateReflowGridCells(fig, spec, pagePlan, gridTop, entries, scaling, config)
                    % SUB-CONTROLLER: Walk this page's ordinal-sequence chunk
                    % column-major, create per-cell axes, dispatch to the renderer,
                    % and prefix each cell's sub-header with its ordinal value. The
                    % nominal column index is fixed at 1. Sequence positions map to
                    % (row, col) by column-major fill over the layout row count; an
                    % in-range ordinal with no eligible entry renders the
                    % missing-cell placeholder (a real gap in the series), and slots
                    % past the chunk end are never visited (left blank, no axes).
                    % Each rendered cell gets its stat block below it, and the
                    % cells of the first column carry the row names, since the
                    % column-major fill starts every row there.
                    color = config.colors(config.nominal_order{1});
                    rowLabels = statRowLabels(config, spec.stat_page);
                    seqIdx = pagePlan.seqIdx;
                    nCells = numel(seqIdx);
                    for localSeq = 1:nCells
                        pi = seqIdx(localSeq);
                        [localRow, localCol] = seqToRowCol(localSeq, pagePlan.nRowsLayout);
                        cellPos = computeSelectedCellPosition(localRow, localCol, pagePlan, config, spec, gridTop);
                        ax = createCellAxes(fig, cellPos);
                        entry = entries{pi, 1};
                        if isempty(entry)
                            renderMissingCell(ax);
                        else
                            spec.renderer(ax, entry, color, scaling, config);
                            diameter = resolvePlateDiameterMm(entry);
                            cellMeta = makeCellMeta(entry, diameter, config, spec.stat_page);
                            drawCellStatBlock(ax, cellMeta.lines, spec.stat_page, config);
                        end
                        if localCol == 1
                            drawCellRowLabels(ax, rowLabels, spec.stat_page, config);
                        end
                        setCellOrdinalTitle(ax, config.ordinal_axis_label, config.ordinal_values(pi));
                    end

                    function [r, c] = seqToRowCol(localSeq, nRows)
                        % MODEL: Column-major (row, col) from a 1-based sequence
                        % index (TERMINAL)
                        c = ceil(localSeq / nRows);
                        r = mod(localSeq - 1, nRows) + 1;
                    end

                    function setCellOrdinalTitle(ax, ordLabel, ordVal)
                        % VIEW: Title each reflow cell with its ordinal value, since
                        % position no longer encodes the ordinal. The stat block
                        % sits below the cell, so the title above it is free for
                        % this line. Underscores in the ordinal label render as
                        % spaces, matching the page's other labels. (TERMINAL)
                        ordLine = sprintf('%s %g', strrep(ordLabel, '_', ' '), ordVal);
                        title(ax, ordLine, 'FontSize', 8, 'FontWeight', 'normal');
                    end
                end
            end

            % ====================================================================
            % GRID PIPELINE (default: ordinal down, nominal across)
            % ====================================================================
            function fig = buildSelectedGridPage(spec, pagePlan, entries, scaling, config)
                % SUB-CONTROLLER: Build one grid page over a nominal/ordinal chunk
                % (ordinal down, nominal across) with headers and per-cell axes.
                % A nominal chunk narrower than the page layout is centered by a
                % column offset shared by the headers and the cells, so both keep
                % the slot width of a full page. Column headers are skipped under
                % a null nominal and row headers under a null ordinal, since each
                % would print one constant. Row headers are drawn after the cells,
                % into each row's first axes, so they sit beside the plot at any
                % centering offset. The header lines stack from the top of the
                % page, and the grid starts directly below the last one drawn.
                % Block-wide cell fields of the page's type print in the footnote.
                fig = createPageFigure(spec, config);
                pageTitle = composeChunkTitle(spec.title, pagePlan, config);
                colOffset = computeColumnOffset(pagePlan);
                headerLayout = computeSelectedHeaderLayout(pageTitle, ~config.nominal_is_null, config);
                drawSelectedPageTitle(fig, pageTitle, headerLayout.titleBottom);
                if ~config.nominal_is_null
                    drawSelectedColumnHeaders(fig, pagePlan, colOffset, headerLayout.headerBottom, config);
                end
                if isfield(spec, 'show_axis_labels') && spec.show_axis_labels && ...
                        ~isnan(headerLayout.titleBottom)
                    addAxisLabels(fig, headerLayout.titleBottom);
                end
                firstColumnAxes = populateSelectedGridCells(fig, spec, pagePlan, colOffset, headerLayout.gridTop, entries, scaling, config);
                if ~config.ordinal_is_null
                    drawSelectedRowHeaders(firstColumnAxes, spec, pagePlan, config);
                end
                drawPageFootnote(fig, config.footnote_lines.(spec.stat_page), config);

                function t = composeChunkTitle(baseTitle, pagePlan, config)
                    % MODEL: Append a parenthesized suffix naming the block, when
                    % one is set, and the range of each axis that paginates, so
                    % repeated figure titles disambiguate. (TERMINAL)
                    parts = {};
                    if ~isempty(config.block_title)
                        parts{end+1} = config.block_title;
                    end
                    if pagePlan.nNomChunks > 1
                        nomFirst = config.nominal_labels(config.nominal_order{pagePlan.nomIdx(1)});
                        nomLast  = config.nominal_labels(config.nominal_order{pagePlan.nomIdx(end)});
                        if numel(pagePlan.nomIdx) > 1
                            parts{end+1} = sprintf('%s %s-%s', config.nominal_axis_label, nomFirst, nomLast); %#ok<AGROW>
                        else
                            parts{end+1} = sprintf('%s %s', config.nominal_axis_label, nomFirst); %#ok<AGROW>
                        end
                    end
                    if pagePlan.nOrdChunks > 1
                        ordFirst = config.ordinal_values(pagePlan.ordIdx(1));
                        ordLast  = config.ordinal_values(pagePlan.ordIdx(end));
                        if numel(pagePlan.ordIdx) > 1
                            parts{end+1} = sprintf('%s %g-%g', config.ordinal_axis_label, ordFirst, ordLast); %#ok<AGROW>
                        else
                            parts{end+1} = sprintf('%s %g', config.ordinal_axis_label, ordFirst); %#ok<AGROW>
                        end
                    end
                    if isempty(parts)
                        t = baseTitle;
                    elseif isempty(baseTitle)
                        t = ['(' strjoin(parts, ', ') ')'];
                    else
                        t = [baseTitle ' (' strjoin(parts, ', ') ')'];
                    end
                end

                function colOffset = computeColumnOffset(pagePlan)
                    % MODEL: Slot offset that centers this page's nominal columns
                    % within the layout width. Half the unused slots, so 2 of 4
                    % columns land in slots 2 and 3, and 1 or 3 of 4 land centered
                    % on a half-slot offset. Zero when the chunk fills the layout,
                    % which includes every unpaginated page. (TERMINAL)
                    colOffset = max(pagePlan.nColsLayout - numel(pagePlan.nomIdx), 0) / 2;
                end

                function drawSelectedColumnHeaders(fig, pagePlan, colOffset, yBottom, config)
                    % VIEW: Nominal column headers above the grid, in the header
                    % line whose box bottom is yBottom, positioned by local column
                    % index plus the centering offset over the page layout width
                    % (TERMINAL)
                    cellW = config.grid_w / pagePlan.nColsLayout;
                    for c = 1:numel(pagePlan.nomIdx)
                        gi = pagePlan.nomIdx(c);
                        nominal = config.nominal_order{gi};
                        label = strrep(config.nominal_labels(nominal), '_', ' ');
                        color = config.colors(nominal);
                        x0 = config.grid_x + (c - 1 + colOffset) * cellW;
                        annotation(fig, 'textbox', ...
                            [x0, yBottom, cellW, config.header_band_h], ...
                            'String', label, 'EdgeColor', 'none', ...
                            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                            'FontSize', 16, 'FontWeight', 'bold', 'Color', color);
                    end
                end

                function drawSelectedRowHeaders(firstColumnAxes, spec, pagePlan, config)
                    % VIEW: Ordinal row headers, rotated 90 degrees and centered
                    % on the height of each row's first axes, just left of its
                    % left edge. Drawn in the axes' normalized units with clipping
                    % off, so a header follows its plot through any centering
                    % offset and any image fit. The gap clears the y tick labels
                    % on distribution pages. The margin below each header stays
                    % free for the stat row names. Interpreter 'none' prints
                    % underscores in a field-name label literally. (TERMINAL)
                    gapPx = config.row_header_gap_px.(spec.stat_page);
                    for r = 1:numel(pagePlan.ordIdx)
                        ax = firstColumnAxes(r);
                        pi = pagePlan.ordIdx(r);
                        pos = get(ax, 'Position');
                        axesWpx = pos(3) * config.fig_position(3);
                        headerText = sprintf('%s %g', config.ordinal_axis_label, config.ordinal_values(pi));
                        text(ax, -gapPx / axesWpx, 0.5, headerText, ...
                            'Units', 'normalized', 'Rotation', 90, ...
                            'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                            'FontSize', config.row_header_font, 'FontWeight', 'bold', ...
                            'Interpreter', 'none', 'Clipping', 'off');
                    end
                end

                function firstColumnAxes = populateSelectedGridCells(fig, spec, pagePlan, colOffset, gridTop, entries, scaling, config)
                    % SUB-CONTROLLER: Create per-cell axes, dispatch to the
                    % renderer, and draw each rendered cell's stat block below it.
                    % The first column's axes carry the row names and are returned
                    % so the row headers can be drawn into them. The column passed
                    % to computeSelectedCellPosition carries the centering offset,
                    % which may be fractional; the grid-mode branch of that model
                    % uses the column only as a slot multiplier, so a half-slot
                    % offset positions exactly.
                    rowLabels = statRowLabels(config, spec.stat_page);
                    firstColumnAxes = gobjects(numel(pagePlan.ordIdx), 1);
                    for r = 1:numel(pagePlan.ordIdx)
                        for c = 1:numel(pagePlan.nomIdx)
                            pi = pagePlan.ordIdx(r);
                            gi = pagePlan.nomIdx(c);
                            cellPos = computeSelectedCellPosition(r, c + colOffset, pagePlan, config, spec, gridTop);
                            ax = createCellAxes(fig, cellPos);
                            entry = entries{pi, gi};
                            nominal = config.nominal_order{gi};
                            color = config.colors(nominal);
                            if isempty(entry)
                                renderMissingCell(ax);
                            else
                                spec.renderer(ax, entry, color, scaling, config);
                                diameter = resolvePlateDiameterMm(entry);
                                cellMeta = makeCellMeta(entry, diameter, config, spec.stat_page);
                                drawCellStatBlock(ax, cellMeta.lines, spec.stat_page, config);
                            end
                            if c == 1
                                drawCellRowLabels(ax, rowLabels, spec.stat_page, config);
                                firstColumnAxes(r) = ax;
                            end
                        end
                    end
                end
            end

            % ====================================================================
            % BOX PLOT PAGE (shared by both kinds via layout.nomChunks)
            % ====================================================================
            function fig = renderSelectedBoxPlotPage(pagePlan, entries, scaling, config)
                % SUB-CONTROLLER: One page of box plots for one nominal chunk,
                % grouped by nominal value with one box per ordinal value and NaN
                % spacers between groups. Y is log-radius shared with the
                % distribution pages, with explicit ticks applied after the limits
                % are set. The per-box summary band is drawn above the axes; the
                % axes rectangle already reserves its height. The ordinal axis name
                % is drawn as in-axes text below the tick labels. Group labels are
                % skipped under a null nominal. Flags are overlaid after axes scale
                % is final; the flag key sits lower left and the block-wide cell
                % field footnote lower right.
                pageTitle = composeBoxChunkTitle('Colony Radius Distributions', pagePlan, config);
                fig = createBoxPlotFigure(config);
                drawSelectedPageTitle(fig, pageTitle, config.title_y);
                drawSelectedBoxAxisLabels(fig, config);
                ax = createSelectedBoxAxes(fig, config);
                [matrix, positionMap, flagInputs] = buildSelectedBoxMatrix(pagePlan, entries, config);
                drawCompiledBoxPlot(ax, matrix);
                applySelectedBoxColoring(ax, positionMap, config);
                configureSelectedBoxAxes(ax, matrix, positionMap, scaling, config);
                applyLogRadiusTicks(ax, config);

                if ~isempty(matrix)
                    bandY = computeBoxBandY(scaling, config);
                    if ~config.nominal_is_null
                        drawSelectedGroupHeaders(ax, pagePlan, bandY, config);
                    end
                    drawSelectedBoxXAxisLabel(ax, bandY, config);
                    boxStats = computeBoxColumnStats(matrix, positionMap);
                    drawBoxStatsBand(ax, boxStats, bandY, config);
                end

                marks = detectPlateFlags(flagInputs, scaling, config);
                drawFlagMarks(ax, marks);
                drawFlagLegend(fig, marks, config);
                drawPageFootnote(fig, config.footnote_lines.all, config);

                function t = composeBoxChunkTitle(baseTitle, pagePlan, config)
                    % MODEL: Append a parenthesized suffix naming the block, when
                    % one is set, and the nominal range when the box plot
                    % paginates on the nominal axis (TERMINAL)
                    parts = {};
                    if ~isempty(config.block_title)
                        parts{end+1} = config.block_title;
                    end
                    if pagePlan.nNomChunks > 1
                        nomFirst = config.nominal_labels(config.nominal_order{pagePlan.nomIdx(1)});
                        nomLast  = config.nominal_labels(config.nominal_order{pagePlan.nomIdx(end)});
                        if numel(pagePlan.nomIdx) > 1
                            parts{end+1} = sprintf('%s %s-%s', config.nominal_axis_label, nomFirst, nomLast);
                        else
                            parts{end+1} = sprintf('%s %s', config.nominal_axis_label, nomFirst);
                        end
                    end
                    if isempty(parts)
                        t = baseTitle;
                    else
                        t = [baseTitle ' (' strjoin(parts, ', ') ')'];
                    end
                end

                function drawSelectedBoxAxisLabels(fig, config)
                    % VIEW: Axis-name annotation at top right. The x axis is named
                    % for the ordinal, or for the nominal under a null ordinal,
                    % whose group labels then carry the x values. The micron sign
                    % is a literal char(956) under Interpreter 'none' so it is
                    % drawn in the page typeface. (TERMINAL)
                    if config.ordinal_is_null
                        xName = config.nominal_axis_label;
                    else
                        xName = config.ordinal_axis_label;
                    end
                    labelText = sprintf('X axis: %s, Y axis: Colony Radius %sm', ...
                        xName, char(956));
                    boxWidth = 0.35;
                    boxHeight = 0.03;
                    rightMargin = 0.01;
                    yPos = config.title_y - boxHeight/2;
                    xPos = 1 - rightMargin - boxWidth;
                    annotation(fig, 'textbox', [xPos, yPos, boxWidth, boxHeight], ...
                        'String', labelText, 'EdgeColor', 'none', 'Interpreter', 'none', ...
                        'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle', ...
                        'FontSize', config.box_font, 'FontWeight', 'normal');
                end

                function ax = createSelectedBoxAxes(fig, config)
                    % VIEW: Single panel axes filling most of the page, shrunk from
                    % the top by the summary band height (TERMINAL)
                    ax = axes('Parent', fig, 'Position', computeBoxAxesRect(config));
                end

                function [matrix, positionMap, flagInputs] = buildSelectedBoxMatrix(pagePlan, entries, config)
                    % MODEL: Column-major matrix grouped by the chunk's nominal
                    % values, every ordinal value within each group, with NaN spacer
                    % columns between groups. positionMap describes each data column
                    % (col, nominal, ordinalValue). flagInputs carries one record per
                    % data column (col, sourceType, plateDiameterMm, maxRadius) for
                    % the flag detector. (TERMINAL)
                    nomIdx = pagePlan.nomIdx;
                    nGl = numel(nomIdx);
                    nP = numel(config.ordinal_values);
                    nSpacers = 2;

                    dataCells = cell(nP, nGl);
                    sourceTypes = cell(nP, nGl);
                    diameters = nan(nP, nGl);
                    maxN = 0;
                    for c = 1:nGl
                        gi = nomIdx(c);
                        for r = 1:nP
                            entry = entries{r, gi};
                            if ~isempty(entry)
                                radii = entry.Measurements.Radius;
                                radii = radii(isfinite(radii) & radii > 0);
                                dataCells{r, c} = radii(:);
                                maxN = max(maxN, length(radii));
                                if isfield(entry, 'source_type')
                                    sourceTypes{r, c} = entry.source_type;
                                else
                                    sourceTypes{r, c} = '';
                                end
                                diameters(r, c) = resolvePlateDiameterMm(entry);
                            else
                                dataCells{r, c} = [];
                            end
                        end
                    end

                    if maxN == 0
                        matrix = [];
                        positionMap = struct('col', {}, 'nominal', {}, 'ordinalValue', {});
                        flagInputs = struct('col', {}, 'sourceType', {}, ...
                            'plateDiameterMm', {}, 'maxRadius', {});
                        return;
                    end

                    nCols = nGl * nP + max(nGl - 1, 0) * nSpacers;
                    matrix = nan(maxN, nCols);
                    positionMap = struct('col', {}, 'nominal', {}, 'ordinalValue', {});
                    flagInputs = struct('col', {}, 'sourceType', {}, ...
                        'plateDiameterMm', {}, 'maxRadius', {});
                    col = 1;
                    for c = 1:nGl
                        gi = nomIdx(c);
                        nominal = config.nominal_order{gi};
                        for r = 1:nP
                            radii = dataCells{r, c};
                            if ~isempty(radii)
                                matrix(1:length(radii), col) = radii;
                            end
                            positionMap(end+1) = struct('col', col, ...
                                'nominal', nominal, ...
                                'ordinalValue', config.ordinal_values(r)); %#ok<AGROW>
                            if ~isempty(entries{r, gi})
                                if isempty(radii)
                                    mr = NaN;
                                else
                                    mr = max(radii);
                                end
                                flagInputs(end+1) = struct('col', col, ...
                                    'sourceType', sourceTypes{r, c}, ...
                                    'plateDiameterMm', diameters(r, c), ...
                                    'maxRadius', mr); %#ok<AGROW>
                            end
                            col = col + 1;
                        end
                        if c < nGl
                            col = col + nSpacers;
                        end
                    end
                end

                function applySelectedBoxColoring(ax, positionMap, config)
                    % VIEW: Recolor box/whisker/median/outlier elements by nominal
                    % value using column position. Spacer columns are skipped. (TERMINAL)
                    colToColor = containers.Map('KeyType', 'int32', 'ValueType', 'any');
                    for i = 1:length(positionMap)
                        entry = positionMap(i);
                        colToColor(int32(entry.col)) = config.colors(entry.nominal);
                    end

                    lineObjects = findobj(ax, 'Type', 'line');
                    for i = 1:length(lineObjects)
                        try
                            xData = get(lineObjects(i), 'XData');
                            if isempty(xData), continue; end
                            col = round(xData(1));
                            if ~isKey(colToColor, int32(col)), continue; end
                            colColor = colToColor(int32(col));
                            tag = get(lineObjects(i), 'Tag');
                            darkEdge = max(colColor * 0.4, 0);
                            if strcmp(tag, 'Outliers')
                                set(lineObjects(i), 'Color', colColor, ...
                                    'MarkerFaceColor', colColor, ...
                                    'MarkerEdgeColor', darkEdge);
                            elseif strcmp(tag, 'MedianInner') || strcmp(tag, 'MedianOuter')
                                set(lineObjects(i), 'Color', colColor, ...
                                    'MarkerFaceColor', 'white', ...
                                    'MarkerEdgeColor', darkEdge, 'LineWidth', 1.5);
                            else
                                set(lineObjects(i), 'Color', colColor);
                            end
                        catch
                            continue;
                        end
                    end

                    patchObjects = findobj(ax, 'Type', 'patch');
                    for j = 1:length(patchObjects)
                        try
                            vertices = get(patchObjects(j), 'Vertices');
                            if isempty(vertices), continue; end
                            col = round(mean(vertices(:, 1)));
                            if ~isKey(colToColor, int32(col)), continue; end
                            colColor = colToColor(int32(col));
                            set(patchObjects(j), 'FaceColor', colColor, 'FaceAlpha', 0.7);
                        catch
                            continue;
                        end
                    end
                end

                function configureSelectedBoxAxes(ax, matrix, positionMap, scaling, config)
                    % VIEW: Y log-scale shared with distribution pages, custom
                    % x-tick labels showing ordinal values at data columns, blank
                    % under a null ordinal, where the group labels name each box.
                    % The ordinal axis name is drawn by drawSelectedBoxXAxisLabel as
                    % in-axes text, since boxplot repositions the axes XLabel after
                    % it is set. The y label is set after the axes FontSize, since
                    % setting the axes FontSize resizes existing labels. Y ticks are
                    % set afterwards by applyLogRadiusTicks. (TERMINAL)
                    if isempty(matrix), return; end
                    set(ax, 'YScale', 'log');
                    ylim(ax, scaling.x_um_extent);

                    dataCols = [positionMap.col];
                    ordValues = [positionMap.ordinalValue];
                    set(ax, 'XTick', dataCols);
                    if config.ordinal_is_null
                        ordLabels = repmat({''}, 1, numel(ordValues));
                    else
                        ordLabels = arrayfun(@(v) sprintf('%g', v), ordValues, ...
                            'UniformOutput', false);
                    end
                    set(ax, 'XTickLabel', ordLabels);
                    xlim(ax, [0, size(matrix, 2) + 1]);

                    set(ax, 'FontSize', config.box_font);
                    ylabel(ax, ['Colony Radius (' char(956) 'm)'], ...
                        'Interpreter', 'none', 'FontSize', config.box_axis_name_font);
                    box(ax, 'on');
                    grid(ax, 'on');
                end

                function drawSelectedGroupHeaders(ax, pagePlan, bandY, config)
                    % VIEW: Colored nominal labels above each group of ordinal
                    % boxes, drawn in the box axes at the group's center column so
                    % they stay over their boxes whatever boxplot does to the axes
                    % rectangle. Clipping is off because the label sits above the
                    % top limit, in the strip the axes gave up. (TERMINAL)
                    nomIdx = pagePlan.nomIdx;
                    nGl = numel(nomIdx);
                    nP = numel(config.ordinal_values);
                    nSpacers = 2;

                    hold(ax, 'on');
                    for c = 1:nGl
                        gi = nomIdx(c);
                        nominal = config.nominal_order{gi};
                        label = strrep(config.nominal_labels(nominal), '_', ' ');
                        color = config.colors(nominal);
                        firstCol = (c - 1) * (nP + nSpacers) + 1;
                        lastCol = firstCol + nP - 1;
                        centerCol = (firstCol + lastCol) / 2;
                        text(ax, centerCol, bandY.groupLabel, label, ...
                            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                            'FontSize', config.box_font, 'FontWeight', 'bold', ...
                            'Color', color, 'Clipping', 'off');
                    end
                    hold(ax, 'off');
                end

                function drawSelectedBoxXAxisLabel(ax, bandY, config)
                    % VIEW: X axis name centered under the box axes, drawn as
                    % in-axes text at bandY.axisLabel with clipping off. The name
                    % is the ordinal label, or the nominal label under a null
                    % ordinal. boxplot does not reposition plain text objects, so
                    % the label holds its place through export. Interpreter 'none'
                    % prints underscores in a field-name default literally. (TERMINAL)
                    if config.ordinal_is_null
                        xName = config.nominal_axis_label;
                    else
                        xName = config.ordinal_axis_label;
                    end
                    xl = get(ax, 'XLim');
                    hold(ax, 'on');
                    text(ax, mean(xl), bandY.axisLabel, xName, ...
                        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                        'FontSize', config.box_axis_name_font, 'FontWeight', 'normal', ...
                        'Interpreter', 'none', 'Clipping', 'off');
                    hold(ax, 'off');
                end
            end
        end
    end

    % ============================================================
    % FULL PIPELINE
    % ============================================================

    function fullLastPage = runFullPipeline(Part3CompleteData, config, outputPath, pageOffset)
        % SUB-CONTROLLER: Organize every display-eligible plate by ON index,
        % compute shared scaling, and render the figure pages and per-genotype
        % box plot pages. Full mode runs under default genotype/passage axes; it
        % reads the genotype_order / passages / genotype_labels aliases on config.
        % Pages number from pageOffset + 1, after the fidelity page; the last
        % page number is returned so appended figures continue the count.
        composite = Part3CompleteData.composite;
        onIndexPlates = selectAllPlatesByONIndex(Part3CompleteData, config);
        validIdx = collectAllPlateIndices(onIndexPlates);
        validEntries = num2cell(composite(validIdx));
        scaling = computeGlobalScaling(validEntries, config);
        fullLastPage = renderFullPages(Part3CompleteData, onIndexPlates, scaling, config, outputPath, pageOffset);

        function onIndexPlates = selectAllPlatesByONIndex(Part3CompleteData, config)
            % SUB-CONTROLLER: For every (passage, genotype) ON index, organize all
            % display-eligible plates into ordered standard and protocol-mod
            % sub-groups
            composite = Part3CompleteData.composite;
            eligibleMask = buildEligibleMask(composite);
            standardSetMask = buildStandardSetMask(composite);
            onIndexPlates = organizeAllONIndices(composite, eligibleMask, standardSetMask, config);

            function mask = buildStandardSetMask(composite)
                % MODEL: Standard-set membership: Standard 6-day not Excluded, plus
                % cdc13-2 P4 LargeSourced 6-day not Excluded as a substitute for the
                % low-colony-count cdc13-2 P4 Standard plate. (TERMINAL)
                standardMask = strcmp({composite.source_type}, 'Standard') & ...
                    [composite.incubation_days] == 6 & ...
                    ~contains({composite.enrichment}, 'Excluded');
                cdcP4LargeMask = strcmp({composite.genotype}, 'cdc13-2') & ...
                    [composite.passage] == 4 & ...
                    strcmp({composite.source_type}, 'LargeSourced') & ...
                    [composite.incubation_days] == 6 & ...
                    ~contains({composite.enrichment}, 'Excluded');
                mask = standardMask | cdcP4LargeMask;
            end

            function onIndexPlates = organizeAllONIndices(composite, em, sm, config)
                % SUB-CONTROLLER: Iterate ON indices, organize one at a time
                nP = length(config.passages);
                nG = length(config.genotype_order);
                emptyEntry.passage = NaN;
                emptyEntry.genotype = '';
                emptyEntry.standardSubGroups = struct('label', {}, 'indices', {});
                emptyEntry.protocolModSubGroups = struct('label', {}, 'indices', {});
                onIndexPlates = repmat(emptyEntry, nP, nG);
                for pi = 1:nP
                    for gi = 1:nG
                        passage = config.passages(pi);
                        genotype = config.genotype_order{gi};
                        onIndexPlates(pi, gi) = organizeOneONIndex( ...
                            composite, em, sm, passage, genotype);
                    end
                end

                function entry = organizeOneONIndex(composite, em, sm, passage, genotype)
                    % SUB-CONTROLLER: Group, order, and sub-categorize one ON
                    % index's plates
                    groupMask = em & strcmp({composite.genotype}, genotype) & ...
                                [composite.passage] == passage;
                    allIdx = find(groupMask);
                    standardIdx = intersect(allIdx, find(sm));
                    protocolModIdx = setdiff(allIdx, standardIdx);

                    standardOrdered = orderPlatesWithinBlock(composite, standardIdx);
                    protocolModOrdered = orderPlatesWithinBlock(composite, protocolModIdx);

                    entry = struct();
                    entry.passage = passage;
                    entry.genotype = genotype;
                    entry.standardSubGroups = groupBySubCategory(composite, standardOrdered);
                    entry.protocolModSubGroups = groupBySubCategory(composite, protocolModOrdered);

                    function ordered = orderPlatesWithinBlock(composite, idx)
                        % MODEL: Sort by (source_type rank, incubation_days,
                        % excluded flag, replicate rank, hce) (TERMINAL)
                        if isempty(idx)
                            ordered = [];
                            return;
                        end
                        n = length(idx);
                        sourceRank = zeros(n, 1);
                        incDays = zeros(n, 1);
                        excludedFlag = zeros(n, 1);
                        replicateRank = zeros(n, 1);
                        hces = zeros(n, 1);
                        for k = 1:n
                            e = composite(idx(k));
                            switch e.source_type
                                case 'Standard',     sourceRank(k) = 1;
                                case 'LargeSourced', sourceRank(k) = 2;
                                case 'SmallSourced', sourceRank(k) = 3;
                                otherwise,           sourceRank(k) = 9;
                            end
                            incDays(k) = e.incubation_days;
                            excludedFlag(k) = double(contains(e.enrichment, 'Excluded'));
                            switch e.replicate
                                case 'A', replicateRank(k) = 1;
                                case 'B', replicateRank(k) = 2;
                                case '',  replicateRank(k) = 3;
                                otherwise, replicateRank(k) = 4;
                            end
                            if isnumeric(e.hce) && ~isempty(e.hce)
                                hces(k) = e.hce;
                            else
                                hces(k) = Inf;
                            end
                        end
                        sortMatrix = [sourceRank, incDays, excludedFlag, replicateRank, hces];
                        [~, sortOrder] = sortrows(sortMatrix);
                        ordered = idx(sortOrder);
                    end

                    function subGroups = groupBySubCategory(composite, orderedIdx)
                        % MODEL: Group consecutive plates sharing a sub-category
                        % label defined by (source_type, incubation_days,
                        % isExcluded) (TERMINAL)
                        subGroups = struct('label', {}, 'indices', {});
                        if isempty(orderedIdx)
                            return;
                        end
                        labels = cell(length(orderedIdx), 1);
                        for k = 1:length(orderedIdx)
                            labels{k} = makeLabel(composite(orderedIdx(k)));
                        end
                        [uniqueLabels, ~, groupIdx] = unique(labels, 'stable');
                        for k = 1:length(uniqueLabels)
                            subGroups(k).label = uniqueLabels{k};
                            subGroups(k).indices = orderedIdx(groupIdx == k);
                        end

                        function lbl = makeLabel(entry)
                            switch entry.source_type
                                case 'Standard',     src = 'Std';
                                case 'LargeSourced', src = 'LgSrc';
                                case 'SmallSourced', src = 'SmSrc';
                                otherwise,           src = entry.source_type;
                            end
                            lbl = sprintf('%s %dd', src, entry.incubation_days);
                            if contains(entry.enrichment, 'Excluded')
                                lbl = [lbl ' Excl'];
                            end
                        end
                    end
                end
            end
        end

        function idx = collectAllPlateIndices(onIndexPlates)
            % MODEL: Flatten every sub-group's indices into one unique array (TERMINAL)
            allIdx = [];
            for pi = 1:size(onIndexPlates, 1)
                for gi = 1:size(onIndexPlates, 2)
                    entry = onIndexPlates(pi, gi);
                    for k = 1:length(entry.standardSubGroups)
                        allIdx = [allIdx; entry.standardSubGroups(k).indices(:)]; %#ok<AGROW>
                    end
                    for k = 1:length(entry.protocolModSubGroups)
                        allIdx = [allIdx; entry.protocolModSubGroups(k).indices(:)]; %#ok<AGROW>
                    end
                end
            end
            idx = unique(allIdx);
        end

        function pageNum = renderFullPages(Part3CompleteData, onIndexPlates, scaling, config, outputPath, pageOffset)
            % SUB-CONTROLLER: Page order is genotype outermost, then passage. Each
            % genotype's run of figure pages is followed by its box plot page.
            composite = Part3CompleteData.composite;
            pageSpecs = defineFullPageSpecs();

            % The main controller cleared the file and may have written page 1
            pageNum = pageOffset;
            nG = length(config.genotype_order);
            nP = length(config.passages);
            for gi = 1:nG
                for pi = 1:nP
                    entry = onIndexPlates(pi, gi);
                    if isOnIndexEmpty(entry), continue; end
                    for fi = 1:length(pageSpecs)
                        fig = buildFullONIndexPage(pageSpecs(fi), composite, entry, scaling, config, gi);
                        pageNum = pageNum + 1;
                        exportPageToPDF(fig, outputPath, pageNum);
                        close(fig);
                    end
                end
                fig = buildGenotypeBoxPlotPage(composite, onIndexPlates(:, gi), scaling, config, gi);
                pageNum = pageNum + 1;
                exportPageToPDF(fig, outputPath, pageNum);
                close(fig);
            end

            function tf = isOnIndexEmpty(entry)
                % MODEL: (TERMINAL)
                tf = isempty(entry.standardSubGroups) && isempty(entry.protocolModSubGroups);
            end

            function specs = defineFullPageSpecs()
                % MODEL: Per-page title, renderer handle, padding, axis-label flag (TERMINAL)
                specs(1) = struct('title', 'Original Source Images', ...
                                  'renderer', @renderCellRawImage, ...
                                  'cell_pad_x', 0.02, 'cell_pad_y', 0.1, ...
                                  'show_axis_labels', false, ...
                                  'stat_page', 'image');
                specs(2) = struct('title', 'Source Images with Colony Overlays', ...
                                  'renderer', @renderCellImageOverlay, ...
                                  'cell_pad_x', 0.02, 'cell_pad_y', 0.1, ...
                                  'show_axis_labels', false, ...
                                  'stat_page', 'image');
                specs(3) = struct('title', 'Density Histograms', ...
                                  'renderer', @renderCellHistogram, ...
                                  'cell_pad_x', NaN, 'cell_pad_y', NaN, ...
                                  'show_axis_labels', true, ...
                                  'stat_page', 'distribution');
                specs(4) = struct('title', 'Kernel Density Estimates', ...
                                  'renderer', @renderCellKDE, ...
                                  'cell_pad_x', NaN, 'cell_pad_y', NaN, ...
                                  'show_axis_labels', true, ...
                                  'stat_page', 'distribution');
                specs(5) = struct('title', 'LogNormal Mixture Fits', ...
                                  'renderer', @renderCellMixture, ...
                                  'cell_pad_x', NaN, 'cell_pad_y', NaN, ...
                                  'show_axis_labels', true, ...
                                  'stat_page', 'distribution');
            end

            function fig = buildFullONIndexPage(spec, composite, entry, scaling, config, gi)
                % SUB-CONTROLLER: Build one ON-index page of one figure type, with
                % block-wide cell fields in the footnote
                fig = createPageFigure(spec, config);
                drawFullPageHeader(fig, spec, entry, config, gi);
                if isfield(spec, 'show_axis_labels') && spec.show_axis_labels
                    addAxisLabels(fig, config.subtitle_y);
                end
                populateFullPageGrid(fig, spec, composite, entry, scaling, config, gi);
                drawPageFootnote(fig, config.footnote_lines.(spec.stat_page), config);

                function drawFullPageHeader(fig, spec, entry, config, gi)
                    % SUB-CONTROLLER: ON-index title (genotype colored) + figure
                    % type subtitle
                    drawFullONIndexTitle(fig, entry, config, gi);
                    drawFullFigureTypeSubtitle(fig, spec, config);

                    function drawFullONIndexTitle(fig, entry, config, gi)
                        % VIEW: (TERMINAL)
                        genotype = config.genotype_order{gi};
                        label = config.genotype_labels(genotype);
                        color = config.colors(genotype);
                        titleStr = sprintf('%s, Passage %d', label, entry.passage);
                        annotation(fig, 'textbox', [0, config.title_y, 1, 0.03], ...
                            'String', titleStr, 'EdgeColor', 'none', ...
                            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                            'FontSize', 14, 'FontWeight', 'bold', 'Color', color);
                    end

                    function drawFullFigureTypeSubtitle(fig, spec, config)
                        % VIEW: (TERMINAL)
                        annotation(fig, 'textbox', [0, config.subtitle_y, 1, 0.025], ...
                            'String', spec.title, 'EdgeColor', 'none', ...
                            'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                            'FontSize', 11, 'FontWeight', 'normal');
                    end
                end

                function populateFullPageGrid(fig, spec, composite, entry, scaling, config, gi)
                    % SUB-CONTROLLER: Lay out plates into rows, render each row
                    rowAssignments = layoutPlatesInRows(entry, config);
                    renderAllFullRows(fig, spec, composite, rowAssignments, scaling, config, gi);

                    function rows = layoutPlatesInRows(entry, config)
                        % MODEL: Each row carries up to col_count plate indices, a
                        % sub-category label, and a flag for whether the label
                        % should be drawn (only on the first row of each sub-group). (TERMINAL)
                        rows = struct('label', {}, 'indices', {}, 'showLabel', {});
                        blocks = {entry.standardSubGroups, entry.protocolModSubGroups};
                        for b = 1:length(blocks)
                            sg = blocks{b};
                            for k = 1:length(sg)
                                ncells = length(sg(k).indices);
                                nrows = ceil(ncells / config.col_count);
                                for r = 1:nrows
                                    startIdx = (r-1)*config.col_count + 1;
                                    endIdx = min(r*config.col_count, ncells);
                                    rows(end+1).label = sg(k).label; %#ok<AGROW>
                                    rows(end).indices = sg(k).indices(startIdx:endIdx);
                                    rows(end).showLabel = (r == 1);
                                end
                            end
                        end
                    end

                    function renderAllFullRows(fig, spec, composite, rows, scaling, config, gi)
                        % SUB-CONTROLLER: Per-row rendering loop
                        genotype = config.genotype_order{gi};
                        color = config.colors(genotype);
                        totalRows = length(rows);
                        for r = 1:totalRows
                            renderOneFullRow(fig, spec, composite, rows(r), r, totalRows, color, scaling, config);
                        end

                        function renderOneFullRow(fig, spec, composite, row, rowIdx, totalRows, color, scaling, config)
                            % SUB-CONTROLLER: Render each plate of one row with its
                            % stat block below it; the row's first cell carries
                            % the stat row names.
                            if row.showLabel
                                drawSubGroupLabel(fig, row.label, rowIdx, totalRows, config);
                            end
                            rowLabels = statRowLabels(config, spec.stat_page);
                            for c = 1:length(row.indices)
                                idx = row.indices(c);
                                pos = computeFullCellPosition(rowIdx, c, totalRows, config, spec);
                                ax = createCellAxes(fig, pos);
                                entry = composite(idx);
                                spec.renderer(ax, entry, color, scaling, config);
                                diameter = resolvePlateDiameterMm(entry);
                                cellMeta = makeCellMeta(entry, diameter, config, spec.stat_page);
                                drawCellStatBlock(ax, cellMeta.lines, spec.stat_page, config);
                                if c == 1
                                    drawCellRowLabels(ax, rowLabels, spec.stat_page, config);
                                end
                            end

                            function drawSubGroupLabel(fig, label, rowIdx, totalRows, config)
                                % VIEW: Sub-group label in the left margin, aligned
                                % to the top of the row slot so the lower margin
                                % stays free for the stat row names. (TERMINAL)
                                denom = max(totalRows, config.max_rows);
                                cellH_total = config.grid_h / denom;
                                y_outer = config.grid_y + (denom - rowIdx) * cellH_total;
                                annotation(fig, 'textbox', ...
                                    [config.subgroup_label_x, y_outer, ...
                                     config.subgroup_label_width, cellH_total], ...
                                    'String', label, 'EdgeColor', 'none', ...
                                    'HorizontalAlignment', 'center', ...
                                    'VerticalAlignment', 'top', ...
                                    'FontSize', 9, 'FontWeight', 'bold');
                            end

                            function pos = computeFullCellPosition(rowIdx, colIdx, totalRows, config, spec)
                                % MODEL: Normalized [x y w h] for cell at (rowIdx,
                                % colIdx). Cells sized for max_rows so they stay
                                % uniform across pages; pages with fewer rows leave
                                % bottom whitespace. The bottom of the padded slot
                                % is held for the stat block (one line per per-cell
                                % field of the spec's page type, plus its gap), and
                                % the axes sit on top of it. Photo cells carry no
                                % title, so they take no top padding and leave
                                % image_row_gap_px below the stat block as the gap
                                % to the next row. (TERMINAL)
                                denom = max(totalRows, config.max_rows);
                                cellW_total = config.grid_w / config.col_count;
                                cellH_total = config.grid_h / denom;
                                x_outer = config.grid_x + (colIdx - 1) * cellW_total;
                                y_outer = config.grid_y + (denom - rowIdx) * cellH_total;
                                if isfield(spec, 'cell_pad_x') && isfinite(spec.cell_pad_x)
                                    pad_frac_x = spec.cell_pad_x;
                                else
                                    pad_frac_x = config.cell_pad_x;
                                end
                                if isfield(spec, 'cell_pad_y') && isfinite(spec.cell_pad_y)
                                    pad_frac_y = spec.cell_pad_y;
                                else
                                    pad_frac_y = config.cell_pad_y;
                                end
                                pad_x = pad_frac_x * cellW_total;
                                figH = config.fig_position(4);
                                if strcmp(spec.stat_page, 'image')
                                    padTop = 0;
                                    padBottom = config.image_row_gap_px / figH;
                                else
                                    padTop = pad_frac_y * cellH_total;
                                    padBottom = padTop;
                                end
                                nStatLines = numel(config.cell_fields.(spec.stat_page));
                                if nStatLines > 0
                                    reserve = (config.stat_gap_px.(spec.stat_page) + ...
                                               nStatLines * config.stat_line_px) / figH;
                                else
                                    reserve = 0;
                                end
                                pos = [x_outer + pad_x, y_outer + padBottom + reserve, ...
                                       cellW_total - 2*pad_x, ...
                                       max(cellH_total - padTop - padBottom - reserve, 1 / figH)];
                            end
                        end
                    end
                end
            end

            function fig = buildGenotypeBoxPlotPage(composite, genotypeColumn, scaling, config, gi)
                % SUB-CONTROLLER: One page of box plots for one genotype, one box
                % per plate, grouped by passage with NaN spacer columns. Standard
                % boxes take higher alpha; protocol-mod boxes lower. The per-box
                % summary band sits above the axes, which already reserve its
                % height. The ordinal axis name sits below the passage labels.
                % Flags overlay after axes scale is final; the flag key sits lower
                % left and the block-wide cell field footnote lower right.
                fig = createBoxPlotFigure(config);
                drawFullBoxTitle(fig, config, gi);
                drawFullBoxAxisLabels(fig, config);
                ax = createFullBoxAxes(fig, config);
                [matrix, positionMap, flagInputs] = buildFullBoxMatrix(composite, genotypeColumn);
                drawCompiledBoxPlot(ax, matrix);
                applyFullBoxColoring(ax, positionMap, config, gi);
                configureFullBoxAxes(ax, matrix, scaling, config);
                applyLogRadiusTicks(ax, config);

                if ~isempty(matrix)
                    bandY = computeBoxBandY(scaling, config);
                    drawFullPassageHeaders(ax, positionMap, bandY, config);
                    drawFullBoxXAxisLabel(ax, bandY, config);
                    boxStats = computeBoxColumnStats(matrix, positionMap);
                    drawBoxStatsBand(ax, boxStats, bandY, config);
                end

                marks = detectPlateFlags(flagInputs, scaling, config);
                drawFlagMarks(ax, marks);
                drawFlagLegend(fig, marks, config);
                drawPageFootnote(fig, config.footnote_lines.all, config);

                function drawFullBoxTitle(fig, config, gi)
                    % VIEW: (TERMINAL)
                    genotype = config.genotype_order{gi};
                    label = config.genotype_labels(genotype);
                    color = config.colors(genotype);
                    titleStr = sprintf('%s: Colony Radius by Plate, Across Passages', label);
                    annotation(fig, 'textbox', [0, config.title_y, 1, 0.03], ...
                        'String', titleStr, 'EdgeColor', 'none', ...
                        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                        'FontSize', 14, 'FontWeight', 'bold', 'Color', color);
                end

                function drawFullBoxAxisLabels(fig, config)
                    % VIEW: Micron sign as a literal char(956) under Interpreter
                    % 'none' so it matches the page typeface (TERMINAL)
                    labelText = sprintf('X axis: Passage, Y axis: Colony Radius %sm', char(956));
                    boxWidth = 0.35;
                    boxHeight = 0.025;
                    rightMargin = 0.01;
                    yPos = config.title_y - boxHeight/2;
                    xPos = 1 - rightMargin - boxWidth;
                    annotation(fig, 'textbox', [xPos, yPos, boxWidth, boxHeight], ...
                        'String', labelText, 'EdgeColor', 'none', 'Interpreter', 'none', ...
                        'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle', ...
                        'FontSize', config.box_font, 'FontWeight', 'normal');
                end

                function ax = createFullBoxAxes(fig, config)
                    % VIEW: Single panel axes, shrunk from the top by the summary
                    % band height (TERMINAL)
                    ax = axes('Parent', fig, 'Position', computeBoxAxesRect(config));
                end

                function [matrix, positionMap, flagInputs] = buildFullBoxMatrix(composite, genotypeColumn)
                    % MODEL: Column-major matrix of radii, columns ordered passage
                    % by passage with NaN spacer columns between non-empty passage
                    % blocks. Within each passage block plates are ordered standard
                    % first, then protocol-mod, matching the grid pages. positionMap
                    % carries (col, compositeIdx, passage, isStandard); flagInputs
                    % carries (col, sourceType, plateDiameterMm, maxRadius) per
                    % data column for the flag detector. (TERMINAL)
                    nSpacers = 2;
                    nP = length(genotypeColumn);

                    passageBlocks = cell(nP, 1);
                    maxN = 0;
                    for pi = 1:nP
                        entry = genotypeColumn(pi);
                        [orderedIdx, isStandard] = flattenEntry(entry);
                        radiiList = cell(length(orderedIdx), 1);
                        for k = 1:length(orderedIdx)
                            r = composite(orderedIdx(k)).Measurements.Radius;
                            r = r(isfinite(r) & r > 0);
                            radiiList{k} = r(:);
                            maxN = max(maxN, length(r));
                        end
                        passageBlocks{pi} = struct( ...
                            'indices', orderedIdx, ...
                            'isStandard', isStandard, ...
                            'radii', {radiiList}, ...
                            'passage', entry.passage);
                    end

                    if maxN == 0
                        matrix = [];
                        positionMap = struct('col', {}, 'compositeIdx', {}, ...
                                             'passage', {}, 'isStandard', {});
                        flagInputs = struct('col', {}, 'sourceType', {}, ...
                            'plateDiameterMm', {}, 'maxRadius', {});
                        return;
                    end

                    totalDataCols = 0;
                    nNonEmptyBlocks = 0;
                    for pi = 1:nP
                        if ~isempty(passageBlocks{pi}.indices)
                            totalDataCols = totalDataCols + length(passageBlocks{pi}.indices);
                            nNonEmptyBlocks = nNonEmptyBlocks + 1;
                        end
                    end
                    nCols = totalDataCols + max(nNonEmptyBlocks - 1, 0) * nSpacers;

                    matrix = nan(maxN, nCols);
                    positionMap = struct('col', {}, 'compositeIdx', {}, ...
                                         'passage', {}, 'isStandard', {});
                    flagInputs = struct('col', {}, 'sourceType', {}, ...
                        'plateDiameterMm', {}, 'maxRadius', {});
                    col = 1;
                    firstBlock = true;
                    for pi = 1:nP
                        block = passageBlocks{pi};
                        if isempty(block.indices)
                            continue;
                        end
                        if ~firstBlock
                            col = col + nSpacers;
                        end
                        firstBlock = false;
                        for k = 1:length(block.indices)
                            radii = block.radii{k};
                            if ~isempty(radii)
                                matrix(1:length(radii), col) = radii;
                            end
                            idx = block.indices(k);
                            positionMap(end+1) = struct( ...
                                'col', col, ...
                                'compositeIdx', idx, ...
                                'passage', block.passage, ...
                                'isStandard', block.isStandard(k)); %#ok<AGROW>
                            e = composite(idx);
                            if isfield(e, 'source_type')
                                st = e.source_type;
                            else
                                st = '';
                            end
                            if isempty(radii)
                                mr = NaN;
                            else
                                mr = max(radii);
                            end
                            flagInputs(end+1) = struct('col', col, ...
                                'sourceType', st, ...
                                'plateDiameterMm', resolvePlateDiameterMm(e), ...
                                'maxRadius', mr); %#ok<AGROW>
                            col = col + 1;
                        end
                    end

                    function [idxList, isStdList] = flattenEntry(entry)
                        idxList = [];
                        isStdList = [];
                        for kk = 1:length(entry.standardSubGroups)
                            ix = entry.standardSubGroups(kk).indices(:);
                            idxList = [idxList; ix]; %#ok<AGROW>
                            isStdList = [isStdList; true(length(ix), 1)]; %#ok<AGROW>
                        end
                        for kk = 1:length(entry.protocolModSubGroups)
                            ix = entry.protocolModSubGroups(kk).indices(:);
                            idxList = [idxList; ix]; %#ok<AGROW>
                            isStdList = [isStdList; false(length(ix), 1)]; %#ok<AGROW>
                        end
                    end
                end

                function applyFullBoxColoring(ax, positionMap, config, gi)
                    % VIEW: All boxes use the genotype color; standard plates take
                    % higher alpha, protocol-mod plates lower alpha (TERMINAL)
                    if isempty(positionMap), return; end
                    genotype = config.genotype_order{gi};
                    color = config.colors(genotype);
                    colToInfo = containers.Map('KeyType', 'int32', 'ValueType', 'any');
                    for i = 1:length(positionMap)
                        pe = positionMap(i);
                        if pe.isStandard
                            a = config.standard_box_alpha;
                        else
                            a = config.protocol_mod_box_alpha;
                        end
                        colToInfo(int32(pe.col)) = struct('color', color, 'alpha', a);
                    end

                    lineObjects = findobj(ax, 'Type', 'line');
                    for i = 1:length(lineObjects)
                        try
                            xData = get(lineObjects(i), 'XData');
                            if isempty(xData), continue; end
                            col = round(xData(1));
                            if ~isKey(colToInfo, int32(col)), continue; end
                            info = colToInfo(int32(col));
                            darkEdge = max(info.color * 0.4, 0);
                            tag = get(lineObjects(i), 'Tag');
                            if strcmp(tag, 'Outliers')
                                set(lineObjects(i), 'Color', info.color, ...
                                    'MarkerFaceColor', info.color, ...
                                    'MarkerEdgeColor', darkEdge);
                            elseif strcmp(tag, 'MedianInner') || strcmp(tag, 'MedianOuter')
                                set(lineObjects(i), 'Color', info.color, ...
                                    'MarkerFaceColor', 'white', ...
                                    'MarkerEdgeColor', darkEdge, 'LineWidth', 1.5);
                            else
                                set(lineObjects(i), 'Color', info.color);
                            end
                        catch
                            continue;
                        end
                    end

                    patchObjects = findobj(ax, 'Type', 'patch');
                    for j = 1:length(patchObjects)
                        try
                            vertices = get(patchObjects(j), 'Vertices');
                            if isempty(vertices), continue; end
                            col = round(mean(vertices(:, 1)));
                            if ~isKey(colToInfo, int32(col)), continue; end
                            info = colToInfo(int32(col));
                            set(patchObjects(j), 'FaceColor', info.color, ...
                                'FaceAlpha', info.alpha);
                        catch
                            continue;
                        end
                    end
                end

                function configureFullBoxAxes(ax, matrix, scaling, config)
                    % VIEW: The y label is set after the axes FontSize, since setting
                    % the axes FontSize resizes existing labels. Y ticks are set
                    % afterwards by applyLogRadiusTicks. (TERMINAL)
                    if isempty(matrix), return; end
                    set(ax, 'YScale', 'log');
                    ylim(ax, scaling.x_um_extent);
                    set(ax, 'XTickLabel', '');
                    xlim(ax, [0, size(matrix, 2) + 1]);
                    set(ax, 'FontSize', config.box_font);
                    ylabel(ax, ['Colony Radius (' char(956) 'm)'], ...
                        'Interpreter', 'none', 'FontSize', config.box_axis_name_font);
                    box(ax, 'on');
                    grid(ax, 'on');
                end

                function drawFullPassageHeaders(ax, positionMap, bandY, config)
                    % VIEW: One passage label centered under each passage group,
                    % drawn in the box axes at the group's center column so it
                    % stays over its boxes. Clipping is off because the label sits
                    % below the bottom limit. (TERMINAL)
                    if isempty(positionMap), return; end
                    cols = [positionMap.col];
                    passages = [positionMap.passage];
                    uniqueP = unique(passages, 'stable');

                    hold(ax, 'on');
                    for pi = 1:length(uniqueP)
                        p = uniqueP(pi);
                        mask = passages == p;
                        pcols = cols(mask);
                        centerCol = (min(pcols) + max(pcols)) / 2;
                        text(ax, centerCol, bandY.passageLabel, sprintf('P%d', p), ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle', ...
                            'FontSize', config.box_font, 'FontWeight', 'bold', ...
                            'Clipping', 'off');
                    end
                    hold(ax, 'off');
                end

                function drawFullBoxXAxisLabel(ax, bandY, config)
                    % VIEW: Ordinal axis name centered under the box axes, below
                    % the passage labels, drawn as in-axes text at bandY.axisLabel
                    % with clipping off. Interpreter 'none' prints underscores
                    % literally. (TERMINAL)
                    xl = get(ax, 'XLim');
                    hold(ax, 'on');
                    text(ax, mean(xl), bandY.axisLabel, config.ordinal_axis_label, ...
                        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                        'FontSize', config.box_axis_name_font, 'FontWeight', 'normal', ...
                        'Interpreter', 'none', 'Clipping', 'off');
                    hold(ax, 'off');
                end
            end
        end
    end

    % ============================================================
    % SHARED FUNCTIONS (used by both pipelines)
    % ============================================================
    function ordered = applyNominalOrder(nominal_order, axisSpec, nominal_labels)
        % MODEL: Reorder the nominal keys by display preference (relative, so
        % missing keys leave no gap). Matching is done on a normalized form of each
        % key, lowercased with every non-alphanumeric character removed, so the
        % file-safe keys ('Wild_Type', 'cdc132', 'rif1_cdc132') compare equal to the
        % readable spellings ('wild_type', 'cdc13-2', 'rif1Δ, cdc13-2'); the
        % defaults therefore match either convention with no reconfiguration.
        %
        % Three modes. When axisSpec.NominalOrder is a non-empty list it sets
        % explicit left-to-right priority: present keys are placed in that order
        % (compared normalized, so the list may be written readably), then any key
        % not on the list trails in first-appearance order. Otherwise a numeric
        % nominal (keys printed by normalizeAxes) sorts ascending by value. Otherwise
        % the structural rule reproduces the reader's arc, wild type, then the
        % non-anchor single mutant, then the anchor (senescent) single, then the
        % double: keys sort by (wild type first), then mutation count, then anchor
        % membership within a tier (non-anchor before anchor), with first-appearance
        % as the final tiebreak.
        %
        % Composition is read from the key and from its display label, each split
        % on underscores and commas (so 'rif1_cdc132' is two mutations and 'rif1'
        % is one), then normalized per token for the anchor test. The mutation
        % count is the larger of the two readings and the anchor counts if either
        % carries it, so an opaque key such as 'double' labeled 'dbf4-1, cdc13-2'
        % sorts as the anchor double. A label can only raise a key's count, so
        % datasets whose keys already carry their composition keep their order.
        % Wild type is matched against the whole normalized key or label, because
        % its underscore ('Wild_Type') is part of the name and not a mutation
        % separator. An opaque key with no informative label still needs an
        % explicit NominalOrder. nominal_labels is optional. (TERMINAL)
        n = numel(nominal_order);
        if n <= 1
            ordered = nominal_order;
            return;
        end

        normalize = @(s) regexprep(lower(char(s)), '[^a-z0-9]', '');

        primary = zeros(n, 1);
        secondary = zeros(n, 1);
        tertiary = (1:n)';   % first-appearance tiebreak (unique, so order is total)

        useExplicit = isfield(axisSpec, 'NominalOrder') && ~isempty(axisSpec.NominalOrder);
        useNumeric = ~useExplicit && isfield(axisSpec, 'NominalIsNumeric') && ...
                     axisSpec.NominalIsNumeric;

        if useExplicit
            prefList = axisSpec.NominalOrder;
            prefNorm = cell(1, numel(prefList));
            for p = 1:numel(prefList)
                prefNorm{p} = normalize(prefList{p});
            end
            for i = 1:n
                keyNorm = normalize(nominal_order{i});
                pos = find(strcmp(prefNorm, keyNorm), 1);
                if isempty(pos)
                    primary(i) = numel(prefList) + 1;   % unlisted keys after listed
                else
                    primary(i) = pos;
                end
            end
        elseif useNumeric
            values = str2double(nominal_order(:));
            values(isnan(values)) = Inf;              % missing values sort last
            primary = values;
        else
            wtNorm = normalize(axisSpec.WildTypeToken);
            anchorNorm = normalize(axisSpec.AnchorGene);
            hasLabels = nargin >= 3 && isa(nominal_labels, 'containers.Map');
            for i = 1:n
                key = char(nominal_order{i});
                readings = {key};
                if hasLabels && isKey(nominal_labels, key)
                    readings{end+1} = char(nominal_labels(key)); %#ok<AGROW>
                end

                isWildType = false;
                for s = 1:numel(readings)
                    if strcmp(normalize(readings{s}), wtNorm)
                        isWildType = true;
                    end
                end

                if isWildType
                    primary(i) = 0;                   % wild type first
                    secondary(i) = 0;
                else
                    count = 0;
                    hasAnchor = false;
                    for s = 1:numel(readings)
                        rawTokens = strsplit(readings{s}, {'_', ','});
                        readingCount = 0;
                        for t = 1:numel(rawTokens)
                            tok = strtrim(rawTokens{t});
                            if isempty(tok)
                                continue;
                            end
                            readingCount = readingCount + 1;
                            if strcmp(normalize(tok), anchorNorm)
                                hasAnchor = true;
                            end
                        end
                        count = max(count, readingCount);
                    end
                    if count == 0
                        count = 1;
                    end
                    primary(i) = count;               % singles before doubles
                    secondary(i) = double(hasAnchor); % within a tier, anchor sorts later
                end
            end
        end

        [~, idx] = sortrows([primary, secondary, tertiary]);
        ordered = nominal_order(idx);
    end

    function rect = computeBoxAxesRect(config)
        % MODEL: Normalized [x y w h] for a box plot axes on either pipeline. The
        % bottom edge and width come from the mode's grid margins; the height is
        % the grid height less the mode's shrink and less the summary band, so a
        % strip immediately above the axes top is left free for the summary rows.
        % This reserves the room; it does not place the rows, which are drawn in
        % axes coordinates because boxplot adjusts the axes after this rectangle is
        % applied. (TERMINAL)
        rect = [config.grid_x, ...
                config.grid_y + config.box_axes_y_offset, ...
                config.grid_w, ...
                config.grid_h - config.box_axes_h_shrink - config.box_stats_band_h];
    end

    function stats = computeBoxColumnStats(matrix, positionMap)
        % MODEL: Per-box colony count and median radius, read off the plotted
        % matrix, so the numbers describe exactly the values the box summarizes
        % (the builders already dropped non-finite and non-positive radii). A
        % column whose plate carries no colonies returns n = 0 and a NaN median,
        % which the band renders as a dash. Spacer columns hold no positionMap
        % record and are skipped. Serves both pipelines, since both positionMaps
        % carry a col field. (TERMINAL)
        stats = struct('col', {}, 'n', {}, 'medianRadius', {});
        if isempty(matrix) || isempty(positionMap)
            return;
        end
        for i = 1:numel(positionMap)
            c = positionMap(i).col;
            if c < 1 || c > size(matrix, 2)
                continue;
            end
            colVals = matrix(:, c);
            colVals = colVals(isfinite(colVals));
            if isempty(colVals)
                stats(end+1) = struct('col', c, 'n', 0, 'medianRadius', NaN); %#ok<AGROW>
            else
                stats(end+1) = struct('col', c, 'n', numel(colVals), ...
                    'medianRadius', median(colVals)); %#ok<AGROW>
            end
        end
    end

    function bandY = computeBoxBandY(scaling, config)
        % MODEL: Y coordinates, in linear microns, for everything a box plot page
        % draws outside its axes limits: the two summary rows and the group label
        % above the top, the passage label below the bottom, and the ordinal axis
        % label below the passage label. Each is expressed first as a fraction of
        % the axes height, then mapped through the log scale by
        % exp(logBottom + f*span), so a fraction above 1 lands above the top limit
        % and a negative fraction lands below the bottom. The axis label drop is
        % measured from the passage label, so box_axis_label_drop is the gap
        % between the two and the label clears the tick labels on selected pages
        % and the passage labels on full pages. These labels are placed in axes
        % coordinates because boxplot adjusts the axes after computeBoxAxesRect is
        % applied, so the predicted rectangle is not the drawn one, and text in
        % data coordinates stays over its boxes regardless. (TERMINAL)
        axesH = config.grid_h - config.box_axes_h_shrink - config.box_stats_band_h;
        rowFrac = config.box_stats_row_h / axesH;
        gapFrac = config.box_stats_gap / axesH;
        logBottom = scaling.x_log_extent(1);
        span = scaling.x_log_extent(2) - scaling.x_log_extent(1);

        fCount   = 1 + gapFrac + 1.5 * rowFrac;
        fMedian  = 1 + gapFrac + 0.5 * rowFrac;
        fGroup   = 1 + gapFrac + 2.7 * rowFrac;
        fPassage = -config.box_passage_label_drop / axesH;
        fAxis    = -(config.box_passage_label_drop + config.box_axis_label_drop) / axesH;

        bandY = struct( ...
            'count',        exp(logBottom + fCount * span), ...
            'median',       exp(logBottom + fMedian * span), ...
            'groupLabel',   exp(logBottom + fGroup * span), ...
            'passageLabel', exp(logBottom + fPassage * span), ...
            'axisLabel',    exp(logBottom + fAxis * span));
    end

    function drawBoxStatsBand(ax, stats, bandY, config)
        % SUB-CONTROLLER: Draw the two-row summary strip above the box axes, count
        % on the upper row and median radius on the lower. Everything is drawn into
        % the box axes at data coordinates with clipping off, so each number sits on
        % the same ruler as the box it describes. Both rows read as one flat line,
        % since their y values are fixed for the page.
        if isempty(stats)
            return;
        end
        drawBoxStatsValues(ax, stats, bandY, config);
        drawBoxStatsRowLabels(ax, bandY, config);

        function drawBoxStatsValues(ax, stats, bandY, config)
            % VIEW: One count and one median per data column, centered on the
            % column's own x coordinate. Medians print as whole microns; a column
            % whose plate carries no colonies prints the empty mark. (TERMINAL)
            hold(ax, 'on');
            for i = 1:numel(stats)
                if stats(i).n > 0
                    countStr = sprintf('%d', stats(i).n);
                else
                    countStr = config.box_stats_empty_mark;
                end
                if isfinite(stats(i).medianRadius)
                    medianStr = sprintf('%d', round(stats(i).medianRadius));
                else
                    medianStr = config.box_stats_empty_mark;
                end
                text(ax, stats(i).col, bandY.count, countStr, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', config.box_stats_font, ...
                    'Rotation', config.box_stats_rotation, ...
                    'Interpreter', 'none', 'Clipping', 'off');
                text(ax, stats(i).col, bandY.median, medianStr, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', config.box_stats_font, ...
                    'Rotation', config.box_stats_rotation, ...
                    'Interpreter', 'none', 'Clipping', 'off');
            end
            hold(ax, 'off');
        end

        function drawBoxStatsRowLabels(ax, bandY, config)
            % VIEW: Name the two rows to the left of the first column, right-aligned
            % so they read into the numbers. Drawn in the same axes at a negative x
            % so they stay level with their row no matter where the axes sits in the
            % figure. (TERMINAL)
            xLabel = -config.box_stats_label_offset;
            rowLabels = {'n', ['Median ' char(956) 'm']};
            rowValues = [bandY.count, bandY.median];
            hold(ax, 'on');
            for i = 1:numel(rowLabels)
                text(ax, xLabel, rowValues(i), rowLabels{i}, ...
                    'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle', ...
                    'FontSize', config.box_stats_font, 'FontWeight', 'normal', ...
                    'Interpreter', 'none', 'Clipping', 'off');
            end
            hold(ax, 'off');
        end
    end

    function applyLogRadiusTicks(ax, config)
        % VIEW: Replace the log scale's decade ticks with the requested radius
        % values. Only ticks inside the current limits are kept, so the axes stay
        % tied to the scaling shared with the distribution pages. Minor ticks and
        % minor grid are turned off, or a sub-decade log axis draws unlabeled marks
        % between the requested values. (TERMINAL)
        lims = get(ax, 'YLim');
        ticks = config.y_ticks_um;
        ticks = ticks(ticks >= lims(1) & ticks <= lims(2));
        if isempty(ticks)
            return;
        end
        labels = arrayfun(@(v) sprintf('%d', round(v)), ticks, ...
            'UniformOutput', false);
        set(ax, 'YTick', ticks, 'YTickLabel', labels, ...
            'YMinorTick', 'off', 'YMinorGrid', 'off');
    end

    function scaling = computeGlobalScaling(validEntries, config)
        % SUB-CONTROLLER: Compute shared x extent, bin edges, and y density max
        % across a cell array of entry structs. Each entry exposes kde,
        % Measurements, and full_colony_set; missing fields are guarded so the
        % same routine serves a selected dataset and a full composite.
        scaling.x_log_extent = computeXLogExtent(validEntries, config);
        scaling.x_um_extent = exp(scaling.x_log_extent);
        scaling.log_bin_edges = computeLogBinEdges(scaling.x_log_extent, config);
        scaling.bin_edges_um = exp(scaling.log_bin_edges);
        scaling.delta_log = scaling.log_bin_edges(2) - scaling.log_bin_edges(1);
        scaling.fine_x_log = linspace(scaling.x_log_extent(1), scaling.x_log_extent(2), 400);
        scaling.fine_x_um = exp(scaling.fine_x_log);
        scaling.y_density_max = computeYDensityMax(validEntries, scaling, config);

        function ext = computeXLogExtent(validEntries, config)
            % MODEL: X extent = union of KDE eval grids, padded in log-space (TERMINAL)
            xMin = +inf;
            xMax = -inf;
            for k = 1:numel(validEntries)
                e = validEntries{k};
                if isfield(e, 'kde') && isfield(e.kde, 'eval_x_log') && ~isempty(e.kde.eval_x_log)
                    xMin = min(xMin, min(e.kde.eval_x_log));
                    xMax = max(xMax, max(e.kde.eval_x_log));
                end
            end
            if ~isfinite(xMin) || ~isfinite(xMax)
                xMin = log(10);
                xMax = log(2000);
            end
            ext = [xMin - config.x_pad_log, xMax + config.x_pad_log];
        end

        function edges = computeLogBinEdges(extent, config)
            % MODEL: Equal-width bin edges in log-space (TERMINAL)
            edges = linspace(extent(1), extent(2), config.n_bins + 1);
        end

        function ymax = computeYDensityMax(validEntries, scaling, config)
            % MODEL: Max log-density across hist, KDE, LMM components, and LMM sum.
            % GMM_mu is the LogNormal median in linear-um, so it is log-transformed
            % before evaluation as a normal pdf over log-radius. (TERMINAL)
            ymax = 0;
            for k = 1:numel(validEntries)
                e = validEntries{k};

                if isfield(e, 'kde') && isfield(e.kde, 'density') && ~isempty(e.kde.density)
                    ymax = max(ymax, max(e.kde.density));
                end

                radii = e.Measurements.Radius;
                radii = radii(isfinite(radii) & radii > 0);
                if ~isempty(radii)
                    counts = histcounts(log(radii), scaling.log_bin_edges);
                    nT = length(radii);
                    ymax = max(ymax, max(counts / (nT * scaling.delta_log)));
                end

                hasLMM = isfield(e, 'full_colony_set') && ...
                    isfield(e.full_colony_set, 'alternative_fits') && ...
                    isfield(e.full_colony_set.alternative_fits, 'LogNormal');
                if hasLMM
                    alt = e.full_colony_set.alternative_fits.LogNormal;
                    mu_linear = alt.gmm_results.fitted_model.GMM_mu(:);
                    sigma = alt.gmm_results.fitted_model.GMM_sigma(:);
                    w = alt.gmm_results.fitted_model.GMM_weights(:);
                    if isempty(mu_linear), continue; end
                    mu_log = log(mu_linear);
                    sumD = zeros(size(scaling.fine_x_log));
                    for c = 1:length(w)
                        compD = w(c) * normpdf(scaling.fine_x_log, mu_log(c), sigma(c));
                        sumD = sumD + compD;
                        ymax = max(ymax, max(compD));
                    end
                    ymax = max(ymax, max(sumD));
                end
            end
            ymax = ymax * config.y_headroom_factor;
        end
    end

    function fig = createPageFigure(spec, config)
        % VIEW: Open figure window for one grid page. The Default*FontName
        % properties set the typeface for every axes, text, and annotation textbox
        % created into this figure, so no downstream view passes a font. (TERMINAL)
        fig = figure('Name', spec.title, 'NumberTitle', 'off', ...
            'Position', config.fig_position, 'Color', 'w', ...
            'Visible', 'off', 'PaperPositionMode', 'auto', ...
            'DefaultAxesFontName', config.font_name, ...
            'DefaultTextFontName', config.font_name, ...
            'DefaultTextboxshapeFontName', config.font_name, ...
            'DefaultTextarrowshapeFontName', config.font_name);
    end

    function fig = createBoxPlotFigure(config)
        % VIEW: Open figure window for a box plot page, with the same typeface
        % defaults as a grid page (TERMINAL)
        fig = figure('Name', 'Box Plot Page', 'NumberTitle', 'off', ...
            'Position', config.fig_position, 'Color', 'w', ...
            'Visible', 'off', 'PaperPositionMode', 'auto', ...
            'DefaultAxesFontName', config.font_name, ...
            'DefaultTextFontName', config.font_name, ...
            'DefaultTextboxshapeFontName', config.font_name, ...
            'DefaultTextarrowshapeFontName', config.font_name);
    end

    function ax = createCellAxes(fig, pos)
        % VIEW: Axes at the specified normalized position (TERMINAL)
        ax = axes('Parent', fig, 'Position', pos);
    end

    function addAxisLabels(fig, yPos)
        % VIEW: Top-right annotation describing the cell axes, vertically centered
        % at yPos so it sits level with the page title or subtitle. The micron sign
        % is a literal char(956) under Interpreter 'none' so it is drawn in the page
        % typeface. (TERMINAL)
        labelText = sprintf('X axis: Colony Radius %sm, Y axis: Density', char(956));
        boxWidth = 0.35;
        boxHeight = 0.03;
        rightMargin = 0.01;
        xPos = 1 - rightMargin - boxWidth;
        annotation(fig, 'textbox', [xPos, yPos, boxWidth, boxHeight], ...
            'String', labelText, 'EdgeColor', 'none', 'Interpreter', 'none', ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle', ...
            'FontSize', 9, 'FontWeight', 'normal');
    end

    function drawPageFootnote(fig, footLines, config)
        % VIEW: Block-wide cell fields, one line each, stacked upward from
        % config.footnote_y at the lower right of the page, right-aligned so the
        % lines end flush with the page margin. The caller passes the lines for
        % its page type (image, distribution, or all for box plot pages). The
        % lower left stays free for the flag key on box plot pages. Draws nothing
        % when there are no lines. Interpreter 'none' prints field values
        % literally. (TERMINAL)
        if isempty(footLines)
            return;
        end
        nLines = numel(footLines);
        for i = 1:nLines
            y = config.footnote_y + (nLines - i) * config.footnote_line_h;
            annotation(fig, 'textbox', ...
                [config.footnote_x, y, config.footnote_w, config.footnote_line_h], ...
                'String', footLines{i}, 'EdgeColor', 'none', 'Interpreter', 'none', ...
                'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle', ...
                'FontSize', config.footnote_font, 'FontWeight', 'normal');
        end
    end

    function exportPageToPDF(fig, outputPath, pageNum)
        % VIEW: Export one figure to PDF; append after the first page. Padding
        % 'figure' sizes every page to the figure rectangle (config.fig_position),
        % so pages whose content extends past their axes (box plot summary band,
        % row labels, flag glyphs, legend, axis labels) export at the same
        % dimensions as the grid pages. Without it, exportgraphics crops each page
        % to its own content bounds, and appended pages disagree in size. Any
        % unclipped text placed outside the figure is cut at the page edge.
        % Requires R2021b or later. (TERMINAL)
        if pageNum == 1
            exportgraphics(fig, outputPath, 'ContentType', 'vector', ...
                'Padding', 'figure');
        else
            exportgraphics(fig, outputPath, 'ContentType', 'vector', ...
                'Padding', 'figure', 'Append', true);
        end
    end

    function d = resolvePlateDiameterMm(entry)
        % MODEL: Plate diameter in mm from whichever shape the entry uses. A
        % selected dataset entry stores plate_diameter_mm directly; a full
        % composite entry stores plate_type.plate_radius_cm (radius cm to
        % diameter mm via x20). Returns NaN when neither is available. (TERMINAL)
        if isfield(entry, 'plate_diameter_mm') && ~isempty(entry.plate_diameter_mm)
            d = entry.plate_diameter_mm;
        elseif isfield(entry, 'plate_type') && isstruct(entry.plate_type) && ...
                isfield(entry.plate_type, 'plate_radius_cm') && ...
                ~isempty(entry.plate_type.plate_radius_cm)
            d = entry.plate_type.plate_radius_cm * 20;
        else
            d = NaN;
        end
    end

    function txt = cellFieldText(entry, field, plateDiameterMm, missingTokens)
        % MODEL: Display text for one registry field of one entry, or '' when
        % the value is missing. Each path in field.paths is walked through nested
        % structs; a path that breaks (absent field, non-scalar struct) reads as
        % missing. The path {'plate_diameter_mm'} takes the diameter from the
        % caller, since entries store it in two shapes. Formatting follows
        % field.kind:
        %   count     whole number             77
        %   percent   fraction as percent      16.7%
        %   um        whole microns            507 um (micron sign)
        %   um_range  two paths, whole microns 457-606 um
        %   mm        millimeters              90 mm
        %   text      number with %g, or trimmed text
        % Every numeric kind requires finite numeric scalars on all its paths,
        % so text such as 'N/A' reads as missing there. For text, a value
        % matching a missing token case-insensitively ('N/A', 'NA', 'NaN',
        % 'none', blank) reads as missing. Shared by the stat field classifier
        % and the per-cell metadata builder. (TERMINAL)
        mu = char(956);
        nPaths = numel(field.paths);
        values = cell(1, nPaths);
        for p = 1:nPaths
            path = field.paths{p};
            if isequal(path, {'plate_diameter_mm'})
                v = plateDiameterMm;
            else
                v = entry;
                for s = 1:numel(path)
                    if isstruct(v) && isscalar(v) && isfield(v, path{s})
                        v = v.(path{s});
                    else
                        v = [];
                        break;
                    end
                end
            end
            values{p} = v;
        end

        isFiniteScalar = @(x) (isnumeric(x) || islogical(x)) && isscalar(x) && isfinite(double(x));

        txt = '';
        switch field.kind
            case 'text'
                v = values{1};
                if isFiniteScalar(v)
                    txt = sprintf('%g', double(v));
                elseif ischar(v) && (isrow(v) || isempty(v))
                    txt = strtrim(v);
                elseif isstring(v) && isscalar(v) && ~ismissing(v)
                    txt = strtrim(char(v));
                end
                if any(strcmpi(txt, missingTokens))
                    txt = '';
                end
            otherwise
                if ~all(cellfun(isFiniteScalar, values))
                    return;
                end
                nums = cellfun(@double, values);
                switch field.kind
                    case 'count'
                        txt = sprintf('%d', round(nums(1)));
                    case 'percent'
                        txt = sprintf('%.1f%%', 100 * nums(1));
                    case 'um'
                        txt = sprintf('%d %sm', round(nums(1)), mu);
                    case 'um_range'
                        txt = sprintf('%d-%d %sm', round(nums(1)), round(nums(2)), mu);
                    case 'mm'
                        txt = sprintf('%g mm', nums(1));
                end
        end
    end

    function cm = makeCellMeta(entry, plateDiameterMm, config, pageType)
        % SUB-CONTROLLER: Build the stat block for one entry from the block's
        % per-cell fields of one page type (config.cell_fields.(pageType)), in
        % registry order. Each field is reduced to display text, then composed
        % into lines. Built identically from a selected dataset entry or a full
        % composite entry. Diameter is resolved by the caller and passed in.
        registry = config.cell_field_registry;
        shown = registry(ismember({registry.key}, config.cell_fields.(pageType)));
        texts = cell(numel(shown), 1);
        for k = 1:numel(shown)
            texts{k} = cellFieldText(entry, shown(k), plateDiameterMm, config.missing_tokens);
        end
        cm = composeStatLines(texts, config);

        function cm = composeStatLines(texts, config)
            % MODEL: One line per shown field, in order. A field missing on this
            % entry prints the empty mark (en dash), so every line stays level
            % with its row name in the left margin. (TERMINAL)
            lines = texts;
            for k = 1:numel(lines)
                if isempty(lines{k})
                    lines{k} = config.box_stats_empty_mark;
                end
            end
            cm = struct('lines', {lines});
        end
    end

    function labels = statRowLabels(config, pageType)
        % MODEL: Row names for the stat block of one page type, in the same
        % registry order makeCellMeta uses for the values, so each name lines up
        % with its value line. (TERMINAL)
        registry = config.cell_field_registry;
        shown = registry(ismember({registry.key}, config.cell_fields.(pageType)));
        labels = {shown.label}';
    end

    function drawCellStatBlock(ax, lines, pageType, config)
        % VIEW: The cell's stat values as one multi-line text object, centered
        % under the axes and top-aligned one gap below its bottom edge. Placed in
        % the axes' normalized units with clipping off, so it follows the axes
        % through any image fit; the gap is converted from pixels by the axes
        % height and clears the x tick labels on distribution pages. The row
        % names use the same font and top, so the lines match them one to one.
        % (TERMINAL)
        if isempty(lines)
            return;
        end
        pos = get(ax, 'Position');
        axesHpx = pos(4) * config.fig_position(4);
        yTop = -config.stat_gap_px.(pageType) / axesHpx;
        text(ax, 0.5, yTop, lines, 'Units', 'normalized', ...
            'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', ...
            'FontSize', config.stat_font, 'Interpreter', 'none', 'Clipping', 'off');
    end

    function drawCellRowLabels(ax, labels, pageType, config)
        % VIEW: The stat row names as one gray multi-line text object,
        % right-aligned just left of the axes and top-aligned at the stat block's
        % top, so each name sits level with its value line. Drawn into the first
        % cell of each page row, in the axes' normalized units with clipping off.
        % (TERMINAL)
        if isempty(labels)
            return;
        end
        pos = get(ax, 'Position');
        axesWpx = pos(3) * config.fig_position(3);
        axesHpx = pos(4) * config.fig_position(4);
        xRight = -config.stat_label_gap_px / axesWpx;
        yTop = -config.stat_gap_px.(pageType) / axesHpx;
        text(ax, xRight, yTop, labels, 'Units', 'normalized', ...
            'HorizontalAlignment', 'right', 'VerticalAlignment', 'top', ...
            'FontSize', config.stat_font, 'Color', config.stat_label_color, ...
            'Interpreter', 'none', 'Clipping', 'off');
    end

    function fitAxesToImage(ax, img, config)
        % VIEW: Shrink the axes to the image aspect inside its current rectangle,
        % keeping the bottom edge fixed and centering horizontally. imshow holds
        % the image aspect inside whatever box it gets, so an axes of a different
        % aspect draws the photo with an empty band beside or above it; fitting
        % the axes puts the photo's edges on the axes edges. The fixed bottom
        % keeps the stat block directly under the photo and level across a page
        % row. (TERMINAL)
        if isempty(img)
            return;
        end
        pos = get(ax, 'Position');
        figW = config.fig_position(3);
        figH = config.fig_position(4);
        wPx = pos(3) * figW;
        hPx = pos(4) * figH;
        imgAspect = size(img, 2) / size(img, 1);
        if wPx / hPx > imgAspect
            newWpx = hPx * imgAspect;
            pos(1) = pos(1) + (wPx - newWpx) / 2 / figW;
            pos(3) = newWpx / figW;
        else
            pos(4) = (wPx / imgAspect) / figH;
        end
        set(ax, 'Position', pos);
    end

    function gray = convertToGrayscale(img)
        % MODEL: RGB to grayscale, passthrough if already gray (TERMINAL)
        if size(img, 3) == 3
            gray = rgb2gray(img);
        else
            gray = img;
        end
    end

    function dens = computeHistDensity(entry, scaling)
        % MODEL: Log-space density per bin from radius measurements (TERMINAL)
        radii = entry.Measurements.Radius;
        radii = radii(isfinite(radii) & radii > 0);
        nT = length(radii);
        if nT == 0
            dens = zeros(1, length(scaling.log_bin_edges) - 1);
            return;
        end
        counts = histcounts(log(radii), scaling.log_bin_edges);
        dens = counts / (nT * scaling.delta_log);
    end

    function drawDensityBars(ax, bin_edges_um, density, color, alpha)
        % VIEW: Histogram bars with explicit bin heights, log-axis safe (TERMINAL)
        histogram(ax, 'BinEdges', bin_edges_um, 'BinCounts', density, ...
            'FaceColor', color, 'FaceAlpha', alpha, 'EdgeColor', 'none');
    end

    function configureDistributionAxes(ax, scaling)
        % VIEW: Log-x scale and shared x/y limits for a distribution panel (TERMINAL)
        set(ax, 'XScale', 'log');
        xlim(ax, scaling.x_um_extent);
        ylim(ax, [0, scaling.y_density_max]);
        box(ax, 'on');
        set(ax, 'FontSize', 7);
    end

    function drawCompiledBoxPlot(ax, matrix)
        % VIEW: Draw the compact-style box plot on the matrix (TERMINAL)
        if isempty(matrix)
            text(ax, 0.5, 0.5, 'No data', 'Units', 'normalized', ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                'FontSize', 12, 'Color', [0.5 0.5 0.5]);
            set(ax, 'XTick', [], 'YTick', [], 'Box', 'on');
            return;
        end
        boxplot(ax, matrix, 'PlotStyle', 'compact');
    end

    function marks = detectPlateFlags(flagInputs, scaling, config)
        % MODEL: Evaluate two independent flag rules per box and resolve each
        % fired event to a positioned mark. Rule 1 (enrichment, tier 1):
        % source_type present and not 'Standard', registry symbol/label/color
        % with a default for unlisted types. Rule 2 (size, tier 2): plate
        % diameter == 140 mm. A box that trips both yields two marks stacked by
        % tier. Spacing is a fraction of the axis log-span so the visual gap is
        % constant regardless of how wide the radius range is: the lowest tier
        % sits one clearance above the box top, each higher tier one gap above
        % the previous. If the full-gap stack would clear the axis ceiling the gap
        % is compressed toward a glyph-height floor, so marks never overlap each
        % other and never drop into the data; a very tall double-flagged box keeps
        % its separation and may ride slightly into the summary band. Returns a
        % struct array (x, y, symbol, eventKey, label, color, tier); empty when
        % nothing fires. (TERMINAL)
        marks = struct('x', {}, 'y', {}, 'symbol', {}, 'eventKey', {}, ...
                       'label', {}, 'color', {}, 'tier', {});
        if isempty(flagInputs)
            return;
        end
        span = scaling.x_log_extent(2) - scaling.x_log_extent(1);
        clearance = config.flag_clearance_frac * span;
        gap = config.flag_gap_frac * span;
        minGap = config.flag_min_gap_frac * span;
        ceilingLog = log(scaling.x_um_extent(2) * config.flag_clamp_factor);

        for bi = 1:length(flagInputs)
            fin = flagInputs(bi);
            if ~isfinite(fin.maxRadius) || fin.maxRadius <= 0
                continue;
            end

            firedSymbol = {};
            firedKey = {};
            firedLabel = {};
            firedColor = {};
            firedTier = [];

            st = fin.sourceType;
            if ~isempty(st) && ~strcmp(st, 'Standard')
                if isKey(config.flagMarks, st)
                    spec = config.flagMarks(st);
                    lbl = spec.label;
                else
                    spec = config.flagMarkDefault;
                    lbl = sprintf('%s (%s)', spec.label, st);
                end
                firedSymbol{end+1} = spec.symbol; %#ok<AGROW>
                firedKey{end+1} = st;             %#ok<AGROW>
                firedLabel{end+1} = lbl;          %#ok<AGROW>
                firedColor{end+1} = spec.color;   %#ok<AGROW>
                firedTier(end+1) = spec.tier;     %#ok<AGROW>
            end

            if isfinite(fin.plateDiameterMm) && abs(fin.plateDiameterMm - 140) < 0.5
                spec = config.flag140;
                firedSymbol{end+1} = spec.symbol; %#ok<AGROW>
                firedKey{end+1} = spec.key;       %#ok<AGROW>
                firedLabel{end+1} = spec.label;   %#ok<AGROW>
                firedColor{end+1} = spec.color;   %#ok<AGROW>
                firedTier(end+1) = spec.tier;     %#ok<AGROW>
            end

            if isempty(firedTier)
                continue;
            end

            % Stack marks upward by tier: lowest tier one clearance above the box
            % top, higher tiers one gap above the previous. Compress the gap to a
            % glyph-height floor only if the full-gap stack would clear the ceiling.
            base = log(fin.maxRadius);
            bottom = base + clearance;
            nF = length(firedTier);
            if nF == 1
                effGap = 0;
            else
                idealTop = bottom + gap * (nF - 1);
                if idealTop > ceilingLog
                    avail = (ceilingLog - bottom) / (nF - 1);
                    effGap = max(avail, minGap);
                else
                    effGap = gap;
                end
            end

            [~, ascOrder] = sort(firedTier, 'ascend');
            for j = 1:nF
                idx = ascOrder(j);
                yLog = bottom + (j - 1) * effGap;
                marks(end+1) = struct('x', fin.col, 'y', exp(yLog), ...
                    'symbol', firedSymbol{idx}, 'eventKey', firedKey{idx}, ...
                    'label', firedLabel{idx}, 'color', firedColor{idx}, ...
                    'tier', firedTier(idx)); %#ok<AGROW>
            end
        end
    end

    function drawFlagMarks(ax, marks)
        % VIEW: Drop each resolved mark glyph over its box at the precomputed
        % (x, y); bottom-aligned so the glyph sits above the box top (TERMINAL)
        if isempty(marks)
            return;
        end
        hold(ax, 'on');
        for i = 1:length(marks)
            text(ax, marks(i).x, marks(i).y, marks(i).symbol, ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                'FontSize', 14, 'FontWeight', 'bold', 'Color', marks(i).color, ...
                'Interpreter', 'none', 'Clipping', 'off');
        end
        hold(ax, 'off');
    end

    function drawFlagLegend(fig, marks, config)
        % VIEW: List only the event types that actually fired, one stacked
        % annotation per unique eventKey so each keeps its own glyph and color.
        % Placed lower-left, below the axes. (TERMINAL)
        if isempty(marks)
            return;
        end
        seen = {};
        uniqMarks = struct('symbol', {}, 'label', {}, 'color', {});
        for i = 1:length(marks)
            k = marks(i).eventKey;
            if ~any(strcmp(seen, k))
                seen{end+1} = k; %#ok<AGROW>
                uniqMarks(end+1) = struct('symbol', marks(i).symbol, ...
                    'label', marks(i).label, 'color', marks(i).color); %#ok<AGROW>
            end
        end

        baseX = 0.06;
        baseY = 0.01;
        lineH = 0.02;
        width = 0.5;
        nU = length(uniqMarks);

        annotation(fig, 'textbox', ...
            [baseX, baseY + nU * lineH, width, lineH], ...
            'String', 'Plate flags:', 'EdgeColor', 'none', ...
            'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
            'FontSize', config.box_font, 'FontWeight', 'bold', 'Color', [0 0 0]);

        for i = 1:nU
            y = baseY + (nU - i) * lineH;
            str = sprintf('%s  %s', uniqMarks(i).symbol, uniqMarks(i).label);
            annotation(fig, 'textbox', [baseX, y, width, lineH], ...
                'String', str, 'EdgeColor', 'none', 'Interpreter', 'none', ...
                'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
                'FontSize', config.box_font, 'FontWeight', 'normal', 'Color', uniqMarks(i).color);
        end
    end

    % ===== Cell renderers (shared, dispatched once per cell) =====
    % Each renderer draws the plot alone; the calling populator draws the stat
    % block under it, so every renderer shares one signature:
    %   renderer(ax, entry, color, scaling, config)

    function renderCellRawImage(ax, entry, ~, ~, config)
        % SUB-CONTROLLER: Render grayscale plate image, axes fit to its aspect
        grayImg = convertToGrayscale(entry.image);
        imshow(grayImg, 'Parent', ax);
        fitAxesToImage(ax, grayImg, config);
    end

    function renderCellImageOverlay(ax, entry, ~, ~, config)
        % SUB-CONTROLLER: Grayscale plate image with colony overlays, axes fit
        % to its aspect
        grayImg = convertToGrayscale(entry.image);
        imshow(grayImg, 'Parent', ax);
        fitAxesToImage(ax, grayImg, config);
        hold(ax, 'on');
        drawColonyOverlays(ax, entry);
        hold(ax, 'off');

        function drawColonyOverlays(ax, entry)
            % VIEW: Polygons for irregular detections, circles for circular (TERMINAL)
            if ~isfield(entry, 'Measurements') || ~isstruct(entry.Measurements)
                return;
            end
            m = entry.Measurements;
            if ~isfield(m, 'Centers') || isempty(m.Centers) || ...
               ~isfield(m, 'Radius_Pixels') || isempty(m.Radius_Pixels)
                return;
            end
            centers = m.Centers;
            radii_pix = m.Radius_Pixels;
            if isfield(m, 'Boundaries') && ~isempty(m.Boundaries)
                boundaries = m.Boundaries;
            else
                boundaries = cell(size(centers, 1), 1);
            end
            n = min([size(centers, 1), numel(radii_pix), numel(boundaries)]);
            theta = linspace(0, 2*pi, 60);
            circleColor = [1 0 0];
            polygonColor = [1 0 1];
            for i = 1:n
                b = boundaries{i};
                isValidPolygon = ~isempty(b) && isnumeric(b) && ~isscalar(b) && ...
                                 size(b, 2) >= 2 && ~isnan(b(1));
                if isValidPolygon
                    plot(ax, b(:,2), b(:,1), '-', 'Color', polygonColor, 'LineWidth', 0.6);
                else
                    cx = centers(i, 1);
                    cy = centers(i, 2);
                    r = radii_pix(i);
                    plot(ax, cx + r*cos(theta), cy + r*sin(theta), '-', ...
                         'Color', circleColor, 'LineWidth', 0.6);
                end
            end
        end
    end

    function renderCellHistogram(ax, entry, color, scaling, config)
        % SUB-CONTROLLER: Log-spaced density histogram
        density = computeHistDensity(entry, scaling);
        drawDensityBars(ax, scaling.bin_edges_um, density, color, config.hist_alpha_solo);
        configureDistributionAxes(ax, scaling);
    end

    function renderCellKDE(ax, entry, color, scaling, ~)
        % SUB-CONTROLLER: KDE curve with peak/mean dots and coordinate labels
        hold(ax, 'on');
        drawKDECurveOnAxes(ax, entry, color);
        addDotsAndCoordinates(ax, entry, color, scaling);
        hold(ax, 'off');
        configureDistributionAxes(ax, scaling);
        set(ax, 'FontSize', 8);

        function drawKDECurveOnAxes(ax, entry, color)
            % VIEW: Plot stored KDE density curve (TERMINAL)
            if ~isfield(entry, 'kde') || ~isfield(entry.kde, 'eval_x_log') || ...
               isempty(entry.kde.eval_x_log)
                return;
            end
            x_um = exp(entry.kde.eval_x_log);
            plot(ax, x_um, entry.kde.density, '-', 'Color', color, 'LineWidth', 1.8);
        end

        function addDotsAndCoordinates(ax, entry, color, scaling)
            % SUB-CONTROLLER: Compute dot positions then draw dots and labels
            if ~isfield(entry, 'kde') || ~isfield(entry.kde, 'eval_x_log') || ...
               isempty(entry.kde.eval_x_log)
                return;
            end
            dotCoords = computeDotCoordinates(entry);
            drawDotsOnCurve(ax, dotCoords, color);
            drawCoordinateLabels(ax, dotCoords, scaling, color);

            function dots = computeDotCoordinates(entry)
                % MODEL: Compute (x, y) for peak and mean dots (TERMINAL)
                dots = struct();
                dots.peak_x = entry.summary_stats.mode;
                dots.peak_y = max(entry.kde.density);

                x_um = exp(entry.kde.eval_x_log);
                meanX = entry.summary_stats.mean;
                if meanX >= min(x_um) && meanX <= max(x_um)
                    dots.mean_y = interp1(x_um, entry.kde.density, meanX, 'linear');
                else
                    dots.mean_y = 0;
                end
                dots.mean_x = meanX;
            end

            function drawDotsOnCurve(ax, dots, color)
                % VIEW: Place peak (circle) and mean (diamond) dots (TERMINAL)
                darkEdge = max(color * 0.4, 0);
                scatter(ax, dots.peak_x, dots.peak_y, 60, color, 'filled', ...
                    'MarkerEdgeColor', darkEdge, 'LineWidth', 0.8);
                scatter(ax, dots.mean_x, dots.mean_y, 70, color, 'd', 'filled', ...
                    'MarkerEdgeColor', darkEdge, 'LineWidth', 0.8);
            end

            function drawCoordinateLabels(ax, dots, scaling, color)
                % VIEW: Print Mean and Peak coordinate text in headroom (TERMINAL)
                yMax = scaling.y_density_max;
                yRowMean = yMax * 0.92;
                yRowPeak = yMax * 0.82;
                xCenter = exp(mean(log(scaling.x_um_extent)));
                darkText = max(color * 0.3, 0);

                meanStr = sprintf('Mean: (%d, %.2f)', round(dots.mean_x), dots.mean_y);
                peakStr = sprintf('Peak: (%d, %.2f)', round(dots.peak_x), dots.peak_y);

                text(ax, xCenter, yRowMean, meanStr, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', 8, 'Color', darkText, 'FontWeight', 'bold');
                text(ax, xCenter, yRowPeak, peakStr, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                    'FontSize', 8, 'Color', darkText, 'FontWeight', 'bold');
            end
        end
    end

    function renderCellMixture(ax, entry, color, scaling, config)
        % SUB-CONTROLLER: Histogram backing + sum (black, behind) + components
        hold(ax, 'on');
        histDensity = computeHistDensity(entry, scaling);
        drawDensityBars(ax, scaling.bin_edges_um, histDensity, color, config.hist_alpha_backing);
        mix = computeMixtureComponents(entry, scaling);
        if ~isempty(mix)
            drawSumCurve(ax, mix);
            drawComponentCurves(ax, mix, config);
        end
        hold(ax, 'off');
        configureDistributionAxes(ax, scaling);

        function mix = computeMixtureComponents(entry, scaling)
            % MODEL: Pull LMM params, sort by weight desc, build component grid.
            % GMM_mu is the LogNormal median in linear-um, so it is log-transformed
            % to evaluate as a normal pdf over log-radius. (TERMINAL)
            hasLMM = isfield(entry, 'full_colony_set') && ...
                isfield(entry.full_colony_set, 'alternative_fits') && ...
                isfield(entry.full_colony_set.alternative_fits, 'LogNormal');
            if ~hasLMM
                mix = [];
                return;
            end
            alt = entry.full_colony_set.alternative_fits.LogNormal;
            mu_linear = alt.gmm_results.fitted_model.GMM_mu(:);
            sigma = alt.gmm_results.fitted_model.GMM_sigma(:);
            w = alt.gmm_results.fitted_model.GMM_weights(:);
            if isempty(mu_linear)
                mix = [];
                return;
            end
            [w_sorted, sortIdx] = sort(w, 'descend');
            mu_log_sorted = log(mu_linear(sortIdx));
            sigma_sorted = sigma(sortIdx);
            nComp = length(w_sorted);
            componentDensity = zeros(nComp, length(scaling.fine_x_log));
            for c = 1:nComp
                componentDensity(c, :) = w_sorted(c) * ...
                    normpdf(scaling.fine_x_log, mu_log_sorted(c), sigma_sorted(c));
            end
            mix = struct( ...
                'x_um', scaling.fine_x_um, ...
                'componentDensity', componentDensity, ...
                'sumDensity', sum(componentDensity, 1), ...
                'nComp', nComp);
        end

        function drawSumCurve(ax, mix)
            % VIEW: Plot summed mixture density in black, drawn before components (TERMINAL)
            plot(ax, mix.x_um, mix.sumDensity, '-', 'Color', 'k', 'LineWidth', 1.6);
        end

        function drawComponentCurves(ax, mix, config)
            % VIEW: Plot per-component curves in dominance-rank colors (TERMINAL)
            for c = 1:mix.nComp
                rankIdx = min(c, length(config.lmm_component_colors));
                rankColor = config.lmm_component_colors{rankIdx};
                plot(ax, mix.x_um, mix.componentDensity(c, :), '-', ...
                     'Color', rankColor, 'LineWidth', 1.2);
            end
        end
    end

    % ===== Shared classification / formatting helpers =====

    function mask = buildEligibleMask(composite)
        % MODEL: Eligible plates have an image and were measured. A measured
        % plate carries a Measurements struct with Centers and Radius_Pixels
        % fields and a finite colony_count; the fields may be empty, so a plate
        % with zero detected colonies stays eligible and renders its photo, empty
        % distribution axes, and an n = 0 box plot column. Pooled entries (empty
        % image) fall out, as do plates never measured, provided those lack the
        % fields or carry an empty or non-finite colony_count. Used by the
        % classifier (multiplicity), the composite selected collector, the cell
        % header classifier, and the full pipeline's ON-index organizer. (TERMINAL)
        hasImage = arrayfun(@(c) ~isempty(c.image), composite);
        wasMeasured = arrayfun(@(c) isstruct(c.Measurements) && ...
            isfield(c.Measurements, 'Centers') && ...
            isfield(c.Measurements, 'Radius_Pixels'), composite);
        if isfield(composite, 'colony_count')
            hasCount = arrayfun(@(c) isnumeric(c.colony_count) && ...
                isscalar(c.colony_count) && isfinite(c.colony_count), composite);
        else
            hasCount = true(size(composite));
        end
        mask = hasImage & wasMeasured & hasCount;
    end

    function composite = extractComposite(data)
        % MODEL: Return the composite struct array from either a wrapped dataset
        % (a scalar struct with a .composite field) or a bare composite array. (TERMINAL)
        if isstruct(data) && isscalar(data) && isfield(data, 'composite')
            composite = data.composite;
        else
            composite = data;
        end
    end

    function s = capitalizeFirst(str)
        % MODEL: Upper-case the first character, leave the rest unchanged; used for
        % the mode token in the file name and for default axis display labels. (TERMINAL)
        str = char(str);
        if isempty(str)
            s = str;
        else
            s = [upper(str(1)), str(2:end)];
        end
    end
end
%% Utils
function ExploreImages(InputCompleteData)
    % CONTROLLER: Browse composite entries with image and metadata display
    
    % Initialize the viewer state
    viewerState = createInitialState(InputCompleteData);
    
    % Build the UI components
    viewerHandles = buildViewerInterface(viewerState);
    
    % Wire up all navigation callbacks
    wireNavigationCallbacks(viewerHandles);
    
    % Render the first composite entry
    renderCurrentComposite();
    
    % === SHARED NESTED FUNCTIONS (closure access to viewerState/viewerHandles) ===
    
    function renderCurrentComposite()
        % SUB-CONTROLLER: Render the current composite entry to the UI
        
        % Display the current image
        displayCurrentImage();
        
        % Display the current metadata text
        displayCurrentMetadata();
        
        % Update the navigation controls (counter, buttons, index input)
        updateNavigationControls();
        
        function displayCurrentImage()
            % SUB-CONTROLLER: Display the current composite image with colony overlays
            
            % Fetch the image array for the current index
            imageData = fetchCurrentImage();
            
            % Render it to the image axes
            renderImageToAxes(imageData);
            
            % Fetch the colony measurement data for the current index
            colonyData = fetchCurrentColonyData();
            
            % Draw colony overlays (polygons for irregular, circles for circular)
            drawColoniesOnAxes(colonyData);
            overlayGrowthMaskIfEnabled();
            
            function imageData = fetchCurrentImage()
                % MODEL: Get image array for the current viewable entry (TERMINAL)
                actualIdx = viewerState.viewableIndices(viewerState.currentIndex);
                imageData = viewerState.data.composite(actualIdx).image;
            end
            
            function renderImageToAxes(imageData)
    % VIEW: Show image on the image axes in grayscale (TERMINAL)
    if size(imageData, 3) == 3
        imageData = rgb2gray(imageData);
    end
    imshow(imageData, 'Parent', viewerHandles.imageAxes);
    set(viewerHandles.imageAxes, 'XTick', [], 'YTick', []);
end
            
            function colonyData = fetchCurrentColonyData()
                % MODEL: Get colony centers, pixel radii, and boundaries (TERMINAL)
                actualIdx = viewerState.viewableIndices(viewerState.currentIndex);
                entry = viewerState.data.composite(actualIdx);
                colonyData = struct();
                colonyData.centers = [];
                colonyData.radii_pixels = [];
                colonyData.boundaries = {};
                colonyData.count = 0;
                
                % Guard: Measurements field must exist
                if ~isfield(entry, 'Measurements') || isempty(entry.Measurements)
                    warning('Viewer: Entry %d missing field "Measurements" - skipping overlays', actualIdx);
                    return;
                end
                measurements = entry.Measurements;
                
                % Guard: Centers must exist and be Nx2
                if ~isfield(measurements, 'Centers') || isempty(measurements.Centers) || size(measurements.Centers, 2) < 2
                    warning('Viewer: Entry %d missing field "Centers" - skipping overlays', actualIdx);
                    return;
                end
                colonyData.centers = measurements.Centers;
                
                % Guard: Radius_Pixels must exist and be non-empty
                if ~isfield(measurements, 'Radius_Pixels') || isempty(measurements.Radius_Pixels)
                    warning('Viewer: Entry %d missing field "Radius_Pixels" - skipping overlays', actualIdx);
                    return;
                end
                colonyData.radii_pixels = measurements.Radius_Pixels;
                
                % Boundaries: optional, fall back to circles if missing
                if isfield(measurements, 'Boundaries') && ~isempty(measurements.Boundaries)
                    colonyData.boundaries = measurements.Boundaries;
                else
                    warning('Viewer: Entry %d missing field "Boundaries" - falling back to circle overlays', actualIdx);
                    colonyData.boundaries = cell(size(measurements.Centers, 1), 1);
                end
                
                % Use shortest array length to handle ragged arrays
                colonyData.count = min([size(colonyData.centers, 1), ...
                                        numel(colonyData.radii_pixels), ...
                                        numel(colonyData.boundaries)]);
            end
            
            function drawColoniesOnAxes(colonyData)
                % VIEW: Draw polygons where boundaries exist, circles otherwise (TERMINAL)
                ax = viewerHandles.imageAxes;
                hold(ax, 'on');
                circleColor = [0 0 1];     % blue for circular detections
                polygonColor = [0 0 1];    % blue for irregular detections
                theta = linspace(0, 2*pi, 60);
                for i = 1:colonyData.count
                    b = colonyData.boundaries{i};
                    isValidPolygon = ~isempty(b) && isnumeric(b) && ~isscalar(b) ...
                                     && size(b, 2) >= 2 && ~isnan(b(1));
                    if isValidPolygon
                        % Irregular: plot polygon (col 2 = X, col 1 = Y per bwboundaries)
                        plot(ax, b(:,2), b(:,1), '-', ...
                             'Color', polygonColor, 'LineWidth', 2);
                    else
                        % Circular: synthesize circle from center + pixel radius
                        cx = colonyData.centers(i, 1);
                        cy = colonyData.centers(i, 2);
                        r  = colonyData.radii_pixels(i);
                        plot(ax, cx + r*cos(theta), cy + r*sin(theta), '-', ...
                             'Color', circleColor, 'LineWidth', 2);
                    end
                end
                hold(ax, 'off');
            end
            
            function overlayGrowthMaskIfEnabled()
    % SUB-CONTROLLER: Draw the stored growth mask overlay when the toggle is on
    if ~viewerState.showMask
        return;
    end
    mask = fetchStoredMask();
    drawGrowthOverlay(mask);

    function maskOut = fetchStoredMask()
        % MODEL: Read the precomputed growth mask off the current entry (TERMINAL)
        % The startup workflow stores the mask at biomass_occupation.mask (empty
        % for image-less entries). Returns [] when the field is absent so the
        % view's empty guard simply draws nothing.
        idx = viewerState.viewableIndices(viewerState.currentIndex);
        entry = viewerState.data.composite(idx);
        if isfield(entry, 'biomass_occupation') && ...
                isfield(entry.biomass_occupation, 'mask')
            maskOut = entry.biomass_occupation.mask;
        else
            maskOut = [];
        end
    end

    function drawGrowthOverlay(maskIn)
        % VIEW: Tint growth pixels semi-transparent red over the image (TERMINAL)
        if isempty(maskIn)
            return;
        end
        ax = viewerHandles.imageAxes;
        hold(ax, 'on');
        redLayer = cat(3, ones(size(maskIn)), zeros(size(maskIn)), zeros(size(maskIn)));
        h = imshow(redLayer, 'Parent', ax);
        set(h, 'AlphaData', double(maskIn) * 0.35);
        hold(ax, 'off');
    end
end
        
            end
        
        function displayCurrentMetadata()
            % SUB-CONTROLLER: Display metadata for the current entry
            
            % Build the formatted text lines
            metadataLines = buildMetadataLines();
            
            % Push the text into the panel
            renderMetadataText(metadataLines);
            
            function metadataLines = buildMetadataLines()
    % MODEL: Build the metadata text content (TERMINAL)
    actualIdx = viewerState.viewableIndices(viewerState.currentIndex);
    entry = viewerState.data.composite(actualIdx);
    
    colonyCoverage = entry.biomass_occupation.colony * 100;
    growthCoverage = entry.biomass_occupation.growth * 100;
    
    metadataLines = {
        sprintf('%-16s %d of %d', 'Viewer:', viewerState.currentIndex, viewerState.totalCount);
        sprintf('%-16s %d', 'Composite #:', actualIdx);
        '';
        sprintf('%-16s %d', 'Passage:', entry.passage);
        sprintf('%-16s %s', 'Genotype:', entry.genotype);
        sprintf('%-16s %d', 'HCE:', entry.hce);
        sprintf('%-16s %d', 'Colony Count:', entry.colony_count);
        '';
        sprintf('%-16s %.1f%%', 'Colony Coverage:', colonyCoverage);
        sprintf('%-16s %.1f%%', 'Growth Coverage:', growthCoverage);
    };
end
            function renderMetadataText(metadataLines)
                % VIEW: Push metadata text into the text panel (TERMINAL)
                set(viewerHandles.textPanel, 'String', metadataLines);
            end
        end
        
        function updateNavigationControls()
            % SUB-CONTROLLER: Update counter label, button states, and index input
            
            % Compute the new control state
            controlState = computeControlState();
            
            % Apply the counter label text
            applyCounterText(controlState);
            
            % Apply the button enable states
            applyButtonEnables(controlState);
            
            % Sync the index input to the current composite index
            syncIndexInput();
            
            function controlState = computeControlState()
                % MODEL: Compute counter text and button enable states (TERMINAL)
                idx = viewerState.currentIndex;
                total = viewerState.totalCount;
                
                controlState = struct();
                controlState.counterText = sprintf('%d / %d', idx, total);
                
                if idx <= 1
                    controlState.prevEnable = 'off';
                else
                    controlState.prevEnable = 'on';
                end
                
                if idx >= total
                    controlState.nextEnable = 'off';
                else
                    controlState.nextEnable = 'on';
                end
            end
            
            function applyCounterText(controlState)
                % VIEW: Set the counter label text (TERMINAL)
                set(viewerHandles.counterLabel, 'String', controlState.counterText);
            end
            
            function applyButtonEnables(controlState)
                % VIEW: Set enable state on navigation buttons (TERMINAL)
                set(viewerHandles.prevButton, 'Enable', controlState.prevEnable);
                set(viewerHandles.nextButton, 'Enable', controlState.nextEnable);
            end
            
            function syncIndexInput()
                % VIEW: Update index input to reflect current composite index (TERMINAL)
                actualIdx = viewerState.viewableIndices(viewerState.currentIndex);
                set(viewerHandles.indexInput, 'String', num2str(actualIdx));
            end
        end
    end
    
    function handleNavigation(direction)
        % SUB-CONTROLLER: Process a navigation button press
        
        % Update the current index with bounds clamping
        viewerState.currentIndex = computeBoundedIndex(direction);
        
        % Re-render with the new index
        renderCurrentComposite();
        
        function newIndex = computeBoundedIndex(direction)
            % MODEL: Compute new index clamped to valid range (TERMINAL)
            proposed = viewerState.currentIndex + direction;
            newIndex = max(1, min(viewerState.totalCount, proposed));
        end
    end
    
    function handleMaskToggle(src)
    % SUB-CONTROLLER: Toggle growth mask overlay and re-render
    viewerState.showMask = logical(get(src, 'Value'));
    renderCurrentComposite();
    end

    function handleDropdownNavigation()
        % SUB-CONTROLLER: Jump to next entry matching dropdown criteria
        
        % Get current dropdown selections
        criteria = readDropdownCriteria();
        
        % Search for next matching entry from current position
        matchIdx = findNextMatch(criteria);
        
        % Jump if found, warn if not
        if matchIdx > 0
            viewerState.currentIndex = matchIdx;
            renderCurrentComposite();
        else
            warnNoMatch(criteria);
        end
        
        function criteria = readDropdownCriteria()
            % MODEL: Read current dropdown selections (TERMINAL)
            genotypeItems = get(viewerHandles.genotypeDropdown, 'String');
            genotypeVal = get(viewerHandles.genotypeDropdown, 'Value');
            passageItems = get(viewerHandles.passageDropdown, 'String');
            passageVal = get(viewerHandles.passageDropdown, 'Value');
            
            criteria = struct();
            criteria.genotype = genotypeItems{genotypeVal};
            criteria.passage = passageItems{passageVal};
            criteria.filterGenotype = ~strcmp(criteria.genotype, 'All');
            criteria.filterPassage = ~strcmp(criteria.passage, 'All');
        end
        
        function matchIdx = findNextMatch(criteria)
            % MODEL: Find next viewable index matching criteria, with wraparound (TERMINAL)
            n = viewerState.totalCount;
            matchIdx = 0;
            
            for offset = 1:n
                candidateIdx = mod(viewerState.currentIndex - 1 + offset, n) + 1;
                actualIdx = viewerState.viewableIndices(candidateIdx);
                entry = viewerState.data.composite(actualIdx);
                
                genotypeMatch = ~criteria.filterGenotype || strcmp(entry.genotype, criteria.genotype);
                passageMatch = ~criteria.filterPassage || (entry.passage == str2double(criteria.passage));
                
                if genotypeMatch && passageMatch
                    matchIdx = candidateIdx;
                    return;
                end
            end
        end
        
        function warnNoMatch(criteria)
            % VIEW: Warn in command window that no match was found (TERMINAL)
            warning('Viewer: No entry found matching Genotype="%s", Passage="%s"', ...
                    criteria.genotype, criteria.passage);
        end
    end
    
    function handleIndexJump()
        % SUB-CONTROLLER: Jump to an absolute composite index from text input
        
        % Parse the input text
        targetIdx = parseIndexInput();
        
        % Find the viewer index for that composite index
        viewerIdx = findViewerIndex(targetIdx);
        
        % Jump or warn
        if viewerIdx > 0
            viewerState.currentIndex = viewerIdx;
            renderCurrentComposite();
        else
            warnInvalidIndex(targetIdx);
        end
        
        function targetIdx = parseIndexInput()
            % MODEL: Parse the index input text field (TERMINAL)
            inputStr = get(viewerHandles.indexInput, 'String');
            targetIdx = round(str2double(inputStr));
        end
        
        function viewerIdx = findViewerIndex(targetIdx)
            % MODEL: Find viewer index for a given absolute composite index (TERMINAL)
            if isnan(targetIdx) || targetIdx < 1 || targetIdx > length(viewerState.data.composite)
                viewerIdx = 0;
                return;
            end
            found = find(viewerState.viewableIndices == targetIdx, 1);
            if isempty(found)
                viewerIdx = 0;
            else
                viewerIdx = found;
            end
        end
        
        function warnInvalidIndex(targetIdx)
            % VIEW: Warn about invalid or non-viewable index (TERMINAL)
            if isnan(targetIdx)
                warning('Viewer: Invalid index input - not a number');
            else
                warning('Viewer: Composite index %d is not viewable (no image or out of range)', targetIdx);
            end
        end
    end
    
    % === SETUP SUB-CONTROLLERS ===
    function viewerState = createInitialState(InputCompleteData)
    % MODEL: Build the initial viewer state struct (TERMINAL)
    % Skip entries with empty .image (pooled replicates have no image data)
    nEntries = length(InputCompleteData.composite);
    hasImage = false(1, nEntries);
    for i = 1:nEntries
        hasImage(i) = ~isempty(InputCompleteData.composite(i).image);
    end
    
    viewerState = struct();
    viewerState.data = InputCompleteData;
    viewerState.viewableIndices = find(hasImage);
    viewerState.currentIndex = 1;
    viewerState.totalCount = numel(viewerState.viewableIndices);
    viewerState.showMask = false;
    
    % Extract unique genotypes and passages from viewable entries
    allGenotypes = {};
    allPassages = [];
    for i = viewerState.viewableIndices
        allGenotypes{end+1} = InputCompleteData.composite(i).genotype; %#ok<AGROW>
        allPassages(end+1) = InputCompleteData.composite(i).passage; %#ok<AGROW>
    end
    viewerState.uniqueGenotypes = unique(allGenotypes);
    viewerState.uniquePassages = sort(unique(allPassages));
end
    function viewerHandles = buildViewerInterface(viewerState)
        % SUB-CONTROLLER: Construct figure window and all UI elements
        
        % Compute layout dimensions
        viewerLayout = computeViewerLayout();
        
        % Create the main figure
        viewerHandles.fig = createMainFigure(viewerLayout);
        
        % Create the image axes
        viewerHandles.imageAxes = createImageAxes(viewerHandles.fig);
        
        % Create the metadata text panel
        viewerHandles.textPanel = createTextPanel(viewerHandles.fig);
        
        % Create sequential navigation controls (Prev / Counter / Next)
        navHandles = createNavigationControls(viewerHandles.fig, viewerState);
        viewerHandles.prevButton = navHandles.prevButton;
        viewerHandles.nextButton = navHandles.nextButton;
        viewerHandles.counterLabel = navHandles.counterLabel;
        
        % Create filter dropdown controls (Genotype / Passage)
        filterHandles = createFilterControls(viewerHandles.fig, viewerState);
        viewerHandles.genotypeDropdown = filterHandles.genotypeDropdown;
        viewerHandles.passageDropdown = filterHandles.passageDropdown;
        
        % Create index jump controls (text input / Go button)
        indexHandles = createIndexControls(viewerHandles.fig);
        viewerHandles.indexInput = indexHandles.indexInput;
        viewerHandles.goButton = indexHandles.goButton;
        viewerHandles.maskToggle = createMaskToggle(viewerHandles.fig);
        
        function viewerLayout = computeViewerLayout()
            % MODEL: Compute viewer figure layout (TERMINAL)
            screenSize = get(0, 'ScreenSize');
            figWidth = min(1400, screenSize(3) * 0.8);
            figHeight = min(800, screenSize(4) * 0.8);
            figX = (screenSize(3) - figWidth) / 2;
            figY = (screenSize(4) - figHeight) / 2;
            
            viewerLayout = struct();
            viewerLayout.position = [figX, figY, figWidth, figHeight];
            viewerLayout.name = 'Part 3 Composite Viewer';
        end
        
        function fig = createMainFigure(viewerLayout)
            % VIEW: Create the main figure window (TERMINAL)
            fig = figure('Name', viewerLayout.name, ...
                         'NumberTitle', 'off', ...
                         'Position', viewerLayout.position, ...
                         'Color', [0.95 0.95 0.95]);
        end
        
        function imageAxes = createImageAxes(fig)
            % VIEW: Create the axes for displaying composite images (TERMINAL)
            imageAxes = axes('Parent', fig, ...
                             'Units', 'normalized', ...
                             'Position', [0.02, 0.14, 0.65, 0.83], ...
                             'XTick', [], ...
                             'YTick', []);
        end
        
        function textPanel = createTextPanel(fig)
            % VIEW: Create the text panel for metadata display (TERMINAL)
            textPanel = uicontrol('Parent', fig, ...
                                  'Style', 'edit', ...
                                  'Units', 'normalized', ...
                                  'Position', [0.70, 0.14, 0.28, 0.83], ...
                                  'Max', 20, ...
                                  'Min', 0, ...
                                  'HorizontalAlignment', 'left', ...
                                  'FontName', 'Consolas', ...
                                  'FontSize', 11, ...
                                  'BackgroundColor', 'white', ...
                                  'Enable', 'inactive', ...
                                  'String', '');
        end
        
        function navHandles = createNavigationControls(fig, viewerState)
            % VIEW: Create previous/next buttons and counter label (TERMINAL)
            navHandles.prevButton = uicontrol('Parent', fig, ...
                'Style', 'pushbutton', ...
                'Units', 'normalized', ...
                'Position', [0.30, 0.01, 0.10, 0.05], ...
                'String', '< Previous', ...
                'FontSize', 11);
            
            navHandles.counterLabel = uicontrol('Parent', fig, ...
                'Style', 'text', ...
                'Units', 'normalized', ...
                'Position', [0.42, 0.01, 0.16, 0.05], ...
                'String', sprintf('1 / %d', viewerState.totalCount), ...
                'FontSize', 12, ...
                'FontWeight', 'bold', ...
                'BackgroundColor', [0.95 0.95 0.95]);
            
            navHandles.nextButton = uicontrol('Parent', fig, ...
                'Style', 'pushbutton', ...
                'Units', 'normalized', ...
                'Position', [0.60, 0.01, 0.10, 0.05], ...
                'String', 'Next >', ...
                'FontSize', 11);
        end
        
        function filterHandles = createFilterControls(fig, viewerState)
            % VIEW: Create genotype and passage dropdown menus (TERMINAL)
            genotypeItems = [{'All'}, viewerState.uniqueGenotypes];
            passageStrings = arrayfun(@num2str, viewerState.uniquePassages, 'UniformOutput', false);
            passageItems = [{'All'}, passageStrings];
            
            % Genotype label
            uicontrol('Parent', fig, ...
                'Style', 'text', ...
                'Units', 'normalized', ...
                'Position', [0.02, 0.07, 0.07, 0.04], ...
                'String', 'Genotype:', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'right', ...
                'BackgroundColor', [0.95 0.95 0.95]);
            
            % Genotype dropdown
            filterHandles.genotypeDropdown = uicontrol('Parent', fig, ...
                'Style', 'popupmenu', ...
                'Units', 'normalized', ...
                'Position', [0.10, 0.07, 0.15, 0.045], ...
                'String', genotypeItems, ...
                'FontSize', 10, ...
                'Value', 1);
            
            % Passage label
            uicontrol('Parent', fig, ...
                'Style', 'text', ...
                'Units', 'normalized', ...
                'Position', [0.27, 0.07, 0.06, 0.04], ...
                'String', 'Passage:', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'right', ...
                'BackgroundColor', [0.95 0.95 0.95]);
            
            % Passage dropdown
            filterHandles.passageDropdown = uicontrol('Parent', fig, ...
                'Style', 'popupmenu', ...
                'Units', 'normalized', ...
                'Position', [0.34, 0.07, 0.10, 0.045], ...
                'String', passageItems, ...
                'FontSize', 10, ...
                'Value', 1);
        end
        
        function indexHandles = createIndexControls(fig)
            % VIEW: Create index text input and Go button (TERMINAL)
            
            % Index label
            uicontrol('Parent', fig, ...
                'Style', 'text', ...
                'Units', 'normalized', ...
                'Position', [0.55, 0.07, 0.06, 0.04], ...
                'String', 'Index:', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'right', ...
                'BackgroundColor', [0.95 0.95 0.95]);
            
            % Index text input (Enter key triggers callback)
            indexHandles.indexInput = uicontrol('Parent', fig, ...
                'Style', 'edit', ...
                'Units', 'normalized', ...
                'Position', [0.62, 0.07, 0.08, 0.045], ...
                'String', '1', ...
                'FontSize', 10, ...
                'HorizontalAlignment', 'center');
            
            % Go button
            indexHandles.goButton = uicontrol('Parent', fig, ...
                'Style', 'pushbutton', ...
                'Units', 'normalized', ...
                'Position', [0.71, 0.07, 0.05, 0.045], ...
                'String', 'Go', ...
                'FontSize', 10);
        end
        
        function maskToggle = createMaskToggle(fig)
    % VIEW: Create the growth mask overlay checkbox (TERMINAL)
    maskToggle = uicontrol('Parent', fig, ...
        'Style', 'checkbox', ...
        'Units', 'normalized', ...
        'Position', [0.78, 0.07, 0.18, 0.045], ...
        'String', 'Show Growth Mask', ...
        'FontSize', 10, ...
        'BackgroundColor', [0.95 0.95 0.95], ...
        'Value', 0);
end
    end
    
    function wireNavigationCallbacks(viewerHandles)
        % SUB-CONTROLLER: Attach all navigation callbacks
        
        % Attach sequential navigation callbacks
        attachPrevCallback(viewerHandles);
        attachNextCallback(viewerHandles);
        
        % Attach dropdown jump callbacks
        attachDropdownCallbacks(viewerHandles);
        
        % Attach index jump callbacks
        attachIndexCallbacks(viewerHandles);

        attachMaskToggleCallback(viewerHandles);
        
        function attachPrevCallback(viewerHandles)
            % VIEW: Set the previous button callback (TERMINAL)
            set(viewerHandles.prevButton, 'Callback', ...
                @(~, ~) handleNavigation(-1));
        end
        
        function attachNextCallback(viewerHandles)
            % VIEW: Set the next button callback (TERMINAL)
            set(viewerHandles.nextButton, 'Callback', ...
                @(~, ~) handleNavigation(+1));
        end
        
        function attachDropdownCallbacks(viewerHandles)
            % VIEW: Set dropdown change callbacks (TERMINAL)
            set(viewerHandles.genotypeDropdown, 'Callback', ...
                @(~, ~) handleDropdownNavigation());
            set(viewerHandles.passageDropdown, 'Callback', ...
                @(~, ~) handleDropdownNavigation());
        end
        
        function attachIndexCallbacks(viewerHandles)
            % VIEW: Set index input and Go button callbacks (TERMINAL)
            set(viewerHandles.goButton, 'Callback', ...
                @(~, ~) handleIndexJump());
            set(viewerHandles.indexInput, 'Callback', ...
                @(~, ~) handleIndexJump());
        end
    
        function attachMaskToggleCallback(viewerHandles)
    % VIEW: Set the growth mask toggle callback (TERMINAL)
    set(viewerHandles.maskToggle, 'Callback', @(src, ~) handleMaskToggle(src));
end
    end
end
function datasets = CountDatasetGenerator(Part3CompleteData)
% CountDatasetGenerator  Build the selection dataset by raw colony count.
%   For each genotype and passage, the 6-day Standard plate (Rep A or Rep B)
%   within the separable range whose colony count lies closest to a shared
%   target fills the cell. The separable range is the confluency floor used
%   in the within-state test: colony coverage at least 25% of growth
%   coverage. The target defaults to the median colony count across all
%   eligible plates; a numeric config.target replaces it.
%
%   A cell whose pool comes back empty carries a diagnostic. The diagnostic
%   anchors on genotype and passage, then records every remaining filter
%   independently for each candidate plate, so a plate failing two filters
%   shows both.

    % === COORDINATE SUB-CONTROLLERS ===
    [datasets, report, config] = resolveDatasets(Part3CompleteData);
    reportSummary(report, config);

    % === SUB-CONTROLLERS ===

    function [datasets, report, config] = resolveDatasets(Part3CompleteData)
        % SUB-CONTROLLER (model): read every plate into a record with its
        % colony count and separability, set the target, then fill each
        % dataset cell with the plate from its pool whose count is closest to
        % the target. Records each cell outcome for the view. Calls model
        % functions only.

        config = buildSelectionConfig();
        C      = Part3CompleteData.composite;
        plates = readPlateRecords(C, config);
        config = resolveTarget(plates, config);

        datasets = struct();
        report   = struct('datasetNum', {}, 'passage', {}, 'label', {}, ...
                          'status', {}, 'filename', {}, 'count', {}, ...
                          'captureRatio', {}, 'nPool', {}, 'diag', {});

        for d = 1:config.nDatasets
            grid = blankGrid();
            for p = config.passages
                for g = 1:numel(config.genotypes)
                    spec = getPoolSpec(config, d, config.genotypes{g}, p);
                    [grid, rec] = placeCell(grid, p, config.fields{g}, spec, ...
                                            plates, C, config.target);
                    report(end+1) = makeCellReport(d, p, config.labels{g}, rec); %#ok<AGROW>
                end
            end
            datasets.(sprintf('Dataset%d', d)) = grid;
        end

        function config = buildSelectionConfig()
            % MODEL (TERMINAL): target, candidate filters, separability floor,
            % genotype naming, the replicates each dataset draws from, and the
            % passage-line overrides. genotypes holds the strings stored in the
            % composite entries, fields the grid field names, labels the
            % display names. An empty target means the median colony count
            % across all eligible plates.
            config.target           = [];
            config.targetRule       = '';
            config.incubationDays   = 6;
            config.resolvedRatioMin = 0.25;
            config.genotypes = {'wild_type', 'dbf4-1', 'cdc13-2', 'double'};
            config.fields    = {'wild_type', 'dbf4_1', 'cdc13_2', 'double'};
            config.labels    = {'Wild Type', 'Dbf4-1', 'Cdc13-2', 'Double'};
            config.passages  = 1:5;

            % One dataset; Rep A and Rep B plates compete in the same pool, so
            % each cell holds one representative plate
            config.datasetReplicate = {{'A', 'B'}};
            config.nDatasets        = numel(config.datasetReplicate);

            % Cells whose pool is set by passage line. None apply: cdc13-2 P4
            % takes the standard-line plate through the default pool. An entry
            % here replaces a cell's sources and replicates, and skip = true
            % leaves the cell empty.
            config.overrides = struct('datasetNum', {}, 'genotype', {}, ...
                'passage', {}, 'sources', {}, 'replicates', {}, 'skip', {});
        end

        function plates = readPlateRecords(C, config)
            % MODEL (TERMINAL): one record per composite entry holding the
            % selection fields, the colony count, the capture ratio (colony
            % coverage over growth coverage), and whether the plate sits in the
            % separable range. The capture ratio enters as a filter only; it
            % never scales the count. A plate without a finite capture ratio is
            % not separable and never enters a pool.
            n = numel(C);
            plates = struct('genotype', cell(1, n), 'passage', NaN, ...
                            'replicate', '', 'source', '', 'days', NaN, ...
                            'count', NaN, 'captureRatio', NaN, ...
                            'separable', false, 'filename', '');

            for i = 1:n
                e = C(i);

                rep = e.replicate;
                if isstring(rep), rep = char(rep); end
                if ~ischar(rep), rep = ''; end

                pas = e.passage;
                if ~isnumeric(pas) || ~isscalar(pas), pas = NaN; end

                days = e.incubation_days;
                if ~isnumeric(days) || ~isscalar(days), days = NaN; end

                cnt = e.colony_count;
                if ~isnumeric(cnt) || ~isscalar(cnt), cnt = NaN; end

                cr = NaN;
                if isfield(e, 'biomass_occupation') && isstruct(e.biomass_occupation) ...
                        && isfield(e.biomass_occupation, 'CaptureRatio') ...
                        && isnumeric(e.biomass_occupation.CaptureRatio) ...
                        && isscalar(e.biomass_occupation.CaptureRatio)
                    cr = double(e.biomass_occupation.CaptureRatio);
                end

                plates(i).genotype     = char(e.genotype);
                plates(i).passage      = double(pas);
                plates(i).replicate    = rep;
                plates(i).source       = char(e.source_type);
                plates(i).days         = double(days);
                plates(i).count        = double(cnt);
                plates(i).captureRatio = cr;
                plates(i).separable    = isfinite(cr) && cr >= config.resolvedRatioMin;
                plates(i).filename     = char(e.filename);
            end
        end

        function config = resolveTarget(plates, config)
            % MODEL (TERMINAL): the shared count target. A numeric target in
            % config is kept. Otherwise the target is the median colony count
            % across plates eligible under the default pool rule (6-day,
            % Standard, dataset replicates, separable, count of at least one),
            % so the target sits inside the range the pools draw from.
            if ~isempty(config.target)
                config.targetRule = 'fixed in config';
                return;
            end

            reps = unique([config.datasetReplicate{:}]);
            vals = [];
            for j = 1:numel(plates)
                q = plates(j);
                if q.days == config.incubationDays ...
                        && strcmp(q.source, 'Standard') ...
                        && any(strcmp(q.replicate, reps)) ...
                        && q.separable ...
                        && isfinite(q.count) && q.count >= 1
                    vals(end+1) = q.count; %#ok<AGROW>
                end
            end

            if isempty(vals)
                error('CountDatasetGenerator:noEligible', ...
                      'No eligible plates to set a count target.');
            end
            config.target     = median(vals);
            config.targetRule = sprintf('median of %d eligible plates', numel(vals));
        end

        function grid = blankGrid()
            % MODEL (TERMINAL): a 1x5 passage grid with the four genotype
            % fields empty, matching the DatasetCreator grid shape.
            one  = struct('wild_type', [], 'dbf4_1', [], 'cdc13_2', [], 'double', []);
            grid = repmat(one, 1, 5);
        end

        function spec = getPoolSpec(config, datasetNum, genotype, passage)
            % MODEL (TERMINAL): the candidate filter for one cell. Defaults to
            % 6-day Standard plates of the dataset's replicates; an override
            % for this dataset, genotype, and passage replaces the sources and
            % replicates or marks the cell to stay empty.
            spec.genotype   = genotype;
            spec.passage    = passage;
            spec.days       = config.incubationDays;
            spec.sources    = {'Standard'};
            spec.replicates = config.datasetReplicate{datasetNum};
            spec.skip       = false;
            spec.ratioMin   = config.resolvedRatioMin;

            for k = 1:numel(config.overrides)
                o = config.overrides(k);
                if o.datasetNum == datasetNum && strcmp(o.genotype, genotype) ...
                        && o.passage == passage
                    spec.sources    = o.sources;
                    spec.replicates = o.replicates;
                    spec.skip       = o.skip;
                end
            end
        end

        function [grid, rec] = placeCell(grid, passage, field, spec, plates, C, target)
            % MODEL CONTROLLER: resolve one cell. A skipped cell stays empty
            % with status 'noplate'. Otherwise the pool is every plate passing
            % the spec, and the plate whose colony count is closest to the
            % target fills the cell. An empty pool leaves the cell empty with
            % status 'miss' and carries a diagnostic naming which filters the
            % candidate plates failed. Calls model terminals only.
            rec = struct('status', '', 'filename', '', 'count', NaN, ...
                         'captureRatio', NaN, 'nPool', 0, 'diag', []);

            if spec.skip
                rec.status = 'noplate';
                return;
            end

            pool      = buildPool(plates, spec);
            rec.nPool = numel(pool);

            if isempty(pool)
                rec.status = 'miss';
                rec.diag   = diagnoseEmptyPool(plates, spec);
                return;
            end

            pick = choosePlate(plates, pool, target);

            grid(passage).(field) = C(pick);
            rec.status       = 'selected';
            rec.filename     = plates(pick).filename;
            rec.count        = plates(pick).count;
            rec.captureRatio = plates(pick).captureRatio;

            function pool = buildPool(plates, spec)
                % MODEL (TERMINAL): indices of plates matching the spec's
                % genotype, passage, incubation time, source type, and
                % replicate, inside the separable range, with a colony count
                % of at least one. Pooled entries (A+B) never match a
                % single-replicate label.
                pool = [];
                for j = 1:numel(plates)
                    q = plates(j);
                    if strcmp(q.genotype, spec.genotype) ...
                            && q.passage == spec.passage ...
                            && q.days == spec.days ...
                            && any(strcmp(q.source, spec.sources)) ...
                            && any(strcmp(q.replicate, spec.replicates)) ...
                            && q.separable ...
                            && isfinite(q.count) && q.count >= 1
                        pool(end+1) = j; %#ok<AGROW>
                    end
                end
            end

            function pick = choosePlate(plates, pool, target)
                % MODEL (TERMINAL): the pool index whose colony count lies
                % closest to the target. A tie resolves to the first plate in
                % composite order.
                counts = [plates(pool).count];
                [~, best] = min(abs(counts - target));
                pick = pool(best);
            end

            function diag = diagnoseEmptyPool(plates, spec)
                % MODEL (TERMINAL): why the pool came back empty. Anchors on
                % genotype and passage, then evaluates the incubation time,
                % source type, replicate, separability, and count filters
                % independently for each anchored plate, so every failure a
                % plate carries is recorded rather than the first one found.
                % Counts plates failing exactly one filter, since those name
                % the single filter standing between the cell and a plate.
                % When no plate carries the genotype and passage at all, the
                % genotype strings and passage numbers present in the
                % composite are recorded instead, which catches a label
                % mismatch.
                diag = struct();
                diag.spec = spec;

                allGeno   = {plates.genotype};
                allPas    = [plates.passage];
                genoMask  = strcmp(allGeno, spec.genotype);

                diag.genotypesSeen   = unique(allGeno);
                diag.nGenotype       = sum(genoMask);

                pasSeen              = allPas(genoMask);
                diag.passagesSeen    = unique(pasSeen(isfinite(pasSeen)));

                anchor               = genoMask & (allPas == spec.passage);
                diag.nGenotypePassage = sum(anchor);

                diag.candidates = struct('filename', {}, 'days', {}, ...
                    'source', {}, 'replicate', {}, 'captureRatio', {}, ...
                    'count', {}, 'okDays', {}, 'okSource', {}, ...
                    'okReplicate', {}, 'okSeparable', {}, 'okCount', {}, ...
                    'separableNote', {}, 'nFail', {});

                diag.failDays      = 0;
                diag.failSource    = 0;
                diag.failReplicate = 0;
                diag.failSeparable = 0;
                diag.failCount     = 0;
                diag.nSingleFail   = 0;

                idx = find(anchor);
                for j = 1:numel(idx)
                    q = plates(idx(j));

                    okDays      = isfinite(q.days) && q.days == spec.days;
                    okSource    = any(strcmp(q.source, spec.sources));
                    okReplicate = any(strcmp(q.replicate, spec.replicates));
                    okSeparable = q.separable;
                    okCount     = isfinite(q.count) && q.count >= 1;

                    if okSeparable
                        note = 'in range';
                    elseif ~isfinite(q.captureRatio)
                        note = 'no capture ratio stored';
                    else
                        note = sprintf('%.3f below %.2f floor', ...
                                       q.captureRatio, spec.ratioMin);
                    end

                    nFail = (~okDays) + (~okSource) + (~okReplicate) ...
                          + (~okSeparable) + (~okCount);

                    diag.failDays      = diag.failDays      + (~okDays);
                    diag.failSource    = diag.failSource    + (~okSource);
                    diag.failReplicate = diag.failReplicate + (~okReplicate);
                    diag.failSeparable = diag.failSeparable + (~okSeparable);
                    diag.failCount     = diag.failCount     + (~okCount);
                    diag.nSingleFail   = diag.nSingleFail   + (nFail == 1);

                    diag.candidates(end+1) = struct( ...
                        'filename',      q.filename, ...
                        'days',          q.days, ...
                        'source',        q.source, ...
                        'replicate',     q.replicate, ...
                        'captureRatio',  q.captureRatio, ...
                        'count',         q.count, ...
                        'okDays',        okDays, ...
                        'okSource',      okSource, ...
                        'okReplicate',   okReplicate, ...
                        'okSeparable',   okSeparable, ...
                        'okCount',       okCount, ...
                        'separableNote', note, ...
                        'nFail',         nFail); %#ok<AGROW>
                end
            end
        end

        function out = makeCellReport(datasetNum, passage, label, rec)
            % MODEL (TERMINAL): one cell-outcome record for the view.
            out = struct('datasetNum', datasetNum, 'passage', passage, ...
                         'label', label, 'status', rec.status, ...
                         'filename', rec.filename, 'count', rec.count, ...
                         'captureRatio', rec.captureRatio, 'nPool', rec.nPool, ...
                         'diag', rec.diag);
        end
    end

    function reportSummary(report, config)
        % SUB-CONTROLLER (view): command-window summary. Leads with the rule,
        % target, and separability floor, then per-dataset tallies, then every
        % selected plate with its count and distance from the target, then the
        % cells left empty, then a per-filter diagnostic for each cell with no
        % eligible plate. Cells with no eligible plate also raise a warning.
        % Calls view terminals only.
        printHeader(report, config);
        printPerDataset(report);
        printSelections(report, config);
        printEmptyCells(report);
        printMissDiagnostics(report);
        warnUnresolved(report);

        function printHeader(report, config)
            % VIEW (TERMINAL): dataset count, the selection rule, the target
            % and how it was set, and the separability floor.
            nDatasets = numel(unique([report.datasetNum]));
            fprintf('\n=== CountDatasetGenerator ===\n');
            fprintf('Datasets created: %d (one plate per genotype and passage, Rep A and Rep B pooled)\n', nDatasets);
            fprintf('Rule: plate with colony count closest to %g (%s).\n', ...
                config.target, config.targetRule);
            fprintf('Separable range: capture ratio >= %.2f (colony coverage / growth coverage).\n', ...
                config.resolvedRatioMin);
        end

        function printPerDataset(report)
            % VIEW (TERMINAL): per-dataset tally of selected and empty cells.
            fprintf('\nPer-dataset summary:\n');
            fprintf('  %-9s %8s %8s %8s\n', 'dataset', 'selected', 'noplate', 'missed');
            dnums = unique([report.datasetNum]);
            for di = 1:numel(dnums)
                dn   = dnums(di);
                mask = [report.datasetNum] == dn;
                stt  = {report(mask).status};
                fprintf('  Dataset%-2d %8d %8d %8d\n', dn, ...
                    sum(strcmp(stt, 'selected')), ...
                    sum(strcmp(stt, 'noplate')), ...
                    sum(strcmp(stt, 'miss')));
            end
        end

        function printSelections(report, config)
            % VIEW (TERMINAL): every selected plate with its colony count,
            % distance from the target, capture ratio, and pool size.
            fprintf('\nSelected plates:\n');
            fprintf('  %-9s %-4s %-10s %6s %6s %6s %5s  %s\n', ...
                'dataset', 'pass', 'genotype', 'count', 'dist', 'capt', 'pool', 'filename');
            for i = 1:numel(report)
                r = report(i);
                if strcmp(r.status, 'selected')
                    fprintf('  Dataset%-2d P%-3d %-10s %6g %6g %6.3f %5d  %s\n', ...
                        r.datasetNum, r.passage, r.label, r.count, ...
                        abs(r.count - config.target), r.captureRatio, ...
                        r.nPool, r.filename);
                end
            end
        end

        function printEmptyCells(report)
            % VIEW (TERMINAL): every cell left empty and why. A noplate cell is
            % a passage-line skip; a miss cell had no eligible plate.
            fprintf('\nEmpty cells:\n');
            anyEmpty = false;
            for i = 1:numel(report)
                r = report(i);
                switch r.status
                    case 'noplate'
                        anyEmpty = true;
                        fprintf('  Dataset%d %-10s P%d  skipped by passage-line override\n', ...
                            r.datasetNum, r.label, r.passage);
                    case 'miss'
                        anyEmpty = true;
                        fprintf('  Dataset%d %-10s P%d  no eligible plate (6-day, Standard, separable)\n', ...
                            r.datasetNum, r.label, r.passage);
                end
            end
            if ~anyEmpty
                fprintf('  none; every cell resolved to a plate.\n');
            end
        end

        function printMissDiagnostics(report)
            % VIEW (TERMINAL): for each cell with no eligible plate, the spec
            % it searched under, then one row per plate carrying that genotype
            % and passage showing which filters that plate passed. A plate
            % failing several filters shows every failure. The per-filter
            % tallies count each filter independently, so they sum above the
            % number of plates when plates fail more than one. A cell with no
            % plate at the genotype and passage prints the genotype strings
            % and passage numbers that do appear.
            hasMiss = any(strcmp({report.status}, 'miss'));
            if ~hasMiss
                return;
            end

            fprintf('\nEmpty pool diagnostics:\n');

            for i = 1:numel(report)
                r = report(i);
                if ~strcmp(r.status, 'miss')
                    continue;
                end

                d = r.diag;
                s = d.spec;

                fprintf('\n  Dataset%d %s P%d\n', r.datasetNum, r.label, r.passage);
                fprintf('    spec: genotype ''%s'', passage %d, days %g, source {%s}, replicate {%s}, capture ratio >= %.2f, count >= 1\n', ...
                    s.genotype, s.passage, s.days, ...
                    strjoin(s.sources, ', '), strjoin(s.replicates, ', '), ...
                    s.ratioMin);
                fprintf('    plates with this genotype: %d; with this genotype and passage: %d\n', ...
                    d.nGenotype, d.nGenotypePassage);

                if d.nGenotypePassage == 0
                    if d.nGenotype == 0
                        fprintf('    no plate carries genotype ''%s''. Genotype strings present: %s\n', ...
                            s.genotype, strjoin(d.genotypesSeen, ', '));
                    else
                        fprintf('    no plate carries passage %d for this genotype. Passages present: %s\n', ...
                            s.passage, strjoin(arrayfun(@(x) sprintf('%g', x), ...
                            d.passagesSeen, 'UniformOutput', false), ', '));
                    end
                    continue;
                end

                fprintf('    %5s %-10s %-9s %7s %7s  %-44s  %s\n', ...
                    'days', 'source', 'replicate', 'capt', 'count', 'filename', 'filters failed');

                for k = 1:numel(d.candidates)
                    c = d.candidates(k);

                    failed = {};
                    if ~c.okDays,      failed{end+1} = sprintf('days(%g)', c.days); end %#ok<AGROW>
                    if ~c.okSource,    failed{end+1} = sprintf('source(%s)', c.source); end %#ok<AGROW>
                    if ~c.okReplicate, failed{end+1} = sprintf('replicate(''%s'')', c.replicate); end %#ok<AGROW>
                    if ~c.okSeparable, failed{end+1} = sprintf('separable(%s)', c.separableNote); end %#ok<AGROW>
                    if ~c.okCount,     failed{end+1} = sprintf('count(%g)', c.count); end %#ok<AGROW>

                    if isempty(failed)
                        failText = 'none (plate passes the spec; pool build disagrees)';
                    else
                        failText = strjoin(failed, ', ');
                    end

                    fprintf('    %5g %-10s %-9s %7.3f %7g  %-44s  %s\n', ...
                        c.days, c.source, c.replicate, c.captureRatio, ...
                        c.count, c.filename, failText);
                end

                fprintf('    filter tallies over %d plates: days %d, source %d, replicate %d, separable %d, count %d\n', ...
                    d.nGenotypePassage, d.failDays, d.failSource, ...
                    d.failReplicate, d.failSeparable, d.failCount);
                fprintf('    plates failing exactly one filter: %d\n', d.nSingleFail);
            end
        end

        function warnUnresolved(report)
            % VIEW (TERMINAL): a warning for each cell with no eligible plate,
            % so an empty pool is not silent.
            for i = 1:numel(report)
                r = report(i);
                if strcmp(r.status, 'miss')
                    warning('CountDatasetGenerator:miss', ...
                        'Dataset%d %s P%d: no eligible plate; cell left empty.', ...
                        r.datasetNum, r.label, r.passage);
                end
            end
        end
    end
end

%%