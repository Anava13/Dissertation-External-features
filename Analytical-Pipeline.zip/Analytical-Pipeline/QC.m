classdef QC
% QC  Shared utilities for the Part 2 / Part 3 colony-size analyses.
%
%   Bundled as a classdef because MATLAB exposes only one public function per
%   .m file; static methods give every utility an external call site
%   (QC.fitLine, QC.buildPlateRecords, ...). The methods are grouped below as
%   STATS, DATA, and VIEW. Each method follows the same nested MVC discipline
%   as the analysis controllers: terminals do not call other functions, and a
%   method that orchestrates calls only lower-level terminals (or sibling
%   static methods, the global analog of a base-level shared function).
%
%   The inclusion filter is the V2 confluency filter for every analysis. Its
%   three constants (crowding field name, resolved-ratio floor, Part 2 HCE
%   ceiling) live only in buildConfig; no analysis hardcodes them and no plate
%   count appears anywhere.

    methods (Static)

        % ================================================================
        % ===                        STATS                             ===
        % ================================================================

        function fit = fitLine(x, y)
            % MODEL (TERMINAL): ordinary least squares y = a + b*x with R^2.
            % Validity is finite x and finite y only; any positivity
            % requirement is the caller's job, applied before the call, so this
            % stays a single fit primitive for raw values and within-state
            % deviations alike. Field set matches fitPowerLaw so the shared
            % draw and print helpers consume both.

            fit = struct('slope', NaN, 'intercept', NaN, 'r2', NaN, ...
                         'n', 0, 'xfit', [], 'yfit', []);

            x = x(:);
            y = y(:);
            valid = isfinite(x) & isfinite(y);
            x = x(valid);
            y = y(valid);
            fit.n = numel(x);

            if fit.n < 2 || numel(unique(x)) < 2
                return;
            end

            p = polyfit(x, y, 1);
            fit.slope     = p(1);
            fit.intercept = p(2);

            yhat  = polyval(p, x);
            ssRes = sum((y - yhat).^2);
            ssTot = sum((y - mean(y)).^2);
            if ssTot > 0
                fit.r2 = 1 - ssRes / ssTot;
            end

            xspan    = linspace(min(x), max(x), 100);
            fit.xfit = xspan;
            fit.yfit = polyval(p, xspan);
        end

        function fit = fitPowerLaw(x, y)
            % MODEL CONTROLLER: log-log power-law fit y = a * x^b. Filters to
            % x > 0 and y > 0, fits the logs with fitLine, then carries the
            % slope (b), intercept (log10 a), and R^2 across. The fit-line
            % coordinates are rebuilt in linear space so they overlay directly
            % on log axes.

            fit = struct('slope', NaN, 'intercept', NaN, 'r2', NaN, ...
                         'n', 0, 'xfit', [], 'yfit', []);

            x = x(:);
            y = y(:);
            valid = isfinite(x) & isfinite(y) & x > 0 & y > 0;
            x = x(valid);
            y = y(valid);
            fit.n = numel(x);

            if fit.n < 2 || numel(unique(x)) < 2
                return;
            end

            core = QC.fitLine(log10(x), log10(y));
            fit.slope     = core.slope;
            fit.intercept = core.intercept;
            fit.r2        = core.r2;

            xspan    = logspace(log10(min(x)), log10(max(x)), 100);
            fit.xfit = xspan;
            fit.yfit = (10 .^ fit.intercept) .* (xspan .^ fit.slope);
        end

        function v = applyTransform(v, mode)
            % MODEL (TERMINAL): log10 or identity, returned as a row vector. For
            % 'log', non-positive values become NaN and drop downstream.

            v = double(v(:)');
            switch mode
                case 'log'
                    v(~(v > 0)) = NaN;
                    v = log10(v);
                case 'linear'
                    % identity
                otherwise
                    error('QC:applyTransform', 'Unknown transform mode: %s', mode);
            end
        end

        function d = demeanWithinStates(v, blk)
            % MODEL (TERMINAL): subtract each state's mean from its members. v
            % and blk are the same length and already finite.

            d = nan(size(v));
            ids = unique(blk);
            for j = 1:numel(ids)
                m = (blk == ids(j));
                d(m) = v(m) - mean(v(m));
            end
        end

        function panel = demeanedFit(rawX, rawY, blk, geno, xT, yT, doDemean)
            % MODEL CONTROLLER: transform X and Y, optionally center each on its
            % state mean, fit with fitLine, and return a base panel. doDemean
            % false leaves raw transformed values (a pooled, state-ignored fit);
            % doDemean true centers each variable within state (a state-fixed-
            % effects fit). Callers decorate the returned struct with the
            % analysis-specific fields (label, grain, reference slope, limits).

            tx = QC.applyTransform(rawX, xT);
            ty = QC.applyTransform(rawY, yT);

            ok = isfinite(tx) & isfinite(ty) & isfinite(blk);
            tx = tx(ok);
            ty = ty(ok);
            b  = blk(ok);
            g  = geno(ok);

            if doDemean
                x = QC.demeanWithinStates(tx, b);
                y = QC.demeanWithinStates(ty, b);
            else
                x = tx;
                y = ty;
            end

            fit = QC.fitLine(x, y);

            panel = struct();
            panel.x             = x;
            panel.y             = y;
            panel.pointGenotype = g;
            panel.slope         = fit.slope;
            panel.intercept     = fit.intercept;
            panel.r2            = fit.r2;
            panel.xfit          = fit.xfit;
            panel.yfit          = fit.yfit;
            panel.nUnits        = numel(x);
            panel.nstates       = numel(unique(b));
        end

        function lim = paddedLimits(v)
            % MODEL (TERMINAL): padded axis limits. Empty input returns a unit
            % window; a degenerate range is widened by one unit either side.

            v = v(isfinite(v));
            if isempty(v)
                lim = [-1, 1];
                return;
            end
            lo = min(v);
            hi = max(v);
            if lo == hi
                lo = lo - 1;
                hi = hi + 1;
            end
            pad = 0.05 * (hi - lo);
            lim = [lo - pad, hi + pad];
        end

        function g = geoMean(v)
            % MODEL (TERMINAL): geometric mean of the positive finite entries;
            % empty input returns NaN.

            v = v(isfinite(v) & v > 0);
            if isempty(v)
                g = NaN;
                return;
            end
            g = exp(mean(log(v)));
        end

        function r = averageRanks(v)
            % MODEL (TERMINAL): ascending ranks with ties assigned the mean of
            % the ranks they span. Tie handling matters because isolated
            % colonies share a crowding score of exactly 0.

            v = v(:);
            n = numel(v);
            r = zeros(n, 1);
            if n == 0
                return;
            end

            [sorted, idx] = sort(v);
            i = 1;
            while i <= n
                j = i;
                while j < n && sorted(j + 1) == sorted(i)
                    j = j + 1;
                end
                r(idx(i:j)) = (i + j) / 2;
                i = j + 1;
            end
        end

        function rho = spearmanRho(x, y)
            % MODEL CONTROLLER: Spearman rank correlation, the linear fit of the
            % tie-averaged ranks. Validity requires finite x and finite positive
            % y so the radius axis stays positive.

            rho = NaN;
            x = x(:);
            y = y(:);
            valid = isfinite(x) & isfinite(y) & y > 0;
            x = x(valid);
            y = y(valid);
            if numel(x) < 2
                return;
            end

            rx = QC.averageRanks(x);
            ry = QC.averageRanks(y);
            f  = QC.fitLine(rx, ry);
            if isfinite(f.r2) && isfinite(f.slope)
                rho = sign(f.slope) * sqrt(f.r2);
            end
        end

        function partition = variancePartition(vals, blk)
            % MODEL (TERMINAL): one-way variance decomposition with state as the
            % grouping factor. eta^2 is the observed between-state fraction of
            % total sum of squares (treats state means as exact). ICC(1) is the
            % variance-component ratio by method of moments with the unequal-
            % group-size correction n0, discounting the sampling noise in small-
            % state means; it can come out negative when within-state noise
            % exceeds the between-state signal. sdBetween and sdWithin are the
            % square roots of the two variance components, in the input units.

            valid = isfinite(vals) & isfinite(blk);
            vals  = vals(valid);
            blk   = blk(valid);

            partition = struct('ssBetween', NaN, 'ssWithin', NaN, ...
                'ssTotal', NaN, 'eta2', NaN, 'k', 0, 'N', 0, ...
                'dfBetween', NaN, 'dfWithin', NaN, 'msBetween', NaN, ...
                'msWithin', NaN, 'n0', NaN, 'icc', NaN, 'grandMean', NaN, ...
                'sdBetween', NaN, 'sdWithin', NaN, 'nSingleton', 0, ...
                'meanWithinCV', NaN);

            N = numel(vals);
            if N < 2
                return;
            end

            ids   = unique(blk);
            k     = numel(ids);
            grand = mean(vals);

            ssBetween  = 0;
            ssWithin   = 0;
            sumNsq     = 0;
            nSingleton = 0;
            withinCVs  = [];

            for j = 1:k
                m  = (blk == ids(j));
                xb = vals(m);
                nb = numel(xb);
                mb = mean(xb);

                ssBetween = ssBetween + nb * (mb - grand)^2;
                ssWithin  = ssWithin  + sum((xb - mb).^2);
                sumNsq    = sumNsq + nb^2;

                if nb == 1
                    nSingleton = nSingleton + 1;
                elseif mb ~= 0
                    withinCVs(end+1) = std(xb) / mb; %#ok<AGROW>
                end
            end

            ssTotal = ssBetween + ssWithin;

            partition.ssBetween  = ssBetween;
            partition.ssWithin   = ssWithin;
            partition.ssTotal    = ssTotal;
            partition.k          = k;
            partition.N          = N;
            partition.grandMean  = grand;
            partition.nSingleton = nSingleton;

            if ssTotal > 0
                partition.eta2 = ssBetween / ssTotal;
            end
            if ~isempty(withinCVs)
                partition.meanWithinCV = mean(withinCVs);
            end

            dfBetween = k - 1;
            dfWithin  = N - k;
            partition.dfBetween = dfBetween;
            partition.dfWithin  = dfWithin;

            if dfWithin >= 1
                msWithin           = ssWithin / dfWithin;
                partition.msWithin = msWithin;
                partition.sdWithin = sqrt(msWithin);
            else
                msWithin = NaN;
            end

            if dfBetween >= 1
                msBetween           = ssBetween / dfBetween;
                partition.msBetween = msBetween;
            else
                msBetween = NaN;
            end

            if dfBetween >= 1
                n0           = (1 / dfBetween) * (N - sumNsq / N);
                partition.n0 = n0;
                if isfinite(msBetween) && isfinite(msWithin)
                    denom = msBetween + (n0 - 1) * msWithin;
                    if denom ~= 0
                        partition.icc = (msBetween - msWithin) / denom;
                    end
                    if n0 > 0
                        partition.sdBetween = sqrt(max(0, (msBetween - msWithin) / n0));
                    end
                end
            end
        end

        function rel = computeRelationshipFits(x, y, gtypes, order, fitFun)
            % MODEL CONTROLLER: pooled plus per-genotype fits over aligned x, y,
            % and genotype arrays. fitFun selects the fit form and defaults to
            % the log-log power law; pass @QC.fitLine for a linear relationship
            % (the crowding score carries structural zeros a log transform would
            % discard).

            if nargin < 5 || isempty(fitFun)
                fitFun = @QC.fitPowerLaw;
            end

            rel = struct();
            rel.x      = x(:)';
            rel.y      = y(:)';
            rel.gtypes = gtypes(:)';
            rel.pooled = fitFun(x, y);

            nG       = numel(order);
            emptyFit = fitFun([], []);
            byGenotype = repmat(struct('genotype', '', 'fit', emptyFit), 1, nG);

            for gi = 1:nG
                g = order{gi};
                gmask = strcmp(rel.gtypes, g);
                byGenotype(gi).genotype = g;
                byGenotype(gi).fit      = fitFun(rel.x(gmask), rel.y(gmask));
            end

            rel.byGenotype = byGenotype;
        end

        function fit = pickGenotypeFit(rel, g)
            % MODEL (TERMINAL): return the per-genotype fit struct for genotype g
            % from a computed relationship, or a NaN fit if absent.

            fit = struct('slope', NaN, 'intercept', NaN, 'r2', NaN, 'n', 0, ...
                         'xfit', [], 'yfit', []);
            if ~isfield(rel, 'byGenotype')
                return;
            end
            for k = 1:numel(rel.byGenotype)
                if strcmp(rel.byGenotype(k).genotype, g)
                    fit = rel.byGenotype(k).fit;
                    return;
                end
            end
        end

        % ================================================================
        % ===                         DATA                             ===
        % ================================================================

        function config = buildConfig()
            % MODEL (TERMINAL): the universal display and filter constants.
            % Genotype display order, colors, and labels are shared by every
            % analysis; the three filter constants (crowding field name, the
            % confluency resolved-ratio floor, and the Part 2 HCE ceiling) live
            % only here. Analyses extend this struct with their own transforms
            % and reference slopes. Source-type exceptions admit named
            % non-Standard plates for specific Part 3 (genotype, passage) cells.

            config = struct();
            config.order = {'wild_type', 'dbf4-1', 'cdc13-2', 'double', ...
                            'wild_type_dilution'};

            ck = config.order;
            cv = { [0.00 0.45 0.74], ...   % blue   - wild type
                   [0.47 0.67 0.19], ...   % green  - dbf4-1
                   [0.85 0.33 0.10], ...   % orange - cdc13-2
                   [0.49 0.18 0.56], ...   % purple - double
                   [0.10 0.60 0.55] };     % teal   - Part 2 reference
            config.colors = containers.Map(ck, cv);

            lv = {'Wild Type', 'dbf4-1', 'cdc13-2', 'dbf4-1 cdc13-2', ...
                  'WT Dilution (Part 2)'};
            config.labels = containers.Map(ck, lv);

            % per colony, in Measurements, aligned with Measurements.Radius
            config.crowdingField = 'CrowdingScores';

            % confluency floor: a plate is kept only when discrete colony
            % coverage is at least this fraction of total growth coverage. Below
            % it, too much growth has merged into unresolved lawn for
            % colony_count to stand in for competitor number.
            config.resolvedRatioMin = 0.25;

            % Inf keeps every Part 2 plate on the HCE axis; confluency is
            % handled by resolvedRatioMin, which reads the coverage ratio
            % directly rather than HCE as a proxy.
            config.part2HCEceiling = Inf;

            % source-type exceptions: each entry admits the listed source_type
            % values for one Part 3 (genotype, passage) cell in addition to the
            % default 'Standard'. A plate in a listed cell whose source_type is
            % in that entry's sources passes source gating. Add a row (a parallel
            % genotype, passage, sources triple) to extend to another cell, for
            % example cdc13-2 P5. cdc13-2 P4 admits 'LargeSourced'.
            config.sourceExceptions = struct( ...
                'genotype', {'cdc13-2'}, ...
                'passage',  {4}, ...
                'sources',  {{'LargeSourced'}});
        end
        function raw = extractPart2Fields(Part2CompleteData, config)
            % MODEL (TERMINAL): hce, count, total growth coverage, discrete
            % colony coverage, capture ratio, median, and the per-colony radius
            % and crowding vectors. Median comes from summary_stats.median,
            % falling back to the median of finite-positive Measurements.Radius.
            % colonyCov feeds the confluency ratio. captureRatio is
            % biomass_occupation.CaptureRatio, NaN when absent or not a numeric
            % scalar.

            C = Part2CompleteData.composite;
            n = numel(C);

            template = struct('hce', NaN, 'count', NaN, 'coverage', NaN, ...
                'colonyCov', NaN, 'captureRatio', NaN, 'median', NaN, ...
                'colonyRadius', [], 'colonyCrowding', []);
            raw = repmat(template, 1, n);

            for i = 1:n
                e = C(i);

                if isfield(e, 'hce') && isscalar(e.hce)
                    raw(i).hce = double(e.hce);
                end
                raw(i).count = double(e.colony_count);

                if isfield(e, 'biomass_occupation') && ~isempty(e.biomass_occupation)
                    bo = e.biomass_occupation;
                    if isfield(bo, 'growth') && isscalar(bo.growth) && isfinite(bo.growth)
                        raw(i).coverage = 100 * double(bo.growth);
                    end
                    if isfield(bo, 'colony') && isscalar(bo.colony) && isfinite(bo.colony)
                        raw(i).colonyCov = 100 * double(bo.colony);
                    end
                    if isstruct(bo) && isfield(bo, 'CaptureRatio') ...
                            && isnumeric(bo.CaptureRatio) && isscalar(bo.CaptureRatio)
                        raw(i).captureRatio = double(bo.CaptureRatio);
                    end
                end

                radii = [];
                if isfield(e, 'Measurements') && isstruct(e.Measurements)
                    M = e.Measurements;
                    if isfield(M, 'Radius')
                        radii = double(M.Radius(:)');
                        raw(i).colonyRadius = radii;
                    end
                    if isfield(M, config.crowdingField)
                        raw(i).colonyCrowding = double(M.(config.crowdingField)(:)');
                    end
                end

                med = NaN;
                if isfield(e, 'summary_stats') && ~isempty(e.summary_stats) ...
                        && isfield(e.summary_stats, 'median')
                    med = double(e.summary_stats.median);
                end
                if ~isfinite(med) && ~isempty(radii)
                    rr = radii(isfinite(radii) & radii > 0);
                    if ~isempty(rr)
                        med = median(rr);
                    end
                end
                raw(i).median = med;
            end
        end
        function crit = evaluatePart2Inclusion(r, okColony, config)
            % MODEL (TERMINAL): Part 2 inclusion predicates as booleans. Same
            % confluency criterion as Part 3; the HCE predicate carries the
            % confluency ceiling. okColony comes from alignColonyPair at the
            % call site.

            crit = struct();
            crit.hasCount    = isfinite(r.count) && r.count >= 1;
            crit.hasHCE      = isfinite(r.hce) && r.hce > 0 && r.hce <= config.part2HCEceiling;
            crit.hasMedian   = isfinite(r.median) && r.median > 0;
            crit.hasCov      = isfinite(r.coverage);
            crit.hasResolved = isfinite(r.coverage) && r.coverage > 0 && ...
                               isfinite(r.colonyCov) && r.colonyCov >= 0 && ...
                               (r.colonyCov / r.coverage) >= config.resolvedRatioMin;
            crit.okColony    = logical(okColony);
        end
       function kept = filterPart2(Part2CompleteData, config)
            % MODEL CONTROLLER: Part 2 extraction, then inclusion. Survivors are
            % tagged as the dilution reference state with passage NaN. Same
            % normalized record as Part 3.

            raw = QC.extractPart2Fields(Part2CompleteData, config);

            template = QC.plateRecordTemplate();
            kept = repmat(template, 1, 0);

            for i = 1:numel(raw)
                r = raw(i);
                [cr, cc, okColony] = QC.alignColonyPair(r.colonyRadius, r.colonyCrowding);
                crit = QC.evaluatePart2Inclusion(r, okColony, config);

                allOk = crit.hasCount && crit.hasHCE && crit.hasMedian && ...
                        crit.hasCov && crit.hasResolved && crit.okColony;

                if allOk
                    rec = template;
                    rec.genotype       = 'wild_type_dilution';
                    rec.passage        = NaN;
                    rec.part           = 'part2';
                    rec.hce            = r.hce;
                    rec.count          = r.count;
                    rec.coverage       = r.coverage;
                    rec.colonyCov      = r.colonyCov;
                    rec.captureRatio   = r.captureRatio;
                    rec.median         = r.median;
                    rec.colonyRadius   = cr;
                    rec.colonyCrowding = cc;
                    kept(end+1) = rec; %#ok<AGROW>
                end
            end
        end
  function plates = buildPlateRecords(combined, config)
            % MODEL CONTROLLER: the shared inclusion filter. Extract and filter
            % each part into one normalized record, then concatenate. Part 3
            % keeps its design identity; Part 2 enters as the single dilution
            % reference state (genotype wild_type_dilution, passage NaN). Both
            % parts emit records with identical fields in identical order, so the
            % concatenation is well-defined when either part contributes no rows.

            p3     = QC.filterPart3(combined.part3, config);
            p2     = QC.filterPart2(combined.part2, config);
            plates = [p3, p2];
        end
        function raw = extractPart3Fields(Part3CompleteData, config)
            % MODEL (TERMINAL): Part 3 design fields, count, hce, median, total
            % growth coverage, discrete colony coverage, capture ratio, and the
            % per-colony radius and crowding vectors. Read by both the inclusion
            % filter and the omitted-state diagnostic so both see the same raw
            % records. coverage is total growth coverage and colonyCov is colony
            % coverage; their ratio is the confluency criterion. captureRatio is
            % biomass_occupation.CaptureRatio, NaN when absent or not a numeric
            % scalar.

            C = Part3CompleteData.composite;
            n = numel(C);

            template = struct('genotype', '', 'passage', NaN, ...
                'hce', NaN, 'count', NaN, 'coverage', NaN, 'colonyCov', NaN, ...
                'captureRatio', NaN, 'median', NaN, 'colonyRadius', [], ...
                'colonyCrowding', [], 'source_type', '', 'incubation_days', NaN, ...
                'enrichment', '', 'replicate', '');
            raw = repmat(template, 1, n);

            for i = 1:n
                e = C(i);
                raw(i).genotype = e.genotype;
                raw(i).passage  = double(e.passage);
                raw(i).count    = double(e.colony_count);

                if isfield(e, 'hce') && isscalar(e.hce)
                    raw(i).hce = double(e.hce);
                end

                if isfield(e, 'summary_stats') && ~isempty(e.summary_stats) ...
                        && isfield(e.summary_stats, 'median')
                    raw(i).median = double(e.summary_stats.median);
                end

                if isfield(e, 'biomass_occupation') && ~isempty(e.biomass_occupation)
                    bo = e.biomass_occupation;
                    if isfield(bo, 'growth') && isscalar(bo.growth) && isfinite(bo.growth)
                        raw(i).coverage = 100 * double(bo.growth);
                    end
                    if isfield(bo, 'colony') && isscalar(bo.colony) && isfinite(bo.colony)
                        raw(i).colonyCov = 100 * double(bo.colony);
                    end
                    if isstruct(bo) && isfield(bo, 'CaptureRatio') ...
                            && isnumeric(bo.CaptureRatio) && isscalar(bo.CaptureRatio)
                        raw(i).captureRatio = double(bo.CaptureRatio);
                    end
                end

                if isfield(e, 'Measurements') && isstruct(e.Measurements)
                    M = e.Measurements;
                    if isfield(M, 'Radius')
                        raw(i).colonyRadius = double(M.Radius(:)');
                    end
                    if isfield(M, config.crowdingField)
                        raw(i).colonyCrowding = double(M.(config.crowdingField)(:)');
                    end
                end

                raw(i).source_type     = e.source_type;
                raw(i).incubation_days = double(e.incubation_days);
                raw(i).enrichment      = e.enrichment;
                raw(i).replicate       = e.replicate;
            end
        end
        function crit = evaluatePart3Inclusion(r, okColony, config)
            % MODEL (TERMINAL): Part 3 inclusion predicates as booleans, the
            % single source the filter and the omitted-state diagnostic both
            % read. okColony comes from alignColonyPair at the call site, so
            % this stays terminal. Field order sets the order the diagnostic
            % tallies and the summary prints; hasResolved is last so the
            % existing order is unchanged.
            %
            % isStandard now means "source type accepted": a plate passes when
            % its source_type is 'Standard', or when a config.sourceExceptions
            % entry admits its source_type for this (genotype, passage) cell.
            % cdc13-2 P4 admits 'LargeSourced'. The lookup stays inline so this
            % function remains the single point of source gating; the field name
            % is unchanged so the diagnostic and summary need no relabeling.

            crit = struct();

            crit.isStandard = strcmp(r.source_type, 'Standard');
            if ~crit.isStandard && isfield(config, 'sourceExceptions')
                ex = config.sourceExceptions;
                for k = 1:numel(ex)
                    if strcmp(ex(k).genotype, r.genotype) && ...
                            isfinite(r.passage) && ex(k).passage == r.passage && ...
                            any(strcmp(r.source_type, ex(k).sources))
                        crit.isStandard = true;
                        break;
                    end
                end
            end

            crit.isSixDay    = isequal(r.incubation_days, 6);
            crit.notExcluded = ~(ischar(r.enrichment) && ...
                                 ~isempty(strfind(lower(r.enrichment), 'excluded'))); %#ok<STREMP>
            crit.notPooled   = ~(ischar(r.replicate) && ...
                                 ~isempty(strfind(r.replicate, '+'))); 
            crit.hasCount    = isfinite(r.count) && r.count >= 1;
            crit.hasHCE      = isfinite(r.hce) && r.hce > 0;
            crit.hasMedian   = isfinite(r.median) && r.median > 0;
            crit.hasCov      = isfinite(r.coverage);
            crit.okColony    = logical(okColony);
            crit.hasResolved = isfinite(r.coverage) && r.coverage > 0 && ...
                               isfinite(r.colonyCov) && r.colonyCov >= 0 && ...
                               (r.colonyCov / r.coverage) >= config.resolvedRatioMin;
        end
        function kept = filterPart3(Part3CompleteData, config)
            % MODEL CONTROLLER: Part 3 extraction, then inclusion. Predicates
            % come from evaluatePart3Inclusion and the colony pair from
            % alignColonyPair, so the filter and the omitted-state diagnostic
            % cannot diverge. The kept record carries every field any analysis
            % reads downstream; the filter-only design fields are consumed and
            % dropped.

            raw = QC.extractPart3Fields(Part3CompleteData, config);

            template = QC.plateRecordTemplate();
            kept = repmat(template, 1, 0);

            for i = 1:numel(raw)
                r = raw(i);
                [cr, cc, okColony] = QC.alignColonyPair(r.colonyRadius, r.colonyCrowding);
                crit = QC.evaluatePart3Inclusion(r, okColony, config);

                allOk = crit.isStandard && crit.isSixDay && crit.notExcluded && ...
                        crit.notPooled && crit.hasCount && crit.hasHCE && ...
                        crit.hasMedian && crit.hasCov && crit.okColony && ...
                        crit.hasResolved;

                if allOk
                    rec = template;
                    rec.genotype       = r.genotype;
                    rec.passage        = r.passage;
                    rec.part           = 'part3';
                    rec.hce            = r.hce;
                    rec.count          = r.count;
                    rec.coverage       = r.coverage;
                    rec.colonyCov      = r.colonyCov;
                    rec.captureRatio   = r.captureRatio;
                    rec.median         = r.median;
                    rec.colonyRadius   = cr;
                    rec.colonyCrowding = cc;
                    kept(end+1) = rec; %#ok<AGROW>
                end
            end
        end

        function [r, c, ok] = alignColonyPair(radius, crowding)
            % MODEL (TERMINAL): align per-colony radius and crowding. A length
            % mismatch returns ok false, which drops the plate and keeps the
            % sample identical across the four within-state panels. The aligned
            % subset keeps colonies with radius > 0 and finite crowding (a
            % crowding of zero is valid).

            r = []; c = []; ok = false;
            if isempty(radius) || isempty(crowding)
                return;
            end
            if numel(radius) ~= numel(crowding)
                return;
            end
            radius   = radius(:)';
            crowding = crowding(:)';
            keep = isfinite(radius) & radius > 0 & isfinite(crowding);
            if ~any(keep)
                return;
            end
            r  = radius(keep);
            c  = crowding(keep);
            ok = true;
        end
        function template = plateRecordTemplate()
            % MODEL (TERMINAL): the canonical normalized plate record. One
            % definition so the two filter halves and any future producer share
            % a single field set and order. captureRatio defaults to NaN, so a
            % part whose entries lack biomass_occupation.CaptureRatio still
            % emits the same fields.

            template = struct('genotype', '', 'passage', NaN, 'part', '', ...
                'hce', NaN, 'count', NaN, 'coverage', NaN, 'colonyCov', NaN, ...
                'captureRatio', NaN, 'median', NaN, 'colonyRadius', [], ...
                'colonyCrowding', [], 'stateId', NaN);
        end
        
        function [plates, stateList] = assignStates(plates, order)
            % MODEL (TERMINAL): ordered state catalog and per-plate state id.
            % Part 3 states are (genotype, passage); the Part 2 dilution series
            % is one state keyed on genotype alone. Catalog order follows the
            % genotype display order, ascending passage within a genotype, the
            % dilution state last.

            tokenMap = containers.Map( ...
                {'wild_type', 'dbf4-1', 'cdc13-2', 'double'}, ...
                {'WT',        'dbf4-1', 'cdc13-2', 'dbl'});

            gts = {plates.genotype};
            pss = [plates.passage];

            stateList = struct('id', {}, 'genotype', {}, 'passage', {}, ...
                               'axisLabel', {});
            nextId = 1;

            for gi = 1:numel(order)
                g = order{gi};

                if strcmp(g, 'wild_type_dilution')
                    if any(strcmp(gts, g))
                        stateList(end+1) = struct('id', nextId, ...
                            'genotype', g, 'passage', NaN, ...
                            'axisLabel', 'Dil'); %#ok<AGROW>
                        nextId = nextId + 1;
                    end
                else
                    if ~isKey(tokenMap, g)
                        continue;
                    end
                    mask = strcmp(gts, g);
                    ps   = unique(pss(mask));
                    ps   = ps(isfinite(ps));
                    ps   = sort(ps(:)');
                    tok  = tokenMap(g);
                    for pp = ps
                        stateList(end+1) = struct('id', nextId, ...
                            'genotype', g, 'passage', pp, ...
                            'axisLabel', sprintf('%s P%d', tok, pp)); %#ok<AGROW>
                        nextId = nextId + 1;
                    end
                end
            end

            for i = 1:numel(plates)
                plates(i).stateId = NaN;
                for b = 1:numel(stateList)
                    if ~strcmp(stateList(b).genotype, plates(i).genotype)
                        continue;
                    end
                    if strcmp(plates(i).genotype, 'wild_type_dilution')
                        plates(i).stateId = stateList(b).id;
                        break;
                    elseif isfinite(plates(i).passage) && ...
                            stateList(b).passage == plates(i).passage
                        plates(i).stateId = stateList(b).id;
                        break;
                    end
                end
            end
        end

        function omitted = findOmittedStates(combined, stateList, config)
            % MODEL CONTROLLER: Part 3 (genotype, passage) cells that produced no
            % plate clearing inclusion. The expected grid is the Part 3
            % genotypes crossed with the union of passages seen in the raw
            % composite. Subtracting the cells that reached stateList leaves the
            % omitted cells; each is classified and (when it had raw plates) its
            % per-criterion failure tally is built from the same raw records the
            % filter reads.

            raw      = QC.extractPart3Fields(combined.part3, config);
            expected = enumerateExpectedCells(raw, config);
            survived = collectSurvivedCells(stateList);

            omitted = struct('genotype', {}, 'passage', {}, 'label', {}, ...
                             'rawCount', {}, 'category', {}, 'failCounts', {});

            for i = 1:numel(expected)
                cell = expected(i);
                if isSurvived(cell, survived)
                    continue;
                end
                omitted(end+1) = buildOmittedRecord(raw, cell, config); %#ok<AGROW>
            end

            function cells = enumerateExpectedCells(raw, config)
                % MODEL (TERMINAL): Part 3 genotypes (display order, dilution
                % excluded) crossed with the union of finite passages observed
                % across all raw Part 3 plates.

                genotypes = config.order(~strcmp(config.order, 'wild_type_dilution'));

                allPass = [raw.passage];
                allPass = unique(allPass(isfinite(allPass)));
                allPass = sort(allPass(:)');

                cells = struct('genotype', {}, 'passage', {});
                for gi = 1:numel(genotypes)
                    for pp = allPass
                        cells(end+1) = struct('genotype', genotypes{gi}, ...
                                              'passage', pp); %#ok<AGROW>
                    end
                end
            end

            function cells = collectSurvivedCells(stateList)
                % MODEL (TERMINAL): (genotype, passage) of Part 3 states that
                % survived filtering, every stateList entry other than dilution.

                cells = struct('genotype', {}, 'passage', {});
                for b = 1:numel(stateList)
                    if strcmp(stateList(b).genotype, 'wild_type_dilution')
                        continue;
                    end
                    cells(end+1) = struct('genotype', stateList(b).genotype, ...
                                          'passage', stateList(b).passage); %#ok<AGROW>
                end
            end

            function tf = isSurvived(cell, survived)
                % MODEL (TERMINAL): membership of a (genotype, passage) cell.

                tf = false;
                for s = 1:numel(survived)
                    if strcmp(survived(s).genotype, cell.genotype) && ...
                            isfinite(survived(s).passage) && ...
                            survived(s).passage == cell.passage
                        tf = true;
                        return;
                    end
                end
            end

            function rec = buildOmittedRecord(raw, cell, config)
                % MODEL CONTROLLER: one omitted-cell record. rawCount is the
                % cell's raw plate count; category separates a filtered-out cell
                % (had raw plates, none survived) from an absent cell (no raw
                % plates collected); failCounts tallies per-criterion failures.

                rawCount = countCellPlates(raw, cell.genotype, cell.passage);

                if rawCount > 0
                    category   = 'filtered';
                    failCounts = tallyCellFailures(raw, cell.genotype, cell.passage, config);
                else
                    category   = 'absent';
                    failCounts = struct();
                end

                rec = struct();
                rec.genotype   = cell.genotype;
                rec.passage    = cell.passage;
                rec.label      = sprintf('%s P%d', config.labels(cell.genotype), cell.passage);
                rec.rawCount   = rawCount;
                rec.category   = category;
                rec.failCounts = failCounts;

                function n = countCellPlates(raw, genotype, passage)
                    % MODEL (TERMINAL): raw plates in a (genotype, passage) cell.

                    n = 0;
                    for i = 1:numel(raw)
                        if strcmp(raw(i).genotype, genotype) && ...
                                isfinite(raw(i).passage) && raw(i).passage == passage
                            n = n + 1;
                        end
                    end
                end

                function fails = tallyCellFailures(raw, genotype, passage, config)
                    % MODEL CONTROLLER: per-criterion failure counts across the
                    % cell's raw plates. Calls only the shared model terminals
                    % alignColonyPair and evaluatePart3Inclusion. The
                    % accumulator follows the criterion struct's fields and
                    % order, so a criterion added there flows through unchanged.

                    fails       = struct();
                    initialized = false;

                    for i = 1:numel(raw)
                        if ~strcmp(raw(i).genotype, genotype)
                            continue;
                        end
                        if ~(isfinite(raw(i).passage) && raw(i).passage == passage)
                            continue;
                        end

                        [~, ~, okColony] = QC.alignColonyPair(raw(i).colonyRadius, raw(i).colonyCrowding);
                        crit = QC.evaluatePart3Inclusion(raw(i), okColony, config);
                        fn   = fieldnames(crit);

                        if ~initialized
                            for k = 1:numel(fn)
                                fails.(fn{k}) = 0;
                            end
                            initialized = true;
                        end

                        for k = 1:numel(fn)
                            if ~crit.(fn{k})
                                fails.(fn{k}) = fails.(fn{k}) + 1;
                            end
                        end
                    end
                end
            end
        end

        function [crowd, rad, blk, geno] = gatherColonyData(plates)
            % MODEL (TERMINAL): flatten per-colony crowding, radius, state id,
            % and genotype across the included plates. Each colony inherits its
            % plate's state id and genotype. The vectors on each plate record are
            % already aligned and filtered (radius > 0, finite crowding), so the
            % positional pairing is preserved and the result is fit-ready. A
            % between-state caller ignores blk; a within-state caller uses it.

            cc = {}; rr = {}; bb = {}; gg = {};
            for i = 1:numel(plates)
                c = plates(i).colonyCrowding;
                r = plates(i).colonyRadius;
                m = min(numel(c), numel(r));
                if m < 1
                    continue;
                end
                cc{end+1} = c(1:m);                                  %#ok<AGROW>
                rr{end+1} = r(1:m);                                  %#ok<AGROW>
                bb{end+1} = repmat(plates(i).stateId, 1, m);         %#ok<AGROW>
                gg{end+1} = repmat({plates(i).genotype}, 1, m);      %#ok<AGROW>
            end
            crowd = [cc{:}];
            rad   = [rr{:}];
            blk   = [bb{:}];
            geno  = [gg{:}];
        end

        function states = stateAggregates(plates, stateList)
            % MODEL CONTROLLER: one record per state, in catalog order, carrying
            % the within-state coverage vector and summary, and the geometric
            % mean of the state's median radii. Every included plate has finite
            % coverage and positive median by construction; std/min/max are NaN
            % when fewer than two plates. Calls only geoMean.

            template = struct('id', NaN, 'genotype', '', 'passage', NaN, ...
                'axisLabel', '', 'nCoverage', 0, 'meanCoverage', NaN, ...
                'stdCoverage', NaN, 'minCoverage', NaN, 'maxCoverage', NaN, ...
                'geomMeanMedian', NaN, 'coverageVec', []);
            states = repmat(template, 1, numel(stateList));

            bid = [plates.stateId];

            for j = 1:numel(stateList)
                b    = stateList(j);
                mask = (bid == b.id);

                cov = [plates(mask).coverage];
                med = [plates(mask).median];
                cov = cov(isfinite(cov));
                med = med(isfinite(med) & med > 0);

                rec = template;
                rec.id          = b.id;
                rec.genotype    = b.genotype;
                rec.passage     = b.passage;
                rec.axisLabel   = b.axisLabel;
                rec.nCoverage   = numel(cov);
                rec.coverageVec = cov;

                if ~isempty(cov)
                    rec.meanCoverage = mean(cov);
                    if numel(cov) >= 2
                        rec.stdCoverage = std(cov);
                        rec.minCoverage = min(cov);
                        rec.maxCoverage = max(cov);
                    end
                end

                if ~isempty(med)
                    rec.geomMeanMedian = QC.geoMean(med);
                end

                states(j) = rec;
            end
        end

         function kdeData = computeLogKDE(radii, imposed_edges)
    % MODEL: Compute log-space KDE with shrunk Silverman bandwidth (TERMINAL)
    if nargin < 2, imposed_edges = []; end
    kdeData = struct();
    kdeData.radii = radii;
    kdeData.n = length(radii);
    if kdeData.n < 2
        kdeData.empty = true;
        kdeData.mean_r = NaN; kdeData.std_r = NaN; kdeData.cv = NaN;
        kdeData.eval_x_log = []; kdeData.density = [];
        kdeData.bandwidth = NaN;
        return;
    end
    kdeData.empty = false;
    kdeData.mean_r = mean(radii);
    kdeData.std_r = std(radii);
    kdeData.cv = kdeData.std_r / kdeData.mean_r;
    log_radii = log(radii);

    % Shrunk Silverman robust bandwidth (0.5x for mode preservation)
    sigma_log = std(log_radii);
    iqr_log = iqr(log_radii);
    if iqr_log > 0
        spread = min(sigma_log, iqr_log / 1.34);
    else
        spread = sigma_log;
    end
    if spread <= 0
        spread = 0.1;
    end
    silverman_h = 0.9 * spread * kdeData.n^(-1/5);
    h = 0.9 * silverman_h;
    kdeData.bandwidth = h;

    % Evaluation grid
    if isempty(imposed_edges)
        x_min = min(log_radii) - 3*h;
        x_max = max(log_radii) + 3*h;
    else
        x_min = imposed_edges(1);
        x_max = imposed_edges(end);
    end
    n_eval = 300;
    eval_x_log = linspace(x_min, x_max, n_eval);

    % Compute density (Gaussian kernel)
    density = zeros(1, n_eval);
    norm_factor = 1 / (kdeData.n * h * sqrt(2*pi));
    for i = 1:kdeData.n
        density = density + exp(-0.5 * ((eval_x_log - log_radii(i)) / h).^2);
    end
    density = density * norm_factor;

    kdeData.eval_x_log = eval_x_log;
    kdeData.density = density;
end

        % ================================================================
        % ===                         VIEW                             ===
        % ================================================================
        
        function colorMap = getGenotypeColors(genotypeKeys)
    % MODEL: Map each requested genotype key to a default RGB color (TERMINAL)
    %
    % Single source of truth for genotype colors across figure functions. Known
    % genotypes get curated colors. Spelling variants of one genotype resolve to
    % one color through case- and separator-insensitive normalization, so
    % wild_type/Wild_Type/"Wild Type", cdc13-2/cdc13_2/cdc132, and dbf4-1/dbf4_1
    % each collapse to a single entry. A genotype with no curated entry gets a
    % stable color drawn from a fallback palette by hashing its normalized key,
    % so the same genotype always receives the same color across calls.
    %
    % Input:  genotypeKeys - char row vector or cellstr of genotype keys
    % Output: colorMap     - containers.Map from each input key (verbatim) to a
    %                        1x3 RGB triplet in [0,1]
 
    if ischar(genotypeKeys)
        genotypeKeys = {genotypeKeys};
    end
 
    registry = knownColorRegistry();
    palette  = fallbackPalette();
    colorMap = containers.Map('KeyType', 'char', 'ValueType', 'any');
 
    for i = 1:numel(genotypeKeys)
        key     = genotypeKeys{i};
        normKey = normalizeKey(key);
        if isKey(registry, normKey)
            colorMap(key) = registry(normKey);
        else
            idx = hashIndex(normKey, size(palette, 1));
            colorMap(key) = palette(idx, :);
        end
    end
 
    % === SHARED FUNCTIONS ===
 
    function reg = knownColorRegistry()
        % MODEL: Curated genotype -> RGB, keyed by normalized name (TERMINAL)
        reg = containers.Map('KeyType', 'char', 'ValueType', 'any');
        reg('wildtype')   = [0.20 0.40 0.85];   % blue   (wild_type, Wild_Type)
        reg('dbf41')      = [0.95 0.55 0.10];   % orange (dbf4-1, dbf4_1)
        reg('cdc132')     = [0.20 0.65 0.30];   % green  (cdc13-2, cdc13_2, cdc132)
        reg('double')     = [0.85 0.40 0.65];   % magenta (dbf4-1 cdc13-2)
        reg('rif1')       = [0.55 0.35 0.75];   % purple (rif1Δ)
        reg('rif1cdc132') = [0.85 0.20 0.20];   % red    (rif1Δ cdc13-2)
    end
 
    function p = fallbackPalette()
        % MODEL: Distinct colors for genotypes with no curated entry (TERMINAL)
        p = [0.20 0.40 0.85; ...
             0.95 0.55 0.10; ...
             0.20 0.65 0.30; ...
             0.85 0.40 0.65; ...
             0.55 0.35 0.75; ...
             0.85 0.20 0.20; ...
             0.40 0.70 0.75; ...
             0.70 0.55 0.20; ...
             0.50 0.50 0.50; ...
             0.25 0.25 0.25];
    end
 
    function nk = normalizeKey(key)
        % MODEL: Fold case, separators, commas, and the delta glyph/word so
        % spelling variants of one genotype map to one registry key (TERMINAL)
        nk = lower(key);
        nk = strrep(nk, char(916), '');   % uppercase delta
        nk = strrep(nk, char(948), '');   % lowercase delta
        nk = strrep(nk, 'delta', '');
        nk = regexprep(nk, '[\s_\-,]', '');
    end
 
    function idx = hashIndex(s, n)
        % MODEL: Stable index into the fallback palette from a key string (TERMINAL)
        idx = mod(sum(double(s)), n) + 1;
    end
end

        function scatterByGenotype(ax, x, y, gtypes, config, markerSize, faceAlpha)
            % VIEW (TERMINAL): scatter aligned x, y, genotype arrays, colored per
            % point by genotype in display order, all with HandleVisibility off
            % (legends are drawn separately via genotypeLegendProxies). Only
            % finite pairs are drawn; any positivity needed for log axes is the
            % caller's responsibility.

            hold(ax, 'on');
            order = config.order;
            for gi = 1:numel(order)
                g = order{gi};
                m = strcmp(gtypes, g) & isfinite(x) & isfinite(y);
                if ~any(m)
                    continue;
                end
                c  = config.colors(g);
                hs = scatter(ax, x(m), y(m), markerSize, c, 'filled');
                hs.MarkerFaceAlpha  = faceAlpha;
                hs.MarkerEdgeColor  = c;
                hs.HandleVisibility = 'off';
            end
        end

        function genotypeLegendProxies(ax, present, config)
            % VIEW (TERMINAL): one invisible proxy handle per present genotype,
            % in display order, so the legend carries the genotype colors
            % without depending on plotted-point order. Hold is forced on so the
            % first proxy does not clear an axes whose hold was released.

            hold(ax, 'on');
            order = config.order;
            for gi = 1:numel(order)
                g = order{gi};
                if ~any(strcmp(present, g))
                    continue;
                end
                c = config.colors(g);
                h = plot(ax, NaN, NaN, 'o', 'MarkerFaceColor', c, ...
                    'MarkerEdgeColor', c, 'LineStyle', 'none');
                h.DisplayName = config.labels(g);
            end
        end

        function overlayFitLine(ax, fit, color, lineWidth)
            % VIEW (TERMINAL): overlay a fit line from any struct carrying xfit,
            % yfit, and slope (power-law or linear). Nothing is drawn for an
            % empty or non-finite fit.

            if nargin < 4 || isempty(lineWidth)
                lineWidth = 1.8;
            end
            if isempty(fit.xfit) || ~isfinite(fit.slope)
                return;
            end
            h = plot(ax, fit.xfit, fit.yfit, '-', 'Color', color, 'LineWidth', lineWidth);
            h.HandleVisibility = 'off';
        end

        function annotationBox(ax, lines, fx, fy)
            % VIEW (TERMINAL): a corner text box placed at fractional position
            % (fx, fy) of the current axis limits, top-aligned. The data
            % coordinates respect each axis scale, so the same call places
            % correctly on linear and log axes.

            xl = get(ax, 'XLim');
            yl = get(ax, 'YLim');

            if strcmp(get(ax, 'XScale'), 'log')
                tx = 10 ^ (log10(xl(1)) + fx * (log10(xl(2)) - log10(xl(1))));
            else
                tx = xl(1) + fx * (xl(2) - xl(1));
            end
            if strcmp(get(ax, 'YScale'), 'log')
                ty = 10 ^ (log10(yl(1)) + fy * (log10(yl(2)) - log10(yl(1))));
            else
                ty = yl(1) + fy * (yl(2) - yl(1));
            end

            text(ax, tx, ty, lines, ...
                'VerticalAlignment', 'top', 'HorizontalAlignment', 'left', ...
                'FontSize', 8, 'BackgroundColor', [1 1 1], ...
                'EdgeColor', [0.7 0.7 0.7], 'Margin', 3);
        end

        function formatAxes(ax, xLabel, yLabel, ttl, xScale, yScale)
            % VIEW (TERMINAL): scales, grid, box, labels, title.

            set(ax, 'XScale', xScale, 'YScale', yScale, 'Box', 'on');
            grid(ax, 'on');
            xlabel(ax, xLabel);
            ylabel(ax, yLabel);
            title(ax, ttl);
        end

        function printFitTable(rel, config, ttl)
            % VIEW (TERMINAL): per-genotype plus pooled slope/R^2 table for a
            % relationship struct.

            fprintf('\n--- %s ---\n', ttl);
            fprintf('%-16s %-8s %-8s %-5s\n', 'Genotype', 'Slope', 'R^2', 'n');

            order = config.order;
            for gi = 1:numel(order)
                g = order{gi};
                if config.labels.isKey(g)
                    lab = config.labels(g);
                else
                    lab = g;
                end
                f = rel.byGenotype(gi).fit;
                if isfinite(f.slope)
                    fprintf('%-16s %-8.3f %-8.3f %-5d\n', lab, f.slope, f.r2, f.n);
                else
                    fprintf('%-16s %-8s %-8s %-5d\n', lab, 'n/a', 'n/a', f.n);
                end
            end

            f = rel.pooled;
            if isfinite(f.slope)
                fprintf('%-16s %-8.3f %-8.3f %-5d\n', 'pooled', f.slope, f.r2, f.n);
            else
                fprintf('%-16s %-8s %-8s %-5d\n', 'pooled', 'n/a', 'n/a', f.n);
            end
        end

    end
end