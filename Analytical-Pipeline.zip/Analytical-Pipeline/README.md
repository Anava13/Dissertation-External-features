# Analytical Pipeline

MATLAB code that turns the QuantaColony project files (Complete Analyses) into the composite dataset and the figures reported in the dissertation. One command runs the whole pipeline on a fresh machine.

## Requirements

- MATLAB R2021b or later (`exportgraphics` page appending)
- Statistics and Machine Learning Toolbox (`fitgmdist`, `ksdensity`, `prctile`, `kstest`)
- MATLAB started with Java enabled, the default (used for SHA-256 checks)
- Internet access on the first run, to download Complete Analyses (2.2 GB)
- About 5 GB of free disk space during installation, plus room for outputs

QuantaColony itself does not need to be installed. The project files load as plain MATLAB data.

## Run

1. Download this folder from the repository, or clone the repository.
2. Open MATLAB and run `run_all.m`.

The first run downloads the four parts of Complete Analyses from the release [`complete-analyses`](https://github.com/anava13/Dissertation-External-features/releases/tag/complete-analyses). It checks each zip against the SHA-256 value in `pipelineConfig.m` and installs it in `data/Complete Analyses/`. Later runs find the data in place and skip the download. The build and library fitting take about 15 minutes after that.

| Step | Script | Output |
|---|---|---|
| Data installation | `ensureCompleteAnalyses.m` (called by `CompositeBuilder.m`) | `data/Complete Analyses/{P2, P3, Anbalagan, Historical}` |
| Composite build and library fitting | `CompositeBuilder.m` | `outputs/composite_V40.mat`, per-part results in `outputs/V40/`, logs in `outputs/Text/V40/` |
| Figures and overview PDFs | `LeanFinalAnalysis.m` | `outputs/Overview PDFs/` |

Each script also runs on its own. `LeanFinalAnalysis.m` reads the composite file from a previous `CompositeBuilder.m` run.

## Folder layout

```
Analytical-Pipeline/
├── run_all.m                  runs the two analysis scripts in order
├── pipelineConfig.m           paths and settings, resolved from this folder
├── CompositeBuilder.m         composite build and stable-phi library fitting
├── LeanFinalAnalysis.m        figures and overview PDFs
├── QC.m                       shared statistics, data, and plotting utilities
├── ensureCompleteAnalyses.m   download, checksum, and installation of the data
├── sha256File.m               file checksum used by the two scripts below
├── preparePartZips.m          maintainer tool that builds the release zips
├── data/
│   ├── stable_phi_library_V40.mat
│   └── Complete Analyses/     installed on the first run
└── outputs/                   created on the first run
```

Every path is built from the location of `pipelineConfig.m` with `fullfile`. The pipeline runs from any folder on Windows, macOS, or Linux.

## Settings

`pipelineConfig.m` holds every adjustable value. Reviewers do not need to change any of them.

- `analysesOverride`: absolute path to a copy of Complete Analyses stored elsewhere. Empty uses `data/Complete Analyses`.
- `keepZips`: keep the downloaded zips after installation.
- `rngSeed`: seed for the random number generator. Gaussian mixture fits and plot jitter draw random numbers, so the fixed seed gives identical results on repeated runs with the same MATLAB release. Other MATLAB releases or processors can differ in the last decimal places of mixture fits.

## Installing the data by hand

If the download fails (no internet, or a blocked network), the error message names the zip URL and the target folder. To install by hand, download `P2.zip`, `P3.zip`, `Anbalagan.zip`, and `Historical.zip` from the release and unzip each into `data/Complete Analyses/`. The result is four folders: `data/Complete Analyses/P2/`, `P3/`, `Anbalagan/`, and `Historical/`. Folder names are case-sensitive on Linux. Run `run_all.m` again, and the data step finds the folders and skips the download.

## Maintainer: publishing the data

1. Place the final Complete Analyses in `data/Complete Analyses/`, with one folder per part.
2. Run `preparePartZips` in MATLAB. It writes one zip per part to `release/`, flags any zip at or above the GitHub limit of 2 GiB, and prints four `sha256.<part> = '...';` lines.
3. Paste those lines into `pipelineConfig.m`, replacing the empty values.
4. On GitHub, create a release with the tag `complete-analyses` and attach the four zips.
5. Commit and push the updated `pipelineConfig.m`.
6. Test from a fresh download of the repository on a second machine, or after `restoredefaultpath`, by running `run_all.m`.
