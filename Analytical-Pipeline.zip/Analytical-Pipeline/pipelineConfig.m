function cfg = pipelineConfig()
% MODEL: Paths and run settings for the analysis pipeline (TERMINAL)
%
% Every path resolves from the folder that holds this file, so the pipeline
% runs from any location on Windows, macOS, or Linux. Reviewers do not need
% to edit anything here. The SETTINGS block lists the values that can change.

    % === SETTINGS ===

    % Stable-phi library version. Selects data/stable_phi_library_<rounds>.mat
    % and suffixes every output file.
    rounds = 'V40';

    % Fixed seed for the random number generator. Gaussian mixture fits
    % (fitgmdist with replicates) and plot jitter draw random numbers, so the
    % seed makes repeated runs give identical results on the same MATLAB release.
    rngSeed = 20261023;

    % Location of Complete Analyses. Leave empty to use data/Complete Analyses
    % inside this folder (the download step installs it there). Set an absolute
    % path to use a copy stored elsewhere, for example on an external drive.
    analysesOverride = '';

    % Keep the downloaded part zips in the data folder after unzipping.
    keepZips = false;

    % GitHub release that hosts one zip per part of Complete Analyses.
    release.owner = 'anava13';
    release.repo  = 'Dissertation-External-features';
    release.tag   = 'complete-analyses';

    % Parts of Complete Analyses, one folder and one release zip each.
    parts = {'P2', 'P3', 'Anbalagan', 'Historical'};

    % SHA-256 checksum of each release zip. preparePartZips.m prints these
    % four lines with their values after it builds the zips.
    sha256.P2         = 'bdb71fdf12f654955df86c3252c59908aaecf88c40b0c78a1450dc34d94e46ac';
    sha256.P3         = '8ec7964a7de336390c0046826921efbf8d6be8fba68b38655868d7f44a353c9f';
    sha256.Anbalagan  = 'b6e64c05f330f5cd5da1fb923fe6766522283ab453eb4c526aa04f08064d04af';
    sha256.Historical = 'b469d0cf731f555aaed37e854b1fb4444c56d53a5693a21345f747e6bd9dbb9b';

    % === DERIVED PATHS ===

    root       = fileparts(mfilename('fullpath'));
    dataFolder = fullfile(root, 'data');

    if isempty(analysesOverride)
        analysesFolder = fullfile(dataFolder, 'Complete Analyses');
    else
        analysesFolder = analysesOverride;
    end

    outputFolder = fullfile(root, 'outputs');

    cfg = struct();
    cfg.root           = root;
    cfg.rounds         = rounds;
    cfg.rngSeed        = rngSeed;
    cfg.keepZips       = keepZips;
    cfg.release        = release;
    cfg.parts          = parts;
    cfg.sha256         = sha256;
    cfg.dataFolder     = dataFolder;
    cfg.analysesFolder = analysesFolder;
    cfg.outputFolder   = outputFolder;
    cfg.overviewFolder = fullfile(outputFolder, 'Overview PDFs');
    cfg.compositeFile  = fullfile(outputFolder, ['composite_' rounds '.mat']);
end
