function hex = sha256File(filePath)
% MODEL: SHA-256 checksum of a file as a lowercase hex string (TERMINAL)
%
% Streams the file in 16 MB blocks through Java's MessageDigest, which ships
% with MATLAB, so multi-gigabyte files hash without a toolbox and without
% loading the whole file into memory. Shared by ensureCompleteAnalyses.m
% (checks downloads) and preparePartZips.m (prints release checksums).

    fid = fopen(filePath, 'r');
    if fid < 0
        error('sha256File:CannotOpen', 'Cannot open file: %s', filePath);
    end
    fileCloser = onCleanup(@() fclose(fid)); %#ok<NASGU>

    digest    = java.security.MessageDigest.getInstance('SHA-256');
    blockSize = 16 * 1024 * 1024;

    while true
        block = fread(fid, blockSize, '*uint8');
        if isempty(block)
            break
        end
        digest.update(typecast(block, 'int8'));
    end

    raw = typecast(digest.digest(), 'uint8');
    hex = lower(reshape(dec2hex(double(raw), 2).', 1, []));
end
