function ensureCompleteAnalyses(cfg)
% CONTROLLER: Put every part of Complete Analyses in place before the build
%
% Checks cfg.analysesFolder for each part in cfg.parts. A part counts as
% present when its folder holds at least one project with a
% Workspace/*DataManagerState*.mat file, the layout CompositeBuilder reads.
% Each missing part is downloaded from the pinned GitHub release, checked
% against its SHA-256 value in pipelineConfig.m, unzipped into a staging
% folder, and moved into place. Parts already present are left untouched, so
% later runs go straight to the build.
%
% Usage:
%   ensureCompleteAnalyses(pipelineConfig())

    status = checkPartStatus(cfg);
    reportPartStatus(status);

    if all(status.present)
        return
    end

    reportDownloadPlan(status, cfg);
    acquireMissingParts(status, cfg);

    finalStatus = checkPartStatus(cfg);
    confirmAllPresent(finalStatus, cfg);

    % === SUB-CONTROLLERS ===

    function reportPartStatus(status)
        % VIEW: List each part as present or missing (TERMINAL)
        fprintf('\n=== Complete Analyses ===\n');
        for k = 1:numel(status.parts)
            if status.present(k)
                fprintf('  %-12s present\n', status.parts{k});
            else
                fprintf('  %-12s missing\n', status.parts{k});
            end
        end
    end

    function reportDownloadPlan(status, cfg)
        % VIEW: State what will be downloaded and the disk space it needs (TERMINAL)
        missing = status.parts(~status.present);
        fprintf('\nDownloading %d part(s) from github.com/%s/%s, release "%s".\n', ...
            numel(missing), cfg.release.owner, cfg.release.repo, cfg.release.tag);
        fprintf('All four parts need about 5 GB of free disk space while unzipping\n');
        fprintf('(2.2 GB of zips plus 2.8 GB extracted). Install folder:\n  %s\n\n', ...
            cfg.analysesFolder);
    end

    function acquireMissingParts(status, cfg)
        % SUB-CONTROLLER: Download, verify, and install each missing part in turn

        missing = status.parts(~status.present);
        for k = 1:numel(missing)
            acquirePart(missing{k}, cfg);
        end

        function acquirePart(part, cfg)
            % SUB-CONTROLLER: Take one part from release zip to installed folder

            plan = planPart(part, cfg);

            reportStep(plan, 'fetch');
            obtainVerifiedZip(plan);

            reportStep(plan, 'install');
            installPart(plan);

            reportStep(plan, 'done');

            function plan = planPart(part, cfg)
                % MODEL: Paths, URL, and expected checksum for one part (TERMINAL)
                % Stops before any download when the checksum is not set or when
                % an incomplete folder already occupies the install location.

                plan = struct();
                plan.part     = part;
                plan.url      = sprintf('https://github.com/%s/%s/releases/download/%s/%s.zip', ...
                                    cfg.release.owner, cfg.release.repo, cfg.release.tag, part);
                plan.zipPath  = fullfile(cfg.dataFolder, [part '.zip']);
                plan.staging  = fullfile(cfg.dataFolder, ['_staging_' part]);
                plan.target   = fullfile(cfg.analysesFolder, part);
                plan.expected = lower(strtrim(cfg.sha256.(part)));
                plan.keepZip  = cfg.keepZips;

                if isempty(plan.expected)
                    error('ensureCompleteAnalyses:NoChecksum', ...
                        ['pipelineConfig.m holds no SHA-256 value for %s, so the download ' ...
                         'cannot be checked. Fill in sha256.%s with the value printed by ' ...
                         'preparePartZips.m.'], part, part);
                end

                if isfolder(plan.target)
                    error('ensureCompleteAnalyses:IncompleteFolder', ...
                        ['%s exists but holds no project with a ' ...
                         'Workspace/*DataManagerState*.mat file. Delete or rename this ' ...
                         'folder, then run again to download a fresh copy.'], plan.target);
                end
            end

            function obtainVerifiedZip(plan)
                % SUB-CONTROLLER: Reuse a zip already on disk when its checksum
                % matches, otherwise download it and check the new copy

                if isfile(plan.zipPath)
                    existing = sha256File(plan.zipPath);
                else
                    existing = '';
                end

                if strcmp(existing, plan.expected)
                    return
                end

                downloadZip(plan);
                actual = sha256File(plan.zipPath);
                assertChecksum(actual, plan);

                function downloadZip(plan)
                    % MODEL: Download the release zip through a .partial file (TERMINAL)
                    % The file takes its final name only after websave returns,
                    % so an interrupted transfer never looks like a finished zip.
                    % Timeout covers the wait for the server's first response,
                    % not the length of the transfer.

                    partialPath = [plan.zipPath '.partial'];
                    if isfile(partialPath)
                        delete(partialPath);
                    end

                    try
                        savedPath = websave(partialPath, plan.url, weboptions('Timeout', 60));
                    catch ME
                        if isfile(partialPath)
                            delete(partialPath);
                        end
                        error('ensureCompleteAnalyses:DownloadFailed', ...
                            ['Download of %s failed: %s\n\nTo install this part by hand:\n' ...
                             '  1. Download %s\n' ...
                             '  2. Unzip it so this folder exists:\n     %s\n' ...
                             '  3. Run the script again. It detects the folder and skips the download.'], ...
                            plan.part, ME.message, plan.url, plan.target);
                    end

                    movefile(savedPath, plan.zipPath, 'f');
                end

                function assertChecksum(actual, plan)
                    % MODEL: Stop and delete the zip when its checksum differs (TERMINAL)
                    if ~strcmp(actual, plan.expected)
                        delete(plan.zipPath);
                        error('ensureCompleteAnalyses:ChecksumMismatch', ...
                            ['Checksum mismatch for %s.zip.\n  expected %s\n  received %s\n' ...
                             'The file was deleted. Run again to download a fresh copy. If the ' ...
                             'mismatch repeats, the release file differs from the one this code ' ...
                             'was published with.'], plan.part, plan.expected, actual);
                    end
                end
            end

            function installPart(plan)
                % SUB-CONTROLLER: Unzip into staging, find the part folder, move
                % it into place, and remove the staging folder and zip

                extractToStaging(plan);
                source = locatePartFolder(plan);
                moveIntoPlace(source, plan);
                cleanUpPart(plan);

                function extractToStaging(plan)
                    % MODEL: Unzip into an empty staging folder (TERMINAL)
                    if isfolder(plan.staging)
                        rmdir(plan.staging, 's');
                    end
                    mkdir(plan.staging);
                    unzip(plan.zipPath, plan.staging);
                end

                function source = locatePartFolder(plan)
                    % MODEL: Shallowest folder named for the part that holds
                    % project data (TERMINAL)
                    % Searching by name handles zips that unzip with extra
                    % nesting levels. Folders under __MACOSX are skipped.

                    entries = dir(fullfile(plan.staging, '**'));
                    isCandidate = [entries.isdir] ...
                        & strcmp({entries.name}, plan.part) ...
                        & ~contains({entries.folder}, '__MACOSX');
                    candidates = entries(isCandidate);

                    paths = cell(1, numel(candidates));
                    for c = 1:numel(candidates)
                        paths{c} = fullfile(candidates(c).folder, candidates(c).name);
                    end
                    [~, order] = sort(cellfun(@length, paths));
                    paths = paths(order);

                    source = '';
                    for c = 1:numel(paths)
                        stateFiles = dir(fullfile(paths{c}, '*', 'Workspace', '*DataManagerState*.mat'));
                        if ~isempty(stateFiles)
                            source = paths{c};
                            break
                        end
                    end

                    if isempty(source)
                        error('ensureCompleteAnalyses:BadZipLayout', ...
                            ['%s.zip holds no folder named %s with project Workspace ' ...
                             'data. The release file does not match the expected layout.'], ...
                            plan.part, plan.part);
                    end
                end

                function moveIntoPlace(source, plan)
                    % MODEL: Move the part folder into the analyses folder (TERMINAL)
                    parentFolder = fileparts(plan.target);
                    if ~isfolder(parentFolder)
                        mkdir(parentFolder);
                    end
                    movefile(source, plan.target);
                end

                function cleanUpPart(plan)
                    % MODEL: Remove staging, and the zip unless kept (TERMINAL)
                    if isfolder(plan.staging)
                        rmdir(plan.staging, 's');
                    end
                    if ~plan.keepZip && isfile(plan.zipPath)
                        delete(plan.zipPath);
                    end
                end
            end
        end
    end

    function confirmAllPresent(status, cfg)
        % MODEL: Stop when any part is still missing after installation (TERMINAL)
        if ~all(status.present)
            error('ensureCompleteAnalyses:StillMissing', ...
                'Parts still missing from %s: %s', ...
                cfg.analysesFolder, strjoin(status.parts(~status.present), ', '));
        end
    end
end

% === SHARED FUNCTIONS ===

function status = checkPartStatus(cfg)
    % MODEL: Which parts are installed in the analyses folder (TERMINAL)
    parts   = cfg.parts;
    present = false(1, numel(parts));
    for k = 1:numel(parts)
        partFolder = fullfile(cfg.analysesFolder, parts{k});
        if isfolder(partFolder)
            stateFiles = dir(fullfile(partFolder, '*', 'Workspace', '*DataManagerState*.mat'));
            present(k) = ~isempty(stateFiles);
        end
    end
    status = struct('parts', {parts}, 'present', present);
end

function reportStep(plan, stage)
    % VIEW: Progress line for one part (TERMINAL)
    switch stage
        case 'fetch'
            fprintf('[%s] Fetching %s\n', plan.part, plan.url);
        case 'install'
            fprintf('[%s] Checksum verified. Unzipping and installing.\n', plan.part);
        case 'done'
            fprintf('[%s] Installed at %s\n\n', plan.part, plan.target);
    end
end
