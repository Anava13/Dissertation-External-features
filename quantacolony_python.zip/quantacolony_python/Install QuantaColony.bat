@echo off
rem Installs QuantaColony for this user: the program (in %%LOCALAPPDATA%%\QuantaColony\Program),
rem Desktop and Start menu shortcuts, the .qcproj icon, and a backup of the program in the project library.
rem Afterwards the folder this file is in is no longer needed.
title QuantaColony installer
cd /d "%~dp0"
where uv >nul 2>nul
if errorlevel 1 (
    echo Installing uv, which downloads Python and the libraries QuantaColony needs ...
    powershell -NoProfile -ExecutionPolicy ByPass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    set "PATH=%USERPROFILE%\.local\bin;%PATH%"
)
rem The installer runs in a temporary environment, so nothing is left in this folder or in the library
set "UV_PROJECT_ENVIRONMENT=%TEMP%\QuantaColony-installer"
uv run --quiet --no-dev --project "%~dp0." quantacolony-install "%~dp0."
echo.
pause
