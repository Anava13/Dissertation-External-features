@echo off
rem Installs QuantaColony for the current user and creates its Desktop and Start menu shortcuts.
rem The program is copied to uv's tools folder, so afterwards this folder can be moved or deleted.
rem Run it again with a newer copy to update. Close QuantaColony first.
cd /d "%~dp0"
where uv >nul 2>nul
if errorlevel 1 goto no_uv

set "PINS=%TEMP%\quantacolony-pins.txt"
echo Installing QuantaColony (the first time downloads Python and the libraries, a few minutes)...
uv export --frozen --no-dev --no-emit-project --no-hashes --quiet -o "%PINS%" || goto failed
uv tool install --reinstall --constraints "%PINS%" . || goto failed
del "%PINS%" 2>nul
for /f "delims=" %%d in ('uv tool dir') do set "TOOLS=%%d"
"%TOOLS%\quantacolony\Scripts\quantacolony-shortcut.exe" || goto failed
echo.
echo QuantaColony is installed in %TOOLS%\quantacolony
echo This folder is no longer needed: you can move or delete it.
pause
exit /b 0

:no_uv
echo uv is not installed. Open PowerShell and run:
echo   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
echo Then close PowerShell and double-click this file again.
pause
exit /b 1

:failed
echo.
echo The installation did not finish; the messages above say why.
echo If QuantaColony is open, close it and run this file again.
pause
exit /b 1
