"""Help window shared by every screen: one formatted HTML page per topic.

Pages live in assets/help/<topic>.html and hold content only; the look comes
from HELP_STYLE here, so every page reads the same. The window is not modal:
it can stay open beside the screen it explains.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QHBoxLayout, QPushButton, QTextBrowser, QVBoxLayout, QWidget

from ..theme.icons import app_icon
from ..theme.tokens import get_quanta_colony_style

HELP_FOLDER = Path(__file__).resolve().parent.parent / "assets" / "help"
TITLES = {"detection": "Colony Detection", "cropping": "Cropping", "stats": "Stats", "projects": "Projects",
          "new_project": "Project setup"}

L = get_quanta_colony_style().light

# Qt's rich-text engine supports a subset of CSS; these rules stay within it
HELP_STYLE = f"""
body {{ color: {L.text}; font-size: 14px; }}
h1 {{ font-size: 22px; font-weight: 700; color: {L.header}; margin: 0 0 6px 0; }}
h2 {{ font-size: 15px; font-weight: 700; color: {L.link}; margin: 18px 0 4px 0; }}
p {{ margin: 4px 0 8px 0; line-height: 140%; }}
p.lead {{ color: {L.text_secondary}; font-size: 14px; }}
table {{ margin: 4px 0 10px 0; border-collapse: collapse; }}
th {{ background-color: {L.hover}; text-align: left; padding: 6px 10px; font-weight: 600; }}
td {{ padding: 5px 10px; border-bottom: 1px solid {L.rule}; vertical-align: top; }}
code {{ background-color: {L.hover}; font-family: Consolas, monospace; font-size: 13px; }}
.detected {{ color: {L.link}; font-weight: 600; }}
.review {{ color: {L.review_text}; font-weight: 600; }}
"""

_open: dict[tuple[int, str], "HelpWindow"] = {}


def help_html(topic: str) -> str:
    path = HELP_FOLDER / f"{topic}.html"
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return f"<h1>{TITLES.get(topic, topic)}</h1><p>The help page for this screen is missing.</p>"


class HelpWindow(QDialog):
    def __init__(self, topic: str, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle(f"QuantaColony help · {TITLES.get(topic, topic)}")
        self.setWindowIcon(app_icon())
        self.setModal(False)
        self.resize(680, 720)
        self.setStyleSheet(f"QDialog {{ background: {L.page}; }}"
                           f"QTextBrowser {{ background: {L.surface}; border: 1px solid {L.border}; border-radius: 8px;"
                           f" padding: 14px 18px; color: {L.text}; }}"
                           f"QPushButton {{ background: {L.button}; color: {L.text}; border: 1px solid {L.border};"
                           " border-radius: 6px; padding: 6px 18px; }"
                           f"QPushButton:hover {{ background: {L.hover}; }}"
                           "QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }"
                           f"QScrollBar::handle:vertical {{ background: {L.scrollbar}; border-radius: 4px; min-height: 30px; }}"
                           "QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }")
        column = QVBoxLayout(self)
        column.setContentsMargins(16, 16, 16, 14)
        column.setSpacing(10)
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)
        self.browser.document().setDefaultStyleSheet(HELP_STYLE)
        self.browser.setHtml(help_html(topic))
        column.addWidget(self.browser, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        close = QPushButton("Close")
        close.setCursor(Qt.PointingHandCursor)
        close.clicked.connect(self.close)
        row.addWidget(close)
        column.addLayout(row)


def show_help(topic: str, parent: QWidget | None = None) -> HelpWindow:
    """Open (or bring forward) the help page for a topic."""
    key = (id(parent), topic)
    window = _open.get(key)
    if window is None or not window.isVisible():
        window = HelpWindow(topic, parent)
        window.setAttribute(Qt.WA_DeleteOnClose)
        window.destroyed.connect(lambda _=None, k=key: _open.pop(k, None))
        _open[key] = window
    window.show()
    window.raise_()
    window.activateWindow()
    return window
