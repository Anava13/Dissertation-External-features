"""The back button every screen inside a project shows at the same place: the far left of the
QuantaColony banner at the top, before the logo. Cropping, Colony Detection and Stats go back to
the project page; the project page goes back to the project list.

Its size, margins and colors are fixed here rather than taken from each window's style sheet, so it
looks and sits the same on the light pages and in the dark modules (both banners are
BANNER_HEIGHT tall with BANNER_MARGIN on the left).
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QPushButton

BANNER_HEIGHT = 60
BANNER_MARGIN = 16
BACK_SIZE = (176, 34)

BACK_STYLE = """
QPushButton#BackButton {{ background: transparent; color: #E6E6E2; border: 1px solid #4A4A4A; border-radius: 6px;
    font-size: 13px; font-weight: 600; padding: 0 12px; text-align: left; min-height: 0; }}
QPushButton#BackButton:hover {{ background: #2E2E2E; border-color: #6A6A6A; color: #FFFFFF; }}
QPushButton#BackButton:pressed {{ background: #3A3A3A; }}
"""


def back_button(text: str = "Back to project", tooltip: str = "Back to the project page") -> QPushButton:
    button = QPushButton(f"‹   {text}")
    button.setObjectName("BackButton")
    button.setFixedSize(*BACK_SIZE)
    button.setCursor(Qt.PointingHandCursor)
    button.setToolTip(tooltip)
    button.setAccessibleName(text)
    button.setStyleSheet(BACK_STYLE.format())
    return button
