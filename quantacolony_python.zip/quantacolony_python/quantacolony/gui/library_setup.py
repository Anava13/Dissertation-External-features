"""First start and missing-library screens: choose, locate or create the project library.

LibrarySetupWindow is the view (light palette); LibrarySetupController checks
locations with data.library and hands the result to the DataManager.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPixmap
from PySide6.QtWidgets import (QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QPushButton, QVBoxLayout, QWidget)

from ..data import DataManager, Library, LibraryError, check_location, create_library, default_library_folder
from ..data.library import read_marker
from ..theme import Theme
from ..theme.icons import app_icon, logo_pixmap
from ..theme.stylesheet import build_light_stylesheet
from ..theme.tokens import get_quanta_colony_style
from .dialogs import ERROR, WARNING, confirm, notify

SETUP, MISSING = "setup", "missing"
NEW_FOLDER_NAME = "QuantaColony Library"


class LibrarySetupWindow(QDialog):
    """View: one card with a title, explanation, folder field and actions."""

    def __init__(self, theme: Theme, parent=None):
        super().__init__(parent)
        self.theme = theme
        light = theme.style.light
        self.setObjectName("LightWindow")
        self.setWindowTitle("QuantaColony · Project library")
        self.setWindowIcon(app_icon())
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family))
        self.resize(760, 580)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        header = QFrame(objectName="LightHeader")
        header.setFixedHeight(52)
        header_row = QHBoxLayout(header)
        header_row.setContentsMargins(20, 0, 20, 0)
        header_row.setSpacing(10)
        logo = QLabel()
        logo.setPixmap(logo_pixmap(26))
        header_row.addWidget(logo)
        wordmark = QLabel()
        wordmark.setPixmap(self._wordmark("QuantaColony"))
        header_row.addWidget(wordmark)
        header_row.addStretch(1)
        root.addWidget(header)

        page = QWidget()
        page_column = QVBoxLayout(page)
        page_column.setContentsMargins(24, 40, 24, 24)
        card = QFrame(objectName="LightCard")
        card.setFixedWidth(600)               # fixed width lets wrapped labels compute their height
        page_column.addWidget(card, 0, Qt.AlignHCenter | Qt.AlignTop)
        page_column.addStretch(1)
        root.addWidget(page, 1)

        column = QVBoxLayout(card)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        top = QVBoxLayout()
        top.setContentsMargins(28, 24, 28, 18)
        top.setSpacing(8)
        self.title = self._label("", "title")
        self.intro = self._label("", "body", wrap=True)
        top.addWidget(self.title)
        top.addWidget(self.intro)
        column.addLayout(top)
        rule = QFrame(objectName="LightRule")
        rule.setFixedHeight(1)
        column.addWidget(rule)

        # Setup: folder field
        self.setup_body = QWidget()
        body = QVBoxLayout(self.setup_body)
        body.setContentsMargins(28, 20, 28, 20)
        body.setSpacing(10)
        body.addWidget(self._label("Library folder", "field"))
        field_row = QHBoxLayout()
        field_row.setSpacing(8)
        self.path_field = QLineEdit()
        self.path_field.setReadOnly(True)
        self.path_field.setAccessibleName("Library folder")
        self.choose_button = self._button("Choose folder…", "secondary")
        field_row.addWidget(self.path_field, 1)
        field_row.addWidget(self.choose_button)
        body.addLayout(field_row)
        self.status = self._label("", None, wrap=True)
        self.status.setAccessibleName("Folder check")
        body.addWidget(self.status)
        body.addWidget(self._label("Choose a folder on a local drive. Network drives, and folders synced by "
                                   "OneDrive, Dropbox or Google Drive, can damage project files while they are "
                                   "open. To share a project, export a copy from QuantaColony.", "muted", wrap=True))
        column.addWidget(self.setup_body)

        # Missing: where it was
        self.missing_body = QWidget()
        missing = QVBoxLayout(self.missing_body)
        missing.setContentsMargins(28, 20, 28, 20)
        missing.setSpacing(12)
        grid = QGridLayout()
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(6)
        grid.addWidget(self._label("Last found at", "muted"), 0, 0)
        self.last_path = self._label("", None, wrap=True)
        grid.addWidget(self.last_path, 0, 1)
        grid.addWidget(self._label("Also checked", "muted"), 1, 0)
        grid.addWidget(self._label("The same folder on every other drive letter", None, wrap=True), 1, 1)
        grid.setColumnStretch(1, 1)
        missing.addLayout(grid)
        missing.addWidget(self._label("If the library is on an external drive, connect it and try again. If the "
                                      "folder was moved, locate it: QuantaColony checks that it is the same "
                                      "library before using it.", "body", wrap=True))
        column.addWidget(self.missing_body)

        footer = QFrame(objectName="LightCardFooter")
        buttons = QHBoxLayout(footer)
        buttons.setContentsMargins(28, 12, 28, 12)
        buttons.setSpacing(8)
        self.quit_button = self._button("Quit", "quiet")
        buttons.addWidget(self.quit_button)
        buttons.addStretch(1)
        self.new_library_button = self._button("Create a new library", None)
        self.retry_button = self._button("Try again", None)
        self.locate_button = self._button("Locate library…", "primary")
        self.create_button = self._button("Create library", "primary")
        for widget in (self.new_library_button, self.retry_button, self.locate_button, self.create_button):
            buttons.addWidget(widget)
        column.addWidget(footer)

    # ----- construction helpers -----------------------------------------
    @staticmethod
    def _label(text: str, role: str | None, wrap: bool = False) -> QLabel:
        widget = QLabel(text)
        if role:
            widget.setProperty("role", role)
        widget.setWordWrap(wrap)
        return widget

    @staticmethod
    def _button(text: str, variant: str | None) -> QPushButton:
        widget = QPushButton(text)
        if variant:
            widget.setProperty("variant", variant)
        widget.setCursor(Qt.PointingHandCursor)
        return widget

    def _wordmark(self, text: str) -> QPixmap:
        font = QFont(self.theme.brand_family)
        font.setPixelSize(16)
        font.setVariableAxis(QFont.Tag("wght"), 800)
        metrics = QFontMetricsF(font)
        pixmap = QPixmap(int((metrics.horizontalAdvance(text) + 2) * 2), int((metrics.height() + 2) * 2))
        pixmap.fill(Qt.transparent)
        pixmap.setDevicePixelRatio(2.0)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.TextAntialiasing)
        painter.setFont(font)
        painter.setPen(QColor(get_quanta_colony_style().colors.accent))
        painter.drawText(1, int(metrics.ascent()) + 1, text)
        painter.end()
        return pixmap

    # ----- updates the controller calls ----------------------------------
    def show_mode(self, mode: str, last_path: str = "") -> None:
        setup = mode == SETUP
        self.title.setText("Where should QuantaColony keep your projects?" if setup
                           else "The project library was not found")
        self.intro.setText("Every project is kept in one library folder. QuantaColony manages the files in it: "
                           "projects are opened, shared and restored from inside the program." if setup else
                           "QuantaColony keeps every project in one library folder, and that folder is not "
                           "where it was last found.")
        metrics = self.last_path.fontMetrics()
        self.last_path.setText(metrics.elidedText(last_path, Qt.ElideMiddle, 420))
        self.last_path.setToolTip(last_path)
        self.setup_body.setVisible(setup)
        self.missing_body.setVisible(not setup)
        self.create_button.setVisible(setup)
        for widget in (self.new_library_button, self.retry_button, self.locate_button):
            widget.setVisible(not setup)

    def show_candidate(self, path: str, message: str, state: str) -> None:
        """state: 'ok', 'note' (usable, with a warning) or 'bad' (cannot be used)."""
        self.path_field.setText(path)
        self.status.setText(message)
        for widget in (self.status, self.path_field):
            widget.setProperty("state", state)
            widget.style().unpolish(widget)
            widget.style().polish(widget)
        self.create_button.setEnabled(state != "bad")

    def ask_folder(self, start: str) -> str:
        return QFileDialog.getExistingDirectory(self, "Choose the library folder", start)

    def confirm(self, title: str, text: str) -> bool:
        return confirm(self, title, text)

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)


class LibrarySetupController:
    """Chooses, locates or creates the library and gives it to the DataManager."""

    def __init__(self, manager: DataManager, window: LibrarySetupWindow):
        self.manager = manager
        self.window = window
        self.candidate: Path = default_library_folder()
        self.mode = MISSING if manager.settings.library_path else SETUP
        window.choose_button.clicked.connect(lambda: self.choose_folder())
        window.create_button.clicked.connect(self.create_library)
        window.locate_button.clicked.connect(lambda: self.locate_library())
        window.retry_button.clicked.connect(self.try_again)
        window.new_library_button.clicked.connect(lambda: self.set_mode(SETUP))
        window.quit_button.clicked.connect(window.reject)
        self.set_mode(self.mode)

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.window.show_mode(mode, self.manager.settings.library_path)
        if mode == SETUP:
            self.set_candidate(self.candidate)

    def set_candidate(self, folder: Path) -> None:
        """Check a folder. A non-empty folder that is not a library gets a new subfolder inside it."""
        folder = Path(folder)
        if read_marker(folder) is not None:
            self.candidate = folder
            self.window.show_candidate(str(folder), "This folder already holds a QuantaColony library; "
                                                    "it will be used as it is.", "ok")
            return
        if folder.is_dir() and any(folder.iterdir()):
            folder = folder / NEW_FOLDER_NAME
        self.candidate = folder
        check = check_location(folder)
        if not check.ok:
            self.window.show_candidate(str(folder), check.problem, "bad")
        elif check.warning:
            self.window.show_candidate(str(folder), check.warning, "note")
        else:
            self.window.show_candidate(str(folder), f"{check.free_bytes / 1024 ** 3:,.0f} GB free on this drive",
                                       "ok")

    def choose_folder(self, folder: str | None = None) -> None:
        folder = folder if folder is not None else self.window.ask_folder(str(self.candidate.parent))
        if folder:
            self.set_candidate(Path(folder))

    def create_library(self) -> None:
        try:
            library = create_library(self.candidate)
        except (LibraryError, OSError) as error:
            self.window.report("Library not created", str(error))
            return
        self._finish(library)

    def locate_library(self, folder: str | None = None) -> None:
        folder = folder if folder is not None else self.window.ask_folder(self.manager.settings.library_path)
        if not folder:
            return
        library_id = read_marker(Path(folder))
        if library_id is None:
            self.window.report("Not a library", f"{folder} is not a QuantaColony library. "
                                                "Choose the folder that contains library.json.", WARNING)
            return
        if library_id != self.manager.settings.library_id and not self.window.confirm(
                "A different library", "This folder holds a different QuantaColony library than the one last "
                                       "used. Use it from now on?"):
            return
        self._finish(Library(Path(folder).resolve(), library_id))

    def try_again(self) -> None:
        library = self.manager.resolve_library()
        if library is None:
            self.window.report("Still not found", "The library is not at its last location or on another drive.", WARNING)
            return
        self._finish(library)

    def _finish(self, library: Library) -> None:
        self.manager.use_library(library)
        self.window.accept()


def ensure_library(manager: DataManager, theme: Theme) -> bool:
    """Find the library, or ask the user to create or locate one. False when the user quits."""
    if manager.resolve_library() is not None:
        return True
    window = LibrarySetupWindow(theme)
    LibrarySetupController(manager, window)
    return window.exec() == QDialog.Accepted and manager.library is not None
