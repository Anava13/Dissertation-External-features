"""Interaction modes: label, icon, shortcut, hint text and which side panel shows.

Keys keep the MATLAB mode names (ModifyGlobalParameters, ...) so code maps
one to one; labels are the new user-facing names.

Detection is two steps: automatic detection on the whole image, then manual
correction with four tools. Each mode belongs to one of the two groups.
"""

from __future__ import annotations

from dataclasses import dataclass

AUTOMATIC, MANUAL = "automatic", "manual"
GROUP_TITLES = {AUTOMATIC: "Step 1 · Automatic detection", MANUAL: "Step 2 · Manual correction"}


@dataclass(frozen=True)
class ModeSpec:
    key: str
    label: str
    icon: str
    shortcut: str
    group: str                # AUTOMATIC or MANUAL
    hint: str                 # chip over the plate before the user has started
    hint_active: str          # chip once there is something to act on
    panel: str                # 'parameters', 'delete_one', 'delete_region', 'add_one'
    region_parameters: bool = False   # parameters apply inside a region only (Add Many)


MODES: dict[str, ModeSpec] = {spec.key: spec for spec in [
    ModeSpec("ModifyGlobalParameters", "Detect automatically", "sliders", "1", AUTOMATIC,
             "Detect automatically · adjust settings on the left",
             "Detect automatically · adjust settings on the left", "parameters"),
    ModeSpec("DeleteIndividualColonies", "Delete colonies", "circle_x", "2", MANUAL,
             "Delete colonies · click detections to select",
             "Delete colonies · click more, then Delete (Esc clears)", "delete_one"),
    ModeSpec("DeleteManyColonies", "Delete a region", "region_x", "3", MANUAL,
             "Delete a region · drag a box over false detections",
             "Delete a region · Delete, or drag a new box", "delete_region"),
    ModeSpec("AddIndividualColonies", "Add colonies", "circle_plus", "4", MANUAL,
             "Add colonies · drag across a colony, edge to edge",
             "Add colonies · drag inside to move, drag the edge to resize", "add_one"),
    ModeSpec("AddManyColonies", "Detect in a region", "region_plus", "5", MANUAL,
             "Detect in a region · drag a box around the colonies",
             "Detect in a region · tune the settings, then Add", "parameters", region_parameters=True),
]}

MODE_ORDER = list(MODES)
DEFAULT_MODE = "ModifyGlobalParameters"
