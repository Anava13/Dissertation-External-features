"""CroppingController: connects the Cropping window to the DataManager.

State while Cropping is open:
    packet   CropPacket from the DataManager: variables, plate, photos, saved layouts
    drafts   {photo_id: Draft} for photos changed since their last save (or never saved);
             nothing here reaches the project file until "Done with photo"
    scope    {variable name: 'photo' | 'section'}, view / pages for the index board

"Done with photo" commits one photo (layout plus the levels of every section)
through DataManager.commit_photo, then opens the next photo with a proposal:
the previous layout, and the whole-photo variables stepped like an odometer.
"Finish cropping" lists indices that no photo holds before it emits finished.

The level pickers and the board show the design variables only. With a replicate variable, sections that
share a combination are plates of one index; DataManager.commit_photo numbers them and keeps the numbers.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from PySide6.QtCore import QObject, Signal

from ..core import cropping as cp
from ..core.cropping import DishLayout, GridLayout, layout_from_dict
from ..data import DataManager, ProjectError
from .cropping_window import CroppingWindow
from .help import show_help
from .dialogs import INFO, WARNING

ROTATE_STEP = 5.0                      # degrees per rotate button press or R key


@dataclass
class Draft:
    layout: object                      # DishLayout or GridLayout
    sections: list = field(default_factory=list)   # {variable: value} (possibly partial) or None per section
    edited: bool = False                # changed by the user (a fresh proposal is not)


class CroppingController(QObject):
    finished = Signal()

    def __init__(self, manager: DataManager, window: CroppingWindow):
        super().__init__()
        self.manager = manager
        self.data_manager = manager
        self.window = window
        self.next = None                         # (window, controller) of Colony Detection after Finish
        self.packet = manager.crop_packet()
        self.variables = list(self.packet.variables)           # design variables; replicates are numbered on save
        self.replicate = self.packet.replicate
        prefs = self.packet.preferences or {}
        self.scope = {v.name: prefs.get("scope", {}).get(v.name, cp.default_scope(self.variables)[v.name])
                      for v in self.variables}
        default_view = cp.default_view(self.variables, self.scope)
        self.view = {v.name: prefs.get("view", {}).get(v.name, default_view[v.name]) for v in self.variables}
        self.pages = {v.name: v.values[0] for v in self.variables}
        self.drafts: dict[int, Draft] = {}
        self._images: dict[int, object] = {}
        self.position = 0
        self.selected = 0
        self._connect()
        self.open_photo(self._first_open_position())

    # ----- wiring -----------------------------------------------------------
    def _connect(self) -> None:
        w = self.window
        w.previousRequested.connect(lambda: self.open_photo(self.position - 1))
        w.nextRequested.connect(lambda: self.open_photo(self.position + 1))
        w.doneRequested.connect(self.done_with_photo)
        w.finishRequested.connect(self.finish)
        w.helpRequested.connect(lambda: show_help("cropping", w))
        w.fitRequested.connect(self.fit_dish)
        w.rotateRequested.connect(lambda direction: self.rotate(direction * ROTATE_STEP))
        w.countRequested.connect(self.change_count)
        w.unusedRequested.connect(self.toggle_unused)
        w.problemRequested.connect(self.open_problem)
        w.layoutEdited.connect(self.layout_edited)
        w.sectionPicked.connect(self.select_section)
        w.cutRemoved.connect(self.remove_cut)
        w.targetChosen.connect(lambda target: self.open_target(*target))
        w.nextSectionRequested.connect(lambda: self.select_section(self.selected + 1))
        w.numberPressed.connect(self.pick_by_number)

    # ----- what is where ------------------------------------------------------
    @property
    def photos(self):
        return self.packet.photos

    @property
    def photo(self):
        return self.photos[self.position]

    def photo_variables(self):
        return [v for v in self.variables if self.scope[v.name] == cp.PHOTO]

    def section_variables(self):
        return [v for v in self.variables if self.scope[v.name] == cp.SECTION]

    def _saved(self, photo_id: int):
        if photo_id not in self.packet.layouts:
            return None
        layout, sections = self.packet.layouts[photo_id]
        return layout_from_dict(layout), [dict(s) if s else None for s in sections]

    def _first_open_position(self) -> int:
        return next((p.position - 1 for p in self.photos if p.photo_id not in self.packet.layouts), 0)

    def _image(self, photo_id: int):
        if photo_id not in self._images:
            self._images[photo_id] = self.manager.photo_image(photo_id)
        return self._images[photo_id]

    def current(self) -> tuple[object, list, bool]:
        """Layout, sections and whether they are saved as shown."""
        photo_id = self.photo.photo_id
        if photo_id in self.drafts:
            draft = self.drafts[photo_id]
            return draft.layout, draft.sections, False
        layout, sections = self._saved(photo_id)
        return layout, sections, True

    def _draft(self) -> Draft:
        """The current photo's draft, created from its saved layout on the first edit."""
        photo_id = self.photo.photo_id
        if photo_id not in self.drafts:
            layout, sections = self._saved(photo_id)
            self.drafts[photo_id] = Draft(layout, sections)
        draft = self.drafts[photo_id]
        draft.edited = True
        return draft

    def _proposal(self, position: int) -> Draft:
        """Previous photo's layout (dish refitted) with the whole-photo levels stepped; a fresh layout if none."""
        photo = self.photos[position]
        image = self._image(photo.photo_id)
        for earlier in range(position - 1, -1, -1):
            pid = self.photos[earlier].photo_id
            source = (self.drafts[pid].layout, self.drafts[pid].sections) if pid in self.drafts else self._saved(pid)
            if source is None:
                continue
            layout, sections = source
            if isinstance(layout, DishLayout):
                cx, cy, r = cp.fit_dish(image)
                layout = DishLayout(cx, cy, r, layout.cuts)
            repeat = self._expects_more_plates(earlier, sections)
            return Draft(layout, [self._without_replicate(s) for s in
                                  cp.propose_sections(sections, self.photo_variables(), repeat)])
        layout = cp.default_layout(image, self.packet.plate)
        start = {v.name: v.values[0] for v in self.photo_variables()}
        return Draft(layout, [dict(start) for _ in range(layout.section_count)])

    def _expects_more_plates(self, position: int, sections: list) -> bool:
        """With replicates: True while fewer photos up to `position` carry the whole-photo levels of `sections`
        than the plates each index expects (so the next photo is proposed as another plate of them)."""
        photo_variables = self.photo_variables()
        if not self.replicate or not photo_variables:
            return False
        first = next((s for s in sections if s), None)
        if first is None:
            return False
        wide = {v.name: first.get(v.name) for v in photo_variables}
        count = 0
        for photo in self.photos[:position + 1]:
            pid = photo.photo_id
            entries = self.drafts[pid].sections if pid in self.drafts else (
                self.packet.layouts[pid][1] if pid in self.packet.layouts else [])
            mine = next((s for s in entries if s), None)
            if mine is not None and all(mine.get(k) == x for k, x in wide.items()):
                count += 1
        return count < self.packet.plates_per_index

    def _without_replicate(self, levels):
        """A proposal's section levels without the replicate number (a new photo's plates get their own)."""
        if levels is None or not self.replicate:
            return levels
        return {k: v for k, v in levels.items() if k != self.replicate}

    def _elsewhere(self) -> dict[tuple, tuple[int, int]]:
        """Index keys saved on other photos -> (photo number, section)."""
        found = {}
        for photo in self.photos:
            if photo.photo_id == self.photo.photo_id or photo.photo_id not in self.packet.layouts:
                continue
            for section, levels in enumerate(self.packet.layouts[photo.photo_id][1]):
                if cp.complete(levels, self.variables):
                    found[cp.index_key(levels, self.variables)] = (photo.position, section)
        return found

    def problems(self) -> dict[int, str]:
        _, sections, _ = self.current()
        return cp.duplicate_sections(sections, self.variables, self._elsewhere(), replicates=bool(self.replicate))

    def can_confirm(self) -> bool:
        _, sections, saved = self.current()
        if saved:
            return self.position < len(self.photos) - 1
        ready = all(s is None or cp.complete(s, self.variables) for s in sections)
        return ready and any(s is not None for s in sections) and not self.problems()

    # ----- navigation ---------------------------------------------------------
    def open_photo(self, position: int) -> None:
        if not 0 <= position < len(self.photos):
            return
        self.position = position
        photo = self.photo
        if photo.photo_id not in self.packet.layouts and photo.photo_id not in self.drafts:
            self.drafts[photo.photo_id] = self._proposal(position)
        self.selected = 0
        self.window.show_photo(self._image(photo.photo_id))
        self.refresh()

    def open_target(self, position: int, section: int) -> None:
        if position != self.position:
            self.open_photo(position)
        self.select_section(section)

    def select_section(self, section: int) -> None:
        layout, _, _ = self.current()
        self.selected = section % layout.section_count
        self.refresh()

    def open_problem(self) -> None:
        problem = self.problems().get(self.selected, "")
        layout, sections, _ = self.current()
        key = cp.index_key(sections[self.selected] or {}, self.variables)
        if key in self._elsewhere():
            number, section = self._elsewhere()[key]
            self.open_target(number - 1, section)
        elif problem:
            twin = next(i for i, s in enumerate(sections)
                        if i != self.selected and s and cp.index_key(s, self.variables) == key)
            self.select_section(twin)

    # ----- layout edits -------------------------------------------------------
    def _set_layout(self, layout, remap: bool = True) -> None:
        draft = self._draft()
        if remap:
            draft.sections = self._carry_sections(draft.layout, layout, draft.sections)
        draft.layout = layout
        self.selected = min(self.selected, layout.section_count - 1)

    def _carry_sections(self, old, new, sections: list) -> list:
        """Levels follow the plate: each new section takes the levels of the old section under its middle.
        A section split in two keeps its levels on one half; the other half gets the whole-photo levels only."""
        claimed, carried = set(), []
        wide = next((s for s in sections if s), None) or {}
        wide = {v.name: wide[v.name] for v in self.photo_variables() if v.name in wide}
        for index in range(new.section_count):
            if isinstance(new, DishLayout):
                a, b = new.spans()[index]
                x, y = cp.point_at(new.cx, new.cy, (a + b) / 2, new.r * 0.5)
                if isinstance(old, DishLayout):     # compare angles: the dish center may have moved
                    x, y = x - new.cx + old.cx, y - new.cy + old.cy
            else:
                x, y = new.label_point(index)
                if isinstance(old, GridLayout):
                    x, y = x - new.cx + old.cx, y - new.cy + old.cy
            source = old.section_at(x, y)
            if 0 <= source < len(sections) and source not in claimed:
                claimed.add(source)
                carried.append(dict(sections[source]) if sections[source] else None)
            else:
                carried.append(dict(wide))
        return carried

    def layout_edited(self, layout, final: bool) -> None:
        self._set_layout(layout)
        if final:
            self.refresh()
        else:
            self._draw_canvas()

    def rotate(self, degrees: float) -> None:
        layout, _, _ = self.current()
        self._set_layout(layout.rotated(degrees))
        self.refresh()

    def fit_dish(self) -> None:
        layout, _, _ = self.current()
        if isinstance(layout, DishLayout):
            cx, cy, r = cp.fit_dish(self._image(self.photo.photo_id))
            self._set_layout(DishLayout(cx, cy, r, layout.cuts), remap=False)
            self.refresh()

    def change_count(self, step: int) -> None:
        layout, _, _ = self.current()
        if isinstance(layout, GridLayout):
            new = layout.with_grid(layout.rows, layout.cols + step)
        elif step > 0:
            spans = layout.spans()
            a, b = max(spans, key=lambda s: s[1] - s[0])
            new = layout.with_added_cut((a + b) / 2)
        else:
            if not layout.cuts:
                return
            spans = layout.spans()
            narrowest = min(range(len(spans)), key=lambda i: spans[i][1] - spans[i][0])
            end = spans[narrowest][1] % 360                   # remove the cut that closes the narrowest section
            new = layout.without_cut(min(range(len(layout.cuts)), key=lambda i: abs(layout.cuts[i] - end)))
        if new.section_count != layout.section_count:
            self._set_layout(new)
            self.refresh()

    def remove_cut(self, index: int) -> None:
        layout, _, _ = self.current()
        if isinstance(layout, DishLayout) and layout.cuts:
            self._set_layout(layout.without_cut(index))
            self.refresh()

    # ----- levels -------------------------------------------------------------
    def pick(self, variable: cp.VariableLevels, value: str) -> None:
        draft = self._draft()
        if self.scope[variable.name] == cp.PHOTO:
            for levels in draft.sections:
                if levels is not None:
                    levels[variable.name] = value
        else:
            if draft.sections[self.selected] is None:
                draft.sections[self.selected] = self._photo_levels(draft.sections)
            draft.sections[self.selected][variable.name] = value
        self.refresh()

    def pick_by_number(self, number: int) -> None:
        """Number keys: level n of the first per-section variable, then move to the next section."""
        variables = self.section_variables()
        if variables and number < len(variables[0].values):
            self.pick(variables[0], variables[0].values[number])
            layout, _, _ = self.current()
            if self.selected < layout.section_count - 1:
                self.select_section(self.selected + 1)

    def _photo_levels(self, sections: list) -> dict:
        first = next((s for s in sections if s), {})
        return {v.name: first[v.name] for v in self.photo_variables() if v.name in first}

    def toggle_unused(self) -> None:
        draft = self._draft()
        if draft.sections[self.selected] is None:
            draft.sections[self.selected] = self._photo_levels(draft.sections)
        else:
            draft.sections[self.selected] = None
        self.refresh()

    def set_scope(self, variable: cp.VariableLevels, scope: str) -> None:
        """Move a variable between the whole-photo and per-section pickers (all photos)."""
        if self.scope[variable.name] == scope:
            return
        self.scope[variable.name] = scope
        if scope == cp.PHOTO and self.photo.photo_id in self.drafts:
            sections = self.drafts[self.photo.photo_id].sections
            chosen = sections[self.selected] if sections[self.selected] else next((s for s in sections if s), None)
            value = (chosen or {}).get(variable.name)
            if value is not None:
                for levels in sections:
                    if levels is not None:
                        levels[variable.name] = value
        self._save_preferences()
        self.refresh()

    def set_view(self, variable: cp.VariableLevels, place: str) -> None:
        self.view[variable.name] = place
        self._save_preferences()
        self.refresh()

    def set_page(self, variable: cp.VariableLevels, value: str) -> None:
        self.pages[variable.name] = value
        self.refresh()

    def _save_preferences(self) -> None:
        self.manager.save_cropping_preferences({"scope": self.scope, "view": self.view})

    # ----- commit and finish --------------------------------------------------
    def done_with_photo(self) -> None:
        if not self.can_confirm():
            return
        layout, sections, saved = self.current()
        if not saved:
            try:
                flagged = self.manager.commit_photo(self.photo.photo_id, layout.to_dict(), sections)
            except ProjectError as error:
                self.window.report("This photo was not saved", str(error))
                return
            self.drafts.pop(self.photo.photo_id, None)
            self.packet = self.manager.crop_packet()
            if flagged:
                self.window.report("Colonies to review", f"{len(flagged)} index(es) on this photo already had saved "
                                   "colonies and their region changed. Colony Detection marks them for review.", WARNING)
        following = [p.position - 1 for p in self.photos[self.position + 1:] if p.photo_id not in self.packet.layouts]
        self.open_photo(following[0] if following else min(self.position + 1, len(self.photos) - 1))

    def unsaved_photos(self) -> int:
        return sum(1 for pid, d in self.drafts.items() if d.edited)

    def finish(self) -> bool:
        missing = self.manager.unassigned_index_keys()
        total = len(cp.all_index_keys(self.variables))
        examples = [cp.describe_key(key, self.variables) for key in missing[:8]]
        if not self.window.ask_finish(len(missing), total, examples, self.unsaved_photos()):
            return False
        if len(missing) == total:
            self.window.report("Nothing to detect yet", "No photo has been saved with regions yet.", INFO)
            return False
        self.finished.emit()
        return True

    # ----- drawing ------------------------------------------------------------
    def _section_text(self, levels) -> tuple[str, str]:
        if levels is None:
            return "Unused", "unused"
        shown = self.section_variables() or self.variables
        if not any(levels.get(v.name) in v.values for v in shown):
            return "Pick levels", "proposed"
        text = " · ".join(v.display(levels[v.name]) if levels.get(v.name) in v.values else "?" for v in shown)
        if self.replicate and levels.get(self.replicate):
            text += f" · plate {levels[self.replicate]}"
        return text, ""

    def _draw_canvas(self) -> None:
        layout, sections, saved = self.current()
        labels = []
        for i, levels in enumerate(sections):
            text, state = self._section_text(levels)
            labels.append((f"Section {i + 1}", text, state or ("confirmed" if saved else "proposed")))
        self.window.show_layout(layout, labels, self.selected, set(self.problems()))

    def refresh(self) -> None:
        w = self.window
        layout, sections, saved = self.current()
        photo = self.photo
        done = sum(1 for p in self.photos if p.photo_id in self.packet.layouts)
        w.set_photo_title(photo.file_name, photo.position, len(self.photos), done)
        self._draw_canvas()
        self._photo_list(done)
        self._pickers(sections)
        self._section_panel(layout, sections, saved)
        self._board()
        self._tools(layout, saved)

    def _photo_list(self, done: int) -> None:
        rows = []
        for photo in self.photos:
            draft = self.drafts.get(photo.photo_id)
            if photo.photo_id in self.packet.layouts:
                count = sum(1 for s in self.packet.layouts[photo.photo_id][1] if s)
                status, state = (("Changed, not saved", "proposed") if draft and draft.edited
                                 else (f"Done · {count} region{'s' if count != 1 else ''}", "done"))
            else:
                status, state = ("Proposed", "proposed") if draft else ("Not started", "new")
            rows.append((photo.file_name, status, state, photo.position - 1 == self.position,
                         lambda p=photo.position - 1: self.open_photo(p)))
        self.window.set_photo_rows(rows)

    def _pickers(self, sections: list) -> None:
        whole = next((s for s in sections if s), {}) or {}
        own = sections[self.selected] or {}
        whole_rows, section_rows = [], []
        for variable in self.variables:
            per_photo = self.scope[variable.name] == cp.PHOTO
            chosen = (whole if per_photo else own).get(variable.name)
            options = [(variable.display(value), value == chosen, lambda v=variable, x=value: self.pick(v, x))
                       for value in variable.values]
            target = cp.SECTION if per_photo else cp.PHOTO
            link = (variable.display_name, "set per section" if per_photo else "set for whole photo", options,
                    lambda v=variable, t=target: self.set_scope(v, t))
            (whole_rows if per_photo else section_rows).append(link)
        self.window.set_level_rows(self.window.whole_rows, whole_rows)
        self.window.set_level_rows(self.window.section_rows, section_rows)
        self.window.set_whole_note("same for every section" if whole_rows else "none")

    def _section_panel(self, layout, sections: list, saved: bool) -> None:
        levels = sections[self.selected]
        state = ("Unused" if levels is None else "Saved" if saved
                 else "Proposed" if cp.complete(levels, self.variables) else "Needs levels")
        problem = self.problems().get(self.selected, "")
        action = "Open it" if problem.startswith("Already") else "Show it"
        self.window.set_section_panel(f"Section {self.selected + 1} of {layout.section_count}", state, problem, action)
        self.window.set_unused(levels is None)

    def _board(self) -> None:
        placements: dict[tuple, list] = {}
        for photo in self.photos:
            draft = self.drafts.get(photo.photo_id)
            if draft is not None:
                entries, confirmed = draft.sections, False
            elif photo.photo_id in self.packet.layouts:
                entries, confirmed = self.packet.layouts[photo.photo_id][1], True
            else:
                continue
            for section, levels in enumerate(entries):
                if cp.complete(levels, self.variables):
                    placements.setdefault(cp.index_key(levels, self.variables), []).append(
                        (photo.position - 1, section, confirmed))
        board = cp.build_board(self.variables, self.view, self.pages, placements, replicates=bool(self.replicate))
        total = len(cp.all_index_keys(self.variables))
        confirmed = sum(1 for hits in placements.values() if any(c for _, _, c in hits))
        summary = f"{confirmed} of {total} placed"
        if self.replicate:
            plates = sum(1 for hits in placements.values() for _, _, c in hits if c)
            summary = f"{plates} plate{'s' if plates != 1 else ''} in {confirmed} of {total} combinations"
        note = []
        if board.counted:
            note.append(f"{board.counted} is counted inside each cell (too many columns to show it).")
        note.append("Click a cell to open its photo and section.")
        if self.replicate:
            note.append("Sections with the same levels are plates of one index (×2: two plates).")
        self.window.set_board(board, summary, " ".join(note))
        names = {cp.ROWS: "Rows", cp.COLUMNS: "Columns", cp.PAGES: "Pages"}
        self.window.set_view_rows([(v.display_name, [(names[place], self.view[v.name] == place,
                                                      lambda v=v, p=place: self.set_view(v, p)) for place in names])
                                   for v in self.variables])
        self.window.set_page_rows([(v.display_name, [(v.display(x), self.pages[v.name] == x,
                                                      lambda v=v, x=x: self.set_page(v, x)) for x in v.values])
                                   for v in self.variables if self.view[v.name] == cp.PAGES])

    def _tools(self, layout, saved: bool) -> None:
        circular = isinstance(layout, DishLayout)
        if circular:
            rotation = f"{(layout.cuts[0] if layout.cuts else 0):.0f}°"
            count = f"{layout.section_count} section{'s' if layout.section_count != 1 else ''}"
            hint = "Drag the center to move · the square to resize · the large handle to rotate · click a section"
        else:
            rotation = f"{layout.angle:.0f}°"
            count = f"{layout.rows} × {layout.cols} grid"
            hint = "Drag the center to move · a corner to resize · the round handle to rotate · click a section"
        plate = self.packet.plate
        if circular and plate.get("scale") == "dish" and plate.get("dish_mm"):
            scale = f"{2 * layout.r / float(plate['dish_mm']):.2f} px/mm from the {plate['dish_mm']:g} mm dish"
        else:
            scale = f"{self.photo.px_per_mm:.2f} px/mm" if self.photo.px_per_mm and math.isfinite(
                self.photo.px_per_mm) else ""
        text = "Next photo" if saved else ("Save changes" if self.photo.photo_id in self.packet.layouts
                                           else "Done with photo")
        self.window.set_tools(hint, rotation, count, scale, circular, self.can_confirm(), text)
