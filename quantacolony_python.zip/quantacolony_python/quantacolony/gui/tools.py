"""The four manual tools. Each turns mouse input into requests for the controller.

Tools hold only the state of the drag in progress. Colony data and the list
of drawn circles belong to the controller and the session.
"""

from __future__ import annotations

from typing import Callable, Protocol

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPainterPath, QPen
from PySide6.QtWidgets import (QGraphicsEllipseItem, QGraphicsItem, QGraphicsLineItem, QGraphicsPathItem,
                               QGraphicsRectItem, QGraphicsSimpleTextItem)

from ..theme.tokens import get_quanta_colony_style

EDGE_TOLERANCE_PX = 6          # screen pixels around a circle's edge that count as the edge


class CanvasTool:
    def __init__(self, canvas):
        self.canvas = canvas

    def press(self, point: QPointF, button=Qt.LeftButton) -> None: ...
    def move(self, point: QPointF) -> None: ...
    def release(self, point: QPointF, button=Qt.LeftButton) -> None: ...

    def deactivate(self) -> None:
        """Remove any temporary drawing when the mode changes."""


class DeleteIndividualTool(CanvasTool):
    """Click a colony to toggle its selection (handleDeleteClick)."""

    def __init__(self, canvas, on_click: Callable[[float, float], None]):
        super().__init__(canvas)
        self.on_click = on_click

    def release(self, point: QPointF, button=Qt.LeftButton) -> None:
        if button == Qt.LeftButton:
            self.on_click(point.x(), point.y())


class RectangleTool(CanvasTool):
    """Drag a dotted rectangle; report its corners on release (startDrawDeleteRect)."""

    def __init__(self, canvas, on_rect: Callable[[float, float, float, float], None], color: str):
        super().__init__(canvas)
        self.on_rect = on_rect
        self.color = color
        self._start: QPointF | None = None
        self._item: QGraphicsRectItem | None = None

    def press(self, point: QPointF, button=Qt.LeftButton) -> None:
        if button != Qt.LeftButton:
            return
        self._start = point
        self._item = QGraphicsRectItem(QRectF(point, point))
        pen = QPen(QColor(self.color), 2, Qt.DotLine)
        pen.setCosmetic(True)
        self._item.setPen(pen)
        self.canvas.add_preview_item(self._item)

    def move(self, point: QPointF) -> None:
        if self._start is not None and self._item is not None:
            self._item.setRect(QRectF(self._start, point).normalized())

    def release(self, point: QPointF, button=Qt.LeftButton) -> None:
        if self._start is None or button != Qt.LeftButton:
            return
        start, self._start = self._start, None
        self.deactivate()
        if abs(point.x() - start.x()) > 1 and abs(point.y() - start.y()) > 1:
            self.on_rect(start.x(), start.y(), point.x(), point.y())

    def deactivate(self) -> None:
        self.canvas.remove_preview_item(self._item)
        self._item = None
        self._start = None


class DeleteManyTool(RectangleTool):
    """Rectangle selection for deletion (setupManyDeletionMode)."""


class AddManyTool(RectangleTool):
    """Rectangle region for automatic detection (setupAddManyColoniesMode)."""


class CircleEditor(Protocol):
    """What AddIndividualTool needs from the controller."""

    def hit_test_circle(self, x: float, y: float, edge_tolerance: float) -> tuple[int, str]: ...
    def add_new_circle(self, x: float, y: float, r: float) -> int: ...
    def update_circle(self, index: int, x: float, y: float, r: float, final: bool) -> None: ...
    def remove_circle(self, index: int) -> None: ...
    def circle_geometry(self, index: int) -> tuple[float, float, float]: ...
    def describe_radius(self, r: float) -> str: ...


class RadiusGuide:
    """Center dot, guide line and radius readout shown while drawing or resizing.
    The line runs from start (the press point when drawing, the center when resizing) to the pointer."""

    def __init__(self, canvas, color: str):
        self.canvas = canvas
        pen = QPen(QColor(color), 1.4, Qt.DashLine)
        pen.setCosmetic(True)
        pen.setDashPattern([3, 2])
        self.line = QGraphicsLineItem()
        self.line.setPen(pen)
        self.center = QGraphicsEllipseItem(-3.5, -3.5, 7, 7)        # screen pixels (ignores zoom)
        self.center.setFlag(QGraphicsItem.ItemIgnoresTransformations)
        self.center.setBrush(QBrush(QColor(color)))
        self.center.setPen(QPen(QColor(get_quanta_colony_style().colony.halo), 1.5))
        # Readout: text on a dark rounded tag, sized in screen pixels beside the pointer
        self.tag = QGraphicsPathItem()
        self.tag.setFlag(QGraphicsItem.ItemIgnoresTransformations)
        self.tag.setBrush(QBrush(QColor(22, 23, 20, 235)))
        self.tag.setPen(QPen(QColor(color), 1))
        self.text = QGraphicsSimpleTextItem(self.tag)
        font = QFont()
        font.setPixelSize(12)
        font.setWeight(QFont.DemiBold)
        self.text.setFont(font)
        self.text.setBrush(QBrush(QColor(color)))
        self.items = (self.line, self.center, self.tag)
        for item in self.items:
            item.setZValue(10)
        self.shown = False

    def show(self, x: float, y: float, start: QPointF, pointer: QPointF, readout: str) -> None:
        if not self.shown:
            for item in self.items:
                self.canvas.add_preview_item(item)
            self.shown = True
        self.line.setLine(start.x(), start.y(), pointer.x(), pointer.y())
        self.center.setPos(x, y)
        self.text.setText(readout)
        box = self.text.boundingRect()
        self.text.setPos(14 + 8, -30 + 4)
        outline = QPainterPath()
        outline.addRoundedRect(QRectF(14, -30, box.width() + 16, box.height() + 8), 6, 6)
        self.tag.setPath(outline)
        self.tag.setPos(pointer.x(), pointer.y())

    def hide(self) -> None:
        if self.shown:
            for item in self.items:
                self.canvas.remove_preview_item(item)
            self.shown = False


class AddIndividualTool(CanvasTool):
    """Draw, move, resize and remove circles (drawcircle / addNewCircle).

    Left press on empty image: draw a new circle (press on one edge of the colony, drag
    across to the opposite edge; the drag is the diameter).
    Left press inside a circle: move it.  Left press on its edge: resize it.
    Right click on a circle: remove it.
    """

    def __init__(self, canvas, editor: CircleEditor, guide_color: str = get_quanta_colony_style().colony.manual):
        super().__init__(canvas)
        self.editor = editor
        self.guide = RadiusGuide(canvas, guide_color)
        self._drag = None          # (action, index, start point, start x, start y)

    def _edge_tolerance(self) -> float:
        return self.canvas.screen_to_image_distance(EDGE_TOLERANCE_PX)

    def press(self, point: QPointF, button=Qt.LeftButton) -> None:
        index, part = self.editor.hit_test_circle(point.x(), point.y(), self._edge_tolerance())
        if button == Qt.RightButton:
            if index >= 0:
                self.editor.remove_circle(index)
            return
        if button != Qt.LeftButton:
            return
        if index < 0:
            # The press point is one edge; the drag sets the diameter
            index = self.editor.add_new_circle(point.x(), point.y(), 0.5)
            part = "draw"
        x, y, _ = self.editor.circle_geometry(index)
        self._drag = (part, index, point, x, y)
        if part != "inside":
            r = 0.0 if part == "draw" else self.editor.circle_geometry(index)[2]
            self.guide.show(x, y, self._guide_start(), point, self.editor.describe_radius(r))

    def move(self, point: QPointF) -> None:
        if self._drag is None:
            self._update_cursor(point)
            return
        self._apply_drag(point, final=False)

    def release(self, point: QPointF, button=Qt.LeftButton) -> None:
        if self._drag is None or button != Qt.LeftButton:
            return
        action, index = self._drag[0], self._drag[1]
        x, y, r = self._new_geometry(point)
        self._drag = None
        self.guide.hide()
        if action == "draw" and r < 1.0:
            self.editor.remove_circle(index)          # a click without a drag draws nothing
            return
        self.editor.update_circle(index, x, y, r, final=True)
        self._update_cursor(point)

    def _new_geometry(self, point: QPointF) -> tuple[float, float, float]:
        action, index, start, start_x, start_y = self._drag
        x, y, r = self.editor.circle_geometry(index)
        if action == "inside":                                    # move
            return start_x + point.x() - start.x(), start_y + point.y() - start.y(), r
        if action == "draw":                                      # press and pointer are opposite edges
            diameter = ((point.x() - start.x()) ** 2 + (point.y() - start.y()) ** 2) ** 0.5
            return (start.x() + point.x()) / 2, (start.y() + point.y()) / 2, max(diameter / 2, 0.5)
        radius = ((point.x() - x) ** 2 + (point.y() - y) ** 2) ** 0.5
        return x, y, max(radius, 0.5)                             # resize: the center stays put

    def _guide_start(self) -> QPointF:
        """Drawing: the press point (the line is the diameter). Resizing: the center (the line is the radius)."""
        action, index, start, _, _ = self._drag
        if action == "draw":
            return start
        x, y, _ = self.editor.circle_geometry(index)
        return QPointF(x, y)

    def _apply_drag(self, point: QPointF, final: bool) -> None:
        x, y, r = self._new_geometry(point)
        if self._drag[0] != "inside":
            self.guide.show(x, y, self._guide_start(), point, self.editor.describe_radius(r))
        self.editor.update_circle(self._drag[1], x, y, r, final=final)

    def _update_cursor(self, point: QPointF) -> None:
        _, part = self.editor.hit_test_circle(point.x(), point.y(), self._edge_tolerance())
        shapes = {"inside": Qt.SizeAllCursor, "edge": Qt.SizeFDiagCursor}
        self.canvas.set_tool_cursor(shapes.get(part, Qt.CrossCursor))

    def deactivate(self) -> None:
        self._drag = None
        self.guide.hide()
        self.canvas.set_tool_cursor(Qt.ArrowCursor)
