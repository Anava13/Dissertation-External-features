"""StatsController: connects the Stats window to the DataManager and the analysis plug-ins.

State while Stats is open (all but the tables are saved with the project):
    colonies     ColonyTable from the DataManager: every colony of every detected index
    indices      IndexTable from the DataManager: one row per detected index
    analysis     id of the chosen analysis (built-in or from the library's Analyses folder)
    assignments  {analysis id: {variable name: slot key or '' (pooled)}}
    scheme       'raw', 'control_nominal' or 'control_ordinal'
    measures     {analysis id: measure id} for analyses with one row per index
    options      {analysis id: {option key: value}}

Analyses that declare background=True compute on a worker thread. Every result is kept for
the session by its inputs, so switching back to an analysis does not recompute it.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")           # analyses draw on figures; the window shows them on a Qt canvas

from PySide6.QtCore import QObject, QThread, Signal  # noqa: E402

from ..analyses import POOLED, PlotStyle  # noqa: E402
from ..analyses import data as ad  # noqa: E402
from ..analyses.common import show_message  # noqa: E402
from ..analyses.registry import load_analyses, sections  # noqa: E402
from ..data import DataManager, ProjectError  # noqa: E402
from .help import show_help  # noqa: E402
from .stats_window import StatsWindow  # noqa: E402

KIND_NAMES = {"nominal": "nominal", "ordinal": "ordinal", "replicate": "replicate"}
COVERAGE_MEASURES = ("growth_coverage", "colony_coverage", "capture_ratio")
SCHEME_NOTES = {ad.RAW: "The measurement as recorded.",
                ad.CONTROL_NOMINAL: "Each value divided by the mean of the control {groups} at the same {steps} level.",
                ad.CONTROL_ORDINAL: "Each value divided by the mean of its own group at the control {steps}."}


def plot_style(theme) -> PlotStyle:
    """The theme's plot colors and font, in the form every analysis draws with."""
    p = theme.style.plot
    return PlotStyle(ink=p.ink, muted=p.muted, grid=p.grid, spine=p.spine, background=p.background,
                     panel_edge=p.panel_edge, bar=p.bar, empty_cell=p.empty_cell, marker_fill=p.marker_fill,
                     group_colors=tuple(p.group_colors), step_colormap=p.step_colormap,
                     zone_colors=tuple(p.zone_colors), font_family=theme.ui_family or "sans-serif",
                     font_size=float(theme.style.fonts.small - 2))


class ComputeWorker(QThread):
    """Runs one analysis's compute step off the interface thread."""

    computed = Signal(object)
    failed = Signal(str)

    def __init__(self, analysis, data, options):
        from PySide6.QtCore import QCoreApplication
        app = QCoreApplication.instance()
        super().__init__(app)                          # outlives the Stats window if it closes mid-fit
        self.analysis, self.data, self.options = analysis, data, options
        self.finished.connect(self.deleteLater)
        if app is not None:
            app.aboutToQuit.connect(self.wait)

    def run(self) -> None:
        try:
            self.computed.emit(self.analysis.compute(self.data, self.options))
        except Exception as error:                          # an analysis's own error is shown, never raised
            self.failed.emit(f"{type(error).__name__}: {error}")


class StatsController(QObject):
    closed = Signal()

    def __init__(self, manager: DataManager, window: StatsWindow, theme=None):
        super().__init__()
        self.manager = manager
        self.data_manager = manager
        self.window = window
        self.style = plot_style(theme or window.theme)
        self.colonies = manager.colony_table()
        self.coverage_ready = manager.coverage_waiting() == 0
        self.indices = manager.index_table(coverage=self.coverage_ready)
        self.variables = list(self.colonies.variables)
        self.report = load_analyses(manager.analyses_folder())
        prefs = manager.module_preferences("stats")
        self.assignments: dict = dict(prefs.get("assignments", {}))
        self.measures: dict = dict(prefs.get("measures", {}))
        self.options: dict = dict(prefs.get("option_values", {}))
        self.scheme = prefs.get("scheme", ad.RAW)
        self.analysis_id = prefs.get("analysis", "density")
        if self.analysis_id not in self.report.analyses or self.current.background:
            self.analysis_id = "density"              # a long fit never starts on its own when Stats opens
        self.result = None
        self.data = None
        self._cache: dict = {}
        self._worker = None
        self._drawn_figure = None                     # a figure an analysis made itself (shown in place of ours)
        window.set_analyses(sections(self.report))
        window.analysisChosen.connect(self.choose_analysis)
        window.helpRequested.connect(lambda: show_help("stats", window))
        window.saveFigureRequested.connect(self.save_figure)
        window.saveTableRequested.connect(self.save_table)
        window.pluginsFolderRequested.connect(lambda: window.open_folder(str(manager.analyses_folder())))
        window.select_analysis(self.analysis_id)
        self.refresh()

    # ----- the chosen analysis -----------------------------------------------------
    @property
    def current(self):
        return self.report.analyses[self.analysis_id]

    @property
    def assignment(self) -> dict:
        return ad.merge_assignment(self.current, self.variables, self.assignments.get(self.analysis_id))

    def option_values(self) -> dict:
        saved = self.options.get(self.analysis_id, {})
        return {o.key: saved.get(o.key, o.initial) if saved.get(o.key) in dict(o.choices) else o.initial
                for o in self.current.options}

    # ----- choices ------------------------------------------------------------------
    def choose_analysis(self, key: str) -> None:
        if key != self.analysis_id and key in self.report.analyses:
            self.analysis_id = key
            self.window.select_analysis(key)
            self._save_preferences()
            self.refresh()

    def set_slot(self, variable: str, slot: str) -> None:
        assignment = self.assignment
        if assignment.get(variable) != slot:
            assignment[variable] = slot
            self.assignments[self.analysis_id] = assignment
            self._save_preferences()
            self.refresh()

    def set_scheme(self, scheme: str) -> None:
        if scheme != self.scheme:
            self.scheme = scheme
            self._save_preferences()
            self.refresh()

    def set_measure(self, measure: str) -> None:
        if self.measures.get(self.analysis_id) != measure:
            self.measures[self.analysis_id] = measure
            self._save_preferences()
            self.refresh()

    def set_option(self, key: str, value: str) -> None:
        values = self.option_values()
        if values.get(key) != value:
            values[key] = value
            self.options[self.analysis_id] = values
            self._save_preferences()
            self.refresh()

    def _save_preferences(self) -> None:
        self.manager.save_module_preferences("stats", {
            "analysis": self.analysis_id, "assignments": self.assignments, "scheme": self.scheme,
            "measures": self.measures, "option_values": self.options})

    # ----- controls -------------------------------------------------------------------
    def _controls(self, problem: str, axes: dict | None) -> None:
        analysis, assignment = self.current, self.assignment
        slots = [(s.key, s.title) for s in analysis.slots] + [(POOLED, "Pooled")]
        self.window.set_slots([(v.display_name, KIND_NAMES.get(v.kind, v.kind),
                                [(title, assignment[v.name] == key,
                                  lambda n=v.name, k=key: self.set_slot(n, k), ad.accepts(analysis, key, v))
                                 for key, title in slots]) for v in self.variables], problem)
        settings = []
        if analysis.normalize is not None and axes is not None:
            schemes = ad.available_schemes(analysis, axes)
            groups, steps = analysis.normalize
            words = {"groups": (axes[groups].title or "group").lower(), "steps": (axes[steps].title or "step").lower()}
            scheme = self.scheme if self.scheme in schemes else ad.RAW
            settings.append(("Normalization",
                             [(ad.scheme_label(s, axes, analysis), scheme == s, lambda s=s: self.set_scheme(s),
                               s in schemes) for s in ad.SCHEMES], True, SCHEME_NOTES[scheme].format(**words)))
        measures = ad.measures_for(analysis, self.indices)
        if len(measures) > 1:
            chosen = self.measures.get(self.analysis_id, next(iter(measures)))
            settings.append(("Measure", [(label.split(" (")[0], chosen == key, lambda k=key: self.set_measure(k))
                                         for key, label in measures.items()], True, ""))
        values = self.option_values()
        for option in analysis.options:
            settings.append((option.title, [(label, values[option.key] == value,
                                             lambda k=option.key, v=value: self.set_option(k, v))
                                            for value, label in option.choices], True, ""))
        if analysis.normalize is None and analysis.unit == "colony":
            settings.append(("Normalization", [("Raw data", True, lambda: None)], False,
                             "This analysis always uses the raw measurement."))
        self.window.set_settings(settings)

    # ----- drawing ----------------------------------------------------------------------
    def refresh(self) -> None:
        w, analysis = self.window, self.current
        w.set_heading(analysis.name, analysis.description)
        w.set_exports(False)
        self.result, self.data = None, None
        problem = ad.assignment_problem(analysis, self.variables, self.assignment)
        rows = len(self.indices) if analysis.unit == "index" else len(self.colonies)
        if not rows:
            self._controls(problem, None)
            self._message("No detected colonies yet. Finish Colony Detection on at least one index.")
            return
        if problem:
            self._controls(problem, None)
            self._message(problem)
            return
        if analysis.unit == "index" and self.measures.get(self.analysis_id) in COVERAGE_MEASURES \
                and not self.coverage_ready:
            self._measure_coverage()
        data = ad.build_data(analysis, self.colonies, self.indices, self.assignment, self.scheme,
                             self.measures.get(self.analysis_id, ""))
        self._controls("", data.axes)
        problem = analysis.problem(data)
        if problem:
            self._message(problem)
            return
        self.data = data
        options = self.option_values()
        key = self._cache_key(data, options)
        if key in self._cache:
            self._show(self._cache[key])
            return
        if analysis.background:
            self._compute_in_background(analysis, data, options, key)
            return
        try:
            result = analysis.compute(data, options)
        except Exception as error:
            self._message(f"{analysis.name} could not be computed.", f"{type(error).__name__}: {error}")
            return
        self._cache[key] = result
        self._show(result)

    def _measure_coverage(self) -> None:
        """Growth coverage for every index not measured yet, with a progress dialog that can stop it."""
        waiting = self.manager.coverage_waiting()
        progress = self.window.start_progress("Measuring growth", f"Measuring growth on {waiting} indices…", waiting)
        measured = {"count": 0}

        def step(done, total):
            measured["count"] = done
            return progress(done, total)

        self.indices = self.manager.index_table(coverage=True, progress=step)
        self.coverage_ready = self.manager.coverage_waiting() == 0
        self.window.end_progress()
        self._cache = {key: value for key, value in self._cache.items() if key[0] != self.analysis_id}

    def _cache_key(self, data, options) -> tuple:
        return (self.analysis_id, tuple(sorted(self.assignment.items())), data.scheme, data.measure,
                tuple(sorted(options.items())))

    def _message(self, text: str, notes: str = "") -> None:
        show_message(self._fresh_figure(), text, self.style)
        self.window.show_figure(self.window.figure)
        self.window.set_notes("\n".join(filter(None, [notes] + self.report.problems)))

    def _fresh_figure(self):
        """The window's own figure (a figure an analysis made itself is replaced by it)."""
        from matplotlib.figure import Figure
        if self.window.figure is self._drawn_figure or self.window.figure is None:
            self.window.show_figure(Figure(figsize=(12, 7), facecolor=self.style.background))
        return self.window.figure

    def _show(self, result) -> None:
        analysis = self.current
        figure = self._fresh_figure()
        try:
            drawn = analysis.draw(figure, result, self.style)
        except Exception as error:
            self._message(f"{analysis.name} could not be drawn.", f"{type(error).__name__}: {error}")
            return
        if drawn is not None and drawn is not figure:
            self._drawn_figure = drawn
            self.window.show_figure(drawn, fit_height=True)
        else:
            self.window.show_figure(figure)
        self.result = result
        self.window.set_exports(bool(analysis.table(result)))
        self.window.set_notes("\n".join(filter(None, list(analysis.notes(result)) + self.report.problems)))

    def _compute_in_background(self, analysis, data, options, key) -> None:
        if self._worker is not None:
            return
        busy = analysis.busy_text(data) if hasattr(analysis, "busy_text") else f"Computing {analysis.name}…"
        show_message(self._fresh_figure(), busy, self.style)
        self.window.show_figure(self.window.figure)
        self.window.set_busy(True, busy)
        self._worker = ComputeWorker(analysis, data, options)
        self._worker.computed.connect(lambda result, k=key: self._computed(k, result))
        self._worker.failed.connect(lambda message: self._message(f"{analysis.name} could not run.", message))
        self._worker.finished.connect(self._worker_done)
        self._worker.start()

    def _computed(self, key, result) -> None:
        self._cache[key] = result
        if self.data is not None and key == self._cache_key(self.data, self.option_values()):
            self._show(result)

    def _worker_done(self) -> None:
        self._worker = None
        self.window.set_busy(False)
        if self.data is not None and self._cache_key(self.data, self.option_values()) not in self._cache:
            self.refresh()                     # the choices changed while it was computing

    def wait_for_compute(self, timeout_ms: int = 300000) -> None:
        """Block until a running background computation finishes (tests, scripts)."""
        if self._worker is not None:
            self._worker.wait(timeout_ms)

    # ----- exports -----------------------------------------------------------------------
    def _export_name(self) -> str:
        scheme = f"_{self.data.scheme}" if self.data is not None and self.data.scheme != ad.RAW else ""
        measure = f"_{self.data.measure}" if self.data is not None and self.current.unit == "index" else ""
        return f"{self.analysis_id.replace(':', '_')}{measure}{scheme}"

    def table_rows(self) -> list[dict]:
        return self.current.table(self.result) if self.result is not None else []

    def save_figure(self, path: str | None = None) -> None:
        if path is None:
            start = str(self.manager.exports_folder / "stats" / f"{self._export_name()}.png")
            path = self.window.ask_figure_path(start)
            if not path:
                return
        try:
            saved = self.manager.export_figure(self.window.figure, self._export_name(), path=path)
        except (OSError, ProjectError, ValueError) as error:
            self.window.report("Could not save the figure", str(error))
            return
        self.window.add_note_above(f"Saved {saved}")

    def save_table(self, path: str | None = None) -> None:
        rows = self.table_rows()
        if not rows:
            return
        if path is None:
            start = str(self.manager.exports_folder / "stats" / f"{self._export_name()}.csv")
            path = self.window.ask_table_path(start)
            if not path:
                return
        try:
            saved = self.manager.export_rows_csv(rows, self._export_name(), path=path)
        except (OSError, ProjectError) as error:
            self.window.report("Could not save the table", str(error))
            return
        self.window.add_note_above(f"Saved {saved}")
