"""StatsController: connects the Stats window to the DataManager and the analysis plug-ins.

State while Stats is open (all but the tables are saved with the project):
    colonies     ColonyTable from the DataManager: every colony of every detected index
    indices      IndexTable from the DataManager: one row per detected index
    analysis     id of the chosen analysis (built-in or from the library's Analyses folder)
    assignments  {analysis id: {variable name: slot key or '' (pooled)}}
    scheme       'raw', 'control_nominal' or 'control_ordinal'
    measures     {analysis id: measure id} for analyses with one row per index
    options      {analysis id: {option key: value}}
    hidden       {variable name: level values not shown}, for every analysis
    color_by     the variable whose levels set the colors, '' for each analysis's own colors
    level_colors {variable name: {level value: '#rrggbb'}}: colors the user chose (defaults elsewhere)
    leave_out    True: indices below the capture-ratio cutoff (overplated) are left out of every analysis
    no_touching  True: colonies split from touching blobs are left out of colony sizes (counts keep them)
    by_hand      index ids left out of every analysis by hand (the plate list)
    choice       one plate per group (core.selection): an analysis with marks_selection (the mixture
                 model) draws every used plate and marks the chosen ones; others use the chosen ones only

Analyses that declare background=True compute on a worker thread. Every result is kept for
the session by its inputs, so switching back to an analysis does not recompute it.
"""

from __future__ import annotations

import dataclasses

import matplotlib

matplotlib.use("Agg")           # analyses draw on figures; the window shows them on a Qt canvas

import numpy as np  # noqa: E402
from PySide6.QtCore import QObject, QThread, Signal  # noqa: E402

from ..analyses import POOLED, PlotStyle  # noqa: E402
from ..analyses import data as ad  # noqa: E402
from ..analyses.common import show_message  # noqa: E402
from ..analyses.registry import load_analyses, sections  # noqa: E402
from ..core.growth import SEPARABLE_CAPTURE_RATIO  # noqa: E402
from ..core.selection import (MISS, PINNED, SELECTED, SKIPPED, STATUS_TEXT, PlateTable, SelectionChoice,  # noqa: E402
                              default_matched, group_key_text, select_plates)
from ..data import DataManager, ProjectError  # noqa: E402
from .help import show_help  # noqa: E402
from .stats_window import StatsWindow  # noqa: E402

KIND_NAMES = {"nominal": "nominal", "ordinal": "ordinal", "replicate": "replicate"}
COVERAGE_MEASURES = ("growth_coverage", "colony_coverage", "capture_ratio")
SCHEME_NOTES = {ad.RAW: "The measurement as recorded.",
                ad.CONTROL_NOMINAL: "Each value divided by the mean of the control {groups} at the same {steps} level.",
                ad.CONTROL_ORDINAL: "Each value divided by the mean of its own group at the control {steps}."}


def plot_style(theme) -> PlotStyle:
    """The theme's plot colors and font, in the form every analysis draws with."""
    p = theme.style.plot
    return PlotStyle(ink=p.ink, muted=p.muted, grid=p.grid, spine=p.spine, background=p.background,
                     panel_edge=p.panel_edge, bar=p.bar, empty_cell=p.empty_cell, marker_fill=p.marker_fill,
                     group_colors=tuple(p.group_colors), step_colormap=p.step_colormap,
                     zone_colors=tuple(p.zone_colors), font_family=theme.ui_family or "sans-serif",
                     font_size=float(theme.style.fonts.small - 2))


class ComputeWorker(QThread):
    """Runs one analysis's compute step off the interface thread."""

    computed = Signal(object)
    failed = Signal(str)

    def __init__(self, analysis, data, options):
        from PySide6.QtCore import QCoreApplication
        app = QCoreApplication.instance()
        super().__init__(app)                          # outlives the Stats window if it closes mid-fit
        self.analysis, self.data, self.options = analysis, data, options
        self.finished.connect(self.deleteLater)
        if app is not None:
            app.aboutToQuit.connect(self.wait)

    def run(self) -> None:
        try:
            self.computed.emit(self.analysis.compute(self.data, self.options))
        except Exception as error:                          # an analysis's own error is shown, never raised
            self.failed.emit(f"{type(error).__name__}: {error}")


class StatsController(QObject):
    closed = Signal()

    def __init__(self, manager: DataManager, window: StatsWindow, theme=None):
        super().__init__()
        self.manager = manager
        self.data_manager = manager
        self.window = window
        self.style = plot_style(theme or window.theme)
        self.colonies = manager.colony_table()
        self.coverage_ready = manager.coverage_waiting() == 0
        self.indices = manager.index_table(coverage=self.coverage_ready)
        self.variables = list(self.colonies.variables)          # design variables (replicates are always pooled)
        self.replicate_name = next((v.display_name for v in manager.project_info().variables
                                    if v.type == "replicate"), "")
        self.report = load_analyses(manager.analyses_folder())
        for analysis in self.report.analyses.values():           # fits kept per analysis start fresh
            if hasattr(analysis, "reset_cache"):
                analysis.reset_cache()
        prefs = manager.module_preferences("stats")
        self.assignments: dict = dict(prefs.get("assignments", {}))
        self.measures: dict = dict(prefs.get("measures", {}))
        self.options: dict = dict(prefs.get("option_values", {}))
        self.scheme = prefs.get("scheme", ad.RAW)
        names = {v.name for v in self.variables}
        self.hidden: dict = {k: list(v) for k, v in dict(prefs.get("hidden_levels", {})).items() if k in names}
        self.color_by: str = prefs.get("color_by", "") if prefs.get("color_by", "") in names else ""
        self.level_colors: dict = {k: dict(v) for k, v in dict(prefs.get("level_colors", {})).items() if k in names}
        self.leave_out: bool = bool(prefs.get("leave_out_overplated", False))
        self.no_touching: bool = bool(prefs.get("leave_out_touching", False))
        self.variables_collapsed: bool = bool(prefs.get("variables_collapsed", False))
        self.choice = SelectionChoice.from_dict(prefs.get("plate_selection"))
        self.by_hand: list[int] = [int(i) for i in prefs.get("left_out_by_hand", [])]
        self.choice.matched = [n for n in self.choice.matched if n in names] or default_matched(self.variables)
        self.analysis_id = prefs.get("analysis", "density")
        if self.analysis_id not in self.report.analyses or self.current.background:
            self.analysis_id = "density"              # a long fit never starts on its own when Stats opens
        self.result = None
        self.data = None
        self._cache: dict = {}
        self._worker = None
        self._drawn_figure = None                     # a figure an analysis made itself (shown in place of ours)
        window.set_analyses(sections(self.report))
        window.analysisChosen.connect(self.choose_analysis)
        window.variablesToggled.connect(self.set_variables_collapsed)
        window.helpRequested.connect(lambda: show_help("stats", window))
        window.saveFigureRequested.connect(self.save_figure)
        window.saveTableRequested.connect(self.save_table)
        window.pluginsFolderRequested.connect(lambda: window.open_folder(str(manager.analyses_folder())))
        window.select_analysis(self.analysis_id)
        self.refresh()

    # ----- the chosen analysis -----------------------------------------------------
    @property
    def current(self):
        return self.report.analyses[self.analysis_id]

    @property
    def assignment(self) -> dict:
        return ad.merge_assignment(self.current, self.variables, self.assignments.get(self.analysis_id))

    def option_values(self) -> dict:
        saved = self.options.get(self.analysis_id, {})
        return {o.key: saved.get(o.key, o.initial) if saved.get(o.key) in dict(o.choices) else o.initial
                for o in self.current.options}

    # ----- choices ------------------------------------------------------------------
    def choose_analysis(self, key: str) -> None:
        if key != self.analysis_id and key in self.report.analyses:
            self.analysis_id = key
            self.window.select_analysis(key)
            self._save_preferences()
            self.refresh()

    def set_slot(self, variable: str, slot: str) -> None:
        assignment = self.assignment
        if assignment.get(variable) != slot:
            assignment[variable] = slot
            self.assignments[self.analysis_id] = assignment
            self._save_preferences()
            self.refresh()

    def set_scheme(self, scheme: str) -> None:
        if scheme != self.scheme:
            self.scheme = scheme
            self._save_preferences()
            self.refresh()

    def set_measure(self, measure: str) -> None:
        if self.measures.get(self.analysis_id) != measure:
            self.measures[self.analysis_id] = measure
            self._save_preferences()
            self.refresh()

    def set_option(self, key: str, value: str) -> None:
        values = self.option_values()
        if values.get(key) != value:
            values[key] = value
            self.options[self.analysis_id] = values
            self._save_preferences()
            self.refresh()

    def _variable(self, name: str):
        return next(v for v in self.variables if v.name == name)

    def toggle_level(self, name: str, value: str) -> None:
        """Show or hide one level. The last shown level of a variable stays shown."""
        variable = self._variable(name)
        hidden = {x for x in self.hidden.get(name, ()) if x in variable.values}
        if value in hidden:
            hidden.discard(value)
        elif sum(1 for x in variable.values if x not in hidden) > 1:
            hidden.add(value)
        else:
            return
        if hidden:
            self.hidden[name] = [x for x in variable.values if x in hidden]
        else:
            self.hidden.pop(name, None)
        self._save_preferences()
        self.refresh()
        self.window.refill_selection(self.selection_view())       # hidden levels change the pools
        self.window.refill_plates(self.plates_view())

    def show_all_levels(self, name: str) -> None:
        if self.hidden.pop(name, None) is not None:
            self._save_preferences()
            self.refresh()
            self.window.refill_selection(self.selection_view())

    def set_color_by(self, name: str) -> None:
        if name != self.color_by:
            self.color_by = name
            self._save_preferences()
            self.refresh()

    def set_leave_out(self, leave_out: bool) -> None:
        if leave_out != self.leave_out:
            self.leave_out = leave_out
            self._save_preferences()
            self.refresh()
            self.window.refill_plates(self.plates_view())

    def set_variables_collapsed(self, collapsed: bool) -> None:
        """A view choice: no recomputation, only the panel and the saved preference change."""
        self.variables_collapsed = collapsed
        self._save_preferences()
        self.window.set_variables_collapsed(collapsed, self.variables_summary())

    def variables_summary(self) -> str:
        """One line for the collapsed plot setup: what splits the plot, what is pooled, which plates are used."""
        analysis, assignment = self.current, self.assignment
        parts = []
        for slot in analysis.slots:
            names = [v.display_name for v in self.variables if assignment.get(v.name) == slot.key]
            if names:
                parts.append(f"{slot.title}: {' · '.join(names)}")
        pooled = [v.display_name for v in self.variables if assignment.get(v.name) == POOLED]
        pooled += [f"{self.replicate_name} plates"] if self.replicate_name else []
        if pooled:
            parts.append(f"pooled: {', '.join(pooled)}")
        shown = ad.shown_levels(self.variables, self.hidden)
        hidden = sum(len(v.values) - len(shown[v.name]) for v in self.variables)
        if hidden:
            parts.append(f"{hidden} level{'s' if hidden != 1 else ''} hidden")
        if self.choice.on:
            parts.append(self._selection_words().lower())
        elif self.leave_out:
            parts.append("overplated left out")
        if self.by_hand:
            parts.append(f"{len(self.by_hand)} left out by hand")
        if self.color_by:
            parts.append(f"colored by {self._variable(self.color_by).display_name}")
        return "   ·   ".join(parts) if parts else "No variables"

    def toggle_role(self, variable: str, slot: str) -> None:
        """A variable's chip in one part of the plot: on puts it there, off pools it."""
        self.set_slot(variable, POOLED if self.assignment.get(variable) == slot else slot)

    def set_no_touching(self, leave_out: bool) -> None:
        if leave_out != self.no_touching:
            self.no_touching = leave_out
            self._save_preferences()
            self.refresh()

    def touching_count(self) -> int:
        touching = self.colonies.touching
        return int(touching.sum()) if touching is not None else 0

    def overplated(self) -> list[int]:
        """Indices whose capture ratio is below the cutoff (needs growth coverage measured)."""
        ratios = self.indices.measures.get("capture_ratio")
        if ratios is None or not self.coverage_ready:
            return []
        below = np.isfinite(ratios) & (ratios < SEPARABLE_CAPTURE_RATIO)
        return [int(i) for i in self.indices.index_ids[below]]

    def index_label(self, index_id: int) -> str:
        row = int(np.flatnonzero(self.indices.index_ids == index_id)[0])
        return " · ".join(v.display(self.indices.levels[v.name][row]) for v in self.indices.variables)

    def colors_of(self, name: str) -> dict[str, str]:
        """Every level's color for a variable: the user's choices, defaults elsewhere."""
        return ad.level_colors(self._variable(name), self.style, self.level_colors.get(name))

    def choose_level_color(self, name: str, value: str, color: str | None = None) -> None:
        """Pick a level's color (the color picker when color is None)."""
        variable = self._variable(name)
        color = color or self.window.ask_color(self.colors_of(name)[value], f"Color of {variable.display(value)}")
        if not color:
            return
        self.level_colors.setdefault(name, {})[value] = color
        self._save_preferences()
        self.refresh()

    def draw_style(self):
        """The plot style with the chosen variable's level colors, when it can color this analysis."""
        if not self.color_by or ad.color_problem(self.current, self.variables, self.assignment, self.color_by):
            return self.style
        return dataclasses.replace(self.style, color_variable=self.color_by,
                                   level_colors=tuple(self.colors_of(self.color_by).items()))

    def _save_preferences(self) -> None:
        self.manager.save_module_preferences("stats", {
            "analysis": self.analysis_id, "assignments": self.assignments, "scheme": self.scheme,
            "measures": self.measures, "option_values": self.options, "hidden_levels": self.hidden,
            "color_by": self.color_by, "level_colors": self.level_colors,
            "leave_out_overplated": self.leave_out, "leave_out_touching": self.no_touching,
            "variables_collapsed": self.variables_collapsed, "plate_selection": self.choice.to_dict(),
            "left_out_by_hand": self.by_hand})

    # ----- plate selection (one plate per group, matched on colony count) ----------------
    def plate_table(self) -> PlateTable:
        """Every detected index as a plate: its levels, its photo's colony count and its capture ratio."""
        photos = self.manager.index_photos()
        ids = self.indices.index_ids
        counts = self.indices.measures["colony_count"]
        photo_of = np.array([photos.get(int(i), (-int(i), ""))[0] for i in ids])
        totals = {p: float(np.nansum(counts[photo_of == p])) for p in set(photo_of.tolist())}
        shared = {p for p in totals if int((photo_of == p).sum()) > 1}
        labels = tuple(photos.get(int(i), (0, f"index {int(i)}"))[1] + (f" (index {int(i)})" if photo_of[k] in shared else "")
                       for k, i in enumerate(ids))
        ratios = self.indices.measures.get("capture_ratio")
        if ratios is None:
            ratios = np.full(len(ids), np.nan)
        numbers = self.manager.plate_numbers()
        return PlateTable(ids, self.indices.levels, np.array([totals[p] for p in photo_of], dtype=float),
                          np.asarray(ratios, dtype=float), labels, tuple(numbers.get(int(i), "") for i in ids))

    def _per_index(self) -> bool:
        """True when every design variable is matched within: each group is one index."""
        return all(v.name in self.choice.matched for v in self.variables)

    def _selection_words(self) -> str:
        """How the Plates rule reads: one plate per index (among its replicates), or per group across levels."""
        if self._per_index():
            return ("One plate per index, chosen among its replicate plates" if self.replicate_name else
                    "One plate per index")
        across = [v.display_name for v in self.variables if v.name not in self.choice.matched]
        names = " × ".join(self._variable(n).display_name for n in self.choice.matched)
        return (f"One plate per {names}, chosen across {' and '.join(across)}"
                + (" and the replicate plates" if self.replicate_name else ""))

    def selection(self):
        """The plate selection for the current choices: (Selection or None, problem text)."""
        if not self.coverage_ready:
            return None, "Plate selection needs growth measured on every plate."
        try:
            return select_plates(self.plate_table(), list(self.indices.variables), self.choice.matched, self.hidden,
                                 self.choice.target, self.choice.pins, self.choice.skips,
                                 not_chosen=self.choice.not_chosen, by_hand=self.by_hand), ""
        except ValueError as error:
            return None, str(error)

    def _selection_changed(self) -> None:
        self._save_preferences()
        self.refresh()
        self.window.refill_selection(self.selection_view())

    def set_plate_selection(self, on: bool) -> None:
        if on != self.choice.on:
            self.choice.on = on
            self._save_preferences()
            self.refresh()
            if on:
                self.open_selection()

    def open_selection(self) -> None:
        if not self.coverage_ready:
            self._measure_coverage()
            self.refresh()
        self.window.show_selection(self.selection_view())

    def toggle_matched(self, name: str) -> None:
        """Match within a variable or stop; plates chosen by hand belong to the old groups, so they are cleared."""
        matched = [n for n in self.choice.matched if n != name] if name in self.choice.matched else \
            [v.name for v in self.variables if v.name in self.choice.matched or v.name == name]
        if not matched:
            return                                      # at least one variable
        self.choice.matched, self.choice.pins, self.choice.skips = matched, {}, []
        self._selection_changed()

    def toggle_chosen_from(self, name: str, value: str) -> None:
        """Choose from a level's plates or not (they are still drawn when their level is used)."""
        off = [x for x in self.choice.not_chosen.get(name, []) if x != value]
        if value not in self.choice.not_chosen.get(name, []):
            off.append(value)
        if off:
            self.choice.not_chosen[name] = off
        else:
            self.choice.not_chosen.pop(name, None)
        self._selection_changed()

    def set_target(self, target: float | None) -> None:
        self.choice.target = None if target is None else float(target)
        self._selection_changed()

    def pin_plate(self, group: str, index_id: int) -> None:
        self.choice.pins[group] = int(index_id)
        self.choice.skips = [g for g in self.choice.skips if g != group]
        self._selection_changed()

    def leave_group_empty(self, group: str) -> None:
        self.choice.pins.pop(group, None)
        if group not in self.choice.skips:
            self.choice.skips.append(group)
        self._selection_changed()

    def automatic_group(self, group: str) -> None:
        self.choice.pins.pop(group, None)
        self.choice.skips = [g for g in self.choice.skips if g != group]
        self._selection_changed()

    def reset_selection(self) -> None:
        self.choice.pins, self.choice.skips = {}, []
        self._selection_changed()

    def selection_view(self) -> dict:
        """What the selection window shows."""
        selection, problem = self.selection()
        target = self.choice.target
        shown = ad.shown_levels(self.variables, self.hidden)
        choose_from = [(v.display_name, [(v.display(x), x not in self.choice.not_chosen.get(v.name, []),
                                          lambda n=v.name, x=x: self.toggle_chosen_from(n, x)) for x in shown[v.name]])
                       for v in self.variables if v.name not in self.choice.matched]
        view = {"matched": [(v.display_name, v.name in self.choice.matched, lambda n=v.name: self.toggle_matched(n))
                            for v in self.variables],
                "choose_from": choose_from,
                "target": (target is not None, target if target is not None else
                           (selection.target if selection else float("nan")),
                           lambda: self.set_target(None), lambda value: self.set_target(value)),
                "summary": problem, "rows": [], "reset": self.reset_selection,
                "save": self.save_selection_table}
        if selection is None:
            return view
        view["details"] = selection.diagnostics()
        view["summary"] = (selection.summary() + f" The separable floor is a capture ratio of {selection.cutoff:.2f}."
                           + ("" if self.choice.on else " Plates is set to All: the selection is not used yet."))
        for group in selection.groups:
            text = group_key_text(group.key)
            chosen = group.chosen
            notes = ", ".join(chosen.failures) if chosen is not None and chosen.failures else \
                ("" if chosen is not None else group.why_empty())
            cells = (group.label, chosen.label if chosen else "—",
                     f"{chosen.count:g}" if chosen else "", f"{group.distance(selection.target):g}" if chosen else "",
                     f"{chosen.capture_ratio:.3f}" if chosen and np.isfinite(chosen.capture_ratio) else "",
                     str(group.pool_size), STATUS_TEXT[group.status], notes)
            choices = [("Automatic (closest)", group.status in (SELECTED, MISS), lambda g=text: self.automatic_group(g)),
                       ("Leave empty", group.status == SKIPPED, lambda g=text: self.leave_group_empty(g))]
            for candidate in group.candidates:
                flag = "" if candidate.eligible else " ✕"
                choices.append((f"{candidate.label} · {candidate.count:g}{flag}",
                                group.status == PINNED and chosen is not None and chosen.index_id == candidate.index_id,
                                lambda g=text, i=candidate.index_id: self.pin_plate(g, i)))
            view["rows"].append((cells, group.status == MISS or bool(chosen and chosen.failures), choices))
        return view

    # ----- the plate list: every plate, whether it is used, and why not ------------------
    def plate_reasons(self) -> dict[int, list[str]]:
        """Every plate's reasons for being left out of the plot ([] when it is used)."""
        shown = ad.shown_levels(self.indices.variables, self.hidden)
        overplated = set(self.overplated()) if self.leave_out or self.choice.on else set()
        reasons = {}
        for row, index_id in enumerate(self.indices.index_ids):
            index_id = int(index_id)
            found = []
            if index_id in self.by_hand:
                found.append("left out by hand")
            for v in self.indices.variables:
                value = self.indices.levels[v.name][row]
                if value not in shown[v.name]:
                    found.append(f"{v.display_name} {v.display(value)} not used")
            if index_id in overplated:
                found.append("overplated")
            reasons[index_id] = found
        return reasons

    def plates_view(self) -> dict:
        """What the plate list shows: one row per plate."""
        photos = self.manager.index_photos()
        reasons = self.plate_reasons()
        ratios = self.indices.measures.get("capture_ratio")
        counts = self.indices.measures["colony_count"]
        rows = []
        for row, index_id in enumerate(self.indices.index_ids):
            index_id = int(index_id)
            ratio = float(ratios[row]) if ratios is not None else np.nan
            rows.append((index_id, photos.get(index_id, (0, ""))[1], self.index_label(index_id), f"{counts[row]:g}",
                         f"{ratio:.3f}" if np.isfinite(ratio) else "", not reasons[index_id],
                         index_id not in self.by_hand, "; ".join(reasons[index_id]),
                         lambda i=index_id: self.toggle_by_hand(i)))
        used = sum(1 for r in rows if r[5])
        return {"rows": rows, "summary": f"{used} of {len(rows)} plates used."}

    def open_plates(self) -> None:
        self.window.show_plates(self.plates_view())

    def toggle_by_hand(self, index_id: int) -> None:
        if index_id in self.by_hand:
            self.by_hand.remove(index_id)
        else:
            self.by_hand.append(index_id)
        self._save_preferences()
        self.refresh()
        self.window.refill_plates(self.plates_view())
        self.window.refill_selection(self.selection_view())

    def save_selection_table(self, path: str | None = None) -> None:
        selection, problem = self.selection()
        if selection is None:
            self.window.report("Could not save the selection", problem)
            return
        if path is None:
            start = str(self.manager.exports_folder / "stats" / "plate_selection.csv")
            path = self.window.ask_table_path(start)
            if not path:
                return
        try:
            saved = self.manager.export_rows_csv(selection.rows(), "plate_selection", path=path)
        except (OSError, ProjectError) as error:
            self.window.report("Could not save the selection", str(error))
            return
        self.window.add_note_above(f"Saved {saved}")

    # ----- controls -------------------------------------------------------------------
    def _controls(self, problem: str, axes: dict | None) -> None:
        analysis, assignment = self.current, self.assignment
        # what each variable does: one row per part of the plot, its variables as chips
        roles = []
        for slot in analysis.slots:
            chips = [(v.display_name, assignment[v.name] == slot.key, lambda n=v.name, k=slot.key: self.toggle_role(n, k),
                      ad.accepts(analysis, slot.key, v)) for v in self.variables]
            roles.append((slot.title, slot.description, chips))
        pooled = [v.display_name for v in self.variables if assignment[v.name] == POOLED]
        pooled_text = (f"Not splitting the plot: {', '.join(pooled)}. Their plates are combined." if pooled else "")
        if self.replicate_name:
            pooled_text = (pooled_text + " " if pooled_text else "") + (
                f"{self.replicate_name} plates of each index are interchangeable, so they are always combined "
                "(One per index chooses among them).")
        self.window.set_roles(roles, pooled_text, problem)
        self.window.set_color_by([("Analysis colors", not self.color_by, lambda: self.set_color_by(""))] +
                                 [(v.display_name, self.color_by == v.name, lambda n=v.name: self.set_color_by(n))
                                  for v in self.variables],
                                 ad.color_problem(analysis, self.variables, assignment, self.color_by))
        # which plates: the levels used of each variable
        shown = ad.shown_levels(self.variables, self.hidden)
        rows = []
        for v in self.variables:
            colors = self.colors_of(v.name) if v.name == self.color_by else {}
            levels = [(v.display(x), x in shown[v.name], lambda n=v.name, x=x: self.toggle_level(n, x), colors.get(x),
                       (lambda n=v.name, x=x: self.choose_level_color(n, x)) if colors else None) for x in v.values]
            used = shown[v.name]
            filtered = len(used) < len(v.values)
            text = (f"All {len(v.values)} levels" if not filtered else
                    ", ".join(v.display(x) for x in used) if len(used) <= 3 else f"{len(used)} of {len(v.values)} levels")
            rows.append((v.display_name, KIND_NAMES.get(v.kind, v.kind), levels, text, filtered,
                         lambda n=v.name: self.show_all_levels(n)))
        self.window.set_slots(rows)
        self.window.set_variables_collapsed(self.variables_collapsed, self.variables_summary())
        self.window.set_plate_rules(self._plate_rules(analysis))
        self.window.set_settings(self._analysis_settings(analysis, axes))

    def _plate_rules(self, analysis) -> list:
        """Touching colonies, overplated plates, plates left out by hand and one plate per group."""
        rules = []
        if analysis.unit != "index":
            count = self.touching_count()
            note = (f"{count} colonies were split from touching colonies"
                    + (": left out of sizes, kept in colony counts." if self.no_touching else ".")
                    if count else "No colony was split from touching colonies.")
            rules.append(("Touching", [("Include", not self.no_touching, lambda: self.set_no_touching(False)),
                                       ("Leave out of sizes", self.no_touching, lambda: self.set_no_touching(True))],
                          True, note))
        cutoff = f"{SEPARABLE_CAPTURE_RATIO:.0%}"
        if not self.coverage_ready:
            note = f"Plates below {cutoff} capture ratio. Growth is measured when you choose Leave out."
        else:
            below = len(self.overplated())
            note = (f"{below} plate{'s' if below != 1 else ''} below {cutoff} capture ratio (colonies merged)"
                    + (", left out." if self.leave_out or self.choice.on else ".") if below else
                    f"No plate is below {cutoff} capture ratio.")
        if self.choice.on:
            note += " One plate per group always leaves them out."
        rules.append(("Overplated", [("Include", not self.leave_out and not self.choice.on, lambda: self.set_leave_out(False)),
                                     ("Leave out", self.leave_out or self.choice.on, lambda: self.set_leave_out(True))],
                      not self.choice.on, note))
        by_hand = len(self.by_hand)
        rules.append(("By hand", [], True,
                      f"{by_hand} plate{'s' if by_hand != 1 else ''} left out by hand." if by_hand else "",
                      [("Plates…", self.open_plates)]))
        if self.choice.on:
            note = (f"{self._selection_words()}: the plate closest to the colony-count target."
                    + (" The others are drawn faded." if getattr(analysis, "marks_selection", False) else
                       " The others are left out."))
        else:
            note = "Every plate used" + (f", every {self.replicate_name.lower()} plate of each index pooled."
                                         if self.replicate_name else ".")
        per_index = self._per_index()
        rules.append(("Plates", [("All", not self.choice.on, lambda: self.set_plate_selection(False)),
                                 ("One per index" if per_index else "One per group", self.choice.on,
                                  lambda: self.set_plate_selection(True))],
                      True, note, [("Selection…", self.open_selection)]))
        return rules

    def _analysis_settings(self, analysis, axes) -> list:
        settings = []
        if analysis.normalize is not None and axes is not None:
            schemes = ad.available_schemes(analysis, axes)
            groups, steps = analysis.normalize
            words = {"groups": (axes[groups].title or "group").lower(), "steps": (axes[steps].title or "step").lower()}
            scheme = self.scheme if self.scheme in schemes else ad.RAW
            settings.append(("Normalization",
                             [(ad.scheme_label(s, axes, analysis), scheme == s, lambda s=s: self.set_scheme(s),
                               s in schemes) for s in ad.SCHEMES], True, SCHEME_NOTES[scheme].format(**words)))
        measures = ad.measures_for(analysis, self.indices)
        if len(measures) > 1:
            chosen = self.measures.get(self.analysis_id, next(iter(measures)))
            settings.append(("Measure", [(label.split(" (")[0], chosen == key, lambda k=key: self.set_measure(k))
                                         for key, label in measures.items()], True, ""))
        values = self.option_values()
        for option in analysis.options:
            settings.append((option.title, [(label, values[option.key] == value,
                                             lambda k=option.key, v=value: self.set_option(k, v))
                                            for value, label in option.choices], True, ""))
        if analysis.normalize is None and analysis.unit == "colony":
            settings.append(("Normalization", [("Raw data", True, lambda: None)], False,
                             "This analysis always uses the raw measurement."))
        return settings

    # ----- drawing ----------------------------------------------------------------------
    def refresh(self) -> None:
        w, analysis = self.window, self.current
        w.set_heading(analysis.name, analysis.description)
        w.set_exports(False)
        self.result, self.data = None, None
        problem = ad.assignment_problem(analysis, self.variables, self.assignment)
        rows = len(self.indices) if analysis.unit == "index" else len(self.colonies)
        if not rows:
            self._controls(problem, None)
            self._message("No detected colonies yet. Finish Colony Detection on at least one index.")
            return
        if problem:
            self._controls(problem, None)
            self._message(problem)
            return
        if (self.leave_out or self.choice.on
                or (analysis.unit == "index" and self.measures.get(self.analysis_id) in COVERAGE_MEASURES)) \
                and not self.coverage_ready:
            self._measure_coverage()
        overplated = self.overplated() if self.leave_out or self.choice.on else []
        left_out = sorted(set(overplated) | set(self.by_hand))
        selection = None
        chosen = None
        if self.choice.on:
            selection, selection_problem = self.selection()
            if selection is None:
                self._controls("", None)
                self._message(selection_problem)
                return
            if not selection.chosen:
                self._controls("", None)
                self._message("Plate selection kept no plate. Open Selection… to see why each group is empty.")
                return
            if getattr(analysis, "marks_selection", False):  # every used plate is drawn; the chosen ones stand out
                chosen = frozenset(selection.chosen)
                left_out = sorted(set(left_out) - chosen)  # a plate chosen by hand is drawn even when it fails a rule
            else:
                left_out = [int(i) for i in self.indices.index_ids if int(i) not in selection.chosen]
        self.left_out = (tuple(left_out), tuple(sorted(chosen)) if chosen is not None else None)
        data = ad.build_data(analysis, self.colonies, self.indices, self.assignment, self.scheme,
                             self.measures.get(self.analysis_id, ""), self.hidden, left_out, self.no_touching)
        if chosen is not None:
            data = dataclasses.replace(data, selected=chosen)
        if self.no_touching and analysis.unit != "index" and self.touching_count():
            data = dataclasses.replace(data, notes=(f"{self.touching_count()} colonies split from touching colonies "
                                                    "are left out of sizes.",) + tuple(data.notes))
        if self.by_hand:
            data = dataclasses.replace(data, notes=(f"Left out by hand: {len(self.by_hand)} "
                                                    f"plate{'s' if len(self.by_hand) != 1 else ''}.",)
                                       + tuple(data.notes))
        if overplated:
            data = dataclasses.replace(data, notes=(f"Left out as overplated (capture ratio below "
                                                    f"{SEPARABLE_CAPTURE_RATIO:.0%}): {len(overplated)} "
                                                    f"plate{'s' if len(overplated) != 1 else ''}.",)
                                       + tuple(data.notes))
        if selection is not None:
            data = dataclasses.replace(data, notes=(selection.summary(),) + tuple(data.notes))
        self._controls("", data.axes)
        problem = analysis.problem(data)
        if problem:
            self._message(problem)
            return
        self.data = data
        options = self.option_values()
        key = self._cache_key(data, options)
        if key in self._cache:
            self._show(self._cache[key])
            return
        if analysis.background and getattr(analysis, "needs_background", lambda _data: True)(data):
            self._compute_in_background(analysis, data, options, key)
            return
        try:
            result = analysis.compute(data, options)
        except Exception as error:
            self._message(f"{analysis.name} could not be computed.", f"{type(error).__name__}: {error}")
            return
        self._cache[key] = result
        self._show(result)

    def _measure_coverage(self) -> None:
        """Growth coverage for every index not measured yet, with a progress dialog that can stop it."""
        waiting = self.manager.coverage_waiting()
        progress = self.window.start_progress("Measuring growth", f"Measuring growth on {waiting} indices…", waiting)
        measured = {"count": 0}

        def step(done, total):
            measured["count"] = done
            return progress(done, total)

        self.indices = self.manager.index_table(coverage=True, progress=step)
        self.coverage_ready = self.manager.coverage_waiting() == 0
        self.window.end_progress()
        self._cache = {key: value for key, value in self._cache.items() if key[0] != self.analysis_id}

    def _cache_key(self, data, options) -> tuple:
        hidden = tuple(sorted((name, tuple(values)) for name, values in self.hidden.items()))
        return (self.analysis_id, tuple(sorted(self.assignment.items())), data.scheme, data.measure,
                tuple(sorted(options.items())), hidden, getattr(self, "left_out", ()), self.no_touching)

    def _message(self, text: str, notes: str = "") -> None:
        show_message(self._fresh_figure(), text, self.style)
        self.window.show_figure(self.window.figure)
        self.window.set_notes("\n".join(filter(None, [notes] + self.report.problems)))

    def _fresh_figure(self):
        """The window's own figure (a figure an analysis made itself is replaced by it)."""
        from matplotlib.figure import Figure
        if self.window.figure is self._drawn_figure or self.window.figure is None:
            self.window.show_figure(Figure(figsize=(12, 7), facecolor=self.style.background))
        return self.window.figure

    def _show(self, result) -> None:
        analysis = self.current
        figure = self._fresh_figure()
        try:
            drawn = analysis.draw(figure, result, self.draw_style())
        except Exception as error:
            self._message(f"{analysis.name} could not be drawn.", f"{type(error).__name__}: {error}")
            return
        if drawn is not None and drawn is not figure:
            self._drawn_figure = drawn
            self.window.show_figure(drawn, fit_height=True)
        else:
            self.window.show_figure(figure)
        self.result = result
        self.window.set_exports(bool(analysis.table(result)))
        self.window.set_notes("\n".join(filter(None, list(analysis.notes(result)) + self.report.problems)))

    def _compute_in_background(self, analysis, data, options, key) -> None:
        if self._worker is not None:
            return
        busy = analysis.busy_text(data) if hasattr(analysis, "busy_text") else f"Computing {analysis.name}…"
        show_message(self._fresh_figure(), busy, self.style)
        self.window.show_figure(self.window.figure)
        self.window.set_busy(True, busy)
        self._worker = ComputeWorker(analysis, data, options)
        self._worker.computed.connect(lambda result, k=key: self._computed(k, result))
        self._worker.failed.connect(lambda message: self._message(f"{analysis.name} could not run.", message))
        self._worker.finished.connect(self._worker_done)
        self._worker.start()

    def _computed(self, key, result) -> None:
        self._cache[key] = result
        if self.data is not None and key == self._cache_key(self.data, self.option_values()):
            self._show(result)

    def _worker_done(self) -> None:
        self._worker = None
        self.window.set_busy(False)
        if self.data is not None and self._cache_key(self.data, self.option_values()) not in self._cache:
            self.refresh()                     # the choices changed while it was computing

    def wait_for_compute(self, timeout_ms: int = 300000) -> None:
        """Block until a running background computation finishes (tests, scripts)."""
        if self._worker is not None:
            self._worker.wait(timeout_ms)

    # ----- exports -----------------------------------------------------------------------
    def _export_name(self) -> str:
        scheme = f"_{self.data.scheme}" if self.data is not None and self.data.scheme != ad.RAW else ""
        measure = f"_{self.data.measure}" if self.data is not None and self.current.unit == "index" else ""
        return f"{self.analysis_id.replace(':', '_')}{measure}{scheme}"

    def table_rows(self) -> list[dict]:
        return self.current.table(self.result) if self.result is not None else []

    def save_figure(self, path: str | None = None) -> None:
        if path is None:
            start = str(self.manager.exports_folder / "stats" / f"{self._export_name()}.png")
            path = self.window.ask_figure_path(start)
            if not path:
                return
        try:
            saved = self.manager.export_figure(self.window.figure, self._export_name(), path=path)
        except (OSError, ProjectError, ValueError) as error:
            self.window.report("Could not save the figure", str(error))
            return
        self.window.add_note_above(f"Saved {saved}")

    def save_table(self, path: str | None = None) -> None:
        rows = self.table_rows()
        if not rows:
            return
        if path is None:
            start = str(self.manager.exports_folder / "stats" / f"{self._export_name()}.csv")
            path = self.window.ask_table_path(start)
            if not path:
                return
        try:
            saved = self.manager.export_rows_csv(rows, self._export_name(), path=path)
        except (OSError, ProjectError) as error:
            self.window.report("Could not save the table", str(error))
            return
        self.window.add_note_above(f"Saved {saved}")
