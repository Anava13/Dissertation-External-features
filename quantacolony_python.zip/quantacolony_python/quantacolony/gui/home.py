"""Home page: every project in the library with its progress, in nested folders, a summary of the
selected project or folder, and open, import, export (project file or browsable folder), backups,
delete (to the Trash), the Trash and library move.

Folders: New folder, drag projects and folders onto a folder (or between top-level rows to move
them to the top level), right-click for Rename, Move to and Delete. Delete moves a project, or a
folder with everything in it, into the Trash, where it is restored or deleted permanently.

HomeWindow is the view; HomeController talks to the DataManager. Opening a
project is handed to the navigator through the openProject signal.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QKeySequence, QPalette, QPixmap, QShortcut
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QFileDialog, QFrame, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QStyle, QStyledItemDelegate,
                               QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from ..data import PROJECT_SUFFIX, DataManager, LibraryError, ProjectError, check_location
from ..data.store.folders import TOP
from ..data.exports import export_problem, safe_name
from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .help import show_help
from .light import ProgressBar, light_button, light_header, light_label, paint_progress, panel_head, tile_grid
from .dialogs import ERROR, SUCCESS, WARNING, confirm, notify


def describe_size(size: int) -> str:
    for unit in ("bytes", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "bytes" else f"{size:.1f} {unit}"
        size /= 1024
    return ""


def describe_time(moment: datetime) -> str:
    return moment.astimezone().strftime("%b %d, %Y  %H:%M")


def project_summary(entry) -> dict:
    """What the summary panel shows for a project in the list."""
    waiting = max(entry.cropped_count - entry.detected_count, 0)
    text = f"{entry.detected_count} of {entry.plate_count} plates detected"
    if entry.review_count:
        text += f" · {entry.review_count} to review"
    if waiting:
        text += f" · {waiting} cropped, waiting for detection"
    dates = f"Changed {describe_time(entry.modified)}"
    if entry.created is not None:
        dates = f"Created {entry.created.astimezone().strftime('%b %d, %Y')} · " + dates
    return {"name": entry.name, "dates": dates,
            "progress": (entry.detected_count, entry.review_count, waiting, entry.plate_count),
            "progress_text": text,
            "tiles": [str(entry.photo_count), str(entry.variable_count),
                      f"{entry.cropped_count} of {entry.plate_count}", f"{entry.colony_count:,}"]}


def folder_summary(name: str, entries: list, subfolders: int) -> dict:
    """What the summary panel shows for a folder: its projects at any depth, added up."""
    detected = sum(e.detected_count for e in entries)
    review = sum(e.review_count for e in entries)
    total = sum(e.plate_count for e in entries)
    cropped = sum(e.cropped_count for e in entries)
    waiting = max(cropped - detected, 0)
    projects = f"{len(entries)} project{'s' if len(entries) != 1 else ''}"
    folders = f" · {subfolders} folder{'s' if subfolders != 1 else ''}" if subfolders else ""
    return {"name": name, "dates": f"Folder · {projects}{folders}",
            "progress": (detected, review, waiting, total),
            "progress_text": f"{detected} of {total} plates detected" + (f" · {review} to review" if review else ""),
            "tiles": [str(sum(e.photo_count for e in entries)), str(len(entries)), f"{cropped} of {total}",
                      f"{sum(e.colony_count for e in entries):,}"]}


PROJECT_TILES = ["photos", "variables", "plates cropped", "colonies counted"]
FOLDER_TILES = ["photos", "projects", "plates cropped", "colonies counted"]


class ProjectTree(QTreeWidget):
    """The project list: folders hold projects and other folders. Dropping only reports the move
    (dropped); the controller moves the records and redraws the tree."""

    dropped = Signal(object, str)              # [(kind, id)] dragged, destination folder ('' is the top level)
    deletePressed = Signal()
    renamePressed = Signal()

    def __init__(self):
        super().__init__()
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.InternalMove)
        self.setDefaultDropAction(Qt.MoveAction)

    def dropEvent(self, event) -> None:
        target = self.itemAt(event.position().toPoint())
        destination = TOP
        if target is not None:
            kind, key = target.data(0, Qt.UserRole)
            if kind == "folder" and self.dropIndicatorPosition() == QAbstractItemView.OnItem:
                destination = key
            elif target.parent() is not None:
                destination = target.parent().data(0, Qt.UserRole)[1]
        moved = [item.data(0, Qt.UserRole) for item in self.selectedItems()]
        event.setDropAction(Qt.IgnoreAction)                  # nothing moves here; the tree is redrawn
        event.accept()
        if moved:
            self.dropped.emit(moved, destination)

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Delete:
            self.deletePressed.emit()
        elif event.key() == Qt.Key_F2:
            self.renamePressed.emit()
        else:
            super().keyPressEvent(event)


class ProgressDelegate(QStyledItemDelegate):
    """Progress column: detected, flagged for review, and the rest, with 'n of m' beside the bar."""

    def __init__(self, light, parent=None):
        super().__init__(parent)
        self.light = light

    def paint(self, painter, option, index) -> None:
        super().paint(painter, option, index)                 # selection background
        data = index.data(Qt.UserRole + 1)
        if not data:
            return
        detected, review, total = data
        rect = option.rect.adjusted(10, 0, -10, 0)
        text = f"{detected} of {total}" if total else "no plates"
        painter.save()
        painter.setPen(QColor(self.light.text_secondary))
        metrics = option.fontMetrics
        text_width = metrics.horizontalAdvance("0000 of 0000")
        painter.drawText(QRectF(rect.right() - text_width, rect.top(), text_width, rect.height()),
                         Qt.AlignVCenter | Qt.AlignRight, text)
        painter.restore()
        bar = QRectF(rect.left(), rect.center().y() - 3, max(rect.width() - text_width - 12, 20), 7)
        paint_progress(painter, bar, [(detected - review, self.light.progress_done),
                                      (review, self.light.progress_review)], total, self.light.progress_track)


class ChoiceCard(QFrame):
    """A clickable card: a title and a description that wraps; it grows to fit its text."""

    clicked = Signal()

    def __init__(self, title: str, text: str):
        super().__init__(objectName="ChoiceCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAccessibleName(title)
        column = QVBoxLayout(self)
        column.setContentsMargins(16, 12, 16, 12)
        column.setSpacing(4)
        column.addWidget(light_label(title, "field"))
        column.addWidget(light_label(text, "small", wrap=True))

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.clicked.emit()
        else:
            super().keyPressEvent(event)


class HomeWindow(QMainWindow):
    """The home page's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    openRequested = Signal()                  # Open button or a double-click
    selectionChanged = Signal()
    importRequested = Signal()
    exportRequested = Signal()
    backupsRequested = Signal()
    moveRequested = Signal()
    newRequested = Signal()
    helpRequested = Signal()
    newFolderRequested = Signal()
    renameRequested = Signal()
    moveToRequested = Signal()
    deleteRequested = Signal()
    itemsDropped = Signal(object, str)        # [(kind, id)], destination folder
    trashRequested = Signal()
    tutorialRequested = Signal()
    startTutorialRequested = Signal()
    expansionChanged = Signal()
    restoreTrashRequested = Signal(str)        # Trash item id
    purgeTrashRequested = Signal(str)
    emptyTrashRequested = Signal()

    def __init__(self, theme: Theme):
        super().__init__()
        self.setObjectName("LightWindow")
        self.setProperty("tone", "gray")
        self.light = light = theme.style.light
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family))
        self.setWindowTitle("QuantaColony · Projects")
        self.setWindowIcon(app_icon())
        self.resize(1240, 780)
        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        header, header_row = light_header(theme, ["Projects"])
        self.help_button = light_button("Help", "header")
        header_row.addWidget(self.help_button)
        column.addWidget(header)

        page = QVBoxLayout()
        page.setContentsMargins(36, 26, 36, 22)
        page.setSpacing(16)
        top = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(4)
        titles.addWidget(light_label("Projects", "h1"))
        self.library_label = light_label("", "small")
        titles.addWidget(self.library_label)
        top.addLayout(titles)
        top.addStretch(1)
        self.start_tutorial_button = light_button("Start tutorial", "quiet",
                                                  "A guided tour of every module on the Crowding project")
        top.addWidget(self.start_tutorial_button)
        self.new_folder_button = light_button("New folder", None, "A folder inside the selected folder")
        self.import_button = light_button("Import project…", None, "Copy a shared .qcproj file into the library")
        self.new_button = light_button("New project", "primary")
        top.addWidget(self.new_folder_button)
        top.addWidget(self.import_button)
        top.addWidget(self.new_button)
        page.addLayout(top)

        body = QHBoxLayout()
        body.setSpacing(20)
        list_column = QVBoxLayout()
        list_column.setSpacing(0)
        self.tree = ProjectTree()
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels(["Name", "Progress", "Colonies", "Last changed", "Size"])
        self.tree.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tree.setFocusPolicy(Qt.StrongFocus)
        self.tree.setUniformRowHeights(True)
        self.tree.setIndentation(22)
        self.tree.setStyleSheet("QTreeWidget::item { height: 40px; }")
        self.tree.setItemDelegateForColumn(1, ProgressDelegate(light, self.tree))
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        header_view = self.tree.header()
        header_view.setStretchLastSection(False)
        header_view.setSectionResizeMode(0, QHeaderView.Stretch)
        for column_index, width in ((1, 230), (2, 90), (3, 170), (4, 100)):
            header_view.setSectionResizeMode(column_index, QHeaderView.Fixed)
            self.tree.setColumnWidth(column_index, width)
        header_view.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._folder_icon = self.style().standardIcon(QStyle.SP_DirIcon)
        list_column.addWidget(self.tree, 1)
        self.empty_label = light_label("No projects in this library yet. Create one, or import a shared .qcproj "
                                       "file.", "body", wrap=True)
        list_column.addWidget(self.empty_label)
        body.addLayout(list_column, 1)
        body.addWidget(self._build_summary_panel())
        page.addLayout(body, 1)

        footer = QHBoxLayout()
        self.legend = light_label("", "small")
        self.legend.setTextFormat(Qt.RichText)
        self.legend.setText(f"<span style='color:{light.progress_done}'>■</span> detected &nbsp; "
                            f"<span style='color:{light.progress_review}'>■</span> needs review &nbsp; "
                            f"<span style='color:{light.swatch_todo}'>■</span> still to do")
        footer.addWidget(self.legend)
        footer.addStretch(1)
        self.tutorial_button = light_button("Add tutorial project", "quiet",
                                            "A fresh copy of the Crowding tutorial project, in the selected folder")
        footer.addWidget(self.tutorial_button)
        self.trash_button = light_button("Trash", "quiet", "Deleted projects and folders: restore or delete for good")
        footer.addWidget(self.trash_button)
        self.move_button = light_button("Move library…", "quiet", "Move the whole project library to another folder")
        footer.addWidget(self.move_button)
        page.addLayout(footer)
        column.addLayout(page, 1)
        self.setCentralWidget(root)
        for widget, signal in ((self.open_button, self.openRequested), (self.import_button, self.importRequested),
                               (self.export_button, self.exportRequested), (self.backups_button, self.backupsRequested),
                               (self.move_button, self.moveRequested), (self.new_button, self.newRequested),
                               (self.help_button, self.helpRequested), (self.delete_button, self.deleteRequested),
                               (self.new_folder_button, self.newFolderRequested), (self.trash_button, self.trashRequested),
                               (self.tutorial_button, self.tutorialRequested),
                               (self.start_tutorial_button, self.startTutorialRequested)):
            widget.clicked.connect(signal.emit)
        self.tree.itemDoubleClicked.connect(self._double_clicked)
        self.tree.itemSelectionChanged.connect(self.selectionChanged.emit)
        self.tree.itemExpanded.connect(lambda _item: self.expansionChanged.emit())
        self.tree.itemCollapsed.connect(lambda _item: self.expansionChanged.emit())
        self.tree.dropped.connect(self.itemsDropped.emit)
        self.tree.deletePressed.connect(self.deleteRequested.emit)
        self.tree.renamePressed.connect(self.renameRequested.emit)
        self.tree.customContextMenuRequested.connect(self._context_menu)
        QShortcut(QKeySequence("Ctrl+Shift+N"), self, activated=self.newFolderRequested.emit)
        self._trash_dialog = None

    def _double_clicked(self, item, _column) -> None:
        if item.data(0, Qt.UserRole)[0] == "project":
            self.openRequested.emit()

    def _context_menu(self, position) -> None:
        item = self.tree.itemAt(position)
        menu = QMenu(self)
        if item is not None:
            self.tree.setCurrentItem(item)
            kind = item.data(0, Qt.UserRole)[0]
            if kind == "project":
                menu.addAction("Open", self.openRequested.emit)
            menu.addAction("New folder inside" if kind == "folder" else "New folder here", self.newFolderRequested.emit)
            if kind == "folder":
                menu.addAction("Rename…", self.renameRequested.emit)
            menu.addAction("Move to…", self.moveToRequested.emit)
            menu.addSeparator()
            menu.addAction("Delete", self.deleteRequested.emit)
        else:
            self.tree.clearSelection()
            menu.addAction("New folder", self.newFolderRequested.emit)
        menu.exec(self.tree.viewport().mapToGlobal(position))

    def _build_summary_panel(self) -> QFrame:
        panel = QFrame(objectName="LightPanel")
        panel.setFixedWidth(340)
        column = QVBoxLayout(panel)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        head, _ = panel_head("SELECTED PROJECT")
        column.addWidget(head)
        inner = QVBoxLayout()
        inner.setContentsMargins(18, 16, 18, 18)
        inner.setSpacing(12)
        self.thumbnail = QLabel(objectName="Thumbnail")
        self.thumbnail.setFixedHeight(150)
        self.thumbnail.setAlignment(Qt.AlignCenter)
        inner.addWidget(self.thumbnail)
        self.summary_name = light_label("", "h2", wrap=True)
        self.summary_dates = light_label("", "small", wrap=True)
        inner.addWidget(self.summary_name)
        inner.addWidget(self.summary_dates)
        self.summary_progress = ProgressBar(self.light.progress_track, height=10)
        inner.addWidget(self.summary_progress)
        self.summary_progress_text = light_label("", "small", wrap=True)
        inner.addWidget(self.summary_progress_text)
        grid, self.tiles = tile_grid(PROJECT_TILES, 2)
        inner.addLayout(grid)
        inner.addStretch(1)
        self.open_button = light_button("Open project", "primary")
        inner.addWidget(self.open_button)
        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.export_button = light_button("Export…", None, "Save a copy of this project to share or look inside")
        self.backups_button = light_button("Backups…", None, "Restore an earlier state of this project")
        actions.addWidget(self.export_button, 1)
        actions.addWidget(self.backups_button, 1)
        inner.addLayout(actions)
        self.delete_button = light_button("Delete…", "quiet", "Move to the Trash (restore it from there)")
        inner.addWidget(self.delete_button, 0, Qt.AlignRight)
        column.addLayout(inner, 1)
        self.summary_panel = panel
        return panel

    # ----- updates --------------------------------------------------------
    def set_library(self, path: str) -> None:
        self.library_label.setText(f"Library: {path}")

    def set_tree(self, nodes: list[tuple], selected: tuple | None, expanded: set) -> None:
        """nodes: (kind 'folder' or 'project', id, parent folder id or '', name, (detected, review, total)
        or None for an empty folder, colonies, changed, size), every folder before the folders and projects inside it.
        selected: (kind, id) to select; expanded: folder ids shown open."""
        self.tree.blockSignals(True)
        self.tree.clear()
        items, chosen = {}, None
        for kind, key, parent, name, progress, colonies, changed, size in nodes:
            item = QTreeWidgetItem([name, "", colonies, changed, size])
            item.setData(0, Qt.UserRole, (kind, key))
            font = item.font(0)
            font.setWeight(font.Weight.DemiBold)
            item.setFont(0, font)
            if progress is not None:                        # None: an empty folder
                item.setData(1, Qt.UserRole + 1, progress)
                detected, review, total = progress
                item.setToolTip(1, f"{detected} of {total} plates detected" + (f", {review} to review" if review else ""))
            if kind == "folder":
                item.setIcon(0, self._folder_icon)
                item.setFlags(item.flags() | Qt.ItemIsDropEnabled | Qt.ItemIsDragEnabled)
                items[key] = item
            else:
                item.setFlags((item.flags() | Qt.ItemIsDragEnabled) & ~Qt.ItemIsDropEnabled)
            holder = items.get(parent)
            if holder is not None:
                holder.addChild(item)
            else:
                self.tree.addTopLevelItem(item)
            if (kind, key) == selected:
                chosen = item
        for key, item in items.items():
            item.setExpanded(key in expanded)
        if chosen is None and self.tree.topLevelItemCount():
            chosen = next((self.tree.topLevelItem(i) for i in range(self.tree.topLevelItemCount())
                           if self.tree.topLevelItem(i).data(0, Qt.UserRole)[0] == "project"),
                          self.tree.topLevelItem(0))
        if chosen is not None:
            parent = chosen.parent()
            while parent is not None:                        # the selection is never hidden in a closed folder
                parent.setExpanded(True)
                parent = parent.parent()
            self.tree.setCurrentItem(chosen)
        self.tree.blockSignals(False)
        has_rows = bool(nodes)
        self.tree.setVisible(has_rows)
        self.empty_label.setVisible(not has_rows)
        self.summary_panel.setVisible(has_rows)

    def expanded_folders(self) -> list[str]:
        found = []

        def walk(item):
            for i in range(item.childCount()):
                child = item.child(i)
                kind, key = child.data(0, Qt.UserRole)
                if kind == "folder":
                    if child.isExpanded():
                        found.append(key)
                    walk(child)
        walk(self.tree.invisibleRootItem())
        return found

    def selected_item(self) -> tuple | None:
        """(kind, id) of the selected row, or None."""
        items = self.tree.selectedItems()
        return tuple(items[0].data(0, Qt.UserRole)) if items else None

    def current_folder(self) -> str:
        """The folder new folders, projects and imports go into: the selected folder, or the folder of
        the selected project; '' (the top level) when nothing is selected."""
        items = self.tree.selectedItems()
        if not items:
            return TOP
        kind, key = items[0].data(0, Qt.UserRole)
        if kind == "folder":
            return key
        parent = items[0].parent()
        return parent.data(0, Qt.UserRole)[1] if parent is not None else TOP

    def set_trash_count(self, count: int) -> None:
        self.trash_button.setText(f"Trash ({count})" if count else "Trash")

    def show_summary(self, summary: dict | None, thumbnail: bytes | None, folder: bool = False) -> None:
        """summary: name, dates, progress (detected, review, waiting, total), progress_text, tiles [4 texts].
        folder: the summary is of a folder (its tiles count projects rather than variables)."""
        if summary is None:
            return
        for tile, caption in zip(self.tiles, FOLDER_TILES if folder else PROJECT_TILES):
            tile.set(tile.number.text(), caption)
        self.summary_name.setText(summary["name"])
        self.summary_dates.setText(summary["dates"])
        detected, review, waiting, total = summary["progress"]
        light = self.light
        self.summary_progress.set_parts([(detected - review, light.progress_done), (review, light.progress_review),
                                         (waiting, light.progress_waiting)], total)
        self.summary_progress_text.setText(summary["progress_text"])
        for tile, text in zip(self.tiles, summary["tiles"]):
            tile.set(text)
        pixmap = QPixmap()
        if thumbnail and pixmap.loadFromData(thumbnail):
            self.thumbnail.setPixmap(pixmap.scaled(QSize(302, 148), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            self.thumbnail.setPixmap(QPixmap())
            self.thumbnail.setText("Folder" if folder else "No photos yet")

    def selected_project(self) -> str | None:
        selected = self.selected_item()
        return selected[1] if selected and selected[0] == "project" else None

    def set_actions(self, has_selection: bool, can_create: bool, folder: bool = False) -> None:
        """has_selection: a project is selected; folder: a folder is selected."""
        for widget in (self.export_button, self.backups_button, self.open_button):
            widget.setEnabled(has_selection)
        self.delete_button.setEnabled(has_selection or folder)
        self.new_button.setEnabled(can_create)
        self.new_button.setToolTip("" if can_create else "The New Project wizard is not in the Python version yet")

    # ----- dialogs ----------------------------------------------------------
    def ask_import_path(self) -> str:
        path, _ = QFileDialog.getOpenFileName(self, "Import project", str(Path.home()),
                                              f"QuantaColony project (*{PROJECT_SUFFIX})")
        return path

    def ask_export_path(self, name: str) -> str:
        start = str(Path.home() / "Documents" / f"{name}{PROJECT_SUFFIX}")
        path, _ = QFileDialog.getSaveFileName(self, "Export a copy", start, f"QuantaColony project (*{PROJECT_SUFFIX})")
        return path

    def _light_dialog(self, title: str, width: int) -> QDialog:
        """A dialog on the light palette. It is its own window, so it gets the page's colors itself
        (otherwise it would take the system's background under the page's dark text)."""
        dialog = QDialog(self)
        dialog.setObjectName("LightWindow")
        dialog.setAttribute(Qt.WA_StyledBackground, True)          # paint the page color from the style sheet
        palette = dialog.palette()                                  # and as the palette, for any style
        for role, color in ((QPalette.Window, self.light.page), (QPalette.WindowText, self.light.text),
                            (QPalette.Base, self.light.surface), (QPalette.Text, self.light.text)):
            palette.setColor(role, QColor(color))
        dialog.setPalette(palette)
        # Last, so it wins over the sheet's "every widget inside the page is transparent" rule, which also
        # reaches this dialog because it is a child of the page
        dialog.setStyleSheet(self.styleSheet() + f"\nQDialog#LightWindow {{ background: {self.light.page}; }}")
        dialog.setWindowTitle(title)
        dialog.setMinimumWidth(width)
        return dialog

    def ask_export_kind(self, name: str) -> str:
        """'file' (a .qcproj to share), 'folder' (a browsable copy) or '' when cancelled."""
        dialog = self._light_dialog(f"Export {name}", 540)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(22, 20, 22, 18)
        column.setSpacing(12)
        column.addWidget(light_label("What do you want to export?", "h2"))
        choice = {"kind": ""}
        for kind, title, text in (
                ("file", "Project file (.qcproj)",
                 "One file for someone who has QuantaColony. They import it, and it opens exactly as you left it."),
                ("folder", "Browsable folder",
                 "A folder anyone can look through without QuantaColony: photos, crops, crops with their colonies "
                 "drawn, colony tables and a summary page. A copy for reading; QuantaColony never reads it back.")):
            card = ChoiceCard(title, text)
            card.clicked.connect(lambda k=kind: (choice.update(kind=k), dialog.accept()))
            column.addWidget(card)
        column.addStretch(1)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = light_button("Cancel", None)
        cancel.clicked.connect(dialog.reject)
        buttons.addWidget(cancel)
        column.addLayout(buttons)
        dialog.adjustSize()
        return choice["kind"] if dialog.exec() == QDialog.Accepted else ""

    def ask_folder(self, title: str, start: str) -> str:
        return QFileDialog.getExistingDirectory(self, title, start)

    def choose_backup(self, name: str, backups: list[tuple[str, str]]) -> int:
        """backups: (taken at, size). Returns the chosen row, or -1."""
        dialog = self._light_dialog(f"Backups of {name}", 460)
        dialog.resize(460, 360)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(20, 18, 20, 18)
        column.setSpacing(12)
        column.addWidget(light_label("QuantaColony keeps the five latest snapshots, taken when a project closes "
                                     "after a change. Restoring one keeps the current state as a new backup.",
                                     "body", wrap=True))
        choices = QListWidget()
        for taken, size in backups:
            QListWidgetItem(f"{taken}    {size}", choices)
        if backups:
            choices.setCurrentRow(0)
        column.addWidget(choices, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = light_button("Cancel", None)
        restore = light_button("Restore", "primary")
        restore.setEnabled(bool(backups))
        row.addWidget(cancel)
        row.addWidget(restore)
        column.addLayout(row)
        cancel.clicked.connect(dialog.reject)
        restore.clicked.connect(dialog.accept)
        choices.itemDoubleClicked.connect(lambda _item: dialog.accept())
        return choices.currentRow() if dialog.exec() == QDialog.Accepted else -1

    def ask_text(self, title: str, prompt: str, initial: str = "") -> str | None:
        """A line of text (a folder name), or None when cancelled."""
        dialog = self._light_dialog(title, 420)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(22, 20, 22, 18)
        column.setSpacing(10)
        column.addWidget(light_label(prompt, "body"))
        field = QLineEdit(initial)
        field.selectAll()
        column.addWidget(field)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = light_button("Cancel", None)
        ok = light_button("OK", "primary")
        ok.setDefault(True)
        row.addWidget(cancel)
        row.addWidget(ok)
        column.addLayout(row)
        cancel.clicked.connect(dialog.reject)
        ok.clicked.connect(dialog.accept)
        field.returnPressed.connect(dialog.accept)
        return field.text() if dialog.exec() == QDialog.Accepted else None

    def ask_destination(self, title: str, folders: list[tuple[str, int, str]]) -> str | None:
        """folders: (folder id, depth, name) in tree order. Returns a folder id, '' for the top level,
        or None when cancelled."""
        dialog = self._light_dialog(title, 420)
        dialog.resize(420, 420)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(20, 18, 20, 18)
        column.setSpacing(10)
        column.addWidget(light_label("Move into:", "body"))
        choices = QListWidget()
        top = QListWidgetItem("Projects (top level)", choices)
        top.setData(Qt.UserRole, TOP)
        for key, depth, name in folders:
            item = QListWidgetItem("      " * (depth + 1) + name, choices)
            item.setIcon(self._folder_icon)
            item.setData(Qt.UserRole, key)
        choices.setCurrentRow(0)
        column.addWidget(choices, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = light_button("Cancel", None)
        move = light_button("Move", "primary")
        row.addWidget(cancel)
        row.addWidget(move)
        column.addLayout(row)
        cancel.clicked.connect(dialog.reject)
        move.clicked.connect(dialog.accept)
        choices.itemDoubleClicked.connect(lambda _item: dialog.accept())
        if dialog.exec() != QDialog.Accepted or choices.currentItem() is None:
            return None
        return choices.currentItem().data(Qt.UserRole)

    def show_trash(self, rows: list[tuple[str, str, str]]) -> None:
        """The Trash: rows (item id, title, detail). Restore, Delete permanently and Empty Trash are
        reported as signals; the controller answers with set_trash_rows."""
        dialog = self._light_dialog("Trash", 560)
        dialog.resize(560, 420)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(20, 18, 20, 18)
        column.setSpacing(10)
        column.addWidget(light_label("Deleted projects and folders stay here until you delete them permanently. "
                                     "Restoring puts them back where they were.", "body", wrap=True))
        self._trash_list = QListWidget()
        column.addWidget(self._trash_list, 1)
        row = QHBoxLayout()
        self._empty_trash = light_button("Empty Trash…", "quiet")
        row.addWidget(self._empty_trash)
        row.addStretch(1)
        self._purge = light_button("Delete permanently…", None)
        self._restore = light_button("Restore", "primary")
        close = light_button("Close", None)
        for widget in (self._purge, self._restore, close):
            row.addWidget(widget)
        column.addLayout(row)

        def chosen() -> str:
            item = self._trash_list.currentItem()
            return item.data(Qt.UserRole) if item is not None else ""

        self._restore.clicked.connect(lambda: chosen() and self.restoreTrashRequested.emit(chosen()))
        self._purge.clicked.connect(lambda: chosen() and self.purgeTrashRequested.emit(chosen()))
        self._empty_trash.clicked.connect(self.emptyTrashRequested.emit)
        self._trash_list.itemDoubleClicked.connect(lambda _item: self.restoreTrashRequested.emit(chosen()))
        close.clicked.connect(dialog.accept)
        self._trash_dialog = dialog
        self.set_trash_rows(rows)
        dialog.exec()
        self._trash_dialog = None

    def set_trash_rows(self, rows: list[tuple[str, str, str]]) -> None:
        if self._trash_dialog is None:
            return
        self._trash_list.clear()
        for key, title, detail in rows:
            item = QListWidgetItem(f"{title}\n{detail}", self._trash_list)
            item.setData(Qt.UserRole, key)
            item.setSizeHint(QSize(0, 46))
        if rows:
            self._trash_list.setCurrentRow(0)
        if not rows:
            QListWidgetItem("The Trash is empty.", self._trash_list).setFlags(Qt.NoItemFlags)
        for widget in (self._restore, self._purge, self._empty_trash):
            widget.setEnabled(bool(rows))

    def confirm(self, title: str, text: str) -> bool:
        return confirm(self, title, text)

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)


class HomeController(QObject):
    openProject = Signal(str)
    newProject = Signal()
    startTutorial = Signal()

    def __init__(self, manager: DataManager, window: HomeWindow, can_create: bool = False):
        super().__init__()
        self.manager = manager
        self.window = window
        self.can_create = can_create
        self.entries = []
        self.folders = []                              # FolderEntry
        self.placement = {}                            # project id -> folder id
        window.openRequested.connect(self.open_selected)
        window.selectionChanged.connect(self._selection_changed)
        window.importRequested.connect(lambda: self.import_project())
        window.exportRequested.connect(lambda: self.export_selected())
        window.backupsRequested.connect(self.backups)
        window.moveRequested.connect(lambda: self.move_library())
        window.newRequested.connect(self.new_project)
        window.helpRequested.connect(lambda: show_help("projects", window))
        window.newFolderRequested.connect(lambda: self.new_folder())
        window.renameRequested.connect(lambda: self.rename_selected())
        window.moveToRequested.connect(lambda: self.move_selected())
        window.deleteRequested.connect(lambda: self.delete_selected())
        window.itemsDropped.connect(self.drop)
        window.expansionChanged.connect(self._remember_expanded)
        window.trashRequested.connect(self.show_trash)
        window.tutorialRequested.connect(self.add_tutorial)
        window.startTutorialRequested.connect(self.startTutorial.emit)
        window.restoreTrashRequested.connect(self.restore_trash)
        window.purgeTrashRequested.connect(lambda item_id: self.purge_trash(item_id))
        window.emptyTrashRequested.connect(lambda: self.empty_trash())
        self.refresh()

    # ----- the tree -----------------------------------------------------------------------
    def refresh(self, select: str | tuple | None = None) -> None:
        """Redraw the tree. select: a project id, or (kind, id); else the last project used."""
        self.entries = self.manager.list_projects()
        self.folders, self.placement = self.manager.folder_layout()
        self.window.set_library(str(self.manager.library_root))
        if select is None:
            select = self.window.selected_item() or self.manager.settings.last_project_id
        if isinstance(select, str):
            select = ("project", select)
        self.window.set_tree(self._nodes(), tuple(select) if select else None,
                             set(self.manager.settings.expanded_folders))
        self.window.set_trash_count(len(self.manager.list_trash()))
        self._selection_changed()

    def _children(self, parent: str) -> list:
        return [f for f in self.folders if f.parent == parent]

    def _subfolders(self, folder_id: str) -> list[str]:
        found, frontier = [], [folder_id]
        while frontier:
            frontier = [f.folder_id for f in self.folders if f.parent in frontier]
            found += frontier
        return found

    def _folder_entries(self, folder_id: str) -> list:
        inside = {folder_id, *self._subfolders(folder_id)}
        return [e for e in self.entries if self.placement.get(e.project_id, TOP) in inside]

    def _nodes(self) -> list[tuple]:
        """Folders (alphabetical) before projects (most recently changed first), at every level."""
        nodes = []

        def add(parent: str) -> None:
            for folder in self._children(parent):
                entries = self._folder_entries(folder.folder_id)
                progress = (sum(e.detected_count for e in entries), sum(e.review_count for e in entries),
                            sum(e.plate_count for e in entries))
                if entries:
                    nodes.append(("folder", folder.folder_id, parent, folder.name, progress,
                                  f"{sum(e.colony_count for e in entries):,}",
                                  describe_time(max(e.modified for e in entries)),
                                  describe_size(sum(e.size_bytes for e in entries))))
                else:
                    nodes.append(("folder", folder.folder_id, parent, folder.name, None, "", "empty", ""))
                add(folder.folder_id)
            for e in self.entries:
                if self.placement.get(e.project_id, TOP) == parent:
                    nodes.append(("project", e.project_id, parent, e.name,
                                  (e.detected_count, e.review_count, e.plate_count), f"{e.colony_count:,}",
                                  describe_time(e.modified), describe_size(e.size_bytes)))
        add(TOP)
        return nodes

    def _folder(self, folder_id: str):
        return next((f for f in self.folders if f.folder_id == folder_id), None)

    def _selection_changed(self) -> None:
        selected = self.window.selected_item()
        kind, key = selected if selected else (None, "")
        self.window.set_actions(kind == "project", self.can_create, folder=kind == "folder")
        if kind == "project":
            entry = self._entry(key)
            if entry is not None:
                self.window.show_summary(project_summary(entry), self.manager.project_thumbnail(entry.project_id))
        elif kind == "folder" and self._folder(key) is not None:
            self.window.show_summary(folder_summary(self._folder(key).name, self._folder_entries(key),
                                                    len(self._subfolders(key))), None, folder=True)

    def _remember_expanded(self) -> None:
        self.manager.settings.set_expanded_folders(self.window.expanded_folders())

    # ----- folders ------------------------------------------------------------------------
    def new_project(self) -> None:
        self.manager.new_project_folder = self.window.current_folder()
        self.newProject.emit()

    def new_folder(self, name: str | None = None) -> None:
        parent = self.window.current_folder()
        if name is None:
            where = f" inside {self._folder(parent).name}" if self._folder(parent) else ""
            name = self.window.ask_text("New folder", f"Name of the new folder{where}:", "New folder")
            if name is None:
                return
        try:
            folder_id = self.manager.create_folder(name, parent)
        except ProjectError as error:
            self.window.report("Could not create the folder", str(error), WARNING)
            return
        if parent:
            self.manager.settings.set_expanded_folders(self.manager.settings.expanded_folders + [parent])
        self.refresh(("folder", folder_id))

    def rename_selected(self, name: str | None = None) -> None:
        selected = self.window.selected_item()
        if not selected or selected[0] != "folder" or self._folder(selected[1]) is None:
            return
        folder = self._folder(selected[1])
        if name is None:
            name = self.window.ask_text("Rename folder", "New name:", folder.name)
            if name is None:
                return
        try:
            self.manager.rename_folder(folder.folder_id, name)
        except ProjectError as error:
            self.window.report("Could not rename the folder", str(error), WARNING)
            return
        self.refresh(("folder", folder.folder_id))

    def move_selected(self, destination: str | None = None) -> None:
        selected = self.window.selected_item()
        if not selected:
            return
        if destination is None:
            blocked = {selected[1], *self._subfolders(selected[1])} if selected[0] == "folder" else set()
            rows = []

            def add(parent: str, depth: int) -> None:
                for folder in self._children(parent):
                    if folder.folder_id not in blocked:
                        rows.append((folder.folder_id, depth, folder.name))
                        add(folder.folder_id, depth + 1)
            add(TOP, 0)
            destination = self.window.ask_destination("Move to", rows)
            if destination is None:
                return
        self.drop([selected], destination)

    def drop(self, moved: list, destination: str) -> None:
        """Move dragged projects and folders into a folder ('' is the top level)."""
        try:
            for kind, key in moved:
                if kind == "folder":
                    if key != destination:
                        self.manager.move_folder(key, destination)
                else:
                    self.manager.move_projects([key], destination)
        except ProjectError as error:
            self.window.report("Could not move", str(error), WARNING)
        if destination:
            self.manager.settings.set_expanded_folders(self.manager.settings.expanded_folders + [destination])
        self.refresh(tuple(moved[0]) if moved else None)

    def add_tutorial(self) -> None:
        """A fresh copy of the tutorial project, in the selected folder."""
        self.manager.new_project_folder = self.window.current_folder()
        try:
            project_id = self.manager.add_tutorial_project()
        except (ProjectError, OSError) as error:
            self.window.report("Could not add the tutorial project", str(error))
            return
        self.refresh(project_id)

    # ----- deleting and the Trash ---------------------------------------------------------
    def delete_selected(self, confirmed: bool = False) -> None:
        selected = self.window.selected_item()
        if not selected:
            return
        kind, key = selected
        if kind == "project":
            entry = self._entry(key)
            if entry is None:
                return
            text = f"Move {entry.name} to the Trash? You can restore it from the Trash until you delete it there."
            title = "Delete project"
        else:
            folder = self._folder(key)
            if folder is None:
                return
            entries, subfolders = self._folder_entries(key), len(self._subfolders(key))
            parts = [f"{len(entries)} project{'s' if len(entries) != 1 else ''}"]
            if subfolders:
                parts.insert(0, f"{subfolders} folder{'s' if subfolders != 1 else ''}")
            text = (f"Move the folder {folder.name} and everything in it ({' and '.join(parts)}) to the Trash? "
                    "You can restore it from the Trash until you delete it there.")
            title = "Delete folder"
        if not confirmed and not self.window.confirm(title, text):
            return
        try:
            if kind == "project":
                self.manager.delete_projects([key])
            else:
                self.manager.delete_folder(key)
        except ProjectError as error:
            self.window.report("Could not delete", str(error), WARNING)
        self.refresh(("folder", self.placement.get(key, TOP)) if kind == "project" and self.placement.get(key)
                     else None)

    def _trash_rows(self) -> list[tuple[str, str, str]]:
        rows = []
        for entry in self.manager.list_trash():
            projects = len(entry.project_ids)
            parts = ["Folder" if entry.kind == "folder" else "Project"]
            if entry.kind == "folder":
                if entry.folder_count > 1:
                    parts.append(f"{entry.folder_count - 1} folder{'s' if entry.folder_count != 2 else ''}")
                if projects:
                    parts.append(f"{projects} project{'s' if projects != 1 else ''}")
                elif entry.folder_count == 1:
                    parts.append("empty")
            if projects:
                parts.append(describe_size(self.manager.trash_size(entry)))
            detail = " · ".join(parts) + f" · deleted {describe_time(entry.deleted_at)}"
            rows.append((entry.item_id, entry.name, detail))
        return rows

    def show_trash(self) -> None:
        self.window.show_trash(self._trash_rows())
        self.refresh()

    def restore_trash(self, item_id: str) -> None:
        try:
            renamed = self.manager.restore_trash(item_id)
        except ProjectError as error:
            self.window.report("Could not restore", str(error), WARNING)
            renamed = {}
        self.window.set_trash_rows(self._trash_rows())
        if renamed:
            self.window.report("Restored with a new name", "Another project took the name meanwhile, so the "
                               "restored project is now called " + ", ".join(renamed.values()) + ".", WARNING)

    def purge_trash(self, item_id: str, confirmed: bool = False) -> None:
        entry = next((e for e in self.manager.list_trash() if e.item_id == item_id), None)
        if entry is None:
            return
        if not confirmed and not self.window.confirm(
                "Delete permanently", f"Delete {entry.name} permanently? This cannot be undone."):
            return
        try:
            self.manager.purge_trash(item_id)
        except (ProjectError, OSError) as error:
            self.window.report("Could not delete", str(error), WARNING)
        self.window.set_trash_rows(self._trash_rows())

    def empty_trash(self, confirmed: bool = False) -> None:
        count = len(self.manager.list_trash())
        if not count:
            return
        if not confirmed and not self.window.confirm(
                "Empty Trash", f"Delete everything in the Trash ({count} item{'s' if count != 1 else ''}) "
                               "permanently? This cannot be undone."):
            return
        try:
            self.manager.empty_trash()
        except (ProjectError, OSError) as error:
            self.window.report("Could not empty the Trash", str(error), WARNING)
        self.window.set_trash_rows(self._trash_rows())

    def _entry(self, project_id: str):
        return next((e for e in self.entries if e.project_id == project_id), None)

    def open_selected(self) -> None:
        project_id = self.window.selected_project()
        if project_id:
            self.openProject.emit(project_id)

    def import_project(self, path: str | None = None) -> None:
        path = path or self.window.ask_import_path()
        if not path:
            return
        self.manager.new_project_folder = self.window.current_folder()
        try:
            project_id = self.manager.import_project_file(Path(path))
        except (ProjectError, OSError) as error:
            self.window.report("Could not import", str(error))
            return
        self.refresh(project_id)

    def export_selected(self, path: str | None = None, kind: str | None = None) -> None:
        """Export the selected project as a project file to share or as a browsable folder."""
        entry = self._entry(self.window.selected_project() or "")
        if entry is None:
            return
        kind = kind or self.window.ask_export_kind(entry.name)
        if kind == "folder":
            self.export_browsable(entry, path)
        elif kind == "file":
            self.export_file(entry, path)

    def export_browsable(self, entry, folder: str | None = None) -> None:
        if folder is None:
            parent = self.window.ask_folder("Export a browsable copy into…", str(Path.home() / "Documents"))
            if not parent:
                return
            folder = str(Path(parent) / f"{safe_name(entry.name)} (browsable copy)")
        try:
            saved = self.manager.export_browsable_copy(entry.project_id, Path(folder))
        except ProjectError as error:
            self.window.report("Could not export", str(error))
            return
        except OSError as error:
            self.window.report("Could not export", export_problem(error, Path(folder)))
            return
        self.refresh(entry.project_id)
        self.window.report("Browsable copy saved", f"{entry.name} was saved to\n{saved}\n\nOpen index.html "
                                                   "in that folder to look through it. Changes there do not reach "
                                                   "the project.", SUCCESS)

    def export_file(self, entry, path: str | None = None) -> None:
        path = path or self.window.ask_export_path(entry.name)
        if not path:
            return
        try:
            saved = self.manager.export_project_file(entry.project_id, Path(path))
        except ProjectError as error:
            self.window.report("Could not export", str(error))
            return
        except OSError as error:
            self.window.report("Could not export", export_problem(error, Path(path).parent))
            return
        self.window.report("Copy saved", f"{entry.name} was saved to\n{saved}\n\nThe copy can be imported on "
                                         "another computer. Changes to it do not affect this library.", SUCCESS)

    def backups(self) -> None:
        entry = self._entry(self.window.selected_project() or "")
        if entry is None:
            return
        backups = self.manager.list_backups(entry.project_id)
        choice = self.window.choose_backup(entry.name, [(describe_time(b.taken_at), describe_size(b.size_bytes))
                                                        for b in backups])
        if choice < 0:
            return
        try:
            self.manager.restore_backup(entry.project_id, backups[choice].path)
        except (ProjectError, OSError) as error:
            self.window.report("Could not restore", str(error))
            return
        self.refresh(entry.project_id)

    def move_library(self, folder: str | None = None) -> None:
        folder = folder or self.window.ask_folder("Move the library into…", str(self.manager.library_root.parent))
        if not folder:
            return
        destination = Path(folder)
        if destination.exists() and any(destination.iterdir()):
            destination = destination / "QuantaColony Library"      # a folder with other files gets a subfolder
        check = check_location(destination)
        if not check.ok:
            self.window.report("This folder cannot hold the library", check.problem, WARNING)
            return
        if check.warning and not self.window.confirm("Move the library?", check.warning + "\n\nMove it anyway?"):
            return
        try:
            moved = self.manager.move_library(destination)
        except (LibraryError, ProjectError, OSError) as error:
            self.window.report("Could not move the library", str(error))
            return
        self.refresh()
        if moved.leftover is not None:
            self.window.report("Library moved", f"The library is now in {moved.library.root}.\n\nPart of the old "
                                                f"folder could not be removed, probably because a file in it is open "
                                                f"in another program. It is no longer a library and can be deleted: "
                                                f"{moved.leftover}", WARNING)
