"""Home page: every project in the library with its progress, a summary of the selected project,
and open, import, export (project file or browsable folder), backups and library move.

HomeWindow is the view; HomeController talks to the DataManager. Opening a
project is handed to the navigator through the openProject signal.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPalette, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QFileDialog, QFrame, QHBoxLayout, QHeaderView, QLabel, QListWidget,
                               QListWidgetItem, QMainWindow, QStyledItemDelegate, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from ..data import PROJECT_SUFFIX, DataManager, LibraryError, ProjectError, check_location
from ..data.exports import export_problem, safe_name
from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .help import show_help
from .light import ProgressBar, light_button, light_header, light_label, paint_progress, panel_head, tile_grid
from .dialogs import ERROR, SUCCESS, WARNING, confirm, notify


def describe_size(size: int) -> str:
    for unit in ("bytes", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "bytes" else f"{size:.1f} {unit}"
        size /= 1024
    return ""


def describe_time(moment: datetime) -> str:
    return moment.astimezone().strftime("%b %d, %Y  %H:%M")


def project_summary(entry) -> dict:
    """What the summary panel shows for a project in the list."""
    waiting = max(entry.cropped_count - entry.detected_count, 0)
    text = f"{entry.detected_count} of {entry.index_count} indices detected"
    if entry.review_count:
        text += f" · {entry.review_count} to review"
    if waiting:
        text += f" · {waiting} cropped, waiting for detection"
    dates = f"Changed {describe_time(entry.modified)}"
    if entry.created is not None:
        dates = f"Created {entry.created.astimezone().strftime('%b %d, %Y')} · " + dates
    return {"name": entry.name, "dates": dates,
            "progress": (entry.detected_count, entry.review_count, waiting, entry.index_count),
            "progress_text": text,
            "tiles": [str(entry.photo_count), str(entry.variable_count),
                      f"{entry.cropped_count} of {entry.index_count}", f"{entry.colony_count:,}"]}


class ProgressDelegate(QStyledItemDelegate):
    """Progress column: detected, flagged for review, and the rest, with 'n of m' beside the bar."""

    def __init__(self, light, parent=None):
        super().__init__(parent)
        self.light = light

    def paint(self, painter, option, index) -> None:
        super().paint(painter, option, index)                 # selection background
        data = index.data(Qt.UserRole + 1)
        if not data:
            return
        detected, review, total = data
        rect = option.rect.adjusted(10, 0, -10, 0)
        text = f"{detected} of {total}" if total else "no indices"
        painter.save()
        painter.setPen(QColor(self.light.text_secondary))
        metrics = option.fontMetrics
        text_width = metrics.horizontalAdvance("0000 of 0000")
        painter.drawText(QRectF(rect.right() - text_width, rect.top(), text_width, rect.height()),
                         Qt.AlignVCenter | Qt.AlignRight, text)
        painter.restore()
        bar = QRectF(rect.left(), rect.center().y() - 3, max(rect.width() - text_width - 12, 20), 7)
        paint_progress(painter, bar, [(detected - review, self.light.progress_done),
                                      (review, self.light.progress_review)], total, self.light.progress_track)


class ChoiceCard(QFrame):
    """A clickable card: a title and a description that wraps; it grows to fit its text."""

    clicked = Signal()

    def __init__(self, title: str, text: str):
        super().__init__(objectName="ChoiceCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAccessibleName(title)
        column = QVBoxLayout(self)
        column.setContentsMargins(16, 12, 16, 12)
        column.setSpacing(4)
        column.addWidget(light_label(title, "field"))
        column.addWidget(light_label(text, "small", wrap=True))

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.clicked.emit()
        else:
            super().keyPressEvent(event)


class HomeWindow(QMainWindow):
    """The home page's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    openRequested = Signal()                  # Open button or a double-click
    selectionChanged = Signal()
    importRequested = Signal()
    exportRequested = Signal()
    backupsRequested = Signal()
    moveRequested = Signal()
    newRequested = Signal()
    helpRequested = Signal()

    def __init__(self, theme: Theme):
        super().__init__()
        self.setObjectName("LightWindow")
        self.setProperty("tone", "gray")
        self.light = light = theme.style.light
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family))
        self.setWindowTitle("QuantaColony · Projects")
        self.setWindowIcon(app_icon())
        self.resize(1240, 780)
        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        header, header_row = light_header(theme, ["Projects"])
        self.help_button = light_button("Help", "header")
        header_row.addWidget(self.help_button)
        column.addWidget(header)

        page = QVBoxLayout()
        page.setContentsMargins(36, 26, 36, 22)
        page.setSpacing(16)
        top = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(4)
        titles.addWidget(light_label("Projects", "h1"))
        self.library_label = light_label("", "small")
        titles.addWidget(self.library_label)
        top.addLayout(titles)
        top.addStretch(1)
        self.import_button = light_button("Import project…", None, "Copy a shared .qcproj file into the library")
        self.new_button = light_button("New project", "primary")
        top.addWidget(self.import_button)
        top.addWidget(self.new_button)
        page.addLayout(top)

        body = QHBoxLayout()
        body.setSpacing(20)
        list_column = QVBoxLayout()
        list_column.setSpacing(0)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Name", "Progress", "Colonies", "Last changed", "Size"])
        self.table.verticalHeader().hide()
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setFocusPolicy(Qt.StrongFocus)
        self.table.verticalHeader().setDefaultSectionSize(44)
        self.table.setItemDelegateForColumn(1, ProgressDelegate(light, self.table))
        header_view = self.table.horizontalHeader()
        header_view.setSectionResizeMode(0, QHeaderView.Stretch)
        for column_index, width in ((1, 230), (2, 90), (3, 170), (4, 100)):
            header_view.setSectionResizeMode(column_index, QHeaderView.Fixed)
            self.table.setColumnWidth(column_index, width)
        header_view.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        list_column.addWidget(self.table, 1)
        self.empty_label = light_label("No projects in this library yet. Create one, or import a shared .qcproj "
                                       "file.", "body", wrap=True)
        list_column.addWidget(self.empty_label)
        body.addLayout(list_column, 1)
        body.addWidget(self._build_summary_panel())
        page.addLayout(body, 1)

        footer = QHBoxLayout()
        self.legend = light_label("", "small")
        self.legend.setTextFormat(Qt.RichText)
        self.legend.setText(f"<span style='color:{light.progress_done}'>■</span> detected &nbsp; "
                            f"<span style='color:{light.progress_review}'>■</span> needs review &nbsp; "
                            f"<span style='color:{light.swatch_todo}'>■</span> still to do")
        footer.addWidget(self.legend)
        footer.addStretch(1)
        self.move_button = light_button("Move library…", "quiet", "Move the whole project library to another folder")
        footer.addWidget(self.move_button)
        page.addLayout(footer)
        column.addLayout(page, 1)
        self.setCentralWidget(root)
        for widget, signal in ((self.open_button, self.openRequested), (self.import_button, self.importRequested),
                               (self.export_button, self.exportRequested), (self.backups_button, self.backupsRequested),
                               (self.move_button, self.moveRequested), (self.new_button, self.newRequested),
                               (self.help_button, self.helpRequested)):
            widget.clicked.connect(signal.emit)
        self.table.itemDoubleClicked.connect(lambda _item: self.openRequested.emit())
        self.table.itemSelectionChanged.connect(self.selectionChanged.emit)

    def _build_summary_panel(self) -> QFrame:
        panel = QFrame(objectName="LightPanel")
        panel.setFixedWidth(340)
        column = QVBoxLayout(panel)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        head, _ = panel_head("SELECTED PROJECT")
        column.addWidget(head)
        inner = QVBoxLayout()
        inner.setContentsMargins(18, 16, 18, 18)
        inner.setSpacing(12)
        self.thumbnail = QLabel(objectName="Thumbnail")
        self.thumbnail.setFixedHeight(150)
        self.thumbnail.setAlignment(Qt.AlignCenter)
        inner.addWidget(self.thumbnail)
        self.summary_name = light_label("", "h2", wrap=True)
        self.summary_dates = light_label("", "small", wrap=True)
        inner.addWidget(self.summary_name)
        inner.addWidget(self.summary_dates)
        self.summary_progress = ProgressBar(self.light.progress_track, height=10)
        inner.addWidget(self.summary_progress)
        self.summary_progress_text = light_label("", "small", wrap=True)
        inner.addWidget(self.summary_progress_text)
        grid, self.tiles = tile_grid(["photos", "variables", "indices cropped", "colonies counted"], 2)
        inner.addLayout(grid)
        inner.addStretch(1)
        self.open_button = light_button("Open project", "primary")
        inner.addWidget(self.open_button)
        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.export_button = light_button("Export…", None, "Save a copy of this project to share or look inside")
        self.backups_button = light_button("Backups…", None, "Restore an earlier state of this project")
        actions.addWidget(self.export_button, 1)
        actions.addWidget(self.backups_button, 1)
        inner.addLayout(actions)
        column.addLayout(inner, 1)
        self.summary_panel = panel
        return panel

    # ----- updates --------------------------------------------------------
    def set_library(self, path: str) -> None:
        self.library_label.setText(f"Library: {path}")

    def set_projects(self, rows: list[tuple], selected: str | None) -> None:
        """rows: (project id, name, (detected, review, total), colonies, changed, size)."""
        self.table.setRowCount(len(rows))
        chosen = 0
        for r, (project_id, name, progress, colonies, changed, size) in enumerate(rows):
            for c, text in enumerate((name, "", colonies, changed, size)):
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, project_id)
                if c == 0:
                    font = item.font()
                    font.setWeight(font.Weight.DemiBold)
                    item.setFont(font)
                if c == 1:
                    item.setData(Qt.UserRole + 1, progress)
                    detected, review, total = progress
                    item.setToolTip(f"{detected} of {total} indices detected"
                                    + (f", {review} to review" if review else ""))
                self.table.setItem(r, c, item)
            if project_id == selected:
                chosen = r
        self.table.setVisible(bool(rows))
        self.empty_label.setVisible(not rows)
        self.summary_panel.setVisible(bool(rows))
        if rows:
            self.table.selectRow(chosen)

    def show_summary(self, summary: dict | None, thumbnail: bytes | None) -> None:
        """summary: name, dates, progress (detected, review, waiting, total), progress_text, tiles [4 texts]."""
        if summary is None:
            return
        self.summary_name.setText(summary["name"])
        self.summary_dates.setText(summary["dates"])
        detected, review, waiting, total = summary["progress"]
        light = self.light
        self.summary_progress.set_parts([(detected - review, light.progress_done), (review, light.progress_review),
                                         (waiting, light.progress_waiting)], total)
        self.summary_progress_text.setText(summary["progress_text"])
        for tile, text in zip(self.tiles, summary["tiles"]):
            tile.set(text)
        pixmap = QPixmap()
        if thumbnail and pixmap.loadFromData(thumbnail):
            self.thumbnail.setPixmap(pixmap.scaled(QSize(302, 148), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            self.thumbnail.setPixmap(QPixmap())
            self.thumbnail.setText("No photos yet")

    def selected_project(self) -> str | None:
        items = self.table.selectedItems()
        return items[0].data(Qt.UserRole) if items else None

    def set_actions(self, has_selection: bool, can_create: bool) -> None:
        for widget in (self.export_button, self.backups_button, self.open_button):
            widget.setEnabled(has_selection)
        self.new_button.setEnabled(can_create)
        self.new_button.setToolTip("" if can_create else "The New Project wizard is not in the Python version yet")

    # ----- dialogs ----------------------------------------------------------
    def ask_import_path(self) -> str:
        path, _ = QFileDialog.getOpenFileName(self, "Import project", str(Path.home()),
                                              f"QuantaColony project (*{PROJECT_SUFFIX})")
        return path

    def ask_export_path(self, name: str) -> str:
        start = str(Path.home() / "Documents" / f"{name}{PROJECT_SUFFIX}")
        path, _ = QFileDialog.getSaveFileName(self, "Export a copy", start, f"QuantaColony project (*{PROJECT_SUFFIX})")
        return path

    def _light_dialog(self, title: str, width: int) -> QDialog:
        """A dialog on the light palette. It is its own window, so it gets the page's colors itself
        (otherwise it would take the system's background under the page's dark text)."""
        dialog = QDialog(self)
        dialog.setObjectName("LightWindow")
        dialog.setAttribute(Qt.WA_StyledBackground, True)          # paint the page color from the style sheet
        palette = dialog.palette()                                  # and as the palette, for any style
        for role, color in ((QPalette.Window, self.light.page), (QPalette.WindowText, self.light.text),
                            (QPalette.Base, self.light.surface), (QPalette.Text, self.light.text)):
            palette.setColor(role, QColor(color))
        dialog.setPalette(palette)
        # Last, so it wins over the sheet's "every widget inside the page is transparent" rule, which also
        # reaches this dialog because it is a child of the page
        dialog.setStyleSheet(self.styleSheet() + f"\nQDialog#LightWindow {{ background: {self.light.page}; }}")
        dialog.setWindowTitle(title)
        dialog.setMinimumWidth(width)
        return dialog

    def ask_export_kind(self, name: str) -> str:
        """'file' (a .qcproj to share), 'folder' (a browsable copy) or '' when cancelled."""
        dialog = self._light_dialog(f"Export {name}", 540)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(22, 20, 22, 18)
        column.setSpacing(12)
        column.addWidget(light_label("What do you want to export?", "h2"))
        choice = {"kind": ""}
        for kind, title, text in (
                ("file", "Project file (.qcproj)",
                 "One file for someone who has QuantaColony. They import it, and it opens exactly as you left it."),
                ("folder", "Browsable folder",
                 "A folder anyone can look through without QuantaColony: photos, crops, crops with their colonies "
                 "drawn, colony tables and a summary page. A copy for reading; QuantaColony never reads it back.")):
            card = ChoiceCard(title, text)
            card.clicked.connect(lambda k=kind: (choice.update(kind=k), dialog.accept()))
            column.addWidget(card)
        column.addStretch(1)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = light_button("Cancel", None)
        cancel.clicked.connect(dialog.reject)
        buttons.addWidget(cancel)
        column.addLayout(buttons)
        dialog.adjustSize()
        return choice["kind"] if dialog.exec() == QDialog.Accepted else ""

    def ask_folder(self, title: str, start: str) -> str:
        return QFileDialog.getExistingDirectory(self, title, start)

    def choose_backup(self, name: str, backups: list[tuple[str, str]]) -> int:
        """backups: (taken at, size). Returns the chosen row, or -1."""
        dialog = self._light_dialog(f"Backups of {name}", 460)
        dialog.resize(460, 360)
        column = QVBoxLayout(dialog)
        column.setContentsMargins(20, 18, 20, 18)
        column.setSpacing(12)
        column.addWidget(light_label("QuantaColony keeps the five latest snapshots, taken when a project closes "
                                     "after a change. Restoring one keeps the current state as a new backup.",
                                     "body", wrap=True))
        choices = QListWidget()
        for taken, size in backups:
            QListWidgetItem(f"{taken}    {size}", choices)
        if backups:
            choices.setCurrentRow(0)
        column.addWidget(choices, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = light_button("Cancel", None)
        restore = light_button("Restore", "primary")
        restore.setEnabled(bool(backups))
        row.addWidget(cancel)
        row.addWidget(restore)
        column.addLayout(row)
        cancel.clicked.connect(dialog.reject)
        restore.clicked.connect(dialog.accept)
        choices.itemDoubleClicked.connect(lambda _item: dialog.accept())
        return choices.currentRow() if dialog.exec() == QDialog.Accepted else -1

    def confirm(self, title: str, text: str) -> bool:
        return confirm(self, title, text)

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)


class HomeController(QObject):
    openProject = Signal(str)
    newProject = Signal()

    def __init__(self, manager: DataManager, window: HomeWindow, can_create: bool = False):
        super().__init__()
        self.manager = manager
        self.window = window
        self.can_create = can_create
        self.entries = []
        window.openRequested.connect(self.open_selected)
        window.selectionChanged.connect(self._selection_changed)
        window.importRequested.connect(lambda: self.import_project())
        window.exportRequested.connect(lambda: self.export_selected())
        window.backupsRequested.connect(self.backups)
        window.moveRequested.connect(lambda: self.move_library())
        window.newRequested.connect(self.newProject.emit)
        window.helpRequested.connect(lambda: show_help("projects", window))
        self.refresh()

    def refresh(self, select: str | None = None) -> None:
        self.entries = self.manager.list_projects()
        self.window.set_library(str(self.manager.library_root))
        select = select or self.manager.settings.last_project_id
        self.window.set_projects([(e.project_id, e.name, (e.detected_count, e.review_count, e.index_count),
                                   f"{e.colony_count:,}", describe_time(e.modified), describe_size(e.size_bytes))
                                  for e in self.entries], select)
        self._selection_changed()

    def _selection_changed(self) -> None:
        project_id = self.window.selected_project()
        self.window.set_actions(project_id is not None, self.can_create)
        entry = self._entry(project_id or "")
        if entry is not None:
            self.window.show_summary(project_summary(entry), self.manager.project_thumbnail(entry.project_id))

    def _entry(self, project_id: str):
        return next((e for e in self.entries if e.project_id == project_id), None)

    def open_selected(self) -> None:
        project_id = self.window.selected_project()
        if project_id:
            self.openProject.emit(project_id)

    def import_project(self, path: str | None = None) -> None:
        path = path or self.window.ask_import_path()
        if not path:
            return
        try:
            project_id = self.manager.import_project_file(Path(path))
        except (ProjectError, OSError) as error:
            self.window.report("Could not import", str(error))
            return
        self.refresh(project_id)

    def export_selected(self, path: str | None = None, kind: str | None = None) -> None:
        """Export the selected project as a project file to share or as a browsable folder."""
        entry = self._entry(self.window.selected_project() or "")
        if entry is None:
            return
        kind = kind or self.window.ask_export_kind(entry.name)
        if kind == "folder":
            self.export_browsable(entry, path)
        elif kind == "file":
            self.export_file(entry, path)

    def export_browsable(self, entry, folder: str | None = None) -> None:
        if folder is None:
            parent = self.window.ask_folder("Export a browsable copy into…", str(Path.home() / "Documents"))
            if not parent:
                return
            folder = str(Path(parent) / f"{safe_name(entry.name)} (browsable copy)")
        try:
            saved = self.manager.export_browsable_copy(entry.project_id, Path(folder))
        except ProjectError as error:
            self.window.report("Could not export", str(error))
            return
        except OSError as error:
            self.window.report("Could not export", export_problem(error, Path(folder)))
            return
        self.refresh(entry.project_id)
        self.window.report("Browsable copy saved", f"{entry.name} was saved to\n{saved}\n\nOpen index.html "
                                                   "in that folder to look through it. Changes there do not reach "
                                                   "the project.", SUCCESS)

    def export_file(self, entry, path: str | None = None) -> None:
        path = path or self.window.ask_export_path(entry.name)
        if not path:
            return
        try:
            saved = self.manager.export_project_file(entry.project_id, Path(path))
        except ProjectError as error:
            self.window.report("Could not export", str(error))
            return
        except OSError as error:
            self.window.report("Could not export", export_problem(error, Path(path).parent))
            return
        self.window.report("Copy saved", f"{entry.name} was saved to\n{saved}\n\nThe copy can be imported on "
                                         "another computer. Changes to it do not affect this library.", SUCCESS)

    def backups(self) -> None:
        entry = self._entry(self.window.selected_project() or "")
        if entry is None:
            return
        backups = self.manager.list_backups(entry.project_id)
        choice = self.window.choose_backup(entry.name, [(describe_time(b.taken_at), describe_size(b.size_bytes))
                                                        for b in backups])
        if choice < 0:
            return
        try:
            self.manager.restore_backup(entry.project_id, backups[choice].path)
        except (ProjectError, OSError) as error:
            self.window.report("Could not restore", str(error))
            return
        self.refresh(entry.project_id)

    def move_library(self, folder: str | None = None) -> None:
        folder = folder or self.window.ask_folder("Move the library into…", str(self.manager.library_root.parent))
        if not folder:
            return
        destination = Path(folder)
        if destination.exists() and any(destination.iterdir()):
            destination = destination / "QuantaColony Library"      # a folder with other files gets a subfolder
        check = check_location(destination)
        if not check.ok:
            self.window.report("This folder cannot hold the library", check.problem, WARNING)
            return
        if check.warning and not self.window.confirm("Move the library?", check.warning + "\n\nMove it anyway?"):
            return
        try:
            self.manager.move_library(destination)
        except (LibraryError, ProjectError, OSError) as error:
            self.window.report("Could not move the library", str(error))
            return
        self.refresh()
