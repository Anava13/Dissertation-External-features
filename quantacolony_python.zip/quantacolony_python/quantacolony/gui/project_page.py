"""Project page (port of the MATLAB QuantaColony Hub): the project's variables and the state of each
step, with a button into each module. Counts come from DataManager.project_status, so a step
shows its progress again when photos or regions are added later.
"""

from __future__ import annotations

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import QFrame, QGridLayout, QHBoxLayout, QMainWindow, QVBoxLayout, QWidget

from ..data import DataManager
from ..data.packets import ProjectStatus
from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .help import show_help
from .light import (ProgressBar, clear_layout, light_button, light_header, light_label, panel_head, set_state,
                    tile_grid)

STEPS = (("cropping", "Cropping", "Draw each plate's sections and give every section its levels."),
         ("detection", "Colony Detection", "Detect and correct the colonies of each index."),
         ("stats", "Stats", "Density plots, statistics across ordinal levels, measurement fidelity and "
                            "subpopulations."))


def step_states(status: ProjectStatus) -> dict[str, tuple[str, str, bool]]:
    """Per step: (state 'done' / 'warn' / 'idle', status text, can open)."""
    missing = status.indices - status.indices_with_region
    cropping = (("done" if status.photos and status.photos_cropped == status.photos and not missing else
                 "warn" if status.photos_cropped else "idle"),
                f"{status.photos_cropped} of {status.photos} photos cropped" +
                (f" · {missing} indices without a region" if missing and status.photos_cropped else ""),
                status.photos > 0)
    if not status.indices_with_region:
        detection = ("idle", "Waiting for Cropping", False)
    else:
        text = f"{status.indices_detected} of {status.indices_with_region} indices detected"
        if status.indices_to_review:
            text += f" · {status.indices_to_review} to review"
        complete = status.indices_detected == status.indices_with_region and not status.indices_to_review
        detection = ("done" if complete else "warn" if status.indices_detected else "idle", text, True)
    stats = (("done", f"Ready · {status.indices_detected} indices with colonies", True) if status.indices_detected
             else ("idle", "Waiting for Colony Detection", False))
    return {"cropping": cropping, "detection": detection, "stats": stats}


TILE_CAPTIONS = ("photos", "indices cropped", "indices detected", "to review", "colonies counted")


def summary_numbers(status: ProjectStatus) -> list[str]:
    return [str(status.photos), f"{status.indices_with_region} of {status.indices}",
            f"{status.indices_detected} of {status.indices}", str(status.indices_to_review), f"{status.colonies:,}"]


def step_progress(status: ProjectStatus) -> dict[str, tuple[list[tuple[int, str]], int]]:
    """Bars of the workflow steps: Cropping over photos, Detection and Stats over indices."""
    detected = status.indices_detected - status.indices_to_review
    return {"cropping": ([(status.photos_cropped, "done")], status.photos),
            "detection": ([(detected, "done"), (status.indices_to_review, "review"),
                           (status.indices_waiting, "waiting")], status.indices),
            "stats": ([(status.indices_detected, "done")], status.indices)}


def next_step(status: ProjectStatus) -> str:
    states = step_states(status)
    if not status.photos:
        return "This project has no photos yet."
    if states["cropping"][0] != "done":
        return "Next step: Cropping."
    if states["detection"][0] != "done":
        return "Cropping is finished. Next step: Colony Detection."
    return "Colony Detection is finished. Every index is ready for Stats."


class ProjectWindow(QMainWindow):
    """The project page's view. Controllers use only its signals and its set_ methods."""

    moduleRequested = Signal(str)             # 'cropping', 'detection', 'stats'
    projectsRequested = Signal()
    helpRequested = Signal()

    def __init__(self, theme: Theme, project_name: str):
        super().__init__()
        self.setObjectName("LightWindow")
        self.setProperty("tone", "gray")
        self.light = theme.style.light
        self.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family))
        self.setWindowTitle(f"QuantaColony · {project_name}")
        self.setWindowIcon(app_icon())
        self.resize(1180, 760)
        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        header, header_row = light_header(theme, ["Projects", project_name])
        self.help_button = light_button("Help", "header")
        header_row.addWidget(self.help_button)
        self.projects_button = light_button("All projects", "header")
        header_row.addWidget(self.projects_button)
        self.help_button.clicked.connect(self.helpRequested.emit)
        self.projects_button.clicked.connect(self.projectsRequested.emit)
        column.addWidget(header)

        page = QVBoxLayout()
        page.setContentsMargins(40, 28, 40, 28)
        page.setSpacing(18)
        titles = QVBoxLayout()
        titles.setSpacing(4)
        self.title = light_label(project_name, "h1")
        self.summary = light_label("", "small")
        titles.addWidget(self.title)
        titles.addWidget(self.summary)
        page.addLayout(titles)
        tiles, self.tiles = tile_grid(list(TILE_CAPTIONS), len(TILE_CAPTIONS))
        for tile in self.tiles:
            tile.setProperty("on", "page")              # white tiles on the gray page
        page.addLayout(tiles)

        body = QHBoxLayout()
        body.setSpacing(24)
        steps = QFrame(objectName="LightPanel")
        steps_column = QVBoxLayout(steps)
        steps_column.setContentsMargins(0, 0, 0, 0)
        steps_column.setSpacing(0)
        steps_column.addWidget(panel_head("WORKFLOW")[0])
        self.step_widgets = {}
        self.step_bars: dict[str, ProgressBar] = {}
        for number, (key, name, text) in enumerate(STEPS, start=1):
            row = QFrame(objectName="StepRow")
            grid = QGridLayout(row)
            grid.setContentsMargins(20, 14, 20, 14)
            grid.setHorizontalSpacing(16)
            grid.setVerticalSpacing(2)
            badge = light_label(str(number), "h2")
            badge.setFixedWidth(22)
            grid.addWidget(badge, 0, 0, 2, 1, Qt.AlignTop)
            grid.addWidget(light_label(name, "h2"), 0, 1)
            grid.addWidget(light_label(text, "small", wrap=True), 1, 1)
            state = light_label("", None)
            grid.addWidget(state, 2, 1)
            bar = ProgressBar(self.light.progress_track, height=8)
            grid.addWidget(bar, 3, 1)
            grid.setRowMinimumHeight(3, 14)
            button = light_button(f"Open {name}", None)
            button.setMinimumWidth(220)
            grid.addWidget(button, 0, 2, 4, 1, Qt.AlignVCenter)
            grid.setColumnStretch(1, 1)
            steps_column.addWidget(row)
            self.step_widgets[key] = (state, button)
            self.step_bars[key] = bar
            button.clicked.connect(lambda _c=False, k=key: self.moduleRequested.emit(k))
        self.next_label = light_label("", "body", wrap=True)
        self.next_label.setContentsMargins(20, 12, 20, 14)
        steps_column.addWidget(self.next_label)
        steps_column.addStretch(1)
        body.addWidget(steps, 3)

        variables = QFrame(objectName="LightPanel")
        variables_column = QVBoxLayout(variables)
        variables_column.setContentsMargins(0, 0, 0, 0)
        variables_column.setSpacing(0)
        variables_column.addWidget(panel_head("VARIABLES")[0])
        self.variable_rows = QVBoxLayout()
        self.variable_rows.setContentsMargins(0, 0, 0, 0)
        self.variable_rows.setSpacing(0)
        variables_column.addLayout(self.variable_rows)
        variables_column.addStretch(1)
        body.addWidget(variables, 2)
        page.addLayout(body, 1)
        column.addLayout(page, 1)
        self.setCentralWidget(root)

    def set_summary(self, text: str) -> None:
        self.summary.setText(text)

    def set_steps(self, states: dict[str, tuple[str, str, bool]], next_text: str) -> None:
        """The first step that is open and not finished gets the primary button."""
        first = next((key for key, (state, _, enabled) in states.items() if enabled and state != "done"), None)
        for key, (state, text, enabled) in states.items():
            label, button = self.step_widgets[key]
            label.setText(("✓  " if state == "done" else "") + text)
            set_state(label, state)
            button.setEnabled(enabled)
            button.setProperty("variant", "primary" if key == first else None)
            button.style().unpolish(button)
            button.style().polish(button)
        self.next_label.setText(next_text)

    def set_numbers(self, numbers: list[str]) -> None:
        for tile, text in zip(self.tiles, numbers):
            tile.set(text)

    def set_progress(self, progress: dict[str, tuple[list[tuple[int, str]], int]]) -> None:
        """Per step: colored parts (count, color role) out of a total. Roles: done, review, waiting."""
        colors = {"done": self.light.progress_done, "review": self.light.progress_review,
                  "waiting": self.light.progress_waiting}
        for key, (parts, total) in progress.items():
            self.step_bars[key].set_parts([(count, colors[role]) for count, role in parts], total)

    def set_variables(self, rows: list[tuple[str, str, list[tuple[str, bool]]]]) -> None:
        """rows: (variable, kind, [(level, is control)]); control levels are marked."""
        clear_layout(self.variable_rows)
        for name, kind, levels in rows:
            row = QFrame(objectName="StepRow")
            column = QVBoxLayout(row)
            column.setContentsMargins(20, 10, 20, 12)
            column.setSpacing(3)
            title = QHBoxLayout()
            title.addWidget(light_label(name, "field"))
            title.addStretch(1)
            title.addWidget(light_label(kind, "small"))
            column.addLayout(title)
            text = ", ".join(f"<b style='color:{self.light.link}'>{level} (control)</b>" if control else level
                             for level, control in levels)
            column.addWidget(light_label(text, "small", wrap=True))
            self.variable_rows.addWidget(row)


class ProjectController(QObject):
    openModule = Signal(str)
    showProjects = Signal()

    def __init__(self, manager: DataManager, window: ProjectWindow):
        super().__init__()
        self.manager = manager
        self.data_manager = manager
        self.window = window
        window.moduleRequested.connect(self.openModule.emit)
        window.projectsRequested.connect(self.showProjects.emit)
        window.helpRequested.connect(lambda: show_help("projects", window))
        self.refresh()

    def refresh(self) -> None:
        info = self.manager.project_info()
        status = self.manager.project_status()
        self.status = status
        kinds = {"nominal": "Nominal", "ordinal": "Ordinal", "replicate": "Replicate"}
        rows = [(v.display_name, kinds.get(v.type, v.type.capitalize()),
                 [(lv.display, lv.is_control) for lv in v.levels]) for v in info.variables]
        self.window.set_variables(rows)
        self.window.set_summary(f"{len(info.variables)} variables · {status.indices} indices "
                                "(one per combination of levels)")
        self.window.set_steps(step_states(status), next_step(status))
        self.window.set_numbers(summary_numbers(status))
        self.window.set_progress(step_progress(status))
