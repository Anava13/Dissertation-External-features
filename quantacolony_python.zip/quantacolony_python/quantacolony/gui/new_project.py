"""New Project wizard (light palette): Photos, Plate, Variables, Scale, Review.

NewProjectWindow is the view, NewProjectController edits a core.new_project.ProjectDraft
and asks the DataManager to create the project at the end. Nothing is written before
"Create project".
"""

from __future__ import annotations

import math
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImageReader, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLayout, QLineEdit,
                               QListWidget, QListWidgetItem, QMainWindow, QPushButton, QScrollArea,
                               QStackedWidget, QVBoxLayout, QWidget)

from ..core import new_project as npm
from ..core.params import new_project_detection
from ..data import DataManager, ProjectError
from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from ..theme.tokens import get_quanta_colony_style
from .help import show_help
from .light import LightSegmented, clear_layout, light_button, light_header, light_label
from .dialogs import ERROR, WARNING, confirm, notify

HEADS = (("Plate photos", "Each photo is one plate. The project stores the original files, in the order set here."),
         ("Plate layout", "The plate shape and its sections give Cropping a starting grid for each photo."),
         ("Variables", "Define each experimental factor and its levels. Every combination of levels is one index; "
                       "a replicate variable sets how many interchangeable plates each index holds."),
         ("Scale", "With a known scale, colony sizes are reported in micrometers."),
         ("Review", "Creating the project writes one .qcproj file. Cropping opens next."))
L = get_quanta_colony_style().light
INK, MUTED, LIME, RULE = L.text, L.text_muted, L.accent, L.border


class PlatePreview(QWidget):
    """The plate drawn with its sections numbered (clockwise from the top for a dish)."""

    def __init__(self):
        super().__init__()
        self.setFixedSize(220, 220)
        self.plate, self.sections, self.rows, self.cols = "circular", 4, 2, 2

    def set_plate(self, plate: str, sections: int, rows: int, cols: int) -> None:
        self.plate, self.sections, self.rows, self.cols = plate, sections, rows, cols
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor(INK), 2)
        painter.setPen(pen)
        painter.setBrush(QColor(L.accent_soft))
        font = QFont(self.font())
        font.setPixelSize(15)
        font.setBold(True)
        painter.setFont(font)
        if self.plate == "circular":
            c, r = QPointF(110, 110), 96.0
            painter.drawEllipse(c, r, r)
            n = self.sections
            dashed = QPen(QColor(INK), 1.5, Qt.DashLine)
            painter.setPen(dashed)
            for k in range(n if n > 1 else 0):
                a = math.radians(-90 + k * 360 / n)
                painter.drawLine(c, QPointF(110 + r * math.cos(a), 110 + r * math.sin(a)))
            painter.setPen(QColor(INK))
            for k in range(n):
                a = math.radians(-90 + (k + 0.5) * 360 / n)
                d = 0 if n == 1 else 60
                painter.drawText(QRectF(110 + d * math.cos(a) - 15, 110 + d * math.sin(a) - 12, 30, 24),
                                 Qt.AlignCenter, str(k + 1))
        else:
            box = QRectF(10, 40, 200, 140)
            painter.drawRoundedRect(box, 6, 6)
            painter.setPen(QPen(QColor(INK), 1.5, Qt.DashLine))
            for col in range(1, self.cols):
                x = box.left() + col * box.width() / self.cols
                painter.drawLine(QPointF(x, box.top()), QPointF(x, box.bottom()))
            for row in range(1, self.rows):
                y = box.top() + row * box.height() / self.rows
                painter.drawLine(QPointF(box.left(), y), QPointF(box.right(), y))
            painter.setPen(QColor(INK))
            if self.rows * self.cols > 12:
                font.setPixelSize(11)
                painter.setFont(font)
            for k in range(self.rows * self.cols):
                row, col = divmod(k, self.cols)
                cell = QRectF(box.left() + col * box.width() / self.cols, box.top() + row * box.height() / self.rows,
                              box.width() / self.cols, box.height() / self.rows)
                painter.drawText(cell, Qt.AlignCenter, str(k + 1))
        painter.end()


class StepButton(QPushButton):
    """One step on the left rail: numbered dot, title and a one-line summary."""

    def __init__(self, number: int, title: str):
        super().__init__()
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(56)
        self.setStyleSheet("QPushButton { border: none; background: transparent; text-align: left; padding: 0;"
                           " min-height: 56px; max-height: 56px; }"
                           f" QPushButton:hover {{ background: {L.hover}; }}")
        row = QHBoxLayout(self)
        row.setContentsMargins(16, 6, 12, 6)
        row.setSpacing(12)
        self.dot = QLabel(str(number))
        self.dot.setFixedSize(28, 28)
        self.dot.setAlignment(Qt.AlignCenter)
        self.number = number
        column = QVBoxLayout()
        column.setSpacing(1)
        self.title = QLabel(title)
        self.sub = QLabel()
        column.addWidget(self.title)
        column.addWidget(self.sub)
        row.addWidget(self.dot)
        row.addLayout(column, 1)
        for child in (self.dot, self.title, self.sub):
            child.setAttribute(Qt.WA_TransparentForMouseEvents)

    def set_state(self, current: bool, done: bool, warn: bool, sub: str) -> None:
        style = (f"background: {L.danger_soft}; color: {L.danger_text}; border: 2px solid {L.danger_strong}" if warn else
                 f"background: {L.header}; color: {L.accent}; border: 2px solid {L.header}" if current else
                 f"background: {L.accent}; color: {L.accent_ink}; border: 2px solid {L.accent}" if done else
                 f"background: {L.page}; color: {L.text_muted}; border: 2px solid {L.border}")
        self.dot.setText("!" if warn else "✓" if done else str(self.number))
        self.dot.setStyleSheet(f"{style}; border-radius: 14px; font-size: 12px; font-weight: 700;")
        self.title.setStyleSheet(f"font-weight: {700 if current else 500}; color: {INK}; background: transparent;")
        self.sub.setText(sub)
        self.sub.setStyleSheet(f"font-size: 12px; color: {L.danger_text if warn else MUTED}; background: transparent;")


class NewProjectWindow(QMainWindow):
    """The New Project wizard's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    backRequested = Signal()
    nextRequested = Signal()
    cancelRequested = Signal()

    def __init__(self, theme: Theme):
        super().__init__()
        self.setObjectName("LightWindow")
        self.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family) + f"""
            #LightWindow QComboBox {{ background: {L.surface}; border: 1px solid {L.field_border}; border-radius: 4px;
                padding: 0 10px; min-height: 30px; color: {L.text}; }}
            #LightWindow QComboBox QAbstractItemView {{ background: {L.surface}; color: {L.text};
                selection-background-color: {L.accent_soft}; selection-color: {L.text}; }}
            #LightWindow QLineEdit[state="bad"] {{ border-color: {L.danger_strong}; }}
            #LightWindow QComboBox QLineEdit {{ border: none; background: transparent; min-height: 0; padding: 0; }}
            #LightWindow QFrame#VariableCard {{ background: {L.surface}; border: 1px solid {L.border}; border-radius: 6px; }}
            #LightWindow QFrame#VariableCard[state="bad"] {{ border-color: {L.danger_strong}; }}
            #LightWindow QPushButton[variant="link"] {{ background: transparent; border: none; color: {L.link};
                padding: 0; min-height: 0; text-decoration: underline; }}
            #LightWindow QPushButton[variant="small"] {{ min-height: 28px; padding: 0 10px; }}
            #LightWindow QPushButton[variant="control"] {{ min-height: 0; min-width: 18px; max-width: 18px;
                min-height: 18px; max-height: 18px; padding: 0; border-radius: 9px; border: 1.5px solid {L.toggle_edge}; }}
            #LightWindow QPushButton[variant="control"]:checked {{ border: 5px solid {L.header}; background: {L.accent}; }}
        """)
        self.setWindowTitle("QuantaColony · New project")
        self.setWindowIcon(app_icon())
        self.resize(1280, 820)

        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        header, header_row = light_header(theme, ["Projects", "New project"])
        self.guide_button = light_button("Guide", "header")
        self.cancel_button = light_button("Cancel", "header")
        header_row.addWidget(self.guide_button)
        header_row.addWidget(self.cancel_button)
        self.guide_button.clicked.connect(self.show_guide)
        self.cancel_button.clicked.connect(self.cancelRequested.emit)
        column.addWidget(header)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        rail = QFrame(objectName="LightSide")
        rail.setFixedWidth(250)
        rail_column = QVBoxLayout(rail)
        rail_column.setContentsMargins(0, 18, 0, 18)
        rail_column.setSpacing(2)
        self.step_buttons = [StepButton(i + 1, name) for i, name in enumerate(npm.STEPS)]
        for widget in self.step_buttons:
            rail_column.addWidget(widget)
        rail_column.addStretch(1)
        body.addWidget(rail)

        main = QVBoxLayout()
        main.setContentsMargins(36, 26, 36, 18)
        main.setSpacing(6)
        self.heading = light_label("", "h1")
        self.lede = light_label("", "body", wrap=True)
        main.addWidget(self.heading)
        main.addWidget(self.lede)
        main.addSpacing(10)
        self.pages = QStackedWidget()
        self.page_layouts = []
        for _ in npm.STEPS:
            scroller = QScrollArea()
            scroller.setWidgetResizable(True)
            scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            holder = QWidget()
            layout = QVBoxLayout(holder)
            layout.setSizeConstraint(QLayout.SetMinimumSize)        # the page scrolls, it never squeezes
            layout.setContentsMargins(0, 0, 8, 0)
            layout.setSpacing(14)
            scroller.setWidget(holder)
            self.pages.addWidget(scroller)
            self.page_layouts.append(layout)
        main.addWidget(self.pages, 1)
        footer = QHBoxLayout()
        footer.setSpacing(8)
        self.footer_note = light_label("", "small", wrap=True)
        footer.addWidget(self.footer_note, 1)
        self.back_button = light_button("Back", None)
        self.next_button = light_button("Continue", "primary")
        self.back_button.clicked.connect(self.backRequested.emit)
        self.next_button.clicked.connect(self.nextRequested.emit)
        footer.addWidget(self.back_button)
        footer.addWidget(self.next_button)
        main.addLayout(footer)
        body.addLayout(main, 1)

        summary = QFrame(objectName="LightSide")
        summary.setFixedWidth(270)
        summary.setStyleSheet(f"QFrame#LightSide {{ border-right: none; border-left: 1px solid {L.border}; }}")
        side = QVBoxLayout(summary)
        side.setContentsMargins(20, 22, 20, 20)
        side.setSpacing(8)
        side.addWidget(light_label("PROJECT", "section"))
        self.index_count = light_label("", "h1")
        self.index_formula = light_label("", "small", wrap=True)
        side.addWidget(self.index_count)
        side.addWidget(self.index_formula)
        self.summary_rows = QGridLayout()
        self.summary_rows.setHorizontalSpacing(10)
        self.summary_rows.setVerticalSpacing(4)
        side.addSpacing(6)
        side.addLayout(self.summary_rows)
        side.addSpacing(10)
        side.addWidget(light_label("BEFORE CREATING", "section"))
        self.check_rows = QVBoxLayout()
        self.check_rows.setSpacing(6)
        side.addLayout(self.check_rows)
        side.addStretch(1)
        body.addWidget(summary)
        column.addLayout(body, 1)
        self.setCentralWidget(root)

    # ----- frame -------------------------------------------------------------------
    def set_step(self, step: int, states: list[tuple[bool, bool, bool, str]]) -> None:
        self.pages.setCurrentIndex(step)
        self.heading.setText(HEADS[step][0])
        self.lede.setText(HEADS[step][1])
        for button, state in zip(self.step_buttons, states):
            button.set_state(*state)

    def set_footer(self, note: str, blocked: bool, last: bool, first: bool) -> None:
        self.footer_note.setText(note)
        self.footer_note.setStyleSheet(f"color: {L.danger_text if blocked else MUTED}; font-size: 13px;")
        self.next_button.setText("Create project" if last else "Continue")
        self.next_button.setEnabled(not blocked)
        self.back_button.setEnabled(not first)

    def set_summary(self, count: int, formula: str, rows: list[tuple[str, str]], checks: list[tuple[str, str]]) -> None:
        self.index_count.setText(f"{count} {'index' if count == 1 else 'indices'}")
        self.index_formula.setText(formula)
        clear_layout(self.summary_rows)
        for r, (key, value) in enumerate(rows):
            self.summary_rows.addWidget(light_label(key, "small"), r, 0)
            right = light_label(value, None)
            right.setAlignment(Qt.AlignRight)
            self.summary_rows.addWidget(right, r, 1)
        clear_layout(self.check_rows)
        colors = {"ok": LIME, "note": L.note, "bad": L.danger_strong}
        for state, text in checks:
            line = QHBoxLayout()
            line.setSpacing(8)
            dot = QLabel()
            dot.setFixedSize(8, 8)
            dot.setStyleSheet(f"background: {colors[state]}; border-radius: 1px;")
            line.addWidget(dot, 0, Qt.AlignTop | Qt.AlignHCenter)
            label = light_label(text, None, wrap=True)
            label.setStyleSheet(f"font-size: 13px; color: {L.danger_text if state == 'bad' else INK};")
            line.addWidget(label, 1)
            self.check_rows.addLayout(line)

    def page(self, step: int):
        return self.page_layouts[step]

    # ----- dialogs ------------------------------------------------------------------
    def ask_photos(self) -> list[str]:
        paths, _ = QFileDialog.getOpenFileNames(self, "Add plate photos", str(Path.home()),
                                                "Images (*.jpg *.jpeg *.png *.tif *.tiff *.bmp)")
        return paths

    def show_guide(self) -> None:
        show_help("new_project", self)

    def confirm(self, title: str, text: str) -> bool:
        return confirm(self, title, text)

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)


def _thumbnail(path: Path, size: int) -> QPixmap:
    reader = QImageReader(str(path))
    reader.setAutoTransform(True)
    original = reader.size()
    if original.isValid():
        reader.setScaledSize(original.scaled(QSize(size, size), Qt.KeepAspectRatio))
    image = reader.read()
    return QPixmap.fromImage(image) if not image.isNull() else QPixmap()


class NewProjectController(QObject):
    created = Signal(str)            # project id (the project is left open)
    cancelled = Signal()

    def __init__(self, manager: DataManager, window: NewProjectWindow, draft: npm.ProjectDraft | None = None):
        super().__init__()
        self.manager = manager
        self.data_manager = manager
        self.window = window
        self.draft = draft or npm.example_draft(e.name for e in manager.list_projects())
        self.step = 0
        self.selected_photo = 0
        self.level_edits: list[list[QLineEdit]] = []
        self.error_labels: list[QLabel] = []
        self.cards: list[QFrame] = []
        window.backRequested.connect(lambda: self.go(self.step - 1))
        window.nextRequested.connect(self.next)
        window.cancelRequested.connect(self.cancel)
        for i, button in enumerate(window.step_buttons):
            button.clicked.connect(lambda _c=False, i=i: self.go(i))
        self.go(0)

    # ----- navigation ---------------------------------------------------------------
    def go(self, step: int) -> None:
        if 0 <= step < len(npm.STEPS):
            self.step = step
            self.build_page()
            self.refresh()

    def next(self) -> None:
        if not self.draft.step_ok(self.step):
            return
        if self.step < len(npm.STEPS) - 1:
            self.go(self.step + 1)
        else:
            self.create()

    def cancel(self) -> None:
        if self.draft.photos and not self.window.confirm("Cancel the new project?",
                                                         "Nothing has been written. Close the wizard?"):
            return
        self.cancelled.emit()

    def refresh(self) -> None:
        """Rail, footer, summary and inline errors; the page itself stays as built (keeps focus while typing)."""
        d = self.draft
        subs = d.step_subtitles()
        states = []
        for i in range(len(npm.STEPS)):
            current, done = i == self.step, i < self.step
            states.append((current, done, not d.step_ok(i) and (done or current), subs[i]))
        self.window.set_step(self.step, states)
        blocked = not d.step_ok(self.step)
        last = self.step == len(npm.STEPS) - 1
        note = (d.block_text(self.step) if blocked else
                "The project file is written when you click Create project." if last
                else "Nothing is written until the last step.")
        self.window.set_footer(note, blocked, last, self.step == 0)
        rows = [("Photos", str(len(d.photos))), ("Sections each", str(d.section_count)),
                ("Plate sections", str(len(d.photos) * d.section_count))]
        rows += [(v.name or "Unnamed", f"{len(v.values)} {v.kind}") for v in d.variables]
        self.window.set_summary(d.index_count, d.index_formula(), rows, d.checks())
        if self.step == 0:
            self._name_state()
        if self.step == 2:
            self._variable_errors()

    def build_page(self) -> None:
        layout = self.window.page(self.step)
        clear_layout(layout)
        [self._photos_page, self._plate_page, self._variables_page, self._scale_page, self._review_page][self.step](
            layout)
        layout.addStretch(1)

    # ----- step 1: photos --------------------------------------------------------------
    def _photos_page(self, layout) -> None:
        d = self.draft
        layout.addWidget(light_label("Project name", "field"))
        self.name_edit = QLineEdit(d.name)
        self.name_edit.setPlaceholderText("For example Anbalagan2011")
        self.name_edit.setMaximumWidth(420)
        self.name_edit.textEdited.connect(self.set_name)
        layout.addWidget(self.name_edit)
        name_row = QHBoxLayout()
        self.name_note = light_label("", "small", wrap=True)
        self.suggest_button = light_button("", "link")
        self.suggest_button.clicked.connect(lambda: self.set_name(self.draft.suggested_name(), rebuild=True))
        name_row.addWidget(self.name_note)
        name_row.addWidget(self.suggest_button)
        name_row.addStretch(1)
        layout.addLayout(name_row)

        head = QHBoxLayout()
        head.addWidget(light_label("Plate photos", "field"))
        size = sum(p.stat().st_size for p in d.photos if p.exists()) / 1024 ** 2
        head.addWidget(light_label(f"{len(d.photos)} files · {size:.1f} MB", "small"))
        head.addStretch(1)
        sort_button = light_button("Sort by file number", "small")
        sort_button.setEnabled(len(d.photos) > 1)
        sort_button.clicked.connect(self.sort_photos)
        add_button = light_button("Add photos…", "small")
        add_button.clicked.connect(lambda: self.add_photos())
        head.addWidget(sort_button)
        head.addWidget(add_button)
        layout.addLayout(head)

        row = QHBoxLayout()
        row.setSpacing(16)
        self.photo_list = QListWidget()
        self.photo_list.setMinimumHeight(300)
        self.photo_list.setStyleSheet(f"QListWidget {{ background: {L.surface}; border: 1px solid {L.border};"
                                      " border-radius: 6px; } QListWidget::item { padding: 8px 10px; }")
        for i, path in enumerate(d.photos):
            QListWidgetItem(f"{i + 1:>3}   {path.name}", self.photo_list)
        if d.photos:
            self.photo_list.setCurrentRow(min(self.selected_photo, len(d.photos) - 1))
        self.photo_list.currentRowChanged.connect(self.select_photo)
        row.addWidget(self.photo_list, 1)
        side = QVBoxLayout()
        self.preview = QLabel()
        self.preview.setFixedSize(260, 260)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet(f"background: {L.header}; border-radius: 6px; color: {L.header_muted};")
        side.addWidget(self.preview)
        self.preview_text = light_label("", "small", wrap=True)
        side.addWidget(self.preview_text)
        moves = QHBoxLayout()
        for text, step in (("Move up", -1), ("Move down", 1)):
            button = light_button(text, "small")
            button.clicked.connect(lambda _c=False, s=step: self.move_photo(s))
            moves.addWidget(button)
        remove = light_button("Remove", "small")
        remove.clicked.connect(self.remove_photo)
        moves.addWidget(remove)
        side.addLayout(moves)
        side.addStretch(1)
        row.addLayout(side)
        layout.addLayout(row)
        self._show_preview()

    def set_name(self, text: str, rebuild: bool = False) -> None:
        self.draft.name = text
        if rebuild:
            self.name_edit.setText(text)
        self.refresh()

    def _name_state(self) -> None:
        problem = self.draft.name_problem()
        taken = bool(problem) and bool(self.draft.name.strip())
        self.name_edit.setProperty("state", "bad" if taken else "")
        self.name_edit.style().unpolish(self.name_edit)
        self.name_edit.style().polish(self.name_edit)
        self.name_note.setText(problem if taken else "Kept in your QuantaColony library. Export a copy from the "
                                                    "project list to share it.")
        self.name_note.setStyleSheet(f"color: {L.danger_text if taken else MUTED}; font-size: 13px;")
        self.suggest_button.setVisible(taken)
        self.suggest_button.setText(f"Use {self.draft.suggested_name()}")

    def add_photos(self, paths: list[str] | None = None) -> None:
        paths = paths if paths is not None else self.window.ask_photos()
        unreadable = [p for p in paths if QImageReader(str(p)).size().isEmpty()]
        self.draft.add_photos([p for p in paths if p not in unreadable])
        if unreadable:
            self.window.report("Some files were not added", "These files are not readable images:\n" +
                               "\n".join(Path(p).name for p in unreadable), WARNING)
        if not self.draft.name.strip() and self.draft.photos:
            self.draft.name = self.draft.photos[0].parent.name
        self.go(0)

    def sort_photos(self) -> None:
        self.draft.sort_photos()
        self.selected_photo = 0
        self.go(0)

    def select_photo(self, row: int) -> None:
        self.selected_photo = max(0, row)
        self._show_preview()

    def move_photo(self, step: int) -> None:
        self.selected_photo = self.draft.move_photo(self.selected_photo, step)
        self.go(0)

    def remove_photo(self) -> None:
        if self.draft.photos:
            del self.draft.photos[self.selected_photo]
            self.selected_photo = max(0, min(self.selected_photo, len(self.draft.photos) - 1))
            self.go(0)

    def _show_preview(self) -> None:
        if not self.draft.photos:
            self.preview.setPixmap(QPixmap())
            self.preview.setText("No photo")
            self.preview_text.setText("Add the plate photos of this project.")
            return
        path = self.draft.photos[self.selected_photo]
        self.preview.setPixmap(_thumbnail(path, 256))
        size = QImageReader(str(path)).size()
        megabytes = path.stat().st_size / 1024 ** 2 if path.exists() else 0
        self.preview_text.setText(f"{path.name}\nPosition {self.selected_photo + 1} · {size.width()} × "
                                  f"{size.height()} px · {megabytes:.1f} MB")

    # ----- step 2: plate ----------------------------------------------------------------
    def _plate_page(self, layout) -> None:
        d = self.draft
        row = QHBoxLayout()
        row.setSpacing(32)
        column = QVBoxLayout()
        column.setSpacing(10)
        column.addWidget(light_label("Plate type", "field"))
        shapes = [("Round dish", "circular"), ("Rectangular plate", "rectangular")]
        column.addWidget(LightSegmented([(text, d.plate == key, lambda k=key: self.set_plate(plate=k))
                                         for text, key in shapes], height=30), 0, Qt.AlignLeft)
        if d.plate == "circular":
            column.addWidget(light_label("Sections per dish", "field"))
            column.addWidget(LightSegmented([(str(n), d.sections == n, lambda n=n: self.set_plate(sections=n))
                                             for n in range(1, npm.MAX_SECTIONS + 1)], height=30), 0, Qt.AlignLeft)
            column.addWidget(light_label("Numbered clockwise from the top.", "small"))
        else:
            column.addWidget(light_label("Grid", "field"))
            grid = QHBoxLayout()
            for label, key in (("rows", "rows"), ("columns", "cols")):
                fewer = light_button("−", "small")
                more = light_button("+", "small")
                value = light_label(str(getattr(d, key)), "h2")
                value.setFixedWidth(26)
                value.setAlignment(Qt.AlignCenter)
                fewer.clicked.connect(lambda _c=False, k=key: self.set_plate(**{k: getattr(self.draft, k) - 1}))
                more.clicked.connect(lambda _c=False, k=key: self.set_plate(**{k: getattr(self.draft, k) + 1}))
                for widget in (fewer, value, more, light_label(label, "small")):
                    grid.addWidget(widget)
                grid.addSpacing(14)
            grid.addStretch(1)
            column.addLayout(grid)
        column.addWidget(light_label("Cropping starts every photo from this layout. Sections can still be added, "
                                     "removed and rotated there, photo by photo.", "small", wrap=True))
        column.addStretch(1)
        row.addLayout(column, 1)
        preview = PlatePreview()
        preview.set_plate(d.plate, d.sections, d.rows, d.cols)
        side = QVBoxLayout()
        side.addWidget(preview)
        side.addWidget(light_label(d.plate_text(), "small"), 0, Qt.AlignHCenter)
        side.addStretch(1)
        row.addLayout(side)
        layout.addLayout(row)

    def set_plate(self, **changes) -> None:
        for key, value in changes.items():
            if key in ("rows", "cols"):
                value = max(1, min(npm.MAX_SECTIONS, value))
            setattr(self.draft, key, value)
        self.go(1)

    # ----- step 3: variables -------------------------------------------------------------
    def _variables_page(self, layout) -> None:
        d = self.draft
        self.level_edits, self.error_labels, self.cards = [], [], []
        if d.single_image and not d.variables:
            layout.addWidget(light_label("This project has one photo with one section, so variables are optional. "
                                         "Without them, the image gets a single level named Default.", "body",
                                         wrap=True))
        layout.addWidget(light_label("Name each variable by typing, or pick a suggestion from its list to fill in "
                                     "example levels. Levels you have typed are never replaced.", "small", wrap=True))
        for vi, v in enumerate(d.variables):
            layout.addWidget(self._variable_card(vi, v))
        add = light_button("Add variable", None)
        add.clicked.connect(self.add_variable)
        layout.addWidget(add, 0, Qt.AlignLeft)
        layout.addWidget(light_label("Each combination of nominal and ordinal levels is one index. Indices are placed "
                                     "on plate regions in Cropping, where each region you draw gets its levels; with "
                                     "a replicate variable, regions with the same levels are plates of one index.",
                                     "small", wrap=True))

    def _variable_card(self, vi: int, v: npm.VariableDraft) -> QFrame:
        card = QFrame(objectName="VariableCard")
        column = QVBoxLayout(card)
        column.setContentsMargins(16, 12, 16, 14)
        column.setSpacing(10)
        top = QHBoxLayout()
        top.setSpacing(10)
        name = QComboBox()                              # one box: type a name, or pick a suggestion
        name.setEditable(True)
        name.setInsertPolicy(QComboBox.NoInsert)
        name.setCompleter(None)                         # no inline completion while typing a custom name
        for k, (shown, label) in enumerate(npm.name_suggestions(v.kind)):
            name.addItem(shown, label)
            name.setItemData(k, f"Fills in example levels: {npm.preset_example(v.kind, label)}", Qt.ToolTipRole)
        name.setCurrentIndex(-1)
        name.setEditText(v.name)
        name.lineEdit().setPlaceholderText("Variable name")
        name.setToolTip("Type the variable's name, or pick a suggestion to fill in example levels")
        name.setMinimumWidth(240)
        name.lineEdit().textEdited.connect(lambda text, i=vi: self.edit_variable(i, name=text))
        name.activated.connect(lambda index, i=vi, box=name: self.set_preset(i, box.itemData(index)))
        top.addWidget(name, 1)
        top.addWidget(LightSegmented([(npm.KIND_NAMES[k], v.kind == k, lambda k=k, i=vi: self.set_kind(i, k))
                                      for k in npm.KINDS], height=28))
        column.addLayout(top)

        count = QHBoxLayout()
        replicate = v.kind == "replicate"
        count.addWidget(light_label("Plates per index" if replicate else "Levels", "small"))
        fewer, more = light_button("−", "small"), light_button("+", "small")
        fewer.clicked.connect(lambda _c=False, i=vi: self.set_count(i, -1))
        more.clicked.connect(lambda _c=False, i=vi: self.set_count(i, 1))
        number = light_label(str(len(v.values)), "field")
        number.setFixedWidth(24)
        number.setAlignment(Qt.AlignCenter)
        for widget in (fewer, number, more):
            count.addWidget(widget)
        count.addSpacing(16)
        if v.preset == "Additive":
            additive = QLineEdit(v.additive)
            additive.setPlaceholderText("Additive, e.g. hydroxyurea")
            additive.textEdited.connect(lambda text, i=vi: self.edit_variable(i, additive=text))
            count.addWidget(additive)
        if v.kind == "ordinal":
            unit = QLineEdit(v.unit)
            unit.setPlaceholderText("Units")
            unit.setFixedWidth(110)
            unit.textEdited.connect(lambda text, i=vi: self.edit_variable(i, unit=text))
            count.addWidget(light_label("Units", "small"))
            count.addWidget(unit)
        count.addStretch(1)
        remove = light_button("Remove variable", "quiet")
        remove.clicked.connect(lambda _c=False, i=vi: self.remove_variable(i))
        count.addWidget(remove)
        column.addLayout(count)

        if replicate:                                   # plate numbers, not levels: nothing to name
            column.addWidget(light_label(
                "Replicate plates are interchangeable: they are not crossed with the other variables, so they "
                "never multiply the indices. Each index holds its plates, numbered 1, 2, ... as Cropping places "
                "them, and more can be added later. Stats always pools them, and One per index chooses among "
                "them.", "small", wrap=True))
            error = light_label("", None, wrap=True)
            error.setStyleSheet(f"color: {L.danger_text}; font-size: 13px;")
            column.addWidget(error)
            self.level_edits.append([])
            self.error_labels.append(error)
            self.cards.append(card)
            return card

        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)
        grid.addWidget(light_label("#", "section"), 0, 0)
        grid.addWidget(light_label("VALUE" if v.kind == "ordinal" else "LEVEL NAME", "section"), 0, 1)
        if v.kind != "replicate":
            grid.addWidget(light_label("CONTROL", "section"), 0, 2, Qt.AlignHCenter)
        edits = []
        for li, value in enumerate(v.values):
            grid.addWidget(light_label(str(li + 1), "small"), li + 1, 0)
            edit = QLineEdit(value)
            edit.setMinimumWidth(300)
            edit.setMaximumWidth(420)
            edit.setAccessibleName(f"{v.name or 'Variable'} level {li + 1}")
            edit.textEdited.connect(lambda text, i=vi, j=li: self.edit_level(i, j, text))
            grid.addWidget(edit, li + 1, 1)
            if v.kind != "replicate":
                control = QPushButton()
                control.setProperty("variant", "control")
                control.setCheckable(True)
                control.setChecked(v.control == li)
                control.setCursor(Qt.PointingHandCursor)
                control.setToolTip(f"Use level {li + 1} as the control")
                control.clicked.connect(lambda _c=False, i=vi, j=li: self.toggle_control(i, j))
                grid.addWidget(control, li + 1, 2, Qt.AlignHCenter)
            edits.append(edit)
        grid.setColumnStretch(3, 1)
        column.addLayout(grid)
        error = light_label("", None, wrap=True)
        error.setStyleSheet(f"color: {L.danger_text}; font-size: 13px;")
        column.addWidget(error)
        self.level_edits.append(edits)
        self.error_labels.append(error)
        self.cards.append(card)
        return card

    def _variable_errors(self) -> None:
        for vi in range(len(self.draft.variables)):
            if vi >= len(self.cards):
                break
            message = self.draft.variable_error(vi)
            self.error_labels[vi].setText(message)
            self.error_labels[vi].setVisible(bool(message))
            self.cards[vi].setProperty("state", "bad" if message else "")
            self.cards[vi].style().unpolish(self.cards[vi])
            self.cards[vi].style().polish(self.cards[vi])
            bad = self.draft.bad_levels(vi)
            for li, edit in enumerate(self.level_edits[vi]):
                edit.setProperty("state", "bad" if li in bad else "")
                edit.style().unpolish(edit)
                edit.style().polish(edit)

    def edit_variable(self, index: int, **changes) -> None:
        for key, value in changes.items():
            setattr(self.draft.variables[index], key, value)
        self.refresh()

    def edit_level(self, index: int, level: int, text: str) -> None:
        self.draft.variables[index].values[level] = text
        self.refresh()

    def set_kind(self, index: int, kind: str) -> None:
        v = self.draft.variables[index]
        if v.kind != kind:
            v.change_kind(kind)
            self.go(2)

    def set_preset(self, index: int, preset: str) -> None:
        """A suggestion picked in the name box: its name, unit and example levels (typed levels stay)."""
        if not preset:
            return
        self.draft.variables[index].apply_template(preset)
        self.go(2)

    def set_count(self, index: int, step: int) -> None:
        v = self.draft.variables[index]
        v.set_count(len(v.values) + step)
        self.go(2)

    def toggle_control(self, index: int, level: int) -> None:
        v = self.draft.variables[index]
        v.control = -1 if v.control == level else level
        self.go(2)

    def add_variable(self) -> None:
        number = len(self.draft.variables) + 1
        self.draft.variables.append(npm.VariableDraft(f"Variable {number}"))
        self.go(2)

    def remove_variable(self, index: int) -> None:
        del self.draft.variables[index]
        self.go(2)

    # ----- step 4: scale -----------------------------------------------------------------
    def _scale_page(self, layout) -> None:
        d = self.draft
        circular = d.plate == "circular"
        options = [("dish", "Dish size" if circular else "Plate size",
                    "Cropping finds the dish edge in each photo and converts its width to millimeters." if circular
                    else "The plate size is stored with the project for converting its length to millimeters."),
                   ("bar", "Scale bar in the photo", "A scale bar of known length is marked on each photo."),
                   ("none", "No scale", "Sizes stay in pixels.")]
        for key, title, text in options:
            button = QPushButton()
            button.setCheckable(True)
            button.setChecked(d.scale == key)
            button.setCursor(Qt.PointingHandCursor)
            button.setMinimumHeight(64)
            button.setStyleSheet(
                f"QPushButton {{ text-align: left; background: {L.surface}; border: 1px solid {L.border};"
                " border-radius: 6px; min-height: 64px; }"
                f" QPushButton:checked {{ border: 2px solid {L.accent}; background: {L.accent_soft}; }}")
            inner = QVBoxLayout(button)
            inner.setContentsMargins(16, 8, 16, 8)
            inner.setSpacing(2)
            for child in (light_label(title, "field"), light_label(text, "small", wrap=True)):
                child.setAttribute(Qt.WA_TransparentForMouseEvents)
                inner.addWidget(child)
            button.clicked.connect(lambda _c=False, k=key: self.set_scale(scale=k))
            layout.addWidget(button)
        if d.scale == "dish":
            row = QHBoxLayout()
            row.setSpacing(10)
            if circular:
                row.addWidget(light_label("Dish diameter", "field"))
                row.addWidget(LightSegmented([(label, d.dish_mm == value, lambda v=value: self.set_scale(dish_mm=v))
                                              for value, label in npm.DISH_SIZES], height=30))
                row.addWidget(light_label("or", "small"))
                other = QLineEdit(d.dish_mm if d.dish_mm not in dict(npm.DISH_SIZES) else "")
                other.setPlaceholderText("mm")
                other.setFixedWidth(90)
                other.textEdited.connect(lambda text: self.set_scale(rebuild=False, dish_mm=text.strip()))
                row.addWidget(other)
            else:
                row.addWidget(light_label("Plate size", "field"))
                for i in (0, 1):
                    edit = QLineEdit(d.plate_mm[i])
                    edit.setFixedWidth(90)
                    edit.textEdited.connect(lambda text, i=i: self.set_plate_size(i, text.strip()))
                    row.addWidget(edit)
                    if i == 0:
                        row.addWidget(light_label("×", "small"))
                row.addWidget(light_label("mm (length × width)", "small"))
            row.addStretch(1)
            layout.addLayout(row)
        note = ("A scale can be added later in Cropping." if d.scale == "none" else
                "The scale bar tool is not in the Python version yet; sizes stay in pixels until it is."
                if d.scale == "bar" else
                "Pixels per millimeter are measured in Cropping from the dish edge on each photo." if circular else
                "Rectangular plates keep pixel sizes until Cropping measures plate edges.")
        layout.addWidget(light_label(note, "small", wrap=True))

    def set_scale(self, rebuild: bool = True, **changes) -> None:
        for key, value in changes.items():
            setattr(self.draft, key, value)
        if rebuild:
            self.go(3)
        else:
            self.refresh()

    def set_plate_size(self, index: int, text: str) -> None:
        sizes = list(self.draft.plate_mm)
        sizes[index] = text
        self.draft.plate_mm = tuple(sizes)
        self.refresh()

    # ----- step 5: review -----------------------------------------------------------------
    def _review_page(self, layout) -> None:
        panel = QFrame(objectName="LightPanel")
        column = QVBoxLayout(panel)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        for title, step, text in self.draft.review_rows():
            row = QFrame(objectName="StepRow")
            line = QHBoxLayout(row)
            line.setContentsMargins(18, 12, 18, 12)
            name = light_label(title, "field")
            name.setFixedWidth(110)
            line.addWidget(name, 0, Qt.AlignTop)
            line.addWidget(light_label(text, "body", wrap=True), 1)
            edit = light_button("Edit", "link")
            edit.clicked.connect(lambda _c=False, s=step: self.go(s))
            line.addWidget(edit, 0, Qt.AlignTop)
            column.addWidget(row)
        layout.addWidget(panel)

    # ----- create ---------------------------------------------------------------------------
    def create(self) -> None:
        d = self.draft
        if not all(d.step_ok(i) for i in range(len(npm.STEPS))):
            first = next(i for i in range(len(npm.STEPS)) if not d.step_ok(i))
            self.go(first)
            return
        specs, plate, extra = d.specifications()
        try:
            self.manager.create_project(d.name.strip(), specs, new_project_detection(), plate=plate, extra=extra,
                                        estimate_settings=True)
            project_id = self.manager.project_id
            for path in d.photos:
                self.manager.add_photo(path, px_per_mm=1.0, file_name=path.name,
                                       scaling_method="dish" if d.scale == "dish" else "")
        except (ProjectError, OSError) as error:
            self.window.report("Could not create the project", str(error))
            return
        self.created.emit(project_id)
