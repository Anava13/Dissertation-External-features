"""Builders for each module: window plus controller on the open project of a DataManager."""

from __future__ import annotations

from ..data import DataManager, ProjectError


def open_detection(manager: DataManager, theme):
    """Colony Detection on the first index waiting for detection (or review)."""
    from .controller import ColonyDetectionController, session_from_packet
    from .main_window import ColonyDetectionWindow
    index_id = manager.first_index_for_detection()
    if index_id is None:
        raise ProjectError("This project has no images assigned to an index yet. Run Cropping first.")
    packet = manager.checkout_image(index_id)
    session = session_from_packet(packet)
    record = packet.record
    window = ColonyDetectionWindow(theme, record.nominal_display, record.ordinal_display)
    review = packet.saved.review_reason if packet.saved and packet.saved.needs_review else ""
    controller = ColonyDetectionController(session, window, manager, review_reason=review)
    return window, controller


def open_cropping(manager: DataManager, theme):
    from .cropping_controller import CroppingController
    from .cropping_window import CroppingWindow
    window = CroppingWindow(theme, manager.project_info().name)
    return window, CroppingController(manager, window)


def open_stats(manager: DataManager, theme):
    from .stats_controller import StatsController
    from .stats_window import StatsWindow
    window = StatsWindow(theme, manager.project_info().name)
    return window, StatsController(manager, window, theme)
