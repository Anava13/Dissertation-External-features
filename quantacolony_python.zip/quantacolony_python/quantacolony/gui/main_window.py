"""ColonyDetectionWindow: the Colony Detection screen (view).

Layout, top to bottom: top bar, then three columns (mode list and settings |
plate | summary and activity), then a status bar. Both side columns collapse:
the left one to a rail of mode icons, the right one fully. The window only
builds widgets and shows what the controller passes it; every user action
reaches the controller through Qt signals.

Side panels show only what applies right now: the controller reports the
interaction state (selection, drawn circles, region) and the window shows or
hides the matching controls.
"""

from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPointF, QSize, Qt, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (QButtonGroup, QFrame, QGridLayout, QHBoxLayout, QLabel, QMainWindow, QPushButton, QScrollArea, QStackedWidget, QVBoxLayout, QWidget)

from ..core.params import (CIRCULAR, DARK, IRREGULAR, LIGHT, PARAM_SPECS, THRESHOLD_MAX, THRESHOLD_MIN,
                           THRESHOLD_STEP, DetectionParams, level_from_threshold, threshold_from_level)
from ..theme import Theme
from ..theme.icons import app_icon, icon_pixmap, logo_pixmap
from .canvas import DetectCanvas
from .modes import AUTOMATIC, GROUP_TITLES, MANUAL, MODE_ORDER, MODES, ModeSpec
from .widgets import (ActivityFeed, Dot, Field, GestureRow, HintCard, LegendDot, ModeButton, ParameterRow,
                      ToggleSwitch, button, divider, label)
from .dialogs import ERROR, QUESTION, SUCCESS, notify, show_message

THRESHOLD_CAPTIONS = {DARK: "Pixels at or below this brightness (0 black, 1 white) count as colony.",
                      LIGHT: "Pixels at or above this brightness (0 black, 1 white) count as colony."}


class IndexPopup(QFrame):
    """Drops down from the image name: the index board with its view controls."""

    def __init__(self, colors, parent=None):
        super().__init__(parent, Qt.Popup)
        from .index_board import IndexBoard
        self.colors = c = colors
        self.setObjectName("IndexPopup")
        self.setStyleSheet(f"QFrame#IndexPopup {{ background: {c.panel}; border: 1px solid {c.track_off};"
                           " border-radius: 8px; }")
        self.setFixedWidth(560)
        column = QVBoxLayout(self)
        column.setContentsMargins(16, 14, 16, 14)
        column.setSpacing(10)
        head = QHBoxLayout()
        head.addWidget(label("Indices", "label"))
        head.addStretch(1)
        self.summary = label("", "caption")
        head.addWidget(self.summary)
        column.addLayout(head)
        self.view_rows = QVBoxLayout()
        self.view_rows.setSpacing(4)
        column.addLayout(self.view_rows)
        self.page_rows = QVBoxLayout()
        self.page_rows.setSpacing(4)
        column.addLayout(self.page_rows)
        self.board = IndexBoard(c)
        column.addWidget(self.board)
        legend = QHBoxLayout()
        legend.setSpacing(12)
        for text, swatch, border in (("Detected", c.accent, c.accent), ("Not detected yet", c.board_waiting_fill, c.accent),
                                     ("To review", c.board_review_fill, c.board_review_edge), ("No region", c.window, c.border)):
            chip = QLabel()
            chip.setFixedSize(12, 12)
            chip.setStyleSheet(f"background: {swatch}; border: 1px solid {border}; border-radius: 2px;")
            legend.addWidget(chip)
            legend.addWidget(label(text, "caption"))
        legend.addStretch(1)
        column.addLayout(legend)
        self.note = label("", "caption", wrap=True)
        column.addWidget(self.note)

    def set_content(self, summary: str, view_rows, page_rows, board, note: str) -> None:
        from .index_board import Segmented
        from .light import clear_layout
        self.summary.setText(summary)
        for target, rows in ((self.view_rows, view_rows), (self.page_rows, page_rows)):
            clear_layout(target)
            for name, options in rows:
                line = QHBoxLayout()
                line.addWidget(label(name, "caption"))
                line.addStretch(1)
                control = Segmented(options, self.colors, height=24, tooltip=name)
                control.setFixedWidth(260 if target is self.view_rows else 320)
                line.addWidget(control)
                target.addLayout(line)
        self.board.set_board(board)
        self.note.setText(note)
        self.adjustSize()


class ColonyDetectionWindow(QMainWindow):
    """Colony Detection's view. Controllers use only its signals and its set_/show_/ask_ methods, so the
    layout and widgets can change freely as long as these keep their names and meanings."""

    # ----- what the user asks for (the controller connects to these) -----------
    modeChosen = Signal(str)                   # mode key
    settingEdited = Signal(str, object)        # field name, value (level already carries the colony color)
    shapeChosen = Signal(str)                  # 'Irregular' / 'Circular'
    estimateRequested = Signal()
    deleteRequested = Signal()
    addRequested = Signal()
    clearRequested = Signal()                  # Esc and every Clear button
    contourToggled = Signal(bool)
    growthToggled = Signal(bool)
    undoRequested = Signal()
    redoRequested = Signal()
    finishRequested = Signal()
    helpRequested = Signal()
    previousRequested = Signal()
    nextRequested = Signal()
    boardRequested = Signal()
    indexChosen = Signal(int)                  # from the index board
    pointerMoved = Signal(float, float)        # image coordinates

    def __init__(self, theme: Theme, nominal_display: str, ordinal_display: str):
        super().__init__()
        self.theme = theme
        self.colors = theme.style.colors
        self.setWindowTitle("QuantaColony · Colony Detection")
        self.setWindowIcon(app_icon())
        self.resize(*theme.style.layout.window_size)
        self._spec: ModeSpec = MODES[MODE_ORDER[0]]
        self._state = {"selected": 0, "box": False, "pending": 0, "region": False, "candidates": None}
        self._animations: dict[str, QVariantAnimation] = {}
        self.left_collapsed = False
        self.right_collapsed = False

        root = QWidget(objectName="Root")
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        column.addWidget(self._build_top_bar(nominal_display, ordinal_display))
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        self.left_sidebar = self._build_left_sidebar()
        self.right_sidebar = self._build_right_sidebar()
        body.addWidget(self.left_sidebar)
        body.addWidget(self._build_canvas_area(), 1)
        body.addWidget(self.right_sidebar)
        column.addLayout(body, 1)
        column.addWidget(self._build_status_bar())

        # A scroll area lets the window shrink below the layout's size on small displays
        scroller = QScrollArea()
        scroller.setWidget(root)
        scroller.setWidgetResizable(True)
        scroller.setFrameShape(QFrame.NoFrame)
        self.setCentralWidget(scroller)
        root.setMinimumSize(1100, 700)

        self._status_timer = QTimer(self)
        self._status_timer.setSingleShot(True)
        self._status_timer.timeout.connect(lambda: self.status_text.setText("Ready"))
        self._wire_controls()

    # =====================================================================
    # construction
    # =====================================================================
    def _build_top_bar(self, nominal_display: str, ordinal_display: str) -> QFrame:
        c = self.colors
        bar = QFrame(objectName="TopBar")
        bar.setFixedHeight(self.theme.style.layout.top_bar_height)
        row = QHBoxLayout(bar)
        row.setContentsMargins(16, 0, 16, 0)
        row.setSpacing(16)

        brand = QHBoxLayout()
        brand.setSpacing(10)
        self.left_toggle = button(variant="ghost", icon="panel_left", colors=c, icon_color=c.text_muted,
                                  tooltip="Hide the mode panel ([)", fixed=(34, 34))
        brand.addWidget(self.left_toggle)
        brand.addSpacing(2)
        logo = QLabel()
        logo.setPixmap(logo_pixmap(30))
        logo.setAccessibleName("QuantaColony logo")
        brand.addWidget(logo)
        wordmark = QLabel()
        wordmark.setPixmap(self._wordmark_pixmap("QuantaColony"))
        wordmark.setAccessibleName("QuantaColony")
        brand.addWidget(wordmark)
        brand.addWidget(divider(vertical=True, length=20))
        brand.addWidget(label("Colony Detection", "muted"))
        row.addLayout(brand)
        row.addStretch(1)

        self.prev_button = button(variant="icon", icon="chevron_left", colors=c, icon_color=c.text_faint,
                                  icon_size=16, tooltip="Previous image", fixed=(32, 32))
        self.image_picker = QPushButton(objectName="ImagePicker")
        self.image_picker.setCursor(Qt.PointingHandCursor)
        self.image_picker.setFixedHeight(36)
        picker = QHBoxLayout(self.image_picker)
        picker.setContentsMargins(8, 0, 10, 0)
        picker.setSpacing(10)
        tile = QLabel()
        tile.setFixedSize(22, 22)
        tile.setAlignment(Qt.AlignCenter)
        tile.setStyleSheet(f"background: {c.raised}; border-radius: 6px;")
        tile.setPixmap(icon_pixmap("plate", c.text_muted, 14))
        picker.addWidget(tile)
        self.nominal_label = label(nominal_display)
        self.nominal_label.setStyleSheet("font-weight: 500;")
        picker.addWidget(self.nominal_label)
        self.ordinal_chip = label(ordinal_display, "chipNeutral")
        self.ordinal_chip.setFixedHeight(22)
        picker.addWidget(self.ordinal_chip)
        chevron = QLabel()
        chevron.setPixmap(icon_pixmap("chevron_down", c.text_faint, 16))
        picker.addWidget(chevron)
        for child in (tile, self.nominal_label, self.ordinal_chip, chevron):
            child.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.image_picker.setMinimumWidth(self.nominal_label.sizeHint().width()
                                          + self.ordinal_chip.sizeHint().width() + 90)
        self.image_picker.setAccessibleName(f"Image: {nominal_display}, {ordinal_display}")
        self.next_button = button(variant="icon", icon="chevron_right", colors=c, icon_color=c.text_faint,
                                  icon_size=16, tooltip="Next image", fixed=(32, 32))
        nav = QHBoxLayout()
        nav.setSpacing(6)
        for widget in (self.prev_button, self.image_picker, self.next_button):
            nav.addWidget(widget)
        row.addLayout(nav)
        row.addStretch(1)

        self.right_toggle = button(variant="ghost", icon="panel_right", colors=c, icon_color=c.text_muted,
                                   tooltip="Hide the summary panel (])", fixed=(34, 34))
        row.addWidget(self.right_toggle)
        history = QFrame(objectName="ButtonGroup")
        history.setFixedHeight(38)
        history_row = QHBoxLayout(history)
        history_row.setContentsMargins(3, 3, 3, 3)
        history_row.setSpacing(0)
        self.undo_button = button(variant="ghost", icon="undo", colors=c, tooltip="Undo (Ctrl+Z)", fixed=(34, 30))
        self.redo_button = button(variant="ghost", icon="redo", colors=c, tooltip="Redo (Ctrl+Y)", fixed=(34, 30))
        history_row.addWidget(self.undo_button)
        history_row.addWidget(self.redo_button)
        row.addWidget(history)
        self.help_button = button(variant="icon", icon="help", colors=c, icon_color=c.text_muted,
                                  icon_size=18, tooltip="Help", fixed=(38, 38))
        row.addWidget(self.help_button)
        self.finish_button = button("Finish image", "primary", icon="check", colors=c,
                                    icon_color=c.accent_ink, stroke=2.4)
        self.finish_button.setObjectName("TopPrimary")
        self.finish_button.setToolTip("Save this image's colonies (I'm Satisfied)")
        row.addWidget(self.finish_button)
        return bar

    def _wordmark_pixmap(self, text: str) -> QPixmap:
        """Raleway ExtraBold drawn directly: the variable font's weight axis must be set
        on the QFont itself, which style sheets cannot do."""
        font = QFont(self.theme.brand_family)
        font.setPixelSize(17)
        font.setVariableAxis(QFont.Tag("wght"), 800)
        font.setLetterSpacing(QFont.AbsoluteSpacing, 0.2)
        metrics = QFontMetricsF(font)
        ratio = 2.0
        width, height = metrics.horizontalAdvance(text) + 2, metrics.height() + 2
        pixmap = QPixmap(int(width * ratio), int(height * ratio))
        pixmap.fill(Qt.transparent)
        pixmap.setDevicePixelRatio(ratio)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.TextAntialiasing)
        painter.setFont(font)
        painter.setPen(QColor(self.colors.accent))      # wordmark in logo lime
        painter.drawText(QPointF(1, metrics.ascent() + 1), text)
        painter.end()
        return pixmap

    def _build_left_sidebar(self) -> QFrame:
        c = self.colors
        side = QFrame(objectName="LeftSidebar")
        side.setFixedWidth(self.theme.style.layout.sidebar_width + 10)
        self._left_column = QVBoxLayout(side)
        self._left_column.setContentsMargins(16, 20, 16, 20)
        self._left_column.setSpacing(20)

        modes = QVBoxLayout()
        modes.setSpacing(4)
        self.mode_group = QButtonGroup(self)
        self.mode_group.setExclusive(True)
        self.mode_buttons: dict[str, ModeButton] = {}
        self.group_labels: dict[str, QLabel] = {}
        self.rail_separator = divider()
        for group in (AUTOMATIC, MANUAL):
            if group == MANUAL:
                modes.addSpacing(12)
                modes.addWidget(self.rail_separator)
            section = label(GROUP_TITLES[group], "section")
            section.setContentsMargins(12, 0, 0, 6)
            self.group_labels[group] = section
            modes.addWidget(section)
            for key in MODE_ORDER:
                spec = MODES[key]
                if spec.group != group:
                    continue
                mode_button = ModeButton(spec.icon, spec.label, spec.shortcut, c)
                self.mode_group.addButton(mode_button)
                self.mode_buttons[key] = mode_button
                modes.addWidget(mode_button)
        self.rail_separator.hide()
        self._left_column.addLayout(modes)
        self.panel_divider = divider()
        self._left_column.addWidget(self.panel_divider)

        self.panels = QStackedWidget()
        self.panel_pages = {
            "parameters": self._build_parameter_panel(),
            "delete_one": self._build_delete_one_panel(),
            "delete_region": self._build_delete_region_panel(),
            "add_one": self._build_add_one_panel(),
        }
        for page in self.panel_pages.values():
            self.panels.addWidget(page)
        # Settings scroll when the window is too short to show them all
        self.panel_scroller = QScrollArea()
        self.panel_scroller.setWidget(self.panels)
        self.panel_scroller.setWidgetResizable(True)
        self.panel_scroller.setFrameShape(QFrame.NoFrame)
        self.panel_scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._left_column.addWidget(self.panel_scroller, 1)
        # Region actions sit below the scrolling settings so they stay in view while tuning
        self.region_footer = QWidget()
        footer = QVBoxLayout(self.region_footer)
        footer.setContentsMargins(0, 0, 0, 0)
        footer.setSpacing(8)
        footer.addWidget(self.region_add_button)
        footer.addWidget(self.region_clear_button)
        self._left_column.addWidget(self.region_footer)
        self.rail_stretch = QWidget()            # keeps the rail's icons at the top
        self.rail_stretch.hide()
        self._left_column.addWidget(self.rail_stretch, 1)
        return side

    def _build_parameter_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(18)

        self.region_intro = HintCard("Drag a box on the plate around the colonies to detect. "
                                     "Detection settings appear once the region is drawn.", c, icon="region_plus")
        column.addWidget(self.region_intro)

        # Everything that sets detection; hidden in Detect in a region until a box exists
        self.parameter_controls = QWidget()
        controls = QVBoxLayout(self.parameter_controls)
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(18)
        column.addWidget(self.parameter_controls)

        shape = QVBoxLayout()
        shape.setSpacing(8)
        shape.addWidget(label("Colony shape", "section"))
        segmented = QFrame(objectName="Segmented")
        segment_row = QHBoxLayout(segmented)
        segment_row.setContentsMargins(4, 4, 4, 4)
        segment_row.setSpacing(4)
        self.shape_group = QButtonGroup(self)
        self.shape_buttons: dict[str, QPushButton] = {}
        for kind in (IRREGULAR, CIRCULAR):
            segment = button(kind, "segment")
            segment.setCheckable(True)
            self.shape_group.addButton(segment)
            self.shape_buttons[kind] = segment
            segment_row.addWidget(segment)
        shape.addWidget(segmented)
        controls.addLayout(shape)

        polarity = QVBoxLayout()
        polarity.setSpacing(8)
        polarity.addWidget(label("Colony color", "section"))
        polarity_frame = QFrame(objectName="Segmented")
        polarity_row = QHBoxLayout(polarity_frame)
        polarity_row.setContentsMargins(4, 4, 4, 4)
        polarity_row.setSpacing(4)
        self.polarity_group = QButtonGroup(self)
        self.polarity_buttons: dict[str, QPushButton] = {}
        for key, text, tip in ((DARK, "Dark", "Colonies are darker than the agar"),
                               (LIGHT, "Light", "Colonies are lighter than the agar")):
            segment = button(text, "segment", tooltip=tip)
            segment.setCheckable(True)
            self.polarity_group.addButton(segment)
            self.polarity_buttons[key] = segment
            polarity_row.addWidget(segment)
        polarity.addWidget(polarity_frame)
        controls.addLayout(polarity)

        sense = PARAM_SPECS["sense"]
        self.level_row = ParameterRow("Brightness threshold", THRESHOLD_MIN, THRESHOLD_MAX, THRESHOLD_STEP, 2,
                                      THRESHOLD_CAPTIONS[DARK])
        self.sense_row = ParameterRow("Sensitivity", sense.minimum, sense.maximum, sense.step, 3)
        controls.addWidget(self.level_row)
        controls.addWidget(self.sense_row)

        radius = QVBoxLayout()
        radius.setSpacing(8)
        radius.addWidget(label("Colony radius", "label"))
        radius_grid = QHBoxLayout()
        radius_grid.setSpacing(8)
        rmin, rmax = PARAM_SPECS["rmin"], PARAM_SPECS["rmax"]
        self.rmin_field = Field("Min", "px", rmin.minimum, rmin.maximum, rmin.step, 0, "Minimum radius in pixels",
                                steppers=c)
        self.rmax_field = Field("Max", "px", rmax.minimum, rmax.maximum, rmax.step, 0, "Maximum radius in pixels",
                                steppers=c)
        radius_grid.addWidget(self.rmin_field)
        radius_grid.addWidget(self.rmax_field)
        radius.addLayout(radius_grid)
        controls.addLayout(radius)

        largest = QHBoxLayout()
        largest_label = label("Largest object", "label")
        largest.addWidget(largest_label)
        largest.addStretch(1)
        maxpix = PARAM_SPECS["maxpix"]
        self.maxpix_field = Field("", "px", maxpix.minimum, maxpix.maximum, maxpix.step, 0,
                                  "Largest object in pixels", field_width=56)
        self.maxpix_field.setFixedHeight(32)
        largest.addWidget(self.maxpix_field)
        controls.addLayout(largest)

        self.auto_button = button("Estimate settings", None, icon="wand", colors=c,
                                  icon_color=c.accent_text, icon_size=16,
                                  tooltip="Set the brightness threshold, colony color and radius range from "
                                          "this image, then rerun detection (undoable)")
        column.addWidget(self.auto_button)
        self.detect_hint = HintCard("Each change reruns detection on the whole image. "
                                    "Undo restores the previous result. A new image starts from the "
                                    "settings of the last image you finished.", c)
        column.addWidget(self.detect_hint)
        self.region_hint = HintCard("These settings apply inside the box only. The whole-image "
                                    "settings stay as they are. Drag a new box to move the region.", c)
        column.addWidget(self.region_hint)
        self.region_add_button = button("Add detected colonies", "primary", icon="plus", colors=c,
                                        icon_color=c.accent_ink, icon_size=16, stroke=2.4)
        self.region_clear_button = button("Clear region (Esc)")
        column.addStretch(1)
        return page

    def _count_card(self, title: str) -> tuple[QFrame, QLabel]:
        card = QFrame(objectName="CountCard")
        row = QHBoxLayout(card)
        row.setContentsMargins(14, 12, 14, 12)
        row.addWidget(label(title, "secondary"))
        row.addStretch(1)
        count = label("0", "countDanger")
        row.addWidget(count)
        return card, count

    @staticmethod
    def _action_group() -> tuple[QWidget, QVBoxLayout]:
        """Controls shown only once there is something to act on."""
        group = QWidget()
        column = QVBoxLayout(group)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        return group, column

    def _build_delete_one_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        column.addWidget(label("Click detections to select them. Click again to deselect.", "secondary", wrap=True))
        self.delete_one_actions, actions = self._action_group()
        card, self.selected_count_label = self._count_card("Selected")
        actions.addWidget(card)
        self.delete_one_button = button("Delete colonies", "danger", icon="trash", colors=c,
                                        icon_color=c.danger_ink, icon_size=16, stroke=2.2)
        actions.addWidget(self.delete_one_button)
        self.clear_selection_button = button("Clear selection (Esc)")
        actions.addWidget(self.clear_selection_button)
        column.addWidget(self.delete_one_actions)
        column.addStretch(1)
        return page

    def _build_delete_region_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        column.addWidget(label("Drag a box around false detections. Every colony whose center falls "
                               "inside is selected.", "secondary", wrap=True))
        self.delete_region_actions, actions = self._action_group()
        card, self.region_count_label = self._count_card("Selected in box")
        actions.addWidget(card)
        self.delete_region_button = button("Delete colonies", "danger", icon="trash", colors=c,
                                           icon_color=c.danger_ink, icon_size=16, stroke=2.2)
        actions.addWidget(self.delete_region_button)
        self.clear_box_button = button("Clear box (Esc)")
        actions.addWidget(self.clear_box_button)
        column.addWidget(self.delete_region_actions)
        column.addStretch(1)
        return page

    def _build_add_one_panel(self) -> QWidget:
        c = self.colors
        page = QWidget()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(14)
        snap = QFrame(objectName="CountCard")
        snap_row = QHBoxLayout(snap)
        snap_row.setContentsMargins(14, 12, 14, 12)
        snap_row.setSpacing(12)
        texts = QVBoxLayout()
        texts.setSpacing(2)
        snap_title = label("Snap to colony edge")
        snap_title.setStyleSheet("font-weight: 600;")
        texts.addWidget(snap_title)
        texts.addWidget(label("Fit circles to the colony inside", "caption", wrap=True))
        snap_row.addLayout(texts, 1)
        self.contour_switch = ToggleSwitch(c, "Snap to colony edge")
        snap_row.addWidget(self.contour_switch)
        column.addWidget(snap)

        column.addWidget(GestureRow("draw_circle", "Drag across a colony, edge to edge, to draw", c))
        self.add_one_actions, actions = self._action_group()
        actions.setSpacing(10)
        for icon_name, text in (("move", "Drag inside a circle to move it"),
                                ("resize", "Drag its edge to resize"),
                                ("mouse_right", "Right-click a circle to remove it")):
            actions.addWidget(GestureRow(icon_name, text, c))
        actions.addSpacing(4)
        self.add_one_button = button("Add colonies", "primary", icon="plus", colors=c,
                                     icon_color=c.accent_ink, icon_size=16, stroke=2.4)
        actions.addWidget(self.add_one_button)
        column.addWidget(self.add_one_actions)
        column.addStretch(1)
        return page

    def _build_canvas_area(self) -> QWidget:
        c = self.colors
        area = QWidget(objectName="CanvasArea")
        area.setMinimumWidth(480)
        layout = QVBoxLayout(area)
        layout.setContentsMargins(0, 0, 0, 0)
        self.canvas = DetectCanvas(self.theme.style.colony, frame_color=c.border)
        layout.addWidget(self.canvas)

        # Floating chips and toolbar, positioned in _place_overlays
        self.mode_chip = QFrame(area, objectName="Chip")
        chip_row = QHBoxLayout(self.mode_chip)
        chip_row.setContentsMargins(12, 0, 14, 0)
        chip_row.setSpacing(8)
        chip_row.addWidget(Dot(c.accent))
        self.mode_chip_label = QLabel()
        chip_row.addWidget(self.mode_chip_label)
        self.mode_chip.setFixedHeight(32)

        self.legend = QFrame(area, objectName="Chip")
        self.legend.setProperty("legend", True)
        legend_row = QHBoxLayout(self.legend)
        legend_row.setContentsMargins(12, 0, 12, 0)
        legend_row.setSpacing(14)
        colony = self.theme.style.colony
        self.legend_items: dict[str, QWidget] = {}
        for key, color, text, dashed in (("detected", colony.detected, "Detected", False),
                                         ("added", colony.manual, "Added", False),
                                         ("pending", colony.candidate, "To add", True),
                                         ("selected", colony.selected, "Selected", False)):
            item = QWidget()
            item_row = QHBoxLayout(item)
            item_row.setContentsMargins(0, 0, 0, 0)
            item_row.setSpacing(6)
            item_row.addWidget(LegendDot(color, dashed))
            legend_text = QLabel(text)
            legend_text.setStyleSheet("font-size: 12px;")
            item_row.addWidget(legend_text)
            legend_row.addWidget(item)
            self.legend_items[key] = item
        self.legend.setFixedHeight(32)

        self.zoom_toolbar = QFrame(area, objectName="Toolbar")
        tools = QHBoxLayout(self.zoom_toolbar)
        tools.setContentsMargins(4, 4, 4, 4)
        tools.setSpacing(2)
        self.zoom_out_button = button(variant="toolbar", icon="minus", colors=c, icon_size=16,
                                      tooltip="Zoom out", fixed=(34, 34))
        self.zoom_label = QLabel("100%")
        self.zoom_label.setFixedWidth(52)
        self.zoom_label.setAlignment(Qt.AlignCenter)
        self.zoom_in_button = button(variant="toolbar", icon="plus", colors=c, icon_size=16,
                                     tooltip="Zoom in", fixed=(34, 34))
        self.fit_button = button(variant="toolbar", icon="fit", colors=c, icon_size=16,
                                 tooltip="Fit plate to view (double-click)", fixed=(34, 34))
        self.pan_button = button(variant="toolbar", icon="hand", colors=c, icon_size=16,
                                 tooltip="Pan (or hold Space and drag)", fixed=(34, 34))
        self.pan_button.setCheckable(True)
        for widget in (self.zoom_out_button, self.zoom_label, self.zoom_in_button):
            tools.addWidget(widget)
        separator = divider(vertical=True, length=20)
        tools.addSpacing(4)
        tools.addWidget(separator)
        tools.addSpacing(4)
        tools.addWidget(self.fit_button)
        tools.addWidget(self.pan_button)

        original_resize = area.resizeEvent

        def resize_and_place(event) -> None:
            original_resize(event)
            self._place_overlays(area)

        area.resizeEvent = resize_and_place
        return area

    def _place_overlays(self, area: QWidget) -> None:
        for widget in (self.mode_chip, self.legend, self.zoom_toolbar):
            widget.adjustSize()
            widget.raise_()
        self.mode_chip.move(16, 16)
        self.legend.move(area.width() - self.legend.width() - 16, 16)
        self.zoom_toolbar.move((area.width() - self.zoom_toolbar.width()) // 2,
                               area.height() - self.zoom_toolbar.height() - 20)

    def _build_right_sidebar(self) -> QFrame:
        c = self.colors
        side = QFrame(objectName="RightSidebar")
        side.setFixedWidth(self.theme.style.layout.sidebar_width)
        column = QVBoxLayout(side)
        column.setContentsMargins(16, 20, 16, 16)
        column.setSpacing(16)

        card = QFrame(objectName="Card")
        card_column = QVBoxLayout(card)
        card_column.setContentsMargins(16, 16, 16, 16)
        card_column.setSpacing(14)
        count_row = QHBoxLayout()
        count_row.setSpacing(8)
        self.count_label = label("0", "bigNumber")
        count_row.addWidget(self.count_label, 0, Qt.AlignBaseline)
        count_row.addWidget(label("colonies", "muted"), 0, Qt.AlignBaseline)
        count_row.addStretch(1)
        card_column.addLayout(count_row)
        pills = QHBoxLayout()
        pills.setSpacing(6)
        self.auto_pill = label("Automatic 0", "pillInfo")
        self.added_pill = label("Added 0", "pillAccent")
        for pill in (self.auto_pill, self.added_pill):
            pill.setFixedHeight(24)
        pills.addWidget(self.auto_pill)
        pills.addWidget(self.added_pill)
        pills.addStretch(1)
        card_column.addLayout(pills)
        card_column.addWidget(divider())
        stats = QGridLayout()
        stats.setHorizontalSpacing(12)
        stats.setVerticalSpacing(12)
        self.stat_values: dict[str, QLabel] = {}
        for index, (key, title) in enumerate((("mean", "Mean radius"), ("median", "Median radius"),
                                              ("range", "Radius range"), ("scale", "Scale"))):
            cell = QVBoxLayout()
            cell.setSpacing(2)
            cell.addWidget(label(title, "caption"))
            value = label("–", "statValue")
            cell.addWidget(value)
            self.stat_values[key] = value
            stats.addLayout(cell, index // 2, index % 2)
        card_column.addLayout(stats)
        card_column.addWidget(divider())
        growth_row = QHBoxLayout()
        growth_text = QVBoxLayout()
        growth_text.setSpacing(2)
        growth_text.addWidget(label("Growth coverage", "caption"))
        self.growth_value = label("–", "statValue")
        self.growth_value.setToolTip("Share of this index's growable area covered by growth, learned from the "
                                     "colonies you marked; colony coverage counts only the marked colonies")
        growth_text.addWidget(self.growth_value)
        growth_row.addLayout(growth_text, 1)
        growth_row.addWidget(label("Show", "caption"))
        self.growth_switch = ToggleSwitch(c, "Show growth on the image")
        self.growth_switch.setToolTip("Tint every pixel found as growth (amber outside the marked colonies)")
        growth_row.addWidget(self.growth_switch)
        card_column.addLayout(growth_row)
        column.addWidget(card)

        header = QHBoxLayout()
        activity_title = label("Activity", "label")
        activity_title.setStyleSheet("font-size: 13px; font-weight: 600;")
        header.addWidget(activity_title)
        header.addStretch(1)
        self.clear_activity_button = button("Clear", "link")
        header.addWidget(self.clear_activity_button)
        column.addLayout(header)
        self.activity = ActivityFeed(c)
        column.addWidget(self.activity, 1)
        return side

    def _build_status_bar(self) -> QFrame:
        c = self.colors
        bar = QFrame(objectName="StatusBar")
        bar.setFixedHeight(self.theme.style.layout.status_bar_height)
        row = QHBoxLayout(bar)
        row.setContentsMargins(16, 0, 16, 0)
        row.setSpacing(18)
        ready = QHBoxLayout()
        ready.setSpacing(6)
        ready.addWidget(Dot(c.accent, 7))
        self.status_text = label("Ready", "status")
        ready.addWidget(self.status_text)
        row.addLayout(ready)
        self.pointer_label = label("", "status")
        self.size_label = label("", "status")
        self.zoom_status_label = label("", "status")
        for widget in (self.pointer_label, self.size_label, self.zoom_status_label):
            row.addWidget(widget)
        row.addStretch(1)
        self.undo_steps_label = label("", "status")
        row.addWidget(self.undo_steps_label)
        self.report_button = button("Report a bug", "link")
        self.report_button.setStyleSheet(f"color: {c.accent_text};")
        row.addWidget(self.report_button)
        return bar

    # =====================================================================
    # view updates the controller calls
    # =====================================================================
    def update_mode_specific_view(self, spec: ModeSpec) -> None:
        self._spec = spec
        button_for_mode = self.mode_buttons[spec.key]
        if not button_for_mode.isChecked():
            button_for_mode.setChecked(True)
        self.panels.setCurrentWidget(self.panel_pages[spec.panel])
        for key, item in self.legend_items.items():
            item.setVisible({"selected": spec.panel in ("delete_one", "delete_region"),
                             "pending": spec.panel == "add_one" or spec.region_parameters}.get(key, True))
        self._refresh_panel_state()

    def set_interaction_state(self, selected: int, box: bool, pending: int, region: bool,
                              candidates: int | None) -> None:
        """What the user has started in the current mode; decides which controls show."""
        self._state = {"selected": selected, "box": box, "pending": pending, "region": region,
                       "candidates": candidates}
        self.set_selection_count(selected)
        self.set_pending_count(pending)
        self.set_region_candidates(candidates)
        self._refresh_panel_state()

    def _refresh_panel_state(self) -> None:
        spec, state = self._spec, self._state
        region_mode = spec.region_parameters
        self.region_intro.setVisible(region_mode and not state["region"])
        self.parameter_controls.setVisible(not region_mode or state["region"])
        self.detect_hint.setVisible(spec.panel == "parameters" and not region_mode)
        self.auto_button.setVisible(spec.panel == "parameters" and not region_mode)
        self.region_hint.setVisible(region_mode and state["region"])
        self.region_footer.setVisible(region_mode and state["region"] and not self.left_collapsed)
        self.delete_one_actions.setVisible(state["selected"] > 0)
        self.delete_region_actions.setVisible(state["box"])
        self.add_one_actions.setVisible(state["pending"] > 0)
        active = {"delete_one": state["selected"] > 0, "delete_region": state["box"],
                  "add_one": state["pending"] > 0}.get(spec.panel, region_mode and state["region"])
        self.mode_chip_label.setText(spec.hint_active if active else spec.hint)
        self._place_overlays(self.canvas.parentWidget())

    # ----- collapsing the side columns -----------------------------------
    def set_left_collapsed(self, collapsed: bool, animate: bool = True) -> None:
        """Collapse the left column to a rail of mode icons, or expand it again."""
        self.left_collapsed = collapsed
        layout = self.theme.style.layout
        target = layout.rail_width if collapsed else layout.sidebar_width + 10
        self.left_toggle.setToolTip("Show the mode panel ([)" if collapsed else "Hide the mode panel ([)")

        def apply_content() -> None:
            margin = 11 if collapsed else 16
            self._left_column.setContentsMargins(margin, 20, margin, 20)
            for section in self.group_labels.values():
                section.setVisible(not collapsed)
            self.rail_separator.setVisible(collapsed)
            self.panel_divider.setVisible(not collapsed)
            self.panel_scroller.setVisible(not collapsed)
            self.rail_stretch.setVisible(collapsed)
            self._refresh_panel_state()
            for mode_button in self.mode_buttons.values():
                mode_button.set_compact(collapsed)

        if collapsed:
            apply_content()                         # hide text first, then narrow
            self._animate_width("left", self.left_sidebar, target, animate)
        else:
            self._animate_width("left", self.left_sidebar, target, animate, apply_content)

    def set_right_collapsed(self, collapsed: bool, animate: bool = True) -> None:
        """Hide or show the summary and activity column."""
        self.right_collapsed = collapsed
        self.right_toggle.setToolTip("Show the summary panel (])" if collapsed else "Hide the summary panel (])")
        if collapsed:
            self._animate_width("right", self.right_sidebar, 0, animate, self.right_sidebar.hide)
        else:
            self.right_sidebar.show()
            self._animate_width("right", self.right_sidebar, self.theme.style.layout.sidebar_width, animate)

    def _animate_width(self, key: str, widget: QWidget, target: int, animate: bool, finished=None) -> None:
        previous = self._animations.pop(key, None)
        if previous is not None:
            previous.stop()
        if not animate:
            widget.setFixedWidth(target)
            if finished:
                finished()
            return
        animation = QVariantAnimation(self)
        animation.setDuration(180)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.setStartValue(widget.width())
        animation.setEndValue(target)
        animation.valueChanged.connect(lambda value: widget.setFixedWidth(int(value)))
        if finished:
            animation.finished.connect(finished)
        self._animations[key] = animation
        animation.start()

    def set_spinner_values(self, params: DetectionParams) -> None:
        polarity, threshold = threshold_from_level(params.level)
        self.set_polarity(polarity)
        self.level_row.set_value(threshold)
        self.sense_row.set_value(params.sense)
        self.rmin_field.set_value(params.rmin)
        self.rmax_field.set_value(params.rmax)
        self.maxpix_field.set_value(params.maxpix)
        for kind, segment in self.shape_buttons.items():
            segment.blockSignals(True)
            segment.setChecked(kind == params.detection_type)
            segment.blockSignals(False)

    def ask_all_detected(self, count: int) -> str:
        """'stats', 'project' or 'stay' once every index is detected."""
        noun = "The index is" if count == 1 else f"All {count} indices are"
        choice = show_message(self, SUCCESS, f"{noun} detected",
                              "Every result is saved in the project. Open Stats to analyze the colonies, "
                              "or go back to the project page.",
                              [("stay", "Stay here"), ("project", "Back to project"), ("stats", "Go to Stats")],
                              default="stats")
        return choice or "stay"

    # ----- the window's own wiring: widgets to signals, view-only controls -------
    def _wire_controls(self) -> None:
        for key, mode_button in self.mode_buttons.items():
            mode_button.clicked.connect(lambda _checked=False, k=key: self.modeChosen.emit(k))
        for number, key in enumerate(MODE_ORDER, start=1):
            QShortcut(QKeySequence(str(number)), self, activated=lambda k=key: self.modeChosen.emit(k))
        self.level_row.valueEdited.connect(lambda _v: self.settingEdited.emit("level", self.level_value()))
        for segment in self.polarity_buttons.values():
            segment.clicked.connect(self._polarity_clicked)
        self.sense_row.valueEdited.connect(lambda v: self.settingEdited.emit("sense", v))
        self.rmin_field.valueEdited.connect(lambda v: self.settingEdited.emit("rmin", v))
        self.rmax_field.valueEdited.connect(lambda v: self.settingEdited.emit("rmax", v))
        self.maxpix_field.valueEdited.connect(lambda v: self.settingEdited.emit("maxpix", v))
        for kind, segment in self.shape_buttons.items():
            segment.clicked.connect(lambda _checked=False, k=kind: self.shapeChosen.emit(k))
        self.auto_button.clicked.connect(self.estimateRequested.emit)
        for widget in (self.delete_one_button, self.delete_region_button):
            widget.clicked.connect(self.deleteRequested.emit)
        for widget in (self.add_one_button, self.region_add_button):
            widget.clicked.connect(self.addRequested.emit)
        for widget in (self.clear_selection_button, self.clear_box_button, self.region_clear_button):
            widget.clicked.connect(self.clearRequested.emit)
        self.contour_switch.toggled.connect(self.contourToggled.emit)
        self.growth_switch.toggled.connect(self.growthToggled.emit)
        self.undo_button.clicked.connect(self.undoRequested.emit)
        self.redo_button.clicked.connect(self.redoRequested.emit)
        self.finish_button.clicked.connect(self.finishRequested.emit)
        self.help_button.clicked.connect(self.helpRequested.emit)
        self.prev_button.clicked.connect(self.previousRequested.emit)
        self.next_button.clicked.connect(self.nextRequested.emit)
        self.image_picker.clicked.connect(self.boardRequested.emit)
        self.index_popup().board.cellClicked.connect(lambda target: self.indexChosen.emit(target[0]))
        self.canvas.pointerMoved.connect(self.pointerMoved.emit)
        for keys, signal in ((QKeySequence.Undo, self.undoRequested), (QKeySequence.Redo, self.redoRequested),
                             (QKeySequence("Ctrl+Y"), self.redoRequested), (QKeySequence("Escape"), self.clearRequested),
                             (QKeySequence(Qt.Key_PageUp), self.previousRequested),
                             (QKeySequence(Qt.Key_PageDown), self.nextRequested)):
            QShortcut(keys, self, activated=signal.emit)
        # view-only controls: the controller never needs to know about these
        self.left_toggle.clicked.connect(lambda: self.set_left_collapsed(not self.left_collapsed))
        self.right_toggle.clicked.connect(lambda: self.set_right_collapsed(not self.right_collapsed))
        QShortcut(QKeySequence("["), self, activated=lambda: self.set_left_collapsed(not self.left_collapsed))
        QShortcut(QKeySequence("]"), self, activated=lambda: self.set_right_collapsed(not self.right_collapsed))
        self.clear_activity_button.clicked.connect(self.activity.clear)
        self.report_button.setEnabled(False)
        self.zoom_in_button.clicked.connect(self.canvas.zoom_in)
        self.zoom_out_button.clicked.connect(self.canvas.zoom_out)
        self.fit_button.clicked.connect(self.canvas.reset_axes_view)
        self.pan_button.toggled.connect(self.canvas.set_pan_mode)
        self.canvas.zoomChanged.connect(lambda scale: self.set_zoom(scale * 100))

    def _polarity_clicked(self) -> None:
        """Colonies darker or lighter than the agar: keeps the threshold shown, flips the stored level."""
        self.set_polarity(self.polarity())
        self.settingEdited.emit("level", self.level_value())

    # ----- what the controller reads and sets -------------------------------------
    def settings(self) -> dict:
        """The detection settings as the controls show them."""
        return {"level": self.level_value(), "sense": self.sense_row.value(), "rmin": self.rmin_field.value(),
                "rmax": self.rmax_field.value(), "maxpix": self.maxpix_field.value(),
                "detection_type": CIRCULAR if self.shape_buttons[CIRCULAR].isChecked() else IRREGULAR}

    def growth_shown(self) -> bool:
        return self.growth_switch.isChecked()

    def set_growth_shown(self, shown: bool) -> None:
        self.growth_switch.setChecked(shown)

    def set_navigation(self, enabled: bool, can_step: bool) -> None:
        """Index board and previous / next: enabled at all, and whether there is another index to step to."""
        self.image_picker.setEnabled(enabled)
        self.prev_button.setEnabled(enabled and can_step)
        self.next_button.setEnabled(enabled and can_step)

    def set_tool(self, tool) -> None:
        """The interaction tool the canvas forwards mouse events to (None: no tool)."""
        self.canvas.tool = tool

    def tool_surface(self):
        """What interaction tools draw previews on and read coordinates from."""
        return self.canvas

    def show_image(self, image) -> None:
        self.canvas.set_image(image)
        rows, cols = image.shape[:2]
        self.set_image_size(cols, rows)

    def draw_colonies(self, colonies, **state) -> None:
        self.canvas.render_colonies(colonies, **state)

    def board_open(self) -> bool:
        return self.index_popup().isVisible()

    def set_board(self, summary: str, view_rows, page_rows, board, note: str) -> None:
        self.index_popup().set_content(summary, view_rows, page_rows, board, note)

    def hide_board(self) -> None:
        self.index_popup().hide()

    def set_close_guard(self, guard) -> None:
        """guard() -> True when the window may close (asks about unsaved edits)."""
        self.close_guard = guard

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)

    def set_polarity(self, polarity: str) -> None:
        for key, segment in self.polarity_buttons.items():
            segment.blockSignals(True)
            segment.setChecked(key == polarity)
            segment.blockSignals(False)
        self.level_row.set_caption(THRESHOLD_CAPTIONS[polarity])

    def polarity(self) -> str:
        return LIGHT if self.polarity_buttons[LIGHT].isChecked() else DARK

    def level_value(self) -> float:
        """The stored brightness level from the colony color and the threshold shown."""
        return level_from_threshold(self.polarity(), self.level_row.value())

    def set_summary(self, summary: dict) -> None:
        self.count_label.setText(str(summary["total"]))
        self.auto_pill.setText(f"Automatic {summary['automatic']}")
        self.added_pill.setText(f"Added {summary['added']}")
        if summary["mean_um"] is None:
            for key in ("mean", "median", "range"):
                self.stat_values[key].setText("–")
        else:
            self.stat_values["mean"].setText(f"{summary['mean_um']:,.0f} µm")
            self.stat_values["median"].setText(f"{summary['median_um']:,.0f} µm")
            self.stat_values["range"].setText(f"{summary['min_um']:,.0f}–{summary['max_um']:,.0f} µm")
        self.stat_values["scale"].setText(f"{summary['um_per_px']:.1f} µm/px")

    def set_growth(self, metrics: dict | None) -> None:
        """Growth and colony coverage of the current colonies, or None when not measured yet."""
        if metrics is None or metrics.get("growth_coverage") is None:
            self.growth_value.setText("–")
            return
        self.growth_value.setText(f"{metrics['growth_coverage']:.1%} · colonies {metrics['colony_coverage']:.1%}")

    def show_growth(self, growth, colonies) -> None:
        """Tint growth on the image (None removes the tint)."""
        if growth is None:
            self.canvas.set_overlay(None)
            return
        import numpy as np
        from PySide6.QtGui import QColor
        rgba = np.zeros(growth.shape + (4,), dtype=np.uint8)
        for mask, name, alpha in ((growth & ~colonies, self.theme.style.colony.growth, 150),
                                  (colonies & growth, self.theme.style.colony.detected, 70)):
            color = QColor(name)
            rgba[mask] = (color.red(), color.green(), color.blue(), alpha)
        self.canvas.set_overlay(rgba)

    def set_selection_count(self, count: int) -> None:
        noun = "colony" if count == 1 else "colonies"
        for count_label, delete_button in ((self.selected_count_label, self.delete_one_button),
                                           (self.region_count_label, self.delete_region_button)):
            count_label.setText(str(count))
            delete_button.setText(f"Delete {count} {noun}" if count else "Delete colonies")
            delete_button.setEnabled(count > 0)
        self.clear_selection_button.setEnabled(count > 0)

    def set_pending_count(self, count: int) -> None:
        noun = "colony" if count == 1 else "colonies"
        self.add_one_button.setText(f"Add {count} {noun}" if count else "Add colonies")
        self.add_one_button.setEnabled(count > 0)

    def set_region_candidates(self, count: int | None) -> None:
        if count is None:
            self.region_add_button.setText("Add detected colonies")
            self.region_add_button.setEnabled(False)
        else:
            noun = "colony" if count == 1 else "colonies"
            self.region_add_button.setText(f"Add {count} {noun}")
            self.region_add_button.setEnabled(count > 0)

    def set_history(self, can_undo: bool, can_redo: bool, undo_steps: int) -> None:
        self.undo_button.setEnabled(can_undo)
        self.redo_button.setEnabled(can_redo)
        self.undo_steps_label.setText(f"{undo_steps} undo step{'s' if undo_steps != 1 else ''}")

    def add_activity(self, kind: str, title: str, detail: str = "") -> None:
        self.activity.add_entry(kind, title, detail)

    def show_status(self, text: str, timeout_ms: int = 4000) -> None:
        self.status_text.setText(text)
        self._status_timer.start(timeout_ms)

    def set_image_size(self, cols: int, rows: int) -> None:
        self.size_label.setText(f"{cols} × {rows} px")

    def set_pointer(self, x: float, y: float, inside: bool) -> None:
        # 1-based pixel numbers, as in MATLAB and in image viewers
        self.pointer_label.setText(f"x {round(x) + 1} · y {round(y) + 1}" if inside else "")

    def set_zoom(self, percent: float) -> None:
        text = f"{percent:.0f}%"
        self.zoom_label.setText(text)
        self.zoom_status_label.setText(f"Zoom {text}")

    def set_image_label(self, nominal_display: str, ordinal_display: str, position: str) -> None:
        """Name of the open index in the top bar; position like '3 of 96'."""
        self.nominal_label.setText(nominal_display)
        self.ordinal_chip.setText(ordinal_display)
        self.ordinal_chip.setVisible(bool(ordinal_display))
        self.image_picker.setMinimumWidth(self.nominal_label.sizeHint().width()
                                          + self.ordinal_chip.sizeHint().width() + 90)
        self.image_picker.setAccessibleName(f"Image {position}: {nominal_display}, {ordinal_display}")
        self.image_picker.setToolTip(f"Index {position}. Click to choose another index.")

    def index_popup(self) -> IndexPopup:
        if getattr(self, "_index_popup", None) is None:
            self._index_popup = IndexPopup(self.colors, self)
        return self._index_popup

    def show_index_popup(self) -> None:
        popup = self.index_popup()
        below = self.image_picker.mapToGlobal(self.image_picker.rect().bottomLeft())
        center = below.x() + self.image_picker.width() // 2 - popup.width() // 2
        popup.move(max(0, center), below.y() + 6)
        popup.show()

    def ask_save_before_leaving(self, name: str) -> str:
        """'save', 'discard' or 'cancel' for an index with edits that are not saved."""
        choice = show_message(self, QUESTION, "Save this image?",
                              f"{name} has changes that are not saved to the project.",
                              [("cancel", "Cancel"), ("discard", "Discard changes"), ("save", "Save")], default="save")
        return choice or "cancel"

    def closeEvent(self, event) -> None:
        guard = getattr(self, "close_guard", None)
        if guard is not None and not guard():
            event.ignore()
            return
        super().closeEvent(event)

    def fit_to_screen(self) -> None:
        """Open at the design size when it fits, otherwise fill the screen's usable area."""
        available = self.screen().availableGeometry()
        width, height = self.theme.style.layout.window_size
        frame_margin = 40                        # title bar and borders drawn by the system
        if width <= available.width() and height + frame_margin <= available.height():
            self.resize(width, height)
            self.move(available.center() - self.rect().center())
        else:
            self.setGeometry(available.adjusted(0, frame_margin, 0, 0))
            self.showMaximized()

    def sizeHint(self) -> QSize:
        return QSize(*self.theme.style.layout.window_size)
