"""CropCanvas: a plate photo with its layout drawn on top, and the mouse tool that edits the layout.

Round dish: drag the center to move the dish, the square on the rim to resize
it, the large handle to rotate every cut, a small cut handle to move that cut
alone; right-click a cut handle to remove it. Rectangular plate: drag the
center, a corner (resizes about the center) or the rotation handle. Clicking
inside a section selects it. Zoom and pan work as in Colony Detection.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainterPath, QPen
from PySide6.QtWidgets import (QGraphicsEllipseItem, QGraphicsItem, QGraphicsPathItem, QGraphicsRectItem,
                               QGraphicsSimpleTextItem)

from ..core.cropping import DishLayout, GridLayout, clock_angle, point_at
from .canvas import DetectCanvas
from .tools import CanvasTool
from ..theme.tokens import get_quanta_colony_style

_C = get_quanta_colony_style().colors
LIME, LIME_TEXT, DANGER, HALO = _C.accent, _C.accent_text, _C.danger, _C.canvas
HANDLE_PX = 9                     # grab distance around a handle, screen pixels


class CropCanvas(DetectCanvas):
    layoutEdited = Signal(object, bool)       # new layout, drag finished
    sectionPicked = Signal(int)
    cutRemoved = Signal(int)

    def __init__(self, colony_colors, frame_color: str = _C.frame, parent=None):
        super().__init__(colony_colors, frame_color, parent)
        self.layout_model = None
        self.tool = PlateTool(self)
        self._plate_items: list = []

    def set_image(self, image) -> None:
        """New photo: the scene starts empty (no frame or layout left from the previous photo)."""
        self.scene().clear()
        self._image_item = None
        self._frame_item = None
        self._overlay_items = []
        self._plate_items = []
        super().set_image(image)

    # ----- drawing -------------------------------------------------------
    def show_layout(self, layout, labels: list[tuple[str, str, str]], selected: int, problems: set[int]) -> None:
        """labels: (title, text, state) per section; state 'confirmed', 'proposed' or 'unused'."""
        self.layout_model = layout
        for item in self._plate_items:
            self.scene().removeItem(item)
        self._plate_items = []
        if layout is None:
            return
        for index in range(layout.section_count):
            if index == selected or index in problems:
                color = QColor(LIME if index == selected else DANGER)
                color.setAlpha(34)
                self._path(self._section_path(layout, index), None, 0, fill=color)
        if isinstance(layout, DishLayout):
            outline = QPainterPath()
            outline.addEllipse(QPointF(layout.cx, layout.cy), layout.r, layout.r)
            self._path(outline, LIME, 2.5)
            cuts = QPainterPath()
            for angle in layout.cuts:
                cuts.moveTo(layout.cx, layout.cy)
                cuts.lineTo(*point_at(layout.cx, layout.cy, angle, layout.r))
            self._path(cuts, LIME, 2, dashed=True)
            for i, angle in enumerate(layout.cuts):
                self._handle(*point_at(layout.cx, layout.cy, angle, layout.r), big=i == 0)
            self._handle(*self.tool.radius_handle(layout), square=True)
        else:
            outline = QPainterPath()
            corners = layout.corners()
            outline.moveTo(*corners[0])
            for corner in corners[1:]:
                outline.lineTo(*corner)
            outline.closeSubpath()
            self._path(outline, LIME, 2.5)
            lines = QPainterPath()
            for (x0, y0), (x1, y1) in layout.grid_lines():
                lines.moveTo(x0, y0)
                lines.lineTo(x1, y1)
            self._path(lines, LIME, 2, dashed=True)
            for corner in corners:
                self._handle(*corner, square=True)
            self._handle(*self.tool.rotation_handle(layout), big=True)
        center = layout.cx, layout.cy
        cross = QPainterPath()
        size = self.screen_to_image_distance(8)
        cross.moveTo(center[0] - size, center[1])
        cross.lineTo(center[0] + size, center[1])
        cross.moveTo(center[0], center[1] - size)
        cross.lineTo(center[0], center[1] + size)
        self._path(cross, LIME, 2)
        for index, (title, text, state) in enumerate(labels):
            self._label(*layout.label_point(index), title, text, state, index == selected, index in problems)

    @staticmethod
    def _section_path(layout, index: int) -> QPainterPath:
        path = QPainterPath()
        if isinstance(layout, GridLayout):
            cell = layout.cell(index)
            path.moveTo(*cell[0])
            for point in cell[1:]:
                path.lineTo(*point)
            path.closeSubpath()
            return path
        a, b = layout.spans()[index]
        if layout.section_count == 1:
            path.addEllipse(QPointF(layout.cx, layout.cy), layout.r, layout.r)
            return path
        rect = QRectF(layout.cx - layout.r, layout.cy - layout.r, 2 * layout.r, 2 * layout.r)
        path.moveTo(layout.cx, layout.cy)
        path.arcTo(rect, 90 - a, -(b - a))            # Qt: degrees counterclockwise from 3 o'clock
        path.closeSubpath()
        return path

    def _path(self, path: QPainterPath, color: str | None, width: float, dashed: bool = False, fill=None) -> None:
        pen = QPen(Qt.NoPen) if color is None else QPen(QColor(color), width, Qt.DashLine if dashed else Qt.SolidLine)
        if color is not None:
            pen.setCosmetic(True)
            if dashed:
                pen.setDashPattern([5, 4])
        item = self.scene().addPath(path, pen, QBrush(fill) if fill is not None else QBrush(Qt.NoBrush))
        item.setZValue(1)
        self._plate_items.append(item)

    def _handle(self, x: float, y: float, big: bool = False, square: bool = False) -> None:
        size = 18 if big else 11
        item = (QGraphicsRectItem if square else QGraphicsEllipseItem)(-size / 2, -size / 2, size, size)
        item.setFlag(QGraphicsItem.ItemIgnoresTransformations)
        item.setPos(x, y)
        item.setBrush(QBrush(QColor(LIME if big else HALO)))
        item.setPen(QPen(QColor(HALO if big else LIME), 2.5 if big else 2))
        item.setZValue(3)
        self.scene().addItem(item)
        self._plate_items.append(item)

    def _label(self, x: float, y: float, title: str, text: str, state: str, selected: bool, problem: bool) -> None:
        tag = QGraphicsPathItem()
        tag.setFlag(QGraphicsItem.ItemIgnoresTransformations)
        tag.setPos(x, y)
        tag.setZValue(4)
        font = QFont()
        font.setPixelSize(13)
        font.setWeight(QFont.DemiBold)
        small = QFont(font)
        small.setPixelSize(10)
        top = QGraphicsSimpleTextItem(title, tag)
        top.setFont(small)
        top.setBrush(QBrush(QColor(_C.section_label_top)))
        main = QGraphicsSimpleTextItem(text, tag)
        main.setFont(font)
        main.setBrush(QBrush(QColor(_C.section_label if state != "unused" else _C.section_label_unused)))
        width = max(top.boundingRect().width(), main.boundingRect().width()) + 18
        height = top.boundingRect().height() + main.boundingRect().height() + 8
        top.setPos(-top.boundingRect().width() / 2, -height / 2 + 3)
        main.setPos(-main.boundingRect().width() / 2, -height / 2 + 3 + top.boundingRect().height())
        outline = QPainterPath()
        outline.addRoundedRect(QRectF(-width / 2, -height / 2, width, height), 5, 5)
        tag.setPath(outline)
        tag.setBrush(QBrush(QColor(22, 23, 20, 238)))
        color = (DANGER if problem else LIME_TEXT if selected
                 else LIME if state in ("confirmed", "proposed") else _C.section_idle_edge)
        solid = state == "confirmed" and not problem
        pen = QPen(QColor(color), 2 if selected else 1.4, Qt.SolidLine if solid else Qt.DashLine)
        tag.setPen(pen)
        self.scene().addItem(tag)
        self._plate_items.append(tag)


class PlateTool(CanvasTool):
    """Turns drags on the handles into new layouts, and clicks into section picks."""

    def __init__(self, canvas: CropCanvas):
        super().__init__(canvas)
        self._drag = None             # (part, extra, start point, start layout)

    @staticmethod
    def radius_handle(layout: DishLayout) -> tuple[float, float]:
        spans = layout.spans()
        a, b = spans[0]
        return point_at(layout.cx, layout.cy, (a + b) / 2, layout.r)

    @staticmethod
    def rotation_handle(layout: GridLayout) -> tuple[float, float]:
        t = math.radians(layout.angle)
        distance = layout.height / 2 + max(24.0, layout.height * 0.08)
        return layout.cx + distance * math.sin(t), layout.cy - distance * math.cos(t)

    def _near(self, point: QPointF, x: float, y: float) -> bool:
        return math.hypot(point.x() - x, point.y() - y) <= self.canvas.screen_to_image_distance(HANDLE_PX)

    def _part_at(self, point: QPointF):
        layout = self.canvas.layout_model
        if layout is None:
            return None, None
        if self._near(point, layout.cx, layout.cy):
            return "center", None
        if isinstance(layout, DishLayout):
            for i, angle in enumerate(layout.cuts):
                if self._near(point, *point_at(layout.cx, layout.cy, angle, layout.r)):
                    return ("rotate" if i == 0 else "cut"), i
            if self._near(point, *self.radius_handle(layout)):
                return "radius", None
        else:
            if self._near(point, *self.rotation_handle(layout)):
                return "rotate", None
            for corner in layout.corners():
                if self._near(point, *corner):
                    return "corner", None
        return None, None

    def press(self, point: QPointF, button=Qt.LeftButton) -> None:
        layout = self.canvas.layout_model
        if layout is None:
            return
        part, extra = self._part_at(point)
        if button == Qt.RightButton:
            if part == "cut":
                self.canvas.cutRemoved.emit(extra)
            return
        if button != Qt.LeftButton:
            return
        if part is None:
            section = layout.section_at(point.x(), point.y())
            if section >= 0:
                self.canvas.sectionPicked.emit(section)
            return
        self._drag = (part, extra, point, layout)

    def move(self, point: QPointF) -> None:
        if self._drag is None:
            part, _ = self._part_at(point)
            shapes = {"center": Qt.SizeAllCursor, "rotate": Qt.CrossCursor, "cut": Qt.CrossCursor,
                      "radius": Qt.SizeFDiagCursor, "corner": Qt.SizeFDiagCursor}
            self.canvas.set_tool_cursor(shapes.get(part, Qt.ArrowCursor))
            return
        self.canvas.layoutEdited.emit(self._dragged(point), False)

    def release(self, point: QPointF, button=Qt.LeftButton) -> None:
        if self._drag is None or button != Qt.LeftButton:
            return
        layout = self._dragged(point)
        self._drag = None
        if isinstance(layout, DishLayout):
            layout = layout.normalized()
        self.canvas.layoutEdited.emit(layout, True)

    def _dragged(self, point: QPointF):
        part, extra, start, layout = self._drag
        dx, dy = point.x() - start.x(), point.y() - start.y()
        if part == "center":
            return layout.moved(layout.cx + dx, layout.cy + dy)
        if isinstance(layout, DishLayout):
            if part == "radius":
                return layout.resized(math.hypot(point.x() - layout.cx, point.y() - layout.cy))
            angle = clock_angle(point.x() - layout.cx, point.y() - layout.cy)
            if part == "rotate":
                return layout.rotated(angle - layout.cuts[0])
            return layout.with_cut(extra, angle)
        if part == "rotate":
            return layout.rotated(clock_angle(point.x() - layout.cx, point.y() - layout.cy) - layout.angle)
        return layout.corner_to(point.x(), point.y())

    def deactivate(self) -> None:
        self._drag = None
