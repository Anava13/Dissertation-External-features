"""CroppingWindow: the Cropping screen (view, dark palette: it is mostly photos).

Top bar (photo navigation, Finish cropping, Done with photo), photo list on
the left, the plate canvas in the middle, levels and the index board on the
right. The window only shows what the controller passes it.
"""

from __future__ import annotations

from PySide6.QtCore import QPointF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow, QPushButton, QScrollArea,
                               QVBoxLayout, QWidget)

from ..core.cropping import Board
from ..theme import Theme
from ..theme.icons import app_icon, icon_pixmap, logo_pixmap
from .cropping_canvas import CropCanvas
from .index_board import IndexBoard, PhotoRow, Segmented
from .light import clear_layout
from .widgets import button, divider, label
from .dialogs import ERROR, WARNING, notify, show_message


_clear = clear_layout


class CroppingWindow(QMainWindow):
    """Cropping's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    previousRequested = Signal()
    nextRequested = Signal()
    doneRequested = Signal()                 # Done with photo (Enter)
    finishRequested = Signal()
    helpRequested = Signal()
    fitRequested = Signal()
    rotateRequested = Signal(int)            # +1 clockwise step, -1 counterclockwise
    countRequested = Signal(int)             # +1 / -1 cuts or columns
    unusedRequested = Signal()
    problemRequested = Signal()
    nextSectionRequested = Signal()          # Tab
    numberPressed = Signal(int)              # keys 1-9, as 0-8
    layoutEdited = Signal(object, bool)      # new layout, drag finished
    sectionPicked = Signal(int)
    cutRemoved = Signal(int)
    targetChosen = Signal(object)            # an index board cell's target

    def __init__(self, theme: Theme, project_name: str):
        super().__init__()
        self.theme = theme
        self.colors = theme.style.colors
        self.setWindowTitle(f"QuantaColony · Cropping · {project_name}")
        self.setWindowIcon(app_icon())
        self.resize(*theme.style.layout.window_size)

        root = QWidget(objectName="Root")
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        column.addWidget(self._top_bar())
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._photo_list())
        body.addWidget(self._canvas_area(), 1)
        body.addWidget(self._side_panel())
        column.addLayout(body, 1)
        scroller = QScrollArea()
        scroller.setWidget(root)
        scroller.setWidgetResizable(True)
        scroller.setFrameShape(QFrame.NoFrame)
        self.setCentralWidget(scroller)
        self._wire_controls()
        root.setMinimumSize(1100, 700)

    # ----- construction ---------------------------------------------------
    def _top_bar(self) -> QFrame:
        c = self.colors
        bar = QFrame(objectName="TopBar")
        bar.setFixedHeight(self.theme.style.layout.top_bar_height)
        row = QHBoxLayout(bar)
        row.setContentsMargins(16, 0, 16, 0)
        row.setSpacing(14)
        logo = QLabel()
        logo.setPixmap(logo_pixmap(28))
        row.addWidget(logo)
        wordmark = QLabel()
        wordmark.setPixmap(self._wordmark("QuantaColony"))
        row.addWidget(wordmark)
        row.addWidget(divider(vertical=True, length=20))
        row.addWidget(label("Cropping", "muted"))
        row.addStretch(1)
        self.prev_button = button(variant="icon", icon="chevron_left", colors=c, icon_color=c.text_faint,
                                  icon_size=16, tooltip="Previous photo (Page Up)", fixed=(32, 32))
        self.photo_label = QLabel()
        self.photo_label.setMinimumWidth(240)
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.photo_label.setFixedHeight(32)
        self.photo_label.setStyleSheet(f"background: {c.card}; border: 1px solid {c.border}; border-radius: 6px;"
                                       " padding: 0 12px; font-weight: 500;")
        self.next_button = button(variant="icon", icon="chevron_right", colors=c, icon_color=c.text_faint,
                                  icon_size=16, tooltip="Next photo (Page Down)", fixed=(32, 32))
        for widget in (self.prev_button, self.photo_label, self.next_button):
            row.addWidget(widget)
        row.addStretch(1)
        self.help_button = button(variant="icon", icon="help", colors=c, icon_color=c.text_muted,
                                  icon_size=18, tooltip="Help", fixed=(38, 38))
        row.addWidget(self.help_button)
        self.finish_button = button("Finish cropping", None, icon="check", colors=c, icon_size=16)
        self.finish_button.setToolTip("Check for indices without a region, then open Colony Detection")
        row.addWidget(self.finish_button)
        self.done_button = button("Done with photo", "primary", colors=c)
        self.done_button.setObjectName("TopPrimary")
        self.done_button.setToolTip("Save this photo's regions and open the next photo (Enter)")
        row.addWidget(self.done_button)
        return bar

    def _wordmark(self, text: str) -> QPixmap:
        font = QFont(self.theme.brand_family)
        font.setPixelSize(17)
        font.setVariableAxis(QFont.Tag("wght"), 800)
        metrics = QFontMetricsF(font)
        pixmap = QPixmap(int((metrics.horizontalAdvance(text) + 2) * 2), int((metrics.height() + 2) * 2))
        pixmap.fill(Qt.transparent)
        pixmap.setDevicePixelRatio(2.0)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.TextAntialiasing)
        painter.setFont(font)
        painter.setPen(QColor(self.colors.accent))
        painter.drawText(QPointF(1, metrics.ascent() + 1), text)
        painter.end()
        return pixmap

    def _photo_list(self) -> QFrame:
        side = QFrame(objectName="LeftSidebar")
        side.setFixedWidth(230)
        column = QVBoxLayout(side)
        column.setContentsMargins(0, 14, 0, 14)
        column.setSpacing(6)
        header = QHBoxLayout()
        header.setContentsMargins(16, 0, 16, 0)
        header.addWidget(label("Photos", "label"))
        header.addStretch(1)
        self.photo_count_label = label("", "caption")
        header.addWidget(self.photo_count_label)
        column.addLayout(header)
        scroller = QScrollArea()
        scroller.setWidgetResizable(True)
        scroller.setFrameShape(QFrame.NoFrame)
        holder = QWidget()
        self.photo_rows = QVBoxLayout(holder)
        self.photo_rows.setContentsMargins(0, 0, 0, 0)
        self.photo_rows.setSpacing(0)
        scroller.setWidget(holder)
        column.addWidget(scroller, 1)
        return side

    def _canvas_area(self) -> QWidget:
        c = self.colors
        area = QWidget(objectName="CanvasArea")
        layout = QVBoxLayout(area)
        layout.setContentsMargins(0, 0, 0, 0)
        self.canvas = CropCanvas(self.theme.style.colony, frame_color=c.border)
        layout.addWidget(self.canvas)
        self.hint_chip = QFrame(area, objectName="Chip")
        chip_row = QHBoxLayout(self.hint_chip)
        chip_row.setContentsMargins(12, 0, 14, 0)
        self.hint_label = QLabel()
        chip_row.addWidget(self.hint_label)
        self.hint_chip.setFixedHeight(32)

        self.toolbar = QFrame(area, objectName="Toolbar")
        tools = QHBoxLayout(self.toolbar)
        tools.setContentsMargins(4, 4, 8, 4)
        tools.setSpacing(2)

        def tool(text: str, tip: str, width: int = 34) -> QPushButton:
            widget = button(text, "toolbar", tooltip=tip)
            widget.setFixedSize(width, 34)
            return widget

        self.fit_button = tool("Fit dish", "Find the dish edge in this photo", 74)
        self.rotate_left_button = tool("↺", "Rotate the cuts counterclockwise (Shift+R)")
        self.rotation_label = QLabel()
        self.rotation_label.setFixedWidth(46)
        self.rotation_label.setAlignment(Qt.AlignCenter)
        self.rotate_right_button = tool("↻", "Rotate the cuts clockwise (R)")
        self.fewer_button = tool("−", "One section fewer")
        self.count_label = QLabel()
        self.count_label.setFixedWidth(96)
        self.count_label.setAlignment(Qt.AlignCenter)
        self.more_button = tool("+", "One section more")
        self.scale_label = label("", "caption")
        self.scale_label.setContentsMargins(8, 0, 0, 0)
        for widget in (self.fit_button, divider(vertical=True, length=20), self.rotate_left_button, self.rotation_label,
                       self.rotate_right_button, divider(vertical=True, length=20), self.fewer_button, self.count_label,
                       self.more_button, divider(vertical=True, length=20), self.scale_label):
            tools.addWidget(widget)
        original_resize = area.resizeEvent

        def place(event) -> None:
            original_resize(event)
            self._place_overlays(area)

        area.resizeEvent = place
        return area

    def _place_overlays(self, area: QWidget) -> None:
        for widget in (self.hint_chip, self.toolbar):
            widget.adjustSize()
            widget.raise_()
        self.hint_chip.move(16, 16)
        self.toolbar.move((area.width() - self.toolbar.width()) // 2, area.height() - self.toolbar.height() - 18)

    def _side_panel(self) -> QScrollArea:
        c = self.colors
        side = QFrame(objectName="RightSidebar")
        column = QVBoxLayout(side)
        column.setContentsMargins(18, 16, 18, 16)
        column.setSpacing(14)

        whole_header = QHBoxLayout()
        whole_header.addWidget(label("Whole photo", "label"))
        whole_header.addStretch(1)
        self.whole_note = label("", "caption")
        whole_header.addWidget(self.whole_note)
        column.addLayout(whole_header)
        self.whole_rows = QVBoxLayout()
        self.whole_rows.setSpacing(8)
        column.addLayout(self.whole_rows)
        column.addWidget(divider())

        section_header = QHBoxLayout()
        self.section_title = label("", "label")
        section_header.addWidget(self.section_title)
        section_header.addStretch(1)
        self.section_state = label("", "caption")
        section_header.addWidget(self.section_state)
        column.addLayout(section_header)
        self.section_rows = QVBoxLayout()
        self.section_rows.setSpacing(8)
        column.addLayout(self.section_rows)
        self.problem_box = QFrame()
        self.problem_box.setStyleSheet(f"QFrame {{ background: {c.problem_fill}; border: 1px solid {c.problem_border};"
                                       " border-radius: 6px; }")
        problem_row = QHBoxLayout(self.problem_box)
        problem_row.setContentsMargins(10, 6, 6, 6)
        self.problem_text = QLabel()
        self.problem_text.setWordWrap(True)
        self.problem_text.setStyleSheet(f"color: {c.danger_text}; font-size: 13px; border: none;"
                                        " background: transparent;")
        problem_row.addWidget(self.problem_text, 1)
        self.problem_button = button("Fix the other", None)
        self.problem_button.setFixedHeight(30)
        problem_row.addWidget(self.problem_button)
        column.addWidget(self.problem_box)
        self.unused_button = button("Leave section unused", "link")
        column.addWidget(self.unused_button, 0, Qt.AlignLeft)
        column.addWidget(divider())

        board_header = QHBoxLayout()
        board_header.addWidget(label("Indices", "label"))
        board_header.addStretch(1)
        self.board_summary = label("", "caption")
        board_header.addWidget(self.board_summary)
        column.addLayout(board_header)
        view_box = QFrame(objectName="CountCard")
        self.view_rows = QVBoxLayout(view_box)
        self.view_rows.setContentsMargins(8, 8, 8, 8)
        self.view_rows.setSpacing(4)
        column.addWidget(view_box)
        self.page_rows = QVBoxLayout()
        self.page_rows.setSpacing(6)
        column.addLayout(self.page_rows)
        self.board = IndexBoard(c)
        column.addWidget(self.board)
        self.board_note = label("", "caption", wrap=True)
        column.addWidget(self.board_note)
        column.addStretch(1)

        scroller = QScrollArea()
        scroller.setWidget(side)
        scroller.setWidgetResizable(True)
        scroller.setFrameShape(QFrame.NoFrame)
        scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroller.setFixedWidth(424)
        return scroller

    # ----- updates the controller calls -----------------------------------
    def _wire_controls(self) -> None:
        for widget, signal in ((self.prev_button, self.previousRequested), (self.next_button, self.nextRequested),
                               (self.done_button, self.doneRequested), (self.finish_button, self.finishRequested),
                               (self.help_button, self.helpRequested), (self.fit_button, self.fitRequested),
                               (self.unused_button, self.unusedRequested), (self.problem_button, self.problemRequested)):
            widget.clicked.connect(signal.emit)
        self.rotate_left_button.clicked.connect(lambda: self.rotateRequested.emit(-1))
        self.rotate_right_button.clicked.connect(lambda: self.rotateRequested.emit(1))
        self.fewer_button.clicked.connect(lambda: self.countRequested.emit(-1))
        self.more_button.clicked.connect(lambda: self.countRequested.emit(1))
        self.canvas.layoutEdited.connect(self.layoutEdited.emit)
        self.canvas.sectionPicked.connect(self.sectionPicked.emit)
        self.canvas.cutRemoved.connect(self.cutRemoved.emit)
        self.board.cellClicked.connect(self.targetChosen.emit)
        keys = [(Qt.Key_Return, self.doneRequested.emit), (Qt.Key_Enter, self.doneRequested.emit),
                (Qt.Key_PageUp, self.previousRequested.emit), (Qt.Key_PageDown, self.nextRequested.emit),
                (Qt.Key_Tab, self.nextSectionRequested.emit), (Qt.Key_R, lambda: self.rotateRequested.emit(1)),
                (QKeySequence("Shift+R"), lambda: self.rotateRequested.emit(-1))]
        keys += [(Qt.Key_1 + k, lambda k=k: self.numberPressed.emit(k)) for k in range(9)]
        self._shortcuts = []
        for key, handler in keys:
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.activated.connect(handler)
            self._shortcuts.append(shortcut)

    def show_photo(self, image) -> None:
        self.canvas.set_image(image)

    def show_layout(self, layout, labels, selected, problems) -> None:
        self.canvas.show_layout(layout, labels, selected, problems)

    def set_whole_note(self, text: str) -> None:
        self.whole_note.setText(text)

    def set_unused(self, unused: bool) -> None:
        self.unused_button.setText("Use this section" if unused else "Leave section unused")

    def set_photo_title(self, name: str, position: int, total: int, done: int) -> None:
        self.photo_label.setText(f"{name}    {position} of {total}")
        self.photo_count_label.setText(f"{done} of {total} done")

    def set_photo_rows(self, rows: list[tuple[str, str, str, bool, object]]) -> None:
        """rows: (name, status, state 'done'/'proposed'/'new', current, click handler)."""
        c = self.colors
        _clear(self.photo_rows)
        for name, status, state, current, handler in rows:
            row = PhotoRow(objectName="PhotoRow")
            row.setCursor(Qt.PointingHandCursor)
            row.setFixedHeight(52)
            row.setStyleSheet(
                "QFrame#PhotoRow { border: none; border-radius: 0;"
                f" background: {self.colors.accent_faint if current else 'transparent'};"
                f" border-left: 3px solid {c.accent if current else 'transparent'}; }}"
                f" QFrame#PhotoRow:hover {{ background: {c.card}; }}")
            inner = QHBoxLayout(row)
            inner.setContentsMargins(13, 6, 12, 6)
            inner.setSpacing(10)
            thumb = QLabel()
            thumb.setPixmap(icon_pixmap("plate", c.text_muted, 26))
            thumb.setFixedSize(34, 34)
            thumb.setAlignment(Qt.AlignCenter)
            thumb.setStyleSheet(f"background: {c.canvas}; border-radius: 6px;")
            inner.addWidget(thumb)
            texts = QVBoxLayout()
            texts.setSpacing(1)
            title = QLabel(name)
            title.setStyleSheet("font-size: 13px; font-weight: 500; background: transparent;")
            sub = QLabel(status)
            color = c.accent_text if state == "done" else c.text_secondary if current else c.text_faint
            sub.setStyleSheet(f"font-size: 12px; color: {color}; background: transparent;")
            texts.addWidget(title)
            texts.addWidget(sub)
            inner.addLayout(texts, 1)
            for child in (thumb, title, sub):
                child.setAttribute(Qt.WA_TransparentForMouseEvents)
            row.clicked.connect(handler)
            self.photo_rows.addWidget(row)
        self.photo_rows.addStretch(1)

    def set_level_rows(self, target, rows: list[tuple[str, str, list[tuple[str, bool, object]], object]]) -> None:
        """rows: (variable name, link text, [(level, pressed, handler)], link handler)."""
        _clear(target)
        for name, link_text, options, link_handler in rows:
            line = QHBoxLayout()
            line.setSpacing(8)
            names = QVBoxLayout()
            names.setSpacing(0)
            names.addWidget(label(name, "secondary"))
            link = button(link_text, "link")
            link.setStyleSheet("padding: 0; font-size: 11px; text-decoration: underline;")
            link.clicked.connect(lambda _c=False, h=link_handler: h())
            names.addWidget(link, 0, Qt.AlignLeft)
            holder = QWidget()
            holder.setFixedWidth(108)
            holder.setLayout(names)
            line.addWidget(holder)
            line.addWidget(Segmented(options, self.colors, tooltip=name), 1)
            target.addLayout(line)

    def set_section_panel(self, title: str, state: str, problem: str, problem_action: str) -> None:
        self.section_title.setText(title)
        self.section_state.setText(state)
        self.problem_box.setVisible(bool(problem))
        self.problem_text.setText(problem)
        self.problem_button.setText(problem_action)

    def set_view_rows(self, rows: list[tuple[str, list[tuple[str, bool, object]]]]) -> None:
        _clear(self.view_rows)
        for name, options in rows:
            line = QHBoxLayout()
            line.addWidget(label(name, "caption"))
            line.addStretch(1)
            control = Segmented(options, self.colors, height=24, tooltip=f"Show {name} as")
            control.setFixedWidth(210)
            line.addWidget(control)
            self.view_rows.addLayout(line)

    def set_page_rows(self, rows: list[tuple[str, list[tuple[str, bool, object]]]]) -> None:
        _clear(self.page_rows)
        for name, options in rows:
            line = QHBoxLayout()
            line.addWidget(label(name, "caption"))
            line.addWidget(Segmented(options, self.colors, height=24, tooltip=name), 1)
            self.page_rows.addLayout(line)

    def set_board(self, board: Board, summary: str, note: str) -> None:
        self.board.set_board(board)
        self.board_summary.setText(summary)
        self.board_note.setText(note)

    def set_tools(self, hint: str, rotation: str, count: str, scale: str, circular: bool, can_confirm: bool,
                  confirm_text: str) -> None:
        self.hint_label.setText(hint)
        self.rotation_label.setText(rotation)
        self.count_label.setText(count)
        self.scale_label.setText(scale)
        self.fit_button.setVisible(circular)
        self.fewer_button.setToolTip("Remove a cut" if circular else "One column fewer")
        self.more_button.setToolTip("Add a cut" if circular else "One column more")
        self.done_button.setEnabled(can_confirm)
        self.done_button.setText(confirm_text)
        self._place_overlays(self.canvas.parentWidget())

    def ask_finish(self, missing: int, total: int, examples: list[str], unsaved: int) -> bool:
        """Warn about indices without a region (and unsaved photos) before finishing."""
        lines = []
        if unsaved:
            lines.append(f"{unsaved} photo{'s have' if unsaved != 1 else ' has'} changes that are not saved; "
                         "those changes will be dropped.")
        if missing:
            more = "\n  …" if missing > len(examples) else ""
            listed = "\n".join(f"  {e}" for e in examples)
            lines.append(f"{missing} of {total} indices have no region on any photo, so they will have no "
                         f"colonies:\n\n{listed}{more}")
        if not lines:
            return True
        return show_message(self, WARNING, "Finish cropping?", "\n\n".join(lines),
                            [("finish", "Finish anyway"), ("back", "Go back")], default="back") == "finish"

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)

    def fit_to_screen(self) -> None:
        available = self.screen().availableGeometry()
        width, height = self.theme.style.layout.window_size
        if width <= available.width() and height + 40 <= available.height():
            self.resize(width, height)
            self.move(available.center() - self.rect().center())
        else:
            self.setGeometry(available.adjusted(0, 40, 0, 0))
            self.showMaximized()

    def sizeHint(self) -> QSize:
        return QSize(*self.theme.style.layout.window_size)
