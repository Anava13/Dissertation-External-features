"""The index board (every index as a cell; rows, columns and pages hold any number of variables)
and the small dark-palette widgets around it. Used by Cropping and Colony Detection."""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QPushButton, QSizePolicy, QWidget

from ..core.cropping import Board

# state -> colors -> (fill, border, text, dashed)
STATE_STYLES = {
    # Cropping
    "confirmed": lambda c: (c.accent, c.accent, c.accent_ink, False),
    "proposed": lambda c: (c.board_waiting_fill, c.accent, c.accent_text, True),
    "partial": lambda c: (c.board_partial_fill, c.board_partial_edge, c.accent_text, False),
    "duplicate": lambda c: (c.board_duplicate_fill, c.danger, c.danger_text, True),
    "empty": lambda c: (c.window, c.border, c.text_disabled, False),
    # Colony Detection
    "detected": lambda c: (c.accent, c.accent, c.accent_ink, False),
    "waiting": lambda c: (c.board_waiting_fill, c.accent, c.accent_text, False),
    "review": lambda c: (c.board_review_fill, c.board_review_edge, c.board_review_text, False),
    "none": lambda c: (c.window, c.border, c.text_disabled, True),
}


class Segmented(QFrame):
    """A row of joined buttons; the pressed one is filled lime."""

    def __init__(self, options: list[tuple[str, bool, object]], colors, height: int = 28, tooltip: str = ""):
        super().__init__()
        self.setObjectName("Segmented")
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        self.buttons = []
        for text, on, handler in options:
            widget = QPushButton(text)
            widget.setCheckable(True)
            widget.setChecked(on)
            widget.setFixedHeight(height)
            widget.setCursor(Qt.PointingHandCursor)
            widget.setProperty("variant", "segment")
            widget.setStyleSheet(
                f"QPushButton {{ border: none; border-radius: 0; padding: 0 6px; min-height: {height}px;"
                f" font-size: 12px; background: {colors.window}; color: {colors.text_secondary}; }}"
                f" QPushButton:checked {{ background: {colors.accent}; color: {colors.accent_ink}; font-weight: 600; }}"
                f" QPushButton:hover:!checked {{ background: {colors.card}; }}")
            widget.clicked.connect(lambda _c=False, h=handler: h())
            if tooltip:
                widget.setToolTip(f"{tooltip}: {text}")
            row.addWidget(widget, 1)
            self.buttons.append(widget)
        self.setFixedHeight(height + 2)
        self.setStyleSheet(f"QFrame#Segmented {{ border: 1px solid {colors.border}; border-radius: 6px;"
                           " padding: 0; margin: 0; }")
        row.setContentsMargins(1, 1, 1, 1)


class PhotoRow(QFrame):
    clicked = Signal()

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.clicked.emit()


class IndexBoard(QWidget):
    """Every index as a cell, rows and columns holding any number of variables (from core.cropping.Board)."""

    cellClicked = Signal(object)         # the cell's target: (photo position, section) or (index id,)

    def __init__(self, colors, parent=None):
        super().__init__(parent)
        self.colors = colors
        self.board: Board | None = None
        self._cells: list[tuple[QRectF, object]] = []
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_board(self, board: Board) -> None:
        self.board = board
        self.setFixedHeight(self._height())
        self.update()

    def _metrics(self):
        board = self.board
        label_columns = max(1, len(board.row_labels[0]) if board.row_labels else 1)
        label_width = sum(self._label_widths())
        columns = len(board.cells[0]) if board.cells else 1
        cell_w = max(12.0, (self.width() - label_width - 2) / columns)
        cell_h = 22.0 if board.counted else 17.0
        header_h = 14.0 * len(board.header_rows)
        return label_width, cell_w, cell_h, header_h, label_columns

    def _label_widths(self) -> list[float]:
        font = QFont(self.font())
        font.setPixelSize(11)
        metrics = QFontMetricsF(font)
        columns = len(self.board.row_labels[0]) if self.board.row_labels else 1
        return [max([metrics.horizontalAdvance(r[d]) for r in self.board.row_labels if len(r) > d] + [0]) + 8
                for d in range(columns)]

    def _height(self) -> int:
        if not self.board:
            return 0
        _, _, cell_h, header_h, _ = self._metrics()
        return int(header_h + len(self.board.cells) * (cell_h + 3) + 4)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self.board:
            self.setFixedHeight(self._height())

    def paintEvent(self, event) -> None:
        if not self.board:
            return
        c = self.colors
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        label_width, cell_w, cell_h, header_h, label_columns = self._metrics()
        small = QFont(self.font())
        small.setPixelSize(10)
        painter.setFont(small)
        for depth, header in enumerate(self.board.header_rows):
            x = label_width
            for text, span in header:
                rect = QRectF(x, depth * 14, cell_w * span, 13)
                painter.setPen(QColor(c.text_faint))
                painter.drawText(rect, Qt.AlignCenter, text)
                if depth < len(self.board.header_rows) - 1:
                    painter.setPen(QPen(QColor(c.border), 1))
                    painter.drawLine(QPointF(x + 2, rect.bottom()), QPointF(x + cell_w * span - 2, rect.bottom()))
                x += cell_w * span
        self._cells = []
        label_font = QFont(self.font())
        label_font.setPixelSize(11)
        for r, (labels, line) in enumerate(zip(self.board.row_labels, self.board.cells)):
            y = header_h + r * (cell_h + 3)
            painter.setFont(label_font)
            x = 0.0
            for depth, (text, width) in enumerate(zip(labels, self._label_widths())):
                painter.setPen(QColor(c.text if depth == 0 else c.text_muted))
                painter.drawText(QRectF(x, y, width, cell_h), Qt.AlignVCenter | Qt.AlignLeft, text)
                x += width
            painter.setFont(small)
            for k, cell in enumerate(line):
                rect = QRectF(label_width + k * cell_w + 1.5, y, cell_w - 3, cell_h)
                fill, border, text_color, dashed = STATE_STYLES.get(cell.state, STATE_STYLES["empty"])(c)
                painter.setBrush(QColor(fill))
                pen = QPen(QColor(border), 1.3 if dashed else 1, Qt.DashLine if dashed else Qt.SolidLine)
                painter.setPen(pen)
                painter.drawRoundedRect(rect, 3, 3)
                if cell.current:
                    painter.setBrush(Qt.NoBrush)
                    painter.setPen(QPen(QColor(c.text), 2))
                    painter.drawRoundedRect(rect.adjusted(-1.5, -1.5, 1.5, 1.5), 4, 4)
                if cell.text:
                    painter.setPen(QColor(text_color))
                    painter.drawText(rect, Qt.AlignCenter, cell.text)
                self._cells.append((rect, cell))
        painter.end()

    def _cell_at(self, pos):
        for rect, cell in self._cells:
            if rect.contains(pos):
                return cell
        return None

    def mouseMoveEvent(self, event) -> None:
        cell = self._cell_at(event.position())
        self.setToolTip(cell.label if cell else "")
        self.setCursor(Qt.PointingHandCursor if cell and cell.target else Qt.ArrowCursor)

    def mousePressEvent(self, event) -> None:
        cell = self._cell_at(event.position())
        if cell and cell.target:
            self.cellClicked.emit(cell.target)
