"""ColonyDetectionController: connects the window (view) to the session (model).

Method names follow the MATLAB app in Python style, e.g. dropdownChanged ->
dropdown_changed, handleBackupAndDetection -> handle_backup_and_detection.

The controller holds the state that is not part of the record and is not
undoable: the current mode, colonies selected for deletion, circles drawn
but not yet added, and the region preview.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QTimer

from ..core import cropping as cp
from ..core.colony_set import ColonySet
from ..core.drawing import DrawnCircle, drawn_to_colonies, hit_test
from ..core.autoparams import estimate_parameters
from ..core.measurements import summarize_colonies
from ..core.messages import compose_message
from ..core.params import DetectionParams, validate_detection_parameters
from ..core.session import DetectionSession
from ..data import DataManager, ProjectError
from ..data.exports import export_problem
from .main_window import ColonyDetectionWindow
from .modes import DEFAULT_MODE, MODES
from .tools import AddIndividualTool, AddManyTool, DeleteIndividualTool, DeleteManyTool

def session_from_packet(packet) -> DetectionSession:
    """A session on a checked-out index: its saved result, or a fresh automatic detection.

    A new index starts from the settings of the last image finished in the project; before
    any image is finished, a project that asks for it estimates them from this image."""
    if packet.saved:
        session = DetectionSession(packet.record, packet.saved.params)
        session.load_saved(packet.saved)
        return session
    params = packet.defaults
    if packet.estimate:
        params = estimate_parameters(packet.record.image, packet.record.mask, params)
    session = DetectionSession(packet.record, params)
    session.initialize_detection()
    return session


DETECTION_DELAY_MS = 150          # wait for slider drags and clicks to settle before re-detecting
GROWTH_DELAY_MS = 400             # wait for edits to settle before measuring growth again
SELECTION_TOLERANCE = 2.0         # click within 2 radii of a center (isWithinSelectionTolerance)


class ColonyDetectionController:
    def __init__(self, session: DetectionSession, window: ColonyDetectionWindow, data_manager: DataManager,
                 review_reason: str = ""):
        self.session = session
        self.window = window
        self.data_manager = data_manager          # receives the result on "Finish image"
        self.leave_to = None                      # set by the navigator: called with 'stats' or 'project'
        self.label = session.record.display_label

        # Temporary interaction state
        self.mode = DEFAULT_MODE
        self.selected_ids: set[int] = set()
        self.selection_rect = None
        self.pending_circles: list[DrawnCircle] = []       # drawn, not yet added
        self.contour_enabled = False
        self.roi = None
        self.roi_params: DetectionParams | None = None
        self.candidates: ColonySet | None = None

        self._detection_timer = QTimer()
        self._detection_timer.setSingleShot(True)
        self._detection_timer.setInterval(DETECTION_DELAY_MS)
        self._detection_timer.timeout.connect(self.handle_backup_and_detection)
        self._region_timer = QTimer()
        self._region_timer.setSingleShot(True)
        self._region_timer.setInterval(DETECTION_DELAY_MS)
        self._region_timer.timeout.connect(self.update_region_detection)
        self._growth_timer = QTimer()
        self._growth_timer.setSingleShot(True)
        self._growth_timer.setInterval(GROWTH_DELAY_MS)
        self._growth_timer.timeout.connect(self.update_growth)

        colors = window.theme.style.colony
        canvas = window.tool_surface()
        self.tools = {
            "DeleteIndividualColonies": DeleteIndividualTool(canvas, self.handle_delete_click),
            "DeleteManyColonies": DeleteManyTool(canvas, self.highlight_colonies_in_rect, colors.selected),
            "AddIndividualColonies": AddIndividualTool(canvas, editor=self, guide_color=colors.manual),
            "AddManyColonies": AddManyTool(canvas, self.start_region_detection, colors.manual),
        }

        self._connect_signals()
        self._setup_navigation()
        self._bind(session, review_reason)

    def _bind(self, session: DetectionSession, review_reason: str = "") -> None:
        """Show one index: its image, its colonies and its settings."""
        self.session = session
        self.label = session.record.display_label
        self._clear_pending()
        session.subscribe(self._on_session_changed)
        self.window.show_image(session.image)
        self.window.set_growth(None)
        if self.window.growth_shown():
            self._growth_timer.start()
        self.window.set_spinner_values(session.params)
        self._show_position()
        self.notifyuser("ImageLoaded")
        if session.loaded_revision:
            self.notifyuser("LoadedSaved", (len(session.colonies), session.loaded_revision))
        else:
            self.notifyuser("DetectionResults", (len(session.colonies), session.params))
        if review_reason:
            self.notifyuser("NeedsReview", review_reason)
        self.select_dropdown_option(self.mode if self.mode in MODES else DEFAULT_MODE)

    # ----- moving between indices -----------------------------------------
    def _setup_navigation(self) -> None:
        """The index board (same rows / columns / pages view as Cropping) and the previous / next arrows."""
        w = self.window
        prefs = self.data_manager.module_preferences("detection")
        self.variables = list(self.data_manager.crop_packet().variables)
        cropping = self.data_manager.crop_packet().preferences.get("scope", {})
        scope = {v.name: cropping.get(v.name, cp.default_scope(self.variables)[v.name]) for v in self.variables}
        default_view = cp.default_view(self.variables, scope)
        self.view = {v.name: prefs.get("view", {}).get(v.name, default_view[v.name]) for v in self.variables}
        self.pages = {v.name: v.values[0] for v in self.variables}
        w.set_navigation(True, True)
        w.previousRequested.connect(lambda: self.step_index(-1))
        w.nextRequested.connect(lambda: self.step_index(1))
        w.boardRequested.connect(self.show_index_board)
        w.indexChosen.connect(self.open_index)
        w.set_close_guard(self.ready_to_leave)

    def index_status(self) -> list[tuple[int, tuple, str]]:
        """(index id, level values in variable order, 'waiting' / 'detected' / 'review') for every index with a
        region, in level order (last variable fastest)."""
        order = {key: i for i, key in enumerate(cp.all_index_keys(self.variables))}
        names = {v.display_name: v.name for v in self.data_manager.project_info().variables}
        found = []
        for index in self.data_manager.project_info().indices:
            if not index.has_region:
                continue
            levels = {names[label.variable]: label.value for label in index.labels}
            key = cp.index_key(levels, self.variables)
            state = "review" if index.needs_review else "detected" if index.revision else "waiting"
            found.append((index.index_id, key, state))
        return sorted(found, key=lambda item: order.get(item[1], len(order)))

    def _show_position(self) -> None:
        indices = self.index_status()
        ids = [i for i, _, _ in indices]
        current = self.session.record.index_id
        position = f"{ids.index(current) + 1} of {len(ids)}" if current in ids else ""
        record = self.session.record
        self.window.set_image_label(record.nominal_display, record.ordinal_display, position)
        self.window.set_navigation(True, len(ids) > 1)
        if self.window.board_open():
            self._fill_index_board()

    def _fill_index_board(self) -> None:
        indices = self.index_status()
        status = {key: (state, index_id) for index_id, key, state in indices}
        current = next((key for index_id, key, _ in indices if index_id == self.session.record.index_id), None)
        board = cp.build_status_board(self.variables, self.view, self.pages, status, current)
        places = {cp.ROWS: "Rows", cp.COLUMNS: "Columns", cp.PAGES: "Pages"}
        view_rows = [(v.display_name, [(places[p], self.view[v.name] == p, lambda v=v, p=p: self.set_board_view(v, p))
                                       for p in places]) for v in self.variables]
        page_rows = [(v.display_name, [(v.display(x), self.pages[v.name] == x,
                                        lambda v=v, x=x: self.set_board_page(v, x)) for x in v.values])
                     for v in self.variables if self.view[v.name] == cp.PAGES]
        counts = [state for _, _, state in indices]
        summary = f"{counts.count('detected')} of {len(indices)} detected"
        if counts.count("review"):
            summary += f" · {counts.count('review')} to review"
        note = "Click a cell to open that index. Page Up and Page Down step through the indices in level order."
        if board.counted:
            note = f"{board.counted} is counted inside each cell (too many columns to show it). " + note
        self.window.set_board(summary, view_rows, page_rows, board, note)

    def show_index_board(self) -> None:
        self._fill_index_board()
        self.window.show_index_popup()

    def set_board_view(self, variable, place: str) -> None:
        self.view[variable.name] = place
        self.data_manager.save_module_preferences("detection", {"view": self.view})
        self._fill_index_board()

    def set_board_page(self, variable, value: str) -> None:
        self.pages[variable.name] = value
        self._fill_index_board()

    def step_index(self, step: int) -> None:
        ids = [i for i, _, _ in self.index_status()]
        if not ids:
            return
        current = self.session.record.index_id
        position = ids.index(current) if current in ids else -1
        self.open_index(ids[(position + step) % len(ids)])

    def has_unsaved_edits(self) -> bool:
        return self.session.undo_depth() > 0

    def ready_to_leave(self) -> bool:
        """Ask about edits that are not saved; True when it is fine to leave this index."""
        if not self.has_unsaved_edits():
            return True
        answer = self.window.ask_save_before_leaving(self.session.record.display_label)
        if answer == "save":
            return self.im_satisfied_pushed(advance=False)
        return answer == "discard"

    def open_index(self, index_id: int) -> bool:
        """Leave the open index (asking about unsaved edits) and show another one."""
        self.window.hide_board()
        if index_id == self.session.record.index_id or not self.ready_to_leave():
            return False
        try:
            packet = self.data_manager.checkout_image(index_id)
        except ProjectError as error:
            self.window.report("Could not open the index", str(error))
            return False
        self._detection_timer.stop()
        self._region_timer.stop()
        self._growth_timer.stop()
        review = packet.saved.review_reason if packet.saved and packet.saved.needs_review else ""
        self._bind(session_from_packet(packet), review)
        return True

    # ----- wiring ---------------------------------------------------------
    def _connect_signals(self) -> None:
        w = self.window
        w.modeChosen.connect(self.dropdown_changed)
        w.settingEdited.connect(self.spinner_value_changing)
        w.shapeChosen.connect(self.detection_type_switch_value_changed)
        w.estimateRequested.connect(self.estimate_settings)
        w.deleteRequested.connect(self.delete_selected_colonies_button_pushed)
        w.addRequested.connect(self.add_selected_colonies_button_pushed)
        w.clearRequested.connect(self.clear_selection)
        w.contourToggled.connect(self.controller_contour_circle)
        w.growthToggled.connect(lambda _on: self.update_growth())
        w.undoRequested.connect(self.undo)
        w.redoRequested.connect(self.redo)
        w.finishRequested.connect(self.im_satisfied_pushed)
        w.helpRequested.connect(self.colony_detection_help)
        w.pointerMoved.connect(self._pointer_moved)

    def _pointer_moved(self, x: float, y: float) -> None:
        rows, cols = self.session.image.shape[:2]
        self.window.set_pointer(x, y, -0.5 <= x < cols - 0.5 and -0.5 <= y < rows - 0.5)

    def _on_session_changed(self, _event: str) -> None:
        self.window.set_spinner_values(self.session.params)
        self.display_colonies()
        self.window.set_growth(None)
        if self.window.growth_shown():
            self._growth_timer.start()                 # restarts while edits keep coming
        else:
            self.window.show_growth(None, None)

    def update_growth(self) -> None:
        """Measure growth on the current colonies; tint it on the image when Show is on."""
        from ..core.growth import growth_mask
        self._growth_timer.stop()
        session = self.session
        result = growth_mask(session.image, session.mask, session.colonies)
        self.window.set_growth(result.metrics())
        if self.window.growth_shown():
            self.window.show_growth(result.growth, result.colonies)
        else:
            self.window.show_growth(None, None)

    # ----- modes ----------------------------------------------------------
    def dropdown_changed(self, mode_key: str) -> None:
        if mode_key != self.mode:
            self.select_dropdown_option(mode_key)
        else:
            self.window.mode_buttons[mode_key].setChecked(True)

    def select_dropdown_option(self, mode_key: str) -> None:
        """Leave the current mode, enter the new one (handleInteractionSpecificActions)."""
        self._detection_timer.stop()
        self._region_timer.stop()
        if self.mode in self.tools:
            self.tools[self.mode].deactivate()
        self._clear_pending()
        self.mode = mode_key
        spec = MODES[mode_key]
        self.window.set_tool(self.tools.get(mode_key))
        self.window.set_spinner_values(self.session.params)
        self.window.update_mode_specific_view(spec)
        self.display_colonies()

    def _clear_pending(self) -> None:
        self.selected_ids.clear()
        self.selection_rect = None
        self.pending_circles.clear()
        self.roi = None
        self.roi_params = None
        self.candidates = None

    def clear_selection(self) -> None:
        """Esc: drop the selection, the deletion box, or the detection region."""
        self.selected_ids.clear()
        self.selection_rect = None
        if self.roi is not None:
            self.roi = None
            self.roi_params = None
            self.candidates = None
            self.window.set_spinner_values(self.session.params)
        self.display_colonies()

    # ----- automatic detection (settings) ---------------------------------
    def spinner_value_changing(self, field_name: str, value: float) -> None:
        if MODES[self.mode].region_parameters:
            base = self.roi_params or self.session.params
            self.roi_params = base.with_value(field_name, value)
            self._region_timer.start()
            return
        self._detection_timer.start()       # restarts while the user keeps changing values

    def estimate_settings(self) -> None:
        """Estimate the settings from this image and rerun detection with them (undoable)."""
        self._detection_timer.stop()
        params = self.session.estimated_parameters()
        if params == self.session.params:
            self.notifyuser("SettingsAlreadyEstimated")
            return
        self._clear_pending()
        count = self.session.detect_colonies(params)
        self.notifyuser("SettingsEstimated", (count, params))

    def detection_type_switch_value_changed(self, kind: str) -> None:
        if MODES[self.mode].region_parameters:
            base = self.roi_params or self.session.params
            self.roi_params = base.with_value("detection_type", kind)
            self.update_region_detection()
        else:
            self.handle_backup_and_detection()

    def _params_from_controls(self) -> DetectionParams:
        return DetectionParams(**self.window.settings())

    def handle_backup_and_detection(self) -> None:
        """Validate the settings, then rerun detection as an undoable command."""
        params = self._params_from_controls()
        if params == self.session.params:
            return
        error = validate_detection_parameters(params)
        if error:
            self.notifyuser("ParameterError", error)
            self.window.set_spinner_values(self.session.params)
            return
        self._clear_pending()
        count = self.session.detect_colonies(params)
        self.notifyuser("DetectionResults", (count, params))

    # ----- Delete colonies (one at a time) -------------------------------
    def handle_delete_click(self, x: float, y: float) -> None:
        colonies = self.session.colonies
        index, distance = colonies.nearest((x, y))
        if index < 0 or distance > SELECTION_TOLERANCE * colonies.radii[index]:
            self.notifyuser("ClickNotCloseEnough")
            return
        colony_id = int(colonies.ids[index])
        if colony_id in self.selected_ids:
            self.selected_ids.discard(colony_id)
            self.notifyuser("ColonyDeselected", colonies.centers[index])
        else:
            self.selected_ids.add(colony_id)
            self.notifyuser("ColonySelected", colonies.centers[index])
        self.display_colonies()

    # ----- Delete a region ------------------------------------------------
    def highlight_colonies_in_rect(self, x0: float, y0: float, x1: float, y1: float) -> None:
        ids = self.session.colonies.ids_in_rect(x0, y0, x1, y1)
        self.selected_ids = {int(i) for i in ids}
        self.selection_rect = (x0, y0, x1, y1)
        self.notifyuser("RectangleSelectionCount", len(ids))
        self.display_colonies()

    def delete_selected_colonies_button_pushed(self) -> None:
        if not self.selected_ids:
            self.notifyuser("NoColoniesSelected")
            return
        deleted = self.session.delete_colonies(sorted(self.selected_ids))
        self.selected_ids.clear()
        self.selection_rect = None
        self.notifyuser("ColoniesDeleted", (deleted, len(self.session.colonies)))
        self.display_colonies()

    # ----- Add colonies (the tool's CircleEditor interface) --------------
    def hit_test_circle(self, x: float, y: float, edge_tolerance: float) -> tuple[int, str]:
        return hit_test(self.pending_circles, x, y, edge_tolerance)

    def circle_geometry(self, index: int) -> tuple[float, float, float]:
        circle = self.pending_circles[index]
        return circle.x, circle.y, circle.r

    def add_new_circle(self, x: float, y: float, r: float) -> int:
        """Start a new circle; the tool then sizes it with update_circle (addNewCircle)."""
        self.pending_circles.append(DrawnCircle(x, y, r))
        self.display_colonies()
        return len(self.pending_circles) - 1

    def update_circle(self, index: int, x: float, y: float, r: float, final: bool) -> None:
        """Move or resize a drawn circle. The contour is refitted when the drag ends."""
        circle = self.pending_circles[index]
        circle = circle.moved_to(x, y) if (x, y) != (circle.x, circle.y) else circle
        circle = circle.resized_to(r) if r != circle.r else circle.without_contour()
        if final and self.contour_enabled:
            circle = self._contour(circle)
        self.pending_circles[index] = circle
        self.display_colonies()

    def describe_radius(self, r: float) -> str:
        """Radius readout next to the pointer while drawing."""
        um = r / self.session.px_per_mm * 1000 if self.session.px_per_mm else None
        return f"r {r:.1f} px" + (f" · {um:,.0f} µm" if um is not None else "")

    def remove_circle(self, index: int) -> None:
        del self.pending_circles[index]
        self.notifyuser("CircleRemoved")
        self.display_colonies()

    def controller_contour_circle(self, enabled: bool) -> None:
        """Snap-to-edge switch (Controller_ContourCircle): fit or clear outlines on every drawn circle."""
        self.contour_enabled = enabled
        self.notifyuser("ContourOn" if enabled else "ContourOff")
        if enabled:
            self.pending_circles = [self._contour(circle) for circle in self.pending_circles]
        else:
            self.pending_circles = [circle.without_contour() for circle in self.pending_circles]
        self.display_colonies()

    def _contour(self, circle: DrawnCircle) -> DrawnCircle:
        fitted = circle.with_contour(self.session.image, self.session.mask)
        if not fitted.contour.found:
            self.notifyuser("ContourFailed", fitted.contour.reason)
        return fitted

    # ----- Detect in a region ---------------------------------------------
    def start_region_detection(self, x0: float, y0: float, x1: float, y1: float) -> None:
        self.roi = (min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0))
        self.roi_params = self.roi_params or self.session.params
        self.update_region_detection()

    def update_region_detection(self) -> None:
        if self.roi is None:
            return
        self.candidates = self.session.preview_region_detection(self.roi_params, self.roi)
        self.notifyuser("RegionCandidates", len(self.candidates))
        self.display_colonies()

    def add_selected_colonies_button_pushed(self) -> None:
        if self.mode == "AddManyColonies":
            new = self.candidates if self.candidates is not None else ColonySet.empty()
        else:
            new = drawn_to_colonies(self.pending_circles)
        if len(new) == 0:
            self.notifyuser("NothingToAdd")
            return
        added = self.session.add_colonies(new, skip_overlapping=self.mode == "AddManyColonies")
        self.pending_circles.clear()
        self.candidates = None
        self.roi = None
        self.notifyuser("ColoniesAdded", (added, len(new) - added, len(self.session.colonies)))
        self.display_colonies()

    # ----- undo / redo ----------------------------------------------------
    def undo(self) -> None:
        self._clear_pending()
        command = self.session.undo()
        if command is None:
            self.notifyuser("NoUndoActions")
            return
        self.notifyuser("Undo", self._describe(command))

    def redo(self) -> None:
        self._clear_pending()
        command = self.session.redo()
        if command is None:
            self.notifyuser("NoRedoActions")
            return
        self.notifyuser("Redo", self._describe(command))

    @staticmethod
    def _describe(command) -> str:
        noun = "colony" if command.count == 1 else "colonies"
        verbs = {"Detection": "detection of", "Deletion": "deletion of", "Addition": "addition of"}
        return f"{verbs.get(command.kind, command.kind.lower())} {command.count} {noun}"

    # ----- finishing ------------------------------------------------------
    @property
    def output_folder(self) -> Path:
        return self.data_manager.exports_folder

    def im_satisfied_pushed(self, advance: bool = True) -> bool:
        """Send the working copy to the DataManager, which stores it as the truth and exports
        the measurement table, then open the next index waiting for detection or review
        (FinishColonySetAndNavigate). Returns whether the save worked."""
        index_id = self.session.record.index_id
        try:
            revision = self.data_manager.commit_detection(self.session.result())
        except (ProjectError, OSError) as error:
            self.window.report("Could not save", str(error))
            return False
        self.session.mark_committed(revision)              # saved in the project, whatever happens to the export
        self.data_manager.request_derived("plate_coverage", index_id)   # measured once, kept
        try:
            path = self.data_manager.export_colonies_csv(index_id)
            exported = f"{path.parent.name}/{path.name}"
        except OSError as error:
            exported = "the colony table was not exported"
            self.notifyuser("ExportFailed", export_problem(error, self.data_manager.exports_folder))
        self.notifyuser("Saved", (len(self.session.colonies), revision, exported))
        self._show_position()
        if advance:
            indices = self.index_status()
            ids = [i for i, _, _ in indices]
            current = ids.index(self.session.record.index_id) if self.session.record.index_id in ids else -1
            following = indices[current + 1:] + indices[:current + 1]
            waiting = next((i for i, _, state in following if state in ("waiting", "review")), None)
            if waiting is not None:
                self.open_index(waiting)
            else:
                self.all_indices_detected(len(ids))
        return True

    def all_indices_detected(self, count: int) -> None:
        """Nothing is left to detect or review: offer Stats or the project page."""
        self.notifyuser("AllDetected")
        if self.leave_to is None:                 # no navigator (a module opened on its own)
            return
        choice = self.window.ask_all_detected(count)
        if choice in ("stats", "project"):
            self.leave_to(choice)

    def colony_detection_help(self) -> None:
        from .help import show_help
        show_help("detection", self.window)

    # ----- display --------------------------------------------------------
    def notifyuser(self, message_key: str, value=None) -> None:
        message = compose_message(message_key, self.label, value)
        if message.kind:
            self.window.add_activity(message.kind, message.text, message.detail)
        else:
            self.window.show_status(message.text)

    def display_colonies(self) -> None:
        self.window.draw_colonies(
            self.session.colonies,
            selected_ids=self.selected_ids,
            pending_circles=self.pending_circles,
            candidates=self.candidates,
            selection_rect=self.selection_rect,
            region_rect=(None if self.roi is None else
                         (self.roi[0], self.roi[1], self.roi[0] + self.roi[2], self.roi[1] + self.roi[3])),
            dim_existing=self.mode == "AddManyColonies" and self.roi is not None,
        )
        self.window.set_history(self.session.can_undo(), self.session.can_redo(), self.session.undo_depth())
        self.window.set_interaction_state(
            selected=len(self.selected_ids), box=self.selection_rect is not None,
            pending=len(self.pending_circles), region=self.roi is not None,
            candidates=None if self.candidates is None else len(self.candidates))
        self.window.set_summary(summarize_colonies(self.session.colonies, self.session.px_per_mm))
