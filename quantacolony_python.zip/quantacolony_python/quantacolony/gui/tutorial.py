"""The tutorial panel: a small window that stays above every screen and walks through the
Crowding project, one step at a time (steps and checks in core/tutorial.py).

TutorialWindow is the view; TutorialController asks the navigator what is on screen twice a
second, ticks off a step when its task is done and shows what the result means. Progress is
kept in settings.json (on this computer).
"""

from __future__ import annotations

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLayout, QVBoxLayout, QWidget

from ..core.tutorial import STEPS, is_done, step_index
from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .light import light_button, light_label

POLL_MS = 500
WIDTH = 380


class TutorialWindow(QWidget):
    """View. Controllers use only its signals and show_step."""

    backRequested = Signal()
    nextRequested = Signal()
    closeRequested = Signal()

    def __init__(self, theme: Theme):
        super().__init__(None, Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        light = theme.style.light
        self.light = light
        self.setStyleSheet(build_light_stylesheet(light, theme.ui_family, theme.brand_family)
                           + f"\nQWidget#LightWindow {{ background: {light.page}; }}")
        self.setWindowTitle("QuantaColony · Tutorial")
        self.setWindowIcon(app_icon())
        column = QVBoxLayout(self)
        column.setSizeConstraint(QLayout.SetFixedSize)          # the window is as tall as its text
        column.setContentsMargins(18, 16, 18, 14)
        column.setSpacing(10)
        self.where = light_label("", "small")
        column.addWidget(self.where)
        self.title = light_label("", "h2", wrap=True)
        column.addWidget(self.title)
        task_box = QFrame(objectName="LightPanel")
        task_column = QVBoxLayout(task_box)
        task_column.setContentsMargins(12, 10, 12, 10)
        task_column.setSpacing(4)
        task_column.addWidget(light_label("DO THIS", "section"))
        self.task = light_label("", "body", wrap=True)
        self.task.setFixedWidth(WIDTH - 36 - 24)
        task_column.addWidget(self.task)
        column.addWidget(task_box)
        self.status = light_label("", "small")
        column.addWidget(self.status)
        self.finding = light_label("", "body", wrap=True)
        column.addWidget(self.finding)
        for label in (self.title, self.finding):              # a fixed width lets wrapped text report its height
            label.setFixedWidth(WIDTH - 36)
        column.addStretch(1)
        row = QHBoxLayout()
        self.close_button = light_button("Close", "quiet", "Close the tutorial; Start tutorial on the home page "
                                                           "comes back to this step")
        row.addWidget(self.close_button)
        row.addStretch(1)
        self.back_button = light_button("Back", None)
        self.next_button = light_button("Next", "primary")
        row.addWidget(self.back_button)
        row.addWidget(self.next_button)
        column.addLayout(row)
        self.back_button.clicked.connect(self.backRequested.emit)
        self.next_button.clicked.connect(self.nextRequested.emit)
        self.close_button.clicked.connect(self.closeRequested.emit)

    def show_step(self, number: int, total: int, module: str, title: str, task: str, finding: str,
                  done: bool, reading: bool) -> None:
        """reading: a step without a task to check (its text shows at once)."""
        self.where.setText(f"Step {number} of {total} · {module}")
        self.title.setText(title)
        self.task.setText(task)
        self.status.setText("" if reading else (f"<span style='color:{self.light.link}; font-weight:600'>✓ Done.</span> "
                                                "What this shows:" if done else "Waiting for you to do this…"))
        self.finding.setText(finding if done or reading else "")
        self.finding.setVisible(done or reading)
        self.back_button.setEnabled(number > 1)
        self.next_button.setText("Finish" if number == total else "Next")
        self.next_button.setProperty("variant", "primary" if done or reading else None)
        self.next_button.style().unpolish(self.next_button)
        self.next_button.style().polish(self.next_button)
        for label in (self.title, self.task, self.finding):      # wrapped text: as tall as it needs
            label.ensurePolished()
            label.setMinimumHeight(label.heightForWidth(label.width()) if label.text() else 0)
        self.adjustSize()

    def place_beside(self, screen_geometry) -> None:
        """At the right edge of the screen, near the top, where the module windows leave room."""
        self.adjustSize()
        self.move(screen_geometry.right() - self.width() - 24, screen_geometry.top() + 80)


class TutorialController(QObject):
    """Checks the current step against the screen (navigator.tutorial_state) and moves through STEPS."""

    finished = Signal()

    def __init__(self, navigator, window: TutorialWindow):
        super().__init__()
        self.navigator = navigator
        self.window = window
        settings = navigator.manager.settings
        self.position = step_index(settings.tutorial_step) if settings.tutorial_step else 0
        self.done = {key for key in settings.tutorial_done if any(step.key == key for step in STEPS)}
        window.backRequested.connect(lambda: self.go(self.position - 1))
        window.nextRequested.connect(self.next)
        window.closeRequested.connect(self.close)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.poll)
        self.timer.start(POLL_MS)
        self.poll()

    @property
    def step(self):
        return STEPS[self.position]

    def poll(self) -> None:
        step = self.step
        if step.key not in self.done and is_done(step, self.navigator.tutorial_state()):
            self.done.add(step.key)
            self._save()
        self._show()

    def _show(self) -> None:
        step = self.step
        self.window.show_step(self.position + 1, len(STEPS), step.module, step.title, step.task, step.finding,
                              step.key in self.done, step.done is None)

    def go(self, position: int) -> None:
        self.position = max(0, min(position, len(STEPS) - 1))
        self._save()
        self.poll()

    def next(self) -> None:
        if self.position == len(STEPS) - 1:
            self.position, self.done = 0, set()            # a finished tutorial starts over next time
            self._save()
            self.close()
            self.finished.emit()
            return
        self.go(self.position + 1)

    def _save(self) -> None:
        self.navigator.manager.settings.set_tutorial(self.step.key, self.done)

    def close(self) -> None:
        self.timer.stop()
        self.window.close()
