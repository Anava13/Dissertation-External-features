"""Navigator: which screen is open. One window at a time, as in MATLAB QuantaColony.

    Home page (projects)  ->  project page  ->  Cropping / Colony Detection / Stats
                          <-                <-  closing a module, or its Back button

Closing the home page or the project page quits; closing a module returns to the
project page. The DataManager keeps one project open while its page or a module is
showing, and closes it (leaving a backup when it changed) on the way back home.
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, QTimer
from PySide6.QtWidgets import QApplication

from ..data import DataManager, ProjectError
from .home import HomeController, HomeWindow
from .launch import open_cropping, open_detection, open_stats
from .project_page import ProjectController, ProjectWindow
from .dialogs import ERROR, notify


class Navigator(QObject):
    def __init__(self, app: QApplication, theme, manager: DataManager):
        super().__init__()
        self.app = app
        self.theme = theme
        self.manager = manager
        self.window = None
        self.controller = None
        self.screen = ""                 # 'home', 'project' or a module name
        self._previous_screen = ""
        self._switching = False
        app.setQuitOnLastWindowClosed(False)

    # ----- screens --------------------------------------------------------
    def show_home(self) -> None:
        self.manager.close()
        window = HomeWindow(self.theme)
        controller = HomeController(self.manager, window, can_create=True)
        controller.openProject.connect(self.open_project)
        controller.newProject.connect(self.show_new_project)
        self._show(window, controller, "home")

    def show_new_project(self) -> None:
        from .new_project import NewProjectController, NewProjectWindow
        self.manager.close()
        window = NewProjectWindow(self.theme)
        controller = NewProjectController(self.manager, window)
        controller.cancelled.connect(self.show_home)
        controller.created.connect(self._project_created)
        self._show(window, controller, "new")

    def _project_created(self, project_id: str) -> None:
        """The wizard leaves the new project open: its page, then Cropping."""
        self.show_project()
        self.open_module("cropping")

    def open_project(self, project_id: str) -> None:
        try:
            self.manager.open_project(project_id)
        except ProjectError as error:
            notify(self.window, ERROR, "Could not open the project", str(error))
            return
        self.show_project()

    def show_project(self) -> None:
        window = ProjectWindow(self.theme, self.manager.project_info().name)
        controller = ProjectController(self.manager, window)
        controller.openModule.connect(self.open_module)
        controller.showProjects.connect(self.show_home)
        self._show(window, controller, "project")

    def open_module(self, name: str) -> None:
        builders = {"cropping": open_cropping, "detection": open_detection, "stats": open_stats}
        try:
            window, controller = builders[name](self.manager, self.theme)
        except ProjectError as error:
            notify(self.window, ERROR, "Could not open", str(error))
            return
        if name == "cropping":
            controller.finished.connect(lambda: self.open_module("detection"))
        if name == "detection":
            controller.leave_to = lambda target: (QTimer.singleShot(0, lambda: self.open_module("stats"))
                                                  if target == "stats" else QTimer.singleShot(0, self.show_project))
        if name == "stats":
            window.backRequested.connect(self.show_project)
        self._show(window, controller, name)

    # ----- window switching -------------------------------------------------
    def _show(self, window, controller, screen: str) -> None:
        previous = self.window
        self._previous_screen = self.screen
        self.window, self.controller, self.screen = window, controller, screen
        window.installEventFilter(self)
        pages = ("home", "project", "new")
        if hasattr(window, "fit_to_screen"):                       # photo modules size themselves
            window.fit_to_screen()
        elif previous is not None and self._previous_screen in pages and screen in pages:
            window.setGeometry(previous.geometry())                # page to page: keep the place
        else:
            available = window.screen().availableGeometry()
            window.resize(min(window.width(), available.width()), min(window.height(), available.height() - 40))
            window.move(available.center() - window.rect().center())
        if not window.isVisible():
            window.show()
        window.raise_()
        window.activateWindow()
        if previous is not None:
            self._switching = True
            previous.close()
            previous.deleteLater()
            self._switching = False

    def eventFilter(self, watched, event) -> bool:
        if event.type() == QEvent.Close and watched is self.window and not self._switching:
            # Act once the close has happened: a window can refuse it (unsaved colonies)
            QTimer.singleShot(0, lambda w=watched: self._closed(w))
        return False

    def _closed(self, window) -> None:
        if window is not self.window or window.isVisible():
            return
        if self.screen in ("home", "project"):
            self.app.quit()
        elif self.screen == "new":
            self.show_home()                       # closing the wizard cancels it
        else:
            self.show_project()                    # a module closed: back to its project
