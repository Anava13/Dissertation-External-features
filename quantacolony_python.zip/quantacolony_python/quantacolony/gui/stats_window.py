"""StatsWindow: the Stats module (view, light palette).

Left: the analyses (built-in and plug-ins). Top left: the variables, which collapse to a
one-line summary. "Color by" is a drop-down; each variable is one row with its slot and a
"levels" button that opens a pop-up of its levels (each shown or hidden, with its color when it
is the color variable). Top right: the normalization, measure and options of the chosen
analysis. Middle: the figure. Bottom:
notes (normalization notes, fit summaries, plug-in problems).
"""

from __future__ import annotations

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import (QAbstractItemView, QColorDialog, QComboBox, QDialog, QFileDialog, QFrame, QGridLayout,
                               QHBoxLayout, QHeaderView, QListWidget, QListWidgetItem, QMainWindow, QPlainTextEdit,
                               QScrollArea, QSizePolicy, QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .banner import back_button
from .light import L, LevelChips, LightSegmented, clear_layout, light_button, light_header, light_label
from .dialogs import ERROR, notify


MAX_SEGMENTS = 4                                # more choices than this show as a drop-down
ROW_NAME_WIDTH = 120                            # variable names column in the variables panel

class LevelsPopup(QFrame):
    """The levels of one variable, opened from its row: click a level to hide or show it, a color
    square to change its color. It stays open while levels change (the window refills it)."""

    def __init__(self, parent: QWidget):
        super().__init__(parent, Qt.Popup)
        self.setObjectName("LevelsPopup")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet(f"QFrame#LevelsPopup {{ background: {L.surface}; border: 1px solid {L.border}; "
                           "border-radius: 8px; }")
        self.variable = ""
        self.column = QVBoxLayout(self)
        self.column.setContentsMargins(14, 12, 14, 12)
        self.column.setSpacing(8)

    def fill(self, variable: str, title: str, levels: list[tuple], summary: str, show_all) -> None:
        self.variable = variable
        clear_layout(self.column)
        head = QHBoxLayout()
        head.addWidget(light_label(title, "field"))
        head.addStretch(1)
        if summary:
            reset = light_button("Show all", "quiet", f"Show every level of {title}")
            reset.clicked.connect(lambda _c=False, h=show_all: h())
            head.addWidget(reset)
        self.column.addLayout(head)
        self.column.addWidget(LevelChips(levels, tooltip=title))
        hint = "Click a level to hide or show it."
        if any(level[3] for level in levels):
            hint += " Click a color square to change its color."
        self.column.addWidget(light_label(hint, "small", wrap=True))
        self.adjustSize()


class StatsWindow(QMainWindow):
    """The Stats module's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    analysisChosen = Signal(str)
    variablesToggled = Signal(bool)            # True: collapse the variables to their summary
    helpRequested = Signal()
    saveFigureRequested = Signal()
    saveTableRequested = Signal()
    pluginsFolderRequested = Signal()
    backRequested = Signal()

    def __init__(self, theme: Theme, project_name: str, analyses: list[tuple[str, list[tuple[str, str]]]] = ()):
        """analyses: (section title, [(key, label)]); set_analyses can replace them later."""
        super().__init__()
        self.theme = theme
        self.setObjectName("LightWindow")
        self.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family))
        self.setWindowTitle(f"QuantaColony · Stats · {project_name}")
        self.setWindowIcon(app_icon())
        self.resize(1440, 900)

        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        self.back_button = back_button()
        header, header_row = light_header(theme, ["Projects", project_name, "Stats"], back=self.back_button)
        self.help_button = light_button("Help", "header")
        header_row.addWidget(self.help_button)
        column.addWidget(header)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._analysis_list(analyses))
        body.addWidget(self._main_area(), 1)
        column.addLayout(body, 1)
        self.setCentralWidget(root)
        for widget, signal in ((self.help_button, self.helpRequested), (self.back_button, self.backRequested),
                               (self.save_figure_button, self.saveFigureRequested),
                               (self.save_table_button, self.saveTableRequested),
                               (self.plugins_button, self.pluginsFolderRequested)):
            widget.clicked.connect(signal.emit)

    # ----- construction ---------------------------------------------------
    def _analysis_list(self, analyses) -> QFrame:
        side = QFrame(objectName="LightSide")
        side.setFixedWidth(240)
        layout = QVBoxLayout(side)
        layout.setContentsMargins(0, 16, 0, 16)
        layout.setSpacing(0)
        self.analysis_list = QListWidget()
        self.analysis_list.setFocusPolicy(Qt.StrongFocus)
        self._keys: dict[str, QListWidgetItem] = {}
        self.analysis_list.currentItemChanged.connect(
            lambda item, _old: item is not None and item.data(Qt.UserRole) and self.analysisChosen.emit(
                item.data(Qt.UserRole)))
        layout.addWidget(self.analysis_list, 1)
        self.set_analyses(list(analyses))
        self.plugins_button = light_button("Analyses folder…", "quiet",
                                           "Open the folder where your own analysis plug-ins go")
        layout.addWidget(self.plugins_button, 0, Qt.AlignLeft)
        return side

    def _main_area(self) -> QWidget:
        area = QWidget()
        column = QVBoxLayout(area)
        column.setContentsMargins(24, 18, 24, 18)
        column.setSpacing(14)

        top = QHBoxLayout()
        self.title = light_label("", "h1")
        top.addWidget(self.title)
        top.addStretch(1)
        self.save_table_button = light_button("Save table (CSV)", None)
        self.save_figure_button = light_button("Save figure…", "primary")
        top.addWidget(self.save_table_button)
        top.addWidget(self.save_figure_button)
        column.addLayout(top)
        self.description = light_label("", "body", wrap=True)
        column.addWidget(self.description)

        controls = QFrame(objectName="LightPanel")
        controls.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)   # never taller than its contents
        panel = QVBoxLayout(controls)
        panel.setContentsMargins(16, 10, 16, 12)
        panel.setSpacing(8)
        head = QHBoxLayout()
        self.variables_toggle = light_button("▾  PLOT SETUP", "quiet", "Collapse the plot setup to a one-line summary")
        self.variables_toggle.setStyleSheet(f"QPushButton {{ padding: 0; min-height: 0; font-size: 11px; "
                                            f"font-weight: 700; letter-spacing: 1px; color: {L.text_secondary}; "
                                            "background: transparent; border: none; text-align: left; }")
        self.variables_toggle.setCursor(Qt.PointingHandCursor)
        self.variables_toggle.clicked.connect(lambda: self.variablesToggled.emit(not self.variables_collapsed))
        head.addWidget(self.variables_toggle)
        self.variables_summary = light_label("", "small", wrap=True)
        self.variables_summary.setVisible(False)
        head.addWidget(self.variables_summary, 1)
        panel.addLayout(head)
        self.variables_collapsed = False

        self.variables_body = QWidget()
        grid = QGridLayout(self.variables_body)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(28)
        grid.setVerticalSpacing(6)
        left, right = QVBoxLayout(), QVBoxLayout()
        left.setSpacing(6)
        right.setSpacing(6)
        # left: what each variable does in the plot, then which of its levels are used
        left.addWidget(light_label("SPLIT THE PLOT BY", "section"))
        self.role_rows = QVBoxLayout()
        self.role_rows.setSpacing(4)
        left.addLayout(self.role_rows)
        self.pooled_note = light_label("", "small", wrap=True)
        left.addWidget(self.pooled_note)
        self.color_row = QHBoxLayout()
        self.color_row.setSpacing(10)
        left.addLayout(self.color_row)
        self.color_note = light_label("", "small", wrap=True)
        self.color_note.setVisible(False)
        left.addWidget(self.color_note)
        self.slot_problem = light_label("", None, wrap=True)
        self.slot_problem.setProperty("state", "bad")
        left.addWidget(self.slot_problem)
        left.addSpacing(6)
        left.addWidget(light_label("PLATES USED", "section"))
        left.addWidget(light_label("Plates with a level switched off are left out of the plot.", "small", wrap=True))
        self.slot_rows = QVBoxLayout()                      # one row per variable: the levels used
        self.slot_rows.setSpacing(4)
        left.addLayout(self.slot_rows)
        left.addStretch(1)
        # right: plate rules, then the analysis settings
        right.addWidget(light_label("PLATE RULES", "section"))
        self.rule_rows = QVBoxLayout()
        self.rule_rows.setSpacing(6)
        right.addLayout(self.rule_rows)
        right.addSpacing(6)
        right.addWidget(light_label("SETTINGS", "section"))
        self.setting_rows = QVBoxLayout()
        self.setting_rows.setSpacing(6)
        right.addLayout(self.setting_rows)
        right.addStretch(1)
        grid.addLayout(left, 0, 0, Qt.AlignTop)
        grid.addLayout(right, 0, 1, Qt.AlignTop)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        panel.addWidget(self.variables_body)
        self.levels_popup = LevelsPopup(self)
        self._rows: dict = {}
        column.addWidget(controls)

        splitter = QSplitter(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        self.figure = Figure(figsize=(12, 7), facecolor=self.theme.style.plot.background)
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.figure_scroller = QScrollArea()
        self.figure_scroller.setWidget(self.canvas)
        self.figure_scroller.setWidgetResizable(True)
        light = self.theme.style.light
        self.figure_scroller.setStyleSheet(f"QScrollArea {{ background: {light.surface}; border: 1px solid "
                                           f"{light.border}; border-radius: 6px; }}")
        splitter.addWidget(self.figure_scroller)
        self.notes = QPlainTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setPlaceholderText("Notes about the current analysis appear here.")
        splitter.addWidget(self.notes)
        splitter.setSizes([760, 90])
        column.addWidget(splitter, 1)
        return area

    # ----- updates the controller calls -----------------------------------
    def select_analysis(self, key: str) -> None:
        item = self._keys.get(key)
        if item is not None and self.analysis_list.currentItem() is not item:
            self.analysis_list.blockSignals(True)
            self.analysis_list.setCurrentItem(item)
            self.analysis_list.blockSignals(False)

    def set_heading(self, title: str, description: str) -> None:
        self.title.setText(title)
        self.description.setText(description)

    def set_analyses(self, analyses: list[tuple[str, list[tuple[str, str]]]]) -> None:
        """Rebuild the analysis list: (section title, [(id, name)])."""
        self.analysis_list.blockSignals(True)
        self.analysis_list.clear()
        self._keys = {}
        for section, items in analyses:
            title = QListWidgetItem(section.upper())
            title.setFlags(Qt.NoItemFlags)
            font = title.font()
            font.setPixelSize(11)
            font.setBold(True)
            title.setFont(font)
            title.setForeground(Qt.gray)
            self.analysis_list.addItem(title)
            for key, text in items:
                item = QListWidgetItem(text)
                item.setData(Qt.UserRole, key)
                self.analysis_list.addItem(item)
                self._keys[key] = item
        self.analysis_list.blockSignals(False)

    def set_color_by(self, options: list[tuple], note: str) -> None:
        """options: (text, chosen, handler) for "Analysis colors" and each variable; note: why the chosen
        variable cannot color this analysis ('' when it can)."""
        clear_layout(self.color_row)
        caption = light_label("Color by", "small")
        caption.setFixedWidth(ROW_NAME_WIDTH)
        self.color_row.addWidget(caption)
        menu = self._menu(options, True, "Color by")
        menu.setMinimumWidth(200)
        self.color_row.addWidget(menu)
        self.color_row.addStretch(1)
        self.color_note.setText(note)
        self.color_note.setVisible(bool(note))

    def set_roles(self, roles: list[tuple], pooled: str, problem: str) -> None:
        """roles: (title, description, chips) per part of the plot a variable can split it into; chips:
        (variable, in this role, handler, allowed). pooled: the sentence on variables that split nothing."""
        clear_layout(self.role_rows)
        for title, description, chips in roles:
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label(title, None)
            caption.setFixedWidth(ROW_NAME_WIDTH)
            caption.setToolTip(description)
            line.addWidget(caption)
            line.addWidget(LevelChips([(text, on, handler, None, None, allowed) for text, on, handler, allowed in chips],
                                      tooltip=title, off_color=L.text_secondary))
            line.addStretch(1)
            self.role_rows.addLayout(line)
            if description:
                note = light_label(description, "small", wrap=True)
                note.setContentsMargins(ROW_NAME_WIDTH + 10, 0, 0, 4)
                self.role_rows.addWidget(note)
        self.pooled_note.setText(pooled)
        self.pooled_note.setVisible(bool(pooled))
        self.slot_problem.setText(problem)
        self.slot_problem.setVisible(bool(problem))

    def set_slots(self, rows: list[tuple], problem: str | None = None) -> None:
        """rows: (variable name, its kind, level options: (level, shown, toggle handler, color or None,
        color handler or None), button text, filtered, show-all handler). One line per variable; its
        levels open in a pop-up from its button."""
        clear_layout(self.slot_rows)
        self._rows = {}
        for name, kind, levels, text, filtered, show_all in rows:
            summary = text if filtered else ""
            self._rows[name] = (levels, summary, show_all)
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label(name, None)
            caption.setFixedWidth(ROW_NAME_WIDTH)
            caption.setToolTip(f"{name} is a {kind} variable")
            caption.setText(caption.fontMetrics().elidedText(name, Qt.ElideRight, ROW_NAME_WIDTH))
            line.addWidget(caption)
            colored = any(level[3] for level in levels)
            button = light_button(f"{text}{'  ●' if colored else ''}  ▾", None,
                                  f"Choose which levels of {name} are used{' and their colors' if colored else ''}")
            if filtered:
                button.setStyleSheet(f"QPushButton {{ color: {L.link}; font-weight: 600; }}")
            button.setFixedHeight(28)
            button.clicked.connect(lambda _c=False, n=name, b=button: self.open_levels(n, b))
            line.addWidget(button)
            line.addStretch(1)
            self.slot_rows.addLayout(line)
        if self.levels_popup.isVisible() and self.levels_popup.variable in self._rows:
            levels, summary, show_all = self._rows[self.levels_popup.variable]
            self.levels_popup.fill(self.levels_popup.variable, self.levels_popup.variable, levels, summary, show_all)
        elif self.levels_popup.isVisible():
            self.levels_popup.close()
        if problem is not None:
            self.slot_problem.setText(problem)
            self.slot_problem.setVisible(bool(problem))

    def open_levels(self, name: str, anchor: QWidget | None = None) -> None:
        """The levels pop-up of one variable, under its button."""
        if name not in self._rows:
            return
        levels, summary, show_all = self._rows[name]
        self.levels_popup.fill(name, name, levels, summary, show_all)
        if anchor is not None:
            self.levels_popup.move(anchor.mapToGlobal(anchor.rect().bottomLeft()) + QPoint(0, 4))
        self.levels_popup.show()

    def set_variables_collapsed(self, collapsed: bool, summary: str) -> None:
        """Collapsed: the whole plot setup shows as one line, leaving the room to the figure."""
        self.variables_collapsed = collapsed
        self.variables_toggle.setText(("▸" if collapsed else "▾") + "  PLOT SETUP")
        self.variables_toggle.setToolTip("Show the plot setup" if collapsed else
                                         "Collapse the plot setup to a one-line summary")
        self.variables_summary.setText(summary)
        self.variables_summary.setVisible(collapsed)
        self.variables_body.setVisible(not collapsed)

    def set_plate_rules(self, rows: list[tuple]) -> None:
        """Plate rules (touching colonies, overplated plates, one plate per group): rows as in set_settings."""
        self._fill_rows(self.rule_rows, rows)

    def set_settings(self, rows: list[tuple]) -> None:
        """rows: (title, segmented options, enabled, note[, buttons]) for normalization, measure and analysis
        options; buttons: (text, handler) shown after the choices."""
        self._fill_rows(self.setting_rows, rows)

    def _fill_rows(self, layout, rows: list[tuple]) -> None:
        clear_layout(layout)
        for title, options, enabled, note, *rest in rows:
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label(title, "small")
            caption.setFixedWidth(96)
            line.addWidget(caption)
            if len(options) > MAX_SEGMENTS:                  # a long list of choices: a drop-down keeps the row short
                line.addWidget(self._menu(options, enabled, title))
            elif options:
                line.addWidget(LightSegmented(options, height=26, enabled=enabled, tooltip=title))
            for text, handler in (rest[0] if rest else []):
                button = light_button(text, None, f"{title}: {text}")
                button.setFixedHeight(28)
                button.clicked.connect(lambda _c=False, h=handler: h())
                line.addWidget(button)
            line.addStretch(1)
            layout.addLayout(line)
            if note:
                label = light_label(note, "small", wrap=True)
                label.setContentsMargins(106, 0, 0, 0)
                layout.addWidget(label)

    @staticmethod
    def _menu(options: list[tuple], enabled: bool, title: str) -> QComboBox:
        menu = QComboBox()
        menu.setToolTip(title)
        menu.setMinimumWidth(260)
        for option in options:
            menu.addItem(option[0])
        menu.setCurrentIndex(next((i for i, option in enumerate(options) if option[1]), 0))
        menu.setEnabled(enabled)
        menu.activated.connect(lambda index: options[index][2]())
        return menu

    def show_figure(self, figure: Figure, fit_height: bool = False) -> None:
        """Show a figure filling the view, or (fit_height) at the view's height keeping its own proportions,
        scrolling sideways when it is wider than the view."""
        size = None
        if fit_height:
            # Same inches at a screen dpi that fits the height, so the figure keeps its own layout. The dpi is set
            # before the canvas exists: the Qt canvas resets a figure's dpi to the one it was created with.
            height = max(380, self.figure_scroller.viewport().height() - 14)
            inches_wide, inches_high = figure.get_size_inches()
            dpi = height / inches_high / self.devicePixelRatioF()
            figure.set_dpi(dpi)
            figure._original_dpi = dpi
            size = (int(round(inches_wide * dpi)), int(round(inches_high * dpi)))
        if figure is not self.figure:
            self.canvas.setParent(None)
            self.canvas.deleteLater()
            self.figure = figure
            self.canvas = FigureCanvasQTAgg(figure)
            self.figure_scroller.setWidget(self.canvas)
        self.figure_scroller.setWidgetResizable(size is None)
        if size is not None:
            self.canvas.setFixedSize(*size)
        else:
            self.canvas.setMinimumSize(0, 0)
            self.canvas.setMaximumSize(16777215, 16777215)
        self.canvas.draw_idle()

    def set_notes(self, text: str) -> None:
        self.notes.setPlainText(text)

    def add_note_above(self, text: str) -> None:
        self.notes.setPlainText(text + "\n\n" + self.notes.toPlainText())

    def set_busy(self, busy: bool, message: str = "") -> None:
        for widget in (self.save_table_button, self.save_figure_button, self.analysis_list):
            widget.setEnabled(not busy)
        if busy:
            self.set_notes(message)

    def start_progress(self, title: str, text: str, total: int):
        """A progress dialog; returns progress(done, total) -> False once the user stops it."""
        from PySide6.QtWidgets import QApplication, QProgressDialog
        self._progress = QProgressDialog(text, "Stop", 0, max(total, 1), self)
        self._progress.setWindowTitle(title)
        self._progress.setWindowModality(Qt.WindowModal)
        self._progress.setMinimumDuration(400)

        def progress(done: int, total: int) -> bool:
            self._progress.setMaximum(max(total, 1))
            self._progress.setValue(done)
            QApplication.processEvents()
            return not self._progress.wasCanceled()

        return progress

    def end_progress(self) -> None:
        if getattr(self, "_progress", None) is not None:
            self._progress.close()
            self._progress = None

    def set_exports(self, table: bool) -> None:
        self.save_table_button.setEnabled(table)

    def ask_color(self, current: str, title: str) -> str:
        """A color from the color picker as '#rrggbb', or '' when cancelled."""
        color = QColorDialog.getColor(QColor(current), self, title)
        return color.name() if color.isValid() else ""

    def ask_figure_path(self, start: str) -> str:
        path, _ = QFileDialog.getSaveFileName(self, "Save figure", start,
                                              "PNG image (*.png);;PDF (*.pdf);;SVG (*.svg)")
        return path

    def ask_table_path(self, start: str) -> str:
        path, _ = QFileDialog.getSaveFileName(self, "Save table", start, "CSV (*.csv)")
        return path

    # ----- plate selection ---------------------------------------------------
    def show_selection(self, view: dict) -> None:
        """Open (or refill) the plate selection window. view: see SelectionDialog.fill."""
        if getattr(self, "selection_dialog", None) is None:
            self.selection_dialog = SelectionDialog(self)
        self.selection_dialog.fill(view)
        self.selection_dialog.show()
        self.selection_dialog.raise_()

    def refill_selection(self, view: dict) -> None:
        """Refill the plate selection window when it is open."""
        dialog = getattr(self, "selection_dialog", None)
        if dialog is not None and dialog.isVisible():
            dialog.fill(view)

    def show_plates(self, view: dict) -> None:
        """Open (or refill) the plate list. view: see PlatesDialog.fill."""
        if getattr(self, "plates_dialog", None) is None:
            self.plates_dialog = PlatesDialog(self)
        self.plates_dialog.fill(view)
        self.plates_dialog.show()
        self.plates_dialog.raise_()

    def refill_plates(self, view: dict) -> None:
        dialog = getattr(self, "plates_dialog", None)
        if dialog is not None and dialog.isVisible():
            dialog.fill(view)

    def close_selection(self) -> None:
        dialog = getattr(self, "selection_dialog", None)
        if dialog is not None:
            dialog.close()

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)

    def open_folder(self, folder: str) -> None:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder))


class SelectionDialog(QDialog):
    """The plate selection: which variables to match within, the colony-count target, and one row
    per group with its plate. Each row's menu keeps the automatic choice, leaves the group empty, or
    pins one of the group's plates. The controller refills it after every change."""

    COLUMNS = ("Group", "Plate", "Colonies", "From target", "Capture", "Pool", "Status", "Choice", "Notes")
    NOTES, CHOICE = 8, 7

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        palette = self.palette()
        for role, color in ((QPalette.Window, L.page), (QPalette.WindowText, L.text), (QPalette.Base, L.surface),
                            (QPalette.Text, L.text)):
            palette.setColor(role, QColor(color))
        self.setPalette(palette)
        self.setStyleSheet(parent.styleSheet() + f"\nQDialog#LightWindow {{ background: {L.page}; }}")
        self.setWindowTitle("Plate selection")
        self.resize(1320, 760)
        column = QVBoxLayout(self)
        column.setContentsMargins(22, 18, 22, 18)
        column.setSpacing(10)
        column.addWidget(light_label("One plate per index, matched on colony count", "h2"))
        column.addWidget(light_label(
            "With every variable under Match within, each group is one index and keeps the replicate plate whose "
            "colony count is closest to the target. Leave a variable out to choose across its levels too (leave "
            "Density out to match counts across the density tiers). A plate can be chosen only when all of its "
            "levels are used and highlighted under Choose from, its capture ratio is at least the separable "
            "floor, it has colonies, and it is not left out by hand. Choose a plate by hand, or leave a group "
            "empty, from a row's menu.", "small", wrap=True))
        self.match_row = QHBoxLayout()
        self.match_row.setSpacing(10)
        column.addLayout(self.match_row)
        self.choose_rows = QVBoxLayout()               # levels the pool is drawn from, per other variable
        self.choose_rows.setSpacing(4)
        column.addLayout(self.choose_rows)
        target_row = QHBoxLayout()
        target_row.setSpacing(10)
        caption = light_label("Target", "small")
        caption.setFixedWidth(110)
        target_row.addWidget(caption)
        self.target_choice = QHBoxLayout()
        target_row.addLayout(self.target_choice)
        self.target_value = QSpinBox()
        self.target_value.setRange(1, 1_000_000)
        self.target_value.setFixedWidth(110)
        self.target_value.setToolTip("Fixed colony-count target")
        self.target_value.editingFinished.connect(lambda: self._set_fixed and self._set_fixed(self.target_value.value()))
        target_row.addWidget(self.target_value)
        target_row.addStretch(1)
        column.addLayout(target_row)
        self.summary = light_label("", "body", wrap=True)
        column.addWidget(self.summary)
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setWordWrap(False)
        header = self.table.horizontalHeader()
        for i in range(self.CHOICE):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Interactive)          # plate names can be long
        header.resizeSection(1, 250)
        self.table.setTextElideMode(Qt.ElideMiddle)
        header.setSectionResizeMode(self.CHOICE, QHeaderView.Fixed)
        header.resizeSection(self.CHOICE, 210)
        header.setStretchLastSection(True)                  # Notes: why a group is empty, filters a pinned plate fails
        column.addWidget(self.table, 1)
        column.addWidget(light_label("Why groups are empty", "small"))
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setFixedHeight(130)
        column.addWidget(self.details)
        buttons = QHBoxLayout()
        self.reset_button = light_button("Reset to automatic", None, "Forget plates chosen by hand and groups left empty")
        self.save_button = light_button("Save table (CSV)", None)
        self.close_button = light_button("Close", "primary")
        self.close_button.clicked.connect(self.close)
        buttons.addWidget(self.reset_button)
        buttons.addStretch(1)
        buttons.addWidget(self.save_button)
        buttons.addWidget(self.close_button)
        column.addLayout(buttons)
        self._set_fixed = None
        self._actions = {}
        self.reset_button.clicked.connect(lambda: self._actions.get("reset", lambda: None)())
        self.save_button.clicked.connect(lambda: self._actions.get("save", lambda: None)())

    def fill(self, view: dict) -> None:
        """view: matched [(name, on, toggle)], target (fixed: bool, value, use median, set fixed(value)),
        summary text, rows [(cells, problem: bool, choices [(text, current, handler)])], reset, save."""
        clear_layout(self.match_row)
        caption = light_label("Match within", "small")
        caption.setFixedWidth(110)
        self.match_row.addWidget(caption)
        self.match_row.addWidget(LevelChips([(name, on, toggle, None, None) for name, on, toggle in view["matched"]],
                                            tooltip="Match within"))
        self.match_row.addStretch(1)
        clear_layout(self.choose_rows)
        for i, (name, levels) in enumerate(view.get("choose_from", [])):
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label("Choose from" if i == 0 else "", "small")
            caption.setFixedWidth(110)
            line.addWidget(caption)
            label = light_label(name, None)
            label.setFixedWidth(90)
            line.addWidget(label)
            line.addWidget(LevelChips([(text, on, toggle, None, None) for text, on, toggle in levels],
                                      tooltip=f"Choose from {name}"))
            line.addStretch(1)
            self.choose_rows.addLayout(line)
        if view.get("choose_from"):
            self.choose_rows.addWidget(light_label(
                "Only plates with a highlighted level can be chosen. The others are still drawn faded where "
                "the analysis draws every plate (mixture model).", "small", wrap=True))
        fixed, value, use_median, set_fixed = view["target"]
        clear_layout(self.target_choice)
        self._set_fixed = set_fixed
        self.target_choice.addWidget(LightSegmented(
            [("Median of eligible plates", not fixed, use_median),
             ("Fixed", fixed, lambda: set_fixed(self.target_value.value()))], height=26, tooltip="Target"))
        self.target_value.blockSignals(True)
        self.target_value.setValue(int(round(value)) if value == value else 1)
        self.target_value.blockSignals(False)
        self.target_value.setEnabled(fixed)
        self.summary.setText(view["summary"])
        self.details.setPlainText(view.get("details", "") or "Every group has a plate.")
        self._actions = {"reset": view["reset"], "save": view["save"]}
        rows = view["rows"]
        self.table.setRowCount(len(rows))
        for r, (cells, problem, choices) in enumerate(rows):
            for c, text in enumerate(cells):
                c = c if c < self.CHOICE else self.NOTES
                item = QTableWidgetItem(str(text))
                if problem:
                    item.setForeground(QColor(L.danger_text))
                item.setToolTip(str(text))                   # plate names and notes can be cut short
                self.table.setItem(r, c, item)
            self.table.setCellWidget(r, self.CHOICE, self._choice_menu(choices))


    @staticmethod
    def _choice_menu(choices: list[tuple]) -> QComboBox:
        menu = QComboBox()
        menu.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)   # long plate names: the list widens
        menu.setMinimumContentsLength(16)
        for text, _current, _handler in choices:
            menu.addItem(text)
        menu.view().setMinimumWidth(menu.view().sizeHintForColumn(0) + 24)
        menu.setCurrentIndex(next((i for i, choice in enumerate(choices) if choice[1]), 0))
        menu.activated.connect(lambda index: choices[index][2]())
        return menu


class PlatesDialog(QDialog):
    """Every plate: its levels, colony count, capture ratio, whether it is used and why not. Unticking
    Use leaves a plate out of every analysis by hand."""

    COLUMNS = ("Use", "Plate", "Levels", "Colonies", "Capture", "Used", "Why not used")

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("LightWindow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        palette = self.palette()
        for role, color in ((QPalette.Window, L.page), (QPalette.WindowText, L.text), (QPalette.Base, L.surface),
                            (QPalette.Text, L.text)):
            palette.setColor(role, QColor(color))
        self.setPalette(palette)
        self.setStyleSheet(parent.styleSheet() + f"\nQDialog#LightWindow {{ background: {L.page}; }}")
        self.setWindowTitle("Plates")
        self.resize(1180, 720)
        column = QVBoxLayout(self)
        column.setContentsMargins(22, 18, 22, 18)
        column.setSpacing(10)
        column.addWidget(light_label("Plates", "h2"))
        column.addWidget(light_label(
            "A plate is used when every one of its levels is used (Plates used), it is not overplated while "
            "overplated plates are left out, and Use is ticked. Untick Use to leave a plate out by hand.",
            "small", wrap=True))
        self.summary = light_label("", "body")
        column.addWidget(self.summary)
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideMiddle)
        header = self.table.horizontalHeader()
        for i in range(len(self.COLUMNS) - 1):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Interactive)
        header.resizeSection(1, 280)
        header.setStretchLastSection(True)
        self.table.itemChanged.connect(self._ticked)
        column.addWidget(self.table, 1)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        close = light_button("Close", "primary")
        close.clicked.connect(self.close)
        buttons.addWidget(close)
        column.addLayout(buttons)
        self._toggles = []

    def fill(self, view: dict) -> None:
        """view: summary, rows (index id, plate, levels, colonies, capture, used, use ticked, why not, toggle)."""
        self.summary.setText(view["summary"])
        rows = view["rows"]
        self._toggles = [row[8] for row in rows]
        self.table.blockSignals(True)
        self.table.setRowCount(len(rows))
        for r, (_index_id, plate, levels, colonies, capture, used, ticked, why, _toggle) in enumerate(rows):
            box = QTableWidgetItem()
            box.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            box.setCheckState(Qt.Checked if ticked else Qt.Unchecked)
            self.table.setItem(r, 0, box)
            for c, text in enumerate((plate, levels, colonies, capture, "yes" if used else "no", why), start=1):
                item = QTableWidgetItem(str(text))
                item.setToolTip(str(text))
                if not used:
                    item.setForeground(QColor(L.text_secondary))
                self.table.setItem(r, c, item)
        self.table.blockSignals(False)

    def _ticked(self, item) -> None:
        if item.column() == 0 and item.row() < len(self._toggles):
            from PySide6.QtCore import QTimer
            QTimer.singleShot(0, self._toggles[item.row()])     # the table is refilled; not inside its own signal
