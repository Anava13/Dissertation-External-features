"""StatsWindow: the Stats module (view, light palette).

Left: the analyses (built-in and plug-ins). Top: which slot each variable fills, then the
normalization, measure and options of the chosen analysis. Middle: the figure. Bottom:
notes (normalization notes, fit summaries, plug-in problems).
"""

from __future__ import annotations

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QListWidget, QListWidgetItem, QMainWindow,
                               QPlainTextEdit, QScrollArea, QSplitter, QVBoxLayout, QWidget)

from ..theme import Theme
from ..theme.icons import app_icon
from ..theme.stylesheet import build_light_stylesheet
from .light import LightSegmented, clear_layout, light_button, light_header, light_label
from .dialogs import ERROR, notify


MAX_SEGMENTS = 4                                # more choices than this show as a drop-down

class StatsWindow(QMainWindow):
    """The Stats module's view. Controllers use only its signals and its set_/show_/ask_ methods."""

    analysisChosen = Signal(str)
    helpRequested = Signal()
    saveFigureRequested = Signal()
    saveTableRequested = Signal()
    pluginsFolderRequested = Signal()
    backRequested = Signal()

    def __init__(self, theme: Theme, project_name: str, analyses: list[tuple[str, list[tuple[str, str]]]] = ()):
        """analyses: (section title, [(key, label)]); set_analyses can replace them later."""
        super().__init__()
        self.theme = theme
        self.setObjectName("LightWindow")
        self.setStyleSheet(build_light_stylesheet(theme.style.light, theme.ui_family, theme.brand_family))
        self.setWindowTitle(f"QuantaColony · Stats · {project_name}")
        self.setWindowIcon(app_icon())
        self.resize(1440, 900)

        root = QWidget()
        column = QVBoxLayout(root)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(0)
        header, header_row = light_header(theme, ["Projects", project_name, "Stats"])
        self.help_button = light_button("Help", "header")
        header_row.addWidget(self.help_button)
        self.back_button = light_button("Back to project", "header")
        header_row.addWidget(self.back_button)
        column.addWidget(header)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._analysis_list(analyses))
        body.addWidget(self._main_area(), 1)
        column.addLayout(body, 1)
        self.setCentralWidget(root)
        for widget, signal in ((self.help_button, self.helpRequested), (self.back_button, self.backRequested),
                               (self.save_figure_button, self.saveFigureRequested),
                               (self.save_table_button, self.saveTableRequested),
                               (self.plugins_button, self.pluginsFolderRequested)):
            widget.clicked.connect(signal.emit)

    # ----- construction ---------------------------------------------------
    def _analysis_list(self, analyses) -> QFrame:
        side = QFrame(objectName="LightSide")
        side.setFixedWidth(240)
        layout = QVBoxLayout(side)
        layout.setContentsMargins(0, 16, 0, 16)
        layout.setSpacing(0)
        self.analysis_list = QListWidget()
        self.analysis_list.setFocusPolicy(Qt.StrongFocus)
        self._keys: dict[str, QListWidgetItem] = {}
        self.analysis_list.currentItemChanged.connect(
            lambda item, _old: item is not None and item.data(Qt.UserRole) and self.analysisChosen.emit(
                item.data(Qt.UserRole)))
        layout.addWidget(self.analysis_list, 1)
        self.set_analyses(list(analyses))
        self.plugins_button = light_button("Analyses folder…", "quiet",
                                           "Open the folder where your own analysis plug-ins go")
        layout.addWidget(self.plugins_button, 0, Qt.AlignLeft)
        return side

    def _main_area(self) -> QWidget:
        area = QWidget()
        column = QVBoxLayout(area)
        column.setContentsMargins(24, 18, 24, 18)
        column.setSpacing(14)

        top = QHBoxLayout()
        self.title = light_label("", "h1")
        top.addWidget(self.title)
        top.addStretch(1)
        self.save_table_button = light_button("Save table (CSV)", None)
        self.save_figure_button = light_button("Save figure…", "primary")
        top.addWidget(self.save_table_button)
        top.addWidget(self.save_figure_button)
        column.addLayout(top)
        self.description = light_label("", "body", wrap=True)
        column.addWidget(self.description)

        controls = QFrame(objectName="LightPanel")
        grid = QGridLayout(controls)
        grid.setContentsMargins(16, 12, 16, 12)
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(8)
        grid.addWidget(light_label("VARIABLES", "section"), 0, 0)
        grid.addWidget(light_label("SETTINGS", "section"), 0, 1)
        self.slot_rows = QVBoxLayout()
        self.slot_rows.setSpacing(6)
        grid.addLayout(self.slot_rows, 1, 0, Qt.AlignTop)
        self.setting_rows = QVBoxLayout()
        self.setting_rows.setSpacing(8)
        grid.addLayout(self.setting_rows, 1, 1, Qt.AlignTop)
        self.slot_problem = light_label("", None, wrap=True)
        self.slot_problem.setProperty("state", "bad")
        grid.addWidget(self.slot_problem, 2, 0, 1, 2)
        grid.setColumnStretch(1, 1)
        column.addWidget(controls)

        splitter = QSplitter(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        self.figure = Figure(figsize=(12, 7), facecolor=self.theme.style.plot.background)
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.figure_scroller = QScrollArea()
        self.figure_scroller.setWidget(self.canvas)
        self.figure_scroller.setWidgetResizable(True)
        light = self.theme.style.light
        self.figure_scroller.setStyleSheet(f"QScrollArea {{ background: {light.surface}; border: 1px solid "
                                           f"{light.border}; border-radius: 6px; }}")
        splitter.addWidget(self.figure_scroller)
        self.notes = QPlainTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setPlaceholderText("Notes about the current analysis appear here.")
        splitter.addWidget(self.notes)
        splitter.setSizes([760, 90])
        column.addWidget(splitter, 1)
        return area

    # ----- updates the controller calls -----------------------------------
    def select_analysis(self, key: str) -> None:
        item = self._keys.get(key)
        if item is not None and self.analysis_list.currentItem() is not item:
            self.analysis_list.blockSignals(True)
            self.analysis_list.setCurrentItem(item)
            self.analysis_list.blockSignals(False)

    def set_heading(self, title: str, description: str) -> None:
        self.title.setText(title)
        self.description.setText(description)

    def set_analyses(self, analyses: list[tuple[str, list[tuple[str, str]]]]) -> None:
        """Rebuild the analysis list: (section title, [(id, name)])."""
        self.analysis_list.blockSignals(True)
        self.analysis_list.clear()
        self._keys = {}
        for section, items in analyses:
            title = QListWidgetItem(section.upper())
            title.setFlags(Qt.NoItemFlags)
            font = title.font()
            font.setPixelSize(11)
            font.setBold(True)
            title.setFont(font)
            title.setForeground(Qt.gray)
            self.analysis_list.addItem(title)
            for key, text in items:
                item = QListWidgetItem(text)
                item.setData(Qt.UserRole, key)
                self.analysis_list.addItem(item)
                self._keys[key] = item
        self.analysis_list.blockSignals(False)

    def set_slots(self, rows: list[tuple[str, str, list[tuple]]], problem: str) -> None:
        """rows: (variable name, its kind, segmented options: (slot title, chosen, handler, allowed))."""
        clear_layout(self.slot_rows)
        for name, kind, options in rows:
            line = QHBoxLayout()
            line.setSpacing(10)
            text = light_label(name, None)
            text.setFixedWidth(110)
            text.setToolTip(f"{name} is a {kind} variable")
            line.addWidget(text)
            line.addWidget(LightSegmented(options, height=26, tooltip=f"Slot of {name}"))
            line.addStretch(1)
            self.slot_rows.addLayout(line)
        self.slot_problem.setText(problem)
        self.slot_problem.setVisible(bool(problem))

    def set_settings(self, rows: list[tuple[str, list[tuple], bool, str]]) -> None:
        """rows: (title, segmented options, enabled, note) for normalization, measure and analysis options."""
        clear_layout(self.setting_rows)
        for title, options, enabled, note in rows:
            line = QHBoxLayout()
            line.setSpacing(10)
            caption = light_label(title, "small")
            caption.setFixedWidth(96)
            line.addWidget(caption)
            if len(options) > MAX_SEGMENTS:                  # a long list of choices: a drop-down keeps the row short
                line.addWidget(self._menu(options, enabled, title))
            else:
                line.addWidget(LightSegmented(options, height=26, enabled=enabled, tooltip=title))
            line.addStretch(1)
            self.setting_rows.addLayout(line)
            if note:
                self.setting_rows.addWidget(light_label(note, "small", wrap=True))

    @staticmethod
    def _menu(options: list[tuple], enabled: bool, title: str) -> QComboBox:
        menu = QComboBox()
        menu.setToolTip(title)
        menu.setMinimumWidth(260)
        for option in options:
            menu.addItem(option[0])
        menu.setCurrentIndex(next((i for i, option in enumerate(options) if option[1]), 0))
        menu.setEnabled(enabled)
        menu.activated.connect(lambda index: options[index][2]())
        return menu

    def show_figure(self, figure: Figure, fit_height: bool = False) -> None:
        """Show a figure filling the view, or (fit_height) at the view's height keeping its own proportions,
        scrolling sideways when it is wider than the view."""
        size = None
        if fit_height:
            # Same inches at a screen dpi that fits the height, so the figure keeps its own layout. The dpi is set
            # before the canvas exists: the Qt canvas resets a figure's dpi to the one it was created with.
            height = max(380, self.figure_scroller.viewport().height() - 14)
            inches_wide, inches_high = figure.get_size_inches()
            dpi = height / inches_high / self.devicePixelRatioF()
            figure.set_dpi(dpi)
            figure._original_dpi = dpi
            size = (int(round(inches_wide * dpi)), int(round(inches_high * dpi)))
        if figure is not self.figure:
            self.canvas.setParent(None)
            self.canvas.deleteLater()
            self.figure = figure
            self.canvas = FigureCanvasQTAgg(figure)
            self.figure_scroller.setWidget(self.canvas)
        self.figure_scroller.setWidgetResizable(size is None)
        if size is not None:
            self.canvas.setFixedSize(*size)
        else:
            self.canvas.setMinimumSize(0, 0)
            self.canvas.setMaximumSize(16777215, 16777215)
        self.canvas.draw_idle()

    def set_notes(self, text: str) -> None:
        self.notes.setPlainText(text)

    def add_note_above(self, text: str) -> None:
        self.notes.setPlainText(text + "\n\n" + self.notes.toPlainText())

    def set_busy(self, busy: bool, message: str = "") -> None:
        for widget in (self.save_table_button, self.save_figure_button, self.analysis_list):
            widget.setEnabled(not busy)
        if busy:
            self.set_notes(message)

    def start_progress(self, title: str, text: str, total: int):
        """A progress dialog; returns progress(done, total) -> False once the user stops it."""
        from PySide6.QtWidgets import QApplication, QProgressDialog
        self._progress = QProgressDialog(text, "Stop", 0, max(total, 1), self)
        self._progress.setWindowTitle(title)
        self._progress.setWindowModality(Qt.WindowModal)
        self._progress.setMinimumDuration(400)

        def progress(done: int, total: int) -> bool:
            self._progress.setMaximum(max(total, 1))
            self._progress.setValue(done)
            QApplication.processEvents()
            return not self._progress.wasCanceled()

        return progress

    def end_progress(self) -> None:
        if getattr(self, "_progress", None) is not None:
            self._progress.close()
            self._progress = None

    def set_exports(self, table: bool) -> None:
        self.save_table_button.setEnabled(table)

    def ask_figure_path(self, start: str) -> str:
        path, _ = QFileDialog.getSaveFileName(self, "Save figure", start,
                                              "PNG image (*.png);;PDF (*.pdf);;SVG (*.svg)")
        return path

    def ask_table_path(self, start: str) -> str:
        path, _ = QFileDialog.getSaveFileName(self, "Save table", start, "CSV (*.csv)")
        return path

    def report(self, title: str, text: str, kind: str = ERROR) -> None:
        """A message with the sound of its kind (see gui.dialogs): ERROR, WARNING, INFO or SUCCESS."""
        notify(self, kind, title, text)

    def open_folder(self, folder: str) -> None:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder))
