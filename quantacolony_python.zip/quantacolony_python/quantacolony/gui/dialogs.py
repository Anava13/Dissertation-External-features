"""Message windows with the sound that fits their purpose.

Qt's QMessageBox lets Windows pick the sound from the icon, and in Windows' default sound
scheme the information and warning sounds are the same alert, so a "Copy saved" sounded
like a problem. These dialogs are plain QDialogs (Windows plays nothing for them) that play
their own sound from the kind of message:

    QUESTION  a choice the user asked for (confirm, save or discard)    no sound
    SUCCESS   something finished                                         Windows notification
    INFO      something to know, nothing wrong                           Windows notification
    WARNING   something needs attention, nothing failed                  Windows exclamation
    ERROR     something failed                                           Windows critical stop

The sounds come from the user's own Windows sound scheme, so they follow its settings
(including "No sounds"). Elsewhere only warnings and errors beep.

A dialog takes the look of the window it opens from: the light palette on the home page,
project page, Stats and the wizard; the dark palette in Cropping and Colony Detection.
"""

from __future__ import annotations

import sys

from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import QApplication, QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from ..theme.icons import icon_pixmap
from ..theme.tokens import get_quanta_colony_style

QUESTION, SUCCESS, INFO, WARNING, ERROR = "question", "success", "info", "warning", "error"
KINDS = (QUESTION, SUCCESS, INFO, WARNING, ERROR)

# Windows sound-scheme names (registry aliases under AppEvents\Schemes\Apps\.Default)
WINDOWS_SOUNDS = {SUCCESS: ("Notification.Default", "SystemAsterisk"), INFO: ("Notification.Default", "SystemAsterisk"),
                  WARNING: ("SystemExclamation",), ERROR: ("SystemHand",)}
TEXT_WIDTH = 380
ICONS = {QUESTION: "help", SUCCESS: "check", INFO: "info", WARNING: "warning", ERROR: "circle_x"}


def play_sound(kind: str) -> None:
    """The sound for a kind of message, from the user's sound scheme. Questions are silent."""
    if kind == QUESTION:
        return
    if sys.platform == "win32":
        import winsound
        for alias in WINDOWS_SOUNDS[kind]:
            try:
                winsound.PlaySound(alias, winsound.SND_ALIAS | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
                return
            except RuntimeError:                       # alias missing from this sound scheme: try the next
                continue
    elif kind in (WARNING, ERROR):
        QApplication.beep()


def _is_light(parent: QWidget | None) -> bool:
    widget = parent
    while widget is not None:
        if widget.objectName() == "LightWindow":
            return True
        widget = widget.parentWidget()
    return False


class MessageDialog(QDialog):
    """Icon, title, text and buttons. buttons: [(key, label)]; the first is the default unless named."""

    def __init__(self, parent: QWidget | None, kind: str, title: str, text: str,
                 buttons: list[tuple[str, str]] | None = None, default: str | None = None, rich: bool = False):
        super().__init__(parent)
        self.kind = kind
        self.choice = ""
        buttons = buttons or [("ok", "OK")]
        default = default or buttons[0][0]
        style = get_quanta_colony_style()
        light = _is_light(parent)
        self._style(style, light)
        self.setWindowTitle(title)

        column = QVBoxLayout(self)
        column.setContentsMargins(22, 20, 22, 16)
        column.setSpacing(16)
        top = QHBoxLayout()
        top.setSpacing(14)
        icon = QLabel()
        icon.setPixmap(icon_pixmap(ICONS[kind], self._icon_color(style, light), 28, 2.0))
        icon.setFixedSize(QSize(32, 32))
        top.addWidget(icon, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setSpacing(6)
        heading = QLabel(title)
        heading.setObjectName("MessageTitle")
        heading.setWordWrap(True)
        body = QLabel(text)
        body.setObjectName("MessageText")
        body.setWordWrap(True)
        body.setTextFormat(Qt.RichText if rich else Qt.PlainText)
        body.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body.setMinimumWidth(TEXT_WIDTH)                         # wrapped text keeps a readable line length
        texts.addWidget(heading)
        texts.addWidget(body)
        texts.addStretch(1)                              # spare height goes below the text, not between
        top.addLayout(texts, 1)
        column.addLayout(top, 1)

        row = QHBoxLayout()
        row.addStretch(1)
        self.buttons: dict[str, QPushButton] = {}
        for key, label in buttons:
            button = QPushButton(label)
            button.setCursor(Qt.PointingHandCursor)
            if key == default:
                button.setProperty("variant", "primary")
                button.setDefault(True)
            button.clicked.connect(lambda _c=False, k=key: self._choose(k))
            row.addWidget(button)
            self.buttons[key] = button
        column.addLayout(row)
        column.setSizeConstraint(QVBoxLayout.SetFixedSize)      # exactly as tall as its text needs

    def _choose(self, key: str) -> None:
        self.choice = key
        self.accept()

    def _icon_color(self, style, light: bool) -> str:
        if light:
            c = style.light
            return {WARNING: c.review_text, ERROR: c.danger_text}.get(self.kind, c.link)
        c = style.colors
        return {WARNING: c.warning, ERROR: c.danger_text}.get(self.kind, c.accent_text)

    def _style(self, style, light: bool) -> None:
        if light:
            c = style.light
            self.setObjectName("LightWindow")
            self.setAttribute(Qt.WA_StyledBackground, True)
            sheet = (f"QDialog#LightWindow {{ background: {c.page}; }}"
                     f" QLabel {{ color: {c.text}; background: transparent; font-size: 14px; }}"
                     f" QLabel#MessageTitle {{ font-size: 16px; font-weight: 600; }}"
                     f" QLabel#MessageText {{ color: {c.text_secondary}; }}"
                     f" QPushButton {{ background: {c.surface}; border: 1px solid {c.field_border}; border-radius: 4px;"
                     f" padding: 0 16px; min-height: 32px; color: {c.text}; font-weight: 500; }}"
                     f" QPushButton:hover {{ background: {c.button}; }}"
                     f" QPushButton[variant=\"primary\"] {{ background: {c.accent}; border: none; color: {c.accent_ink};"
                     " font-weight: 600; }"
                     f" QPushButton[variant=\"primary\"]:hover {{ background: {c.accent_hover}; }}")
        else:
            c = style.colors
            self.setObjectName("MessageDialog")
            self.setAttribute(Qt.WA_StyledBackground, True)
            sheet = (f"QDialog#MessageDialog {{ background: {c.panel}; }}"
                     f" QLabel {{ color: {c.text}; background: transparent; font-size: 14px; }}"
                     f" QLabel#MessageTitle {{ font-size: 16px; font-weight: 600; }}"
                     f" QLabel#MessageText {{ color: {c.text_secondary}; }}")
        self.setStyleSheet(sheet)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        play_sound(self.kind)


def show_message(parent, kind: str, title: str, text: str, buttons=None, default: str | None = None,
                 rich: bool = False) -> str:
    """Show a message and wait; returns the key of the button pressed ('' when closed)."""
    dialog = MessageDialog(parent, kind, title, text, buttons, default, rich)
    dialog.exec()
    return dialog.choice


def notify(parent, kind: str, title: str, text: str) -> None:
    show_message(parent, kind, title, text)


def confirm(parent, title: str, text: str, yes: str = "Yes", no: str = "No", kind: str = QUESTION) -> bool:
    """A yes / no question; the safe answer (no) is the default."""
    return show_message(parent, kind, title, text, [(no, no), (yes, yes)], default=no) == yes
