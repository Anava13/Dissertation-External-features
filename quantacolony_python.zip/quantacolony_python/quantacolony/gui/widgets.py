"""Reusable view pieces for the QuantaColony interface.

Each widget only draws and reports user input through Qt signals; none of
them reads or changes colony data.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QPropertyAnimation, QRectF, QSize, Qt, Signal, Property
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QAbstractButton, QDoubleSpinBox, QFrame, QHBoxLayout, QLabel,
                               QPushButton, QScrollArea, QSizePolicy, QSlider, QVBoxLayout, QWidget)

from ..theme.icons import icon_pixmap, make_icon
from ..theme.tokens import Colors


def label(text: str = "", role: str | None = None, object_name: str | None = None,
          wrap: bool = False) -> QLabel:
    widget = QLabel(text)
    if role:
        widget.setProperty("role", role)
    if object_name:
        widget.setObjectName(object_name)
    widget.setWordWrap(wrap)
    return widget


def divider(vertical: bool = False, length: int = 0) -> QFrame:
    line = QFrame(objectName="Divider")
    if vertical:
        line.setFixedWidth(1)
        if length:
            line.setFixedHeight(length)
    else:
        line.setFixedHeight(1)
    return line


def button(text: str = "", variant: str | None = None, icon: str | None = None, colors: Colors | None = None,
           icon_color: str | None = None, icon_size: int = 17, tooltip: str = "",
           fixed: tuple[int, int] | None = None, stroke: float = 2.0) -> QPushButton:
    widget = QPushButton(text)
    if variant:
        widget.setProperty("variant", variant)
    if icon and colors:
        widget.setIcon(make_icon(icon, icon_color or colors.text, icon_size, stroke,
                                 disabled_color=colors.text_disabled, active_color=colors.accent_text))
        widget.setIconSize(QSize(icon_size, icon_size))
    if tooltip:
        widget.setToolTip(tooltip)
        if not text:
            widget.setAccessibleName(tooltip)
    if fixed:
        widget.setFixedSize(*fixed)
    widget.setCursor(Qt.PointingHandCursor)
    return widget


class ModeButton(QAbstractButton):
    """Mode list entry: icon, label and keyboard shortcut badge, painted directly."""

    def __init__(self, icon_name: str, text: str, shortcut: str, colors: Colors, parent=None):
        super().__init__(parent)
        self.icon_name = icon_name
        self.shortcut_text = shortcut
        self.colors = colors
        self.setText(text)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(42)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setAccessibleName(f"{text} (shortcut {shortcut})")
        self._hover = False
        self.compact = False

    def set_compact(self, compact: bool) -> None:
        """Icon only, for the collapsed sidebar; the label moves to the tooltip."""
        self.compact = compact
        self.setToolTip(f"{self.text()}  ({self.shortcut_text})" if compact else "")
        self.updateGeometry()
        self.update()

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()

    def sizeHint(self) -> QSize:
        return QSize(42, 42) if self.compact else QSize(260, 42)

    def minimumSizeHint(self) -> QSize:
        return QSize(42, 42)

    def paintEvent(self, event) -> None:
        c = self.colors
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect())
        if self.isChecked():
            fill = QColor(c.accent)
            fill.setAlpha(36)
            painter.setBrush(fill)
        elif self._hover:
            painter.setBrush(QColor(c.card))
        else:
            painter.setBrush(Qt.NoBrush)
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(rect, 10, 10)

        foreground = c.accent_text if self.isChecked() else c.text_secondary
        if self.compact:
            painter.drawPixmap(int(rect.width() - 18) // 2, 12, icon_pixmap(self.icon_name, foreground, 18))
            self._paint_focus(painter, rect)
            return
        painter.drawPixmap(12, 12, icon_pixmap(self.icon_name, foreground, 18))
        font = QFont(self.font())
        font.setPixelSize(14)
        font.setWeight(QFont.Medium)
        painter.setFont(font)
        painter.setPen(QColor(foreground))
        painter.drawText(QRectF(42, 0, rect.width() - 80, rect.height()), Qt.AlignVCenter | Qt.AlignLeft, self.text())

        badge = QRectF(rect.width() - 30, 12, 20, 18)
        painter.setPen(QPen(QColor(c.border), 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(badge, 6, 6)
        small = QFont(font)
        small.setPixelSize(11)
        small.setWeight(QFont.Normal)
        painter.setFont(small)
        painter.setPen(QColor(c.text_faint))
        painter.drawText(badge, Qt.AlignCenter, self.shortcut_text)
        self._paint_focus(painter, rect)

    def _paint_focus(self, painter: QPainter, rect: QRectF) -> None:
        if self.hasFocus():
            painter.setPen(QPen(QColor(self.colors.accent_text), 2))
            painter.setBrush(Qt.NoBrush)
            painter.drawRoundedRect(rect.adjusted(1, 1, -1, -1), 10, 10)


class ToggleSwitch(QAbstractButton):
    """On/off switch with a sliding knob."""

    def __init__(self, colors: Colors, accessible_name: str, parent=None):
        super().__init__(parent)
        self.colors = colors
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(44, 26)
        self.setAccessibleName(accessible_name)
        self._offset = 3.0
        self._animation = QPropertyAnimation(self, b"knob", self)
        self._animation.setDuration(120)
        self.toggled.connect(self._animate)

    def _get_knob(self) -> float:
        return self._offset

    def _set_knob(self, value: float) -> None:
        self._offset = value
        self.update()

    knob = Property(float, _get_knob, _set_knob)

    def _animate(self, checked: bool) -> None:
        self._animation.stop()
        self._animation.setEndValue(21.0 if checked else 3.0)
        self._animation.start()

    def setChecked(self, checked: bool) -> None:  # noqa: N802 (Qt naming)
        super().setChecked(checked)
        self._offset = 21.0 if checked else 3.0
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(self.colors.accent if self.isChecked() else self.colors.track_off))
        painter.drawRoundedRect(QRectF(self.rect()), 13, 13)
        painter.setBrush(QColor(self.colors.knob))
        painter.drawEllipse(QRectF(self._offset, 3, 20, 20))
        if self.hasFocus():
            painter.setPen(QPen(QColor(self.colors.accent_text), 2))
            painter.setBrush(Qt.NoBrush)
            painter.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 12, 12)


class ParameterRow(QWidget):
    """Label and number field on one line, slider below. Emits valueEdited only on user input."""

    valueEdited = Signal(float)

    def __init__(self, title: str, minimum: float, maximum: float, step: float, decimals: int,
                 caption: str = "", parent=None):
        super().__init__(parent)
        self.step = step
        self.minimum = minimum
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        top = QHBoxLayout()
        self.title = label(title, "label")
        self.field = QDoubleSpinBox()
        self.field.setRange(minimum, maximum)
        self.field.setSingleStep(step)
        self.field.setDecimals(decimals)
        self.field.setKeyboardTracking(False)
        self.field.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.field.setFixedWidth(76)
        self.field.setAccessibleName(f"{title} value")
        self.title.setBuddy(self.field)
        top.addWidget(self.title)
        top.addStretch(1)
        top.addWidget(self.field)
        layout.addLayout(top)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, round((maximum - minimum) / step))
        self.slider.setAccessibleName(title)
        self.slider.setCursor(Qt.PointingHandCursor)
        layout.addWidget(self.slider)
        self.caption = label(caption, "caption", wrap=True)
        self.caption.setVisible(bool(caption))
        layout.addWidget(self.caption)

        self.slider.valueChanged.connect(self._slider_moved)
        self.field.valueChanged.connect(self._field_changed)

    def value(self) -> float:
        return round(self.field.value(), 6)

    def set_caption(self, text: str) -> None:
        self.caption.setText(text)
        self.caption.setVisible(bool(text))

    def set_value(self, value: float) -> None:
        """Set from the model without emitting valueEdited."""
        for widget in (self.field, self.slider):
            widget.blockSignals(True)
        self.field.setValue(value)
        self.slider.setValue(round((value - self.minimum) / self.step))
        for widget in (self.field, self.slider):
            widget.blockSignals(False)

    def _slider_moved(self, position: int) -> None:
        self.field.blockSignals(True)
        self.field.setValue(self.minimum + position * self.step)
        self.field.blockSignals(False)
        self.valueEdited.emit(self.value())          # the controller debounces rapid changes

    def _field_changed(self, value: float) -> None:
        self.slider.blockSignals(True)
        self.slider.setValue(round((value - self.minimum) / self.step))
        self.slider.blockSignals(False)
        self.valueEdited.emit(self.value())


class Field(QFrame):
    """Compact input well: caption, number, unit (e.g. 'Min [2] px')."""

    valueEdited = Signal(float)

    def __init__(self, caption: str, unit: str, minimum: float, maximum: float, step: float,
                 decimals: int, accessible_name: str, field_width: int = 0, parent=None,
                 steppers: Colors | None = None):
        """steppers: colors for up/down buttons at the right end (one step per click; hold to repeat)."""
        super().__init__(parent)
        self.setObjectName("Field")
        self.setFixedHeight(36)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 4 if steppers else 10, 0)
        layout.setSpacing(6)
        if caption:
            layout.addWidget(QLabel(caption))
        self.spin = QDoubleSpinBox()
        self.spin.setRange(minimum, maximum)
        self.spin.setSingleStep(step)
        self.spin.setDecimals(decimals)
        self.spin.setKeyboardTracking(False)
        self.spin.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.spin.setAccessibleName(accessible_name)
        if field_width:
            self.spin.setFixedWidth(field_width)
        layout.addWidget(self.spin, 1)
        if unit:
            layout.addWidget(QLabel(unit))
        if steppers is not None:
            self.spin.setMinimumWidth(28)                # room for the arrows in a narrow column
            arrows = QVBoxLayout()
            arrows.setContentsMargins(0, 3, 0, 3)
            arrows.setSpacing(1)
            for icon, step_by in (("chevron_up", self.spin.stepUp), ("chevron_down", self.spin.stepDown)):
                arrow = button(variant="stepper", icon=icon, colors=steppers, icon_color=steppers.text_muted,
                               icon_size=12, stroke=2.6, fixed=(20, 14),
                               tooltip=f"{'Raise' if icon == 'chevron_up' else 'Lower'} {accessible_name.lower()}")
                arrow.setAutoRepeat(True)
                arrow.setAutoRepeatDelay(350)
                arrow.setAutoRepeatInterval(90)
                arrow.setFocusPolicy(Qt.NoFocus)
                arrow.clicked.connect(step_by)
                arrows.addWidget(arrow)
            layout.addLayout(arrows)
        self.spin.valueChanged.connect(lambda v: self.valueEdited.emit(round(v, 6)))

    def set_value(self, value: float) -> None:
        self.spin.blockSignals(True)
        self.spin.setValue(value)
        self.spin.blockSignals(False)

    def value(self) -> float:
        return round(self.spin.value(), 6)


class HintCard(QFrame):
    """Rounded card with an info icon and wrapped text."""

    def __init__(self, text: str, colors: Colors, icon: str = "info", parent=None):
        super().__init__(parent)
        self.setObjectName("HintCard")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)
        tile = QLabel()
        tile.setPixmap(icon_pixmap(icon, colors.accent, 16))
        tile.setAlignment(Qt.AlignTop)
        layout.addWidget(tile, 0, Qt.AlignTop)
        self.text = label(text, "secondary", wrap=True)
        self.text.setStyleSheet("font-size: 13px;")
        layout.addWidget(self.text, 1)


class GestureRow(QWidget):
    """One mouse gesture: icon tile and description."""

    def __init__(self, icon_name: str, text: str, colors: Colors, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        tile = QLabel()
        tile.setFixedSize(26, 26)
        tile.setAlignment(Qt.AlignCenter)
        tile.setStyleSheet(f"background: {colors.card}; border-radius: 7px;")
        tile.setPixmap(icon_pixmap(icon_name, colors.text_secondary, 14))
        layout.addWidget(tile)
        text_label = label(text, "secondary", wrap=True)
        text_label.setStyleSheet("font-size: 13px;")
        layout.addWidget(text_label, 1)


class ActivityFeed(QScrollArea):
    """Newest-first list of what happened: detections, edits, undo, saves."""

    KIND_STYLE = {   # icon name, icon color, tile background
        "detect": ("search", "info_text", "info_soft"),
        "delete": ("trash", "danger_text", "danger_soft"),
        "add": ("plus", "accent_pill_text", "accent_soft"),
        "history": ("history", "text_muted", "raised"),
        "image": ("image", "text_muted", "raised"),
        "warning": ("warning", "warning", "warning_soft"),
        "save": ("save", "accent_pill_text", "accent_soft"),
    }
    MAX_ROWS = 100

    def __init__(self, colors: Colors, parent=None):
        super().__init__(parent)
        self.colors = colors
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        container = QWidget()
        self.rows = QVBoxLayout(container)
        self.rows.setContentsMargins(0, 0, 0, 0)
        self.rows.setSpacing(2)
        self.rows.addStretch(1)
        self.setWidget(container)

    def _color(self, name: str) -> str:
        return getattr(self.colors, name, name)

    def add_entry(self, kind: str, title: str, detail: str = "") -> None:
        icon_name, icon_color, tile_color = self.KIND_STYLE.get(kind, self.KIND_STYLE["history"])
        row = QFrame(objectName="ActivityRow")
        row.setProperty("latest", True)
        layout = QHBoxLayout(row)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        tile = QLabel()
        tile.setFixedSize(26, 26)
        tile.setAlignment(Qt.AlignCenter)
        tile.setStyleSheet(f"background: {self._color(tile_color)}; border-radius: 8px;")
        tile.setPixmap(icon_pixmap(icon_name, self._color(icon_color), 14))
        layout.addWidget(tile, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setSpacing(2)
        title_label = label(title, object_name="ActivityTitle", wrap=True)
        texts.addWidget(title_label)
        if detail:
            texts.addWidget(label(detail, "caption", wrap=True))
        layout.addLayout(texts, 1)
        time_label = label(datetime.now().strftime("%H:%M"), "caption")
        layout.addWidget(time_label, 0, Qt.AlignTop)

        # Only the newest row keeps the highlight
        if self.rows.count() > 1:
            previous = self.rows.itemAt(0).widget()
            if previous is not None:
                previous.setProperty("latest", False)
                previous.style().unpolish(previous)
                previous.style().polish(previous)
        self.rows.insertWidget(0, row)
        while self.rows.count() - 1 > self.MAX_ROWS:
            old = self.rows.takeAt(self.rows.count() - 2).widget()
            old.deleteLater()
        self.verticalScrollBar().setValue(0)

    def clear(self) -> None:
        while self.rows.count() > 1:
            item = self.rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def entry_count(self) -> int:
        return self.rows.count() - 1


class LegendDot(QWidget):
    """Ring swatch for the canvas legend."""

    def __init__(self, color: str, dashed: bool = False, parent=None):
        super().__init__(parent)
        self.color = color
        self.dashed = dashed
        self.setFixedSize(10, 10)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        pen = QPen(QColor(self.color), 1.6 if self.dashed else 2)
        if self.dashed:
            pen.setDashPattern([2, 1.5])
        painter.setPen(pen)
        painter.drawEllipse(QRectF(1, 1, 8, 8))


class Dot(QWidget):
    """Filled status dot."""

    def __init__(self, color: str, size: int = 8, parent=None):
        super().__init__(parent)
        self.color = color
        self.setFixedSize(size, size)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(self.color))
        path = QPainterPath()
        path.addEllipse(QRectF(self.rect()))
        painter.drawPath(path)
