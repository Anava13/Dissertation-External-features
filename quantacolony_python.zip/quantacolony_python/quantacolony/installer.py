"""QuantaColony installer: run once from the unpacked download ("Install QuantaColony.bat").

1. Finds the project library, or asks where to make it (the first-start screen).
2. Copies the program to %LOCALAPPDATA%\\QuantaColony\\Program and builds its Python environment
   there (uv sync). QuantaColony runs from that copy.
3. Puts QuantaColony shortcuts on the Desktop and in the Start menu, and gives .qcproj files the
   QuantaColony icon (double-clicking one opens it; set for the current user, no administrator
   rights needed).
4. Backs the program up in the library (<library>\\Program, with this installer), so a new
   computer installs from the library.

Afterwards the unpacked download is no longer needed and can be deleted. Running the installer
again (from a newer download, or from the library's Program folder) updates the installed copy.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from .data.manager import DataManager
from .data.program import PROGRAM_FOLDER, back_up_program, copy_program, is_program_folder, program_root
from .data.settings import default_settings_folder
from .theme.icons import LOGO_ICO

SHORTCUT_NAME = "QuantaColony.lnk"

# Paths reach PowerShell through environment variables, so spaces and quotes need no escaping
POWERSHELL_SCRIPT = r"""
$shell = New-Object -ComObject WScript.Shell
$made = @()
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $path = Join-Path $folder $env:QC_NAME
    $link = $shell.CreateShortcut($path)
    $link.TargetPath = $env:QC_TARGET
    $link.WorkingDirectory = $env:QC_WORKDIR
    $link.IconLocation = "$($env:QC_ICON),0"
    $link.Description = 'QuantaColony Colony Detection'
    $link.Save()
    $made += $path
}
$made -join "`n"
"""


def launcher_path(install: Path) -> Path:
    """The console-free launcher uv builds from [project.gui-scripts] in the installed environment."""
    return Path(install) / ".venv" / "Scripts" / "quantacolony-gui.exe"


def icon_path(install: Path) -> Path:
    return Path(install) / LOGO_ICO.relative_to(program_root())


def create_shortcuts(target: Path, workdir: Path, icon: Path) -> list[str]:
    """Desktop and Start menu shortcuts that start target (Windows)."""
    env = dict(os.environ, QC_NAME=SHORTCUT_NAME, QC_TARGET=str(target), QC_WORKDIR=str(workdir), QC_ICON=str(icon))
    result = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", POWERSHELL_SCRIPT],
                            env=env, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise InstallError(f"Could not create the shortcuts:\n{result.stderr.strip()}")
    return result.stdout.strip().splitlines()


PROG_ID = "QuantaColony.Project"


def register_project_files(launcher: Path, icon: Path) -> None:
    """Associate .qcproj with QuantaColony for the current user: icon and double-click to open."""
    import ctypes
    import winreg
    classes = r"Software\Classes"
    entries = {
        rf"{classes}\.qcproj": PROG_ID,
        rf"{classes}\{PROG_ID}": "QuantaColony project",
        rf"{classes}\{PROG_ID}\DefaultIcon": f'"{icon}",0',
        rf"{classes}\{PROG_ID}\shell\open\command": f'"{launcher}" "%1"',
    }
    for key_path, value in entries.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
            winreg.SetValueEx(key, "", 0, winreg.REG_SZ, value)
    SHCNE_ASSOCCHANGED, SHCNF_IDLIST = 0x08000000, 0
    ctypes.windll.shell32.SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, None, None)   # Explorer redraws icons


class InstallError(Exception):
    """Installation stopped; the message is meant for the user."""


def install_folder() -> Path:
    return default_settings_folder() / PROGRAM_FOLDER


def uv_command() -> str:
    """The uv that started the installer (uv run sets UV), else the one on the PATH."""
    found = os.environ.get("UV") or shutil.which("uv")
    if not found:
        raise InstallError("uv was not found. Run Install QuantaColony.bat, which installs it.")
    return found


# uv settings the inner uv sync may keep (where it caches and downloads, network and certificates). Every other
# UV_* setting belongs to the uv run that started the installer and must not steer the installed copy.
KEPT_UV_SETTINGS = ("UV_CACHE_DIR", "UV_PYTHON_INSTALL_DIR", "UV_PYTHON_DOWNLOADS", "UV_NATIVE_TLS", "UV_INDEX_URL",
                    "UV_EXTRA_INDEX_URL", "UV_DEFAULT_INDEX", "UV_INDEX", "UV_HTTP_TIMEOUT", "UV_OFFLINE",
                    "UV_INSECURE_HOST", "UV_TOOL_DIR")


def environment_for_sync() -> dict:
    return {key: value for key, value in os.environ.items()
            if key.upper() not in ("VIRTUAL_ENV", "CONDA_PREFIX")
            and (not key.upper().startswith("UV_") or key.upper() in KEPT_UV_SETTINGS)}


def build_environment(install: Path, run=subprocess.run) -> None:
    """uv sync inside the installed copy: Python and the libraries, in install/.venv."""
    install = Path(install).resolve()
    uv = uv_command()
    command = [uv, "sync", "--no-dev", "--directory", str(install)]
    result = run(command, env=environment_for_sync(), cwd=str(install), capture_output=True, text=True, check=False)
    if result.returncode != 0:
        version = run([uv, "--version"], capture_output=True, text=True, check=False).stdout.strip()
        raise InstallError("Python and the libraries could not be installed. If QuantaColony is open, close it and "
                           f"run the installer again.\n\n{(result.stderr or result.stdout).strip()[-1500:]}\n\n"
                           f"({version or 'uv'}; command: {' '.join(command)})")


def find_library(manager: DataManager) -> bool:
    """The library from settings, or the first-start screen to choose one. False when the user quits."""
    if manager.resolve_library() is not None:
        return True
    from PySide6.QtWidgets import QApplication

    from .gui.library_setup import ensure_library
    from .theme import apply_theme
    app = QApplication.instance() or QApplication(sys.argv[:1])
    return ensure_library(manager, apply_theme(app))


def install(source: Path, manager: DataManager, windows: bool | None = None, run=subprocess.run,
            say=print) -> Path:
    """Every step of the installation; returns the folder QuantaColony now runs from."""
    windows = sys.platform == "win32" if windows is None else windows
    source = Path(source).resolve()
    if not is_program_folder(source):
        raise InstallError(f"{source} does not hold the QuantaColony program (pyproject.toml and quantacolony).")
    if not find_library(manager):
        raise InstallError("No project library was chosen, so nothing was installed.")
    target = install_folder()
    say(f"Copying QuantaColony to {target} ...")
    copy_program(source, target)
    say("Installing Python and the libraries (the first time takes a few minutes) ...")
    build_environment(target, run)
    if windows:
        launcher = launcher_path(target)
        if not launcher.is_file():
            raise InstallError(f"The program launcher is missing: {launcher}")
        say("Creating the Desktop and Start menu shortcuts ...")
        create_shortcuts(launcher, target, icon_path(target))
        register_project_files(launcher, icon_path(target))
    say(f"Backing the program up in the library ({manager.library.root / PROGRAM_FOLDER}) ...")
    back_up_program(source, manager.library.root)
    return target


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    source = Path(argv[0]) if argv else program_root()
    manager = DataManager()
    try:
        target = install(source, manager)
    except (InstallError, OSError) as error:
        print(f"\nQuantaColony was not installed.\n{error}")
        return 1
    print(f"\nQuantaColony is installed in {target}.")
    print("Start it from the QuantaColony icon on the Desktop or in the Start menu.")
    if source.resolve() != target.resolve() and not str(source.resolve()).startswith(str(manager.library.root)):
        print(f"The folder you installed from is no longer needed and can be deleted:\n  {source.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
