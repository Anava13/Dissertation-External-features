"""Program-wide theme: tokens, bundled fonts, icons and the Qt style sheet.

Every QuantaColony window calls apply_theme() once at startup and reads
colors and fonts from the returned Theme.
"""

from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from .assets import register_font
from .stylesheet import build_stylesheet
from .tokens import QuantaColonyStyle, get_quanta_colony_style


@dataclass
class Theme:
    style: QuantaColonyStyle
    ui_family: str
    brand_family: str


def apply_theme(app: QApplication) -> Theme:
    style = get_quanta_colony_style()
    ui_family = register_font(style.fonts.ui_file, style.fonts.fallback)
    brand_family = register_font(style.fonts.brand_file, ui_family)
    app.setStyle("Fusion")                      # same base look on Windows, macOS and Linux
    base = QFont(ui_family)
    base.setPixelSize(style.fonts.size)
    app.setFont(base)
    app.setStyleSheet(build_stylesheet(style, ui_family, brand_family))
    return Theme(style, ui_family, brand_family)
