"""Bundled fonts. The package carries everything it draws; no external folder is read.

Fonts: Inter (interface) and Raleway (QuantaColony name), both under the
SIL Open Font License (license files sit next to the fonts).
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QFontDatabase

FONT_FOLDER = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def register_font(file_name: str, fallback: str) -> str:
    """Load a bundled .ttf into Qt; return its family name, or the fallback family."""
    path = FONT_FOLDER / file_name
    if path.is_file():
        font_id = QFontDatabase.addApplicationFont(str(path))
        if font_id >= 0:
            families = QFontDatabase.applicationFontFamilies(font_id)
            if families:
                return families[0]
    return fallback
