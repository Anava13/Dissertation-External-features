"""Line icons drawn from SVG path data (24 x 24 grid, stroked, round caps).

Icons are code, not image files: any icon renders in any color and size, and
the program needs no icon folder. Shapes follow the mockup.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from PySide6.QtCore import QByteArray, QRectF, QSize, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

# Each icon: SVG body elements drawn with the current stroke color
ICON_SHAPES: dict[str, str] = {
    "sliders": '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/>'
               '<circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
    "circle_x": '<circle cx="12" cy="12" r="8"/><path d="m9 9 6 6M15 9l-6 6"/>',
    "region_x": '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3'
                'M8 20H5a1 1 0 0 1-1-1v-3"/><path d="m9.5 9.5 5 5M14.5 9.5l-5 5"/>',
    "circle_plus": '<circle cx="12" cy="12" r="8"/><path d="M12 8.5v7M8.5 12h7"/>',
    "region_plus": '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3'
                   'M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M12 9v6M9 12h6"/>',
    "undo": '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
    "redo": '<path d="m15 14 5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>',
    "help": '<circle cx="12" cy="12" r="9.5"/><path d="M9.2 9a3 3 0 0 1 5.8 1c0 2-3 2.6-3 4.5"/>'
            '<path d="M12 17.5h.01"/>',
    "check": '<path d="M20 6 9 17l-5-5"/>',
    "chevron_down": '<path d="m6 9 6 6 6-6"/>',
    "chevron_up": '<path d="m6 15 6-6 6 6"/>',
    "wand": '<path d="m4 20 11-11M14 4v3M12.5 5.5h3M19 9v3M17.5 10.5h3M18 3v2M17 4h2"/>',
    "chevron_left": '<path d="m15 18-6-6 6-6"/>',
    "chevron_right": '<path d="m9 18 6-6-6-6"/>',
    "plate": '<circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r="1.5"/><circle cx="14.5" cy="14" r="2"/>',
    "info": '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    "trash": '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "minus": '<path d="M5 12h14"/>',
    "fit": '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3'
           'M16 21h3a2 2 0 0 0 2-2v-3"/>',
    "hand": '<path d="M18 11V6a2 2 0 0 0-4 0M14 10V4a2 2 0 0 0-4 0v2M10 10.5V6a2 2 0 0 0-4 0v8"/>'
            '<path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.9-6-2.4l-3.6-3.6'
            'a2 2 0 0 1 2.8-2.8L7 15"/>',
    "draw_circle": '<circle cx="12" cy="12" r="8"/><path d="M12 12h8"/>',
    "move": '<path d="M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/>',
    "resize": '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
    "mouse_right": '<rect x="6" y="3" width="12" height="18" rx="6"/><path d="M12 3v7"/>'
                   '<path d="M12 3h6v7h-6z" fill="currentColor"/>',
    "search": '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    "image": '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/>'
             '<path d="m21 15-4-4L6 21"/>',
    "warning": '<path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4M12 17h.01"/>',
    "save": '<path d="M5 3h11l3 3v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/>'
            '<path d="M7 3v5h8V3M7 21v-7h10v7"/>',
    "panel_left": '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16"/>',
    "panel_right": '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M15 4v16"/>',
    "history": '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 3"/>',
}


def _svg(name: str, color: str, stroke_width: float) -> bytes:
    body = ICON_SHAPES[name].replace("currentColor", color)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
            f'stroke="{color}" stroke-width="{stroke_width}" stroke-linecap="round" '
            f'stroke-linejoin="round">{body}</svg>').encode()


@lru_cache(maxsize=512)
def icon_pixmap(name: str, color: str, size: int = 18, stroke_width: float = 2.0,
                device_ratio: float = 2.0) -> QPixmap:
    """Icon drawn at size x size logical pixels, sharp on high-DPI screens."""
    renderer = QSvgRenderer(QByteArray(_svg(name, color, stroke_width)))
    pixels = int(round(size * device_ratio))
    pixmap = QPixmap(pixels, pixels)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    renderer.render(painter, QRectF(0, 0, pixels, pixels))
    painter.end()
    pixmap.setDevicePixelRatio(device_ratio)
    return pixmap


def make_icon(name: str, color: str, size: int = 18, stroke_width: float = 2.0,
              disabled_color: str | None = None, active_color: str | None = None) -> QIcon:
    """QIcon with optional colors for the disabled and checked states."""
    icon = QIcon()
    icon.addPixmap(icon_pixmap(name, color, size, stroke_width), QIcon.Normal, QIcon.Off)
    if active_color:
        icon.addPixmap(icon_pixmap(name, active_color, size, stroke_width), QIcon.Normal, QIcon.On)
    if disabled_color:
        icon.addPixmap(icon_pixmap(name, disabled_color, size, stroke_width), QIcon.Disabled, QIcon.Off)
    return icon


LOGO_FOLDER = Path(__file__).resolve().parent.parent / "assets" / "logo"
LOGO_SVG = LOGO_FOLDER / "logo.svg"            # full mark, 48 px and up
FAVICON_SVG = LOGO_FOLDER / "favicon.svg"      # simplified mark for 16-32 px
LOGO_ICO = LOGO_FOLDER / "quantacolony.ico"    # Windows shortcut and taskbar icon


@lru_cache(maxsize=16)
def logo_pixmap(size: int = 28, device_ratio: float = 2.0) -> QPixmap:
    """QuantaColony mark from the bundled SVG; the simplified version at small sizes."""
    source = FAVICON_SVG if size * device_ratio <= 64 else LOGO_SVG
    renderer = QSvgRenderer(str(source))
    pixels = int(round(size * device_ratio))
    pixmap = QPixmap(pixels, pixels)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    renderer.render(painter, QRectF(0, 0, pixels, pixels))
    painter.end()
    pixmap.setDevicePixelRatio(device_ratio)
    return pixmap


def app_icon() -> QIcon:
    """Window and taskbar icon at every size Windows asks for."""
    icon = QIcon()
    for size in (16, 24, 32, 48, 64, 128, 256):
        icon.addPixmap(logo_pixmap(size, 1.0))
    return icon


ICON_SIZE = QSize(18, 18)
