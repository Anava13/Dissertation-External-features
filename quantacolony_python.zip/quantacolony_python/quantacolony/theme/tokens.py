"""QuantaColony design tokens: the one place that defines the program's look.

Dark charcoal surfaces from the original Colony Detection panel. The two
brand colors come from the QuantaColony logo: lime (accent, manual edits) and
teal (automatic detection, information). Every window reads from here.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Colors:
    # Surfaces, darkest to lightest
    canvas: str = "#0A0B09"          # behind the plate image
    window: str = "#0E0F0D"          # page background, input wells
    panel: str = "#161714"           # sidebars, top bar, status bar
    card: str = "#1E201B"            # cards, hint boxes, segmented track
    card_alt: str = "#1A1B18"        # newest activity row
    raised: str = "#2A2C26"          # selected segment, chips
    border: str = "#2A2C26"
    track_off: str = "#3A3C35"       # switch track when off

    # Text (all pass 4.5:1 on panel)
    text: str = "#ECEEE6"
    text_secondary: str = "#C9CCC1"
    text_muted: str = "#A3A69B"
    text_faint: str = "#8A8D83"
    text_disabled: str = "#5C5F56"

    # Accent (logo lime) and its derived tints
    accent: str = "#7BF501"
    accent_hover: str = "#97F83D"
    accent_pressed: str = "#66CF00"
    accent_text: str = "#9CF84A"     # accent-colored text on dark surfaces
    accent_ink: str = "#132100"      # text on an accent fill
    accent_soft: str = "rgba(123, 245, 1, 36)"      # 14% tint (Qt rgba alpha is 0-255)
    accent_pill_text: str = "#B6FA7A"

    # Semantic
    danger: str = "#FF6B5E"
    danger_ink: str = "#2A0B07"
    danger_text: str = "#FF8A7F"
    info: str = "#2EC8BB"            # logo teal
    info_soft: str = "rgba(46, 200, 187, 40)"
    info_text: str = "#74DDD3"
    warning: str = "#F2B544"
    danger_soft: str = "rgba(255, 107, 94, 36)"     # delete rows in the activity feed
    warning_soft: str = "rgba(242, 181, 68, 36)"
    accent_faint: str = "rgba(123, 245, 1, 26)"     # current row in Cropping's photo list
    problem_fill: str = "rgba(255, 107, 94, 26)"    # Cropping's duplicate warning
    problem_border: str = "#5A2A24"
    knob: str = "#FFFFFF"                           # switch knob
    frame: str = "#2A2C26"                          # outline around the plate image
    danger_hover: str = "#FF8175"
    picker_hover: str = "#3A3C35"
    slider_hover: str = "#FFFFFF"

    # Index board (Cropping and Colony Detection): fill, edge and text per cell state
    board_waiting_fill: str = "#1C2A0C"
    board_partial_fill: str = "#24380E"
    board_partial_edge: str = "#4F7F12"
    board_duplicate_fill: str = "#4A2420"
    board_review_fill: str = "#4A3A10"
    board_review_edge: str = "#E0B23A"
    board_review_text: str = "#F2D58A"

    # Cropping's section labels on the plate
    section_label: str = "#ECEEE6"
    section_label_unused: str = "#8A8D83"
    section_label_top: str = "#A3A69B"
    section_idle_edge: str = "#4A4C44"


@dataclass(frozen=True)
class LightColors:
    """Light palette for text-heavy screens (setup, project creation), from the MATLAB
    getQuantaColonyStyle cream colors. Photo-heavy screens use the dark Colors."""

    page: str = "#FBFCF8"            # off white (primary.background)
    page_gray: str = "#ECEDE7"       # home and project pages: gray around the white panels
    panel_head: str = "#F5F6F1"      # panel title strips and table headers on those pages
    surface: str = "#FFFFFF"         # panels, fields
    header: str = "#212121"          # top bar (projects.darkest)
    text: str = "#2D2D2D"            # primary.text
    text_secondary: str = "#5C5F56"
    text_muted: str = "#6B6E66"      # 4.5:1 on page
    border: str = "#DCDCDC"          # secondary.border
    field_border: str = "#C9C9C4"
    rule: str = "#E8E8E4"
    button: str = "#F0F0F0"          # projects.brightest
    accent: str = "#9BE034"          # primary.accent
    accent_ink: str = "#212121"
    accent_soft: str = "#F2F9E6"     # selected rows and menu items
    link: str = "#3B6B00"
    danger_text: str = "#8A2318"
    danger_soft: str = "#FDF1EF"
    danger_border: str = "#E8A09A"
    note: str = "#D9B44A"
    danger_strong: str = "#D9655A"   # borders and marks of fields that need fixing
    hover: str = "#F0F0EC"
    disabled_text: str = "#B0B0AB"
    disabled_fill: str = "#E2E2E2"
    toggle_edge: str = "#8E8E8E"     # unchecked control dots in the wizard
    swatch_todo: str = "#B9BAB3"     # legend: still to do
    header_muted: str = "#9A9A95"    # muted text on the dark header
    review_text: str = "#A36A00"     # "needs review" on light pages
    scrollbar: str = "#CFCFCA"
    note_text: str = "#7A5A00"
    warn_text: str = "#8A5A00"
    accent_hover: str = "#ACE854"
    disabled_ink: str = "#8E8E8E"
    header_edge: str = "#4A4A4A"
    header_text: str = "#E6E6E2"
    header_hover: str = "#2E2E2E"
    disabled_label: str = "#A3A39E"
    list_selected: str = "#F1F8E6"
    table_selected: str = "#EAF5DA"
    # progress bars
    progress_done: str = "#7CC21E"   # detected
    progress_review: str = "#E5A92F" # detected, flagged for review
    progress_waiting: str = "#CFE9AE"# has a region, not detected yet
    progress_track: str = "#E4E5DF"  # nothing yet


@dataclass(frozen=True)
class ColonyColors:
    """Overlay colors on the plate image."""

    detected: str = "#2EC8BB"         # logo teal
    manual: str = "#7BF501"           # logo lime
    split: str = "#9C8CFF"            # detected, cut from a blob of touching colonies
    selected: str = "#FF6B5E"
    candidate: str = "#7BF501"        # found in a region, not yet added (drawn dashed)
    growth: str = "#E5A92F"           # growth outside the marked colonies (Show growth)
    dimmed_alpha: int = 90            # existing colonies while previewing a region (0-255)
    halo: str = "#0A0B09"             # dark outline under contours for contrast
    detected_width: float = 1.6
    manual_width: float = 1.8
    selected_width: float = 2.4


@dataclass(frozen=True)
class PlotColors:
    """Colors of Stats figures; handed to every analysis as its PlotStyle."""

    ink: str = "#2D2D2D"
    muted: str = "#6B6E66"
    grid: str = "#E8E8E4"
    spine: str = "#B5B5B0"
    background: str = "#FFFFFF"
    panel_edge: str = "#B3B3B3"
    bar: str = "#4D4D4D"
    empty_cell: str = "#E6E6E6"
    marker_fill: str = "#FFFFFF"
    group_colors: tuple = ("#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD", "#8C564B", "#E377C2",
                           "#7F7F7F", "#BCBD22", "#17BECF")       # matplotlib tab10
    step_colormap: str = "viridis"
    zone_colors: tuple = ("#33CC33", "#99E633", "#FFD933", "#FF801A", "#E63333")   # fidelity zones, best to worst


@dataclass(frozen=True)
class Fonts:
    ui_file: str = "Inter-Variable.ttf"
    brand_file: str = "Raleway-Variable.ttf"
    fallback: str = "Segoe UI"
    size: int = 14
    small: int = 12
    tiny: int = 11


@dataclass(frozen=True)
class Layout:
    window_size: tuple[int, int] = (1440, 920)
    top_bar_height: int = 60
    status_bar_height: int = 30
    sidebar_width: int = 300
    rail_width: int = 64             # left sidebar when collapsed to icons
    radius: int = 10
    radius_small: int = 8
    radius_card: int = 12


@dataclass(frozen=True)
class QuantaColonyStyle:
    colors: Colors = field(default_factory=Colors)
    light: LightColors = field(default_factory=LightColors)
    colony: ColonyColors = field(default_factory=ColonyColors)
    plot: PlotColors = field(default_factory=PlotColors)
    fonts: Fonts = field(default_factory=Fonts)
    layout: Layout = field(default_factory=Layout)


def get_quanta_colony_style() -> QuantaColonyStyle:
    return QuantaColonyStyle()
