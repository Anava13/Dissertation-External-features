"""Builds the Qt style sheet (CSS-like rules) from the design tokens.

Widgets opt into rules by objectName (#TopBar) or by a 'variant' or 'role'
property, so one sheet styles every window in the program.
"""

from __future__ import annotations

from .tokens import QuantaColonyStyle


def build_stylesheet(style: QuantaColonyStyle, ui: str, brand: str) -> str:
    c, f, L = style.colors, style.fonts, style.layout
    return f"""
* {{
    font-family: "{ui}";
    font-size: {f.size}px;
    color: {c.text};
}}
QMainWindow, QWidget#Root {{ background: {c.window}; }}
QToolTip {{
    background: {c.card}; color: {c.text}; border: 1px solid {c.border};
    border-radius: 6px; padding: 4px 8px; font-size: {f.small}px;
}}

/* ---------- bars and panels ---------- */
QFrame#TopBar {{ background: {c.panel}; border-bottom: 1px solid {c.border}; }}
QFrame#StatusBar {{ background: {c.panel}; border-top: 1px solid {c.border}; }}
QFrame#LeftSidebar {{ background: {c.panel}; border-right: 1px solid {c.border}; }}
QFrame#RightSidebar {{ background: {c.panel}; border-left: 1px solid {c.border}; }}
QFrame#Divider {{ background: {c.border}; border: none; }}
QWidget#CanvasArea {{ background: {c.canvas}; }}

/* ---------- text ---------- */
QLabel {{ background: transparent; }}
QLabel[role="muted"] {{ color: {c.text_muted}; font-weight: 500; }}
QLabel[role="secondary"] {{ color: {c.text_secondary}; }}
QLabel[role="section"] {{ color: {c.text_faint}; font-size: {f.small}px; font-weight: 600; }}
QLabel[role="label"] {{ color: {c.text_secondary}; font-weight: 500; }}
QLabel[role="caption"] {{ color: {c.text_faint}; font-size: {f.small}px; }}
QLabel[role="bigNumber"] {{ font-size: 40px; font-weight: 600; }}
QLabel[role="statValue"] {{ font-weight: 600; }}
QLabel[role="countDanger"] {{ color: {c.danger_text}; font-size: 18px; font-weight: 600; }}
QLabel[role="status"] {{ color: {c.text_faint}; font-size: {f.small}px; }}
QLabel[role="pillInfo"] {{
    background: {c.info_soft}; color: {c.info_text}; border-radius: 12px;
    padding: 0 10px; font-size: {f.small}px; font-weight: 500;
}}
QLabel[role="pillAccent"] {{
    background: {c.accent_soft}; color: {c.accent_pill_text}; border-radius: 12px;
    padding: 0 10px; font-size: {f.small}px; font-weight: 500;
}}
QLabel[role="chipNeutral"] {{
    background: {c.raised}; color: {c.text_secondary}; border-radius: 11px;
    padding: 0 8px; font-size: {f.small}px;
}}

/* ---------- buttons ---------- */
QPushButton {{
    background: transparent; color: {c.text_secondary};
    border: 1px solid {c.border}; border-radius: {L.radius}px;
    padding: 0 14px; min-height: 36px; font-weight: 500;
}}
QPushButton:hover {{ background: {c.card}; }}
QPushButton:pressed {{ background: {c.raised}; }}
QPushButton:disabled {{ color: {c.text_disabled}; border-color: {c.card}; }}
QPushButton[variant="primary"] {{
    background: {c.accent}; color: {c.accent_ink}; border: none; font-weight: 600; min-height: 42px;
}}
QPushButton[variant="primary"]:hover {{ background: {c.accent_hover}; }}
QPushButton[variant="primary"]:pressed {{ background: {c.accent_pressed}; }}
QPushButton[variant="primary"]:disabled {{ background: {c.raised}; color: {c.text_disabled}; }}
QPushButton[variant="danger"] {{
    background: {c.danger}; color: {c.danger_ink}; border: none; font-weight: 600; min-height: 42px;
}}
QPushButton[variant="danger"]:hover {{ background: {c.danger_hover}; }}
QPushButton[variant="danger"]:disabled {{ background: {c.raised}; color: {c.text_disabled}; }}
QPushButton[variant="icon"] {{ padding: 0; min-height: 0; }}
QPushButton[variant="ghost"] {{ border: none; padding: 0; min-height: 0; border-radius: 7px; }}
QPushButton[variant="ghost"]:hover {{ background: {c.raised}; }}
QPushButton[variant="link"] {{
    border: none; padding: 2px 6px; min-height: 0; color: {c.text_faint};
    font-size: {f.small}px; border-radius: 6px;
}}
QPushButton[variant="link"]:hover {{ color: {c.text_secondary}; background: {c.card}; }}
QPushButton#ImagePicker {{
    background: {c.card}; color: {c.text}; padding: 0 12px 0 8px; text-align: left;
}}
QPushButton#ImagePicker:hover {{ border-color: {c.picker_hover}; }}
QPushButton#TopPrimary {{ min-height: 38px; padding: 0 16px 0 12px; }}
QFrame#ButtonGroup {{ background: {c.card}; border: 1px solid {c.border}; border-radius: {L.radius}px; }}

/* segmented control */
QFrame#Segmented {{ background: {c.window}; border: 1px solid {c.border}; border-radius: {L.radius}px; }}
QPushButton[variant="segment"] {{
    border: none; border-radius: 7px; min-height: 32px; padding: 0; color: {c.text_faint};
    font-size: 13px;
}}
QPushButton[variant="segment"]:checked {{ background: {c.raised}; color: {c.text}; }}
QPushButton[variant="segment"]:hover:!checked {{ color: {c.text_secondary}; background: transparent; }}

/* ---------- inputs ---------- */
QAbstractSpinBox {{
    background: {c.window}; color: {c.text}; border: 1px solid {c.border};
    border-radius: 7px; padding: 0 8px; min-height: 28px; font-size: 13px; font-weight: 500;
    selection-background-color: {c.accent}; selection-color: {c.accent_ink};
}}
QAbstractSpinBox:focus {{ border-color: {c.accent}; }}
QAbstractSpinBox::up-button, QAbstractSpinBox::down-button {{ width: 0; border: none; }}
QFrame#Field {{ background: {c.window}; border: 1px solid {c.border}; border-radius: {L.radius_small}px; }}
QFrame#Field QAbstractSpinBox {{ border: none; background: transparent; padding: 0; }}
QFrame#Field QLabel {{ color: {c.text_faint}; font-size: {f.small}px; }}
QPushButton[variant="stepper"] {{ background: transparent; border: none; border-radius: 4px; padding: 0;
    min-height: 0; min-width: 0; }}
QPushButton[variant="stepper"]:hover {{ background: {c.raised}; }}
QPushButton[variant="stepper"]:pressed {{ background: {c.track_off}; }}

QSlider::groove:horizontal {{ height: 4px; background: {c.raised}; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {c.accent}; border-radius: 2px; }}
QSlider::handle:horizontal {{
    background: {c.text}; width: 16px; height: 16px; margin: -6px 0; border-radius: 8px;
    border: 3px solid {c.accent};
}}
QSlider::handle:horizontal:hover {{ background: {c.slider_hover}; }}

/* ---------- cards ---------- */
QFrame#HintCard {{ background: {c.card}; border-radius: {L.radius}px; }}
QFrame#Card {{ background: {c.card}; border-radius: {L.radius_card}px; }}
QFrame#CountCard {{ background: {c.card}; border-radius: {L.radius}px; }}
QFrame#ActivityRow {{ border-radius: {L.radius}px; background: transparent; }}
QFrame#ActivityRow[latest="true"] {{ background: {c.card_alt}; }}
QLabel#ActivityTitle {{ font-weight: 500; }}

/* ---------- canvas overlays ---------- */
QGraphicsView#DetectCanvas {{ background: {c.canvas}; border: none; }}
QFrame#Chip {{
    background: rgba(22, 23, 20, 235); border: 1px solid {c.border}; border-radius: 16px;
}}
QFrame#Chip QLabel {{ color: {c.text_secondary}; font-size: 13px; }}
QFrame#Legend QLabel {{ font-size: {f.small}px; }}
QFrame#Toolbar {{
    background: rgba(22, 23, 20, 242); border: 1px solid {c.border}; border-radius: 12px;
}}
QFrame#Toolbar QLabel {{ color: {c.text_secondary}; font-size: 13px; font-weight: 500; }}
QPushButton[variant="toolbar"] {{ border: none; border-radius: 8px; min-height: 0; padding: 0; }}
QPushButton[variant="toolbar"]:hover {{ background: {c.raised}; }}
QPushButton[variant="toolbar"]:checked {{ background: {c.accent_soft}; }}

/* ---------- scrolling ---------- */
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {c.raised}; border-radius: 3px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 8px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {c.raised}; border-radius: 3px; min-width: 30px; }}
QMessageBox {{ background: {c.panel}; }}
"""


def build_light_stylesheet(light, ui: str, brand: str) -> str:
    """Light palette for text-heavy windows; applied on the window itself, so it overrides the
    dark program-wide sheet inside that window only. Windows opt in by objectName 'LightWindow'."""
    c = light
    return f"""
#LightWindow {{ background: {c.page}; }}
#LightWindow[tone="gray"] {{ background: {c.page_gray}; }}
#LightWindow[tone="gray"] QHeaderView::section {{ background: {c.panel_head}; }}
#LightWindow QFrame#PanelHead {{ background: {c.panel_head}; border-bottom: 1px solid {c.rule};
    border-top-left-radius: 6px; border-top-right-radius: 6px; }}
#LightWindow QFrame#Tile {{ background: {c.panel_head}; border-radius: 6px; }}
#LightWindow QFrame#ChoiceCard {{ background: {c.surface}; border: 1px solid {c.field_border}; border-radius: 6px; }}
#LightWindow QFrame#ChoiceCard:hover, #LightWindow QFrame#ChoiceCard:focus {{ border: 2px solid {c.accent};
    background: {c.accent_soft}; }}
#LightWindow QFrame#Tile[on="page"] {{ background: {c.surface}; border: 1px solid {c.border}; }}
#LightWindow QLabel[role="tileNumber"] {{ font-size: 20px; font-weight: 600; color: {c.text}; }}
#LightWindow QLabel[role="tileLabel"] {{ font-size: 12px; color: {c.text_muted}; }}
#LightWindow QLabel#Thumbnail {{ background: {c.panel_head}; border: 1px solid {c.rule}; border-radius: 6px;
    color: {c.text_muted}; font-size: 12px; }}
#LightWindow QWidget {{ color: {c.text}; font-family: "{ui}"; font-size: 14px; background: transparent; }}
#LightWindow QFrame#LightHeader {{ background: {c.header}; }}
#LightWindow QFrame#LightCard {{ background: {c.surface}; border: 1px solid {c.border}; border-radius: 6px; }}
#LightWindow QFrame#LightCardFooter {{ background: {c.page}; border-top: 1px solid {c.rule};
    border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }}
#LightWindow QFrame#LightRule {{ background: {c.rule}; border: none; }}
#LightWindow QLabel[role="title"] {{ font-size: 21px; font-weight: 600; }}
#LightWindow QLabel[role="body"] {{ color: {c.text_secondary}; }}
#LightWindow QLabel[role="muted"] {{ color: {c.text_muted}; font-size: 13px; }}
#LightWindow QLabel[role="field"] {{ font-weight: 500; }}
#LightWindow QLabel[state="ok"] {{ color: {c.text_secondary}; font-size: 13px; }}
#LightWindow QLabel[state="note"] {{ color: {c.note_text}; font-size: 13px; }}
#LightWindow QLabel[state="bad"] {{ color: {c.danger_text}; font-size: 13px; }}
#LightWindow QLineEdit {{ background: {c.page}; border: 1px solid {c.field_border}; border-radius: 4px;
    padding: 0 10px; min-height: 32px; color: {c.text}; selection-background-color: {c.accent}; }}
#LightWindow QLineEdit[state="bad"] {{ border-color: {c.danger_strong}; }}
#LightWindow QComboBox {{ background: {c.surface}; border: 1px solid {c.field_border}; border-radius: 4px;
    padding: 0 10px; min-height: 26px; color: {c.text}; }}
#LightWindow QComboBox QAbstractItemView {{ background: {c.surface}; color: {c.text};
    selection-background-color: {c.accent_soft}; selection-color: {c.text}; }}
#LightWindow QPushButton {{ background: {c.surface}; border: 1px solid {c.field_border}; border-radius: 4px;
    padding: 0 14px; min-height: 32px; color: {c.text}; font-weight: 500; }}
#LightWindow QPushButton:hover {{ background: {c.button}; }}
#LightWindow QPushButton[variant="secondary"] {{ background: {c.button}; }}
#LightWindow QPushButton[variant="primary"] {{ background: {c.accent}; border: none; color: {c.accent_ink};
    font-weight: 600; }}
#LightWindow QPushButton[variant="primary"]:hover {{ background: {c.accent_hover}; }}
#LightWindow QPushButton[variant="primary"]:disabled {{ background: {c.disabled_fill}; color: {c.disabled_ink}; }}
#LightWindow QPushButton[variant="quiet"] {{ background: transparent; border: none; color: {c.text_secondary}; }}
#LightWindow QPushButton[variant="quiet"]:hover {{ color: {c.text}; }}
#LightWindow QPushButton[variant="header"] {{ background: transparent; border: 1px solid {c.header_edge}; color: {c.header_text};
    min-height: 30px; }}
#LightWindow QPushButton[variant="header"]:hover {{ background: {c.header_hover}; }}
#LightWindow QPushButton:disabled {{ color: {c.disabled_label}; }}
#LightWindow QLabel[role="header"] {{ color: {c.header_text}; font-size: 14px; }}
#LightWindow QLabel[role="headerMuted"] {{ color: {c.header_muted}; font-size: 14px; }}
#LightWindow QLabel[role="section"] {{ font-size: 12px; font-weight: 600; color: {c.text_muted};
    letter-spacing: 0.4px; }}
#LightWindow QLabel[role="h1"] {{ font-size: 24px; font-weight: 600; }}
#LightWindow QLabel[role="h2"] {{ font-size: 16px; font-weight: 600; }}
#LightWindow QLabel[role="small"] {{ color: {c.text_secondary}; font-size: 13px; }}
#LightWindow QLabel[state="done"] {{ color: {c.link}; font-weight: 600; }}
#LightWindow QLabel[state="warn"] {{ color: {c.warn_text}; font-weight: 600; }}
#LightWindow QLabel[state="idle"] {{ color: {c.text_muted}; }}
#LightWindow QFrame#LightSide {{ background: {c.surface}; border-right: 1px solid {c.border}; }}
#LightWindow QFrame#LightPanel {{ background: {c.surface}; border: 1px solid {c.border}; border-radius: 6px; }}
#LightWindow QFrame#StepRow {{ background: {c.surface}; border-bottom: 1px solid {c.rule}; }}
#LightWindow QListWidget {{ background: transparent; border: none; outline: none; }}
#LightWindow QListWidget::item {{ padding: 6px 14px; border-left: 3px solid transparent; color: {c.text}; }}
#LightWindow QListWidget::item:selected {{ background: {c.list_selected}; border-left: 3px solid {c.accent};
    color: {c.text}; font-weight: 600; }}
#LightWindow QListWidget::item:hover:!selected {{ background: {c.button}; }}
#LightWindow QTableWidget {{ background: {c.surface}; border: 1px solid {c.border}; border-radius: 6px;
    gridline-color: {c.rule}; selection-background-color: {c.table_selected}; selection-color: {c.text}; }}
#LightWindow QTableWidget::item {{ padding: 0 10px; border-bottom: 1px solid {c.rule}; }}
#LightWindow QHeaderView::section {{ background: {c.page}; color: {c.text_muted}; font-size: 12px;
    font-weight: 600; border: none; border-bottom: 1px solid {c.border}; padding: 6px 10px; }}
#LightWindow QPlainTextEdit {{ background: {c.surface}; border: 1px solid {c.border}; border-radius: 6px;
    font-family: "Consolas", "Menlo", monospace; font-size: 12px; color: {c.text_secondary}; }}
#LightWindow QScrollArea {{ border: none; }}
#LightWindow QScrollBar:vertical {{ width: 10px; background: transparent; }}
#LightWindow QScrollBar::handle:vertical {{ background: {c.scrollbar}; border-radius: 4px; min-height: 30px; }}
#LightWindow QScrollBar:horizontal {{ height: 10px; background: transparent; }}
#LightWindow QScrollBar::handle:horizontal {{ background: {c.scrollbar}; border-radius: 4px; min-width: 30px; }}
#LightWindow QScrollBar::add-line, #LightWindow QScrollBar::sub-line {{ width: 0; height: 0; }}
"""
