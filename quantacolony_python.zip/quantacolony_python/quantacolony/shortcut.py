"""Creates Desktop and Start menu shortcuts that open QuantaColony without a terminal, and gives
.qcproj files the QuantaColony icon.

Run once from the project folder:  uv run quantacolony-shortcut
(or double-click "Create desktop shortcut.bat").

A file's icon in Windows Explorer comes from a registry entry for its extension, not from
the file. register_project_files writes that entry for the current user only (no
administrator rights needed): .qcproj files show the QuantaColony icon, and double-clicking
one opens it in QuantaColony (a project from the library opens; any other is imported).

The shortcut starts .venv\\Scripts\\quantacolony-gui.exe, the console-free launcher
that uv builds from [project.gui-scripts], with the project folder as working
directory so results land in its output folder.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from .theme.icons import LOGO_ICO

SHORTCUT_NAME = "QuantaColony.lnk"

# Paths reach PowerShell through environment variables, so spaces and quotes need no escaping
POWERSHELL_SCRIPT = r"""
$shell = New-Object -ComObject WScript.Shell
$made = @()
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $path = Join-Path $folder $env:QC_NAME
    $link = $shell.CreateShortcut($path)
    $link.TargetPath = $env:QC_TARGET
    $link.WorkingDirectory = $env:QC_WORKDIR
    $link.IconLocation = "$($env:QC_ICON),0"
    $link.Description = 'QuantaColony Colony Detection'
    $link.Save()
    $made += $path
}
$made -join "`n"
"""


def launcher_path() -> Path:
    """The console-free launcher next to this environment's python.exe."""
    return Path(sys.executable).parent / "quantacolony-gui.exe"


def create_shortcuts(project_folder: Path | None = None) -> list[str]:
    if sys.platform != "win32":
        raise SystemExit("Shortcuts are created on Windows only. Elsewhere, run: uv run quantacolony")
    target = launcher_path()
    if not target.is_file():
        raise SystemExit(f"Launcher not found: {target}\nRun 'uv sync' in the project folder, then try again.")
    env = dict(os.environ, QC_NAME=SHORTCUT_NAME, QC_TARGET=str(target),
               QC_WORKDIR=str(project_folder or Path.cwd()), QC_ICON=str(LOGO_ICO))
    result = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", POWERSHELL_SCRIPT],
                            env=env, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise SystemExit(f"Could not create the shortcuts:\n{result.stderr.strip()}")
    return result.stdout.strip().splitlines()


PROG_ID = "QuantaColony.Project"


def register_project_files(launcher: Path | None = None, icon: Path | None = None) -> None:
    """Associate .qcproj with QuantaColony for the current user: icon and double-click to open."""
    if sys.platform != "win32":
        raise SystemExit("File icons are registered on Windows only.")
    import ctypes
    import winreg
    launcher = launcher or launcher_path()
    icon = icon or LOGO_ICO
    classes = r"Software\Classes"
    entries = {
        rf"{classes}\.qcproj": PROG_ID,
        rf"{classes}\{PROG_ID}": "QuantaColony project",
        rf"{classes}\{PROG_ID}\DefaultIcon": f'"{icon}",0',
        rf"{classes}\{PROG_ID}\shell\open\command": f'"{launcher}" "%1"',
    }
    for key_path, value in entries.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
            winreg.SetValueEx(key, "", 0, winreg.REG_SZ, value)
    SHCNE_ASSOCCHANGED, SHCNF_IDLIST = 0x08000000, 0
    ctypes.windll.shell32.SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, None, None)   # Explorer redraws icons


def main() -> int:
    for path in create_shortcuts():
        print(f"Created {path}")
    register_project_files()
    print("QuantaColony project files (.qcproj) now show the QuantaColony icon.")
    print("Double-click QuantaColony on the Desktop, or find it in the Start menu.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
