"""Scoring automatic detection on a project's corrected results.

Every detected index of a project is detected again with its own saved settings (or with
settings changed by `change`) and scored against the colonies a person kept (core/scoring.py).

    uv run python -m quantacolony.evaluation "D:\\Projects\\Crowding.qcproj"
    uv run python -m quantacolony.evaluation Crowding.qcproj --set split=1 split_pinch=0.3

A project file given on the command line is copied into a temporary library and scored there;
the file itself is never changed.
"""

from __future__ import annotations

import argparse
import sys
import tempfile
from dataclasses import dataclass, replace
from pathlib import Path

from .core.detection import perform_detection
from .core.params import DetectionParams
from .core.scoring import Score, score
from .data import DataManager, Settings, create_library


@dataclass(frozen=True)
class IndexScore:
    index_id: int
    label: str
    params: DetectionParams
    score: Score
    edited: bool                      # a person changed the detector's result on this index


def score_open_project(manager: DataManager, change: dict | None = None) -> list[IndexScore]:
    """Score every detected index of the open project."""
    results = []
    for info in manager.project_info().indices:
        if not info.revision:
            continue
        packet = manager.checkout_image(info.index_id)
        saved = packet.saved
        params = replace(saved.params, **(change or {}))
        detected = perform_detection(packet.record.image, params, region_mask=packet.record.mask)
        edited = bool(manager.edit_log(info.index_id))
        label = " · ".join(lv.display for lv in info.labels)
        results.append(IndexScore(info.index_id, label, params, score(detected, saved.colonies), edited))
    return results


def score_file(path: Path, change: dict | None = None) -> list[IndexScore]:
    """Score a project file without changing it (it is copied into a temporary library)."""
    with tempfile.TemporaryDirectory() as folder:
        manager = DataManager(Settings(folder=Path(folder) / "settings"))
        manager.use_library(create_library(Path(folder) / "Library"))
        manager.open_project(manager.import_project_file(Path(path)))
        try:
            return score_open_project(manager, change)
        finally:
            manager.close()


def table(results: list[IndexScore]) -> str:
    lines = [f"{'index':<22}{'reference':>10}{'detected':>10}{'matched':>9}{'missed':>8}{'extra':>7}"
             f"{'corrections':>13}{'F1':>7}  edited"]
    for r in results:
        s = r.score
        lines.append(f"{r.label:<22}{s.reference:>10}{s.detected:>10}{s.matched:>9}{s.missed:>8}{s.extra:>7}"
                     f"{s.corrections:>13}{s.f1:>7.3f}  {'yes' if r.edited else 'no'}")
    if results:
        total = sum((r.score for r in results), Score(0, 0, 0))
        lines.append(f"{'all':<22}{total.reference:>10}{total.detected:>10}{total.matched:>9}{total.missed:>8}"
                     f"{total.extra:>7}{total.corrections:>13}{total.f1:>7.3f}")
    return "\n".join(lines)


def _value(text: str):
    try:
        return float(text)
    except ValueError:
        return text


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Score automatic detection against a project's corrected results.")
    parser.add_argument("project", type=Path)
    parser.add_argument("--set", nargs="*", default=[], metavar="NAME=VALUE",
                        help="change a detection setting on every index, e.g. split=1 split_pinch=0.3")
    args = parser.parse_args(argv)
    change = {}
    for item in args.set:
        name, _, value = item.partition("=")
        change[name] = _value(value)
    if "split" in change:
        change["split"] = bool(change["split"])
    print(table(score_file(args.project, change)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
