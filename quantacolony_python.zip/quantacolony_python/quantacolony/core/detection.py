"""Automatic colony detection (Qt-free).

Irregular mode reproduces the MATLAB pipeline exactly: on the bundled image
it returns the same 33 colonies as the saved MATLAB result. Circular mode
uses scikit-image's Hough transform in place of MATLAB's imfindcircles; the
two algorithms differ, so circular results approximate the MATLAB ones.
"""

from __future__ import annotations

import numpy as np
from scipy import ndimage
from skimage import measure
from skimage.transform import hough_circle, hough_circle_peaks

from .colony_set import KIND_CIRCULAR, KIND_IRREGULAR, ColonySet
from .params import CIRCULAR, DetectionParams

# Increase when a change alters which colonies automatic detection returns.
# Each committed result records the version that produced it.
DETECTION_VERSION = 1

# MATLAB rgb2gray weights
_GRAY_WEIGHTS = np.array([0.298936021293775, 0.587043074451121, 0.114020904255103])


def prepare_image(image_rgb: np.ndarray, level: float) -> np.ndarray:
    """Threshold the plate image (prepareImage).

    Returns a boolean mask that is True on candidate colony pixels.
    level >= 0: pixels darker than or equal to level are kept.
    level <  0: pixels brighter than or equal to 1 - |level| are kept.
    """
    gray = np.round(image_rgb[..., :3].astype(float) @ _GRAY_WEIGHTS) / 255.0
    if level >= 0:
        return ~(gray > level)
    return ~((1.0 - gray) > abs(level))


def apply_roi_mask(mask: np.ndarray, roi: tuple[float, float, float, float] | None) -> np.ndarray:
    """Keep only the rectangle roi = (x, y, width, height) (applyROIMask)."""
    if roi is None:
        return mask
    x, y, w, h = roi
    rows, cols = mask.shape
    r0, r1 = max(0, int(round(y))), min(rows, int(round(y + h)) + 1)
    c0, c1 = max(0, int(round(x))), min(cols, int(round(x + w)) + 1)
    limited = np.zeros_like(mask)
    limited[r0:r1, c0:c1] = mask[r0:r1, c0:c1]
    return limited


def detect_irregular_colonies(mask: np.ndarray, params: DetectionParams) -> ColonySet:
    """Connected components filtered by area and eccentricity (detectIrregularColonies)."""
    labels = measure.label(mask, connectivity=2)
    min_area = np.pi * params.rmin ** 2
    max_area = np.pi * params.rmax ** 2

    centers, radii, boundaries, eccentricities = [], [], [], []
    for region in measure.regionprops(labels):
        area = region.area
        if not (area < params.maxpix and min_area <= area <= max_area
                and region.eccentricity <= params.sense):
            continue
        row, col = region.centroid
        centers.append((col, row))
        radii.append(np.sqrt(area / np.pi))
        eccentricities.append(region.eccentricity)
        boundaries.append(_trace_outline(region))

    return ColonySet.from_columns(
        centers=np.array(centers).reshape(-1, 2),
        radii=radii,
        boundaries=boundaries,
        kinds=[KIND_IRREGULAR] * len(radii),
        eccentricities=eccentricities,
    )


def _trace_outline(region) -> np.ndarray:
    """Outline of one region as (M, 2) x/y points, in image coordinates."""
    r0, c0, _, _ = region.bbox
    padded = np.pad(region.image, 1).astype(float)
    contours = measure.find_contours(padded, 0.5)
    outline = max(contours, key=len)            # outer edge; inner contours are holes
    return np.column_stack([outline[:, 1] + c0 - 1, outline[:, 0] + r0 - 1])


def detect_circular_colonies(mask: np.ndarray, params: DetectionParams) -> ColonySet:
    """Hough circle detection on the filtered colony mask (detectCircularColonies)."""
    labels = measure.label(mask, connectivity=2)
    sizes = np.bincount(labels.ravel())
    keep = sizes < params.maxpix
    keep[0] = False
    filtered = keep[labels]
    edges = filtered & ~ndimage.binary_erosion(filtered)

    radii_range = np.arange(max(1, int(params.rmin)), int(params.rmax) + 1)
    if len(radii_range) == 0 or not edges.any():
        return ColonySet.empty()
    accumulator = hough_circle(edges, radii_range)
    # The normalized accumulator is the fraction of a circle's edge that is
    # present. Higher sensitivity lowers the required fraction, so more
    # circles are found, as with imfindcircles.
    threshold = float(np.clip(1.45 - params.sense, 0.3, 0.95))
    _, cx, cy, found_radii = hough_circle_peaks(
        accumulator, radii_range, threshold=threshold,
        min_xdistance=int(params.rmin), min_ydistance=int(params.rmin))

    # A colony is a filled blob, so its center must lie on the mask
    rows = np.clip(cy, 0, filtered.shape[0] - 1)
    cols = np.clip(cx, 0, filtered.shape[1] - 1)
    centered = filtered[rows, cols]
    n = int(centered.sum())
    return ColonySet.from_columns(
        centers=np.column_stack([cx, cy])[centered].astype(float),
        radii=found_radii[centered].astype(float),
        boundaries=[None] * n,
        kinds=[KIND_CIRCULAR] * n,
    )


def calc_overlap_fraction(r1: float, r2: float, d: float) -> float:
    """Fraction of the smaller circle (r2) covered by the larger (r1)."""
    if d >= r1 + r2:
        return 0.0
    if d <= abs(r1 - r2):
        return 1.0
    part1 = r1 ** 2 * np.arccos((d ** 2 + r1 ** 2 - r2 ** 2) / (2 * d * r1))
    part2 = r2 ** 2 * np.arccos((d ** 2 + r2 ** 2 - r1 ** 2) / (2 * d * r2))
    part3 = 0.5 * np.sqrt((-d + r1 + r2) * (d + r1 - r2) * (d - r1 + r2) * (d + r1 + r2))
    return float((part1 + part2 - part3) / (np.pi * r2 ** 2))


def remove_overlaps(colonies: ColonySet, threshold: float = 0.5) -> ColonySet:
    """Drop a colony when >= threshold of its area lies inside a larger one (removeOverlaps)."""
    n = len(colonies)
    if n <= 1:
        return colonies
    keep = np.ones(n, dtype=bool)
    order = np.argsort(-colonies.radii, kind="stable")
    for a, larger in enumerate(order):
        if not keep[larger]:
            continue
        for smaller in order[a + 1:]:
            if not keep[smaller]:
                continue
            d = float(np.hypot(*(colonies.centers[larger] - colonies.centers[smaller])))
            fraction = calc_overlap_fraction(colonies.radii[larger], colonies.radii[smaller], d)
            if fraction >= threshold:
                keep[smaller] = False
    return colonies.subset(keep)


def perform_detection(image_rgb: np.ndarray, params: DetectionParams,
                      roi: tuple[float, float, float, float] | None = None,
                      region_mask: np.ndarray | None = None) -> ColonySet:
    """Full automatic detection for one image (performDetection).

    region_mask marks the pixels that belong to the index (from cropping);
    pixels outside it are never colony pixels, even where the masked-out
    black would pass a dark-colony threshold.
    Returned colonies carry placeholder ids (-1); the session assigns real ids.
    """
    mask = apply_roi_mask(prepare_image(image_rgb, params.level), roi)
    if region_mask is not None:
        mask = mask & region_mask
    if params.detection_type == CIRCULAR:
        found = detect_circular_colonies(mask, params)
    else:
        found = detect_irregular_colonies(mask, params)
    return remove_overlaps(found)


def filter_valid_colonies(candidates: ColonySet, existing: ColonySet,
                          threshold: float = 0.5) -> ColonySet:
    """Drop candidates that overlap an existing colony by >= threshold (filterValidColonies)."""
    if len(candidates) == 0 or len(existing) == 0:
        return candidates
    keep = np.ones(len(candidates), dtype=bool)
    for i in range(len(candidates)):
        for j in range(len(existing)):
            d = float(np.hypot(*(candidates.centers[i] - existing.centers[j])))
            r_new, r_old = candidates.radii[i], existing.radii[j]
            larger, smaller = max(r_new, r_old), min(r_new, r_old)
            if calc_overlap_fraction(larger, smaller, d) >= threshold:
                keep[i] = False
                break
    return candidates.subset(keep)
