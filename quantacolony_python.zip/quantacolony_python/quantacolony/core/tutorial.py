"""The tutorial: steps through every module on the Crowding project (Qt-free).

Each step gives a task, checks it against what is on screen (a TutorialState the navigator
builds), and once the task is done shows what the result means. The steps follow the wild-type
dilution series: ten plates from one culture spread at 100X to 128000X, so plating density is
the only difference between them.

    TutorialState   what is on screen: the screen, whether the open project is a tutorial
                    project, the Cropping photo, the Colony Detection index, the Stats choices
    Step            module, title, task, finding; done(state) says when the task is done
                    (None: a reading step, done when the user moves on)
    STEPS           the tutorial, in order
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

DILUTION = "dilution_level"                       # the tutorial project's variable


@dataclass(frozen=True)
class TutorialState:
    screen: str = ""                              # 'home', 'project', 'cropping', 'detection', 'stats', 'new'
    tutorial_open: bool = False                   # the open project is a tutorial project
    photo: int = -1                               # Cropping: position of the photo shown (0 is the first)
    index_values: tuple = ()                      # Colony Detection: level values of the index shown
    split: bool = False                           # Colony Detection: Split touching colonies is on
    analysis: str = ""                            # Stats: the chosen analysis
    slots: dict = field(default_factory=dict)     # Stats: variable name -> slot key ('' pooled)
    measure: str = ""                             # Stats: the measure of an analysis with one row per index
    leave_out: bool = False                       # Stats: overplated plates left out


@dataclass(frozen=True)
class Step:
    key: str
    module: str
    title: str
    task: str
    finding: str
    done: Callable[[TutorialState], bool] | None = None


def _in(screen: str):
    return lambda s: s.tutorial_open and s.screen == screen


def _stats(analysis: str, x_axis: bool = True, measure: str = "", leave_out: bool | None = None):
    def check(s: TutorialState) -> bool:
        return (s.tutorial_open and s.screen == "stats" and s.analysis == analysis
                and (not x_axis or s.slots.get(DILUTION) == "x")
                and (not measure or s.measure == measure)
                and (leave_out is None or s.leave_out == leave_out))
    return check


STEPS: tuple[Step, ...] = (
    Step("open", "Projects", "Open the Crowding project",
         "On the home page, double-click Crowding.",
         "The project page lists the three steps of every project: Cropping, Colony Detection and Stats. "
         "All ten plates here are cropped and detected, so each module shows a finished result. "
         "Every plate came from one culture and was incubated and photographed with the others; only the "
         "dilution differs, from 100X to 128000X.",
         lambda s: s.tutorial_open and s.screen in ("project", "cropping", "detection", "stats")),
    Step("dish", "Cropping", "The dish sets the scale",
         "Open Cropping and go to photo 8 (32000X) with the arrows or the photo list.",
         "The circle sits on the edge of the agar. Its size against the dish's known diameter (90 mm) "
         "gives the scale in pixels per millimeter, so colony sizes come out in micrometers. Photo 8 was "
         "taken from farther away: the dish looks smaller, and its scale is smaller with it, so its "
         "colony sizes still agree with the other plates.",
         lambda s: _in("cropping")(s) and s.photo == 7),
    Step("sparse", "Colony Detection", "A sparse plate",
         "Open Colony Detection and choose 128000X: click the plate name in the top bar for the board of "
         "every plate.",
         "Every colony stands apart from its neighbors, so automatic detection finds nearly all of them. "
         "Sparse plates like this one are the easy case.",
         lambda s: _in("detection")(s) and s.index_values == ("128000",)),
    Step("crowded", "Colony Detection", "Touching colonies",
         "Now open 500X and turn on Show growth in the summary card. Then, under Detect automatically, turn "
         "on Split touching colonies.",
         "Touching colonies form one blob. The saved result on this plate was made before QuantaColony split "
         "them: 82 colonies were added by hand and 143 merged detections deleted, and Show growth tints the "
         "touching colonies left unmarked amber. With splitting on, detection cuts pairs and chains apart "
         "where they narrow and draws the pieces violet. Split colonies count toward colony counts; Stats "
         "can leave them out of sizes, and the capture ratio treats them as merged growth. To keep the saved "
         "result, choose Discard changes when you leave this plate.",
         lambda s: _in("detection")(s) and s.index_values == ("500",) and s.split),
    Step("size", "Stats", "Crowding sets colony size",
         "Open Stats, choose Box plots, and put Dilution Level on the X axis.",
         "Median colony radius rises about 2.7-fold from 100X to 128000X. Nothing differs between these plates "
         "except how many cells were spread, so crowding alone changes colony size. Comparing colony size "
         "between plates that carry different numbers of colonies mixes this effect into the comparison.",
         _stats("box")),
    Step("count", "Stats", "Colony count tracks crowding",
         "Choose Plate metrics, keep Dilution Level on the X axis, and set Measure to Colonies counted.",
         "A 256-fold change in dilution (500X to 128000X) gives only about an 18-fold change in colony count: "
         "on denser plates, fewer of the cells spread establish separate colonies. The colonies that "
         "establish share the plate, so colony count, not the number of cells plated, is what tracks "
         "crowding. At 100X the count drops below 500X: colonies merged.",
         _stats("plate_metrics", measure="colony_count")),
    Step("capture", "Stats", "The capture ratio finds overplated plates",
         "Set Measure to Capture ratio.",
         "Capture ratio is the share of all growth that lies inside separate colonies. 100X falls below the "
         "25% line: much of its growth merged into lawn, so its colony count and sizes cannot be trusted. "
         "500X and every sparser plate stay above it. The cutoff works from the photo alone, so it applies "
         "to plates with no dilution series behind them.",
         _stats("plate_metrics", measure="capture_ratio")),
    Step("leave_out", "Stats", "Leave overplated plates out",
         "Set Overplated to Leave out.",
         "100X now leaves every analysis, and the notes say so. Use the same switch on your own projects.",
         lambda s: s.tutorial_open and s.screen == "stats" and s.leave_out),
    Step("fidelity", "Stats", "Check measurement precision",
         "Choose Measurement fidelity.",
         "Each colony's radius is uncertain by about half a pixel at its edge, so colonies spanning few pixels "
         "measure poorly. Here every plate's median colony is measured to within about 5% (High fidelity; 100X "
         "is just over, at Good), so measurement precision limits no comparison in this series. Check this on "
         "your own photos before comparing sizes.",
         _stats("fidelity", x_axis=False)),
    Step("design", "Your experiments", "Plan for crowding",
         "Read this, then press Finish.",
         "Colony size depends on how many colonies share a plate, and how many establish depends on the "
         "strain itself. So: plate each condition at several densities, so their colony counts overlap; "
         "compare plates with similar colony counts; leave out plates below 25% capture ratio; and check "
         "measurement fidelity."),
)


def step_index(key: str) -> int:
    return next((i for i, step in enumerate(STEPS) if step.key == key), 0)


def is_done(step: Step, state: TutorialState) -> bool:
    return step.done is not None and bool(step.done(state))
