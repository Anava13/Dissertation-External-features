"""Cropping model (Qt-free): plate layouts, the regions they produce, proposals and the index board.

A photo's layout describes the plate: a round dish (circle plus cut angles)
or a rectangular plate (rotated rectangle plus a rows x columns grid). Each
section of the layout becomes one region, stored by the DataManager as an
assignment of one index (one level of every variable).

Angles in layouts are degrees clockwise from the top of the photo (12 o'clock).
Region geometry handed to the DataManager uses data.regions' convention
(degrees clockwise from +x), so the conversion lives here, in one place.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field, replace

import numpy as np

CIRCULAR, RECTANGULAR = "circular", "rectangular"
PHOTO, SECTION = "photo", "section"            # where a variable's level is set
ROWS, COLUMNS, PAGES = "rows", "columns", "pages"


# =========================================================================
# layouts
# =========================================================================
@dataclass(frozen=True)
class DishLayout:
    """Round dish: circle (photo pixels) and cut angles (degrees clockwise from the top)."""

    cx: float
    cy: float
    r: float
    cuts: tuple[float, ...]
    kind: str = CIRCULAR

    @classmethod
    def template(cls, cx: float, cy: float, r: float, sections: int, rotation: float = 0.0) -> "DishLayout":
        cuts = () if sections <= 1 else tuple((rotation + k * 360.0 / sections) % 360 for k in range(sections))
        return cls(cx, cy, r, tuple(sorted(cuts)))

    @property
    def section_count(self) -> int:
        return max(1, len(self.cuts))

    def spans(self) -> list[tuple[float, float]]:
        """(start, end) of each section, clockwise from the top; end may exceed 360."""
        if len(self.cuts) <= 1:
            return [(0.0, 360.0)]
        cuts = sorted(self.cuts)
        return [(a, b if b > a else b + 360) for a, b in zip(cuts, cuts[1:] + cuts[:1])]

    def rotated(self, delta: float) -> "DishLayout":
        return replace(self, cuts=tuple(sorted((c + delta) % 360 for c in self.cuts)))

    def moved(self, cx: float, cy: float) -> "DishLayout":
        return replace(self, cx=cx, cy=cy)

    def resized(self, r: float) -> "DishLayout":
        return replace(self, r=max(5.0, r))

    def with_cut(self, index: int, angle: float) -> "DishLayout":
        cuts = list(self.cuts)
        cuts[index] = angle % 360
        return replace(self, cuts=tuple(cuts))          # order kept while dragging; normalized on release

    def normalized(self) -> "DishLayout":
        return replace(self, cuts=tuple(sorted(c % 360 for c in self.cuts)))

    def with_added_cut(self, angle: float) -> "DishLayout":
        cuts = list(self.cuts)
        if not cuts:                                    # a whole dish needs two cuts to make two sections
            cuts = [angle % 360, (angle + 180) % 360]
        else:
            cuts.append(angle % 360)
        return replace(self, cuts=tuple(sorted(cuts)))

    def without_cut(self, index: int) -> "DishLayout":
        cuts = [c for i, c in enumerate(self.cuts) if i != index]
        return replace(self, cuts=tuple(cuts) if len(cuts) > 1 else ())

    def section_at(self, x: float, y: float) -> int:
        if math.hypot(x - self.cx, y - self.cy) > self.r:
            return -1
        angle = clock_angle(x - self.cx, y - self.cy)
        for i, (a, b) in enumerate(self.spans()):
            if a <= angle < b or a <= angle + 360 < b:
                return i
        return 0

    def label_point(self, index: int) -> tuple[float, float]:
        a, b = self.spans()[index]
        if self.section_count == 1:
            return self.cx, self.cy
        return point_at(self.cx, self.cy, (a + b) / 2, self.r * 0.62)

    def region(self, index: int) -> tuple[str, dict]:
        a, b = self.spans()[index]
        if self.section_count == 1:
            a, b = 0.0, 360.0
        return "sector", {"cx": self.cx, "cy": self.cy, "radius": self.r,
                          "start_deg": (a - 90) % 360,
                          "end_deg": (b - 90) % 360 if b - a < 360 else (a - 90) % 360 + 360}

    def to_dict(self) -> dict:
        return {"kind": CIRCULAR, "cx": self.cx, "cy": self.cy, "r": self.r, "cuts": list(self.cuts)}


@dataclass(frozen=True)
class GridLayout:
    """Rectangular plate: rotated rectangle (center, size, angle in degrees) cut into an even grid."""

    cx: float
    cy: float
    width: float
    height: float
    angle: float
    rows: int
    cols: int
    kind: str = RECTANGULAR

    @property
    def section_count(self) -> int:
        return self.rows * self.cols

    def _to_photo(self, u: float, v: float) -> tuple[float, float]:
        """Plate coordinates (u right, v down, from the center) to photo pixels."""
        t = math.radians(self.angle)
        return self.cx + u * math.cos(t) - v * math.sin(t), self.cy + u * math.sin(t) + v * math.cos(t)

    def _to_plate(self, x: float, y: float) -> tuple[float, float]:
        t = math.radians(self.angle)
        dx, dy = x - self.cx, y - self.cy
        return dx * math.cos(t) + dy * math.sin(t), -dx * math.sin(t) + dy * math.cos(t)

    def corners(self) -> np.ndarray:
        w, h = self.width / 2, self.height / 2
        return np.array([self._to_photo(u, v) for u, v in ((-w, -h), (w, -h), (w, h), (-w, h))])

    def cell(self, index: int) -> np.ndarray:
        row, col = divmod(index, self.cols)
        u0 = -self.width / 2 + col * self.width / self.cols
        v0 = -self.height / 2 + row * self.height / self.rows
        u1, v1 = u0 + self.width / self.cols, v0 + self.height / self.rows
        return np.array([self._to_photo(u, v) for u, v in ((u0, v0), (u1, v0), (u1, v1), (u0, v1))])

    def grid_lines(self) -> list[tuple[tuple[float, float], tuple[float, float]]]:
        w, h = self.width / 2, self.height / 2
        xs = [-w + c * self.width / self.cols for c in range(1, self.cols)]
        ys = [-h + r * self.height / self.rows for r in range(1, self.rows)]
        lines = [(self._to_photo(u, -h), self._to_photo(u, h)) for u in xs]
        lines += [(self._to_photo(-w, v), self._to_photo(w, v)) for v in ys]
        return lines

    def section_at(self, x: float, y: float) -> int:
        u, v = self._to_plate(x, y)
        if abs(u) > self.width / 2 or abs(v) > self.height / 2:
            return -1
        col = min(self.cols - 1, int((u + self.width / 2) / self.width * self.cols))
        row = min(self.rows - 1, int((v + self.height / 2) / self.height * self.rows))
        return row * self.cols + col

    def label_point(self, index: int) -> tuple[float, float]:
        cell = self.cell(index)
        return float(cell[:, 0].mean()), float(cell[:, 1].mean())

    def region(self, index: int) -> tuple[str, dict]:
        return "polygon", {"points": self.cell(index).round(2).tolist()}

    def moved(self, cx: float, cy: float) -> "GridLayout":
        return replace(self, cx=cx, cy=cy)

    def rotated(self, delta: float) -> "GridLayout":
        return replace(self, angle=(self.angle + delta) % 360)

    def corner_to(self, x: float, y: float) -> "GridLayout":
        """Resize symmetrically so a corner sits at (x, y)."""
        u, v = self._to_plate(x, y)
        return replace(self, width=max(10.0, 2 * abs(u)), height=max(10.0, 2 * abs(v)))

    def with_grid(self, rows: int, cols: int) -> "GridLayout":
        return replace(self, rows=max(1, min(24, rows)), cols=max(1, min(24, cols)))

    def to_dict(self) -> dict:
        return {"kind": RECTANGULAR, "cx": self.cx, "cy": self.cy, "width": self.width, "height": self.height,
                "angle": self.angle, "rows": self.rows, "cols": self.cols}


Layout = DishLayout | GridLayout


def layout_from_dict(data: dict) -> Layout:
    if data.get("kind") == RECTANGULAR:
        return GridLayout(data["cx"], data["cy"], data["width"], data["height"], data["angle"],
                          data["rows"], data["cols"])
    return DishLayout(data["cx"], data["cy"], data["r"], tuple(data.get("cuts", ())))


def clock_angle(dx: float, dy: float) -> float:
    """Degrees clockwise from 12 o'clock for a photo-pixel offset (y points down)."""
    return math.degrees(math.atan2(dx, -dy)) % 360


def point_at(cx: float, cy: float, angle: float, radius: float) -> tuple[float, float]:
    a = math.radians(angle)
    return cx + radius * math.sin(a), cy - radius * math.cos(a)


def default_layout(image: np.ndarray, plate: dict) -> Layout:
    """First layout for a photo: dish found automatically, or a centered grid."""
    rows, cols = image.shape[:2]
    if plate.get("type") == RECTANGULAR:
        return GridLayout(cols / 2, rows / 2, cols * 0.8, rows * 0.8, 0.0,
                          int(plate.get("rows", 2)), int(plate.get("cols", 2)))
    cx, cy, r = fit_dish(image)
    return DishLayout.template(cx, cy, r, int(plate.get("sections", 4)))


def fit_dish(image: np.ndarray) -> tuple[float, float, float]:
    """Dish circle (cx, cy, r) in photo pixels from the strongest large circle; centered guess if none."""
    from skimage.feature import canny
    from skimage.transform import hough_circle, hough_circle_peaks, rescale

    rows, cols = image.shape[:2]
    gray = image[..., :3].mean(axis=2) / 255.0 if image.ndim == 3 else image / 255.0
    scale = min(1.0, 300.0 / max(rows, cols))
    small = rescale(gray, scale, anti_aliasing=True) if scale < 1 else gray
    edges = canny(small, sigma=2.0)
    short = min(small.shape)
    radii = np.arange(int(short * 0.30), int(short * 0.52), 2)
    if edges.any() and len(radii):
        accumulator = hough_circle(edges, radii)
        _, x, y, r = hough_circle_peaks(accumulator, radii, total_num_peaks=1)
        if len(r):
            return float(x[0] / scale), float(y[0] / scale), float(r[0] / scale)
    return cols / 2, rows / 2, min(rows, cols) * 0.45


# =========================================================================
# levels, proposals and duplicates
# =========================================================================
@dataclass(frozen=True)
class VariableLevels:
    """One variable as Cropping sees it: name, display name and its levels (values and display text)."""

    name: str
    display_name: str
    values: tuple[str, ...]
    displays: tuple[str, ...]
    kind: str = ""                   # 'nominal', 'ordinal', 'replicate'

    def display(self, value: str) -> str:
        return self.displays[self.values.index(value)] if value in self.values else value


Levels = dict                       # variable name -> level value, one per variable


def index_key(levels: Levels, variables: list[VariableLevels]) -> tuple:
    return tuple(levels.get(v.name) for v in variables)


def complete(levels: Levels | None, variables: list[VariableLevels]) -> bool:
    return levels is not None and all(levels.get(v.name) in v.values for v in variables)


def step_photo_levels(levels: Levels, photo_variables: list[VariableLevels]) -> Levels:
    """Next combination of the whole-photo variables, the last one changing fastest (an odometer)."""
    stepped = dict(levels)
    for variable in reversed(photo_variables):
        current = stepped.get(variable.name)
        position = variable.values.index(current) if current in variable.values else -1
        position = (position + 1) % len(variable.values)
        stepped[variable.name] = variable.values[position]
        if position != 0:
            break
    return stepped


def propose_sections(previous: list[Levels | None], photo_variables: list[VariableLevels]) -> list[Levels | None]:
    """The previous photo's section levels with the whole-photo variables stepped to their next combination."""
    first = next((lv for lv in previous if lv), None)
    if first is None or not photo_variables:
        return [dict(lv) if lv else None for lv in previous]
    stepped = step_photo_levels(first, photo_variables)
    wide = {v.name: stepped[v.name] for v in photo_variables}
    return [dict(lv, **wide) if lv else None for lv in previous]


def duplicate_sections(sections: list[Levels | None], variables: list[VariableLevels],
                       elsewhere: dict[tuple, tuple[int, int]]) -> dict[int, str]:
    """Sections whose index is used twice on this photo or already sits on another photo -> reason."""
    problems: dict[int, str] = {}
    seen: dict[tuple, int] = {}
    for i, levels in enumerate(sections):
        if not complete(levels, variables):
            continue
        key = index_key(levels, variables)
        if key in seen:
            problems[i] = f"Section {seen[key] + 1} has the same index."
            problems.setdefault(seen[key], f"Section {i + 1} has the same index.")
        else:
            seen[key] = i
        if key in elsewhere:
            photo, section = elsewhere[key]
            problems[i] = f"Already on photo {photo}, section {section + 1}."
    return problems


def all_index_keys(variables: list[VariableLevels]) -> list[tuple]:
    return list(itertools.product(*(v.values for v in variables)))


def describe_key(key: tuple, variables: list[VariableLevels]) -> str:
    return " · ".join(v.display(value) for v, value in zip(variables, key))


# =========================================================================
# index board: any number of variables on two axes, plus pages
# =========================================================================
@dataclass(frozen=True)
class BoardCell:
    text: str                        # count text when a variable is folded into the cell, else ""
    state: str                       # Cropping: 'empty', 'proposed', 'confirmed', 'partial', 'duplicate'
                                     # Colony Detection: 'none', 'waiting', 'detected', 'review', 'partial'
    label: str                       # accessible description
    target: tuple | None             # what a click opens: (photo position, section) or (index id,)
    current: bool = False            # the cell holds the image that is open


@dataclass(frozen=True)
class Board:
    header_rows: list[list[tuple[str, int]]]     # per header row: (text, columns spanned)
    row_labels: list[list[str]]                  # per board row: one label per row variable ('' when repeated)
    cells: list[list[BoardCell]]
    counted: str                                 # display name of the variable folded into counts, or ''
    rows: list[str] = field(default_factory=list)
    columns: list[str] = field(default_factory=list)
    pages: list[str] = field(default_factory=list)


def default_view(variables: list[VariableLevels], scope: dict[str, str]) -> dict[str, str]:
    """Whole-photo variables on columns (one photo fills a column), section variables on rows."""
    return {v.name: COLUMNS if scope.get(v.name) == PHOTO else ROWS for v in variables}


def _layout_board(variables, view: dict[str, str], pages: dict[str, str], cell_for, max_columns: int) -> Board:
    """Rows, columns and pages of variables; cell_for(options, fixed, counted) makes each cell, where options
    holds one {variable: value} per index the cell covers (several when a variable is folded into counts)."""
    rows = [v for v in variables if view.get(v.name) == ROWS]
    cols = [v for v in variables if view.get(v.name) == COLUMNS]
    page_vars = [v for v in variables if view.get(v.name) == PAGES]
    span = lambda vs: math.prod(len(v.values) for v in vs)  # noqa: E731
    counted = None
    if span(cols) > max_columns and len(cols) > 1:
        counted, cols = cols[-1], cols[:-1]

    header_rows = []
    for depth, variable in enumerate(cols):
        inner, outer = span(cols[depth + 1:]), span(cols[:depth])
        header_rows.append([(variable.display(value), inner) for _ in range(outer) for value in variable.values])

    row_combos = list(itertools.product(*(v.values for v in rows))) or [()]
    col_combos = list(itertools.product(*(v.values for v in cols))) or [()]
    row_labels, cells = [], []
    for ri, row_values in enumerate(row_combos):
        labels = []
        for depth, variable in enumerate(rows):
            inner = span(rows[depth + 1:])
            labels.append(variable.display(row_values[depth]) if ri % inner == 0 else "")
        row_labels.append(labels or [""])
        line = []
        for col_values in col_combos:
            fixed = {v.name: x for v, x in zip(rows, row_values)}
            fixed.update({v.name: x for v, x in zip(cols, col_values)})
            fixed.update({v.name: pages.get(v.name, v.values[0]) for v in page_vars})
            options = [dict(fixed, **{counted.name: x}) for x in counted.values] if counted else [fixed]
            line.append(cell_for(options, fixed, counted))
        cells.append(line)
    return Board(header_rows, row_labels, cells, counted.display_name if counted else "",
                 [v.display_name for v in rows], [v.display_name for v in cols], [v.display_name for v in page_vars])


def build_board(variables: list[VariableLevels], view: dict[str, str], pages: dict[str, str],
                placements: dict[tuple, list[tuple[int, int, bool]]], max_columns: int = 16) -> Board:
    """Cropping: placements maps index key -> [(photo position, section, confirmed)] for every region placed
    or proposed."""
    def cell_for(options, fixed, counted):
        hits = [placements.get(index_key(o, variables), []) for o in options]
        confirmed = sum(1 for h in hits if len(h) == 1 and h[0][2])
        duplicate = any(len(h) > 1 for h in hits)
        proposed = any(any(not c for _, _, c in h) for h in hits)
        target = next(((h[0][0], h[0][1]) for h in hits if h), None)
        state = ("duplicate" if duplicate else "confirmed" if confirmed == len(options)
                 else "proposed" if proposed else "partial" if confirmed else "empty")
        name = " · ".join(v.display(fixed[v.name]) for v in variables if v is not counted)
        where = f"photo {target[0] + 1}, section {target[1] + 1}" if target else "not assigned"
        label = (f"{name}: {confirmed} of {len(options)} {counted.display_name.lower()} levels confirmed"
                 if counted else f"{name}: {where}")
        return BoardCell(f"{confirmed}/{len(options)}" if counted else "", state, label, target)
    return _layout_board(variables, view, pages, cell_for, max_columns)


def build_status_board(variables: list[VariableLevels], view: dict[str, str], pages: dict[str, str],
                       status: dict[tuple, tuple[str, int]], current: tuple | None = None,
                       max_columns: int = 16) -> Board:
    """Colony Detection: status maps index key -> (state 'waiting' / 'detected' / 'review', index id) for every
    index with a region; an index without one is 'none'. A click opens the cell's first index with a region
    (with folded counts: the first one waiting or to review)."""
    words = {"none": "no region", "waiting": "not detected yet", "detected": "detected", "review": "to review"}

    def cell_for(options, fixed, counted):
        keys = [index_key(o, variables) for o in options]
        found = [(k, status[k]) for k in keys if k in status]
        states = [state for _, (state, _) in found]
        detected = states.count("detected")
        state = ("none" if not found else "review" if "review" in states else
                 "detected" if detected == len(options) else "partial" if detected else "waiting")
        first = next((index for _, (s, index) in found if s in ("waiting", "review")), None)
        target = (first if first is not None else found[0][1][1],) if found else None
        name = " · ".join(v.display(fixed[v.name]) for v in variables if v is not counted)
        if counted:
            label = f"{name}: {detected} of {len(options)} {counted.display_name.lower()} levels detected"
        else:
            label = f"{name}: {words[states[0] if states else 'none']}"
        return BoardCell(f"{detected}/{len(options)}" if counted else "", state, label, target,
                         current=current in keys)
    return _layout_board(variables, view, pages, cell_for, max_columns)


def default_scope(variables: list[VariableLevels]) -> dict[str, str]:
    """First guess at where levels are set: nominal variables per section, the rest per photo."""
    return {v.name: SECTION if v.kind == "nominal" else PHOTO for v in variables}
