"""Entry point: python -m quantacolony, the quantacolony command, or the desktop shortcut.

Startup: find the project library (first start or a missing library opens
the library setup screen), then show the home page with every project in it.
On the first run the bundled sample project is created. Opening a project shows
its project page, which opens Cropping, Colony Detection and Stats; closing a
module returns to the project page.

    uv run quantacolony                         home page
    uv run quantacolony "D:\\Shared\\X.qcproj"     import a shared project, then show its project page
    uv run quantacolony --demo-cropping         synthetic demo with nothing cropped yet
    uv run quantacolony --demo-stats            synthetic demo cropped and detected (for Stats)
"""

from __future__ import annotations

import sys
import traceback
from pathlib import Path

from PySide6.QtWidgets import QApplication

from .data import PROJECT_SUFFIX, DataManager, Library, ProjectError, Settings
from .data.demo_project import DEMO_PROJECT_NAME, STATS_DEMO_NAME, complete_demo_project, create_demo_project
from .data.sample_project import create_sample_project
from .gui.launch import open_cropping as launch_cropping
from .gui.launch import open_detection
from .gui.library_setup import ensure_library
from .gui.navigator import Navigator
from .theme import apply_theme
from .theme.icons import app_icon
from .gui.dialogs import ERROR, notify

APP_ID = "QuantaColony.ColonyDetection"
DEMOS = {"--demo-cropping": (DEMO_PROJECT_NAME, create_demo_project),
         "--demo-stats": (STATS_DEMO_NAME, complete_demo_project)}


def open_startup_project(manager: DataManager, project_id: str | None = None,
                         import_path: Path | None = None) -> None:
    """Imported project, else the requested one, else the last used, else the most recent, else the sample."""
    if import_path is not None:
        project_id = manager.import_project_file(import_path)
    available = [entry.project_id for entry in manager.list_projects()]
    for candidate in (project_id, manager.settings.last_project_id, *available):
        if candidate and candidate in available:
            manager.open_project(candidate)
            return
    create_sample_project(manager)


def open_demo_project(manager: DataManager, flag: str = "--demo-cropping") -> None:
    """Open the demo named by the flag, creating it the first time."""
    name, create = DEMOS[flag]
    entry = next((e for e in manager.list_projects() if e.name == name), None)
    if entry is None:
        create(manager, name)
    else:
        manager.open_project(entry.project_id)


def open_cropping(manager: DataManager, theme):
    """Cropping; when it finishes, its window is replaced by Colony Detection (kept on controller.next)."""
    window, controller = launch_cropping(manager, theme)

    def to_detection() -> None:
        controller.next = open_detection(manager, theme)
        detection_window = controller.next[0]
        detection_window.fit_to_screen()
        detection_window.show()
        window.close()

    controller.finished.connect(to_detection)
    return window, controller


def build(app: QApplication, settings: Settings | None = None, library: Library | None = None,
          project_id: str | None = None, import_path: Path | None = None, demo_cropping: bool = False,
          module: str | None = None):
    """One module on a project, without the home and project pages (tests, scripts).
    The module is `module` ('cropping' / 'detection'), else the one the project needs.
    Returns (window, controller), or None when the user quits setup. Passing a library skips the setup screen."""
    theme = apply_theme(app)
    manager = DataManager(settings)
    if library is not None:
        manager.use_library(library)
    elif not ensure_library(manager, theme):
        return None
    if demo_cropping:
        open_demo_project(manager)
    else:
        open_startup_project(manager, project_id, import_path)
    if module is None:
        needs = manager.photos_needing_cropping() or manager.first_index_for_detection() is None
        module = "cropping" if needs else "detection"
    return open_cropping(manager, theme) if module == "cropping" else open_detection(manager, theme)


def start(app: QApplication, settings: Settings | None = None, library: Library | None = None,
          arguments: list[str] | None = None) -> Navigator | None:
    """Library, then the home page (or the project page of an imported project or a demo).
    Returns the navigator, or None when the user quits library setup."""
    arguments = arguments or []
    theme = apply_theme(app)
    manager = DataManager(settings)
    if library is not None:
        manager.use_library(library)
    elif not ensure_library(manager, theme):
        return None
    _back_up_program(manager)
    navigator = Navigator(app, theme, manager)
    app.aboutToQuit.connect(manager.close)                    # releases the lock, leaves a backup
    import_path = next((Path(arg) for arg in arguments if arg.lower().endswith(PROJECT_SUFFIX)), None)
    demo = next((arg for arg in arguments if arg in DEMOS), None)
    if import_path is not None:
        in_library = manager.library_project_id(import_path)       # double-clicked inside the library: open it
        navigator.open_project(in_library or manager.import_project_file(import_path))
    elif demo is not None:
        open_demo_project(manager, demo)
        navigator.show_project()
    else:
        if not manager.list_projects():
            create_sample_project(manager)
            manager.close()
        navigator.show_home()
    return navigator


def _back_up_program(manager: DataManager) -> None:
    """Keep the library's backup of the program equal to the program that is running (after an update)."""
    from .data.program import back_up_program, program_root
    try:
        back_up_program(program_root(), manager.library.root)
    except OSError:
        pass                                          # a backup that cannot be written never stops QuantaColony


def _set_windows_app_id() -> None:
    """Group the window under its own taskbar icon on Windows (otherwise Python's icon shows)."""
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)


def main() -> int:
    _set_windows_app_id()
    app = QApplication(sys.argv)
    app.setApplicationName("QuantaColony")
    app.setWindowIcon(app_icon())
    try:
        navigator = start(app, arguments=sys.argv[1:])
    except ProjectError as error:
        notify(None, ERROR, "QuantaColony could not start", str(error))
        return 1
    except Exception:                               # started from the shortcut: no console to show it
        notify(None, ERROR, "QuantaColony could not start", traceback.format_exc())
        return 1
    if navigator is None:                           # quit at library setup
        return 0
    print("QuantaColony is open. Close the window to return here.")
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
