"""Variables, levels and indices: the experimental design of a project."""

from __future__ import annotations

import math

from ...core.record import LevelLabel
from ..exports import safe_name
from ..packets import LevelInfo, VariableInfo, VariableSpec
from .project_file import ProjectFile


class Structure:
    def __init__(self, file: ProjectFile):
        self.file = file

    @property
    def db(self):
        return self.file.connection

    # ----- reading ----------------------------------------------------------
    def variables(self) -> tuple[VariableInfo, ...]:
        """Every variable with its levels, in variable order (two queries in all)."""
        levels: dict[int, list[LevelInfo]] = {}
        for row in self.db.execute("SELECT * FROM levels ORDER BY variable_id, sort_order"):
            levels.setdefault(row["variable_id"], []).append(
                LevelInfo(row["level_id"], row["value"], row["display_value"], row["sort_order"],
                          bool(row["is_control"])))
        return tuple(VariableInfo(row["variable_id"], row["name"], row["display_name"], row["type"],
                                  tuple(levels.get(row["variable_id"], ())))
                     for row in self.db.execute("SELECT * FROM variables ORDER BY position"))

    def all_labels(self) -> dict[int, tuple[LevelLabel, ...]]:
        """index id -> its level labels in variable order (one query for every index)."""
        labels: dict[int, list[LevelLabel]] = {}
        for r in self.db.execute(
                "SELECT il.index_id, v.display_name, v.type, l.value, l.display_value FROM index_levels il "
                "JOIN variables v USING (variable_id) JOIN levels l USING (level_id) "
                "ORDER BY il.index_id, v.position"):
            labels.setdefault(r["index_id"], []).append(
                LevelLabel(r["display_name"], r["type"], r["value"], r["display_value"]))
        return {index_id: tuple(values) for index_id, values in labels.items()}

    def labels(self, index_id: int) -> tuple[LevelLabel, ...]:
        rows = self.db.execute(
            "SELECT v.display_name, v.type, l.value, l.display_value FROM index_levels il "
            "JOIN variables v USING (variable_id) JOIN levels l USING (level_id) "
            "WHERE il.index_id = ? ORDER BY v.position", (index_id,))
        return tuple(LevelLabel(r["display_name"], r["type"], r["value"], r["display_value"]) for r in rows)

    def level_values(self, index_id: int) -> dict[str, str]:
        """{variable name: level value} for an index."""
        return {r["name"]: r["value"] for r in self.db.execute(
            "SELECT v.name, l.value FROM index_levels il JOIN variables v USING (variable_id) "
            "JOIN levels l USING (level_id) WHERE il.index_id = ?", (index_id,))}

    def all_level_values(self) -> dict[int, dict[str, str]]:
        values: dict[int, dict[str, str]] = {}
        for r in self.db.execute("SELECT il.index_id, v.name, l.value FROM index_levels il "
                                 "JOIN variables v USING (variable_id) JOIN levels l USING (level_id)"):
            values.setdefault(r["index_id"], {})[r["name"]] = r["value"]
        return values

    @staticmethod
    def name_from_labels(labels: tuple[LevelLabel, ...]) -> str:
        """File-safe name from level values, e.g. 'rif1_cdc132_Figure_2_v_25'."""
        return safe_name("_".join(label.value for label in labels))

    def index_name(self, index_id: int) -> str:
        return self.name_from_labels(self.labels(index_id))

    def variable_ids(self) -> dict[str, int]:
        return {row["name"]: row["variable_id"] for row in self.db.execute("SELECT name, variable_id FROM variables")}

    def level_ids(self) -> dict[str, dict[str, int]]:
        """{variable name: {level value: level id}}."""
        result: dict[str, dict[str, int]] = {}
        for r in self.db.execute("SELECT v.name, l.value, l.level_id FROM levels l JOIN variables v USING (variable_id)"):
            result.setdefault(r["name"], {})[r["value"]] = r["level_id"]
        return result

    def find_index(self, level_ids: dict[int, int]) -> int | None:
        """The index with exactly these {variable id: level id}, or None."""
        stored: dict[int, dict[int, int]] = {}
        for r in self.db.execute("SELECT index_id, variable_id, level_id FROM index_levels"):
            stored.setdefault(r["index_id"], {})[r["variable_id"]] = r["level_id"]
        return next((index_id for index_id, levels in stored.items() if levels == level_ids), None)

    def combination_count(self) -> int:
        """Every combination of levels: the number of indices the design calls for."""
        counts = [r[0] for r in self.db.execute("SELECT COUNT(*) FROM levels GROUP BY variable_id")]
        return math.prod(counts) if counts else 0

    # ----- writing (inside a transaction) -------------------------------------
    def insert_variables(self, variables: list[VariableSpec]) -> None:
        self.file.require_transaction()
        for position, spec in enumerate(variables):
            cursor = self.db.execute(
                "INSERT INTO variables (name, display_name, type, position) VALUES (?, ?, ?, ?)",
                (spec.name, spec.display_name or spec.name, spec.type, position))
            self.db.executemany(
                "INSERT INTO levels (variable_id, value, display_value, sort_order, is_control) "
                "VALUES (?, ?, ?, ?, ?)",
                [(cursor.lastrowid, level.value, level.display or level.value, order, int(level.is_control))
                 for order, level in enumerate(spec.levels)])

    def insert_index(self, level_ids: dict[int, int]) -> int:
        self.file.require_transaction()
        index_id = self.db.execute("INSERT INTO indices DEFAULT VALUES").lastrowid
        self.db.executemany("INSERT INTO index_levels (index_id, variable_id, level_id) VALUES (?, ?, ?)",
                            [(index_id, variable_id, level_id) for variable_id, level_id in level_ids.items()])
        return index_id
