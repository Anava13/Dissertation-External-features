"""Projects as files in the library: summaries for the project list, copies in and out, backups.

These work on project files that are not open (read-only connections), except
where the DataManager passes the open file so a copy includes unsaved state.
"""

from __future__ import annotations

import json
import math
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from ..library import Library
from ..schema import SCHEMA_VERSION
from .project_file import FileProblem, copy_database, read_only

PROJECT_SUFFIX = ".qcproj"
BACKUPS_KEPT = 5
_STAMP = "%Y%m%dT%H%M%S%fZ"


@dataclass(frozen=True)
class ProjectEntry:
    """One project in the library, as the project list shows it."""

    project_id: str
    name: str
    modified: datetime
    size_bytes: int
    index_count: int                  # every combination of levels the design calls for
    detected_count: int               # indices with committed colonies (and a region)
    review_count: int = 0             # detected indices flagged for review
    cropped_count: int = 0            # indices with a photo region
    photo_count: int = 0
    colony_count: int = 0             # colonies counted over every detected index
    variable_count: int = 0
    created: datetime | None = None


@dataclass(frozen=True)
class BackupEntry:
    path: Path
    taken_at: datetime
    size_bytes: int


def _value(connection, key: str):
    row = connection.execute("SELECT value FROM project WHERE key = ?", (key,)).fetchone()
    return json.loads(row["value"]) if row else None


def summarize(project_id: str, path: Path) -> ProjectEntry | None:
    """A project's line in the project list, or None when the file is not readable as a project."""
    try:
        connection = read_only(path)
        try:
            name = _value(connection, "name")
            created = _value(connection, "created_at")
            per_variable = [r[0] for r in connection.execute("SELECT COUNT(*) FROM levels GROUP BY variable_id")]
            combinations = math.prod(per_variable) if per_variable else 0
            cropped = connection.execute("SELECT COUNT(*) FROM assignments").fetchone()[0]
            detected, review = connection.execute(
                "SELECT COUNT(*), COALESCE(SUM(d.needs_review), 0) FROM detection d "
                "JOIN assignments a USING (index_id)").fetchone()
            colonies = connection.execute("SELECT COUNT(*) FROM colonies c JOIN assignments a USING (index_id) "
                                          "WHERE c.in_final = 1").fetchone()[0]
            photos = connection.execute("SELECT COUNT(*) FROM photos").fetchone()[0]
        finally:
            connection.close()
    except (sqlite3.DatabaseError, TypeError):
        return None
    if name is None:
        return None
    stat = path.stat()
    try:
        created_at = datetime.fromisoformat(created) if created else None
    except ValueError:
        created_at = None
    return ProjectEntry(project_id, name, datetime.fromtimestamp(stat.st_mtime, timezone.utc), stat.st_size,
                        combinations, detected, int(review), cropped, photos, colonies, len(per_variable), created_at)


def list_projects(library: Library) -> list[ProjectEntry]:
    """Every project in the library, most recently changed first."""
    entries = [summarize(project_id, library.project_path(project_id)) for project_id in library.project_ids()]
    return sorted((e for e in entries if e is not None), key=lambda e: e.modified, reverse=True)


def thumbnail(path: Path) -> bytes | None:
    """The first photo's thumbnail (PNG bytes), or None (no photos, or a file from before thumbnails)."""
    try:
        connection = read_only(path)
        try:
            row = connection.execute("SELECT thumbnail FROM photos ORDER BY photo_id LIMIT 1").fetchone()
        finally:
            connection.close()
    except sqlite3.DatabaseError:
        return None
    return bytes(row[0]) if row and row[0] is not None else None


# ----- sharing -----------------------------------------------------------------
def export_copy(library: Library, project_id: str, destination: Path, open_connection=None) -> Path:
    """A consistent copy of a project for sending to someone, outside the library."""
    destination = Path(destination)
    if destination.suffix != PROJECT_SUFFIX:
        destination = destination.with_suffix(PROJECT_SUFFIX)
    if library.root.resolve() in destination.resolve().parents:
        raise FileProblem("Export to a folder outside the library")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if open_connection is not None:
        copy_database(open_connection, destination)
    else:
        source = read_only(library.project_path(project_id))
        try:
            copy_database(source, destination)
        finally:
            source.close()
    return destination


def import_copy(library: Library, source: Path) -> str:
    """Copy a shared .qcproj into the library; returns its project id. A project already in the
    library is imported as a copy with a new id and name."""
    source = Path(source)
    try:
        original = read_only(source)
    except sqlite3.DatabaseError as error:
        raise FileProblem(f"{source.name} cannot be opened ({error})") from error
    try:
        try:
            ok = original.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            values = {r["key"]: json.loads(r["value"]) for r in original.execute("SELECT key, value FROM project")}
        except sqlite3.DatabaseError as error:
            raise FileProblem(f"{source.name} is not a QuantaColony project ({error})") from error
        if not ok:
            raise FileProblem(f"{source.name} is damaged and was not imported")
        if values.get("schema_version", SCHEMA_VERSION + 1) > SCHEMA_VERSION:
            raise FileProblem(f"{source.name} needs a newer QuantaColony")
        project_id = values.get("project_id") or uuid.uuid4().hex
        name = values.get("name", source.stem)
        if project_id in library.project_ids():
            project_id = uuid.uuid4().hex
        names = {entry.name for entry in list_projects(library)}
        base, copy = name, 1
        while name in names:
            name = f"{base} (copy {copy})" if copy > 1 else f"{base} (copy)"
            copy += 1
        target = library.project_path(project_id)
        library.projects_folder.mkdir(parents=True, exist_ok=True)
        copy_database(original, target)
    finally:
        original.close()
    imported = sqlite3.connect(str(target), isolation_level=None)
    try:
        imported.execute("BEGIN IMMEDIATE")
        imported.executemany("INSERT OR REPLACE INTO project (key, value) VALUES (?, ?)",
                             [("project_id", json.dumps(project_id)), ("name", json.dumps(name))])
        imported.execute("COMMIT")
    finally:
        imported.close()
    return project_id


def library_project_id(library: Library, path: Path) -> str | None:
    """The project id when path is a project file inside this library, else None."""
    try:
        path = Path(path).resolve()
    except OSError:
        return None
    if path.parent == library.projects_folder.resolve() and path.suffix == PROJECT_SUFFIX \
            and path.stem in library.project_ids():
        return path.stem
    return None


# ----- backups -----------------------------------------------------------------
def snapshot(library: Library, connection: sqlite3.Connection, project_id: str) -> Path:
    folder = library.backups_folder / project_id
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{datetime.now(timezone.utc).strftime(_STAMP)}{PROJECT_SUFFIX}"
    copy_database(connection, target)
    for old in sorted(folder.glob(f"*{PROJECT_SUFFIX}"))[:-BACKUPS_KEPT]:
        old.unlink(missing_ok=True)
    return target


def snapshot_file(library: Library, project_id: str) -> Path:
    current = read_only(library.project_path(project_id))
    try:
        return snapshot(library, current, project_id)
    finally:
        current.close()


def list_backups(library: Library, project_id: str) -> list[BackupEntry]:
    """Snapshots of a project, newest first."""
    folder = library.backups_folder / project_id
    entries = []
    for path in sorted(folder.glob(f"*{PROJECT_SUFFIX}"), reverse=True):
        taken = datetime.strptime(path.stem, _STAMP).replace(tzinfo=timezone.utc)
        entries.append(BackupEntry(path, taken, path.stat().st_size))
    return entries


def restore_file(library: Library, project_id: str, backup: Path) -> None:
    """Overwrite a (closed, locked) project file with a snapshot."""
    source = read_only(backup)
    try:
        copy_database(source, library.project_path(project_id))
    finally:
        source.close()
