"""The bundled sample: one cropped plate image from the Anbalagan 2011 project.

create_sample_project builds a .qcproj from it the same way project creation
and cropping will: variables, one index, one photo, one region covering the
whole photo. It stands in for those modules until they exist.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

from ..core.params import DetectionParams
from .manager import DataManager
from .packets import Assignment, LevelSpec, ProjectInfo, VariableSpec

SAMPLE_FOLDER = Path(__file__).parent / "sample"
SAMPLE_NAME = "rif1_cdc132_Figure_2_v25"


def sample_metadata() -> dict:
    return json.loads((SAMPLE_FOLDER / f"{SAMPLE_NAME}.json").read_text(encoding="utf-8"))


def sample_image() -> tuple[np.ndarray, float, DetectionParams]:
    """(image, px_per_mm, saved parameters): the sample without a project, for tests and scripts."""
    meta = sample_metadata()
    image = np.array(Image.open(SAMPLE_FOLDER / meta["image_file"]).convert("RGB"))
    return image, float(meta["px_per_mm"]), DetectionParams(**meta["saved_params"])


SAMPLE_PROJECT_NAME = "Sample (Anbalagan 2011)"


def create_sample_project(manager: DataManager) -> ProjectInfo:
    """Build the sample project in the manager's library and leave it open."""
    meta = sample_metadata()
    manager.create_project(
        SAMPLE_PROJECT_NAME,
        [VariableSpec("condition", "nominal", (LevelSpec(meta["nominal"], meta["nominal_display"]),), "Condition"),
         VariableSpec("ordinal", "ordinal", (LevelSpec(meta["ordinal"], meta["ordinal_display"]),), "Ordinal")],
        DetectionParams(**meta["saved_params"]))
    photo_path = SAMPLE_FOLDER / meta["image_file"]
    photo_id = manager.add_photo(photo_path, meta["px_per_mm"], scaling_method="sample")
    rows, cols = Image.open(photo_path).size[::-1]
    index_id = manager.add_index({"condition": meta["nominal"], "ordinal": meta["ordinal"]})
    # The sample photo is already cropped: its region is the whole photo
    manager.commit_assignments([Assignment(index_id, photo_id, "rectangle",
                                           {"x": -0.5, "y": -0.5, "width": cols, "height": rows})])
    return manager.project_info()
