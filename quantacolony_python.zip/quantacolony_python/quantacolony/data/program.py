"""The program's own files: copying them to where QuantaColony runs from, and backing them up in
the project library.

    %LOCALAPPDATA%\\QuantaColony\\Program   where the installed program runs from (with its .venv)
    <library>\\Program                      a backup of the program, without its .venv, with the
                                            installer, so a new computer installs from the library

The running copy stays outside the library on purpose: Move library deletes the old library
folder, which Windows refuses while the program in it is running, and a Python environment
(.venv) stops working when it is moved.
"""

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

PROGRAM_FOLDER = "Program"
FINGERPRINT_FILE = ".program-fingerprint"
INSTALLER_NAME = "Install QuantaColony.bat"
# Never part of the program: the environment uv builds, caches, version control, results
SKIPPED = {".venv", ".git", "__pycache__", ".pytest_cache", ".ruff_cache", "output", FINGERPRINT_FILE}


def program_root() -> Path:
    """The folder that holds pyproject.toml and the quantacolony package of the running program."""
    return Path(__file__).resolve().parents[2]


def is_program_folder(folder: Path) -> bool:
    folder = Path(folder)
    return (folder / "pyproject.toml").is_file() and (folder / "quantacolony" / "__init__.py").is_file()


def program_files(source: Path) -> list[Path]:
    """Every file of the program, relative to source, in a fixed order."""
    source = Path(source)
    files = []
    for path in sorted(source.rglob("*")):
        relative = path.relative_to(source)
        if any(part in SKIPPED for part in relative.parts) or path.suffix in (".pyc", ".tmp") or not path.is_file():
            continue
        files.append(relative)
    return files


def fingerprint(source: Path) -> str:
    """Identifies the program's exact content: every file's path and bytes."""
    digest = hashlib.sha256()
    for relative in program_files(source):
        digest.update(relative.as_posix().encode())
        digest.update(hashlib.sha256((Path(source) / relative).read_bytes()).digest())
    return digest.hexdigest()


def copy_program(source: Path, destination: Path, keep: tuple[str, ...] = (".venv",)) -> Path:
    """Make destination hold exactly the program in source. Folders named in keep (the environment
    uv builds) are left in place; any other file that is no longer part of the program is removed."""
    source, destination = Path(source).resolve(), Path(destination)
    if destination.exists() and destination.resolve() == source:
        return destination                                  # installing from the installed copy itself
    wanted = program_files(source)
    destination.mkdir(parents=True, exist_ok=True)
    for relative in wanted:
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / relative, target)
    present = set(wanted)
    for path in sorted(destination.rglob("*"), reverse=True):     # deepest first, so folders empty out
        relative = path.relative_to(destination)
        if relative.parts[0] in keep:
            continue
        if path.is_file() and relative not in present:
            path.unlink()
        elif path.is_dir() and not any(path.iterdir()):
            path.rmdir()
    (destination / FINGERPRINT_FILE).write_text(fingerprint(source), encoding="ascii")
    return destination


def stored_fingerprint(folder: Path) -> str:
    try:
        return (Path(folder) / FINGERPRINT_FILE).read_text(encoding="ascii").strip()
    except OSError:
        return ""


def back_up_program(source: Path, library_root: Path) -> bool:
    """Keep <library>/Program equal to the program in source. Returns True when it copied anything."""
    backup = Path(library_root) / PROGRAM_FOLDER
    if not is_program_folder(source):
        return False
    if stored_fingerprint(backup) == fingerprint(source):
        return False
    copy_program(source, backup, keep=())
    return True
