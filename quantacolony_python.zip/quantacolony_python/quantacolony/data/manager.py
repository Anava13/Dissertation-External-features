"""DataManager: the only part of QuantaColony that reads or writes project files.

The DataManager holds the source of truth, builds packets for modules on
request, stores what modules send back, and writes exports. Modules ask it
for data and send results to it; they never open project files.

It is the front door to private helpers (data.store), one per area of the
project file. It creates them, hands each the one open file, and runs every
action that touches more than one area inside a single transaction. Helpers
never call each other; see data/store/__init__.py.

Projects live in the library (see library.py), one SQLite file each, named
by project id. Users reach them through QuantaColony: open by id, export a
copy to share, import a shared copy, restore a backup. Nobody picks or moves
project files by hand. A session that changed a project leaves a backup
snapshot when the project closes.
"""

from __future__ import annotations

import hashlib
import io
import json
import sqlite3
import uuid
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

import numpy as np
from PIL import Image

from .. import __version__
from ..core.colony_set import ColonySet
from ..core.params import DetectionParams
from ..core.record import DetectionResult, ImageRecord, SavedDetection
from .codec import blob_to_array
from .derived import DERIVATIONS, DerivationInputs, fingerprint
from .exports import (check_writable, safe_name, write_browsable_summary, write_figure, write_growth_png, write_json,
                      write_overlay_png, write_png, write_table_csv, write_text)
from .library import Library, LibraryError, ProjectLock, find_library, move_library
from .packets import (Assignment, CropPacket, DerivedTable, ImagePacket, IndexInfo, ProjectInfo, ProjectStatus,
                      VariableSpec)
from .regions import REGION_KINDS, crop_box, cut_region, outline_from_geometry
from .schema import SCHEMA_VERSION
from .settings import Settings
from .store import catalog
from .store.catalog import BACKUPS_KEPT, PROJECT_SUFFIX, BackupEntry, ProjectEntry
from .store.derived_cache import DerivedCache
from .store.detections import REGION_CHANGED, REGION_REMOVED, Detections
from .store.photos import Photos
from .store.project_file import FileProblem, ProjectFile, now
from .store.structure import Structure

__all__ = ["DataManager", "ProjectError", "ProjectEntry", "BackupEntry", "PROJECT_SUFFIX", "BACKUPS_KEPT"]

KIND_NAMES = {"nominal": "Nominal", "ordinal": "Ordinal", "replicate": "Replicate"}
INDEX_MEASURES = {"colony_count": "Colonies counted", "mean_radius_um": "Mean colony radius (µm)",
                  "growth_coverage": "Growth coverage (fraction of growable area)",
                  "colony_coverage": "Colony coverage (fraction of growable area)",
                  "capture_ratio": "Capture ratio (colony area / growth area)"}


class ProjectError(Exception):
    """A request the project cannot satisfy; the message is meant for the user."""


class DataManager:
    def __init__(self, settings: Settings | None = None, library: Library | None = None):
        self.settings = settings if settings is not None else Settings.load()
        self.library: Library | None = library
        self._file: ProjectFile | None = None
        self._project_id: str | None = None
        self._lock: ProjectLock | None = None
        # helpers on the open file (created in _attach)
        self._structure: Structure | None = None
        self._photos: Photos | None = None
        self._detections: Detections | None = None
        self._cache: DerivedCache | None = None

    # =====================================================================
    # library
    # =====================================================================
    def resolve_library(self) -> Library | None:
        """The library from settings, following it to another drive letter; None if not found."""
        if self.library is None:
            self.library = find_library(self.settings.library_path, self.settings.library_id)
            if self.library is not None and str(self.library.root) != self.settings.library_path:
                self.settings.set_library(self.library.root, self.library.library_id)
        return self.library

    def use_library(self, library: Library) -> None:
        """Make library the one QuantaColony uses from now on (first start, located, created or moved)."""
        self.close()
        self.library = library
        self.settings.set_library(library.root, library.library_id)

    def move_library(self, destination: Path) -> Library:
        """Move the whole library (closes the open project first) and point settings at the new place."""
        library = self._require_library()
        reopen = self._project_id
        self.close()
        try:
            moved = move_library(library, destination)
        except LibraryError as error:
            raise ProjectError(str(error)) from error
        self.use_library(moved)
        if reopen:
            self.open_project(reopen)
        return moved

    def _require_library(self) -> Library:
        if self.library is None:
            raise ProjectError("No project library is set up")
        return self.library

    def list_projects(self) -> list[ProjectEntry]:
        """Every project in the library with its progress, most recently changed first."""
        return catalog.list_projects(self._require_library())

    def project_thumbnail(self, project_id: str) -> bytes | None:
        """PNG bytes of a small picture of the project's first photo, or None."""
        return catalog.thumbnail(self._require_library().project_path(project_id))

    def library_project_id(self, path: Path) -> str | None:
        """The project id when path is a project file inside the library (open it, do not import it)."""
        return catalog.library_project_id(self._require_library(), path)

    # =====================================================================
    # the open project
    # =====================================================================
    @property
    def library_root(self) -> Path:
        return self._require_library().root

    @property
    def is_open(self) -> bool:
        return self._file is not None

    @property
    def project_id(self) -> str:
        self._require_open()
        return self._project_id

    @property
    def project_path(self) -> Path:
        self._require_open()
        return self._file.path

    @property
    def _connection(self):
        """The open SQLite connection (tests only; modules never use it)."""
        return self._file.connection if self._file else None

    @property
    def exports_folder(self) -> Path:
        """Documents/QuantaColony Exports/<project name>: where exports go unless a path is given."""
        return Path.home() / "Documents" / "QuantaColony Exports" / safe_name(self._file.setting("name") or "project")

    def create_project(self, name: str, variables: list[VariableSpec], detection_defaults: DetectionParams,
                       plate: dict | None = None, extra: dict | None = None,
                       estimate_settings: bool = False) -> ProjectInfo:
        """New project in the library, then opened. Built under a temporary name, then renamed.

        extra: more project settings stored by key (e.g. variable units from the New Project wizard).
        estimate_settings: Colony Detection estimates its settings from the first image instead of
        starting from detection_defaults."""
        library = self._require_library()
        if not name.strip():
            raise ProjectError("A project needs a name")
        if any(entry.name == name for entry in self.list_projects()):
            raise ProjectError(f"A project named {name} already exists")
        if not variables:
            raise ProjectError("A project needs at least one variable")
        project_id = uuid.uuid4().hex
        path = library.project_path(project_id)
        library.projects_folder.mkdir(parents=True, exist_ok=True)
        building = path.with_name(path.name + ".creating")
        settings = {"project_id": project_id, "name": name, "schema_version": SCHEMA_VERSION,
                    "created_at": now(), "software_version": __version__,
                    "detection_defaults": asdict(detection_defaults), "plate": plate or {},
                    "estimate_detection_settings": bool(estimate_settings)}
        settings.update({key: value for key, value in (extra or {}).items() if key not in settings})
        try:
            ProjectFile.create(building, settings)
            file = ProjectFile.open(building)
            try:
                with file.transaction():
                    Structure(file).insert_variables(variables)
            finally:
                file.close()
        except Exception:
            building.unlink(missing_ok=True)
            raise
        building.replace(path)
        info = self.open_project(project_id)
        self._file.changed = True                     # a new project gets a first backup on close
        return info

    def open_project(self, project_id: str) -> ProjectInfo:
        library = self._require_library()
        path = library.project_path(project_id)
        if not path.is_file():
            raise ProjectError("This project is not in the library")
        self.close()
        lock = ProjectLock(library.lock_path(project_id))
        try:
            lock.acquire()
        except LibraryError as error:
            raise ProjectError(str(error)) from error
        try:
            file = ProjectFile.open(path)
        except FileProblem as error:
            lock.release()
            raise ProjectError(str(error)) from error
        except Exception:
            lock.release()
            raise
        self._attach(file, project_id, lock)
        if file.upgraded_from is not None and file.upgraded_from < 3:
            with file.transaction():                   # photos stored before sizes were kept
                self._photos.fill_missing_sizes()
        self.settings.remember_project(project_id)
        return self.project_info()

    def _attach(self, file: ProjectFile, project_id: str, lock: ProjectLock) -> None:
        self._file, self._project_id, self._lock = file, project_id, lock
        self._structure = Structure(file)
        self._photos = Photos(file)
        self._detections = Detections(file)
        self._cache = DerivedCache(file)

    def close(self) -> None:
        """Close the open project; a session that changed it leaves a backup snapshot."""
        if self._file is not None:
            if self._file.changed:
                try:
                    catalog.snapshot(self._require_library(), self._file.connection, self._project_id)
                except (OSError, sqlite3.DatabaseError, ProjectError):
                    pass                                   # a failed backup never blocks closing
            self._file.close()
        if self._lock is not None:
            self._lock.release()
        self._file, self._project_id, self._lock = None, None, None
        self._structure = self._photos = self._detections = self._cache = None

    def _require_open(self) -> None:
        if self._file is None:
            raise ProjectError("No project is open")

    # ----- sharing ----------------------------------------------------------
    def export_project_file(self, project_id: str, destination: Path) -> Path:
        """A consistent copy of a project for sending to someone; QuantaColony never works on it in place."""
        library = self._require_library()
        check_writable(Path(destination).parent)
        open_connection = self._file.connection if project_id == self._project_id and self._file else None
        try:
            return catalog.export_copy(library, project_id, destination, open_connection)
        except FileProblem as error:
            raise ProjectError(str(error)) from error

    def import_project_file(self, source: Path) -> str:
        """Copy a shared .qcproj into the library; returns its project id. A project already in the
        library is imported as a copy with a new id."""
        try:
            return catalog.import_copy(self._require_library(), source)
        except FileProblem as error:
            raise ProjectError(str(error)) from error

    # ----- backups ----------------------------------------------------------
    def list_backups(self, project_id: str) -> list[BackupEntry]:
        """Snapshots of a project, newest first."""
        return catalog.list_backups(self._require_library(), project_id)

    def restore_backup(self, project_id: str, backup: Path) -> None:
        """Replace a project with one of its snapshots. The current state is snapshotted first,
        so a restore can itself be undone."""
        library = self._require_library()
        backup = Path(backup)
        if backup.parent != library.backups_folder / project_id:
            raise ProjectError("That backup belongs to another project")
        reopen = self._project_id == project_id
        already_saved = reopen and self._file.changed          # closing below snapshots the current state
        if reopen:
            self.close()
        lock = ProjectLock(library.lock_path(project_id))
        try:
            lock.acquire()
        except LibraryError as error:
            raise ProjectError(str(error)) from error
        try:
            if not already_saved:
                catalog.snapshot_file(library, project_id)
            catalog.restore_file(library, project_id, backup)
        finally:
            lock.release()
        if reopen:
            self.open_project(project_id)

    # =====================================================================
    # project contents
    # =====================================================================
    def project_info(self) -> ProjectInfo:
        self._require_open()
        labels = self._structure.all_labels()
        assigned = set(self._photos.assigned_ids())
        states = self._detections.states()
        indices = []
        for row in self._file.connection.execute("SELECT index_id FROM indices ORDER BY index_id").fetchall():
            index_id = row["index_id"]
            revision, review = states.get(index_id, (0, False))
            indices.append(IndexInfo(index_id, labels.get(index_id, ()), index_id in assigned, revision, review))
        return ProjectInfo(self._project_id, self._file.setting("name"), self._file.setting("schema_version"),
                           self._structure.variables(), tuple(indices), self.detection_defaults())

    def detection_defaults(self) -> DetectionParams:
        return DetectionParams(**self._file.setting("detection_defaults"))

    def index_name(self, index_id: int) -> str:
        """File-safe name from the index's level values, e.g. 'rif1_cdc132_Figure_2_v_25'."""
        return self._structure.index_name(index_id)

    def add_index(self, levels: dict[str, str]) -> int:
        """New multivariable index from {variable name: level value}; every variable needs a level."""
        self._require_open()
        variables = self._structure.variable_ids()
        if set(levels) != set(variables):
            raise ProjectError(f"An index needs one level for each variable: {', '.join(sorted(variables))}")
        known = self._structure.level_ids()
        level_ids = {}
        for name, value in levels.items():
            if value not in known.get(name, {}):
                raise ProjectError(f"Variable '{name}' has no level '{value}'")
            level_ids[variables[name]] = known[name][value]
        if self._structure.find_index(level_ids) is not None:
            raise ProjectError(f"An index for {levels} already exists")
        with self._file.transaction():
            return self._structure.insert_index(level_ids)

    # ----- photos and regions (project creation and cropping) ------------
    def add_photo(self, source: Path | bytes, px_per_mm: float, file_name: str = "",
                  scaling_method: str = "") -> int:
        """Store a plate photo exactly as uploaded. source is a file path or the file's bytes."""
        self._require_open()
        content = Path(source).read_bytes() if isinstance(source, (str, Path)) else bytes(source)
        file_name = file_name or (Path(source).name if isinstance(source, (str, Path)) else "photo")
        if px_per_mm <= 0:
            raise ProjectError("The scale (pixels per mm) must be positive")
        try:
            Image.open(io.BytesIO(content)).verify()
        except Exception as error:
            raise ProjectError(f"{file_name} is not a readable image ({error})") from error
        with self._file.transaction():
            return self._photos.insert(content, file_name, px_per_mm, scaling_method)

    def commit_assignments(self, assignments: list[Assignment]) -> list[int]:
        """Store regions for indices directly. Returns indices flagged for review because a region
        changed after their colonies were committed."""
        self._require_open()
        prepared = []
        for assignment in assignments:
            if assignment.region_kind not in REGION_KINDS:
                raise ProjectError(f"Unknown region kind: {assignment.region_kind}")
            try:
                outline = outline_from_geometry(assignment.region_kind, assignment.geometry)
                crop_box(outline, self._photos.shape(assignment.photo_id))
            except (KeyError, ValueError) as error:
                raise ProjectError(f"Index {assignment.index_id}: invalid region ({error})") from error
            prepared.append((assignment, outline))
        flagged = []
        with self._file.transaction():
            for assignment, outline in prepared:
                changed = self._photos.save_assignment(assignment.index_id, assignment.photo_id,
                                                       assignment.region_kind, assignment.geometry, outline)
                if changed and self._detections.flag_review(assignment.index_id, REGION_CHANGED):
                    flagged.append(assignment.index_id)
        return flagged

    def _region(self, index_id: int):
        """(assignment row, photo row) for an index, or a ProjectError naming the missing step."""
        assignment = self._photos.assignment(index_id)
        if assignment is None:
            raise ProjectError("This index has no photo region yet. Assign one in Cropping first.")
        return assignment, self._photos.row(assignment["photo_id"])

    # =====================================================================
    # Colony Detection
    # =====================================================================
    def first_index_for_detection(self) -> int | None:
        """The first index waiting for detection or review, else the first index with a region."""
        indices = [i for i in self.project_info().indices if i.has_region]
        waiting = [i for i in indices if i.revision == 0 or i.needs_review]
        chosen = waiting or indices
        return chosen[0].index_id if chosen else None

    def detection_start(self) -> tuple[DetectionParams, bool]:
        """Settings a new index starts from, and whether to estimate them from its image instead.

        A new index starts from the settings of the last image finished in this project. Before
        any image is finished it starts from the project defaults, or from an estimate when the
        project asks for one."""
        last = self._file.setting("last_detection_params")
        if last:
            return DetectionParams(**last), False
        return self.detection_defaults(), bool(self._file.setting("estimate_detection_settings"))

    def checkout_image(self, index_id: int) -> ImagePacket:
        """The cropped image, its mask and scale, the saved result (crop coordinates), and the
        settings a new index starts from."""
        self._require_open()
        assignment, photo = self._region(index_id)
        crop = cut_region(self._photos.array(photo["photo_id"]), blob_to_array(assignment["outline"]))
        labels = self._structure.labels(index_id)
        record = ImageRecord(index_id, self._structure.name_from_labels(labels), labels, crop.image, crop.mask,
                             float(photo["px_per_mm"]))
        saved = self._detections.load(index_id)
        if saved is not None:
            dx, dy = crop.offset
            saved = SavedDetection(saved.params, saved.colonies.translated(-dx, -dy),
                                   saved.baseline.translated(-dx, -dy), saved.revision, saved.detection_version,
                                   saved.needs_review, saved.review_reason)
        start, estimate = self.detection_start()
        return ImagePacket(record, saved, start, estimate)

    def commit_detection(self, result: DetectionResult) -> int:
        """Store a finished result as the new truth for its index and remember its settings as the
        starting point for the next new index. Returns the new revision."""
        self._require_open()
        assignment, photo = self._region(result.index_id)
        x0, y0, _, _ = crop_box(blob_to_array(assignment["outline"]), self._photos.shape(photo["photo_id"]))
        final, baseline = result.colonies.translated(x0, y0), result.baseline.translated(x0, y0)
        for name, colonies in (("final", final), ("baseline", baseline)):
            if len(set(colonies.ids.tolist())) != len(colonies) or (len(colonies) and colonies.ids.min() < 1):
                raise ProjectError(f"The {name} colonies need unique positive ids")
        with self._file.transaction():
            revision = self._detections.write(result.index_id, result.params, final, baseline, result.edits,
                                              result.detection_version)
            self._cache.clear(result.index_id)
            self._file.set_setting("last_detection_params", asdict(result.params))
        return revision

    def edit_log(self, index_id: int) -> list[dict]:
        """Every committed edit for an index, oldest first."""
        self._require_open()
        return self._detections.edit_log(index_id)

    # =====================================================================
    # derived results
    # =====================================================================
    def request_derived(self, name: str, index_id: int) -> DerivedTable:
        """Computed now, or taken from the cache when its fingerprint matches the current inputs."""
        self._require_open()
        derivation = DERIVATIONS.get(name)
        if derivation is None:
            raise ProjectError(f"Unknown derived result: {name}")
        assignment, photo = self._region(index_id)
        saved = self._detections.load(index_id)

        def crop():
            cut = cut_region(self._photos.array(photo["photo_id"]), blob_to_array(assignment["outline"]))
            return cut.image, cut.mask, cut.offset

        inputs = DerivationInputs(index_id, saved.colonies if saved else ColonySet.empty(),
                                  float(photo["px_per_mm"]), saved.revision if saved else 0, photo["sha256"],
                                  hashlib.sha256(bytes(assignment["outline"])).hexdigest(), crop)
        key = fingerprint(derivation, inputs)
        if derivation.cache:
            cached = self._cache.lookup(name, index_id, key)
            if cached is not None:
                return DerivedTable(name, index_id, derivation.version, derivation.columns, tuple(cached),
                                    from_cache=True)
        rows = derivation.compute(inputs)
        if derivation.cache:
            self._cache.store(name, index_id, key, rows)
        return DerivedTable(name, index_id, derivation.version, derivation.columns, tuple(rows))

    # =====================================================================
    # exports (output only; never read back)
    # =====================================================================
    def export_colonies_csv(self, index_id: int, path: Path | None = None) -> Path:
        table = self.request_derived("colony_measurements", index_id)
        revision, version = self._detections.provenance(index_id)
        provenance = {label.variable: label.display for label in self._structure.labels(index_id)}
        provenance.update({"detection_revision": revision, "detection_version": version,
                           "measurement_version": table.algorithm_version, "software_version": __version__})
        path = Path(path) if path else self.exports_folder / f"{self.index_name(index_id)}_colonies.csv"
        return write_table_csv(table.columns, table.rows, path, provenance)

    def export_crop_png(self, index_id: int, path: Path | None = None) -> Path:
        record = self.checkout_image(index_id).record
        path = Path(path) if path else self.exports_folder / f"{record.name}_crop.png"
        return write_png(record.image, path)

    def export_browsable_copy(self, project_id: str, folder: Path) -> Path:
        """A folder anyone can look through without QuantaColony (see export_project). The project
        is opened for the export when it is not the open one, then closed again."""
        check_writable(folder)                                  # before opening anything
        if self._project_id == project_id:
            return self.export_project(folder)
        previous = self._project_id
        self.open_project(project_id)
        try:
            return self.export_project(folder)
        finally:
            self.close()
            if previous:
                self.open_project(previous)

    def export_project(self, folder: Path | None = None) -> Path:
        """Browsable copy of the open project: original photos, and for every index its crop, the
        crop with its colonies drawn on it and its colony table, plus summary.csv, project.json
        and an index.html page that explains the folder. QuantaColony never reads it back."""
        info = self.project_info()
        folder = Path(folder) if folder else self.exports_folder / "Browsable copy"
        check_writable(folder)
        for photo_id, file_name, content in self._photos.contents():
            target = folder / "photos" / f"{photo_id}_{safe_name(file_name)}"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)

        entries, rows, page_rows = [], [], []
        total_colonies = 0
        for index in info.indices:
            name = Structure.name_from_labels(index.labels)
            levels = {label.variable: label.display for label in index.labels}
            entry = {"index_id": index.index_id, "name": name,
                     "levels": {label.variable: label.value for label in index.labels},
                     "revision": index.revision, "needs_review": index.needs_review}
            page = {"name": name, "levels": " · ".join(f"{k}: {v}" for k, v in levels.items()),
                    "crop": "", "overlay": "", "table": "", "folder": "", "colonies": "–"}
            colonies = None
            if index.has_region:
                region = self._photos.assignment(index.index_id)
                entry["region"] = {"photo_id": region["photo_id"], "kind": region["region_kind"],
                                   "geometry": json.loads(region["geometry"])}
                packet = self.checkout_image(index.index_id)
                index_folder = folder / "indices" / name
                write_png(packet.record.image, index_folder / "crop.png")
                page["crop"] = f"indices/{name}/crop.png"
                page["folder"] = f"indices/{name}/"
                if packet.saved is not None:
                    colonies = packet.saved.colonies
                    write_overlay_png(packet.record.image, colonies, index_folder / "colonies.png")
                    self.export_colonies_csv(index.index_id, index_folder / "colonies.csv")
                    page["overlay"] = f"indices/{name}/colonies.png"
                    page["table"] = f"indices/{name}/colonies.csv"
                    entry["detection_params"] = asdict(packet.saved.params)
                    entry["edit_log"] = self.edit_log(index.index_id)
                    _, growth, marked = self.growth_overlay(index.index_id)
                    write_growth_png(packet.record.image, growth, marked, index_folder / "growth.png")
                    page["growth"] = f"indices/{name}/growth.png"
                    cover = self.request_derived("plate_coverage", index.index_id).rows[0]
                    entry["coverage"] = cover
                    if cover.get("growth_coverage") is not None:
                        page["coverage"] = f"{cover['growth_coverage']:.1%}"
            state = ("needs review" if index.needs_review else "detected" if index.revision
                     else "not detected yet" if index.has_region else "no region")
            count = len(colonies) if colonies is not None else ""
            if colonies is not None:
                total_colonies += len(colonies)
                page["colonies"] = len(colonies)
            radii_um = (colonies.radii * 1000.0 / float(self._region(index.index_id)[1]["px_per_mm"])
                        if colonies is not None and len(colonies) else np.array([]))
            cover = entry.get("coverage", {})
            rows.append({"index": name, **levels, "state": state, "colonies": count,
                         "median_radius_um": round(float(np.median(radii_um)), 2) if len(radii_um) else "",
                         "mean_radius_um": round(float(np.mean(radii_um)), 2) if len(radii_um) else "",
                         **{key: "" if cover.get(key) is None else round(float(cover[key]), 4)
                            for key in ("growth_coverage", "colony_coverage", "capture_ratio")},
                         "detection_revision": index.revision or ""})
            page["state"] = state
            entries.append(entry)
            page_rows.append(page)

        columns = ["index"] + [v.display_name for v in info.variables] + [
            "state", "colonies", "median_radius_um", "mean_radius_um", "growth_coverage", "colony_coverage",
            "capture_ratio", "detection_revision"]
        write_table_csv(columns, rows, folder / "summary.csv", {"software_version": __version__})
        write_json({"name": info.name, "schema_version": info.schema_version, "software_version": __version__,
                    "exported_at": now(), "detection_defaults": asdict(info.detection_defaults),
                    "variables": [{"name": v.name, "display_name": v.display_name, "type": v.type,
                                   "levels": [{"value": lv.value, "display": lv.display, "is_control": lv.is_control}
                                              for lv in v.levels]} for v in info.variables],
                    "indices": entries}, folder / "project.json")
        detected = sum(1 for i in info.indices if i.revision)
        write_browsable_summary({
            "name": info.name, "software_version": __version__,
            "exported_at": datetime.now().astimezone().strftime("%b %d, %Y %H:%M"),
            "tiles": [(self._photos.count(), "photos"), (len(info.variables), "variables"),
                      (self._structure.combination_count(), "indices"), (detected, "indices detected"),
                      (total_colonies, "colonies counted")],
            "variables": [(v.display_name, KIND_NAMES.get(v.type, v.type),
                           ", ".join(lv.display + (" (control)" if lv.is_control else "") for lv in v.levels))
                          for v in info.variables],
            "indices": page_rows}, folder / "index.html")
        return folder

    # =====================================================================
    # Cropping
    # =====================================================================
    def crop_packet(self) -> CropPacket:
        """Variables, plate settings, photos in order and every saved photo layout."""
        from ..core.cropping import VariableLevels
        self._require_open()
        variables = tuple(VariableLevels(v.name, v.display_name, tuple(lv.value for lv in v.levels),
                                         tuple(lv.display for lv in v.levels), v.type)
                          for v in self._structure.variables())
        return CropPacket(self._file.setting("name"), variables, self._file.setting("plate") or {},
                          self._photos.infos(), self._photos.layouts(),
                          self._file.setting("cropping_preferences") or {})

    def photo_image(self, photo_id: int) -> np.ndarray:
        """A plate photo as RGB pixels (read-only array)."""
        self._require_open()
        try:
            return self._photos.array(photo_id)
        except KeyError as error:
            raise ProjectError(f"No photo {photo_id} in this project") from error

    def save_cropping_preferences(self, preferences: dict) -> None:
        """Which variables are set per photo or per section, and the index board's view."""
        self.save_module_preferences("cropping", preferences)

    def commit_photo(self, photo_id: int, layout: dict, sections: list) -> list[int]:
        """Store one photo's layout and its regions as the truth, in one transaction.

        sections holds {variable name: level value} or None (unused) per section of the layout.
        Returns indices flagged for review because their region changed after detection.
        """
        from ..core.cropping import layout_from_dict
        self._require_open()
        plan = layout_from_dict(layout)
        if len(sections) != plan.section_count:
            raise ProjectError("Every section of the layout needs levels or must be marked unused")
        if self._photos.row(photo_id) is None:
            raise ProjectError(f"No photo {photo_id} in this project")
        variables = self._structure.variable_ids()
        level_ids = self._structure.level_ids()
        shape = self._photos.shape(photo_id)
        regions = []                      # (index levels as {variable_id: level_id}, kind, geometry, outline)
        seen = set()
        for number, levels in enumerate(sections, start=1):
            if levels is None:
                continue
            if set(levels) != set(variables) or any(levels[n] not in level_ids.get(n, {}) for n in variables):
                raise ProjectError(f"Section {number} needs one valid level of every variable")
            key = tuple(sorted((variables[n], level_ids[n][levels[n]]) for n in variables))
            if key in seen:
                raise ProjectError(f"Section {number} repeats an index already used on this photo")
            seen.add(key)
            kind, geometry = plan.region(number - 1)
            outline = outline_from_geometry(kind, geometry)
            try:
                crop_box(outline, shape)
            except ValueError as error:
                raise ProjectError(f"Section {number} lies outside the photo") from error
            regions.append((dict(key), kind, geometry, outline))

        plate = self._file.setting("plate") or {}
        flagged = []
        with self._file.transaction():
            index_ids = []
            for key, kind, geometry, outline in regions:
                index_id = self._structure.find_index(key)
                if index_id is None:
                    index_id = self._structure.insert_index(key)
                old = self._photos.assignment(index_id)
                if old is not None and old["photo_id"] != photo_id:
                    raise ProjectError("An index on this photo is already on another photo. Change one of them first.")
                if self._photos.save_assignment(index_id, photo_id, kind, geometry, outline) \
                        and self._detections.flag_review(index_id, REGION_CHANGED):
                    flagged.append(index_id)
                index_ids.append(index_id)
            for index_id in self._photos.assigned_on(photo_id):
                if index_id not in index_ids:
                    self._photos.delete_assignment(index_id)
                    if self._detections.flag_review(index_id, REGION_REMOVED):
                        flagged.append(index_id)
            self._photos.save_layout(photo_id, layout, sections)
            dish_mm = plate.get("dish_mm")
            if layout.get("kind") == "circular" and plate.get("scale") == "dish" and dish_mm:
                self._photos.set_scale(photo_id, 2 * float(layout["r"]) / float(dish_mm), "dish")
        return flagged

    # =====================================================================
    # project page and Stats
    # =====================================================================
    def project_status(self) -> ProjectStatus:
        """Counts for each step of the project page."""
        self._require_open()
        photos = self._photos.count()
        regions = len(self._photos.assigned_ids())
        detected, review, colonies = self._detections.counts()
        return ProjectStatus(photos, photos - self._photos.photos_needing_cropping(),
                             self._structure.combination_count(), regions, detected, review, colonies)

    def stats_variables(self) -> list:
        from ..core.stats import StatsVariable
        self._require_open()
        variables = []
        for v in self._structure.variables():
            control = next((lv.value for lv in v.levels if lv.is_control), None)
            variables.append(StatsVariable(v.name, v.display_name, v.type, tuple(lv.value for lv in v.levels),
                                           tuple(lv.display for lv in v.levels), control))
        return variables

    def colony_table(self):
        """Every colony of every detected index with its levels and scale (core.stats.ColonyTable)."""
        from ..core.stats import build_colony_table
        self._require_open()
        values = self._structure.all_level_values()
        indices = []
        for row in self._file.connection.execute("SELECT d.index_id, p.px_per_mm FROM detection d "
                                                 "JOIN assignments a USING (index_id) JOIN photos p USING (photo_id) "
                                                 "ORDER BY d.index_id").fetchall():
            table = self.request_derived("colony_measurements", row["index_id"])
            indices.append((row["index_id"], values.get(row["index_id"], {}), float(row["px_per_mm"]),
                            list(table.rows)))
        return build_colony_table(self.stats_variables(), indices)

    def index_table(self, coverage: bool = True, progress=None):
        """One row per detected index with its plate-level measures (core.stats.IndexTable).

        coverage: include growth and colony coverage (core.growth; about half a second for each index
        not measured before). progress(done, total) is called as indices are measured; returning False
        stops early, leaving the rest unmeasured (NaN)."""
        from ..core.stats import build_index_table
        self._require_open()
        values = self._structure.all_level_values()
        detected = self._file.connection.execute(
            "SELECT d.index_id, p.px_per_mm FROM detection d JOIN assignments a USING (index_id) "
            "JOIN photos p USING (photo_id) ORDER BY d.index_id").fetchall()
        rows = []
        measuring = coverage
        for done, row in enumerate(detected):
            table = self.request_derived("colony_measurements", row["index_id"])
            radii = [float(r["radius_um"]) for r in table.rows]
            measures = {"colony_count": float(len(radii)),
                        "mean_radius_um": float(np.mean(radii)) if radii else np.nan}
            if measuring:
                cover = self.request_derived("plate_coverage", row["index_id"]).rows[0]
                measures.update({key: np.nan if cover.get(key) is None else float(cover[key])
                                 for key in ("growth_coverage", "colony_coverage", "capture_ratio")})
                if progress is not None and progress(done + 1, len(detected)) is False:
                    measuring = False
            rows.append((row["index_id"], values.get(row["index_id"], {}), float(row["px_per_mm"]), measures))
        return build_index_table(self.stats_variables(), rows, INDEX_MEASURES)

    def coverage_waiting(self) -> int:
        """Detected indices whose growth coverage is not measured for their current colonies yet."""
        self._require_open()
        waiting = 0
        derivation = DERIVATIONS["plate_coverage"]
        for row in self._file.connection.execute("SELECT d.index_id FROM detection d JOIN assignments a "
                                                 "USING (index_id)").fetchall():
            assignment, photo = self._region(row["index_id"])
            saved = self._detections.load(row["index_id"])
            inputs = DerivationInputs(row["index_id"], ColonySet.empty(), float(photo["px_per_mm"]),
                                      saved.revision if saved else 0, photo["sha256"],
                                      hashlib.sha256(bytes(assignment["outline"])).hexdigest())
            if self._cache.lookup("plate_coverage", row["index_id"], fingerprint(derivation, inputs)) is None:
                waiting += 1
        return waiting

    def growth_overlay(self, index_id: int):
        """(crop image, growth mask, marked-colony mask) of an index, in crop coordinates."""
        from ..core.growth import growth_mask
        packet = self.checkout_image(index_id)
        colonies = packet.saved.colonies if packet.saved else ColonySet.empty()
        result = growth_mask(packet.record.image, packet.record.mask, colonies)
        return packet.record.image, result.growth, result.colonies

    def analyses_folder(self) -> Path:
        """The library's Analyses folder, created with an example and a note on first use."""
        folder = self._require_library().analyses_folder
        if not folder.is_dir():
            from ..analyses.registry import EXAMPLE
            folder.mkdir(parents=True, exist_ok=True)
            write_text(EXAMPLE, folder / "example_analysis.py.txt")
            write_text("Analysis plug-ins for QuantaColony Stats.\n\nEvery file ending in .py in this folder is "
                       "loaded when Stats opens. Loading a file runs its Python code, so only add files you "
                       "trust.\nexample_analysis.py.txt shows the format: rename it to example_analysis.py to try "
                       "it.\n", folder / "README.txt")
        return folder

    def module_preferences(self, module: str) -> dict:
        self._require_open()
        return self._file.setting(f"{module}_preferences") or {}

    def save_module_preferences(self, module: str, preferences: dict) -> None:
        self._require_open()
        with self._file.transaction():
            self._file.set_setting(f"{module}_preferences", preferences)

    def export_figure(self, figure, name: str, suffix: str = ".png", path: Path | None = None) -> Path:
        path = Path(path) if path else self.exports_folder / "stats" / f"{safe_name(name)}{suffix}"
        return write_figure(figure, path)

    def export_rows_csv(self, rows: list[dict], name: str, path: Path | None = None) -> Path:
        path = Path(path) if path else self.exports_folder / "stats" / f"{safe_name(name)}.csv"
        columns = list(rows[0]) if rows else []
        return write_table_csv(columns, rows, path, {"project": self._file.setting("name"),
                                                     "software_version": __version__})

    def photos_needing_cropping(self) -> int:
        """Photos with neither a saved Cropping layout nor any region assigned."""
        self._require_open()
        return self._photos.photos_needing_cropping()

    def unassigned_index_keys(self) -> list[tuple]:
        """Combinations of levels (values in variable order) that no photo region holds yet."""
        from ..core.cropping import all_index_keys
        packet_variables = self.crop_packet().variables
        names = [v.name for v in packet_variables]
        values = self._structure.all_level_values()
        assigned = {tuple(values.get(index_id, {}).get(n) for n in names) for index_id in self._photos.assigned_ids()}
        return [key for key in all_index_keys(list(packet_variables)) if key not in assigned]
