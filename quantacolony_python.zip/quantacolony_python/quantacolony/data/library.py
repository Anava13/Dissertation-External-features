"""The project library: one folder that holds every project, its backups and a marker file.

Finding the library: settings.json (always in local application data) stores
the library's path and id. The library folder holds library.json with the
same id. When the folder is not at the stored path, the same path is tried on
every other drive letter (an external drive that came back under a new
letter); otherwise the user locates the folder or creates a new library.
Projects hold their photos and refer to nothing outside themselves, so a
library moved intact never breaks a project.

    <library>/
      library.json                 marker: library id, format
      Projects/<project id>.qcproj one SQLite file per project
      Projects/<project id>.lock   held while the project is open
      Backups/<project id>/<UTC time>.qcproj
      Analyses/*.py                analysis plug-ins for Stats (see quantacolony/analyses/api.py)
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import sqlite3
import string
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

LIBRARY_MARKER = "library.json"
LIBRARY_FORMAT = 1
PROJECTS_FOLDER = "Projects"
BACKUPS_FOLDER = "Backups"
ANALYSES_FOLDER = "Analyses"
LOW_SPACE_BYTES = 5 * 1024 ** 3        # warn below 5 GB free: photos make projects large

# Folder names that sync programs create; SQLite files there can be copied mid-write
SYNC_FOLDER_PREFIXES = ("onedrive", "dropbox", "google drive", "googledrive", "icloud drive", "iclouddrive",
                        "icloud~", "pcloud")
SYNC_FOLDER_NAMES = ("my drive", "box", "box sync", "mega", "megasync")


class LibraryError(Exception):
    """A library problem; the message is meant for the user."""


@dataclass(frozen=True)
class Library:
    root: Path
    library_id: str

    @property
    def projects_folder(self) -> Path:
        return self.root / PROJECTS_FOLDER

    @property
    def backups_folder(self) -> Path:
        return self.root / BACKUPS_FOLDER

    @property
    def analyses_folder(self) -> Path:
        """Analysis plug-ins (.py files) that Stats loads besides the built-in ones."""
        return self.root / ANALYSES_FOLDER

    def project_path(self, project_id: str) -> Path:
        return self.projects_folder / f"{project_id}.qcproj"

    def lock_path(self, project_id: str) -> Path:
        return self.projects_folder / f"{project_id}.lock"

    def project_ids(self) -> list[str]:
        if not self.projects_folder.is_dir():
            return []
        return sorted(p.stem for p in self.projects_folder.glob("*.qcproj"))


@dataclass(frozen=True)
class LocationCheck:
    ok: bool
    problem: str             # why the folder cannot hold a library, empty when ok
    warning: str             # usable, but worth knowing (low space), may be empty
    free_bytes: int


# ----- marker ----------------------------------------------------------------
def read_marker(root: Path) -> str | None:
    """Library id from root/library.json, or None when root is not a library."""
    try:
        data = json.loads((Path(root) / LIBRARY_MARKER).read_text(encoding="utf-8"))
        return str(data["library_id"]) if data.get("format", 0) <= LIBRARY_FORMAT else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _write_marker(root: Path, library_id: str) -> None:
    temporary = root / (LIBRARY_MARKER + ".tmp")
    temporary.write_text(json.dumps({"library_id": library_id, "format": LIBRARY_FORMAT,
                                     "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                                    indent=2), encoding="utf-8")
    temporary.replace(root / LIBRARY_MARKER)


def open_library(root: Path) -> Library:
    library_id = read_marker(root)
    if library_id is None:
        raise LibraryError(f"{root} is not a QuantaColony library (no {LIBRARY_MARKER})")
    return Library(Path(root).resolve(), library_id)


def create_library(root: Path) -> Library:
    """New library at root (an empty or missing folder), or the library already there."""
    root = Path(root)
    if read_marker(root) is not None:
        return open_library(root)
    check = check_location(root)
    if not check.ok:
        raise LibraryError(check.problem)
    if root.exists() and any(root.iterdir()):
        raise LibraryError(f"{root} already holds other files. Choose an empty folder.")
    (root / PROJECTS_FOLDER).mkdir(parents=True, exist_ok=True)
    (root / BACKUPS_FOLDER).mkdir(exist_ok=True)
    library_id = uuid.uuid4().hex
    _write_marker(root, library_id)
    return Library(root.resolve(), library_id)


# ----- finding a library that moved -------------------------------------------
def find_library(stored_path: str, library_id: str) -> Library | None:
    """The library with this id at its stored path, or at the same path on another drive."""
    if not stored_path or not library_id:
        return None
    for candidate in _candidates(Path(stored_path)):
        if read_marker(candidate) == library_id:
            return Library(candidate.resolve(), library_id)
    return None


def _candidates(path: Path):
    yield path
    if sys.platform == "win32" and path.drive and len(path.drive) == 2:
        rest = Path(*path.parts[1:])
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if drive.upper() != path.anchor.upper() and os.path.exists(drive):
                yield Path(drive) / rest


# ----- choosing a location -----------------------------------------------------
def check_location(folder: Path) -> LocationCheck:
    """Whether a folder can hold the library: local, outside sync folders, with space."""
    folder = Path(folder).expanduser().absolute()
    existing = folder
    while not existing.exists() and existing.parent != existing:
        existing = existing.parent
    try:
        free = shutil.disk_usage(existing).free
    except OSError:
        free = 0
    resolved = existing.resolve() / folder.relative_to(existing) if folder != existing else existing.resolve()

    if _is_network(folder) or _is_network(resolved):
        return LocationCheck(False, "This folder is on a network drive. SQLite project files need a local drive, "
                                    "so the library cannot go there.", "", free)
    sync = _sync_folder(resolved)
    if sync:
        return LocationCheck(False, f"This folder is inside {sync}, which copies files while they are open "
                                    "and can damage project files. Choose a folder outside it.", "", free)
    if read_marker(folder) is None and folder.exists() and not folder.is_dir():
        return LocationCheck(False, f"{folder} is a file, not a folder.", "", free)
    warning = ""
    if free < LOW_SPACE_BYTES:
        warning = f"Only {free / 1024 ** 3:.1f} GB free on this drive; projects with many photos need several GB."
    return LocationCheck(True, "", warning, free)


def _sync_folder(path: Path) -> str:
    """Name of the sync service whose folder contains path, or ''."""
    for variable in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        root = os.environ.get(variable)
        if root and _is_within(path, Path(root)):
            return "OneDrive"
    for part in path.parts:
        lowered = part.lower()
        if lowered.startswith(SYNC_FOLDER_PREFIXES) or lowered in SYNC_FOLDER_NAMES:
            return part
    return ""


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False


def _is_network(path: Path) -> bool:
    text = str(path)
    if text.startswith("\\\\") or text.startswith("//"):
        return True
    if sys.platform == "win32" and path.drive:
        import ctypes
        DRIVE_REMOTE = 4
        return ctypes.windll.kernel32.GetDriveTypeW(path.anchor) == DRIVE_REMOTE
    if sys.platform.startswith("linux"):
        try:
            mounts = [line.split() for line in Path("/proc/mounts").read_text().splitlines()]
        except OSError:
            return False
        best, fstype = "", ""
        for fields in mounts:
            if len(fields) >= 3 and _is_within(path, Path(fields[1])) and len(fields[1]) > len(best):
                best, fstype = fields[1], fields[2]
        return fstype in {"nfs", "nfs4", "cifs", "smb3", "smbfs", "sshfs", "fuse.sshfs", "9p"}
    return False


# ----- moving the library --------------------------------------------------------
def move_library(library: Library, destination: Path) -> Library:
    """Copy the library to destination, verify every project there, then remove the old folder.

    The marker is written last, so an interrupted move leaves the old library
    complete and the new folder unrecognized. Close every project first.
    """
    destination = Path(destination)
    check = check_location(destination)
    if not check.ok:
        raise LibraryError(check.problem)
    if destination.exists() and any(destination.iterdir()):
        raise LibraryError(f"{destination} already holds other files. Choose an empty folder.")
    for lock in library.projects_folder.glob("*.lock"):
        if is_locked(lock):
            raise LibraryError("A project is open. Close it before moving the library.")
    for folder in (PROJECTS_FOLDER, BACKUPS_FOLDER):
        source = library.root / folder
        if source.is_dir():
            shutil.copytree(source, destination / folder, ignore=shutil.ignore_patterns("*.lock", "*.tmp"),
                            dirs_exist_ok=True)
        else:
            (destination / folder).mkdir(parents=True, exist_ok=True)
    for copied in (destination / PROJECTS_FOLDER).glob("*.qcproj"):
        original = library.projects_folder / copied.name
        if copied.stat().st_size != original.stat().st_size or not _intact(copied):
            shutil.rmtree(destination, ignore_errors=True)
            raise LibraryError(f"The copy of {copied.name} did not match the original; the library was not moved.")
    _write_marker(destination, library.library_id)
    shutil.rmtree(library.root)
    return Library(destination.resolve(), library.library_id)


def _intact(path: Path) -> bool:
    try:
        connection = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
        try:
            return connection.execute("PRAGMA quick_check").fetchone()[0] == "ok"
        finally:
            connection.close()
    except sqlite3.DatabaseError:
        return False


# ----- one QuantaColony window per project ---------------------------------------
class ProjectLock:
    """An operating-system file lock held while a project is open.

    The operating system releases it when the process ends, so a crash never
    leaves a project locked.
    """

    def __init__(self, path: Path):
        self.path = Path(path)
        self._handle = None

    def acquire(self) -> None:
        handle = open(self.path, "a+", encoding="utf-8")
        try:
            _lock(handle)
        except OSError as error:
            handle.seek(0)
            holder = handle.read().strip() or "another QuantaColony window"
            handle.close()
            raise LibraryError(f"This project is already open ({holder}). Close it there first.") from error
        handle.seek(0)
        handle.truncate()
        handle.write(f"{socket.gethostname()}, process {os.getpid()}")
        handle.flush()
        self._handle = handle

    def release(self) -> None:
        if self._handle is not None:
            try:
                _unlock(self._handle)
            finally:
                self._handle.close()
                self._handle = None
            self.path.unlink(missing_ok=True)


def is_locked(path: Path) -> bool:
    try:
        with open(path, "a+", encoding="utf-8") as handle:
            _lock(handle)
            _unlock(handle)
        return False
    except OSError:
        return True


if sys.platform == "win32":
    import msvcrt

    def _lock(handle) -> None:
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)

    def _unlock(handle) -> None:
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
else:
    import fcntl

    def _lock(handle) -> None:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock(handle) -> None:
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
