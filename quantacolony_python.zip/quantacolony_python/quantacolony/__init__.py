"""QuantaColony: colony analysis for plate photographs."""

__version__ = "0.2.0"
