"""From the project's tables and the user's slot choices to an AnalysisData (Qt-free).

    assignment   {variable name: slot key, or POOLED}
    scheme       'raw', 'control_nominal' (divide by the control level of the groups slot at the same
                 step) or 'control_ordinal' (divide by the own group's mean at the control step)
    hidden       {variable name: level values the user does not show}
    left_out     index ids left out entirely (overplated plates): before normalization, so they never
                 serve as a reference
    no_touching  colonies split from touching blobs are left out of colony sizes (one row per colony
                 only), before normalization; colony counts per index always include them

Normalizations follow the MATLAB Hub: each value is divided by the mean of the control group.

Hidden levels: values are normalized first, then rows with a hidden level are left out. A
hidden level of the variables that hold the control (the reference slot) still serves as the
reference, so mutants can be shown normalized to a wild type that is not drawn. A hidden level
of any other variable (a pooled replicate, say) is left out of the reference too.
"""

from __future__ import annotations

import dataclasses
import itertools

import numpy as np

from ..core.stats import ColonyTable, IndexTable, StatsVariable
from .api import INDEX, POOLED, Analysis, AnalysisData, Axis

RAW, CONTROL_NOMINAL, CONTROL_ORDINAL = "raw", "control_nominal", "control_ordinal"
SCHEMES = (RAW, CONTROL_NOMINAL, CONTROL_ORDINAL)

COLONY_MEASURES = {"radius_um": "Colony radius (µm)"}


# ----- slot assignment ------------------------------------------------------------
def default_assignment(analysis: Analysis, variables) -> dict[str, str]:
    """Each slot takes the variables of its first accepted kind (one ordinal variable at most), then
    any accepted variable it still needs to reach its minimum. Everything else is pooled."""
    assignment = {v.name: POOLED for v in variables}
    for slot in sorted(analysis.slots, key=lambda s: len(s.kinds)):         # most specific slots first
        free = [v for v in variables if assignment[v.name] == POOLED]
        primary = [v for v in free if v.kind == slot.kinds[0]]
        if slot.kinds[0] == "ordinal":
            primary = primary[:1]
        limit = slot.max_variables if slot.max_variables is not None else len(primary)
        for v in primary[:limit]:
            assignment[v.name] = slot.key
        taken = sum(1 for k in assignment.values() if k == slot.key)
        for v in [v for v in free if assignment[v.name] == POOLED and v.kind in slot.kinds]:
            if taken >= slot.min_variables:
                break
            assignment[v.name] = slot.key
            taken += 1
    return assignment


def merge_assignment(analysis: Analysis, variables, saved: dict | None) -> dict[str, str]:
    """A saved assignment where it still fits this analysis, the default elsewhere."""
    keys = {s.key for s in analysis.slots}
    default = default_assignment(analysis, variables)
    if not saved:
        return default
    merged = {}
    for v in variables:
        slot = saved.get(v.name, default[v.name])
        merged[v.name] = slot if slot == POOLED or slot in keys else default[v.name]
    return merged


def assignment_problem(analysis: Analysis, variables, assignment: dict[str, str]) -> str:
    """Why this assignment cannot be drawn, or ''."""
    by_name = {v.name: v for v in variables}
    for name, slot_key in assignment.items():
        if slot_key == POOLED or name not in by_name:
            continue
        slot = next((s for s in analysis.slots if s.key == slot_key), None)
        if slot is None:
            return f"{by_name[name].display_name}: {analysis.name} has no '{slot_key}'."
        if by_name[name].kind not in slot.kinds:
            kinds = " or ".join(slot.kinds)
            return f"{slot.title} takes {kinds} variables; {by_name[name].display_name} is {by_name[name].kind}."
    for slot in analysis.slots:
        count = sum(1 for k in assignment.values() if k == slot.key)
        if count < slot.min_variables:
            kinds = " or ".join(slot.kinds)
            need = "a variable" if slot.min_variables == 1 else f"{slot.min_variables} variables"
            return f"{slot.title} needs {need} ({kinds})."
        if slot.max_variables is not None and count > slot.max_variables:
            return f"{slot.title} takes at most {slot.max_variables} variable{'s' if slot.max_variables > 1 else ''}."
    return ""


def accepts(analysis: Analysis, slot_key: str, variable: StatsVariable) -> bool:
    slot = next((s for s in analysis.slots if s.key == slot_key), None)
    return slot is None or variable.kind in slot.kinds


# ----- shown levels ------------------------------------------------------------------
def shown_levels(variables, hidden: dict | None) -> dict[str, tuple[str, ...]]:
    """The levels shown for each variable, in level order. A variable always shows at least one level:
    when every level is hidden, every level is shown. Levels added to a project later are shown."""
    shown = {}
    for v in variables:
        off = set((hidden or {}).get(v.name, ()))
        shown[v.name] = tuple(value for value in v.values if value not in off) or tuple(v.values)
    return shown


def shown_variable(variable: StatsVariable, shown: tuple[str, ...]) -> StatsVariable:
    """The variable with only its shown levels (its control is kept even when hidden)."""
    return dataclasses.replace(variable, values=tuple(shown),
                               displays=tuple(variable.display(value) for value in shown))


def shown_rows(levels: dict, n_rows: int, shown: dict, exempt: set | frozenset = frozenset()) -> np.ndarray:
    """Rows whose level is shown for every variable not in exempt."""
    keep = np.ones(n_rows, dtype=bool)
    for name, values in shown.items():
        if name not in exempt and name in levels:
            keep &= np.isin(levels[name], np.asarray(values, dtype=object))
    return keep


def hidden_note(variables, shown: dict) -> str:
    parts = [f"{v.display_name}: {', '.join(v.display(x) for x in v.values if x not in shown[v.name])}"
             for v in variables if len(shown[v.name]) < len(v.values)]
    return f"Not shown: {'; '.join(parts)}." if parts else ""


# ----- level colors ------------------------------------------------------------------
def default_level_colors(variable: StatsVariable, style) -> dict[str, str]:
    """A color for every level, by its place among all the variable's levels (hiding a level never
    recolors another): the group palette, or a gradient for an ordinal variable."""
    from matplotlib.colors import to_hex
    if variable.kind == "ordinal":
        return {value: to_hex(color) for value, color in zip(variable.values, style.step_colors(len(variable.values)))}
    return {value: style.group_color(i) for i, value in enumerate(variable.values)}


def level_colors(variable: StatsVariable, style, saved: dict | None) -> dict[str, str]:
    """The default colors with the user's choices where they name a level and a valid color."""
    from matplotlib.colors import is_color_like, to_hex
    colors = default_level_colors(variable, style)
    for value, color in (saved or {}).items():
        if value in colors and isinstance(color, str) and is_color_like(color):
            colors[value] = to_hex(color)
    return colors


def color_problem(analysis: Analysis, variables, assignment: dict[str, str], color_variable: str) -> str:
    """Why the chosen color variable cannot color this analysis ('' when it can, or none is chosen)."""
    variable = next((v for v in variables if v.name == color_variable), None)
    if variable is None:
        return ""
    if not analysis.color_slots:
        return f"{analysis.name} keeps its own colors."
    titles = " or ".join(s.title for s in analysis.slots if s.key in analysis.color_slots)
    slot = assignment.get(color_variable, POOLED)
    if slot == POOLED:
        return (f"{variable.display_name} is pooled, so each group mixes its levels and the default colors are "
                f"used. Put {variable.display_name} in {titles} to color by it.")
    if slot not in analysis.color_slots:
        title = next((s.title for s in analysis.slots if s.key == slot), slot)
        return (f"{analysis.name} colors by {titles}; {variable.display_name} is on {title}, so the default colors "
                f"are used.")
    return ""


# ----- axes ---------------------------------------------------------------------------
def slot_axis(variables, assignment: dict[str, str], slot_key: str) -> Axis:
    chosen = tuple(v for v in variables if assignment.get(v.name) == slot_key)
    keys = tuple(itertools.product(*(v.values for v in chosen))) if chosen else ((),)
    labels = tuple(" · ".join(v.display(x) for v, x in zip(chosen, key)) for key in keys)
    return Axis(chosen, keys, labels, " · ".join(v.display_name for v in chosen))


def positions_on(levels: dict, n_rows: int, axis: Axis) -> np.ndarray:
    """Each row's position on the axis (-1 when a level is missing)."""
    if not axis.variables:
        return np.zeros(n_rows, dtype=int)
    lookup = {key: i for i, key in enumerate(axis.keys)}
    columns = [levels[v.name] for v in axis.variables]
    return np.array([lookup.get(tuple(c[i] for c in columns), -1) for i in range(n_rows)], dtype=int)


def control_position(axis: Axis) -> tuple[int, str]:
    """The level whose variables all sit at their control level (the first level where none is marked)."""
    key = tuple(v.control if v.control in v.values else v.values[0] for v in axis.variables)
    unmarked = [v.display_name for v in axis.variables if v.control not in v.values]
    note = f"No control level marked for {', '.join(unmarked)}; the first level is used." if unmarked else ""
    return axis.keys.index(key), note


# ----- normalization --------------------------------------------------------------------
def available_schemes(analysis: Analysis, axes: dict) -> list[str]:
    if analysis.normalize is None:
        return [RAW]
    groups, steps = analysis.normalize
    schemes = [RAW]
    if axes[groups].variables:
        schemes.append(CONTROL_NOMINAL)
    if axes[steps].variables:
        schemes.append(CONTROL_ORDINAL)
    return schemes


def scheme_label(scheme: str, axes: dict, analysis: Analysis) -> str:
    if scheme == RAW or analysis.normalize is None:
        return "Raw data"
    groups, steps = analysis.normalize
    title = axes[groups].title if scheme == CONTROL_NOMINAL else axes[steps].title
    return f"Control {title.lower() or 'level'}"


def normalize(values: np.ndarray, group_pos: np.ndarray, step_pos: np.ndarray, groups: Axis, steps: Axis,
              scheme: str) -> tuple[np.ndarray, list[str]]:
    values = values.astype(float).copy()
    present = np.isfinite(values)                  # rows left out beforehand (hidden levels) get no note
    notes = []
    if scheme == CONTROL_ORDINAL:
        control, note = control_position(steps)
        notes += [note] if note else []
        for g in range(len(groups)):
            reference = values[(group_pos == g) & (step_pos == control) & np.isfinite(values)]
            rows = group_pos == g
            if reference.size and np.nanmean(reference) != 0:
                values[rows] = values[rows] / np.nanmean(reference)
            elif (rows & present).any():
                values[rows] = np.nan
                notes.append(f"{groups.labels[g] or 'All'}: nothing at the control {steps.title.lower()} "
                             f"({steps.labels[control]}), so it is left out.")
    elif scheme == CONTROL_NOMINAL:
        control, note = control_position(groups)
        notes += [note] if note else []
        for s in range(len(steps)):
            reference = values[(step_pos == s) & (group_pos == control) & np.isfinite(values)]
            rows = step_pos == s
            if reference.size and np.nanmean(reference) != 0:
                values[rows] = values[rows] / np.nanmean(reference)
            elif (rows & present).any():
                values[rows] = np.nan
                notes.append(f"{steps.labels[s] or 'All'}: nothing from the control {groups.title.lower()} "
                             f"({groups.labels[control]}), so it is left out.")
    return values, notes


# ----- building the data ------------------------------------------------------------------
def measures_for(analysis: Analysis, index_table: IndexTable | None) -> dict[str, str]:
    """Measures the analysis can plot: {id: label}."""
    if analysis.unit == INDEX:
        return dict(index_table.measure_labels) if index_table is not None else {}
    return dict(COLONY_MEASURES)


def build_data(analysis: Analysis, colonies: ColonyTable, index_table: IndexTable | None,
               assignment: dict[str, str], scheme: str = RAW, measure: str = "",
               hidden: dict | None = None, left_out=(), no_touching: bool = False) -> AnalysisData:
    if analysis.unit == INDEX:
        if index_table is None:
            raise ValueError("No per-index measurements are available")
        variables, levels, n = index_table.variables, index_table.levels, len(index_table)
        measure = measure if measure in index_table.measures else next(iter(index_table.measures))
        raw, value_label = index_table.measures[measure], index_table.measure_labels[measure]
        um_per_px, radius_px, ids = index_table.um_per_px, np.array([]), index_table.index_ids
    else:
        variables, levels, n = colonies.variables, colonies.levels, len(colonies)
        measure = "radius_um"
        raw, value_label = colonies.radius_um, COLONY_MEASURES["radius_um"]
        um_per_px, radius_px, ids = colonies.um_per_px, colonies.radius_px, colonies.index_ids
    shown = shown_levels(variables, hidden)
    kept = ~np.isin(np.asarray(ids), np.asarray(list(left_out), dtype=int)) if len(left_out) else np.ones(n, bool)
    if no_touching and analysis.unit != INDEX and colonies.touching is not None:
        kept &= ~colonies.touching
    full_axes = {slot.key: slot_axis(variables, assignment, slot.key) for slot in analysis.slots}
    schemes = available_schemes(analysis, full_axes)
    scheme = scheme if scheme in schemes else RAW
    notes: list[str] = []
    values = np.where(kept, np.asarray(raw, dtype=float), np.nan)
    if scheme != RAW:                       # normalize on every level, then hide (see the module notes)
        groups, steps = analysis.normalize
        reference = full_axes[groups if scheme == CONTROL_NOMINAL else steps]
        usable = shown_rows(levels, n, shown, exempt={v.name for v in reference.variables})
        full_positions = {key: positions_on(levels, n, axis) for key, axis in full_axes.items()}
        values, notes = normalize(np.where(usable, values, np.nan), full_positions[groups], full_positions[steps],
                                  full_axes[groups], full_axes[steps], scheme)
        value_label = f"Normalized {value_label.split(' (')[0].lower()}"

    rows = np.flatnonzero(shown_rows(levels, n, shown) & kept)
    levels = {name: np.asarray(column)[rows] for name, column in levels.items()}
    values = values[rows]
    um_per_px, ids = np.asarray(um_per_px, dtype=float)[rows], np.asarray(ids)[rows]
    radius_px = np.asarray(radius_px, dtype=float)
    radius_px = radius_px[rows] if radius_px.size else radius_px
    note = hidden_note(variables, shown)
    variables = tuple(shown_variable(v, shown[v.name]) for v in variables)
    axes = {slot.key: slot_axis(variables, assignment, slot.key) for slot in analysis.slots}
    positions = {key: positions_on(levels, rows.size, axis) for key, axis in axes.items()}
    for key, pos in positions.items():
        values = np.where(pos >= 0, values, np.nan)
    notes = ([note] if note else []) + list(notes)
    return AnalysisData(analysis.unit, axes, positions, values, value_label, measure, scheme,
                        scheme_label(scheme, axes, analysis), um_per_px, radius_px, ids, tuple(notes))
