"""Finds the analyses Stats offers: the built-in ones, then any in the library's Analyses folder.

A module offers analyses through a list named ANALYSES (or a single one named ANALYSIS). A
file that fails to load, or an analysis that breaks the contract, is skipped and reported;
it never stops Stats from opening. Loading a file runs its Python code, so only put files
you trust in the Analyses folder.
"""

from __future__ import annotations

import importlib
import importlib.util
import sys
import traceback
from pathlib import Path

from .api import API_VERSION, COLONY, INDEX, LoadReport, Option, Slot

BUILTIN_MODULES = ("distributions", "across_levels", "fidelity", "subpopulations", "plate_metrics")
GROUP_ORDER = ("Distributions", "Across ordinal levels", "Measurement quality", "Subpopulations", "Plates")


def contract_problem(analysis) -> str:
    """Why an object cannot be used as an analysis, or ''."""
    for attribute in ("id", "name", "compute", "draw"):
        if not getattr(analysis, attribute, None):
            return f"it has no {attribute}"
    if getattr(analysis, "unit", COLONY) not in (COLONY, INDEX):
        return f"unit must be '{COLONY}' or '{INDEX}'"
    if getattr(analysis, "api_version", API_VERSION) > API_VERSION:
        return f"it needs a newer QuantaColony (analysis API {analysis.api_version}, this one is {API_VERSION})"
    slots = getattr(analysis, "slots", ())
    if not all(isinstance(slot, Slot) for slot in slots):
        return "every slot must be an analyses.api.Slot"
    if len({slot.key for slot in slots}) != len(slots):
        return "two slots share a key"
    if not all(isinstance(option, Option) for option in getattr(analysis, "options", ())):
        return "every option must be an analyses.api.Option"
    normalize = getattr(analysis, "normalize", None)
    if normalize is not None and not set(normalize) <= {slot.key for slot in slots}:
        return "normalize names a slot it does not have"
    return ""


def _offered(module) -> list:
    if hasattr(module, "ANALYSES"):
        return list(module.ANALYSES)
    if hasattr(module, "ANALYSIS"):
        return [module.ANALYSIS]
    return []


def _add(report: LoadReport, analysis, source: str) -> None:
    problem = contract_problem(analysis)
    name = getattr(analysis, "name", "") or getattr(analysis, "id", "") or repr(analysis)
    if problem:
        report.problems.append(f"{source}: '{name}' was skipped because {problem}.")
    elif analysis.id in report.analyses:
        report.problems.append(f"{source}: '{name}' was skipped because another analysis already has the id "
                               f"'{analysis.id}' ({report.sources[analysis.id]}).")
    else:
        report.analyses[analysis.id] = analysis
        report.sources[analysis.id] = source


def load_analyses(user_folder: Path | None = None) -> LoadReport:
    report = LoadReport()
    for name in BUILTIN_MODULES:
        module = importlib.import_module(f"{__package__}.builtin.{name}")
        for analysis in _offered(module):
            _add(report, analysis, "built-in")
    if user_folder is not None and Path(user_folder).is_dir():
        for path in sorted(Path(user_folder).glob("*.py")):
            module_name = f"quantacolony_user_analysis_{path.stem}"
            try:
                spec = importlib.util.spec_from_file_location(module_name, path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
            except Exception:                                    # any error in a user file is reported, not raised
                sys.modules.pop(module_name, None)
                last = traceback.format_exc().strip().splitlines()[-1]
                report.problems.append(f"{path.name} could not be loaded: {last}")
                continue
            offered = _offered(module)
            if not offered:
                report.problems.append(f"{path.name} defines no ANALYSES list.")
            for analysis in offered:
                _add(report, analysis, path.name)
    return report


def sections(report: LoadReport) -> list[tuple[str, list[tuple[str, str]]]]:
    """(group title, [(id, name)]) in the built-in group order, then other groups alphabetically."""
    groups: dict[str, list[tuple[str, str]]] = {}
    for analysis in report.analyses.values():
        groups.setdefault(analysis.group or "Other", []).append((analysis.id, analysis.name))
    order = [g for g in GROUP_ORDER if g in groups] + sorted(g for g in groups if g not in GROUP_ORDER)
    return [(group, groups[group]) for group in order]


EXAMPLE = '''"""An example QuantaColony analysis. Rename this file to end in .py to load it.

Every file ending in .py in this folder is loaded when Stats opens. Each defines ANALYSES, a
list of analysis objects. See quantacolony/analyses/api.py for the full contract.
"""

import numpy as np

from quantacolony.analyses.api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot
from quantacolony.analyses.common import show_message, style_axes


class ColonyCounts(Analysis):
    id = "example:colony_counts"            # unique; prefix it with something of your own
    name = "Colony counts"
    group = "My analyses"
    description = "Number of colonies for every level of the x axis."
    unit = "colony"                          # 'colony' (a row per colony) or 'index' (a row per index)
    slots = (Slot("x", "X axis", (NOMINAL, ORDINAL, REPLICATE), min_variables=1),)

    def compute(self, data, options):
        axis = data.axes["x"]
        counts = [int(data.select(x=i).sum()) for i in range(len(axis))]
        return {"labels": list(axis.labels), "counts": counts, "title": axis.title}

    def draw(self, figure, result, style):
        figure.clear()
        if not sum(result["counts"]):
            show_message(figure, "No colonies yet.", style)
            return None
        ax = figure.add_subplot(111)
        style_axes(ax, style)
        ax.bar(np.arange(len(result["counts"])), result["counts"], color=style.group_color(0))
        ax.set_xticks(np.arange(len(result["labels"])), result["labels"])
        ax.set_xlabel(result["title"], color=style.ink)
        ax.set_ylabel("Colonies", color=style.ink)
        return None

    def table(self, result):
        return [{"level": label, "colonies": count} for label, count in zip(result["labels"], result["counts"])]


ANALYSES = [ColonyCounts()]
'''
