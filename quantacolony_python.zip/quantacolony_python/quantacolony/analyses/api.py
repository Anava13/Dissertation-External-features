"""The contract between QuantaColony and an analysis (Qt-free).

An analysis is a Python object that declares what it needs and supplies three steps:

    declares   id, name, group, description, version
               unit       'colony' (one row per colony) or 'index' (one row per plate region)
               slots      the variable dimensions it plots: for each, which variable kinds it
                          accepts and how many variables it takes
               options    choices the user makes (shown as buttons above the figure)
               normalize  which two slots the control normalizations refer to, or None
               color_slots  the slots that define one colored element (a box, a curve, a line),
                          so "Color by" can color it by a level of the chosen variable; () when
                          the analysis keeps its own colors

    compute(data, options)          -> result      the numbers (pure; may run in the background)
    draw(figure, result, style)     -> None, or a new Figure to show instead
    table(result)                   -> rows        the numbers behind the figure, for Save table

QuantaColony builds the controls from the declaration, assigns every design variable (nominal,
ordinal) to one slot or pools it (a replicate variable is always pooled: its plates are interchangeable), normalizes the measurement, and hands the analysis an AnalysisData. Variables
left out of every slot are pooled: their colonies (or indices) join the same groups.
Levels the user hides are left out of the data before the analysis sees it (after
normalization, so a hidden control level still serves as the reference).

Colors: an analysis that declares color_slots asks style.color_for(data, slot=position, ...)
for each element it draws, and uses its own color when that returns None.

Writing a new analysis: subclass Analysis (or set the same attributes on any object),
put it in a module that defines ANALYSES = [MyAnalysis()], and drop the module into the
Analyses folder of the project library. QuantaColony loads it at the next start of Stats.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

API_VERSION = 1

NOMINAL, ORDINAL, REPLICATE = "nominal", "ordinal", "replicate"
# A replicate variable never reaches an analysis: it numbers the interchangeable plates of an index, so Stats
# always pools it. REPLICATE stays in the kinds slots may list, so plug-ins written for it still load.
ANY_KIND = (NOMINAL, ORDINAL, REPLICATE)
COLONY, INDEX = "colony", "index"
POOLED = ""                                       # a variable in no slot


@dataclass(frozen=True)
class Slot:
    """One variable dimension of a plot (x axis, color groups, panels, ...)."""

    key: str
    title: str                                    # shown on the slot's button
    kinds: tuple[str, ...] = ANY_KIND             # variable kinds the slot accepts
    min_variables: int = 0                        # fewer is a problem the window reports
    max_variables: int | None = None              # None: any number (they combine into level pairs)
    description: str = ""


@dataclass(frozen=True)
class Option:
    key: str
    title: str
    choices: tuple[tuple[str, str], ...]          # (value, label)
    default: str = ""

    @property
    def initial(self) -> str:
        return self.default or self.choices[0][0]


@dataclass(frozen=True)
class Axis:
    """The levels of one slot: every combination of its variables, in variable and level order."""

    variables: tuple                              # core.stats.StatsVariable
    keys: tuple[tuple, ...]
    labels: tuple[str, ...]
    title: str                                    # the variables' names joined, '' when the slot is empty

    def __len__(self) -> int:
        return len(self.keys)


@dataclass(frozen=True)
class AnalysisData:
    """What QuantaColony hands an analysis: one entry per row (colony or index).

    axes[slot]       the slot's levels
    positions[slot]  each row's level position on that slot (-1 when the row lacks a level)
    values           the measurement after normalization (NaN where it cannot be normalized)
    um_per_px        each row's photo scale, for resolution-aware choices (bandwidth floors)
    selected         index ids chosen by one plate per group, for an analysis that declares
                     marks_selection = True (it receives every used plate and marks these); None otherwise
    """

    unit: str
    axes: dict
    positions: dict
    values: np.ndarray
    value_label: str                              # axis label for the values
    measure: str                                  # measure id ('radius_um', 'growth_coverage', ...)
    scheme: str                                   # 'raw', 'control_nominal', 'control_ordinal'
    scheme_label: str
    um_per_px: np.ndarray
    radius_px: np.ndarray                         # colony unit: radius in pixels (fidelity); else empty
    index_ids: np.ndarray
    notes: tuple[str, ...] = ()
    selected: frozenset | None = None             # with one plate per group: the chosen index ids (else None)

    def __len__(self) -> int:
        return len(self.values)

    def select(self, **levels: int) -> np.ndarray:
        """Boolean rows at the given slot positions with a finite value, e.g. select(x=2, groups=0)."""
        keep = np.isfinite(self.values)
        for slot, position in levels.items():
            keep &= self.positions[slot] == position
        return keep

    def cell(self, **levels: int) -> np.ndarray:
        return self.values[self.select(**levels)]

    def axis(self, slot: str) -> Axis:
        return self.axes[slot]


@dataclass(frozen=True)
class PlotStyle:
    """Colors and fonts the front end gives every analysis, so analyses never hard-code a look."""

    ink: str = "#2D2D2D"
    muted: str = "#6B6E66"
    grid: str = "#E8E8E4"
    spine: str = "#B5B5B0"
    background: str = "#FFFFFF"
    panel_edge: str = "#B3B3B3"
    bar: str = "#4D4D4D"
    empty_cell: str = "#E6E6E6"
    marker_fill: str = "#FFFFFF"                  # centers of median markers
    group_colors: tuple[str, ...] = ("#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD", "#8C564B",
                                     "#E377C2", "#7F7F7F", "#BCBD22", "#17BECF")
    step_colormap: str = "viridis"                # ordered levels, light to dark in one hue
    zone_colors: tuple[str, ...] = ("#33CC33", "#99E633", "#FFD933", "#FF801A", "#E63333")
    font_family: str = "sans-serif"
    font_size: float = 10.0
    color_variable: str = ""                      # the variable chosen in "Color by"; '' for the analysis's own colors
    level_colors: tuple = ()                      # ((level value, color), ...) for color_variable

    def color_for(self, data: "AnalysisData", **positions: int) -> str | None:
        """The color of one drawn element, given its position on the slots that define it, e.g.
        color_for(data, groups=g, x=x). None when no variable is chosen or it is in none of those slots."""
        if not self.color_variable:
            return None
        for slot, position in positions.items():
            axis = data.axes.get(slot)
            names = [v.name for v in axis.variables] if axis is not None else []
            if self.color_variable in names and 0 <= position < len(axis.keys):
                return dict(self.level_colors).get(axis.keys[position][names.index(self.color_variable)])
        return None

    def group_color(self, i: int) -> str:
        return self.group_colors[i % len(self.group_colors)]

    def step_colors(self, n: int) -> list:
        from matplotlib import colormaps
        cmap = colormaps[self.step_colormap]
        return [cmap(0.15 + 0.7 * k / max(1, n - 1)) for k in range(n)]


class Analysis:
    """Base class with the declaration's defaults. Subclasses set the attributes and the three steps."""

    id: str = ""
    name: str = ""
    group: str = "Other"
    description: str = ""
    version: int = 1
    api_version: int = API_VERSION
    unit: str = COLONY
    slots: tuple[Slot, ...] = ()
    options: tuple[Option, ...] = ()
    normalize: tuple[str, str] | None = None      # (groups slot, steps slot) for the control schemes
    color_slots: tuple[str, ...] = ()             # slots that define one colored element ("Color by")
    background: bool = False                      # compute takes long: run it off the interface thread
    marks_selection: bool = False                 # one plate per group: draw every used plate, mark the chosen

    def problem(self, data: AnalysisData) -> str:
        """Why this data cannot be drawn, or ''. Called after the slot checks pass."""
        return ""

    def compute(self, data: AnalysisData, options: dict) -> Any:
        raise NotImplementedError

    def draw(self, figure, result: Any, style: PlotStyle):
        raise NotImplementedError

    def table(self, result: Any) -> list[dict]:
        return []

    def notes(self, result: Any) -> list[str]:
        return []

    def title(self, data: AnalysisData, options: dict) -> str:
        return self.name


Loader = Callable[[], list]


@dataclass
class LoadReport:
    """What the registry found: analyses by id, and problems with files it could not load."""

    analyses: dict = field(default_factory=dict)
    problems: list[str] = field(default_factory=list)
    sources: dict = field(default_factory=dict)   # id -> 'built-in' or the file it came from
