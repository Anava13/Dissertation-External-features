"""Analyses Stats can draw. Each is a plug-in that declares its variable slots and draws on a
figure QuantaColony provides; see api.py for the contract and registry.py for loading."""

from .api import (ANY_KIND, API_VERSION, COLONY, INDEX, NOMINAL, ORDINAL, POOLED, REPLICATE, Analysis,
                  AnalysisData, Axis, Option, PlotStyle, Slot)

__all__ = ["Analysis", "AnalysisData", "Axis", "Option", "PlotStyle", "Slot", "API_VERSION", "ANY_KIND", "COLONY",
           "INDEX", "NOMINAL", "ORDINAL", "POOLED", "REPLICATE"]
