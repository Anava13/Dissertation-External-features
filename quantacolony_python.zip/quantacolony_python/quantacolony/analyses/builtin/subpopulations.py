"""Subpopulations: a LogNormal mixture per index (subpopfig), clustered by one slot and ordered by another.

The fit takes seconds to a minute, so it runs in the background. subpopfig draws its own
figure; draw() returns it so the window shows it in place of its own.
"""

from __future__ import annotations

import contextlib
import io

import numpy as np

from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot


class Subpopulations(Analysis):
    id = "subpopulations"
    name = "Mixture model"
    group = "Subpopulations"
    description = ("LogNormal mixture per index (subpopfig): the number of subpopulations with the lowest BIC, "
                   "up to four. Each column of circles is one index.")
    slots = (Slot("clusters", "Clusters", (NOMINAL, REPLICATE, ORDINAL)),
             Slot("levels", "Levels", (ORDINAL, NOMINAL, REPLICATE)))
    background = True

    def frame(self, data):
        """One row per colony with the subpopfig roles. EntryID is the index, so one mixture is fit per index.
        Levels become their position (1, 2, ...), with the level text as display."""
        import pandas as pd
        clusters, levels = data.axes["clusters"], data.axes["levels"]
        c_pos, l_pos = data.positions["clusters"], data.positions["levels"]
        keep = (c_pos >= 0) & (l_pos >= 0) & np.isfinite(data.values) & (data.values > 0)
        frame = pd.DataFrame({
            "entry": [f"index {i}" for i in data.index_ids[keep]],
            "nominal": [clusters.labels[c] or "All" for c in c_pos[keep]],
            "ordinal": l_pos[keep] + 1,
            "ordinal_display": [levels.labels[o] or "All" for o in l_pos[keep]],
            "radius_um": data.values[keep],
            "nominal_order": c_pos[keep],
        }).sort_values(["nominal_order", "ordinal"], kind="stable")
        schema = {
            "EntryID": {"column": "entry", "label": "Index"},
            "Nominal": {"column": "nominal", "label": clusters.title or "All"},
            "Ordinal": {"column": "ordinal", "display_column": "ordinal_display", "label": levels.title or "All"},
            "Measurement": {"column": "radius_um", "label": "Radius (µm)"},
        }
        return frame.drop(columns="nominal_order"), schema

    def compute(self, data, options):
        from ...stats.subpopfig import fit_mixtures, from_dataframe
        frame, schema = self.frame(data)
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            workbook = from_dataframe(frame, schema, source="QuantaColony project")
            fits = fit_mixtures(workbook)
        return {"fits": fits, "printed": printed.getvalue()}

    def busy_text(self, data) -> str:
        entries = len(set(data.index_ids[np.isfinite(data.values)].tolist()))
        return f"Fitting LogNormal mixtures to {entries} indices ({int(np.isfinite(data.values).sum())} colonies)…"

    def draw(self, figure, result, style):
        import matplotlib.pyplot as plt

        from ...stats.subpopfig import plot_subpopulations
        fits = result["fits"]
        width = max(15.0, 0.62 * len(fits.levels.nominal_display) * len(fits.levels.ordinal))
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            drawn = plot_subpopulations(fits, figsize=(width, 7.5), dpi=100)
        plt.close(drawn.figure)                     # keep pyplot from holding every figure drawn
        result["drawn_notes"] = printed.getvalue()
        return drawn.figure

    def table(self, result):
        rows = []
        for entry in result["fits"].entries:
            for c in range(entry.n_components):
                rows.append({"index": entry.entry_id, "cluster": entry.nominal_display, "level": entry.ordinal_display,
                             "selected": entry.selected, "k": entry.k, "fit_status": entry.fit_status,
                             "subpopulation": c + 1, "median_um": float(entry.component_medians[c]),
                             "weight": float(entry.component_weights[c]), "p25_um": float(entry.component_p25[c]),
                             "p75_um": float(entry.component_p75[c]), "colonies": int(entry.component_n[c])})
        return rows

    def notes(self, result):
        return [(result["printed"] + result.get("drawn_notes", "")).strip()]


ANALYSES = [Subpopulations()]
