"""Subpopulations: a LogNormal mixture per index (subpopfig), clustered by one slot and ordered by another.

Fits are kept per index while Stats is open: an index's fit depends only on its colony radii,
so changing slots, colors or hidden levels reuses every fit and redraws at once. Only indices
not fit before are fit, in the background (needs_background); the busy message counts them.
A change that alters an index's colonies (leaving split colonies out of sizes) is a new fit,
kept beside the first. With one plate per group on, every used plate is drawn and the chosen
plate of each block and column is the bright one (a column whose group is empty has none);
otherwise subpopfig picks the plate closest to the median colony count. subpopfig draws its own figure; draw() returns it so the window shows
it in place of its own.
"""

from __future__ import annotations

import contextlib
import io

import numpy as np

from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot


class Subpopulations(Analysis):
    id = "subpopulations"
    name = "Mixture model"
    group = "Subpopulations"
    description = ("LogNormal mixture per index (subpopfig): the number of subpopulations with the lowest BIC, "
                   "up to four. Each column of circles is one index.")
    slots = (Slot("clusters", "Blocks", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level gets its own colored block along the bottom (for example Genotype)."),
             Slot("levels", "Columns", (ORDINAL, NOMINAL, REPLICATE),
                  description="Columns inside each block, joined by trajectory lines (for example Passage). "
                              "Every plate of a column is drawn in it."))
    background = True
    marks_selection = True                        # one plate per group: every used plate drawn, the chosen bright

    def __init__(self):
        self.fits: dict = {}                      # fit_key(radii) -> fit, for the Stats session

    def reset_cache(self) -> None:
        """Forget every fit (Stats opening)."""
        self.fits = {}

    def _entry_radii(self, data) -> list:
        """Each index's radii, in the order the fit sees them."""
        frame, _ = self.frame(data)
        return [group["radius_um"].to_numpy(dtype=float) for _, group in frame.groupby("entry", sort=False)]

    def missing(self, data) -> int:
        """Indices whose fit is not kept yet."""
        from ...stats.subpopfig import fit_key
        return sum(1 for radii in self._entry_radii(data) if fit_key(radii) not in self.fits)

    def needs_background(self, data) -> bool:
        return self.missing(data) > 0

    def frame(self, data):
        """One row per colony with the subpopfig roles. EntryID is the index, so one mixture is fit per index.
        Levels become their position (1, 2, ...), with the level text as display."""
        import pandas as pd
        clusters, levels = data.axes["clusters"], data.axes["levels"]
        c_pos, l_pos = data.positions["clusters"], data.positions["levels"]
        keep = (c_pos >= 0) & (l_pos >= 0) & np.isfinite(data.values) & (data.values > 0)
        frame = pd.DataFrame({
            "entry": [f"index {i}" for i in data.index_ids[keep]],
            "nominal": [clusters.labels[c] or "All" for c in c_pos[keep]],
            "ordinal": l_pos[keep] + 1,
            "ordinal_display": [levels.labels[o] or "All" for o in l_pos[keep]],
            "radius_um": data.values[keep],
            "nominal_order": c_pos[keep],
        })
        if data.selected is not None:                # one plate per group chose these; the rest are drawn faded
            frame["selected"] = [int(i) in data.selected for i in data.index_ids[keep]]
        frame = frame.sort_values(["nominal_order", "ordinal"], kind="stable")
        schema = {
            "EntryID": {"column": "entry", "label": "Index"},
            "Nominal": {"column": "nominal", "label": clusters.title or "All"},
            "Ordinal": {"column": "ordinal", "display_column": "ordinal_display", "label": levels.title or "All"},
            "Measurement": {"column": "radius_um", "label": "Radius (µm)"},
        }
        if data.selected is not None:
            schema["Selected"] = {"column": "selected"}
        return frame.drop(columns="nominal_order"), schema

    def compute(self, data, options):
        from ...stats.subpopfig import fit_mixtures, from_dataframe
        frame, schema = self.frame(data)
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            workbook = from_dataframe(frame, schema, source="QuantaColony project")
            fits = fit_mixtures(workbook, cache=self.fits)
        return {"fits": fits, "printed": printed.getvalue()}

    def busy_text(self, data) -> str:
        entries = len(set(data.index_ids[np.isfinite(data.values)].tolist()))
        missing = self.missing(data)
        kept = f"; {entries - missing} already fit" if missing < entries else ""
        return f"Fitting LogNormal mixtures to {missing} indices{kept}…"

    def draw(self, figure, result, style):
        import matplotlib.pyplot as plt

        from ...stats.subpopfig import plot_subpopulations
        from ...stats.subpopfig.figure import FigureText
        fits = result["fits"]
        width = max(15.0, 0.62 * len(fits.levels.nominal_display) * len(fits.levels.ordinal))
        printed = io.StringIO()
        with contextlib.redirect_stdout(printed):
            text = FigureText(title="Subpopulation Analysis Across Selected Plates", unit_header="Plates",
                              selected="Selected plate", other="Other plates")
            drawn = plot_subpopulations(fits, figsize=(width, 7.5), dpi=100, text=text)
        plt.close(drawn.figure)                     # keep pyplot from holding every figure drawn
        result["drawn_notes"] = printed.getvalue()
        return drawn.figure

    def table(self, result):
        rows = []
        for entry in result["fits"].entries:
            for c in range(entry.n_components):
                rows.append({"index": entry.entry_id, "cluster": entry.nominal_display, "level": entry.ordinal_display,
                             "selected": entry.selected, "k": entry.k, "fit_status": entry.fit_status,
                             "subpopulation": c + 1, "median_um": float(entry.component_medians[c]),
                             "weight": float(entry.component_weights[c]), "p25_um": float(entry.component_p25[c]),
                             "p75_um": float(entry.component_p75[c]), "colonies": int(entry.component_n[c])})
        return rows

    def notes(self, result):
        return [(result["printed"] + result.get("drawn_notes", "")).strip()]


ANALYSES = [Subpopulations()]
