"""Analyses that ship with QuantaColony."""
