"""Measurement fidelity: the uncertainty of each colony radius from ±0.5 px edge localization.

Always computed on raw pixel radii (0.5 / radius in px), never normalized.
A: histogram with five uncertainty zones. B: median uncertainty per row and column level.
C: the conclusion text.
"""

from __future__ import annotations

import math

import numpy as np
from matplotlib.colors import to_rgba
from matplotlib.patches import Rectangle

from ...core import stats as st
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot
from ..common import show_message


class MeasurementFidelity(Analysis):
    id = "fidelity"
    name = "Measurement fidelity"
    group = "Measurement quality"
    description = ("Measurement uncertainty of each colony from ±0.5 px edge localization (0.5 / radius in px). "
                   "Always computed on raw pixel radii.")
    slots = (Slot("rows", "Rows", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level gets its own row of panels."),
             Slot("columns", "Columns", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level gets its own column of panels."))

    def compute(self, data, options):
        rows_axis, columns_axis = data.axes["rows"], data.axes["columns"]
        placed = (data.positions["rows"] >= 0) & (data.positions["columns"] >= 0)
        valid = placed & np.isfinite(data.radius_px) & (data.radius_px > 0)
        uncertainty = 0.5 / data.radius_px[valid] * 100
        counts, _ = np.histogram(uncertainty, bins=np.asarray(st.ZONE_EDGES))
        total = int(counts.sum())
        pct = counts / total * 100 if total else np.zeros(len(counts))
        medians = np.full((len(rows_axis), len(columns_axis)), np.nan)
        grid_counts = np.zeros((len(rows_axis), len(columns_axis)), dtype=int)
        every = np.where(valid, 0.5 / np.where(valid, data.radius_px, 1) * 100, np.nan)
        for r in range(len(rows_axis)):
            for c in range(len(columns_axis)):
                cell = every[(data.positions["rows"] == r) & (data.positions["columns"] == c) & valid]
                grid_counts[r, c] = cell.size
                if cell.size:
                    medians[r, c] = float(np.median(cell))
        row_labels = tuple(label or "All" for label in rows_axis.labels)
        column_labels = tuple(label or "All" for label in columns_axis.labels)
        conclusion = st.fidelity_conclusion(counts, pct, total, medians, grid_counts, row_labels, column_labels)
        return {"uncertainty": uncertainty, "counts": counts, "pct": pct, "medians": medians,
                "grid_counts": grid_counts, "rows": row_labels, "columns": column_labels, "conclusion": conclusion,
                "indices": len(set(data.index_ids[valid].tolist()))}

    def draw(self, figure, result, style):
        figure.clear()
        figure.set_facecolor(style.background)
        if not len(result["uncertainty"]):
            show_message(figure, "No colonies with a measured radius yet.", style)
            return None
        ink, zone_colors = style.ink, style.zone_colors
        ax = figure.add_axes((0.07, 0.36, 0.40, 0.56))
        x_max = min(100.0, max(55.0, math.ceil(float(result["uncertainty"].max()) / 5) * 5))
        edges = np.arange(0, x_max + 0.5, 0.5)
        counts, _ = np.histogram(np.minimum(result["uncertainty"], x_max - 0.25), bins=edges)
        y_max = max(counts.max() * 1.25, 1)
        zone_edges = list(st.ZONE_EDGES[:-1]) + [x_max]
        for z in range(5):
            ax.add_patch(Rectangle((zone_edges[z], 0), zone_edges[z + 1] - zone_edges[z], y_max,
                                   color=zone_colors[z], alpha=0.25, linewidth=0))
            ax.text((zone_edges[z] + zone_edges[z + 1]) / 2, y_max * 0.97,
                    f"{result['counts'][z]}\n({result['pct'][z]:.1f}%)", ha="center", va="top", fontsize=8,
                    fontweight="bold", bbox={"facecolor": style.background, "edgecolor": style.panel_edge, "pad": 2.5})
        ax.bar(edges[:-1] + 0.25, counts, width=0.5, color=style.bar, alpha=0.7)
        for value, text in zip((5, 10, 25, 50), ("5% (10 px)", "10% (5 px)", "25% (2 px)", "50% (1 px)")):
            ax.axvline(value, color=style.bar, linestyle="--", linewidth=1.2)
            ax.text(value, y_max * 0.5, "  " + text, rotation=90, va="center", ha="left", fontsize=7.5,
                    fontweight="bold", color=style.bar,
                    bbox={"facecolor": style.background, "edgecolor": "none", "pad": 1})
        ax.set_xlim(0, x_max)
        ax.set_ylim(0, y_max)
        ax.set_xlabel("Measurement uncertainty (%)", color=ink)
        ax.set_ylabel("Colony count", color=ink)
        ax.set_title("A   Project-wide measurement fidelity", fontsize=11, fontweight="bold", color=ink, loc="left")
        ax.tick_params(labelsize=9)

        grid = figure.add_axes((0.62, 0.36, 0.36, 0.56))
        rows, columns = len(result["rows"]), len(result["columns"])
        for r in range(rows):
            for c in range(columns):
                value, count = result["medians"][r, c], result["grid_counts"][r, c]
                color = (to_rgba(zone_colors[st.zone_of(value)], 0.5) if np.isfinite(value)
                         else to_rgba(style.empty_cell))
                grid.add_patch(Rectangle((c, rows - r - 1), 1, 1, facecolor=color, edgecolor=style.spine,
                                         linewidth=0.8))
                text = f"{value:.1f}%\nn={count}" if np.isfinite(value) else "no data"
                grid.text(c + 0.5, rows - r - 0.5, text, ha="center", va="center",
                          fontsize=8 if rows * columns <= 40 else 6.5, color=ink)
        grid.set_xlim(0, columns)
        grid.set_ylim(0, rows)
        grid.set_xticks(np.arange(columns) + 0.5, result["columns"], fontsize=8)
        grid.set_yticks(np.arange(rows) + 0.5, list(reversed(result["rows"])), fontsize=8)
        grid.xaxis.tick_top()
        grid.tick_params(length=0)
        for spine in grid.spines.values():
            spine.set_visible(False)
        grid.set_title("B   Median uncertainty per group", fontsize=11, fontweight="bold", color=ink, loc="left",
                       pad=22)

        note = figure.add_axes((0.07, 0.03, 0.91, 0.22))
        note.set_xticks([])
        note.set_yticks([])
        for spine in note.spines.values():
            spine.set_color(style.panel_edge)
        note.text(0.015, 0.92, "C   Conclusion", fontsize=11, fontweight="bold", color=ink, va="top",
                  transform=note.transAxes)
        note.text(0.015, 0.70, "\n".join(result["conclusion"]), fontsize=9.5, color=ink, va="top", wrap=True,
                  transform=note.transAxes)
        return None

    def table(self, result):
        return [{"row": result["rows"][r], "column": result["columns"][c],
                 "colonies": int(result["grid_counts"][r, c]),
                 "median_uncertainty_pct": float(result["medians"][r, c])}
                for r in range(len(result["rows"])) for c in range(len(result["columns"]))]

    def notes(self, result):
        return [f"{len(result['uncertainty'])} colonies from {result['indices']} indices."]


ANALYSES = [MeasurementFidelity()]
