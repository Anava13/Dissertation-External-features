"""Distributions of colony size: density plots, box plots and violin plots.

Box and violin plots follow the MATLAB Plots module:
- x-axis levels sit at positions 1..n, colored by their group (or by "Color by");
- 'Together' draws every group on one axis, with two empty positions between groups and
  the group's name above it; 'Separate' gives each group its own axis;
- boxes use 1.5 x IQR whiskers with outliers drawn as points;
- each violin is a Gaussian kernel density scaled to its own maximum, 0.4 wide, with a median
  line and a white dot; a group with fewer than two values is drawn as a single point.
Violins use the same bandwidth as the density plots (Freedman-Diaconis, never below one pixel
at the group's scale, or 0.05 when normalized), so a violin and a density curve of the same
group agree.
"""

from __future__ import annotations

import numpy as np
from matplotlib.colors import to_rgba

from ...core import stats as st
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Option, Slot
from ..common import (group_bandwidth, grouped_statistics, level_ticks, panel_grid, show_message, statistics_rows,
                      style_axes)

GAP = 2                                           # empty positions between groups ('Together')
BOX_WIDTH = 0.6
VIOLIN_WIDTH = 0.4
VIEW = Option("view", "Layout", (("together", "Together"), ("separate", "Separate")), "together")


# ======================================================================================
# density plots
# ======================================================================================
class DensityPlots(Analysis):
    id = "density"
    name = "Density plots"
    group = "Distributions"
    description = ("Kernel density of colony size, one panel per panel level and one curve per curve level. "
                   "Bandwidth: Freedman-Diaconis, never below one pixel (raw) or 0.05 (normalized).")
    slots = (Slot("panels", "Panels", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level gets its own panel (for example Genotype)."),
             Slot("curves", "Curves", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level is its own curve inside every panel (for example Passage)."))
    normalize = ("panels", "curves")
    color_slots = ("panels", "curves")

    def title(self, data, options):
        across = f" across {data.axes['curves'].title}" if data.axes["curves"].title else ""
        return f"Colony size distribution{across}, {data.scheme_label}"

    def compute(self, data, options):
        return {"title": self.title(data, options), "stats": grouped_statistics(data, "panels", "curves")}

    def draw(self, figure, result, style):
        grouped = result["stats"]
        data = grouped.data
        figure.clear()
        panels = [p for p in range(len(data.axes["panels"]))
                  if any((g := grouped.groups.get((p, c))) is not None and g.density is not None
                         for c in range(len(data.axes["curves"])))]
        if not panels:
            show_message(figure, "No group has three or more colonies yet.", style)
            return None
        colors = style.step_colors(len(data.axes["curves"]))
        top = max(float(g.density.max()) for g in grouped.groups.values() if g.density is not None) * 1.08
        axes, columns, rows = panel_grid(figure, len(panels), sharex=True, sharey=True)
        for k, (ax, p) in enumerate(zip(axes, panels)):
            style_axes(ax, style)
            for c in range(len(data.axes["curves"])):
                group = grouped.groups.get((p, c))
                if group is None or group.density is None:
                    continue
                label = f"{group.second} (n={group.n})" if group.second else f"n={group.n}"
                color = style.color_for(data, panels=p, curves=c) or colors[c]
                ax.plot(grouped.grid, group.density, color=color, linewidth=1.8, label=label)
            ax.set_title(data.axes["panels"].labels[p] or "All colonies", fontsize=11, fontweight="bold",
                         color=style.ink)
            ax.set_ylim(0, top)
            ax.legend(fontsize=7.5, frameon=False, title=data.axes["curves"].title or None, title_fontsize=8)
            if k % columns == 0:
                ax.set_ylabel("Density", color=style.ink)
            if k // columns == rows - 1:
                ax.set_xlabel(data.value_label, color=style.ink)
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink)
        figure.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.6)
        return None

    def table(self, result):
        return statistics_rows(result["stats"])

    def notes(self, result):
        data = result["stats"].data
        return list(data.notes) + [f"{int(np.isfinite(data.values).sum())} colonies in "
                                   f"{len(result['stats'].groups)} groups."]


# ======================================================================================
# box and violin plots
# ======================================================================================
def box_numbers(values: np.ndarray) -> dict:
    """Quartiles, 1.5 x IQR whiskers (to the most extreme value inside them) and outliers."""
    q1, median, q3 = np.percentile(values, [25, 50, 75])
    iqr = q3 - q1
    inside = values[(values >= q1 - 1.5 * iqr) & (values <= q3 + 1.5 * iqr)]
    low, high = (float(inside.min()), float(inside.max())) if inside.size else (float(q1), float(q3))
    outliers = values[(values < low) | (values > high)]
    return {"n": int(values.size), "mean": float(np.mean(values)), "median": float(median), "q1": float(q1),
            "q3": float(q3), "whisker_low": low, "whisker_high": high, "outliers": outliers}


class _BoxOrViolin(Analysis):
    group = "Distributions"
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL, REPLICATE),
                  description="Each level is one position along the x axis (for example Passage)."),
             Slot("groups", "Groups", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level is its own colored shape at every x position (for example Genotype)."))
    options = (VIEW,)
    normalize = ("groups", "x")
    color_slots = ("groups", "x")
    kind = ""

    def title(self, data, options):
        across = f" across {data.axes['x'].title}" if data.axes["x"].title else ""
        return f"Colony size{across}, {data.scheme_label}"

    def compute(self, data, options):
        cells = {}
        for g in range(len(data.axes["groups"])):
            for x in range(len(data.axes["x"])):
                keep = data.select(groups=g, x=x)
                values = data.values[keep]
                if values.size == 0:
                    continue
                cell = box_numbers(values)
                cell["values"] = values
                if self.kind == "violin" and values.size >= 2:
                    h = group_bandwidth(data, keep)
                    low = values.min() - 3 * h
                    if data.scheme == "raw":
                        low = max(low, 0.0)
                    grid = np.linspace(low, values.max() + 3 * h, 160)
                    cell["grid"], cell["density"], cell["bandwidth"] = grid, st.kde(values, grid, h), h
                cells[(g, x)] = cell
        return {"title": self.title(data, options), "data": data, "cells": cells, "view": options.get("view")}

    def draw(self, figure, result, style):
        figure.clear()
        data, cells = result["data"], result["cells"]
        if not cells:
            show_message(figure, "No group has colonies yet.", style)
            return None
        groups = [g for g in range(len(data.axes["groups"])) if any(key[0] == g for key in cells)]
        n_x = len(data.axes["x"])
        if result["view"] == "separate" and len(groups) > 1:
            axes, columns, rows = panel_grid(figure, len(groups), sharey=True)
            for k, (ax, g) in enumerate(zip(axes, groups)):
                style_axes(ax, style)
                for x in range(n_x):
                    if (g, x) in cells:
                        self._draw_cell(ax, cells[(g, x)], x + 1, self._color(data, g, x, style), style)
                ax.set_xlim(0.4, n_x + 0.6)
                level_ticks(ax, list(data.axes["x"].labels), style)
                ax.set_title(data.axes["groups"].labels[g], fontsize=11, fontweight="bold", color=style.ink)
                if k % columns == 0:
                    ax.set_ylabel(data.value_label, color=style.ink)
                if k // columns == rows - 1 and data.axes["x"].title:
                    ax.set_xlabel(data.axes["x"].title, color=style.ink)
            figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink)
            figure.tight_layout(rect=(0, 0, 1, 0.95), h_pad=1.6)
            return None

        ax = figure.add_axes((0.07, 0.12, 0.9, 0.70))
        style_axes(ax, style)
        ticks, labels, centers = [], [], []
        position = 1
        for i, g in enumerate(groups):
            start = position
            for x in range(n_x):
                if (g, x) in cells:
                    self._draw_cell(ax, cells[(g, x)], position, self._color(data, g, x, style), style)
                ticks.append(position)
                labels.append(data.axes["x"].labels[x])
                position += 1
            centers.append(((start + position - 1) / 2, data.axes["groups"].labels[g]))
            if i < len(groups) - 1:
                position += GAP
        ax.set_xlim(0.4, position - 0.4)
        level_ticks(ax, labels, style, positions=np.array(ticks))
        top = ax.get_ylim()[1]
        stacked = any(len(label) > 2.2 * (n_x + GAP) for _, label in centers)   # too wide for its group: one level per line
        for center, label in centers:
            if label:
                ax.text(center, top, label.replace(" · ", "\n") if stacked else label, ha="center", va="bottom",
                        fontweight="bold", color=style.ink, fontsize=style.font_size, linespacing=1.1)
        ax.set_ylabel(data.value_label, color=style.ink)
        if data.axes["x"].title:
            ax.set_xlabel(data.axes["x"].title, color=style.ink)
        figure.suptitle(result["title"], fontsize=13, fontweight="bold", color=style.ink, x=0.07, y=0.98,
                        ha="left")
        return None

    @staticmethod
    def _color(data, g, x, style) -> str:
        return style.color_for(data, groups=g, x=x) or style.group_color(g)

    def _draw_cell(self, ax, cell, position, color, style):
        raise NotImplementedError

    def table(self, result):
        data = result["data"]
        group_title = data.axes["groups"].title or "Group"
        x_title = data.axes["x"].title or "X"
        rows = []
        for (g, x), cell in sorted(result["cells"].items()):
            row = {group_title: data.axes["groups"].labels[g], x_title: data.axes["x"].labels[x]}
            row.update({k: v for k, v in cell.items() if k not in ("values", "grid", "density", "outliers")})
            row["outliers"] = int(cell["outliers"].size)
            rows.append(row)
        return rows

    def notes(self, result):
        data = result["data"]
        return list(data.notes) + [f"{int(np.isfinite(data.values).sum())} colonies in {len(result['cells'])} groups."]


class BoxPlots(_BoxOrViolin):
    id = "box"
    name = "Box plots"
    kind = "box"
    description = ("Median, quartiles and 1.5 × IQR whiskers of colony size for every x-axis level and "
                   "group. Points beyond the whiskers are drawn as outliers.")

    def _draw_cell(self, ax, cell, position, color, style):
        stats = [{"med": cell["median"], "q1": cell["q1"], "q3": cell["q3"], "whislo": cell["whisker_low"],
                  "whishi": cell["whisker_high"], "fliers": cell["outliers"], "mean": cell["mean"]}]
        ax.bxp(stats, positions=[position], widths=BOX_WIDTH, patch_artist=True, showfliers=True,
               boxprops={"facecolor": to_rgba(color, 0.7), "edgecolor": color, "linewidth": 1.2},
               whiskerprops={"color": color, "linewidth": 1.2}, capprops={"color": color, "linewidth": 1.2},
               medianprops={"color": style.ink, "linewidth": 2},
               flierprops={"marker": "o", "markersize": 4, "markerfacecolor": color, "markeredgecolor": color,
                           "alpha": 0.8})
        ax.scatter([position], [cell["median"]], s=22, color=style.marker_fill, edgecolor=color, linewidth=1.4, zorder=4)


class ViolinPlots(_BoxOrViolin):
    id = "violin"
    name = "Violin plots"
    kind = "violin"
    description = ("Kernel density of colony size for every x-axis level and group, drawn as a violin with "
                   "its median. Bandwidth matches the density plots.")

    def _draw_cell(self, ax, cell, position, color, style):
        if "density" not in cell:                                   # fewer than two values: one point
            ax.scatter([position], [cell["values"][0]], s=50, color=color, edgecolor=style.ink, zorder=3)
            return
        half = cell["density"] / cell["density"].max() * (VIOLIN_WIDTH / 2)
        ax.fill_betweenx(cell["grid"], position - half, position + half, facecolor=to_rgba(color, 0.7),
                         edgecolor=style.ink, linewidth=1)
        ax.plot([position - VIOLIN_WIDTH / 2, position + VIOLIN_WIDTH / 2], [cell["median"]] * 2, color=color,
                linewidth=2)
        ax.scatter([position], [cell["median"]], s=25, color=style.marker_fill, edgecolor=color, linewidth=1.5, zorder=4)


ANALYSES = [DensityPlots(), BoxPlots(), ViolinPlots()]
