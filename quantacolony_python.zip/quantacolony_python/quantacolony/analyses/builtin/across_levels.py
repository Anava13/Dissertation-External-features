"""A summary statistic of colony size across ordered levels: one line per line level."""

from __future__ import annotations

import numpy as np

from ...core.stats import LINE_STATISTICS
from ..api import NOMINAL, ORDINAL, REPLICATE, Analysis, Slot
from ..common import grouped_statistics, level_ticks, show_message, statistics_rows, style_axes

LABELS = {"Mean": "Mean", "Median": "Median", "Standard Deviation": "Standard deviation",
          "Coefficient Of Variation": "Coefficient of variation", "Skew": "Skew", "Kurtosis": "Kurtosis",
          "Peak Location": "Peak location", "Peak Density": "Peak density"}
Y_LABELS = {"Mean": "Mean colony size", "Median": "Median colony size",
            "Coefficient Of Variation": "Coefficient of variation (dimensionless)",
            "Skew": "Distribution skewness", "Kurtosis": "Distribution kurtosis (excess)",
            "Peak Location": "Peak colony size", "Standard Deviation": "Standard deviation",
            "Peak Density": "Maximum density"}
WITH_UNITS = ("Mean", "Median", "Peak Location", "Standard Deviation")


class LineStatistic(Analysis):
    group = "Across ordinal levels"
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL), min_variables=1,
                  description="Each level is one point along the x axis (for example Passage)."),
             Slot("lines", "Lines", (NOMINAL, REPLICATE, ORDINAL),
                  description="Each level is its own colored line (for example Genotype)."))
    normalize = ("lines", "x")
    color_slots = ("lines",)

    def __init__(self, statistic: str):
        self.statistic = statistic
        self.id = f"line:{statistic}"
        self.name = LABELS[statistic]
        self.description = (f"{LABELS[statistic]} of colony size for every line level across the x-axis levels. "
                            "Every colony of a group is pooled.")

    def title(self, data, options):
        return f"{LABELS[self.statistic]} across {data.axes['x'].title}, {data.scheme_label}"

    def compute(self, data, options):
        return {"title": self.title(data, options), "stats": grouped_statistics(data, "lines", "x")}

    def draw(self, figure, result, style):
        grouped = result["stats"]
        data = grouped.data
        figure.clear()
        ax = figure.add_axes((0.08, 0.12, 0.66, 0.78))
        style_axes(ax, style)
        n_x = len(data.axes["x"])
        steps = np.arange(1, n_x + 1)
        drawn = 0
        for line in range(len(data.axes["lines"])):
            values = np.array([grouped.groups[(line, x)].values.get(self.statistic, np.nan)
                               if (line, x) in grouped.groups else np.nan for x in range(n_x)])
            if np.all(np.isnan(values)):
                continue
            ax.plot(steps, values, marker="o", markersize=6, linewidth=2, color=style.color_for(data, lines=line) or style.group_color(line),
                    label=data.axes["lines"].labels[line] or "All colonies")
            drawn += 1
        if not drawn:
            show_message(figure, "No group has colonies yet.", style)
            return None
        level_ticks(ax, list(data.axes["x"].labels), style)
        ax.set_xlim(0.5, n_x + 0.5)
        ax.set_xlabel(data.axes["x"].title, color=style.ink)
        ylabel = Y_LABELS[self.statistic]
        if self.statistic in WITH_UNITS:
            ylabel += " (µm)" if data.scheme == "raw" else " (normalized)"
        ax.set_ylabel(ylabel, color=style.ink)
        ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=data.axes["lines"].title or None, title_fontsize=9)
        ax.set_title(result["title"], fontsize=13, fontweight="bold", color=style.ink, loc="left")
        return None

    def table(self, result):
        return statistics_rows(result["stats"])

    def notes(self, result):
        data = result["stats"].data
        return list(data.notes) + [f"{int(np.isfinite(data.values).sum())} colonies in "
                                   f"{len(result['stats'].groups)} groups."]


ANALYSES = [LineStatistic(name) for name in LINE_STATISTICS]
