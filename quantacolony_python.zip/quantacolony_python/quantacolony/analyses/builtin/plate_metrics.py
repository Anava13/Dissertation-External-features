"""Plate metrics: one value per index (colony count, coverage, ...), compared across levels.

Each index is one point; the bar marks the mean of its group and the whiskers ±1 standard
deviation. Color groups sit side by side at each x-axis level.
"""

from __future__ import annotations

import numpy as np

from ..api import INDEX, NOMINAL, ORDINAL, REPLICATE, Analysis, Slot
from ..common import level_ticks, show_message, style_axes

SPREAD = 0.7                                      # width of one x-axis level taken by its color groups


class PlateMetrics(Analysis):
    id = "plate_metrics"
    name = "Plate metrics"
    group = "Plates"
    unit = INDEX
    description = ("One value per index: colony count, growth coverage, colony coverage, capture ratio or mean "
                   "colony radius. Points are indices; bars show the group mean ± 1 SD.")
    slots = (Slot("x", "X axis", (ORDINAL, NOMINAL, REPLICATE)),
             Slot("groups", "Color groups", (NOMINAL, REPLICATE, ORDINAL)))
    normalize = ("groups", "x")

    def title(self, data, options):
        across = f" across {data.axes['x'].title}" if data.axes["x"].title else ""
        return f"{data.value_label.split(' (')[0]}{across}, {data.scheme_label}"

    def compute(self, data, options):
        cells = {}
        for g in range(len(data.axes["groups"])):
            for x in range(len(data.axes["x"])):
                keep = data.select(groups=g, x=x)
                values = data.values[keep]
                if values.size:
                    cells[(g, x)] = {"values": values, "index_ids": data.index_ids[keep], "n": int(values.size),
                                     "mean": float(np.mean(values)),
                                     "sd": float(np.std(values, ddof=1)) if values.size > 1 else 0.0}
        return {"title": self.title(data, options), "data": data, "cells": cells}

    def draw(self, figure, result, style):
        figure.clear()
        data, cells = result["data"], result["cells"]
        if not cells:
            show_message(figure, "No index has this measurement yet.", style)
            return None
        ax = figure.add_axes((0.08, 0.14, 0.68, 0.76))
        style_axes(ax, style)
        n_groups = len(data.axes["groups"])
        step = SPREAD / n_groups
        rng = np.random.default_rng(0)                            # fixed jitter: the figure redraws identically
        drawn = set()
        for (g, x), cell in sorted(cells.items()):
            center = x + 1 + (g - (n_groups - 1) / 2) * step
            color = style.group_color(g)
            label = (data.axes["groups"].labels[g] or "All indices") if g not in drawn else None
            drawn.add(g)
            ax.bar(center, cell["mean"], width=step * 0.8, color=color, alpha=0.25, edgecolor=color, label=label)
            ax.errorbar(center, cell["mean"], yerr=cell["sd"], color=color, capsize=3, linewidth=1.2)
            jitter = rng.uniform(-step * 0.25, step * 0.25, cell["n"])
            ax.scatter(center + jitter, cell["values"], s=18, color=color, edgecolor=style.ink, linewidth=0.4,
                       zorder=3)
        level_ticks(ax, list(data.axes["x"].labels), style)
        ax.set_xlim(0.4, len(data.axes["x"]) + 0.6)
        ax.set_ylabel(data.value_label, color=style.ink)
        if data.axes["x"].title:
            ax.set_xlabel(data.axes["x"].title, color=style.ink)
        ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), frameon=False, fontsize=9,
                  title=data.axes["groups"].title or None, title_fontsize=9)
        ax.set_title(result["title"], fontsize=13, fontweight="bold", color=style.ink, loc="left")
        return None

    def table(self, result):
        data = result["data"]
        group_title, x_title = data.axes["groups"].title or "Group", data.axes["x"].title or "X"
        return [{group_title: data.axes["groups"].labels[g], x_title: data.axes["x"].labels[x], "indices": cell["n"],
                 "mean": cell["mean"], "sd": cell["sd"],
                 "values": " ".join(f"{v:.4g}" for v in cell["values"])}
                for (g, x), cell in sorted(result["cells"].items())]

    def notes(self, result):
        data = result["data"]
        return list(data.notes) + [f"{int(np.isfinite(data.values).sum())} indices with this measurement."]


ANALYSES = [PlateMetrics()]
