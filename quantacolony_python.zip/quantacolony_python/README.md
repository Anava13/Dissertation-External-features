# QuantaColony (Python)

The home page lists the projects in the library. Each project has a project
page (the MATLAB Hub) that opens Cropping, Colony Detection and Stats. The
DataManager holds each project (one `.qcproj` file) and is the only part of the
program that reads or writes files. The sample project holds the rif1Δ, cdc13-2
(Figure 2) crop at ordinal 25 from the Anbalagan2011 project.

## Run it (Windows)

1. Install `uv`, which installs Python and the libraries for you. In PowerShell:

   ```
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

   Close and reopen PowerShell afterwards.

2. In this folder, run:

   ```
   uv run quantacolony
   ```

   The first run downloads Python and the libraries (a few minutes). Later runs start in seconds.
   The first start asks where to keep the project library (default
   `%LOCALAPPDATA%\QuantaColony\Library`) and creates the sample project in it. Every start shows
   the home page. To import a shared project: `uv run quantacolony "D:\Shared\X.qcproj"`.
   Demos on 12 synthetic plates: `uv run quantacolony --demo-cropping` (nothing cropped yet) and
   `uv run quantacolony --demo-stats` (cropped and detected; the first start takes about 15 s).

3. Run the tests: `uv run pytest`

### Start without a terminal

Double-click `Create desktop shortcut.bat` in this folder once. It puts a
QuantaColony icon on the Desktop and in the Start menu. The icon starts the
program with no console window, and results go to this folder's `output`.
It also gives `.qcproj` files the QuantaColony icon: double-clicking one opens it
(a project from the library opens; any other is imported). This is set for the
current user only and needs no administrator rights.
(The same step from PowerShell: `uv run quantacolony-shortcut`.)
Run it again if you move the program folder.

## Home page and project page

**Home page.** Every project in the library with a progress bar (detected, needs review,
still to do, out of every combination of levels), its colony count, last change and size.
Selecting a project shows its summary on the right: a thumbnail of its first photo, photos,
variables, indices cropped and colonies counted. Open (or double-click) shows the project
page. Import project copies a shared `.qcproj` into the library. Export offers two choices:
a project file to share, or a browsable folder (see Exporting). Backups restores one of the
five latest snapshots; Move library moves the whole library. New project opens the wizard.

**New project wizard.** Five steps with a summary of the indices on the right:

1. Photos: project name (a name already in the library is refused, with a free one
   offered), the plate photos in order (move, remove, sort by the numbers in the file names).
2. Plate: round dish with 1 to 8 sections (numbered clockwise from the top), or a
   rectangular grid of up to 8 × 8.
3. Variables: name, kind (nominal, ordinal, replicate), levels and the control level. The
   name box takes any name; its list suggests names (Genotype, Medium, Generations, ...)
   that also fill in example levels and units. Levels you typed are never replaced.
   Ordinal levels must be numbers; ordinal variables take units.
4. Scale: dish size (90 mm, 140 mm or any size), plate size, scale bar, or none.
5. Review: every choice with an Edit link. Create project writes the `.qcproj` file, copies
   the photos into it, and opens Cropping.

Nothing is written before Create project.

**Project page.** Summary numbers (photos, indices cropped, indices detected, to review,
colonies counted), the variables with their control levels, and one row per step with a
progress bar:

| Step | Status shown | Opens when |
|---|---|---|
| Cropping | photos cropped, indices without a region | the project has photos |
| Colony Detection | indices detected, indices to review | some index has a region |
| Stats | indices with colonies | some index is detected |

Counts come from the project file, so a step shows progress again when photos are added
later. Closing a module returns to the project page; closing the home page or the project
page quits.

## Stats

Every analysis is a plug-in (`quantacolony/analyses`). Each declares the variable
dimensions it plots (its slots), which variable kinds each slot accepts and how many
variables it takes. Stats builds its controls from that: every variable goes into one slot
or is pooled, and a variable whose kind a slot does not accept cannot be put there. Two or
more variables in one slot combine into one level per combination. Choices are saved with
the project, per analysis.

| Analysis | Slots | Notes |
|---|---|---|
| Density plots | Panels, Curves | Gaussian KDE; Freedman-Diaconis bandwidth, never below one pixel at the group's own scale (raw) or 0.05 (normalized) |
| Box plots | X axis, Color groups | 1.5 × IQR whiskers, outliers as points; Together (groups side by side, two empty positions between them) or Separate (one axis per group) |
| Violin plots | X axis, Color groups | Same layouts; each violin is a KDE scaled to its own maximum, 0.4 wide, with its median; same bandwidth as the density plots |
| Mean, Median, ... Peak density | X axis (ordinal or nominal), Lines | One statistic across the x-axis levels |
| Measurement fidelity | Rows, Columns | 0.5 px / radius px per colony, five zones, median per group, conclusion; always raw pixel radii |
| Mixture model | Clusters, Levels | subpopfig, one fit per index; runs in the background and is kept while Stats is open |
| Plate metrics | X axis, Color groups | One value per index: colonies counted, mean radius, growth coverage, colony coverage or capture ratio |

- **Normalization** (analyses that declare it): Raw data; Control (groups slot): each value
  divided by the mean of the control group level at the same x-axis level; Control (x-axis
  slot): each value divided by the mean of its own group at the control x-axis level. A
  variable with no control level marked uses its first level, and the notes say so.
- **Growth coverage in Plate metrics:** indices are measured once (see Growth coverage) and
  kept. The first time a coverage measure is chosen, indices not measured yet are measured
  with a progress dialog that can be stopped.

Save figure writes PNG, PDF or SVG; Save table writes the numbers behind the figure as CSV.

### Writing your own analysis

Put a `.py` file in the library's `Analyses` folder (the "Analyses folder…" button in Stats
opens it). Stats loads every file there when it opens. A file defines `ANALYSES`, a list of
analysis objects; `example_analysis.py.txt` in that folder is a working example (rename it
to `.py`). The contract is in `quantacolony/analyses/api.py`:

- declare `id`, `name`, `group`, `description`, `unit` (`"colony"` or `"index"`), `slots`
  (`Slot(key, title, kinds, min_variables, max_variables)`), `options` and `normalize`;
- `compute(data, options)` receives an `AnalysisData`: the levels of every slot, each row's
  position on them, and the (normalized) values. It returns any result;
- `draw(figure, result, style)` draws on the matplotlib figure Stats provides, with the
  colors and fonts in `style` (from the theme); it may return a new figure instead;
- `table(result)` returns the rows Save table writes.

A file that fails to load, or an analysis that breaks the contract, is listed in the notes and
skipped. Loading a file runs its code, so only add files you trust.

## Colony Detection

**Moving between indices.** Click the image name in the top bar for the index board, the
same board as in Cropping: one cell per index, with Rows / Columns / Pages for each variable
(saved with the project). Cells show detected, not detected yet, to review, and no region;
the open index has a white outline. Click a cell to open it. The arrows (or Page Up / Page
Down) step through the indices in level order, last variable fastest. Leaving an index with
edits that are not saved asks Save / Discard changes / Cancel, and so does closing the window.
Finish image saves, then opens the next index that is not detected yet or needs review.

Detection is two steps (keys 1 to 5). Step 1, automatic detection:

| Mode | What to do |
|---|---|
| 1 Detect automatically | Colony shape (Irregular / Circular), colony color (Dark / Light), brightness threshold, sensitivity, radius (arrows or typing) and largest object rerun detection on the whole image. Estimate settings sets the color, threshold and radius range from the image |

Step 2, manual correction:

| Mode | What to do |
|---|---|
| 2 Delete colonies | Click colonies (click again to deselect), then Delete |
| 3 Delete a region | Drag a box, then Delete |
| 4 Add colonies | Press on one edge of a colony and drag to the opposite edge; the drag is the diameter, and a readout shows the radius. Drag inside a circle to move it, drag its edge to resize it, right-click it to remove it. "Snap to colony edge" fits each circle to the colony inside it. Then Add |
| 5 Detect in a region | Drag a box; the settings then apply inside the box only; then Add |

Undo and Redo work for every edit, including setting changes (Ctrl+Z / Ctrl+Y).
Scroll to zoom toward the pointer; middle-drag, Space + drag or the hand button pans;
double-click or the fit button shows the whole plate. Esc clears a selection,
a deletion box or a detection region. `[` collapses the left column to a rail of
mode icons and `]` hides the right column (also the two buttons in the top bar).

The left column shows only the controls that apply at the moment: for example,
Detect in a region shows its settings once a box is drawn, and the Delete and Add
buttons appear once something is selected or drawn.
**Starting settings.** A new index starts from the settings of the last image finished in the
project. In a project made with the wizard, the first image estimates its settings instead.
Colonies drawn in Add colonies are added as drawn, even where they overlap others; Detect in a
region skips candidates that duplicate existing colonies.

**Growth.** The summary card shows growth coverage; Show tints every pixel found as growth
(amber outside the marked colonies). See Growth coverage.

"Finish image" sends the result to the DataManager, which saves it in the project file
and exports `Documents\QuantaColony Exports\<project>\<index>_colonies.csv`. Reopening the project opens the saved
result. Edits before a Finish can no longer be undone afterwards; the next Finish saves a new
revision. Finish image then opens the next index not detected yet or needing review; when
none is left, it offers Stats or the project page.

The Activity panel records detections, edits, undo and saves; brief feedback
appears in the status bar.

## Look and fonts

Everything the interface draws ships inside the package: line icons are drawn
from code (`theme/icons.py`), and the fonts are Inter and Raleway
(`quantacolony/assets/fonts`, SIL Open Font License). Colors, sizes and fonts
are defined once in `theme/tokens.py`, including the colors of Stats figures (`PlotColors`,
handed to every analysis). The two brand colors come from the logo: lime `#7BF501` (accent,
added colonies) and teal `#2EC8BB` (automatic detections).

**Changing the front end.** All interface code is in `gui/` and `theme/`; `core/`, `data/`,
`analyses/` (except drawing on the figure it is given) and `stats/` import no Qt. Every
window declares the signals its controller listens to (for example `finishRequested`,
`settingEdited`) and the `set_`/`show_`/`ask_` methods the controller calls; controllers use
nothing else. A window can be redesigned freely as long as it keeps those names and meanings.
Colors live only in `theme/tokens.py`.

The logo lives in `quantacolony/assets/logo`: `logo.svg` (full mark),
`favicon.svg` (simplified for 16 to 32 px), PNG copies, and `quantacolony.ico`
for the window, taskbar and shortcut.

## Project data (DataManager)

One project is one file (an SQLite database) in the project library. The DataManager keeps it
as the only source of truth: modules ask it for data and send results back, and it alone touches
files.

The DataManager is the front door to private helpers in `data/store/`, one per area of the
file (project file, structure, photos and regions, detections, derived cache, projects as
files). Only the DataManager creates helpers and hands them the one open file; helpers never
call each other, and every action that touches several areas runs inside one transaction in
a DataManager method. Saving a cached calculation does not count as a change, so a session
spent looking at results leaves no backup.

### The project library

```
%LOCALAPPDATA%\QuantaColony\settings.json     pointer: library path and id, last project
<library>\library.json                         marker: library id
<library>\Projects\<project id>.qcproj         one file per project, named by id
<library>\Projects\<project id>.lock           held while the project is open
<library>\Backups\<project id>\<time>.qcproj   snapshots, newest 5 kept
<library>\Analyses\*.py                       analysis plug-ins for Stats
```

- **Choosing it:** the first start asks for the library folder. Network drives and folders inside
  OneDrive, Dropbox or Google Drive are refused, because they can damage open SQLite files.
- **Finding it:** settings.json sits where Windows reports local application data, so it is always
  found. If the library is not at its stored path, QuantaColony tries the same path on every other
  drive letter, then asks to locate it (checking the marker's id) or create a new one.
- **Moving it:** `DataManager.move_library` copies the library, verifies every project, then removes
  the old folder and updates settings. Projects hold their own photos, so a library moved intact
  never breaks a project.
- **Sharing:** `export_project_file` writes a consistent copy anywhere outside the library;
  `import_project_file` (or a `.qcproj` on the command line) copies a shared project in.
- **Backups:** closing a project that changed leaves a snapshot; `restore_backup` brings one back
  and first snapshots the state it replaces.
- **One window per project:** an operating-system lock, released automatically if the program crashes.

| Table | Holds |
|---|---|
| `project` | Name, schema version, detection defaults, plate settings |
| `variables`, `levels` | Variables (nominal, ordinal, replicate) and their values, as rows |
| `indices`, `index_levels` | Each multivariable index: one level per variable |
| `photos` | Plate photos exactly as uploaded, with scale, size and a thumbnail |
| `assignments` | Cropping's region for each index (shape parameters and outline) |
| `detection` | Committed parameters, revision, detection version, review flag |
| `colonies` | Colonies of the final result and the baseline, in photo pixels |
| `edit_log` | Every committed edit, in order |
| `derived_cache` | Derived results, used only while their fingerprint matches |

The file stores photos and decisions only. Crops, masks, measurements, growth coverage and
exports are computed on request. Saves are SQLite transactions: a crash during a save leaves
the last committed state. Files from older versions are upgraded when opened.

### Exporting

- **Project file (.qcproj):** one file for someone who has QuantaColony.
- **Browsable folder:** a read-only copy anyone can look through: `index.html` (what the
  folder holds, the variables, every index with its crop and links), `photos/`,
  `indices/<index>/` (`crop.png`, `colonies.png` with every colony drawn, `growth.png`,
  `colonies.csv`), `summary.csv` (one row per index, with coverage) and `project.json`.
  QuantaColony never reads it back.

## Growth coverage

`core/growth.py` decides which pixels of an index are yeast growth, learning from the
colonies marked in Colony Detection. Each plate teaches its own classifier:

1. **Growable area:** the index's region from Cropping, less a 2 px band along its edge.
2. **Lighting:** a smooth agar surface is estimated from pixels away from every colony; each
   pixel becomes its difference from the local agar, in units of the agar's noise, per CIE
   Lab channel.
3. **Labels from the plate:** pixels inside marked colonies are growth; pixels away from
   colonies that sit within the agar's noise are agar.
4. **Classifier:** a class-balanced logistic regression on the corrected color, a smoothed
   copy and local texture gives each pixel a probability of growth.
5. **Clean-up:** weak pixels are kept only where they connect to confident ones or to a
   marked colony; regions with no part as thick as a small colony (dish rim, scratches,
   streak marks) are dropped. Marked colonies are always growth.

Steps 2 to 4 run twice, so growth found in the first pass does not lift the agar surface. A
plate with no marked colony falls back to an unsupervised rule and is flagged.

| Measure | Definition |
|---|---|
| Growth coverage | growth pixels / growable pixels |
| Colony coverage | pixels inside the union of marked colonies / growable pixels (overlaps count once) |
| Capture ratio | colony coverage / growth coverage |

Coverage is a cached derived result (`plate_coverage`): measured when an image is finished,
and again only when its colonies, crop region or the method's version change.

**Check:** `held_out_check` leaves a third of the marked colonies out of the labels in turn
and reports the share of their pixels found as growth. On the bundled image and the demo
plates it finds 98–100% of the held-out colony pixels (a Python port of the earlier MATLAB
growth mask found 0–56% on the same images), in about 0.25 s per index.

## Cropping

A project opens in Cropping while any photo has no regions yet, otherwise in Colony Detection.

- **Plate.** Round dish: drag the center to move it, the square on the rim to resize it, the
  large handle to rotate every cut, a small handle to move one cut; right-click a cut handle to
  remove it. `−` / `+` remove or add a cut; Fit dish finds the dish edge again. Rectangular
  plate: center, corners (resize about the center), round handle (rotate); `−` / `+` change
  the number of columns.
- **Levels.** Each variable is set either for the whole photo or per section; the link under
  its name moves it to the other group (saved with the project). Click a section to select it.
  Number keys 1-9 pick a level of the first per-section variable and move to the next section.
- **Proposals.** A new photo starts from the previous photo's layout (dish refitted) with the
  whole-photo levels stepped like an odometer, last variable fastest. Proposed labels are dashed.
- **Duplicates.** An index used twice on a photo, or already on another photo, turns red and
  blocks saving; "Open it" / "Show it" goes to the other one. "Leave section unused" skips a section.
- **Done with photo** (Enter) commits the layout and every region to the project in one
  transaction, then opens the next photo without regions.
- **Indices board.** One cell per index; each variable can go on rows, columns or pages (view
  only). With more than 16 columns the last column variable is counted inside each cell.
  Click a cell to open its photo and section.
- **Finish cropping** lists indices that no photo holds (and unsaved changes) before it opens
  Colony Detection; "Go back" returns to Cropping.

## Layout

```
quantacolony/
  core/            model: no Qt imports; runs in scripts and tests
    params.py        DetectionParams and spinner limits
    colony_set.py    ColonySet: immutable colony table with ids
    detection.py     prepare_image, detect_irregular_colonies, detect_circular_colonies, remove_overlaps
    commands.py      edits as commands (before/after snapshots) for undo and redo
    session.py       DetectionSession: one image, its colonies, its history
    messages.py      notifyuser message texts
    measurements.py  per-colony measurements
    autoparams.py    starting detection settings estimated from the image
    growth.py        growth mask, coverage and the held-out check
    contour.py       contour_circle: fit a colony outline inside a drawn circle
    drawing.py       DrawnCircle: drawn circles before they are added
    record.py        what Colony Detection receives from and sends to the DataManager
    cropping.py      Cropping model: dish and grid layouts, proposals, duplicates, index board
    stats.py         colony and index tables; bandwidth, KDE, summary statistics, fidelity zones
    new_project.py   New Project model: the draft, its checks, the specifications to create from
  analyses/        Stats analyses as plug-ins (Qt-free except drawing on the figure given)
    api.py           the contract: Slot, Option, AnalysisData, PlotStyle, Analysis
    data.py          slot assignment, normalization, building AnalysisData
    registry.py      loads built-in analyses and the library's Analyses folder
    common.py        shared per-group statistics and figure styling
    builtin/         distributions (density, box, violin), across_levels, fidelity,
                     subpopulations, plate_metrics
  data/            DataManager: the only code that reads or writes files
    manager.py       DataManager: the front door; packets, commits, derived results, exports
    store/           private helpers: project_file, structure, photos, detections,
                     derived_cache, catalog (list, copy in and out, backups)
    schema.py        the tables of a .qcproj file
    packets.py       values exchanged with modules
    regions.py       crop regions: rectangle, sector, polygon; crop and mask
    derived.py       derived results (colony measurements, plate coverage), versions, fingerprints
    exports.py       CSV, PNG, JSON and HTML writers (atomic): colony and growth overlays, index.html
    codec.py         arrays and parameters to and from stored values
    library.py       project library: marker, finding a moved library, location checks, move, lock
    settings.py      settings.json: library pointer, last and recent projects
    sample_project.py, sample/   builds the sample project from the bundled image
    demo_project.py  synthetic 12-photo, 4-variable project for Cropping
  theme/           program-wide look
    tokens.py        colors (screens and Stats figures), fonts, sizes: the only place colors live
    stylesheet.py    Qt style sheet built from the tokens
    icons.py         line icons drawn from SVG path data
    assets.py        loads the bundled fonts
  stats/subpopfig/ the subpopfig package (mixture fits and the subpopulation figure), unchanged
  gui/             view and controller
    navigator.py     which screen is open; module close returns to the project page
    home.py          home page: project list, import, export, backups, move library
    new_project.py   New Project wizard (view and controller)
    project_page.py  project page: variables and the state of each step
    launch.py        builds each module's window and controller
    index_board.py   the index board shared by Cropping and Colony Detection
    light.py         shared pieces of the light screens
    stats_window.py, stats_controller.py   the Stats module (runs any analysis plug-in)
    help.py          help window: one HTML page per screen (assets/help)
    main_window.py   ColonyDetectionWindow (view)
    widgets.py       mode buttons, switch, slider rows, activity feed
    canvas.py        DetectCanvas: image and colony overlays (view)
    tools.py         the four mouse tools
    modes.py         interaction modes and their instructions
    controller.py    ColonyDetectionController
    library_setup.py first-start and missing-library screens (light palette)
    cropping_window.py   CroppingWindow and the index board (view)
    cropping_canvas.py   CropCanvas and PlateTool: layout drawing and handles
    cropping_controller.py  CroppingController: drafts, proposals, commits, finish warning
  app.py           start: library, home page, demos; build() opens one module directly (tests)
  shortcut.py      creates the Desktop and Start menu shortcuts (Windows)
  assets/logo/     logo SVGs, PNGs and the .ico
  assets/help/     help pages (HTML)
tests/
  test_core.py     detection matches MATLAB; undo/redo; overlap filtering
  test_gui.py      drives every tool through the real controller; finish and reopen
  test_data_manager.py  project file, commits, cache, regions, exports
  test_library.py  library pointer and marker, moves, locks, sharing, backups
  test_cropping.py Cropping on the demo project: commit, proposal, duplicates, finish warning
  test_stats.py    analyses and their data, plug-in loading, Stats on the detected demo, navigation
  test_improvements.py  detection settings, overlaps, end-of-detection prompt, help, home and
                   project pages, growth coverage
  test_new_project.py  wizard checks, specifications, creating a project
  test_detection_navigation.py  index board, arrows, unsaved edits, Finish image moves on
```

## Known differences from MATLAB

- Irregular detection reproduces MATLAB exactly on this image (33 colonies, same
  positions and radii). Coordinates are 0-based; messages show 1-based values, as MATLAB did.
- Circular detection uses scikit-image's Hough transform. MATLAB's `imfindcircles`
  uses a different algorithm, so counts differ; higher sensitivity still finds more circles.
- Results are saved per index in the project file; MATLAB kept FinalParams in the
  DataManager state file and in FinalParams_*.mat.
- The baseline (InitialState) follows the latest whole-image detection, as in MATLAB, and
  undo restores the previous one.
- Parameter changes are undoable. In MATLAB they reset manual edits with no way back.
- Add colonies draws any number of circles directly; there is no "Add Another Circle" step.
- Mode names changed: Modify Global Parameters → Detect automatically, Delete Individual
  Colonies → Delete colonies, Delete Many Colonies → Delete a region, Add Individual
  Colonies → Add colonies, Add Many Colonies → Detect in a region; I'm Satisfied → Finish image.

## Contour

Contour splits the pixels inside a drawn circle into two brightness classes
(Otsu's method), keeps the class at the circle's center (so bright or dark
colonies both work), and traces the connected region under the center.
The colony is added with that outline; its radius comes from the outline's area.

- On the bundled image it contours all 33 detected colonies and rejects 80 of 80
  empty-agar circles. The cutoff (`MIN_CONTRAST` in `core/contour.py`) was set on
  this one image; low-contrast plates may need a lower value.
- Contoured radii are about 12% smaller than automatic irregular detection's for the
  same colonies (median ratio 0.88), because Otsu's threshold sits partway into the
  soft halo that the global brightness level includes.
- Two touching colonies inside one circle are traced as one region.
