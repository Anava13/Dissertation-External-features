# QuantaColony (Python)

The home page lists the projects in the library. Each project has a project
page (the MATLAB Hub) that opens Cropping, Colony Detection and Stats. The
DataManager holds each project (one `.qcproj` file) and is the only part of the
program that reads or writes files.

**The tutorial project (Crowding)** comes with the program: the wild-type dilution series, ten
plates from one culture spread at 100X to 128000X and incubated and photographed together, so
plating density is the only difference between them. Every plate is cropped and detected and
its growth coverage measured, so every module can be explored on it. Its result applies to any
colony-size question: median colony radius rises about 2.7-fold from the densest plate to the
sparsest, and the capture ratio marks the plate too crowded to measure (100X, below 25%). A new
library gets it at first start; "Add tutorial project" on the home page adds a fresh copy any time.

**Start tutorial** (home page) opens a small panel that stays above every screen and walks
through the project in ten steps: open it, the dish fit and scale in Cropping, a sparse and a
crowded plate in Colony Detection, then in Stats crowding against colony size, colony count,
the capture ratio and its cutoff, leaving overplated plates out, measurement fidelity, and how
to plan experiments for crowding. Each step names a task, ticks itself off when the screen shows
it done, and then explains the result. Progress is kept on each computer. Steps and their checks
are in `core/tutorial.py`, the panel in `gui/tutorial.py`.

## Install it (Windows)

1. Install `uv`, which installs Python and the libraries for you. In PowerShell:

   ```
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

   Close PowerShell afterwards.

2. Extract the zip anywhere and double-click `Install QuantaColony.bat`.

   It copies the program into uv's tools folder (`%APPDATA%\uv\tools\quantacolony`), with its own
   Python and the library versions in `uv.lock`, and puts a QuantaColony icon on the Desktop and in
   the Start menu. The first install downloads Python and the libraries (a few minutes).
   **After that, the extracted folder is not needed: move it or delete it.** The installed program
   never refers back to it.

3. To update, extract the new zip and double-click its `Install QuantaColony.bat` (close
   QuantaColony first). The library and its projects are untouched: they live in their own
   folder, and `settings.json` lives in `%LOCALAPPDATA%\QuantaColony`.

The icon starts the program with no console window.
It also gives `.qcproj` files the QuantaColony icon: double-clicking one opens it
(a project from the library opens; any other is imported). This is set for the
current user only and needs no administrator rights.

The first start asks where to keep the project library (default
   `%LOCALAPPDATA%\QuantaColony\Library`) and puts the tutorial project in it. Every start shows
the home page. Results go to `Documents\QuantaColony Exports`.

### Development copy

In the source folder, `uv run quantacolony` runs the code in that folder directly (changes take
effect at the next start); `uv run pytest` runs the tests. To import a shared project:
`uv run quantacolony "D:\Shared\X.qcproj"`. Demos on 12 synthetic plates:
`uv run quantacolony --demo-cropping` (nothing cropped yet) and `uv run quantacolony --demo-stats`
(cropped and detected; the first start takes about 15 s).

A development copy builds `.venv` inside the source folder, and that `.venv` stores the folder's
full path, so a source folder in use cannot be moved; delete `.venv` after a move and `uv run`
builds it again. `uv run quantacolony-shortcut` refuses to point the Desktop icon at a
development copy for the same reason (add `--from-source` to do it anyway). Run
`Install QuantaColony.bat` to update the installed program from it.

## Variables, indices and plates

Nominal and ordinal variables are the design: the factors an experiment crosses. One level of
each together is an **index**. A **plate** is one region on a photo with its own colonies.

A **replicate** variable (one per project at most) is not a factor. Biological replicates are
interchangeable, nothing but chance makes them differ, so they are not a slice of the data: they
are the plates an index holds. Sections with the same levels (on one photo or on several) become
plates 1, 2, ... of that index, numbered when the photo is saved; more are added as plates need
them. A replicate variable never multiplies the indices, is not on the index boards (a cell counts
its plates), never reaches a Stats slot (its plates are always pooled) and is never matched
within: *Plates: One per index* chooses among the plates of each index (see Stats).

Progress counts plates: plates placed, plus every photo not cropped yet at the plate setting's
sections per photo. The combinations of levels matter only in Cropping, where *Finish cropping*
lists combinations no photo holds (expected when the design is not fully crossed).

In the file each plate is one row of `indices` with one level of every variable, the replicate
number included, so regions, detection, colonies and the derived cache work plate by plate as
before. `Structure.plates_by_design` groups them by index; `DataManager.commit_photo` numbers
them.

A value measured on one plate (a hemocytometer cell estimate, say) is not a variable either: as
one, every plate would need its own level and the project would read as mostly empty.

## Home page and project page

**Home page.** Every project in the library with a progress bar (detected, needs review,
still to do, out of its plates), its colony count, last change and size.
Selecting a project shows its summary on the right: a thumbnail of its first photo, photos,
variables, plates cropped and colonies counted. Open (or double-click) shows the project
page. Import project copies a shared `.qcproj` into the library. Export offers two choices:
a project file to share, or a browsable folder (see Exporting). Backups restores one of the
five latest snapshots; Move library moves the whole library. New project opens the wizard.

**Folders.** Projects sit in folders, nested to any depth. New folder makes one inside the
selected folder (or beside the selected project). Drag projects and folders onto a folder to
move them, or between top-level rows to bring them to the top level; right-click for Rename,
Move to and Delete (keys: Delete, F2). A folder row adds up the progress, colonies and size of
everything inside it, and selecting it shows that summary. New project and Import project put
the project in the selected folder. Which folders are open is remembered on each computer.
Folders are records in `folders.json`: project files never move, so opening, locks, backups,
export and Move library work as before.

**Trash.** Delete (button, right-click or the Delete key) moves a project, or a folder with
everything in it, into the library's Trash, together with its backups. Trash (n) at the bottom
lists what was deleted: Restore puts an item back where it was (the top level when its folder is
gone; a project whose name was taken meanwhile comes back as "Name (restored)"), Delete
permanently and Empty Trash remove it for good. Nothing leaves the Trash by itself. A project
open in any window cannot be deleted.

**New project wizard.** Five steps with a summary of the indices on the right:

1. Photos: project name (a name already in the library is refused, with a free one
   offered), the plate photos in order (move, remove, sort by the numbers in the file names).
2. Plate: round dish with 1 to 8 sections (numbered clockwise from the top), or a
   rectangular grid of up to 8 × 8.
3. Variables: name, kind (nominal, ordinal, replicate), levels and the control level. The
   name box takes any name; its list suggests names (Genotype, Medium, Generations, ...)
   that also fill in example levels and units. Levels you typed are never replaced.
   Ordinal levels must be numbers; ordinal variables take units. A replicate variable takes
   a number of plates per index instead of levels (one replicate variable per project).
4. Scale: dish size (90 mm, 140 mm or any size), plate size, scale bar, or none.
5. Review: every choice with an Edit link. Create project writes the `.qcproj` file, copies
   the photos into it, and opens Cropping.

Nothing is written before Create project.

**Project page.** Summary numbers (photos, plates cropped, plates detected, to review,
colonies counted), the variables with their control levels, and one row per step with a
progress bar:

| Step | Status shown | Opens when |
|---|---|---|
| Cropping | photos cropped, plates in indices | the project has photos |
| Colony Detection | plates detected, plates to review | some plate has a region |
| Stats | plates with colonies | some plate is detected |

Counts come from the project file, so a step shows progress again when photos are added
later. "‹ Back to project" at the far left of the banner, at the same place in Cropping, Colony
Detection and Stats ("‹ Back to projects" on the project page; `gui/banner.py`), or closing a
module, returns to the project page; closing the home page or the project
page quits.

## Stats

Every analysis is a plug-in (`quantacolony/analyses`). Each declares the variable
dimensions it plots (its slots), which variable kinds each slot accepts and how many
variables it takes. Stats builds its controls from that: every variable goes into one slot
or is pooled, and a variable whose kind a slot does not accept cannot be put there. Two or
more variables in one slot combine into one level per combination. Choices are saved with
the project, per analysis.

- **The plot setup panel** answers three questions, and its arrow folds all of it into one
  summary line (saved with the project):
  - *Split the plot by*: one row per slot of the analysis, with the slot's description (what a
    level of a variable placed there becomes in the figure); the variables are chips, on in the
    slot they sit in. A slot that does not take a variable's kind shows its chip struck through.
    Variables in no slot are pooled, named in one line under the rows.
  - *Plates used*: one row per variable with the levels used; its button opens the levels pop-up
    (with colors for the color variable). A switched-off level leaves its plates out of every
    analysis; it is saved with the project and listed in the notes. Values are normalized first,
    then those rows are left out, so a switched-off control still serves as the reference; a
    switched-off level of any other variable is left out of the reference too. A replicate variable
    is not listed: its plates are always pooled.
  - *Plate rules*: Touching, Overplated (the note gives a count, the notes under the figure too),
    By hand (*Plates…*: every plate with its levels, colony count, capture ratio, whether it is used
    and why not; unticking Use leaves it out of every analysis), and Plates (one per group).
- **Colors:** "Color by" picks one variable; each of its levels gets a color (the palette by its
  place among all levels, a gradient for an ordinal variable) that a click on its square
  changes. Colors are saved per variable and apply to every analysis that declares
  `color_slots`, when the variable sits in one of them; otherwise the analysis keeps its own
  colors and a note says why.

| Analysis | Slots | Notes |
|---|---|---|
| Density plots | Panels, Curves | Gaussian KDE; Freedman-Diaconis bandwidth, never below one pixel at the group's own scale (raw) or 0.05 (normalized) |
| Box plots | X axis, Groups | 1.5 × IQR whiskers, outliers as points; Together (groups side by side, two empty positions between them) or Separate (one axis per group) |
| Violin plots | X axis, Groups | Same layouts; each violin is a KDE scaled to its own maximum, 0.4 wide, with its median; same bandwidth as the density plots |
| Mean, Median, ... Peak density | X axis (ordinal or nominal), Lines | One statistic across the x-axis levels |
| Measurement fidelity | Rows, Columns | 0.5 px / radius px per colony, five zones, median per group, conclusion; always raw pixel radii |
| Mixture model | Blocks, Columns | subpopfig, one fit per index, kept per index while Stats is open: changing slots, colors or hidden levels redraws without fitting; only indices not fit yet are fit, in the background. Every used plate is drawn; with one plate per group the chosen plates are the bright ones (`marks_selection`), otherwise subpopfig's own pick (closest to the median colony count) |
| Plate metrics | X axis, Groups | One value per index: colonies counted, mean radius, growth coverage, colony coverage or capture ratio |

- **Normalization** (analyses that declare it): Raw data; Control (groups slot): each value
  divided by the mean of the control group level at the same x-axis level; Control (x-axis
  slot): each value divided by the mean of its own group at the control x-axis level. A
  variable with no control level marked uses its first level, and the notes say so.
- **Touching colonies:** colonies Colony Detection split from a blob of touching colonies count
  in colony counts; "Touching: Leave out of sizes" removes them from analyses with one row per
  colony (before normalization), and the notes say how many. Saved with the project.
- **Overplated plates:** a plate whose capture ratio is below 25% holds growth that merged
  instead of forming separate colonies (the dilution series: 100X falls below, 500X and every
  sparser plate stay above; `SEPARABLE_CAPTURE_RATIO` in `core/growth.py`). Plate metrics draws
  the cutoff on the capture ratio and counts the plates below it. "Overplated: Leave out" removes
  those plates from every analysis, before normalization, so they never serve as a reference;
  the notes name them. The choice is saved with the project.
- **Plates: All / One per index** (`core/selection.py`, a port of the MATLAB CountDatasetGenerator),
  built on replicates: the replicate plates of an index are always the pool. By default every
  design variable is under *Match within*, so each group is one index and keeps the replicate
  plate closest to the colony-count target. Leaving a variable out chooses across its levels too
  (the button then reads *One per group*): with Density left out, each Genotype × Passage × Series
  group keeps the plate closest to the target across every tier and its replicates, the
  count-matching rule. *All* draws every plate, with every replicate pooled.
  An analysis declaring `marks_selection` (the mixture model) receives every used plate with
  `AnalysisData.selected` set to the chosen ones; every other analysis receives the chosen plates
  only. A plate can be chosen when it is used (no level switched off, not left out by hand),
  none of its levels is excluded under *Choose from* (the pool can be narrower than the plates
  drawn, as CountDatasetGenerator chose from Standard A/B plates while QC.m drew more), its
  capture ratio is at least 0.25, and it has at least one colony. Overplated plates are always
  left out while it is on. The target is the median colony count of every such plate in every group,
  or a fixed number; each group keeps the plate closest to it, ties going to the first plate in
  project order. Colony count is the photo's (indices on one photo add up). Groups are the shown
  combinations that hold a plate (a combination nobody plated is not a group); a group whose plates
  all fail a filter is reported: *Selection…* lists every plate of it, by the levels it is chosen
  across, its plate number and its photo, with each filter it fails, how many fail each filter and
  how many fail only one. A group's menu
  pins one of its plates (used whatever the target, even one failing a filter, and flagged) or
  leaves it empty; *Reset to automatic* clears these, and changing *Match within* clears them
  too. Overplated is then set by the selection. Save table writes one row per group. Every
  choice is saved with the project.
- **Growth coverage in Plate metrics:** indices are measured once (see Growth coverage) and
  kept. The first time a coverage measure is chosen, indices not measured yet are measured
  with a progress dialog that can be stopped.

Save figure writes PNG, PDF or SVG; Save table writes the numbers behind the figure as CSV.

### Writing your own analysis

Put a `.py` file in the library's `Analyses` folder (the "Analyses folder…" button in Stats
opens it). Stats loads every file there when it opens. A file defines `ANALYSES`, a list of
analysis objects; `example_analysis.py.txt` in that folder is a working example (rename it
to `.py`). The contract is in `quantacolony/analyses/api.py`:

- declare `id`, `name`, `group`, `description`, `unit` (`"colony"` or `"index"`), `slots`
  (`Slot(key, title, kinds, min_variables, max_variables)`), `options`, `normalize` and
  `color_slots` (the slots that define one colored element, for "Color by");
- `compute(data, options)` receives an `AnalysisData`: the levels of every slot, each row's
  position on them, and the (normalized) values. It returns any result;
- `draw(figure, result, style)` draws on the matplotlib figure Stats provides, with the
  colors and fonts in `style` (from the theme); it may return a new figure instead. For each
  element it draws, `style.color_for(data, slot=position, ...)` gives the "Color by" color, or
  None to use its own;
- `table(result)` returns the rows Save table writes.

A file that fails to load, or an analysis that breaks the contract, is listed in the notes and
skipped. Loading a file runs its code, so only add files you trust.

## Colony Detection

**Moving between indices.** Click the image name in the top bar for the index board, the
same board as in Cropping: one cell per index, with Rows / Columns / Pages for each variable
(saved with the project). Cells show detected, not detected yet, to review, and no region;
the open index has a white outline. Click a cell to open it (a cell with several replicate plates
shows how many are detected, 1/2, and opens the first plate still to detect). The arrows (or Page Up / Page
Down) step through the indices in level order, last variable fastest. Leaving an index with
edits that are not saved asks Save / Discard changes / Cancel, and so does closing the window.
Finish image saves, then opens the next index that is not detected yet or needs review.

Detection is two steps (keys 1 to 5). Step 1, automatic detection:

| Mode | What to do |
|---|---|
| 1 Detect automatically | Colony shape (Irregular / Circular), colony color (Dark / Light), brightness threshold, sensitivity, radius (arrows or typing), largest object and Split touching colonies rerun detection on the whole image. Estimate settings sets the color, threshold and radius range from the image |

Step 2, manual correction:

| Mode | What to do |
|---|---|
| 2 Delete colonies | Click colonies (click again to deselect), then Delete |
| 3 Delete a region | Drag a box, then Delete |
| 4 Add colonies | Press on one edge of a colony and drag to the opposite edge; the drag is the diameter, and a readout shows the radius. Drag inside a circle to move it, drag its edge to resize it, right-click it to remove it. "Snap to colony edge" fits each circle to the colony inside it. Then Add |
| 5 Detect in a region | Drag a box; the settings then apply inside the box only; then Add |

Undo and Redo work for every edit, including setting changes (Ctrl+Z / Ctrl+Y).
Scroll to zoom toward the pointer; middle-drag, Space + drag or the hand button pans;
double-click or the fit button shows the whole plate. Esc clears a selection,
a deletion box or a detection region. `[` collapses the left column to a rail of
mode icons and `]` hides the right column (also the two buttons in the top bar).

The left column shows only the controls that apply at the moment: for example,
Detect in a region shows its settings once a box is drawn, and the Delete and Add
buttons appear once something is selected or drawn.
**Starting settings.** A new index starts from the settings of the last image finished in the
project. In a project made with the wizard, the first image estimates its settings instead.
Colonies drawn in Add colonies are added as drawn, even where they overlap others; Detect in a
region skips candidates that duplicate existing colonies.

**Growth.** The summary card shows growth coverage; Show tints every pixel found as growth
(amber outside the marked colonies). See Growth coverage.

"Finish image" sends the result to the DataManager, which saves it in the project file
and exports `Documents\QuantaColony Exports\<project>\<index>_colonies.csv`. Reopening the project opens the saved
result. Edits before a Finish can no longer be undone afterwards; the next Finish saves a new
revision. Finish image then opens the next index not detected yet or needing review; when
none is left, it offers Stats or the project page.

The Activity panel records detections, edits, undo and saves; brief feedback
appears in the status bar.

## Look and fonts

Everything the interface draws ships inside the package: line icons are drawn
from code (`theme/icons.py`), and the fonts are Inter and Raleway
(`quantacolony/assets/fonts`, SIL Open Font License). Colors, sizes and fonts
are defined once in `theme/tokens.py`, including the colors of Stats figures (`PlotColors`,
handed to every analysis). The two brand colors come from the logo: lime `#7BF501` (accent,
added colonies) and teal `#2EC8BB` (automatic detections).

**Changing the front end.** All interface code is in `gui/` and `theme/`; `core/`, `data/`,
`analyses/` (except drawing on the figure it is given) and `stats/` import no Qt. Every
window declares the signals its controller listens to (for example `finishRequested`,
`settingEdited`) and the `set_`/`show_`/`ask_` methods the controller calls; controllers use
nothing else. A window can be redesigned freely as long as it keeps those names and meanings.
Colors live only in `theme/tokens.py`.

The logo lives in `quantacolony/assets/logo`: `logo.svg` (full mark),
`favicon.svg` (simplified for 16 to 32 px), PNG copies, and `quantacolony.ico`
for the window, taskbar and shortcut.

## Project data (DataManager)

One project is one file (an SQLite database) in the project library. The DataManager keeps it
as the only source of truth: modules ask it for data and send results back, and it alone touches
files.

The DataManager is the front door to private helpers in `data/store/`, one per area of the
file (project file, structure, photos and regions, detections, derived cache, projects as
files). Only the DataManager creates helpers and hands them the one open file; helpers never
call each other, and every action that touches several areas runs inside one transaction in
a DataManager method. Saving a cached calculation does not count as a change, so a session
spent looking at results leaves no backup.

### The project library

```
%LOCALAPPDATA%\QuantaColony\settings.json     pointer: library path and id, last project
<library>\library.json                         marker: library id
<library>\Projects\<project id>.qcproj         one file per project, named by id
<library>\Projects\<project id>.lock           held while the project is open
<library>\Backups\<project id>\<time>.qcproj   snapshots, newest 5 kept
<library>\Analyses\*.py                       analysis plug-ins for Stats
<library>\folders.json                         folders, which project sits in which, Trash records
<library>\Trash\<project id>.qcproj            deleted projects (and Trash\Backups\<project id>\)
```

- **Choosing it:** the first start asks for the library folder. Network drives and folders inside
  OneDrive, Dropbox or Google Drive are refused, because they can damage open SQLite files. Folders
  inside the program (the installed copy, or a development copy's source folder) are refused, because
  reinstalling or deleting the program removes them.
- **Finding it:** settings.json sits where Windows reports local application data, so it is always
  found. If the library is not at its stored path, QuantaColony tries the same path on every other
  drive letter, then asks to locate it (checking the marker's id) or create a new one.
- **Moving it:** `DataManager.move_library` copies every folder of the library (Projects, Backups,
  Analyses and any other), checks that every file arrived whole and every project opens, writes the
  marker, then removes the old folder and updates settings. A folder inside the library itself is
  refused. The old marker is removed first, so if a file in the old folder is open in another
  program, the move still completes, the leftover folder is no longer a library, and the home page
  names it for deletion. Projects hold their own photos, so a library moved intact never breaks a
  project.
- **Sharing:** `export_project_file` writes a consistent copy anywhere outside the library;
  `import_project_file` (or a `.qcproj` on the command line) copies a shared project in.
- **Backups:** closing a project that changed leaves a snapshot; `restore_backup` brings one back
  and first snapshots the state it replaces.
- **One window per project:** an operating-system lock, released automatically if the program crashes.

| Table | Holds |
|---|---|
| `project` | Name, schema version, detection defaults, plate settings |
| `variables`, `levels` | Variables (nominal, ordinal, replicate) and their values, as rows |
| `indices`, `index_levels` | Each plate: one level per variable (the replicate number included) |
| `photos` | Plate photos exactly as uploaded, with scale, size and a thumbnail |
| `assignments` | Cropping's region for each index (shape parameters and outline) |
| `detection` | Committed parameters, revision, detection version, review flag |
| `colonies` | Colonies of the final result and the baseline, in photo pixels |
| `edit_log` | Every committed edit, in order |
| `derived_cache` | Derived results, used only while their fingerprint matches |

The file stores photos and decisions only. Crops, masks, measurements, growth coverage and
exports are computed on request. Saves are SQLite transactions: a crash during a save leaves
the last committed state. Files from older versions are upgraded when opened.

### Exporting

- **Project file (.qcproj):** one file for someone who has QuantaColony.
- **Browsable folder:** a read-only copy anyone can look through: `index.html` (what the
  folder holds, the variables, every index with its crop and links), `photos/`,
  `indices/<index>/` (`crop.png`, `colonies.png` with every colony drawn, `growth.png`,
  `colonies.csv`), `summary.csv` (one row per index, with coverage) and `project.json`.
  QuantaColony never reads it back.

## Growth coverage

`core/growth.py` decides which pixels of an index are yeast growth, learning from the
colonies marked in Colony Detection. Each plate teaches its own classifier:

1. **Growable area:** the index's region from Cropping, less a band along its edge (0.6% of
   the region's size, at least 2 px: 9 px on a 1500 px dish), where the dish rim reflects.
2. **Lighting:** a smooth agar surface is estimated from pixels away from every colony that
   look like agar; each pixel becomes its difference from the local agar, in units of the
   agar's noise, per CIE Lab channel. "Look like agar": the plate shows both colors (a thin
   ring just outside the marked colonies is agar, their insides are growth), and a pixel past
   the midpoint toward growth is left out of the agar sample. Without this, a confluent lawn
   far from every marked colony is sampled as agar and taught as agar.
3. **Labels from the plate:** pixels inside marked colonies are growth; pixels away from
   colonies that sit within the agar's noise are agar.
4. **Classifier:** a class-balanced logistic regression on the corrected color, a smoothed
   copy and local texture gives each pixel a probability of growth.
5. **Clean-up:** weak pixels are kept only where they connect to confident ones or to a
   marked colony; parts thinner than a small colony (dish rim, scratches, streak marks) are
   dropped, even where they touch a colony. Marked colonies are always growth.
6. **Dish wall:** a growth part with no marked colony that lies mostly (60%) within 5% of the
   region's size from its edge is the dish wall and is dropped. On the Rescue photos the wall
   forms arcs several colonies thick, which the thin-part rule keeps; with this step, the capture
   ratio falls on the same side of 25% as the MATLAB pipeline's for 114 of 120 plates (98
   without it). Growth version 4: coverage measured before is measured again.

Steps 2 to 4 run twice, so growth found in the first pass does not lift the agar surface. A
plate with no marked colony falls back to an unsupervised rule and is flagged.

| Measure | Definition |
|---|---|
| Growth coverage | growth pixels / growable pixels |
| Colony coverage | pixels inside the union of marked colonies / growable pixels (overlaps count once) |
| Separate coverage | the same for separate colonies only (colonies split from touching ones left out) |
| Capture ratio | separate coverage / growth coverage: the share of growth that resolved into separate colonies |

Coverage is a cached derived result (`plate_coverage`): measured when an image is finished,
and again only when its colonies, crop region or the method's version change.

**Check:** `held_out_check` leaves a third of the marked colonies out of the labels in turn
and reports the share of their pixels found as growth, and the share of confident agar called
growth. On the test image (one Anbalagan 2011 plate crop, `tests/sample`) it finds 98.6% of the held-out colony pixels (a Python port of
the earlier MATLAB growth mask found 0–56%) in about 0.25 s; on the ten plates of the wild-type
dilution series (whole 90 mm dishes, 1500 px) it finds 98.5–99.7% with at most 0.4% of agar
called growth, in 4–7 s per plate.

**Confluent plates (method version 2):** version 1 sampled a confluent lawn as agar, so the 100X
plate of the dilution series read 31% capture ratio and the 25% cutoff no longer separated it
from 500X (29%). Version 2 reads 22.6% (100X) and 30.4% (500X); `test_capture_ratio_separates_the_
overplated_plate` keeps it that way. Growth coverage on that series lies within 1 to 6 points of
the MATLAB measurement on every plate. Ink written on a dish (plate labels) is the color of yeast
and is counted as growth.

## Cropping

A project opens in Cropping while any photo has no regions yet, otherwise in Colony Detection.

- **Plate.** Round dish: drag the center to move it, the square on the rim to resize it, the
  large handle to rotate every cut, a small handle to move one cut; right-click a cut handle to
  remove it. `−` / `+` remove or add a cut; Fit dish finds the dish edge again. Rectangular
  plate: center, corners (resize about the center), round handle (rotate); `−` / `+` change
  the number of columns.
- **Levels.** Each variable is set either for the whole photo or per section; the link under
  its name moves it to the other group (saved with the project). Click a section to select it.
  Number keys 1-9 pick a level of the first per-section variable and move to the next section.
- **Proposals.** A new photo starts from the previous photo's layout (dish refitted) with the
  whole-photo levels stepped like an odometer, last variable fastest. Proposed labels are dashed.
- **Duplicates and replicate plates.** With a replicate variable, sections with the same levels
  are plates of one index; the label shows the plate number once saved. Without one, an index used
  twice on a photo, or already on another photo, turns red and blocks saving; "Open it" / "Show it"
  goes to the other one. "Leave section unused" skips a section.
- **Done with photo** (Enter) commits the layout and every region to the project in one
  transaction, then opens the next photo without regions.
- **Indices board.** One cell per index; each design variable can go on rows, columns or pages
  (view only), and a cell with several replicate plates shows their count (×2). With more than 16
  columns the last column variable is counted inside each cell. Click a cell to open its photo and
  section.
- **Finish cropping** lists combinations of levels that no photo holds (and unsaved changes) before it opens
  Colony Detection; "Go back" returns to Cropping.

## Layout

```
quantacolony/
  core/            model: no Qt imports; runs in scripts and tests
    tutorial.py      the tutorial's steps, their checks and what each result shows
    params.py        DetectionParams and spinner limits
    colony_set.py    ColonySet: immutable colony table with ids
    detection.py     prepare_image, detect_irregular_colonies, detect_circular_colonies, remove_overlaps
    commands.py      edits as commands (before/after snapshots) for undo and redo
    session.py       DetectionSession: one image, its colonies, its history
    messages.py      notifyuser message texts
    measurements.py  per-colony measurements
    autoparams.py    starting detection settings estimated from the image
    growth.py        growth mask, coverage and the held-out check
    selection.py     one plate per index (or group), chosen among replicates on colony count
    contour.py       contour_circle: fit a colony outline inside a drawn circle
    scoring.py       automatic detection scored against a corrected result
    drawing.py       DrawnCircle: drawn circles before they are added
    record.py        what Colony Detection receives from and sends to the DataManager
    cropping.py      Cropping model: dish and grid layouts, proposals, duplicates, index board
    stats.py         colony and index tables; bandwidth, KDE, summary statistics, fidelity zones
    new_project.py   New Project model: the draft, its checks, the specifications to create from
  analyses/        Stats analyses as plug-ins (Qt-free except drawing on the figure given)
    api.py           the contract: Slot, Option, AnalysisData, PlotStyle, Analysis
    data.py          slot assignment, normalization, building AnalysisData
    registry.py      loads built-in analyses and the library's Analyses folder
    common.py        shared per-group statistics and figure styling
    builtin/         distributions (density, box, violin), across_levels, fidelity,
                     subpopulations, plate_metrics
  data/            DataManager: the only code that reads or writes files
    manager.py       DataManager: the front door; packets, commits, derived results, exports
    store/           private helpers: project_file, structure, photos, detections,
                     derived_cache, catalog (list, copy in and out, backups, Trash files),
                     folders (folders.json: nested folders, placement, Trash records)
    schema.py        the tables of a .qcproj file
    packets.py       values exchanged with modules
    regions.py       crop regions: rectangle, sector, polygon; crop and mask
    derived.py       derived results (colony measurements, plate coverage), versions, fingerprints
    exports.py       CSV, PNG, JSON and HTML writers (atomic): colony and growth overlays, index.html
    codec.py         arrays and parameters to and from stored values
    library.py       project library: marker, finding a moved library, location checks, move, lock
    settings.py      settings.json: library pointer, last and recent projects
    tutorial_project.py, tutorial/Crowding.qcproj   the tutorial project (wild-type dilution series)
    demo_project.py  synthetic 12-photo, 4-variable project for Cropping
  theme/           program-wide look
    tokens.py        colors (screens and Stats figures), fonts, sizes: the only place colors live
    stylesheet.py    Qt style sheet built from the tokens
    icons.py         line icons drawn from SVG path data
    assets.py        loads the bundled fonts
  stats/subpopfig/ the subpopfig package (mixture fits and the subpopulation figure); fit_mixtures takes an
                   optional per-entry fit cache (fit_key)
  gui/             view and controller
    navigator.py     which screen is open; module close returns to the project page
    home.py          home page: project list, import, export, backups, move library
    new_project.py   New Project wizard (view and controller)
    project_page.py  project page: variables and the state of each step
    launch.py        builds each module's window and controller
    index_board.py   the index board shared by Cropping and Colony Detection
    light.py         shared pieces of the light screens
    stats_window.py, stats_controller.py   the Stats module (runs any analysis plug-in)
    help.py          help window: one HTML page per screen (assets/help)
    tutorial.py      the tutorial panel (stays above every screen) and its controller
    main_window.py   ColonyDetectionWindow (view)
    widgets.py       mode buttons, switch, slider rows, activity feed
    canvas.py        DetectCanvas: image and colony overlays (view)
    tools.py         the four mouse tools
    modes.py         interaction modes and their instructions
    controller.py    ColonyDetectionController
    library_setup.py first-start and missing-library screens (light palette)
    cropping_window.py   CroppingWindow and the index board (view)
    cropping_canvas.py   CropCanvas and PlateTool: layout drawing and handles
    cropping_controller.py  CroppingController: drafts, proposals, commits, finish warning
  app.py           start: library, home page, demos; build() opens one module directly (tests)
  evaluation.py    scores detection on a project's corrected results (python -m quantacolony.evaluation)
  shortcut.py      creates the Desktop and Start menu shortcuts (Windows; run by the installer)
  assets/logo/     logo SVGs, PNGs and the .ico
  assets/help/     help pages (HTML)
Install QuantaColony.bat   installs the program for the current user (uv tool install) and its shortcuts
tests/
  sample_project.py, sample/   the test sample: one Anbalagan 2011 plate crop (MATLAB comparison)
  golden/          MATLAB reference result; the 100X and 500X Crowding plates (capture ratio test)
  test_core.py     detection matches MATLAB; undo/redo; overlap filtering
  test_gui.py      drives every tool through the real controller; finish and reopen
  test_data_manager.py  project file, commits, cache, regions, exports
  test_library.py  library pointer and marker, moves, locks, sharing, backups
  test_cropping.py Cropping on the demo project: commit, proposal, duplicates, finish warning
  test_stats.py    analyses and their data, plug-in loading, Stats on the detected demo, navigation
  test_improvements.py  detection settings, overlaps, end-of-detection prompt, help, home and
                   project pages, growth coverage
  test_new_project.py  wizard checks, specifications, creating a project
  test_selection.py  one plate per group: the MATLAB rules, diagnostics, pins and skips, in Stats
  test_splitting.py  splitting touching colonies, scoring, split colonies in storage, coverage and Stats
  test_detection_navigation.py  index board, arrows, unsaved edits, Finish image moves on
```

## Known differences from MATLAB

- Irregular detection reproduces MATLAB exactly on the test image (33 colonies, same
  positions and radii). Coordinates are 0-based; messages show 1-based values, as MATLAB did.
- Circular detection uses scikit-image's Hough transform. MATLAB's `imfindcircles`
  uses a different algorithm, so counts differ; higher sensitivity still finds more circles.
- Results are saved per index in the project file; MATLAB kept FinalParams in the
  DataManager state file and in FinalParams_*.mat.
- The baseline (InitialState) follows the latest whole-image detection, as in MATLAB, and
  undo restores the previous one.
- Parameter changes are undoable. In MATLAB they reset manual edits with no way back.
- Add colonies draws any number of circles directly; there is no "Add Another Circle" step.
- Mode names changed: Modify Global Parameters → Detect automatically, Delete Individual
  Colonies → Delete colonies, Delete Many Colonies → Delete a region, Add Individual
  Colonies → Add colonies, Add Many Colonies → Detect in a region; I'm Satisfied → Finish image.

## Splitting touching colonies

Touching colonies form one blob after thresholding. Without splitting, the blob fails the
single-colony test (too large or too elongated) and is dropped, or passes as one oversized colony.
With **Split touching colonies** on (Irregular detection; on in new projects, off in projects made
before it existed), a blob larger than the largest colony or more elongated than *Split above
elongation* is cut apart: each pixel's distance to the blob's edge peaks at every colony's center
and dips where the blob narrows. Peaks separated by a dip of at least *Minimum pinch* × the blob's
widest half-width are colony centers (the h-maxima transform), and the blob is divided between
them along the dips (watershed). A blob is split only when every piece passes the single-colony
test, so a ragged colony is not broken into fragments; a blob with one center (an oval colony)
stays whole. Pieces are marked `split` (drawn violet; `source` in the colony CSV) and their result
records detection version 2.

What follows from a split colony: it counts in colony counts (colony count is what tracks crowding);
Stats can leave it out of sizes ("Touching: Leave out of sizes"); the capture ratio counts it as
merged growth, which keeps the 25% cutoff meaning what it meant (on the dilution series with
splitting on, 100X reads 12.9% and 500X 30.4%).

**Defaults (0.6 elongation, 0.15 pinch) are provisional.** They were chosen on the wild-type
dilution series only, scored against the corrections on the seven plates that were corrected
(100X is overplated; 1000X and 16000X were barely edited): colonies missed fall from 257 to 94, and
no round colony that was accepted as single is cut in two, on any of the ten plates. Choosing on six
plates and testing on the seventh picks the same region every time. 0.5 elongation cuts three
accepted colonies on 1000X, and 0.1 pinch finds five more colonies at more risk on other photos, so
the defaults keep a margin. Score them on other corrected projects before relying on them.

**Scoring detection.** `uv run python -m quantacolony.evaluation project.qcproj [--set split=1
split_pinch=0.15]` redetects every finished image with its own settings (or changed ones) and
scores the result against the corrected colonies: matched (center within half the corrected
colony's radius), missed, extra and corrections (missed + extra), per index (`core/scoring.py`,
`evaluation.py`). The file is copied into a temporary library and never changed. Corrections
reflect how a person corrected: plates where touching colonies were deleted rather than split
count correct splits as extra.

## Contour

Contour splits the pixels inside a drawn circle into two brightness classes
(Otsu's method), keeps the class at the circle's center (so bright or dark
colonies both work), and traces the connected region under the center.
The colony is added with that outline; its radius comes from the outline's area.

- On the test image (`tests/sample`) it contours all 33 detected colonies and rejects 80 of 80
  empty-agar circles. The cutoff (`MIN_CONTRAST` in `core/contour.py`) was set on
  this one image; low-contrast plates may need a lower value.
- Contoured radii are about 12% smaller than automatic irregular detection's for the
  same colonies (median ratio 0.88), because Otsu's threshold sits partway into the
  soft halo that the global brightness level includes.
- Two touching colonies inside one circle are traced as one region.
