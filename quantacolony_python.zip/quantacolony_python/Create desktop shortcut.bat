@echo off
rem Creates QuantaColony shortcuts on the Desktop and in the Start menu.
cd /d "%~dp0"
uv sync
uv run quantacolony-shortcut
pause
