"""Stats: core statistics, the Stats controller on the detected demo, the home and project pages, navigation."""

import time

import numpy as np
import pytest
from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QApplication

from quantacolony.analyses import POOLED, PlotStyle
from quantacolony.analyses import data as ad
from quantacolony.analyses.builtin.distributions import box_numbers
from quantacolony.analyses.common import grouped_statistics
from quantacolony.analyses.registry import load_analyses
from quantacolony.app import start
from quantacolony.core import stats as st
from quantacolony.data import DataManager, Settings, create_library
from quantacolony.data.demo_project import STATS_DEMO_NAME, complete_demo_project
from quantacolony.gui.launch import open_stats

GENOTYPE = st.StatsVariable("genotype", "Genotype", "nominal", ("WT", "mut"), ("Wild type", "mutant"), "WT")
PASSAGE = st.StatsVariable("passage", "Passage", "ordinal", ("1", "2"), ("P1", "P2"), None)
REP = st.StatsVariable("rep", "Replicate", "replicate", ("A", "B"), ("A", "B"), None)


def small_table(seed=0):
    rng = np.random.default_rng(seed)
    indices, index_id = [], 0
    for g in GENOTYPE.values:
        for p in PASSAGE.values:
            for r in REP.values:
                index_id += 1
                base = 20.0 * (0.7 if g == "mut" else 1.0) * (0.8 if p == "2" else 1.0)
                rows = [{"radius_px": float(x), "radius_um": float(x) * 100.0}
                        for x in rng.lognormal(np.log(base), 0.2, 40)]
                indices.append((index_id, {"genotype": g, "passage": p, "rep": r}, 10.0, rows))
    return st.build_colony_table([GENOTYPE, PASSAGE, REP], indices)


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture(scope="module")
def library(tmp_path_factory):
    root = tmp_path_factory.mktemp("stats")
    manager = DataManager(Settings(folder=root / "settings"))
    manager.use_library(create_library(root / "Library"))
    complete_demo_project(manager)
    project_id = manager.project_id
    manager.close()
    return root, project_id


def open_manager(library, folder="s"):
    root, project_id = library
    manager = DataManager(Settings(folder=root / folder))
    manager.use_library(_library(root))
    manager.open_project(project_id)
    return manager


def _library(root):
    from quantacolony.data import open_library
    return open_library(root / "Library")


# ----- analysis data -----------------------------------------------------------------
ANALYSES = load_analyses().analyses


def data_for(analysis_id, table, scheme=ad.RAW, assignment=None):
    analysis = ANALYSES[analysis_id]
    assignment = assignment or ad.default_assignment(analysis, table.variables)
    return analysis, ad.build_data(analysis, table, None, assignment, scheme)


def test_default_slots_and_combined_levels():
    table = small_table()
    density = ANALYSES["density"]
    assert ad.default_assignment(density, table.variables) == {"genotype": "panels", "passage": "curves",
                                                               "rep": POOLED}
    line = ANALYSES["line:Mean"]
    assert ad.assignment_problem(line, table.variables, {"genotype": "lines", "passage": POOLED, "rep": POOLED})
    assert "takes ordinal or nominal" in ad.assignment_problem(line, table.variables,
                                                               {"genotype": "lines", "passage": "x", "rep": "x"})
    two = ad.slot_axis(table.variables, {"genotype": "panels", "rep": "panels"}, "panels")
    assert two.labels == ("Wild type · A", "Wild type · B", "mutant · A", "mutant · B")


def test_normalizations_divide_by_control_mean():
    table = small_table()
    analysis, nominal = data_for("density", table, ad.CONTROL_NOMINAL)
    stats = grouped_statistics(nominal, "panels", "curves")
    assert stats.groups[(0, 0)].values["Mean"] == pytest.approx(1.0)
    assert stats.groups[(0, 1)].values["Mean"] == pytest.approx(1.0)
    assert stats.groups[(1, 0)].values["Mean"] == pytest.approx(0.7, abs=0.05)
    _, ordinal = data_for("density", table, ad.CONTROL_ORDINAL)
    assert ordinal.notes and "first level" in ordinal.notes[0]          # passage has no control marked
    stats = grouped_statistics(ordinal, "panels", "curves")
    assert stats.groups[(1, 0)].values["Mean"] == pytest.approx(1.0)
    assert stats.groups[(1, 1)].values["Mean"] == pytest.approx(0.8, abs=0.05)
    assert ordinal.scheme_label == "Control passage"


def test_summary_and_kde():
    values = np.array([1.0, 2.0, 2.0, 3.0, 7.0])
    summary = st.summary_values(values)
    d = values - values.mean()
    sd = np.sqrt((d ** 2).sum() / 4)
    assert summary["Standard Deviation"] == pytest.approx(sd)
    assert summary["Skew"] == pytest.approx((d ** 3).sum() / 5 / sd ** 3)
    grid = np.linspace(-20, 30, 4001)
    density = st.kde(values, grid, st.bandwidth(values, 0.5))
    assert np.trapezoid(density, grid) == pytest.approx(1.0, abs=1e-3)
    assert st.bandwidth(np.ones(10), 0.05) == 0.05                      # floor holds when the IQR is 0


def test_raw_bandwidth_floor_is_one_pixel():
    table = small_table()
    _, data = data_for("density", table)
    assert st.bandwidth_floor(data.um_per_px[data.select(panels=0, curves=0)], False) == pytest.approx(100.0)


def test_fidelity_zones_and_conclusion():
    table = small_table()
    analysis, data = data_for("fidelity", table)
    result = analysis.compute(data, {})
    expected = np.histogram(0.5 / table.radius_px * 100, bins=np.asarray(st.ZONE_EDGES))[0]
    assert np.array_equal(result["counts"], expected)
    assert result["grid_counts"].sum() == len(table) and result["grid_counts"].shape == (2, 2)
    assert result["conclusion"][0].startswith("Bulk assessment")


def test_subpopulation_frame_feeds_subpopfig():
    from quantacolony.stats.subpopfig import fit_mixtures, from_dataframe
    table = small_table()
    analysis, data = data_for("subpopulations", table)
    frame, schema = analysis.frame(data)
    assert frame["entry"].nunique() == 8 and set(frame["ordinal"]) == {1, 2}
    fits = fit_mixtures(from_dataframe(frame, schema, verbose=False), verbose=False)
    assert len(fits.entries) == 8 and all(e.k >= 1 for e in fits.entries)


def test_box_numbers_follow_the_1_5_iqr_rule():
    values = np.array([1.0, 2, 3, 4, 5, 6, 7, 8, 30])
    numbers = box_numbers(values)
    q1, q3 = np.percentile(values, [25, 75])
    assert numbers["q1"] == q1 and numbers["q3"] == q3
    assert numbers["whisker_high"] == 8 and list(numbers["outliers"]) == [30.0]


@pytest.mark.parametrize("analysis_id", ["box", "violin"])
@pytest.mark.parametrize("view", ["together", "separate"])
def test_box_and_violin_draw(analysis_id, view):
    from matplotlib.figure import Figure
    table = small_table()
    analysis, data = data_for(analysis_id, table)
    result = analysis.compute(data, {"view": view})
    assert len(result["cells"]) == 4
    if analysis_id == "violin":
        cell = result["cells"][(0, 0)]
        assert cell["bandwidth"] == pytest.approx(ad_bandwidth(data, 0, 0))
    figure = Figure()
    assert analysis.draw(figure, result, PlotStyle()) is None
    assert len(figure.axes) == (2 if view == "separate" else 1)
    rows = analysis.table(result)
    assert len(rows) == 4 and {"median", "q1", "q3", "outliers"} <= set(rows[0])


def ad_bandwidth(data, group, x):
    keep = data.select(groups=group, x=x)
    return st.bandwidth(data.values[keep], st.bandwidth_floor(data.um_per_px[keep], False))


def test_plate_metrics_on_an_index_table():
    table = small_table()
    rows = [(i, {v.name: table.levels[v.name][table.index_ids == i][0] for v in table.variables}, 10.0,
             {"colony_count": float((table.index_ids == i).sum())}) for i in sorted(set(table.index_ids.tolist()))]
    indices = st.build_index_table(table.variables, rows, {"colony_count": "Colonies counted"})
    analysis = ANALYSES["plate_metrics"]
    data = ad.build_data(analysis, table, indices, ad.default_assignment(analysis, table.variables))
    result = analysis.compute(data, {})
    assert {cell["n"] for cell in result["cells"].values()} == {2} and result["cells"][(0, 0)]["mean"] == 40


def test_user_analysis_loads_and_bad_files_are_reported(tmp_path):
    from quantacolony.analyses.registry import EXAMPLE
    (tmp_path / "counts.py").write_text(EXAMPLE, encoding="utf-8")
    (tmp_path / "broken.py").write_text("raise RuntimeError('oops')", encoding="utf-8")
    (tmp_path / "clash.py").write_text(EXAMPLE.replace("example:colony_counts", "density"), encoding="utf-8")
    report = load_analyses(tmp_path)
    assert "example:colony_counts" in report.analyses and report.sources["example:colony_counts"] == "counts.py"
    assert any("broken.py" in p and "oops" in p for p in report.problems)
    assert any("clash.py" in p and "density" in p for p in report.problems)
    analysis = report.analyses["example:colony_counts"]
    data = ad.build_data(analysis, small_table(), None, ad.default_assignment(analysis, small_table().variables))
    assert analysis.table(analysis.compute(data, {}))



# ----- shown levels and level colors ---------------------------------------------------
def test_hidden_levels_are_left_out_after_normalization():
    table = small_table()
    analysis = ANALYSES["density"]
    assignment = ad.default_assignment(analysis, table.variables)              # genotype panels, passage curves
    full = ad.build_data(analysis, table, None, assignment, ad.CONTROL_NOMINAL)
    shown = ad.build_data(analysis, table, None, assignment, ad.CONTROL_NOMINAL, hidden={"genotype": ["WT"]})
    assert shown.axes["panels"].labels == ("mutant",) and len(shown) == len(full) // 2
    assert shown.notes[0] == "Not shown: Genotype: Wild type."
    mutant = grouped_statistics(full, "panels", "curves").groups[(1, 0)].values["Mean"]
    assert grouped_statistics(shown, "panels", "curves").groups[(0, 0)].values["Mean"] == pytest.approx(mutant)
    assert mutant == pytest.approx(0.7, abs=0.05)                               # still divided by the hidden WT


def test_a_hidden_pooled_level_is_left_out_of_the_reference_too():
    table = small_table()
    analysis = ANALYSES["density"]
    assignment = ad.default_assignment(analysis, table.variables)              # replicate pooled
    data = ad.build_data(analysis, table, None, assignment, ad.CONTROL_NOMINAL, hidden={"rep": ["B"]})
    assert set(data.index_ids % 2) == {1}                                       # replicate A indices only
    stats = grouped_statistics(data, "panels", "curves")
    assert stats.groups[(0, 0)].values["Mean"] == pytest.approx(1.0)          # WT replicate A against itself
    assert len(data) == len(table) // 2


def test_every_level_hidden_shows_them_all():
    table = small_table()
    shown = ad.shown_levels(table.variables, {"genotype": ["WT", "mut"], "rep": ["B", "gone"]})
    assert shown == {"genotype": ("WT", "mut"), "passage": ("1", "2"), "rep": ("A",)}


def test_level_colors_follow_the_variable_not_the_slot():
    table = small_table()
    style = PlotStyle()
    assert ad.default_level_colors(GENOTYPE, style) == {"WT": style.group_color(0), "mut": style.group_color(1)}
    assert len(set(ad.default_level_colors(PASSAGE, style).values())) == 2           # gradient for ordinal
    colors = ad.level_colors(GENOTYPE, style, {"mut": "#123456", "WT": "not a color", "gone": "#ffffff"})
    assert colors == {"WT": style.group_color(0), "mut": "#123456"}
    box = ANALYSES["box"]
    assignment = {"genotype": "groups", "passage": "x", "rep": POOLED}
    colored = PlotStyle(color_variable="genotype", level_colors=tuple(colors.items()))
    data = ad.build_data(box, table, None, assignment, hidden={"genotype": ["WT"]})
    assert colored.color_for(data, groups=0, x=1) == "#123456"                   # mutant keeps its color
    assert PlotStyle().color_for(data, groups=0, x=1) is None
    assert ad.color_problem(box, table.variables, assignment, "genotype") == ""
    assert "pooled" in ad.color_problem(box, table.variables, assignment, "rep")
    line = ANALYSES["line:Mean"]
    assert "colors by Lines" in ad.color_problem(line, table.variables, {"genotype": "lines", "passage": "x",
                                                                         "rep": "x"}, "rep")
    assert "keeps its own colors" in ad.color_problem(ANALYSES["fidelity"], table.variables, assignment, "genotype")


# ----- Stats module on the detected demo ------------------------------------------
def test_stats_window_on_demo(app, library, tmp_path):
    manager = open_manager(library)
    window, controller = open_stats(manager, apply_theme(app))
    try:
        assert len(controller.colonies) > 500 and len(controller.indices) == 96
        for key in ["density", "line:Mean", "line:Kurtosis", "fidelity", "box", "violin", "plate_metrics"]:
            controller.choose_analysis(key)
            assert controller.table_rows(), key
        controller.choose_analysis("box")
        controller.set_option("view", "separate")
        assert controller.table_rows() and len(window.figure.axes) > 1
        controller.set_scheme(ad.CONTROL_NOMINAL)
        controller.choose_analysis("line:Median")
        rows = controller.table_rows()
        assert any(r["Genotype · Medium"] == "Wild type · YPD" and r["Median"] == pytest.approx(1.0, abs=0.2)
                   for r in rows)
        controller.save_table(str(tmp_path / "median.csv"))
        controller.save_figure(str(tmp_path / "median.pdf"))
        assert (tmp_path / "median.csv").stat().st_size > 0 and (tmp_path / "median.pdf").stat().st_size > 0
        assert manager.module_preferences("stats")["scheme"] == ad.CONTROL_NOMINAL
        controller.set_slot("passage", POOLED)
        assert window.slot_problem.text()                       # the line plot needs an x axis
        controller.choose_analysis("plate_metrics")
        controller.set_measure("mean_radius_um")
        assert controller.data.measure == "mean_radius_um" and controller.table_rows()
        assert (manager.library.analyses_folder / "example_analysis.py.txt").is_file()
    finally:
        window.close()
        manager.close()



def test_levels_and_colors_in_the_window(app, library):
    from matplotlib.colors import to_hex
    manager = open_manager(library, "levels")
    window, controller = open_stats(manager, apply_theme(app))
    try:
        controller.choose_analysis("box")
        assert "replicate" not in {v.name for v in controller.variables}       # replicate plates are always pooled
        for name, slot in (("genotype", "groups"), ("passage", "x"), ("medium", POOLED)):
            controller.set_slot(name, slot)
        controller.set_color_by("genotype")
        controller.choose_level_color("genotype", "cdc13", "#aa0000")
        controller.toggle_level("genotype", "WT")
        controller.toggle_level("genotype", "rif1")
        assert controller.data.axes["groups"].labels == ("cdc13-2", "rif1Δ cdc13-2")
        assert "Not shown: Genotype: Wild type, rif1Δ." in window.notes.toPlainText()
        faces = {to_hex(patch.get_edgecolor()) for patch in window.figure.axes[0].patches}
        assert "#aa0000" in faces                                               # cdc13-2 drawn in its color
        assert controller.colors_of("genotype")["rif1_cdc13"] == controller.style.group_color(3)
        controller.toggle_level("genotype", "cdc13")
        controller.toggle_level("genotype", "rif1_cdc13")                     # the last shown level stays
        assert controller.data.axes["groups"].labels == ("rif1Δ cdc13-2",)
        assert not window.color_note.isVisible() or not window.color_note.text()
        controller.choose_analysis("fidelity")
        assert "keeps its own colors" in window.color_note.text()
        prefs = manager.module_preferences("stats")
        assert prefs["hidden_levels"] == {"genotype": ["WT", "rif1", "cdc13"]} and prefs["color_by"] == "genotype"
        assert prefs["level_colors"] == {"genotype": {"cdc13": "#aa0000"}}
        window.close()
        window, controller = open_stats(manager, apply_theme(app))          # choices come back with the project
        assert controller.hidden == {"genotype": ["WT", "rif1", "cdc13"]} and controller.color_by == "genotype"
        controller.show_all_levels("genotype")
        controller.choose_analysis("box")
        assert len(controller.data.axes["groups"]) == 4
    finally:
        window.close()
        manager.close()

def test_subpopulations_in_window(app, library):
    manager = open_manager(library)
    window, controller = open_stats(manager, apply_theme(app))
    try:
        controller.colonies = small_table()                    # a few entries keep the fit quick
        controller.variables = list(controller.colonies.variables)
        controller.choose_analysis("subpopulations")
        deadline = time.time() + 120
        while controller._worker is not None and time.time() < deadline:
            app.processEvents()
            time.sleep(0.02)
        app.processEvents()
        rows = controller.table_rows()
        assert rows and {"median_um", "weight", "k"} <= set(rows[0])
        assert "read_workbook" in window.notes.toPlainText()
        assert window.figure is controller._drawn_figure
        fits = {(r["index"], r["subpopulation"]): r["median_um"] for r in rows}
        analysis = controller.current
        assert analysis.missing(controller.data) == 0                       # every index's fit is kept
        controller.set_slot("rep", "clusters")                              # a display change ...
        assert controller._worker is None                                   # ... redraws without fitting
        assert {(r["index"], r["subpopulation"]): r["median_um"] for r in controller.table_rows()} == fits
        controller.toggle_level("genotype", "mut")                          # hiding indices: still no fit
        assert controller._worker is None and controller.table_rows()
    finally:
        window.close()
        manager.close()


def apply_theme(app):
    from quantacolony.theme import apply_theme as theme
    return theme(app)


# ----- pages and navigation ------------------------------------------------------
def test_project_status_counts(library):
    manager = open_manager(library)
    try:
        status = manager.project_status()
        assert (status.photos, status.photos_cropped, status.plates, status.plates_cropped, status.plates_detected,
                status.indices) == (12, 12, 96, 96, 96, 32)            # 4 genotypes x 2 media x 4 passages, 3 plates each
    finally:
        manager.close()


def test_navigation_home_project_modules(app, library):
    root, project_id = library
    navigator = start(app, settings=Settings(folder=root / "nav"), library=_library(root))
    try:
        assert navigator.screen == "home" and not navigator.manager.is_open
        names = [e.name for e in navigator.controller.entries]
        assert STATS_DEMO_NAME in names
        navigator.open_project(project_id)
        assert navigator.screen == "project"
        label, button = navigator.window.step_widgets["stats"]
        assert button.isEnabled() and "96" in label.text()
        navigator.open_module("stats")
        assert navigator.screen == "stats"
        navigator.window.back_button.click()
        assert navigator.screen == "project"
        navigator.open_module("detection")
        navigator.window.close()                                 # closing a module returns to the project page
        app.processEvents()
        assert navigator.screen == "project"
        for module in ("cropping", "detection"):                 # every module: Back to project, same place
            navigator.open_module(module)
            corner = navigator.window.back_button.mapTo(navigator.window, QPoint(0, 0))
            assert (corner.x(), corner.y()) == (16, 13)
            navigator.window.back_button.click()
            app.processEvents()
            assert navigator.screen == "project"
        assert navigator.window.projects_button.text().endswith("Back to projects")
        navigator.window.projects_button.click()
        assert navigator.screen == "home" and not navigator.manager.is_open
    finally:
        navigator.manager.close()
        navigator.window.close()


def test_plate_metrics_measure_growth_on_demand(app, library):
    manager = open_manager(library, "coverage")
    window, controller = open_stats(manager, apply_theme(app))
    try:
        controller.choose_analysis("plate_metrics")
        controller.set_scheme(ad.RAW)                           # another test may have saved a normalization
        controller.set_measure("growth_coverage")
        assert controller.coverage_ready and manager.coverage_waiting() == 0
        rows = controller.table_rows()
        assert rows and all(0 < r["mean"] < 1 for r in rows)
    finally:
        window.close()
        manager.close()


# ----- the separable range ------------------------------------------------------------
def test_overplated_plates_are_marked_and_left_out(app, tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "Library"))
    manager.open_project(manager.add_tutorial_project())
    window, controller = open_stats(manager, apply_theme(app))
    try:
        assert controller.coverage_ready and [controller.index_label(i) for i in controller.overplated()] == ["100X"]
        controller.choose_analysis("plate_metrics")
        controller.set_slot("dilution_level", "x")
        controller.set_measure("capture_ratio")
        ax = window.figure.axes[0]
        assert any(line.get_linestyle() == "--" and list(line.get_ydata()) == [0.25, 0.25] for line in ax.lines)
        assert "1 below the 25% cutoff" in window.notes.toPlainText()
        assert len(controller.data.axes["x"]) == 10
        controller.set_leave_out(True)
        assert "Left out as overplated (capture ratio below 25%): 1 plate." in window.notes.toPlainText()
        assert not np.any(controller.data.index_ids == controller.overplated()[0])
        controller.choose_analysis("box")                                   # applies to every analysis
        assert controller.data.notes[0].startswith("Left out as overplated")
        assert manager.module_preferences("stats")["leave_out_overplated"] is True
    finally:
        window.close()
        manager.close()



def test_variables_panel_collapses_and_opens_levels_in_a_pop_up(app, library):
    manager = open_manager(library, "panel")
    window, controller = open_stats(manager, apply_theme(app))
    try:
        window.show()
        controller.choose_analysis("box")
        assert not window.variables_collapsed and window.variables_body.isVisibleTo(window)
        window.variables_toggle.click()                                       # collapse
        assert window.variables_collapsed and not window.variables_body.isVisibleTo(window)
        assert window.variables_summary.text().startswith("X axis:") and "pooled:" in window.variables_summary.text()
        assert manager.module_preferences("stats")["variables_collapsed"] is True
        window.variables_toggle.click()
        anchor = window.findChildren(type(window.variables_toggle))[0]
        window.open_levels("Genotype", anchor)
        assert window.levels_popup.isVisible() and window.levels_popup.variable == "Genotype"
        controller.toggle_level("genotype", "WT")                             # the pop-up stays and refills
        assert window.levels_popup.isVisible()
        chips = [b for b in window.levels_popup.findChildren(type(window.variables_toggle)) if b.isCheckable()]
        assert [b.isChecked() for b in chips] == [False, True, True, True]
        assert "1 level hidden" in controller.variables_summary()
    finally:
        window.levels_popup.close()
        window.close()
        manager.close()


def test_menus_on_light_pages_have_their_own_colors():
    from quantacolony.theme.stylesheet import build_light_stylesheet
    from quantacolony.theme.tokens import get_quanta_colony_style
    sheet = build_light_stylesheet(get_quanta_colony_style().light, "Inter", "Raleway")
    assert "#LightWindow QMenu {" in sheet and "QMenu::item:selected" in sheet
