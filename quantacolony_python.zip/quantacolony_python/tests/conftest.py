"""Close every window and run pending deletions before the interpreter exits, so Qt objects
are not destroyed after the QApplication."""

import pytest


@pytest.fixture(scope="session", autouse=True)
def _close_qt_windows():
    yield
    from PySide6.QtCore import QCoreApplication, QEvent
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance()
    if app is None:
        return
    for widget in QApplication.topLevelWidgets():
        if hasattr(widget, "close_guard"):
            widget.close_guard = None                  # no "save this image?" question at teardown
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()
