"""Splitting touching colonies, scoring detection against corrections, and what follows from split
colonies: their storage, the capture ratio and Stats."""

from dataclasses import replace

import numpy as np
import pytest

from quantacolony.core import growth as gr
from quantacolony.core.colony_set import KIND_IRREGULAR, KIND_SPLIT, ColonySet
from quantacolony.core.detection import (DETECTION_VERSION, SPLIT_DETECTION_VERSION, detection_version,
                                          perform_detection)
from quantacolony.core.params import DetectionParams, new_project_detection
from quantacolony.core.scoring import Score, match, score

PARAMS = DetectionParams(level=-0.45, sense=0.9, rmin=4.0, rmax=16.0, maxpix=5000.0)
SPLIT = replace(PARAMS, split=True, split_elongation=0.6, split_pinch=0.15)


def disc(image, cx, cy, r, value=220):
    yy, xx = np.mgrid[:image.shape[0], :image.shape[1]]
    image[(xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2] = value


def ellipse(image, cx, cy, a, b, value=220):
    yy, xx = np.mgrid[:image.shape[0], :image.shape[1]]
    image[((xx - cx) / a) ** 2 + ((yy - cy) / b) ** 2 <= 1] = value


def plate():
    """Known colonies: one alone, a touching pair, a chain of three, an oval single colony."""
    image = np.full((200, 320, 3), 40, np.uint8)
    disc(image, 30, 30, 10)                                   # alone
    disc(image, 90, 40, 11)
    disc(image, 109, 40, 11)                                   # a pair, centers 19 px apart
    for x in (170, 189, 208):
        disc(image, x, 120, 10)                                # a chain of three
    ellipse(image, 270, 60, 14, 9)                            # one oval colony
    return image


def found_near(colonies, x, y, tolerance=4.0):
    return int(np.sum(np.hypot(colonies.centers[:, 0] - x, colonies.centers[:, 1] - y) <= tolerance))


def test_splitting_cuts_touching_colonies_and_leaves_single_ones_whole():
    image = plate()
    whole = perform_detection(image, PARAMS)
    split = perform_detection(image, SPLIT)
    assert found_near(whole, 99.5, 40) == 1 and found_near(whole, 90, 40) == 0       # the pair passes as one colony
    assert found_near(split, 90, 40) == 1 and found_near(split, 109, 40) == 1         # ... and is cut in two
    assert all(found_near(split, x, 120) == 1 for x in (170, 189, 208))               # the chain: three colonies
    assert found_near(split, 30, 30) == 1 and found_near(split, 270, 60) == 1          # alone and oval: whole
    kinds = {(round(x), round(y)): k for (x, y), k in zip(split.centers, split.kinds)}
    assert kinds[(30, 30)] == KIND_IRREGULAR and kinds[(270, 60)] == KIND_IRREGULAR
    assert sum(k == KIND_SPLIT for k in split.kinds) == 5
    for i in range(len(split)):                                 # each outline sits on its own colony
        assert np.allclose(split.boundaries[i].mean(axis=0), split.centers[i], atol=2.5)


def test_a_shallow_waist_needs_a_lower_pinch():
    image = np.full((120, 160, 3), 40, np.uint8)
    disc(image, 70, 60, 12)
    disc(image, 84, 60, 12)                                    # overlapping: the waist dips about 19%
    assert len(perform_detection(image, replace(SPLIT, split_pinch=0.3))) == 1
    assert len(perform_detection(image, replace(SPLIT, split_pinch=0.15))) == 2


def test_splitting_off_is_detection_as_before():
    image = plate()
    assert perform_detection(image, replace(SPLIT, split=False)).centers.tolist() == \
        perform_detection(image, PARAMS).centers.tolist()
    assert detection_version(PARAMS) == DETECTION_VERSION and detection_version(SPLIT) == SPLIT_DETECTION_VERSION
    assert new_project_detection().split and not DetectionParams().split


def test_scoring_counts_what_a_person_corrects():
    reference = ColonySet.from_columns([(90, 40), (109, 40), (30, 30)], [11.0, 11.0, 10.0])
    merged = ColonySet.from_columns([(99.5, 40), (30, 30)], [15.0, 10.0])
    result = score(merged, reference)
    assert result == Score(3, 2, 1) and result.missed == 2 and result.extra == 1 and result.corrections == 3
    assert match(reference, reference) == [(0, 0), (1, 1), (2, 2)]
    assert score(perform_detection(plate(), SPLIT), perform_detection(plate(), SPLIT)).corrections == 0


def test_the_capture_ratio_counts_separate_colonies_only():
    image = plate()
    region = np.ones(image.shape[:2], bool)
    split = perform_detection(image, SPLIT)
    metrics = gr.growth_mask(image, region, split).metrics()
    assert metrics["separate_coverage"] < metrics["colony_coverage"]
    assert metrics["capture_ratio"] == pytest.approx(metrics["separate_coverage"] / metrics["growth_coverage"])
    unmarked = split.subset(np.ones(len(split), bool))
    plain = ColonySet.from_columns(unmarked.centers, unmarked.radii, boundaries=list(unmarked.boundaries))
    same = gr.growth_mask(image, region, plain).metrics()
    assert same["separate_coverage"] == same["colony_coverage"]


def test_split_settings_and_colonies_are_saved_with_the_image(tmp_path):
    from quantacolony.core.session import DetectionSession
    from quantacolony.data import DataManager, Settings, create_library
    from sample_project import create_sample_project
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    create_sample_project(manager)
    try:
        packet = manager.checkout_image(manager.first_index_for_detection())
        session = DetectionSession(packet.record, replace(packet.defaults, split=True, split_pinch=0.2))
        session.initialize_detection()
        manager.commit_detection(session.result())
        saved = manager.checkout_image(packet.record.index_id).saved
        assert saved.params.split and saved.params.split_pinch == pytest.approx(0.2)
        assert saved.detection_version == SPLIT_DETECTION_VERSION
    finally:
        manager.close()


def test_stats_can_leave_split_colonies_out_of_sizes():
    from quantacolony.analyses import data as ad
    from quantacolony.analyses.registry import load_analyses
    from quantacolony.core import stats as st
    variable = st.StatsVariable("g", "Genotype", "nominal", ("WT",), ("WT",), "WT")
    rows = [{"radius_px": 10.0, "radius_um": 100.0, "source": "irregular"},
            {"radius_px": 12.0, "radius_um": 120.0, "source": "split"},
            {"radius_px": 11.0, "radius_um": 110.0, "source": "manual"}]
    table = st.build_colony_table([variable], [(1, {"g": "WT"}, 10.0, rows)])
    assert table.touching.tolist() == [False, True, False]
    density = load_analyses().analyses["density"]
    assignment = ad.default_assignment(density, table.variables)
    assert np.isfinite(ad.build_data(density, table, None, assignment).values).sum() == 3
    assert np.isfinite(ad.build_data(density, table, None, assignment, no_touching=True).values).sum() == 2


def test_scoring_the_tutorial_project():
    from quantacolony.data.tutorial_project import TUTORIAL_FILE
    from quantacolony.evaluation import score_file, table
    plain = {r.label: r.score for r in score_file(TUTORIAL_FILE)}
    assert plain["500X"].corrections == 223 and plain["100X"].corrections == 0       # the saved results, redone
    split = {r.label: r.score for r in score_file(TUTORIAL_FILE, {"split": True, "split_elongation": 0.6,
                                                                  "split_pinch": 0.15})}
    corrected = ("500X", "2000X", "4000X", "8000X", "32000X", "64000X", "128000X")
    assert sum(split[k].missed for k in corrected) < 0.5 * sum(plain[k].missed for k in corrected)
    printed = table(score_file(TUTORIAL_FILE))
    assert printed.splitlines()[0].split()[:2] == ["index", "reference"] and printed.splitlines()[-1].startswith("all")
