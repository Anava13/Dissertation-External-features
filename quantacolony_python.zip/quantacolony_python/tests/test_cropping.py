"""Cropping: model rules, the controller on the synthetic demo project, and the hand-off to Colony Detection."""

import pytest
from PySide6.QtWidgets import QApplication

from quantacolony.app import build
from quantacolony.core import cropping as cp
from quantacolony.data import DataManager, Settings, create_library
from quantacolony.data.demo_project import create_demo_project


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def crop(app, tmp_path, monkeypatch):
    window, controller = build(app, settings=Settings(folder=tmp_path / "s"), library=create_library(tmp_path / "L"),
                               demo_cropping=True)
    monkeypatch.setattr(window, "report", lambda *a: None)
    yield window, controller
    window.close()
    controller.manager.close()


def fill_sections(controller):
    """Genotype by number keys, medium per section: four genotypes x two media on eight sections."""
    genotype, medium = (next(v for v in controller.variables if v.name == n) for n in ("genotype", "medium"))
    controller.select_section(0)
    for k in range(8):
        controller.pick(medium, medium.values[k // 4])
        controller.pick_by_number(k % 4)


def test_odometer_and_duplicates():
    passage = cp.VariableLevels("passage", "Passage", ("25", "50"), ("25", "50"))
    rep = cp.VariableLevels("replicate", "Replicate", ("R1", "R2"), ("R1", "R2"))
    assert cp.step_photo_levels({"passage": "25", "replicate": "R2"}, [passage, rep]) == {"passage": "50",
                                                                                         "replicate": "R1"}
    sections = [{"passage": "25", "replicate": "R1"}, {"passage": "25", "replicate": "R1"}]
    assert set(cp.duplicate_sections(sections, [passage, rep], {})) == {0, 1}
    assert cp.duplicate_sections(sections[:1], [passage, rep], {("25", "R1"): (3, 2)})[0].startswith("Already")


def test_demo_opens_in_cropping(crop):
    window, controller = crop
    assert controller.position == 0 and not controller.can_confirm()
    assert controller.scope["genotype"] == cp.SECTION and controller.scope["passage"] == cp.PHOTO
    layout, sections, saved = controller.current()
    assert layout.section_count == 8 and not saved


def test_commit_and_proposal(crop):
    window, controller = crop
    fill_sections(controller)
    assert controller.can_confirm()
    controller.done_with_photo()
    first = controller.photos[0].photo_id
    assert first in controller.packet.layouts and controller.position == 1
    _, sections, saved = controller.current()
    assert not saved
    assert sections[0]["passage"] == "25" and sections[0]["replicate"] == "R2"      # odometer: replicate fastest
    assert sections[3]["genotype"] == controller.packet.layouts[first][1][3]["genotype"]
    assert controller.can_confirm()
    assert len(controller.manager.unassigned_index_keys()) == 96 - 8


def test_duplicate_blocks_confirm(crop):
    window, controller = crop
    fill_sections(controller)
    controller.done_with_photo()
    passage, rep = (next(v for v in controller.variables if v.name == n) for n in ("passage", "replicate"))
    controller.pick(rep, "R1")                     # same whole-photo levels as photo 1
    assert controller.problems() and not controller.can_confirm()
    assert window.problem_box.isVisibleTo(window)
    controller.open_problem()
    assert controller.position == 0


def test_rotation_keeps_levels_on_the_plate(crop):
    window, controller = crop
    fill_sections(controller)
    layout, sections, _ = controller.current()
    before = {cp.index_key(s, controller.variables): layout.label_point(i) for i, s in enumerate(sections)}
    for _ in range(6):
        controller.rotate(-5)
    layout, sections, _ = controller.current()
    for i, s in enumerate(sections):
        x0, y0 = before[cp.index_key(s, controller.variables)]
        x1, y1 = layout.label_point(i)
        assert abs(x0 - x1) + abs(y0 - y1) < layout.r * 0.6


def test_section_count_and_unused(crop):
    window, controller = crop
    controller.change_count(-1)
    assert controller.current()[0].section_count == 7
    controller.change_count(1)
    assert controller.current()[0].section_count == 8
    controller.toggle_unused()
    assert controller.current()[1][controller.selected] is None


def test_finish_warns_then_opens_detection(crop, monkeypatch):
    window, controller = crop
    fill_sections(controller)
    controller.done_with_photo()
    asked = []
    monkeypatch.setattr(window, "ask_finish", lambda missing, total, examples, unsaved: asked.append(
        (missing, total, examples, unsaved)) or False)
    assert controller.finish() is False
    missing, total, examples, unsaved = asked[0]
    assert (missing, total) == (88, 96) and examples and "·" in examples[0]
    monkeypatch.setattr(window, "ask_finish", lambda *a: True)
    assert controller.finish() is True
    detection_window, detection = controller.next
    assert detection.session.record.mask is not None             # a sector crop with its mask
    detection_window.close()


def test_scope_switch_and_board(crop):
    window, controller = crop
    medium = next(v for v in controller.variables if v.name == "medium")
    controller.set_scope(medium, cp.PHOTO)
    assert medium in controller.photo_variables()
    assert controller.manager.crop_packet().preferences["scope"]["medium"] == cp.PHOTO
    controller.set_view(medium, cp.PAGES)
    assert window.board.board.pages == ["Medium"]
    fill_sections(controller)                      # medium is per photo now: genotypes repeat on the photo
    controller.set_page(medium, medium.values[1])
    board = window.board.board
    assert any(cell.state == "duplicate" for row in board.cells for cell in row)
    assert not controller.can_confirm()


def test_photos_needing_cropping(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    create_demo_project(manager)
    assert manager.photos_needing_cropping() == 12
    manager.close()
