"""New Project wizard: the draft's checks and specifications, and the controller creating a project."""

import pytest
from PySide6.QtWidgets import QApplication

from quantacolony.core import new_project as npm
from quantacolony.data import DataManager, Settings, create_library
from quantacolony.data.demo_project import draw_plate
from quantacolony.gui.new_project import NewProjectController, NewProjectWindow
from quantacolony.theme import apply_theme


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def photos(tmp_path):
    paths = []
    for n in (10, 2, 1):
        path = tmp_path / f"Plate_{n}.jpg"
        path.write_bytes(draw_plate(n, 0.0, [1.0] * 8))
        paths.append(path)
    return paths


def test_draft_checks(photos):
    draft = npm.example_draft(taken=["Taken"])
    assert not draft.step_ok(0)                                     # no name, no photos
    draft.name = "Taken"
    draft.add_photos(photos)
    assert draft.name_problem() and draft.suggested_name() == "Taken_1"
    draft.name = "Fresh"
    assert draft.step_ok(0)
    draft.sort_photos()
    assert [p.name for p in draft.photos] == ["Plate_1.jpg", "Plate_2.jpg", "Plate_10.jpg"]
    genotype = draft.variables[0]
    genotype.values[1] = "strain 1"
    assert "repeats" in draft.variable_error(0) and draft.bad_levels(0) == {0, 1}
    genotype.values[1] = "rif1Δ"
    passage = npm.VariableDraft("Passage")
    passage.regenerate("ordinal", "Generations", 3)
    assert passage.values == ["1", "2", "3"] and passage.unit == "gen"
    passage.values[2] = "late"
    draft.variables.append(passage)
    assert "numbers" in draft.variable_error(2)
    passage.values[2] = "3"
    assert draft.variables_ok() and draft.index_count == 2 * 3 and draft.plate_count == 2 * 3 * 2  # 2 plates each
    draft.dish_mm = "abc"
    assert not draft.step_ok(3)


def test_specifications():
    draft = npm.example_draft()
    draft.variables[0].name = "Strain name"
    specs, plate, extra = draft.specifications()
    assert specs[0].name == "strain_name" and specs[0].display_name == "Strain name"
    assert specs[0].levels[0].is_control and not specs[1].levels[0].is_control
    assert plate == {"type": "circular", "scale": "dish", "sections": 4, "dish_mm": 90.0}
    assert extra["variable_details"]["strain_name"]["preset"] == "Strain / genotype"
    single = npm.ProjectDraft(name="One", photos=[npm.Path("x.jpg")], sections=1)
    assert single.single_image and single.variables_ok()
    assert single.specifications()[0][0].levels[0].value == "Default"


def test_wizard_creates_project(app, tmp_path, photos):
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    window = NewProjectWindow(apply_theme(app))
    controller = NewProjectController(manager, window)
    created = []
    controller.created.connect(created.append)
    try:
        assert not window.next_button.isEnabled()
        controller.add_photos([str(p) for p in photos])
        controller.set_name("Wizard test")
        controller.sort_photos()
        controller.next()
        controller.set_plate(sections=6)
        controller.next()
        controller.set_count(0, 1)                                  # three strains
        controller.edit_level(0, 1, "rif1Δ")
        controller.add_variable()
        controller.set_kind(2, "ordinal")
        controller.edit_variable(2, name="Passage")
        controller.next()
        controller.next()
        assert window.next_button.text() == "Create project"
        controller.next()
        assert created and manager.is_open
        info = manager.project_info()
        assert info.name == "Wizard test" and [v.display_name for v in info.variables] == ["Genotype", "Replicate",
                                                                                         "Passage"]
        assert manager.crop_packet().plate["sections"] == 6
        assert [p.file_name for p in manager.crop_packet().photos] == ["Plate_1.jpg", "Plate_2.jpg", "Plate_10.jpg"]
        status = manager.project_status()
        assert (status.indices, status.plates) == (0, 3 * 6)        # nothing cropped: three photos of six sections
        assert manager._structure.combination_count() == 3 * 2       # the replicate is not a factor
        assert manager.detection_start()[1]                         # first image estimates its settings
        assert manager.detection_start()[0].split                    # new projects split touching colonies
    finally:
        window.close()
        manager.close()


def test_name_box_templates_keep_typed_levels():
    variable = npm.VariableDraft("Variable 2")
    variable.set_count(3)
    variable.values[1] = "rif1Δ"                                    # typed by the user
    variable.apply_template("Strain / genotype")
    assert variable.name == "Genotype" and variable.preset == "Strain / genotype"
    assert variable.values == ["Strain 1", "rif1Δ", "Strain 3"]
    variable.name = "Background"                                    # a typed name survives a kind change
    variable.change_kind("ordinal")
    assert variable.name == "Background" and variable.unit == "gen"
    assert variable.values == ["1", "rif1Δ", "3"]
    assert [shown for shown, _ in npm.name_suggestions("nominal")] == ["Genotype", "Medium", "Treatment"]
    fresh = npm.VariableDraft("Variable 3")
    fresh.change_kind("replicate")
    assert fresh.name == "Biological replicate" and fresh.values == ["1", "2"]


def test_name_box_in_the_wizard(app, tmp_path, photos):
    window = NewProjectWindow(apply_theme(app))
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "L"))
    controller = NewProjectController(manager, window)
    try:
        controller.add_photos([str(p) for p in photos])
        controller.set_name("Names")
        controller.next()
        controller.next()
        controller.add_variable()
        controller.edit_level(2, 0, "YPD")
        controller.set_preset(2, "Medium")
        variable = controller.draft.variables[2]
        assert variable.name == "Medium" and variable.values == ["YPD", "Medium 2"]
        controller.edit_variable(2, name="Media")
        assert controller.draft.variables[2].name == "Media" and controller.draft.variables[2].values[1] == "Medium 2"
        window.grab().save(str(tmp_path / "variables.png"))
    finally:
        window.close()
        manager.close()
