"""Colony Detection settings and corrections, the end-of-detection prompt, help pages, and the home and
project pages (progress, summary, export choices)."""

import pytest
from PySide6.QtWidgets import QApplication

from quantacolony.core.colony_set import KIND_MANUAL
from quantacolony.core.params import DARK, LIGHT, DetectionParams, level_from_threshold, threshold_from_level
from quantacolony.core.session import DetectionSession
from quantacolony.data import DataManager, Settings, create_library
from sample_project import create_sample_project, sample_image
from quantacolony.gui.help import HELP_FOLDER, TITLES, HelpWindow
from quantacolony.gui.launch import open_detection
from quantacolony.theme import apply_theme


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def manager(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    create_sample_project(manager)
    yield manager
    manager.close()


@pytest.fixture()
def detection(app, manager):
    window, controller = open_detection(manager, apply_theme(app))
    yield window, controller
    window.close_guard = None
    window.close()


# ----- colony color and threshold ------------------------------------------
@pytest.mark.parametrize("level", [0.45, 0.2, -0.65, -0.3])
def test_threshold_round_trip(level):
    polarity, threshold = threshold_from_level(level)
    assert polarity == (DARK if level >= 0 else LIGHT)
    assert level_from_threshold(polarity, threshold) == pytest.approx(level)


def test_color_toggle_keeps_the_threshold_and_flips_the_level(detection):
    window, controller = detection
    assert window.polarity() == LIGHT and window.level_row.value() == pytest.approx(0.35)   # saved level −0.65
    window.polarity_buttons[DARK].click()                       # as the user would
    controller.handle_backup_and_detection()                    # what the debounce timer calls
    assert controller.session.params.level == pytest.approx(0.35)
    controller.undo()
    assert controller.session.params.level == pytest.approx(-0.65) and window.polarity() == LIGHT


def test_radius_arrows_step_the_value(detection):
    window, controller = detection
    edited = []
    window.rmax_field.valueEdited.connect(edited.append)
    before = window.rmax_field.value()
    window.rmax_field.spin.stepUp()
    assert edited == [before + 1]


# ----- estimated settings ---------------------------------------------------
def test_estimate_settings_is_undoable(detection):
    window, controller = detection
    before = controller.session.params
    controller.estimate_settings()
    estimated = controller.session.params
    assert estimated != before and estimated.level < 0             # light colonies on this plate
    assert estimated.rmin >= 2 and estimated.rmax > estimated.rmin
    assert 25 <= len(controller.session.colonies) <= 50            # hand-tuned settings find 33
    controller.undo()
    assert controller.session.params == before


def test_first_image_of_a_wizard_project_estimates_its_settings(manager):
    packet = manager.checkout_image(manager.first_index_for_detection())
    from quantacolony.gui.controller import session_from_packet
    estimated = session_from_packet(type(packet)(packet.record, None, DetectionParams(), estimate=True))
    plain = session_from_packet(type(packet)(packet.record, None, DetectionParams(), estimate=False))
    assert estimated.params.level < 0 and plain.params == DetectionParams()


# ----- hand-drawn colonies may overlap ---------------------------------------
def test_drawn_colonies_may_overlap_but_region_duplicates_are_skipped():
    image, px_per_mm, params = sample_image()
    from quantacolony.core.record import ImageRecord
    import numpy as np
    record = ImageRecord(1, "x", (), image, np.ones(image.shape[:2], bool), px_per_mm)
    session = DetectionSession(record, params)
    session.initialize_detection()
    x, y = session.colonies.centers[0]
    r = float(session.colonies.radii[0])
    drawn = DetectionSession.circles_to_colonies([(x, y, r), (x + 1, y, r)])
    assert session.add_colonies(drawn, skip_overlapping=False) == 2
    assert sum(kind == KIND_MANUAL for kind in session.colonies.kinds) == 2
    assert session.add_colonies(drawn) == 0                        # as Detect in a region treats candidates


def test_add_colonies_mode_keeps_overlapping_circles(detection):
    window, controller = detection
    from quantacolony.core.drawing import DrawnCircle
    controller.dropdown_changed("AddIndividualColonies")
    x, y = controller.session.colonies.centers[0]
    before = len(controller.session.colonies)
    controller.pending_circles.append(DrawnCircle(float(x), float(y), 5.0))
    controller.add_selected_colonies_button_pushed()
    assert len(controller.session.colonies) == before + 1


# ----- end of detection ------------------------------------------------------
def test_all_detected_offers_stats(detection, monkeypatch):
    window, controller = detection
    asked, went = [], []
    monkeypatch.setattr(window, "ask_all_detected", lambda count: asked.append(count) or "stats")
    controller.leave_to = went.append
    assert controller.im_satisfied_pushed()                         # the sample has a single index
    assert asked == [1] and went == ["stats"]


def test_all_detected_without_navigator_only_reports(detection, monkeypatch):
    window, controller = detection
    monkeypatch.setattr(window, "ask_all_detected", lambda count: pytest.fail("no prompt without a navigator"))
    assert controller.im_satisfied_pushed()


# ----- help ---------------------------------------------------------------------
def test_every_help_page_exists_and_renders(app):
    for topic in TITLES:
        assert (HELP_FOLDER / f"{topic}.html").is_file()
        window = HelpWindow(topic)
        assert TITLES[topic] in window.browser.toPlainText()
        window.close()


# ----- home and project pages -------------------------------------------------
def test_home_page_progress_summary_and_exports(app, manager, tmp_path, monkeypatch):
    from quantacolony.gui.home import HomeController, HomeWindow
    packet = manager.checkout_image(manager.first_index_for_detection())
    session = DetectionSession(packet.record, packet.defaults)
    session.initialize_detection()
    manager.commit_detection(session.result())
    project_id = manager.project_id
    manager.close()
    window = HomeWindow(apply_theme(app))
    controller = HomeController(manager, window, can_create=True)
    try:
        progress = window.tree.topLevelItem(0).data(1, 0x0100 + 1)
        assert progress == (1, 0, 1)
        assert window.summary_progress_text.text().startswith("1 of 1 plates detected")
        assert window.tiles[3].number.text() == str(len(session.colonies))
        assert not window.thumbnail.pixmap().isNull()
        monkeypatch.setattr(window, "report", lambda *args: None)
        controller.export_selected(str(tmp_path / "copy.qcproj"), kind="file")
        assert (tmp_path / "copy.qcproj").is_file()
        controller.export_selected(str(tmp_path / "look"), kind="folder")
        assert (tmp_path / "look" / "index.html").is_file() and not manager.is_open
        assert manager.list_backups(project_id) and len(manager.list_backups(project_id)) == 1   # export: no backup
    finally:
        window.close()



def test_home_page_folders_and_trash(app, manager, monkeypatch):
    from PySide6.QtCore import Qt
    from quantacolony.gui.home import HomeController, HomeWindow
    project_id = manager.project_id
    manager.close()
    copy = manager.import_project_file(manager.library.project_path(project_id))
    window = HomeWindow(apply_theme(app))
    controller = HomeController(manager, window, can_create=True)
    monkeypatch.setattr(window, "report", lambda *args: None)
    try:
        window.tree.clearSelection()
        controller.new_folder("Lab")
        lab = window.selected_item()[1]
        controller.new_folder("Rif1")                                   # inside the selected folder
        rif1 = window.selected_item()[1]
        controller.drop([("project", project_id)], rif1)                # dragged onto Rif1
        top = window.tree.topLevelItem(0)
        assert top.text(0) == "Lab" and top.child(0).text(0) == "Rif1"
        assert top.child(0).child(0).data(0, Qt.UserRole) == ("project", project_id)
        assert top.data(1, Qt.UserRole + 1) == top.child(0).child(0).data(1, Qt.UserRole + 1)   # folders add up
        controller.refresh(("folder", lab))
        assert window.summary_dates.text() == "Folder · 1 project · 1 folder"
        assert window.tiles[1].caption.text() == "projects" and not window.open_button.isEnabled()
        controller.refresh(("folder", rif1))
        controller.rename_selected("Rif1 lineages")
        assert window.tree.topLevelItem(0).child(0).text(0) == "Rif1 lineages"
        controller.refresh(("folder", lab))
        controller.delete_selected(confirmed=True)
        assert window.trash_button.text() == "Trash (1)"
        assert [window.tree.topLevelItem(i).data(0, Qt.UserRole) for i in range(window.tree.topLevelItemCount())] \
            == [("project", copy)]
        (row,) = controller._trash_rows()
        assert row[1] == "Lab" and row[2].startswith("Folder · 1 folder · 1 project")
        controller.restore_trash(row[0])
        controller.refresh()
        assert window.trash_button.text() == "Trash" and window.tree.topLevelItem(0).text(0) == "Lab"
        controller.refresh(("project", copy))
        controller.delete_selected(confirmed=True)
        controller.empty_trash(confirmed=True)
        assert manager.list_trash() == [] and copy not in manager.library.project_ids()
        window.tree.topLevelItem(0).setExpanded(True)                   # remembered on this computer
        assert lab in manager.settings.expanded_folders
    finally:
        window.close()

def test_project_page_numbers_and_bars(app, manager):
    from quantacolony.gui.project_page import ProjectController, ProjectWindow
    window = ProjectWindow(apply_theme(app), "Sample")
    ProjectController(manager, window)
    try:
        numbers = [tile.number.text() for tile in window.tiles]
        assert numbers == ["1", "1 of 1", "0 of 1", "0", "0"]
        assert window.step_bars["cropping"].total == 1 and window.step_bars["detection"].total == 1
    finally:
        window.close()


# ----- growth coverage ---------------------------------------------------------------
def _sample_colonies():
    import numpy as np
    from quantacolony.core.detection import perform_detection
    image, _, params = sample_image()
    return image, np.ones(image.shape[:2], bool), perform_detection(image, params).with_ids(1)


def test_growth_finds_held_out_colonies_and_counts_union_once():
    import numpy as np
    from quantacolony.core import growth as gr
    image, region, colonies = _sample_colonies()
    result = gr.growth_mask(image, region, colonies)
    metrics = result.metrics()
    assert result.supervised and 0 < metrics["colony_coverage"] < metrics["growth_coverage"] < 1
    assert metrics["capture_ratio"] == pytest.approx(metrics["colony_coverage"] / metrics["growth_coverage"])
    assert not (result.growth & ~result.growable).any() and (result.growth | ~result.colonies).all()
    check = gr.held_out_check(image, region, colonies)
    assert check["colony_recall"] > 0.9                             # colonies it was not taught are found
    doubled = colonies.subset(np.r_[np.arange(len(colonies)), [0]]) if hasattr(colonies, "subset") else colonies
    union = gr.colony_union(region.shape, colonies)
    assert gr.colony_union(region.shape, doubled).sum() == union.sum()   # overlaps count once



def crowding_plate(dilution):
    """The 100X or 500X plate of the wild-type dilution series: crop, region and colonies (outlines kept)."""
    import io
    from pathlib import Path
    import numpy as np
    from PIL import Image
    from quantacolony.core.colony_set import ColonySet
    f = np.load(Path(__file__).parent / "golden" / "crowding_100x_500x.npz")
    image = np.asarray(Image.open(io.BytesIO(f[f"image_{dilution}"].tobytes())))
    shape = tuple(f[f"shape_{dilution}"])
    region = np.unpackbits(f[f"mask_{dilution}"])[:shape[0] * shape[1]].reshape(shape).astype(bool)
    counts = f[f"outline_counts_{dilution}"]
    outlines = np.split(f[f"outline_points_{dilution}"].astype(float), np.cumsum(counts)[:-1])
    colonies = ColonySet.from_columns(f[f"centers_{dilution}"], f[f"radii_{dilution}"],
                                      boundaries=[o if len(o) else None for o in outlines])
    return image, region, colonies


def test_capture_ratio_separates_the_overplated_plate():
    """A confluent lawn far from every marked colony is growth, not agar: the 100X plate falls below
    the 25% capture ratio cutoff and the 500X plate stays above it (dissertation, dilution series)."""
    from quantacolony.core import growth as gr
    overplated = gr.growth_mask(*crowding_plate("100")).metrics()
    separable = gr.growth_mask(*crowding_plate("500")).metrics()
    assert overplated["capture_ratio"] < 0.25 < separable["capture_ratio"]
    assert overplated["growth_coverage"] > 0.40                       # the dense mass counts as growth

def test_growth_ignores_thin_bright_lines_and_handles_no_colonies():
    import numpy as np
    from quantacolony.core import growth as gr
    from quantacolony.core.colony_set import ColonySet
    rng = np.random.default_rng(1)
    image = np.full((200, 200, 3), 60, np.uint8) + rng.integers(0, 6, (200, 200, 3)).astype(np.uint8)
    yy, xx = np.mgrid[:200, :200]
    centers = [(50, 50), (150, 60), (60, 150), (140, 140), (100, 100), (30, 120)]
    for cy, cx in centers:
        image[(yy - cy) ** 2 + (xx - cx) ** 2 <= 36] = 220
    image[:, 180:182] = 220                                          # a scratch: bright, 2 px wide
    region = np.ones((200, 200), bool)
    colonies = ColonySet.from_columns([(x, y) for y, x in centers[:5]], [6.0] * 5)
    result = gr.growth_mask(image, region, colonies)
    assert result.growth[100, 181] == False                          # noqa: E712 (the scratch is not growth)
    assert result.growth[30, 120]                                    # the unmarked colony is found
    bare = gr.growth_mask(image, region, ColonySet.empty())
    assert not bare.supervised and bare.growth[50, 50]


def test_coverage_is_derived_cached_and_offered_to_stats(manager, tmp_path):
    packet = manager.checkout_image(manager.first_index_for_detection())
    session = DetectionSession(packet.record, packet.defaults)
    session.initialize_detection()
    manager.commit_detection(session.result())
    index_id = packet.record.index_id
    assert manager.coverage_waiting() == 1
    first = manager.request_derived("plate_coverage", index_id)
    assert manager.request_derived("plate_coverage", index_id).from_cache and manager.coverage_waiting() == 0
    assert 0 < first.rows[0]["growth_coverage"] < 1
    table = manager.index_table()
    assert table.measures["growth_coverage"][0] == pytest.approx(first.rows[0]["growth_coverage"])
    folder = manager.export_project(tmp_path / "look")
    assert next((folder / "indices").iterdir()).joinpath("growth.png").is_file()
    assert "growth_coverage" in (folder / "summary.csv").read_text(encoding="utf-8").splitlines()[0]


def test_show_growth_in_detection(detection):
    window, controller = detection
    window.growth_switch.setChecked(True)                            # measures and tints at once
    assert window.growth_value.text() != "–" and window.canvas._overlay_item is not None
    window.growth_switch.setChecked(False)
    assert window.canvas._overlay_item is None


# ----- exports on Windows: refused writes ------------------------------------------------
def test_rename_is_retried_while_another_program_holds_the_file(tmp_path, monkeypatch):
    from pathlib import Path
    from quantacolony.data import exports
    monkeypatch.setattr(exports, "REPLACE_WAIT_S", 0.0)
    real, calls = Path.replace, {"n": 0}

    def busy_then_free(self, target):
        calls["n"] += 1
        if calls["n"] < 3:
            raise PermissionError(13, "The process cannot access the file", str(self))
        return real(self, target)

    monkeypatch.setattr(Path, "replace", busy_then_free)
    path = exports.write_text("ok", tmp_path / "a.txt")
    assert path.read_text() == "ok" and calls["n"] == 3 and not (tmp_path / "a.txt.tmp").exists()


def test_a_refused_folder_is_reported_before_any_work(manager, tmp_path, monkeypatch):
    from pathlib import Path
    from quantacolony.data.exports import ExportBlocked
    real = Path.write_bytes

    def refuse(self, data):
        if self.name == ".quantacolony-write-test":
            raise PermissionError(13, "Permission denied", str(self))
        return real(self, data)

    monkeypatch.setattr(Path, "write_bytes", refuse)
    project_id = manager.project_id
    manager.close()
    with pytest.raises(ExportBlocked, match="Controlled folder access"):
        manager.export_browsable_copy(project_id, tmp_path / "Documents" / "copy")
    assert not manager.is_open


def test_finish_image_saves_even_when_the_csv_export_is_refused(detection, monkeypatch):
    window, controller = detection
    def refuse(index_id, path=None):
        raise PermissionError(13, "Permission denied", "C:/Users/Alex/Documents/QuantaColony Exports/x.csv")
    monkeypatch.setattr(controller.data_manager, "export_colonies_csv", refuse)
    controller.session.delete_colonies(controller.session.colonies.ids[:1])
    assert controller.im_satisfied_pushed(advance=False)
    assert controller.session.undo_depth() == 0 and controller.session.loaded_revision >= 1


# ----- popups play the sound of their purpose ------------------------------------------------
def test_popups_play_the_sound_of_their_kind(app, monkeypatch):
    from PySide6.QtCore import QTimer
    from quantacolony.gui import dialogs
    played = []
    monkeypatch.setattr(dialogs, "play_sound", lambda kind: played.append(kind))

    def press(key):
        def click():
            for widget in app.topLevelWidgets():
                if isinstance(widget, dialogs.MessageDialog) and widget.isVisible():
                    if key:
                        widget.buttons[key].click()
                    else:
                        widget.reject()
        QTimer.singleShot(50, click)

    press("Yes")
    assert dialogs.confirm(None, "Move the library?", "Move it anyway?")
    press("")                                                   # closed with the window's X: the safe answer
    assert dialogs.show_message(None, dialogs.QUESTION, "Save this image?", "", [("cancel", "Cancel"),
                                                                                ("save", "Save")]) == ""
    press("ok")
    dialogs.notify(None, dialogs.SUCCESS, "Copy saved", "Saved")
    press("ok")
    dialogs.notify(None, dialogs.ERROR, "Could not export", "Denied")
    assert played == ["question", "question", "success", "error"]


def test_play_sound_uses_the_windows_scheme(monkeypatch):
    import sys
    import types
    from quantacolony.gui import dialogs
    calls = []
    fake = types.SimpleNamespace(SND_ALIAS=1, SND_ASYNC=2, SND_NODEFAULT=4,
                                 PlaySound=lambda alias, flags: calls.append(alias))
    monkeypatch.setattr(sys, "platform", "win32")
    monkeypatch.setitem(sys.modules, "winsound", fake)
    for kind in dialogs.KINDS:
        dialogs.play_sound(kind)
    assert calls == ["Notification.Default", "Notification.Default", "SystemExclamation", "SystemHand"]


def test_dialogs_take_the_look_of_their_window(app):
    from quantacolony.gui import dialogs
    from quantacolony.gui.home import HomeWindow
    home = HomeWindow(apply_theme(app))
    light = dialogs.MessageDialog(home, dialogs.SUCCESS, "Copy saved", "Saved")
    dark = dialogs.MessageDialog(None, dialogs.ERROR, "Could not save", "Denied")
    assert light.objectName() == "LightWindow" and dark.objectName() == "MessageDialog"
    for widget in (light, dark, home):
        widget.close()


def test_first_start_puts_the_tutorial_project_in_a_new_library(app, tmp_path):
    from quantacolony.app import start
    from quantacolony.data import DataManager, Settings, create_library
    library = create_library(tmp_path / "Library")
    navigator = start(app, settings=Settings(folder=tmp_path / "s"), library=library)
    manager = navigator.manager
    assert [e.name for e in manager.list_projects()] == ["Crowding"] and not manager.is_open
    navigator.window.close()
    manager.delete_projects([manager.list_projects()[0].project_id])
    manager.empty_trash()
    again = start(app, settings=Settings(folder=tmp_path / "s"), library=library)     # removed on purpose: stays gone
    assert again.manager.list_projects() == []
    again.window.close()


def test_tutorial_steps_check_the_screen(app, tmp_path):
    from quantacolony.app import start
    from quantacolony.core.tutorial import STEPS
    from quantacolony.data import Settings, create_library
    navigator = start(app, settings=Settings(folder=tmp_path / "s"), library=create_library(tmp_path / "Library"))
    try:
        navigator.start_tutorial()
        tutorial = navigator.tutorial
        assert tutorial.step.key == "open" and "Waiting" in tutorial.window.status.text()
        navigator.open_project(navigator.manager.list_projects()[0].project_id)
        tutorial.poll()
        assert "open" in tutorial.done and tutorial.window.finding.isVisible()
        tutorial.next()
        navigator.open_module("cropping")
        navigator.controller.open_photo(7)
        tutorial.poll()
        assert "dish" in tutorial.done
        tutorial.next()
        navigator.window.close()
        app.processEvents()
        navigator.open_module("detection")
        detection = navigator.controller
        ids = {i.labels[0].value: i.index_id for i in navigator.manager.project_info().indices}
        for key, value in (("sparse", "128000"), ("crowded", "500")):
            assert tutorial.step.key == key
            detection.open_index(ids[value])
            tutorial.poll()
            if key == "crowded":
                assert "crowded" not in tutorial.done                     # splitting is still off
                navigator.window.split_switch.setChecked(True)
                detection._detection_timer.stop()
                detection.handle_backup_and_detection()
                assert detection.session.params.split
                assert any(k == "split" for k in detection.session.colonies.kinds)
                tutorial.poll()
            assert key in tutorial.done
            tutorial.next()
        navigator.window.close_guard = None                               # leave without the save question
        navigator.window.close()
        app.processEvents()
        navigator.open_module("stats")
        stats = navigator.controller
        assert tutorial.step.key == "size" and "size" not in tutorial.done
        stats.choose_analysis("box")
        stats.set_slot("dilution_level", "x")
        tutorial.poll()
        assert "size" in tutorial.done
        tutorial.next()
        stats.choose_analysis("plate_metrics")
        stats.set_slot("dilution_level", "x")
        stats.set_measure("colony_count")
        tutorial.poll()
        tutorial.next()
        stats.set_measure("capture_ratio")
        tutorial.poll()
        tutorial.next()
        stats.set_leave_out(True)
        tutorial.poll()
        assert {"count", "capture", "leave_out"} <= tutorial.done
        assert navigator.manager.settings.tutorial_step == "leave_out"           # kept on this computer
        tutorial.go(len(STEPS) - 1)
        assert tutorial.window.next_button.text() == "Finish" and tutorial.window.finding.isVisible()
        tutorial.next()
        assert navigator.manager.settings.tutorial_done == [] and navigator.tutorial is None
    finally:
        navigator.close_tutorial()
        navigator.window.close()
        navigator.manager.close()
