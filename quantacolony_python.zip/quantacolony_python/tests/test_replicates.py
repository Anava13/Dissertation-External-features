"""Replicate plates: a replicate variable numbers the interchangeable plates of an index instead of
being a factor of the design (Qt-free)."""

import io

import numpy as np
import pytest
from PIL import Image

from quantacolony.core import cropping as cp
from quantacolony.core import new_project as npm
from quantacolony.core.selection import default_matched
from quantacolony.core.stats import StatsVariable
from quantacolony.data import DataManager, ProjectError, Settings, create_library
from quantacolony.data.packets import LevelSpec, VariableSpec
from quantacolony.data.store import catalog

WHOLE = {"kind": "circular", "cx": 50.0, "cy": 50.0, "r": 40.0, "cuts": []}
HALVES = {"kind": "circular", "cx": 50.0, "cy": 50.0, "r": 40.0, "cuts": [0.0, 180.0]}


def png() -> bytes:
    buffer = io.BytesIO()
    Image.fromarray(np.full((100, 100, 3), 120, np.uint8)).save(buffer, format="PNG")
    return buffer.getvalue()


def design(replicate: bool = True):
    variables = [VariableSpec("genotype", "nominal", (LevelSpec("wt", is_control=True), LevelSpec("mut")), "Genotype"),
                 VariableSpec("passage", "ordinal", (LevelSpec("1"), LevelSpec("2")), "Passage")]
    if replicate:
        variables.append(VariableSpec("replicate", "replicate", (LevelSpec("1"), LevelSpec("2")), "Replicate"))
    return variables


@pytest.fixture()
def manager(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    from quantacolony.core.params import DetectionParams
    manager.create_project("Reps", design(), DetectionParams(), plate={"type": "circular", "sections": 1})
    yield manager
    manager.close()


def plates(manager):
    """{(genotype, passage): sorted replicate numbers} over plates with a region."""
    found = {}
    for index in manager.project_info().indices:
        if index.has_region:
            levels = {label.variable: label.value for label in index.labels}
            found.setdefault((levels["Genotype"], levels["Passage"]), []).append(levels["Replicate"])
    return {key: sorted(values, key=int) for key, values in found.items()}


def test_sections_with_the_same_levels_are_plates_of_one_index(manager):
    photos = [manager.add_photo(png(), 10.0, f"p{i}.png") for i in range(4)]
    wt1 = {"genotype": "wt", "passage": "1"}
    manager.commit_photo(photos[0], HALVES, [dict(wt1), dict(wt1)])           # two plates on one photo
    manager.commit_photo(photos[1], WHOLE, [dict(wt1)])                       # a third: a new number
    manager.commit_photo(photos[2], WHOLE, [{"genotype": "mut", "passage": "2"}])
    assert plates(manager) == {("wt", "1"): ["1", "2", "3"], ("mut", "2"): ["1"]}
    replicate = next(v for v in manager.project_info().variables if v.type == "replicate")
    assert [lv.value for lv in replicate.levels] == ["1", "2", "3"]

    saved = manager.crop_packet().layouts[photos[0]][1]                       # numbers are written back
    assert sorted(s["replicate"] for s in saved) == ["1", "2"]
    ids_before = {i.index_id for i in manager.project_info().indices}
    manager.commit_photo(photos[0], HALVES, saved)                            # saving again keeps them
    manager.commit_photo(photos[1], WHOLE, manager.crop_packet().layouts[photos[1]][1])
    assert {i.index_id for i in manager.project_info().indices} == ids_before
    assert plates(manager)[("wt", "1")] == ["1", "2", "3"]

    status = manager.project_status()
    assert (status.plates_cropped, status.indices, status.plates) == (4, 2, 4 + 1)  # one photo still to crop
    assert manager.crop_packet().replicate == "replicate"
    assert [v.name for v in manager.crop_packet().variables] == ["genotype", "passage"]


def test_a_proposal_without_numbers_never_takes_a_plate_from_another_photo(manager):
    a, b = manager.add_photo(png(), 10.0, "a.png"), manager.add_photo(png(), 10.0, "b.png")
    manager.commit_photo(a, WHOLE, [{"genotype": "wt", "passage": "1"}])
    stolen = {"genotype": "wt", "passage": "1", "replicate": "1"}             # copied from photo a
    manager.commit_photo(b, WHOLE, [stolen])
    assert plates(manager)[("wt", "1")] == ["1", "2"]
    assert manager.crop_packet().layouts[b][1][0]["replicate"] == "2"


def test_removing_a_section_frees_nothing_it_does_not_own(manager):
    photo = manager.add_photo(png(), 10.0, "a.png")
    manager.commit_photo(photo, HALVES, [{"genotype": "wt", "passage": "1"}, {"genotype": "wt", "passage": "1"}])
    saved = manager.crop_packet().layouts[photo][1]
    manager.commit_photo(photo, HALVES, [saved[0], None])
    assert plates(manager)[("wt", "1")] == [saved[0]["replicate"]]


def test_without_a_replicate_variable_a_repeated_index_is_refused(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    from quantacolony.core.params import DetectionParams
    manager.create_project("No reps", design(replicate=False), DetectionParams())
    photo = manager.add_photo(png(), 10.0, "a.png")
    with pytest.raises(ProjectError, match="repeats"):
        manager.commit_photo(photo, HALVES, [{"genotype": "wt", "passage": "1"}, {"genotype": "wt", "passage": "1"}])
    manager.close()


def test_one_replicate_variable_at_most(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    from quantacolony.core.params import DetectionParams
    two = design() + [VariableSpec("tech", "replicate", (LevelSpec("1"),), "Technical")]
    with pytest.raises(ProjectError, match="at most one replicate"):
        manager.create_project("Two", two, DetectionParams())
    manager.close()


def test_add_index_numbers_the_plate_itself(manager):
    first = manager.add_index({"genotype": "wt", "passage": "2"})
    second = manager.add_index({"genotype": "wt", "passage": "2", "replicate": None})
    labels = {i.index_id: {l.variable: l.value for l in i.labels} for i in manager.project_info().indices}
    assert (labels[first]["Replicate"], labels[second]["Replicate"]) == ("1", "2")


def test_the_design_leaves_the_replicate_out(manager):
    assert manager._structure.combination_count() == 4                     # 2 genotypes x 2 passages
    assert [v.kind for v in manager.stats_variables()] == ["nominal", "ordinal"]
    entry = catalog.summarize(manager.project_id, manager.project_path)
    assert entry.index_count == 0 and entry.variable_count == 3


def test_progress_counts_plates_in_the_project_list(manager):
    photos = [manager.add_photo(png(), 10.0, f"p{i}.png") for i in range(3)]
    manager.commit_photo(photos[0], HALVES, [{"genotype": "wt", "passage": "1"}, {"genotype": "wt", "passage": "1"}])
    manager.close()
    path = manager.library.project_path(manager.settings.last_project_id)
    entry = catalog.summarize(manager.settings.last_project_id, path)
    assert (entry.cropped_count, entry.plate_count, entry.index_count) == (2, 2 + 2, 1)


def test_boards_count_plates_instead_of_flagging_duplicates():
    genotype = cp.VariableLevels("genotype", "Genotype", ("wt", "mut"), ("wt", "mut"), "nominal")
    sections = [{"genotype": "wt"}, {"genotype": "wt"}]
    assert cp.duplicate_sections(sections, [genotype], {}, replicates=True) == {}
    assert set(cp.duplicate_sections(sections, [genotype], {})) == {0, 1}
    view = {"genotype": cp.COLUMNS}
    placements = {("wt",): [(0, 0, True), (0, 1, True)]}
    board = cp.build_board([genotype], view, {}, placements, replicates=True)
    assert board.cells[0][0].state == "confirmed" and board.cells[0][0].text == "×2"
    assert cp.build_board([genotype], view, {}, placements).cells[0][0].state == "duplicate"
    status = {("wt",): [("detected", 1), ("waiting", 2)]}
    cell = cp.build_status_board([genotype], view, {}, status).cells[0][0]
    assert (cell.state, cell.text, cell.target) == ("partial", "1/2", (2,))


def test_wizard_counts_indices_and_plates_apart():
    draft = npm.example_draft()
    draft.variables[0].set_count(3)
    draft.variables[1].set_count(4)
    assert (draft.index_count, draft.plates_per_index, draft.plate_count) == (3, 4, 12)
    assert draft.variables[1].values == ["1", "2", "3", "4"]
    assert "plates each" in draft.index_formula()
    draft.variables.append(npm.VariableDraft("Technical", "replicate", "Technical replicate", ["1"]))
    assert "one replicate variable" in draft.variable_error(2)
    specs, _, _ = draft.specifications()
    assert [lv.value for lv in specs[1].levels] == ["1", "2", "3", "4"]


def test_one_per_group_never_matches_within_a_replicate():
    variables = [StatsVariable("replicate", "Replicate", "replicate", ("1", "2"), ("1", "2")),
                 StatsVariable("genotype", "Genotype", "nominal", ("wt",), ("wt",))]
    assert default_matched(variables) == ["genotype"]
