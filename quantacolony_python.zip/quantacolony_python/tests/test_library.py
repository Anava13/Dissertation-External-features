"""Project library: pointer and marker, moves, locks, sharing and backups."""

import pytest

from quantacolony.core.session import DetectionSession
from quantacolony.data import (DataManager, LibraryError, ProjectError, Settings, check_location, create_library,
                               find_library)
from quantacolony.data.sample_project import SAMPLE_PROJECT_NAME, create_sample_project


@pytest.fixture()
def setup(tmp_path):
    manager = DataManager(Settings.load(tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    info = create_sample_project(manager)
    yield manager, info.project_id, tmp_path
    manager.close()


def commit_one_edit(manager, delete=2):
    packet = manager.checkout_image(manager.first_index_for_detection())
    session = DetectionSession(packet.record, packet.saved.params if packet.saved else packet.defaults)
    if packet.saved:
        session.load_saved(packet.saved)
    else:
        session.initialize_detection()
    session.delete_colonies(session.colonies.ids[:delete])
    manager.commit_detection(session.result())
    return len(session.colonies)


def test_settings_find_the_library_and_follow_a_move(setup):
    manager, project_id, tmp_path = setup
    settings = Settings.load(tmp_path / "settings")
    assert find_library(settings.library_path, settings.library_id).root == manager.library.root
    manager.move_library(tmp_path / "Elsewhere")
    assert manager.project_id == project_id                            # reopened after the move
    settings = Settings.load(tmp_path / "settings")
    assert settings.library_path == str((tmp_path / "Elsewhere").resolve())
    assert not (tmp_path / "Library").exists()
    assert [e.name for e in manager.list_projects()] == [SAMPLE_PROJECT_NAME]


def test_a_library_moved_by_hand_is_reported_missing(setup):
    manager, _project_id, tmp_path = setup
    manager.close()
    (tmp_path / "Library").rename(tmp_path / "Renamed")
    fresh = DataManager(Settings.load(tmp_path / "settings"))
    assert fresh.resolve_library() is None


def test_creating_a_library_refuses_unsafe_or_busy_folders(tmp_path, monkeypatch):
    monkeypatch.setenv("OneDrive", str(tmp_path / "OneDrive"))
    assert not check_location(tmp_path / "OneDrive" / "Q").ok
    assert not check_location(tmp_path / "Dropbox" / "Q").ok
    assert check_location(tmp_path / "Local").ok
    busy = tmp_path / "Busy"
    busy.mkdir()
    (busy / "other.txt").write_text("x")
    with pytest.raises(LibraryError):
        create_library(busy)


def test_one_window_per_project(setup):
    manager, project_id, tmp_path = setup
    second = DataManager(Settings.load(tmp_path / "settings"))
    second.resolve_library()
    with pytest.raises(ProjectError, match="already open"):
        second.open_project(project_id)
    manager.close()
    second.open_project(project_id)                                     # lock released on close
    second.close()


def test_export_and_import_make_independent_copies(setup):
    manager, project_id, tmp_path = setup
    commit_one_edit(manager)
    shared = manager.export_project_file(project_id, tmp_path / "share" / "For Alex")
    assert shared.name == "For Alex.qcproj"
    copy_id = manager.import_project_file(shared)
    assert copy_id != project_id
    names = sorted(e.name for e in manager.list_projects())
    assert names == [SAMPLE_PROJECT_NAME, SAMPLE_PROJECT_NAME + " (copy)"]
    manager.open_project(copy_id)
    assert manager.project_info().indices[0].revision == 1             # results travel with the file
    with pytest.raises(ProjectError):
        manager.export_project_file(copy_id, manager.library.root / "inside")


def test_backups_on_close_and_restore(setup):
    manager, project_id, _tmp_path = setup
    manager.close()                                                     # new project: first backup
    manager.open_project(project_id)
    first = commit_one_edit(manager, delete=2)
    manager.close()                                                     # second backup
    manager.open_project(project_id)
    manager.close()                                                     # nothing changed: no backup
    backups = manager.list_backups(project_id)
    assert len(backups) == 2
    manager.open_project(project_id)
    commit_one_edit(manager, delete=3)
    manager.restore_backup(project_id, backups[0].path)                 # back to the state after the first edit
    saved = manager.checkout_image(manager.first_index_for_detection()).saved
    assert len(saved.colonies) == first
    assert len(manager.list_backups(project_id)) == 3                   # restore snapshotted the state it replaced


def test_project_names_are_unique_in_a_library(setup):
    manager, _project_id, _tmp_path = setup
    with pytest.raises(ProjectError, match="already exists"):
        create_sample_project(manager)
