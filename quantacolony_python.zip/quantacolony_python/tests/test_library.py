"""Project library: pointer and marker, moves, locks, sharing and backups."""

import pytest

from quantacolony.core.session import DetectionSession
from quantacolony.data import (DataManager, LibraryError, ProjectError, Settings, check_location, create_library,
                               find_library)
from sample_project import SAMPLE_PROJECT_NAME, create_sample_project


@pytest.fixture()
def setup(tmp_path):
    manager = DataManager(Settings.load(tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    info = create_sample_project(manager)
    yield manager, info.project_id, tmp_path
    manager.close()


def commit_one_edit(manager, delete=2):
    packet = manager.checkout_image(manager.first_index_for_detection())
    session = DetectionSession(packet.record, packet.saved.params if packet.saved else packet.defaults)
    if packet.saved:
        session.load_saved(packet.saved)
    else:
        session.initialize_detection()
    session.delete_colonies(session.colonies.ids[:delete])
    manager.commit_detection(session.result())
    return len(session.colonies)


def test_settings_find_the_library_and_follow_a_move(setup):
    manager, project_id, tmp_path = setup
    settings = Settings.load(tmp_path / "settings")
    assert find_library(settings.library_path, settings.library_id).root == manager.library.root
    manager.move_library(tmp_path / "Elsewhere")
    assert manager.project_id == project_id                            # reopened after the move
    settings = Settings.load(tmp_path / "settings")
    assert settings.library_path == str((tmp_path / "Elsewhere").resolve())
    assert not (tmp_path / "Library").exists()
    assert [e.name for e in manager.list_projects()] == [SAMPLE_PROJECT_NAME]


def test_a_library_moved_by_hand_is_reported_missing(setup):
    manager, _project_id, tmp_path = setup
    manager.close()
    (tmp_path / "Library").rename(tmp_path / "Renamed")
    fresh = DataManager(Settings.load(tmp_path / "settings"))
    assert fresh.resolve_library() is None


def test_creating_a_library_refuses_unsafe_or_busy_folders(tmp_path, monkeypatch):
    monkeypatch.setenv("OneDrive", str(tmp_path / "OneDrive"))
    assert not check_location(tmp_path / "OneDrive" / "Q").ok
    assert not check_location(tmp_path / "Dropbox" / "Q").ok
    assert check_location(tmp_path / "Local").ok
    busy = tmp_path / "Busy"
    busy.mkdir()
    (busy / "other.txt").write_text("x")
    with pytest.raises(LibraryError):
        create_library(busy)


def test_one_window_per_project(setup):
    manager, project_id, tmp_path = setup
    second = DataManager(Settings.load(tmp_path / "settings"))
    second.resolve_library()
    with pytest.raises(ProjectError, match="already open"):
        second.open_project(project_id)
    manager.close()
    second.open_project(project_id)                                     # lock released on close
    second.close()


def test_export_and_import_make_independent_copies(setup):
    manager, project_id, tmp_path = setup
    commit_one_edit(manager)
    shared = manager.export_project_file(project_id, tmp_path / "share" / "For Alex")
    assert shared.name == "For Alex.qcproj"
    copy_id = manager.import_project_file(shared)
    assert copy_id != project_id
    names = sorted(e.name for e in manager.list_projects())
    assert names == [SAMPLE_PROJECT_NAME, SAMPLE_PROJECT_NAME + " (copy)"]
    manager.open_project(copy_id)
    assert manager.project_info().indices[0].revision == 1             # results travel with the file
    with pytest.raises(ProjectError):
        manager.export_project_file(copy_id, manager.library.root / "inside")


def test_backups_on_close_and_restore(setup):
    manager, project_id, _tmp_path = setup
    manager.close()                                                     # new project: first backup
    manager.open_project(project_id)
    first = commit_one_edit(manager, delete=2)
    manager.close()                                                     # second backup
    manager.open_project(project_id)
    manager.close()                                                     # nothing changed: no backup
    backups = manager.list_backups(project_id)
    assert len(backups) == 2
    manager.open_project(project_id)
    commit_one_edit(manager, delete=3)
    manager.restore_backup(project_id, backups[0].path)                 # back to the state after the first edit
    saved = manager.checkout_image(manager.first_index_for_detection()).saved
    assert len(saved.colonies) == first
    assert len(manager.list_backups(project_id)) == 3                   # restore snapshotted the state it replaced


def test_project_names_are_unique_in_a_library(setup):
    manager, _project_id, _tmp_path = setup
    with pytest.raises(ProjectError, match="already exists"):
        create_sample_project(manager)


def test_a_move_takes_every_folder_of_the_library(setup):
    manager, _, tmp_path = setup
    plugin = manager.analyses_folder() / "mine.py"
    plugin.write_text("ANALYSES = []\n", encoding="utf-8")
    manager.move_library(tmp_path / "Elsewhere")
    moved = tmp_path / "Elsewhere"
    assert (moved / "Analyses" / "mine.py").read_text(encoding="utf-8") == "ANALYSES = []\n"
    assert (moved / "Analyses" / "example_analysis.py.txt").is_file()
    assert manager.analyses_folder() == moved / "Analyses"


def test_a_move_into_the_library_itself_is_refused(setup):
    manager, project_id, tmp_path = setup
    for inside in (tmp_path / "Library", tmp_path / "Library" / "QuantaColony Library"):
        with pytest.raises(ProjectError, match="inside itself"):
            manager.move_library(inside)
    assert manager.library.project_path(project_id).is_file()
    assert manager.project_id == project_id                            # reopened after the refusal
    assert project_id in [entry.project_id for entry in manager.list_projects()]


def test_a_move_completes_when_the_old_folder_cannot_be_removed(setup, monkeypatch):
    manager, project_id, tmp_path = setup
    import quantacolony.data.library as library_module
    monkeypatch.setattr(library_module.shutil, "rmtree", lambda *args, **kwargs: None)   # a file held open
    moved = manager.move_library(tmp_path / "Elsewhere")
    assert moved.leftover == (tmp_path / "Library").resolve()
    assert not (tmp_path / "Library" / "library.json").exists()       # no longer a library
    assert manager.library.root == (tmp_path / "Elsewhere").resolve()
    assert manager.project_id == project_id
    settings = Settings.load(tmp_path / "settings")
    assert find_library(str(tmp_path / "Library"), settings.library_id) is None
    assert find_library(settings.library_path, settings.library_id).root == manager.library.root


def test_a_finished_move_reports_no_leftover(setup):
    manager, _, tmp_path = setup
    assert manager.move_library(tmp_path / "Elsewhere").leftover is None


def test_no_library_inside_the_program_folder():
    from quantacolony.data.library import program_folders
    for folder in program_folders():
        check = check_location(folder / "Library")
        assert not check.ok and "program folder" in check.problem
    with pytest.raises(LibraryError, match="program folder"):
        create_library(program_folders()[0] / "QuantaColony Library")


def test_shortcuts_are_not_made_from_a_source_folder(monkeypatch, capsys):
    from quantacolony import shortcut
    monkeypatch.setattr(shortcut, "running_from_source", lambda: True)
    monkeypatch.setattr(shortcut.sys, "argv", ["quantacolony-shortcut"])
    assert shortcut.main() == 1
    assert "Install QuantaColony.bat" in capsys.readouterr().out



# ----- folders and the Trash -------------------------------------------------------
def test_nested_folders_hold_projects(setup):
    manager, project_id, tmp_path = setup
    manager.close()
    lab = manager.create_folder("Lab")
    rif1 = manager.create_folder("Rif1", lab)
    year = manager.create_folder("2026", rif1)
    manager.move_projects([project_id], year)
    folders, placement = manager.folder_layout()
    assert {f.name: f.parent for f in folders} == {"Lab": "", "Rif1": lab, "2026": rif1}
    assert placement[project_id] == year
    with pytest.raises(ProjectError, match="already holds"):
        manager.create_folder("rif1", lab)                              # names are unique per folder
    with pytest.raises(ProjectError, match="into itself"):
        manager.move_folder(lab, year)
    manager.rename_folder(rif1, "Rif1 lineages")
    manager.move_folder(year, "")
    folders, placement = manager.folder_layout()
    assert {f.name: f.parent for f in folders}["2026"] == "" and placement[project_id] == year
    manager.new_project_folder = lab                                    # imports land in the chosen folder
    copy = manager.import_project_file(manager.library.project_path(project_id))
    assert manager.folder_layout()[1][copy] == lab


def test_a_deleted_folder_goes_to_the_trash_whole_and_comes_back(setup):
    manager, project_id, tmp_path = setup
    manager.close()
    lab = manager.create_folder("Lab")
    inner = manager.create_folder("Inner", lab)
    copy = manager.import_project_file(manager.library.project_path(project_id))
    manager.move_projects([project_id], lab)
    manager.move_projects([copy], inner)
    manager.delete_folder(lab)
    assert manager.list_projects() == [] and manager.folder_layout()[0] == []
    (item,) = manager.list_trash()
    assert item.kind == "folder" and item.name == "Lab" and set(item.project_ids) == {project_id, copy}
    assert item.folder_count == 2 and manager.library.trash_path(project_id).is_file()
    assert manager.trash_size(item) > 0
    manager.restore_trash(item.item_id)
    folders, placement = manager.folder_layout()
    assert {f.name for f in folders} == {"Lab", "Inner"}
    assert placement == {project_id: lab, copy: inner} and manager.list_trash() == []
    manager.open_project(project_id)                                    # restored projects open as before


def test_a_restored_project_whose_name_was_taken_is_renamed(setup):
    manager, project_id, tmp_path = setup
    manager.close()
    manager.delete_projects([project_id])
    assert not manager.library.project_path(project_id).exists()
    assert (manager.library.trash_folder / "Backups" / project_id).is_dir()  # its backups went with it
    create_sample_project(manager)                                           # takes the same name
    manager.close()
    (item,) = manager.list_trash()
    renamed = manager.restore_trash(item.item_id)
    assert renamed == {project_id: f"{SAMPLE_PROJECT_NAME} (restored)"}
    assert sorted(e.name for e in manager.list_projects()) == [SAMPLE_PROJECT_NAME, f"{SAMPLE_PROJECT_NAME} (restored)"]
    assert (manager.library.backups_folder / project_id).is_dir()


def test_an_open_project_is_not_deleted(setup):
    manager, project_id, tmp_path = setup
    with pytest.raises(ProjectError, match="Close this project"):
        manager.delete_projects([project_id])
    manager.close()
    other = DataManager(Settings.load(tmp_path / "other"))
    other.use_library(manager.library)
    other.open_project(project_id)                                      # open in another window
    try:
        with pytest.raises(ProjectError, match="already open"):
            manager.delete_projects([project_id])
        assert manager.library.project_path(project_id).is_file() and manager.list_trash() == []
    finally:
        other.close()


def test_permanent_delete_and_an_interrupted_delete(setup):
    manager, project_id, tmp_path = setup
    manager.close()
    copy = manager.import_project_file(manager.library.project_path(project_id))
    manager.delete_projects([project_id, copy])
    assert len(manager.list_trash()) == 2
    manager.purge_trash(manager.list_trash()[0].item_id)
    assert len(manager.list_trash()) == 1 and len(list(manager.library.trash_folder.glob("*.qcproj"))) == 1
    manager.empty_trash()
    assert manager.list_trash() == [] and not list(manager.library.trash_folder.glob("*.qcproj"))
    third = create_sample_project(manager).project_id                  # a file in the Trash with no record
    manager.close()
    manager.library.trash_folder.mkdir(exist_ok=True)
    manager.library.project_path(third).replace(manager.library.trash_path(third))
    (item,) = manager.list_trash()
    assert item.project_ids == (third,) and item.name == SAMPLE_PROJECT_NAME


def test_folders_and_trash_move_with_the_library(setup):
    manager, project_id, tmp_path = setup
    manager.close()
    folder = manager.create_folder("Kept")
    copy = manager.import_project_file(manager.library.project_path(project_id))
    manager.move_projects([project_id], folder)
    manager.delete_projects([copy])
    manager.move_library(tmp_path / "Moved")
    assert manager.folder_layout()[1][project_id] == folder
    (item,) = manager.list_trash()
    manager.restore_trash(item.item_id)
    assert copy in [e.project_id for e in manager.list_projects()]


# ----- the tutorial project ---------------------------------------------------------
def test_the_tutorial_project_comes_ready_to_explore(tmp_path):
    manager = DataManager(Settings.load(tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    assert manager.is_new_library()
    project_id = manager.add_tutorial_project()
    (entry,) = manager.list_projects()
    assert entry.name == "Crowding" and entry.photo_count == 10 and entry.detected_count == entry.index_count == 10
    assert not manager.is_new_library()
    manager.open_project(project_id)
    try:
        (variable,) = manager.project_info().variables
        assert [lv.display for lv in variable.levels][:2] == ["100X", "500X"]
        assert manager.coverage_waiting() == 0                          # growth coverage comes measured
        capture = {i.labels[0].value: manager.request_derived("plate_coverage", i.index_id).rows[0]["capture_ratio"]
                   for i in manager.project_info().indices}
        assert capture["100"] < 0.25 < capture["500"]                   # 100X is too crowded to measure
    finally:
        manager.close()
    second = manager.add_tutorial_project()                             # a fresh copy keeps the first one's work
    assert second != project_id and {e.name for e in manager.list_projects()} == {"Crowding", "Crowding (copy)"}
