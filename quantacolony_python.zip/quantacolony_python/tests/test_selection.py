"""Plate selection: one plate per group, matched on colony count (the MATLAB CountDatasetGenerator rules)."""

import numpy as np
import pytest

from quantacolony.core import stats as st
from quantacolony.core.selection import (MISS, PINNED, SELECTED, SKIPPED, PlateTable, SelectionChoice,
                                         default_matched, group_key_text, select_plates)

GENOTYPE = st.StatsVariable("genotype", "Genotype", "nominal", ("WT", "mut"), ("Wild type", "mutant"), "WT")
PASSAGE = st.StatsVariable("passage", "Passage", "ordinal", ("1", "2"), ("P1", "P2"), None)
SERIES = st.StatsVariable("series", "Series", "nominal", ("main", "late"), ("main", "21 day"), "main")
VARIABLES = [GENOTYPE, PASSAGE, SERIES]


def plates(rows):
    """rows: (index id, genotype, passage, series, count, capture ratio)."""
    ids = np.array([r[0] for r in rows])
    levels = {"genotype": np.array([r[1] for r in rows], dtype=object),
              "passage": np.array([r[2] for r in rows], dtype=object),
              "series": np.array([r[3] for r in rows], dtype=object)}
    return PlateTable(ids, levels, np.array([r[4] for r in rows], dtype=float),
                      np.array([r[5] for r in rows], dtype=float), tuple(f"plate{r[0]}" for r in rows))


ROWS = [
    (1, "WT", "1", "main", 100, 0.6),
    (2, "WT", "1", "main", 300, 0.5),
    (3, "WT", "1", "late", 200, 0.9),     # hidden series: not in the pool
    (4, "WT", "2", "main", 220, 0.4),
    (5, "WT", "2", "main", 180, 0.4),
    (6, "mut", "1", "main", 210, 0.1),    # overplated
    (7, "mut", "1", "main", 0, 0.7),      # no colonies
    (8, "mut", "1", "main", 400, np.nan),  # not measured
    (9, "mut", "2", "main", 260, 0.3),
]


def test_closest_count_to_the_median_of_eligible_plates():
    s = select_plates(plates(ROWS), VARIABLES, ["genotype", "passage"], hidden={"series": ["late"]})
    assert s.eligible == 5 and s.target == 220            # median of 100, 300, 220, 180, 260
    by = {g.key: g for g in s.groups}
    assert len(s.groups) == 4                              # every combination holding a plate, even an empty pool
    assert by[("WT", "1")].chosen.index_id == 2 and by[("WT", "1")].pool_size == 2   # 80 from the target, not 120
    assert by[("WT", "2")].chosen.index_id == 4
    assert by[("mut", "2")].chosen.index_id == 9
    assert by[("mut", "1")].status == MISS and by[("mut", "1")].chosen is None
    assert s.chosen == {2, 4, 9}


def test_ties_go_to_the_first_plate_in_project_order():
    rows = [(5, "WT", "1", "main", 180, 0.4), (4, "WT", "1", "main", 220, 0.4)]
    s = select_plates(plates(rows), VARIABLES, ["genotype", "passage"], target=200)
    assert s.groups[0].chosen.index_id == 4                # both 20 away; index 4 comes first


def test_every_failed_filter_is_reported_for_an_empty_group():
    s = select_plates(plates(ROWS), VARIABLES, ["genotype", "passage"], hidden={"series": ["late"]})
    empty = next(g for g in s.groups if g.key == ("mut", "1"))
    text = empty.why_empty()
    assert "plate6: capture ratio 0.100 below 0.25" in text
    assert "plate7: no colonies" in text
    assert "plate8: no capture ratio measured" in text
    hidden = select_plates(plates([(3, "WT", "1", "late", 0, 0.1)]), VARIABLES, ["genotype", "passage"],
                           hidden={"series": ["late"]}, target=10)
    assert hidden.groups[0].candidates[0].failures == ("Series 21 day (hidden)", "capture ratio 0.100 below 0.25",
                                                       "no colonies")
    diagnostics = select_plates(plates(ROWS), VARIABLES, ["genotype", "passage"],
                                hidden={"series": ["late"]}).diagnostics()
    assert diagnostics.startswith("mutant · P1: 3 plates, none eligible.")
    assert "failing: colonies 1, separable 2" in diagnostics and "failing only one filter: 3" in diagnostics
    assert [g.key for g in hidden.groups] == [("WT", "1")]   # combinations nobody plated are not groups


def test_fixed_target_pins_and_groups_left_empty():
    table = plates(ROWS)
    s = select_plates(table, VARIABLES, ["genotype", "passage"], hidden={"series": ["late"]}, target=290,
                      pins={group_key_text(("mut", "1")): 6}, skips=[group_key_text(("WT", "2"))])
    by = {g.key: g for g in s.groups}
    assert s.target_rule == "fixed" and by[("WT", "1")].chosen.index_id == 2
    assert by[("mut", "1")].status == PINNED and by[("mut", "1")].chosen.failures   # pinned though overplated
    assert by[("WT", "2")].status == SKIPPED and by[("WT", "2")].chosen is None
    assert s.counts() == {SELECTED: 2, PINNED: 1, MISS: 0, SKIPPED: 1}
    assert "1 pinned by hand" in s.summary() and "1 left empty by choice" in s.summary()
    rows = s.rows()
    assert [r["status"] for r in rows] == ["selected", "left empty by choice", "pinned by hand", "selected"]
    assert rows[2]["filters_failed"].startswith("capture ratio")


def test_hidden_levels_of_matched_variables_drop_their_groups():
    s = select_plates(plates(ROWS), VARIABLES, ["genotype", "passage"], hidden={"genotype": ["mut"]})
    assert [g.key for g in s.groups] == [("WT", "1"), ("WT", "2")]


def test_no_eligible_plate_has_no_median():
    with pytest.raises(ValueError):
        select_plates(plates([(1, "WT", "1", "main", 10, 0.1)]), VARIABLES, ["genotype"])


def test_choices_round_trip_and_default_variables():
    choice = SelectionChoice(True, ["genotype", "passage"], 250.0, {"WT | 1": 2}, ["mut | 2"])
    assert SelectionChoice.from_dict(choice.to_dict()) == choice
    assert SelectionChoice.from_dict(None) == SelectionChoice()
    assert default_matched(VARIABLES) == ["genotype", "passage", "series"]     # one plate per index


def test_each_index_chooses_among_its_replicates_or_across_a_left_out_variable():
    rows = [(1, "WT", "1", "main", 150, 0.6), (2, "WT", "1", "main", 230, 0.6),      # two plates of one index
            (3, "WT", "1", "late", 400, 0.6), (4, "WT", "2", "main", 210, 0.6)]
    table = plates(rows)
    table = PlateTable(table.index_ids, table.levels, table.counts, table.capture_ratios, table.labels,
                       ("1", "2", "1", "1"))
    per_index = select_plates(table, VARIABLES, default_matched(VARIABLES), target=220)
    assert [len(g.candidates) for g in per_index.groups] == [2, 1, 1]                  # WT·P1·main, WT·P1·21 day, WT·P2
    assert per_index.groups[0].chosen.index_id == 2
    assert per_index.groups[0].candidates[1].label == "plate 2 · plate2"
    assert "each index, chosen among its replicate plates" in per_index.summary()
    across = select_plates(table, VARIABLES, ["genotype", "passage"], target=220)       # Series left out
    assert len(across.groups) == 2 and across.groups[0].pool_size == 3
    assert across.groups[0].candidates[2].label == "21 day · plate 1 · plate3"
    assert "chosen across Series and the replicate plates" in across.summary()


# ----- in Stats ---------------------------------------------------------------------
def test_stats_keeps_one_plate_per_group_and_saves_the_choices(tmp_path):
    from PySide6.QtWidgets import QApplication
    from quantacolony.data import DataManager, Settings, create_library
    from quantacolony.gui.launch import open_stats
    from test_stats import apply_theme

    app = QApplication.instance() or QApplication([])
    manager = DataManager(Settings(folder=tmp_path / "s"))
    manager.use_library(create_library(tmp_path / "Library"))
    manager.open_project(manager.add_tutorial_project())
    window, controller = open_stats(manager, apply_theme(app))
    try:
        controller.choose_analysis("box")
        all_plates = set(controller.data.index_ids.tolist())
        controller.set_plate_selection(True)
        selection, _ = controller.selection()
        assert selection.target == 190 and len(selection.groups) == 10
        assert set(controller.data.index_ids.tolist()) == selection.chosen < all_plates     # 100X is overplated
        assert controller.data.notes[0].startswith("One plate per Dilution Level")
        dialog = window.selection_dialog
        assert dialog.isVisible() and dialog.table.rowCount() == 10
        assert "100X: 1 plate, none eligible." in dialog.details.toPlainText()
        group = group_key_text(("100",))
        overplated = selection.groups[0].candidates[0].index_id
        controller.pin_plate(group, overplated)                      # pinned though below the floor
        assert overplated in set(controller.data.index_ids.tolist())
        assert dialog.table.item(0, 6).text() == "pinned by hand"
        controller.leave_group_empty(group_key_text(("8000",)))
        controller.set_target(400)
        saved = manager.module_preferences("stats")["plate_selection"]
        assert saved == {"on": True, "matched": ["dilution_level"], "target": 400.0, "pins": {group: overplated},
                         "skips": ["8000"], "not_chosen": {}}
        path = tmp_path / "selection.csv"
        controller.save_selection_table(str(path))
        text = path.read_text()
        assert "pinned by hand" in text and "left empty by choice" in text
        controller.reset_selection()
        controller.set_plate_selection(False)
        assert set(controller.data.index_ids.tolist()) == all_plates
    finally:
        window.close()
        manager.close()


# ----- the dish wall in growth coverage -----------------------------------------------
def test_growth_along_the_dish_wall_is_dropped_but_lawns_and_colonies_stay():
    from quantacolony.core.growth import drop_wall
    yy, xx = np.mgrid[:400, :400]
    r = np.hypot(yy - 200, xx - 200)
    region = r <= 190
    wall = (r > 182) & (r <= 188) & (xx > 200)               # an arc hugging the edge
    lawn = (np.hypot(yy - 200, xx - 60) < 60) & region         # growth reaching the edge from inside
    colony = (np.hypot(yy - 200, xx - 375) < 8) & region       # a marked colony at the edge
    growth = wall | lawn | colony
    kept = drop_wall(growth, colony, region)
    assert not (kept & wall & ~colony).any()
    assert kept[lawn].all() and kept[colony].all()
