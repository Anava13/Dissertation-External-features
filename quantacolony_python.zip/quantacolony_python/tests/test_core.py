"""Core tests. Run with:  uv run pytest"""

from pathlib import Path

import numpy as np

from quantacolony.core.detection import perform_detection
from quantacolony.core.params import DetectionParams
from quantacolony.core.session import DetectionSession
from quantacolony.core.record import ImageRecord
from sample_project import sample_image

REFERENCE = Path(__file__).parent / "golden" / "matlab_reference_rif1_cdc132_v25.npz"


def load_image_record() -> ImageRecord:
    """The bundled sample as Colony Detection receives it, without a project file."""
    image, px_per_mm, params = sample_image()
    record = ImageRecord(1, "sample", (), image, np.ones(image.shape[:2], bool), px_per_mm)
    object.__setattr__(record, "saved_params", params)      # test convenience
    return record


def make_session() -> DetectionSession:
    record = load_image_record()
    session = DetectionSession(record, record.saved_params)
    session.initialize_detection()
    return session


def test_irregular_detection_matches_matlab():
    record = load_image_record()
    colonies = perform_detection(record.image, record.saved_params)
    reference = np.load(REFERENCE)
    assert len(colonies) == len(reference["radii"]) == 33
    distance = np.hypot(colonies.centers[:, None, 0] - reference["centers"][None, :, 0],
                        colonies.centers[:, None, 1] - reference["centers"][None, :, 1])
    assert np.all(distance.min(axis=1) < 1e-6)
    assert np.allclose(np.sort(colonies.radii), np.sort(reference["radii"]))


def test_ids_unique_and_stable_across_undo():
    session = make_session()
    original_ids = session.colonies.ids.copy()
    assert len(set(original_ids)) == len(original_ids)
    session.delete_colonies(original_ids[:3])
    session.undo()
    assert np.array_equal(session.colonies.ids, original_ids)


def test_delete_add_detect_undo_redo_chain():
    session = make_session()
    start = session.colonies
    start_params = session.params

    session.delete_colonies(start.ids[:2])                                   # deletion
    after_delete = session.colonies
    added = session.add_colonies(DetectionSession.circles_to_colonies([(5.0, 5.0, 3.0)]))
    assert added == 1                                                        # addition
    looser = start_params.with_value("sense", 1.0)
    session.detect_colonies(looser)                                          # re-detection
    assert session.params.sense == 1.0

    session.undo()
    assert session.params == start_params and len(session.colonies) == len(start) - 2 + 1
    session.undo()
    assert session.colonies is after_delete
    session.undo()
    assert session.colonies is start
    assert not session.can_undo()

    session.redo()
    session.redo()
    session.redo()
    assert session.params.sense == 1.0
    assert not session.can_redo()


def test_new_edit_clears_redo():
    session = make_session()
    session.delete_colonies(session.colonies.ids[:1])
    session.undo()
    assert session.can_redo()
    session.delete_colonies(session.colonies.ids[:1])
    assert not session.can_redo()


def test_duplicate_manual_circle_is_rejected():
    session = make_session()
    x, y = session.colonies.centers[0]
    r = session.colonies.radii[0]
    assert session.add_colonies(DetectionSession.circles_to_colonies([(x, y, r)])) == 0


def test_region_detection_finds_only_new_colonies():
    session = make_session()
    rows, cols = session.image.shape[:2]
    candidates = session.preview_region_detection(session.params.with_value("sense", 1.0),
                                                  (0, 0, cols, rows))
    # Every colony already present is filtered out of the candidates
    for center in session.colonies.centers:
        if len(candidates):
            assert np.hypot(*(candidates.centers - center).T).min() > 0.5


def test_circular_mode_runs_and_sensitivity_is_monotonic():
    record = load_image_record()
    counts = [len(perform_detection(record.image, DetectionParams(
        level=-0.65, sense=s, rmin=2, rmax=20, maxpix=2000, detection_type="Circular")))
        for s in (0.8, 0.9)]
    assert 0 < counts[0] <= counts[1]


def test_contour_fits_detected_colonies():
    """A circle 1.6x a detected colony's radius contours to roughly that colony's size."""
    from quantacolony.core.contour import contour_circle
    record = load_image_record()
    colonies = perform_detection(record.image, record.saved_params)
    ratios = []
    for (x, y), r in zip(colonies.centers, colonies.radii, strict=True):
        result = contour_circle(record.image, x, y, 1.6 * r)
        assert result.found, result.reason
        assert np.hypot(result.center[0] - x, result.center[1] - y) < r      # stays on the colony
        ratios.append(result.radius / r)
    # Otsu's threshold sits partway into the soft halo that the global level includes
    assert 0.8 < np.median(ratios) < 1.0


def test_contour_reports_empty_agar():
    from quantacolony.core.contour import contour_circle
    record = load_image_record()
    # Verified empty: no thresholded pixel within 3 px of this circle
    result = contour_circle(record.image, 253.1, 230.3, 4.0)
    assert not result.found and result.reason
    # Empty agar is rejected across many random empty circles
    from quantacolony.core.detection import prepare_image
    mask = prepare_image(record.image, record.saved_params.level)
    rows, cols = np.mgrid[:mask.shape[0], :mask.shape[1]]
    rng = np.random.default_rng(0)
    tested = false_hits = 0
    while tested < 80:
        x, y, r = rng.uniform(10, 270), rng.uniform(10, 280), rng.uniform(4, 10)
        if mask[(cols - x) ** 2 + (rows - y) ** 2 <= (r + 3) ** 2].any():
            continue
        tested += 1
        false_hits += contour_circle(record.image, x, y, r).found
    assert false_hits == 0


def test_baseline_follows_latest_detection_and_undo():
    session = make_session()
    first = session.initial_state
    session.delete_colonies(session.colonies.ids[:1])
    assert session.initial_state is first                        # manual edits keep the baseline
    session.detect_colonies(session.params.with_value("sense", 1.0))
    assert session.initial_state is session.colonies              # re-detection replaces it (captureInitialState)
    session.undo()
    assert session.initial_state is first


def test_region_mask_excludes_masked_pixels():
    record = load_image_record()
    full = perform_detection(record.image, record.saved_params)
    left_half = np.zeros(record.image.shape[:2], bool)
    left_half[:, : record.image.shape[1] // 2] = True
    masked = perform_detection(record.image, record.saved_params, region_mask=left_half)
    assert 0 < len(masked) < len(full)
    assert np.all(masked.centers[:, 0] < record.image.shape[1] // 2)


def test_result_logs_every_edit_since_load():
    session = make_session()
    session.delete_colonies(session.colonies.ids[:2])
    session.add_colonies(DetectionSession.circles_to_colonies([(5.0, 5.0, 3.0)]))
    result = session.result()
    assert [e.kind for e in result.edits] == ["Deletion", "Addition"]
    assert len(result.edits[0].colony_ids) == 2 and len(result.baseline) == 33
    session.mark_committed(1)
    assert session.result().edits == () and not session.can_undo()
