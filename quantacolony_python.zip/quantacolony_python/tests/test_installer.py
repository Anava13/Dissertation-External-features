"""The installer: copying the program, building its environment, shortcuts, the backup in the library."""

import os
import types
from pathlib import Path

import pytest

from quantacolony import installer
from quantacolony.data import DataManager, Settings, create_library
from quantacolony.data import program as pg


def fake_program(root: Path) -> Path:
    for relative, text in {"pyproject.toml": "[project]\nname='quantacolony'\n", "uv.lock": "lock",
                           "Install QuantaColony.bat": "@echo off", "quantacolony/__init__.py": "__version__ = '1'",
                           "quantacolony/app.py": "print('hi')", "quantacolony/assets/logo/quantacolony.ico": "ico",
                           ".venv/Scripts/python.exe": "env", "quantacolony/__pycache__/app.cpython-313.pyc": "x",
                           ".git/HEAD": "ref"}.items():
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    return root


def test_program_files_leave_out_environments_caches_and_version_control(tmp_path):
    source = fake_program(tmp_path / "download")
    files = {p.as_posix() for p in pg.program_files(source)}
    assert files == {"pyproject.toml", "uv.lock", "Install QuantaColony.bat", "quantacolony/__init__.py",
                     "quantacolony/app.py", "quantacolony/assets/logo/quantacolony.ico"}


def test_copy_keeps_the_environment_and_removes_files_that_left_the_program(tmp_path):
    source = fake_program(tmp_path / "download")
    target = tmp_path / "Program"
    (target / ".venv" / "Scripts").mkdir(parents=True)
    (target / ".venv" / "Scripts" / "quantacolony-gui.exe").write_text("launcher")
    (target / "quantacolony" / "old_module.py").parent.mkdir(parents=True)
    (target / "quantacolony" / "old_module.py").write_text("gone in this version")
    pg.copy_program(source, target)
    assert (target / ".venv" / "Scripts" / "quantacolony-gui.exe").is_file()
    assert not (target / "quantacolony" / "old_module.py").exists()
    assert (target / "quantacolony" / "app.py").read_text() == "print('hi')"
    assert pg.stored_fingerprint(target) == pg.fingerprint(source)


def test_library_backup_follows_the_running_program(tmp_path):
    source = fake_program(tmp_path / "download")
    library = tmp_path / "Library"
    assert pg.back_up_program(source, library)                       # first time: copied
    assert not pg.back_up_program(source, library)                   # unchanged: nothing to do
    assert not (library / "Program" / ".venv").exists()
    (source / "quantacolony" / "app.py").write_text("print('new')")
    assert pg.back_up_program(source, library)                       # an update reaches the backup
    assert (library / "Program" / "quantacolony" / "app.py").read_text() == "print('new')"


def test_the_real_program_is_recognized_and_backed_up_on_start(tmp_path):
    from quantacolony.app import _back_up_program
    assert pg.is_program_folder(pg.program_root())
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    _back_up_program(manager)
    backup = tmp_path / "Library" / "Program"
    assert (backup / "pyproject.toml").is_file() and (backup / "Install QuantaColony.bat").is_file()
    assert not (backup / ".venv").exists() and pg.stored_fingerprint(backup) == pg.fingerprint(pg.program_root())


@pytest.mark.parametrize("windows", [False, True])
def test_install_runs_every_step(tmp_path, monkeypatch, windows):
    source = fake_program(tmp_path / "download")
    target = tmp_path / "AppData" / "QuantaColony" / "Program"
    monkeypatch.setattr(installer, "install_folder", lambda: target)
    monkeypatch.setenv("UV", "uv.exe")
    monkeypatch.setenv("UV_PROJECT_ENVIRONMENT", str(tmp_path / "temp-env"))
    monkeypatch.setenv("UV_PROJECT", ".")                              # settings of the uv run that started it
    monkeypatch.setenv("UV_CACHE_DIR", str(tmp_path / "cache"))
    calls, made = [], []

    def fake_uv(command, env=None, cwd=None, **kwargs):
        calls.append((command, env, cwd))
        launcher = target / ".venv" / "Scripts" / "quantacolony-gui.exe"
        launcher.parent.mkdir(parents=True, exist_ok=True)
        launcher.write_text("launcher")
        return types.SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr(installer, "create_shortcuts", lambda *args: made.append(("shortcuts", args)) or [])
    monkeypatch.setattr(installer, "register_project_files", lambda *args: made.append(("icon", args)))
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    result = installer.install(source, manager, windows=windows, run=fake_uv, say=lambda text: None)
    assert result == target and (target / "quantacolony" / "app.py").is_file()
    command, env, cwd = calls[0]
    assert command == ["uv.exe", "sync", "--no-dev", "--directory", str(target.resolve())]
    assert cwd == str(target.resolve())
    assert "UV_PROJECT_ENVIRONMENT" not in env and "UV_PROJECT" not in env    # nothing steers the installed copy
    assert env["UV_CACHE_DIR"] == str(tmp_path / "cache")                     # downloads are still shared
    assert (tmp_path / "Library" / "Program" / "pyproject.toml").is_file()
    assert [kind for kind, _ in made] == (["shortcuts", "icon"] if windows else [])
    if windows:
        launcher, workdir, icon = made[0][1]
        assert launcher == target / ".venv" / "Scripts" / "quantacolony-gui.exe" and workdir == target
        assert icon == target / "quantacolony" / "assets" / "logo" / "quantacolony.ico"


def test_a_failed_environment_build_explains_itself(tmp_path, monkeypatch):
    source = fake_program(tmp_path / "download")
    monkeypatch.setattr(installer, "install_folder", lambda: tmp_path / "Program")
    monkeypatch.setenv("UV", "uv.exe")
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    failing = lambda *a, **k: types.SimpleNamespace(returncode=2, stdout="uv 9.9", stderr="network unreachable")  # noqa: E731
    with pytest.raises(installer.InstallError, match="(?s)close it and run the installer again.*uv 9.9; command"):
        installer.install(source, manager, windows=False, run=failing, say=lambda text: None)


def test_install_refuses_a_folder_without_the_program(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    with pytest.raises(installer.InstallError, match="does not hold the QuantaColony program"):
        installer.install(tmp_path, manager, windows=False, say=lambda text: None)


def test_the_batch_file_is_shipped_and_points_at_the_installer():
    bat = (pg.program_root() / "Install QuantaColony.bat").read_text()
    assert "quantacolony-install" in bat and "UV_PROJECT_ENVIRONMENT" in bat
    assert 'quantacolony-install = "quantacolony.installer:main"' in (pg.program_root() / "pyproject.toml").read_text()
    assert os.path.basename(pg.INSTALLER_NAME) == "Install QuantaColony.bat"
