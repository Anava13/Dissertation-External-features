"""GUI workflow tests: drive every mode through the real window and controller.

Runs without a screen when QT_QPA_PLATFORM=offscreen. Set QC_SCREENSHOTS to a
folder to save a screenshot after each step.
"""

import os
from pathlib import Path

import numpy as np
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import QPointF, Qt  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from quantacolony.app import build  # noqa: E402
from quantacolony.data import Settings, create_library  # noqa: E402
from sample_project import create_sample_project  # noqa: E402

SHOTS = os.environ.get("QC_SCREENSHOTS")


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def ui(app, tmp_path):
    window, controller = build(app, settings=Settings(folder=tmp_path / "settings"),
                               library=create_library(tmp_path / "Library"), first_project=create_sample_project)
    window.show()
    app.processEvents()
    return window, controller, app


def snap(window, app, name):
    app.processEvents()
    if SHOTS:
        Path(SHOTS).mkdir(parents=True, exist_ok=True)
        window.grab().save(str(Path(SHOTS) / f"{name}.png"))


def drag(tool, start, end, steps=5):
    tool.press(QPointF(*start))
    for t in np.linspace(0, 1, steps):
        tool.move(QPointF(start[0] + t * (end[0] - start[0]), start[1] + t * (end[1] - start[1])))
    tool.release(QPointF(*end))


def test_full_supervised_workflow(ui):
    window, controller, app = ui
    session = controller.session
    assert len(session.colonies) == 33
    assert window.count_label.text() == "33"
    assert controller.mode == "ModifyGlobalParameters"          # opens in Detect automatically
    assert window.activity.entry_count() == 2                    # image loaded, detection
    snap(window, app, "01_detect")

    # Automatic phase: a settings change reruns detection after the debounce
    window.sense_row.field.setValue(1.0)
    controller.handle_backup_and_detection()                     # what the debounce timer calls
    loose = len(session.colonies)
    assert loose > 33 and window.count_label.text() == str(loose)
    controller.undo()
    assert len(session.colonies) == 33 and window.sense_row.value() == 0.9
    assert window.sense_row.slider.value() == round((0.9 - 0.01) / 0.025)

    # Delete colonies: click two, delete
    controller.dropdown_changed("DeleteIndividualColonies")
    tool = window.canvas.tool
    for center in session.colonies.centers[:2]:
        tool.release(QPointF(*center))
    assert window.selected_count_label.text() == "2"
    assert window.delete_one_button.text() == "Delete 2 colonies" and window.delete_one_button.isEnabled()
    snap(window, app, "02_delete_one")
    controller.delete_selected_colonies_button_pushed()
    assert len(session.colonies) == 31 and not window.delete_one_button.isEnabled()

    # Delete a region: box around the clump at the bottom
    controller.dropdown_changed("DeleteManyColonies")
    drag(window.canvas.tool, (118, 225), (168, 276))
    assert len(controller.selected_ids) >= 1
    snap(window, app, "03_delete_region")
    before = len(session.colonies)
    controller.delete_selected_colonies_button_pushed()
    assert len(session.colonies) < before

    # Add colonies: two circles on empty spots, with snap to edge on
    controller.dropdown_changed("AddIndividualColonies")
    window.contour_switch.setChecked(True)
    drag(window.canvas.tool, (245.5, 203.9), (259.9, 203.9))
    drag(window.canvas.tool, (81.5, 234.0), (91.5, 234.0))
    assert window.add_one_button.text() == "Add 2 colonies"
    snap(window, app, "04_add_one")
    before = len(session.colonies)
    controller.add_selected_colonies_button_pushed()
    assert len(session.colonies) == before + 2
    assert window.added_pill.text() == "Added 2"

    # Detect in a region: local settings change the preview only
    controller.dropdown_changed("AddManyColonies")
    drag(window.canvas.tool, (150, 150), (280, 289))
    window.sense_row.field.setValue(1.0)
    controller.update_region_detection()                          # what the region timer calls
    assert session.params.sense == 0.9                            # whole-image settings untouched
    snap(window, app, "05_add_region")
    if controller.candidates is not None and len(controller.candidates):
        before = len(session.colonies)
        controller.add_selected_colonies_button_pushed()
        assert len(session.colonies) > before

    # Undo everything, then redo everything
    edits = 0
    while session.can_undo():
        controller.undo()
        edits += 1
    assert len(session.colonies) == 33
    for _ in range(edits):
        controller.redo()

    controller.im_satisfied_pushed()
    snap(window, app, "06_finished")
    csv_files = list(controller.output_folder.glob("*.csv"))
    assert csv_files and csv_files[0].read_text().count("\n") == len(session.colonies) + 1


def test_mode_shortcut_buttons_and_status(ui):
    window, controller, app = ui
    window.mode_buttons["DeleteManyColonies"].click()
    assert controller.mode == "DeleteManyColonies"
    assert window.panels.currentWidget() is window.panel_pages["delete_region"]
    controller.handle_delete_click(1.0, 1.0)                       # nothing there
    assert window.status_text.text() == "No colony under the pointer"


def test_zoom_keeps_point_under_pointer(ui):
    window, controller, app = ui
    canvas = window.canvas
    pointer = QPointF(canvas.viewport().width() * 0.8, canvas.viewport().height() * 0.3)
    before = canvas.mapToScene(pointer.toPoint())
    for _ in range(4):
        canvas.zoom_at(pointer, canvas.ZOOM_STEP)
    after = canvas.mapToScene(pointer.toPoint())
    assert canvas.view_scale() > canvas._fit_scale * 1.5
    assert abs(after.x() - before.x()) < 1.0 and abs(after.y() - before.y()) < 1.0
    assert window.zoom_label.text().endswith("%")
    for _ in range(20):
        canvas.zoom_at(pointer, 1 / canvas.ZOOM_STEP)
    assert abs(canvas.view_scale() - canvas._fit_scale) < 1e-6        # stops at the whole plate


def test_drawn_circles_move_resize_remove_and_contour(ui):
    window, controller, app = ui
    controller.dropdown_changed("AddIndividualColonies")
    tool = window.canvas.tool
    colony = controller.session.colonies
    x, y, r = *colony.centers[5], colony.radii[5]
    controller.session.delete_colonies([colony.ids[5]])               # make room to re-add it

    drag(tool, (x - 1.6 * r, y), (x + 1.6 * r, y))                    # draw edge to edge
    assert len(controller.pending_circles) == 1
    drag(tool, (x, y), (x + 3, y + 2))                                # move (press inside)
    moved = controller.pending_circles[0]
    assert abs(moved.x - (x + 3)) < 1e-6 and abs(moved.y - (y + 2)) < 1e-6
    drag(tool, (moved.x + moved.r, moved.y), (moved.x + 2 * r, moved.y))   # resize (press on edge)
    assert abs(controller.pending_circles[0].r - 2 * r) < 1e-6
    drag(tool, (moved.x, moved.y), (x, y))                            # move back over the colony

    window.contour_switch.setChecked(True)                            # snap to edge on
    fitted = controller.pending_circles[0]
    assert fitted.contour is not None and fitted.contour.found
    assert fitted.contour.radius < fitted.r

    drag(tool, (20.0, 20.0), (25.0, 20.0))                            # second circle, then remove it
    assert len(controller.pending_circles) == 2
    tool.press(QPointF(20.0, 20.0), Qt.RightButton)
    assert len(controller.pending_circles) == 1

    before = len(controller.session.colonies)
    controller.add_selected_colonies_button_pushed()
    added = controller.session.colonies
    assert len(added) == before + 1 and added.boundaries[-1] is not None   # traced outline kept


def test_panels_show_only_what_applies(ui):
    window, controller, app = ui
    # Detect in a region: only the instruction until a box is drawn
    controller.dropdown_changed("AddManyColonies")
    assert window.region_intro.isVisible() and not window.parameter_controls.isVisible()
    assert not window.region_add_button.isVisible()
    drag(window.canvas.tool, (150, 150), (280, 289))
    assert window.parameter_controls.isVisible() and window.region_add_button.isVisible()
    assert not window.region_intro.isVisible()
    snap(window, app, "07_region_drawn")
    controller.clear_selection()                                   # Esc clears the region
    assert window.region_intro.isVisible() and controller.roi is None

    # Delete colonies: actions appear with the first selection
    controller.dropdown_changed("DeleteIndividualColonies")
    assert not window.delete_one_actions.isVisible()
    assert not window.legend_items["pending"].isVisible() and window.legend_items["selected"].isVisible()
    window.canvas.tool.release(QPointF(*controller.session.colonies.centers[0]))
    assert window.delete_one_actions.isVisible()

    # Delete a region: actions appear once a box exists, even an empty one
    controller.dropdown_changed("DeleteManyColonies")
    assert not window.delete_region_actions.isVisible()
    drag(window.canvas.tool, (1, 1), (4, 4))
    assert window.delete_region_actions.isVisible() and not window.delete_region_button.isEnabled()

    # Add colonies: move/resize help and Add appear with the first circle
    controller.dropdown_changed("AddIndividualColonies")
    assert not window.add_one_actions.isVisible()
    drag(window.canvas.tool, (60.0, 60.0), (66.0, 60.0))
    assert window.add_one_actions.isVisible()
    assert window.mode_chip_label.text() == window._spec.hint_active


def test_circle_drag_is_diameter_and_guide_shows_radius(ui):
    window, controller, app = ui
    controller.dropdown_changed("AddIndividualColonies")
    tool = window.canvas.tool
    tool.press(QPointF(92.0, 114.0))                                   # one edge
    tool.move(QPointF(108.0, 126.0))                                   # opposite edge: diameter 20
    circle = controller.pending_circles[0]
    assert (circle.x, circle.y) == (100.0, 120.0) and abs(circle.r - 10.0) < 1e-9
    assert tool.guide.shown and tool.guide.text.text().startswith("r 10.0 px")
    snap(window, app, "08_drawing_circle")
    tool.release(QPointF(108.0, 126.0))
    assert not tool.guide.shown and abs(controller.pending_circles[0].r - 10.0) < 1e-9


def test_columns_collapse_and_expand(ui):
    window, controller, app = ui
    canvas_width = window.canvas.width()
    window.set_left_collapsed(True, animate=False)
    window.set_right_collapsed(True, animate=False)
    app.processEvents()
    assert window.left_sidebar.width() == window.theme.style.layout.rail_width
    assert not window.panel_scroller.isVisible() and not window.right_sidebar.isVisible()
    assert all(b.compact for b in window.mode_buttons.values())
    assert window.canvas.width() > canvas_width + 400
    snap(window, app, "09_collapsed")
    window.mode_buttons["DeleteManyColonies"].click()               # the rail still switches modes
    assert controller.mode == "DeleteManyColonies"
    window.set_left_collapsed(False, animate=False)
    window.set_right_collapsed(False, animate=False)
    app.processEvents()
    assert window.panel_scroller.isVisible() and window.right_sidebar.isVisible()
    assert window.canvas.width() == canvas_width


def test_finish_commits_to_project_and_reopens_saved_result(app, tmp_path):
    settings_folder = tmp_path / "settings"
    window, controller = build(app, settings=Settings.load(settings_folder), library=create_library(tmp_path / "Lib"),
                               first_project=create_sample_project)
    session = controller.session
    session.delete_colonies(session.colonies.ids[:4])
    controller.im_satisfied_pushed()
    assert window.activity.entry_count() == 3 and not session.can_undo()
    manager = controller.data_manager
    index_id = session.record.index_id
    assert manager.project_info().indices[0].revision == 1
    assert len(manager.edit_log(index_id)) == 1
    manager.close()                                     # as on quit: releases the lock, leaves a backup

    # Next start: settings find the library, the last project opens with its committed result
    window2, controller2 = build(app, settings=Settings.load(settings_folder), first_project=create_sample_project)
    assert len(controller2.session.colonies) == 29 and controller2.session.loaded_revision == 1
    assert len(controller2.session.initial_state) == 33
    assert window2.count_label.text() == "29"
    assert len(controller2.data_manager.list_backups(controller2.data_manager.project_id)) == 1
    controller2.data_manager.close()


def test_library_setup_screen_checks_and_creates(app, tmp_path, monkeypatch):
    from quantacolony.data import DataManager
    from quantacolony.gui.library_setup import LibrarySetupController, LibrarySetupWindow
    from quantacolony.theme import apply_theme
    monkeypatch.setenv("OneDrive", str(tmp_path / "OneDrive - Lab"))
    manager = DataManager(Settings.load(tmp_path / "settings"))
    window = LibrarySetupWindow(apply_theme(app))
    controller = LibrarySetupController(manager, window)
    assert controller.mode == "setup" and window.create_button.isVisibleTo(window)

    controller.choose_folder(str(tmp_path / "OneDrive - Lab" / "Q"))          # synced folder: refused
    assert window.status.property("state") == "bad" and not window.create_button.isEnabled()
    busy = tmp_path / "Data"
    busy.mkdir()
    (busy / "notes.txt").write_text("x")
    controller.choose_folder(str(busy))                                      # non-empty: library goes inside
    assert controller.candidate == busy / "QuantaColony Library" and window.create_button.isEnabled()
    snap(window, app, "10_library_setup")
    controller.create_library()
    assert manager.library is not None and Settings.load(tmp_path / "settings").library_path

    # The library moves away: next start shows the missing screen; locating it restores the pointer
    moved = tmp_path / "Moved"
    manager.library.root.rename(moved)
    manager2 = DataManager(Settings.load(tmp_path / "settings"))
    window2 = LibrarySetupWindow(apply_theme(app))
    controller2 = LibrarySetupController(manager2, window2)
    assert controller2.mode == "missing" and window2.locate_button.isVisibleTo(window2)
    snap(window2, app, "11_library_missing")
    controller2.locate_library(str(moved))
    assert manager2.library.root == moved.resolve()
    assert Settings.load(tmp_path / "settings").library_path == str(moved.resolve())
