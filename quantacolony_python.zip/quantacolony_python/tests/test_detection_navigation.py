"""Colony Detection moves between indices: the index board, previous / next, unsaved edits, Finish image."""

import pytest
from PySide6.QtWidgets import QApplication

from quantacolony.core import cropping as cp
from quantacolony.data import DataManager, Settings, create_library, open_library
from quantacolony.data.demo_project import complete_demo_project
from quantacolony.gui.launch import open_detection
from quantacolony.theme import apply_theme


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture(scope="module")
def library(tmp_path_factory):
    root = tmp_path_factory.mktemp("navigation")
    manager = DataManager(Settings(folder=root / "settings"))
    manager.use_library(create_library(root / "Library"))
    complete_demo_project(manager)
    project_id = manager.project_id
    manager.close()
    return root, project_id


@pytest.fixture
def detection(app, library):
    root, project_id = library
    manager = DataManager(Settings(folder=root / "s"))
    manager.use_library(open_library(root / "Library"))
    manager.open_project(project_id)
    window, controller = open_detection(manager, apply_theme(app))
    yield window, controller
    window.close_guard = None
    window.close()
    manager.close()


def test_board_and_arrows(app, detection):
    window, controller = detection
    indices = controller.index_status()
    assert len(indices) == 96 and {state for _, _, state in indices} <= {"detected", "waiting", "review"}
    first = controller.session.record.index_id
    controller.step_index(1)
    assert controller.session.record.index_id == indices[[i for i, _, _ in indices].index(first) + 1][0]
    controller.step_index(-1)
    assert controller.session.record.index_id == first
    controller.show_index_board()
    board = window.index_popup().board.board
    cells = [cell for row in board.cells for cell in row]
    assert sum(cell.current for cell in cells) == 1
    assert all(cell.state == "detected" for cell in cells)
    target = next(cell.target for cell in cells if not cell.current)
    window.index_popup().board.cellClicked.emit(target)
    assert controller.session.record.index_id == target[0]
    assert "of 96" in window.image_picker.accessibleName()


def test_board_view_is_saved(detection):
    window, controller = detection
    passage = next(v for v in controller.variables if v.name == "passage")
    controller.show_index_board()
    controller.set_board_view(passage, cp.PAGES)
    assert window.index_popup().board.board.pages == ["Passage"]
    assert controller.data_manager.module_preferences("detection")["view"]["passage"] == cp.PAGES


def test_unsaved_edits_ask_before_leaving(detection, monkeypatch):
    window, controller = detection
    start = controller.session.record.index_id
    controller.session.delete_colonies(controller.session.colonies.ids[:2])
    monkeypatch.setattr(window, "ask_save_before_leaving", lambda name: "cancel")
    controller.step_index(1)
    assert controller.session.record.index_id == start
    monkeypatch.setattr(window, "ask_save_before_leaving", lambda name: "discard")
    controller.step_index(1)
    assert controller.session.record.index_id != start
    controller.open_index(start)
    controller.session.delete_colonies(controller.session.colonies.ids[:1])
    before = controller.session.loaded_revision
    monkeypatch.setattr(window, "ask_save_before_leaving", lambda name: "save")
    controller.step_index(1)
    controller.open_index(start)
    assert controller.session.loaded_revision == before + 1


def test_finish_opens_next_waiting(detection):
    window, controller = detection
    manager = controller.data_manager
    ids = [i for i, _, _ in controller.index_status()]
    start = controller.session.record.index_id
    later = ids[(ids.index(start) + 3) % len(ids)]
    manager._connection.execute("UPDATE detection SET needs_review = 1, review_reason = 'test' WHERE index_id = ?",
                                (later,))
    controller.im_satisfied_pushed()
    assert controller.session.record.index_id == later
