"""DataManager tests: project file, packets, commits, derived cache, regions, exports."""

import json
import sqlite3

import numpy as np
import pytest

from quantacolony.core.session import DetectionSession
from quantacolony.data import DataManager, ProjectError, Settings, create_library
from quantacolony.data.packets import Assignment, LevelSpec, VariableSpec
from quantacolony.data.regions import cut_region, outline_from_geometry
from quantacolony.data.sample_project import SAMPLE_FOLDER, create_sample_project, sample_image


@pytest.fixture()
def manager(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    create_sample_project(manager)
    yield manager
    manager.close()


def detect_and_edit(manager, delete=3):
    packet = manager.checkout_image(manager.first_index_for_detection())
    session = DetectionSession(packet.record, packet.defaults)
    session.initialize_detection()
    session.delete_colonies(session.colonies.ids[:delete])
    return session


def test_project_is_one_file_in_the_library(manager, tmp_path):
    info = manager.project_info()
    assert [v.type for v in info.variables] == ["nominal", "ordinal"]
    assert len(info.indices) == 1 and info.indices[0].has_region and info.indices[0].revision == 0
    files = sorted(p.name for p in manager.library.projects_folder.iterdir())
    assert files == [f"{info.project_id}.lock", f"{info.project_id}.qcproj"]
    assert manager.settings.last_project_id == info.project_id


def test_checkout_gives_crop_mask_scale_and_labels(manager):
    packet = manager.checkout_image(manager.first_index_for_detection())
    image, px_per_mm, params = sample_image()
    assert np.array_equal(packet.record.image, image) and packet.record.mask.all()
    assert packet.record.px_per_mm == px_per_mm and packet.defaults == params and packet.saved is None
    assert packet.record.ordinal_display == "Ordinal 25"


def test_commit_round_trip_keeps_colonies_baseline_and_edits(manager):
    session = detect_and_edit(manager)
    revision = manager.commit_detection(session.result())
    saved = manager.checkout_image(session.record.index_id).saved
    assert revision == saved.revision == 1
    assert np.array_equal(np.sort(saved.colonies.ids), np.sort(session.colonies.ids))
    assert np.allclose(saved.colonies.centers[np.argsort(saved.colonies.ids)],
                       session.colonies.centers[np.argsort(session.colonies.ids)])
    assert len(saved.baseline) == 33 and len(saved.colonies) == 30
    assert manager.edit_log(session.record.index_id)[0]["kind"] == "Deletion"
    assert manager.commit_detection(session.result()) == 2


def test_failed_commit_leaves_previous_truth(manager):
    session = detect_and_edit(manager)
    manager.commit_detection(session.result())
    broken = session.result()
    duplicated = broken.colonies.concat(broken.colonies.subset([0]))          # duplicate id
    with pytest.raises(ProjectError):
        manager.commit_detection(type(broken)(broken.index_id, broken.params, duplicated, broken.baseline,
                                              broken.edits, broken.detection_version))
    assert manager.checkout_image(broken.index_id).saved.revision == 1


def test_derived_cache_is_used_only_while_fingerprint_matches(manager):
    session = detect_and_edit(manager)
    index_id = session.record.index_id
    manager.commit_detection(session.result())
    first = manager.request_derived("colony_measurements", index_id)
    again = manager.request_derived("colony_measurements", index_id)
    assert not first.from_cache and again.from_cache and len(again.rows) == 30
    session.delete_colonies(session.colonies.ids[:1])
    manager.commit_detection(session.result())                              # new revision: cache cleared
    fresh = manager.request_derived("colony_measurements", index_id)
    assert not fresh.from_cache and len(fresh.rows) == 29


def test_region_change_after_detection_flags_review(manager):
    session = detect_and_edit(manager)
    index_id = session.record.index_id
    manager.commit_detection(session.result())
    flagged = manager.commit_assignments([Assignment(index_id, 1, "rectangle",
                                                     {"x": 9.5, "y": 9.5, "width": 200, "height": 200})])
    assert flagged == [index_id]
    packet = manager.checkout_image(index_id)
    assert packet.saved.needs_review and packet.record.image.shape[:2] == (200, 200)
    # Colonies are stored in photo pixels: the crop moved by 10 px, so they shift by -10 in the crop
    original = {int(i): c for i, c in zip(session.colonies.ids, session.colonies.centers)}
    moved = {int(i): c for i, c in zip(packet.saved.colonies.ids, packet.saved.colonies.centers)}
    some = next(iter(moved))
    assert np.allclose(moved[some], original[some] - 10)


def test_sector_region_masks_outside_pixels():
    photo = np.full((101, 101, 3), 200, np.uint8)
    outline = outline_from_geometry("sector", {"cx": 50, "cy": 50, "radius": 50, "start_deg": 0, "end_deg": 90})
    crop = cut_region(photo, outline)
    assert crop.offset == (50, 50)
    assert crop.mask[5, 5] and not crop.mask[-1, -1]                        # near the center vs outside the arc
    assert (crop.image[~crop.mask] == 0).all() and (crop.image[crop.mask] == 200).all()


def test_new_project_with_photo_and_two_indices(tmp_path):
    manager = DataManager(Settings(folder=tmp_path / "settings"))
    manager.use_library(create_library(tmp_path / "Library"))
    manager.create_project("Two", [
        VariableSpec("strain", "nominal", (LevelSpec("wt", "Wild type", True), LevelSpec("est2", "est2Δ"))),
        VariableSpec("day", "ordinal", (LevelSpec("d1", "1"),))], sample_image()[2])
    photo = manager.add_photo(SAMPLE_FOLDER / "rif1_cdc132_Figure_2_v25.png", 6.4)
    a = manager.add_index({"strain": "wt", "day": "d1"})
    b = manager.add_index({"strain": "est2", "day": "d1"})
    with pytest.raises(ProjectError):
        manager.add_index({"strain": "wt", "day": "d1"})                    # each index once
    manager.commit_assignments([
        Assignment(a, photo, "sector", {"cx": 140, "cy": 145, "radius": 140, "start_deg": 90, "end_deg": 270}),
        Assignment(b, photo, "sector", {"cx": 140, "cy": 145, "radius": 140, "start_deg": 270, "end_deg": 90})])
    left, right = manager.checkout_image(a).record, manager.checkout_image(b).record
    assert left.nominal_display == "Wild type" and right.nominal_display == "est2Δ"
    assert left.image.shape[1] < 160 and right.image.shape[1] < 160
    project_id = manager.project_id
    manager.close()
    assert manager.library.project_path(project_id).is_file()


def test_exports_carry_provenance_and_full_project(manager, tmp_path):
    session = detect_and_edit(manager)
    manager.commit_detection(session.result())
    csv_path = manager.export_colonies_csv(session.record.index_id)
    header = csv_path.read_text(encoding="utf-8").splitlines()[0].split(",")
    assert {"Condition", "Ordinal", "detection_revision", "software_version"} <= set(header)
    folder = manager.export_project(tmp_path / "export")
    data = json.loads((folder / "project.json").read_text(encoding="utf-8"))
    assert data["indices"][0]["revision"] == 1 and data["indices"][0]["edit_log"]
    assert any((folder / "photos").iterdir())
    index_folder = folder / "indices" / data["indices"][0]["name"]
    for name in ("crop.png", "colonies.png", "colonies.csv"):
        assert (index_folder / name).is_file()
    page = (folder / "index.html").read_text(encoding="utf-8")
    assert "colonies.png" in page and data["name"] in page
    summary = (folder / "summary.csv").read_text(encoding="utf-8").splitlines()
    assert len(summary) == 1 + len(data["indices"]) and "median_radius_um" in summary[0]


def test_import_rejects_other_files(manager, tmp_path):
    other = tmp_path / "notes.qcproj"
    other.write_text("not a database")
    with pytest.raises(ProjectError):
        manager.import_project_file(other)
    plain = tmp_path / "plain.qcproj"
    sqlite3.connect(plain).execute("CREATE TABLE x (y)").connection.close()
    with pytest.raises(ProjectError):
        manager.import_project_file(plain)


def test_looking_at_results_leaves_no_backup(manager):
    session = detect_and_edit(manager)
    manager.commit_detection(session.result())
    project_id = manager.project_id
    manager.close()                                               # a real change: one backup
    assert len(manager.list_backups(project_id)) == 1
    manager.open_project(project_id)
    manager._connection.execute("DELETE FROM derived_cache")      # as after an update to a measurement
    table = manager.request_derived("colony_measurements", session.record.index_id)
    assert not table.from_cache
    assert manager.request_derived("colony_measurements", session.record.index_id).from_cache
    manager.close()                                               # only a cache save: no new backup
    assert len(manager.list_backups(project_id)) == 1


def test_finished_settings_start_the_next_image(manager):
    index_id = manager.first_index_for_detection()
    packet = manager.checkout_image(index_id)
    assert packet.estimate is False                               # the sample project has fixed defaults
    session = DetectionSession(packet.record, packet.defaults.with_value("rmax", 11.0))
    session.initialize_detection()
    manager.commit_detection(session.result())
    start, estimate = manager.detection_start()
    assert start.rmax == 11.0 and not estimate
    assert manager.checkout_image(index_id).defaults.rmax == 11.0


def test_photo_size_and_thumbnail_are_stored(manager):
    photo = manager.crop_packet().photos[0]
    rows, cols = manager.photo_image(photo.photo_id).shape[:2]
    assert (photo.width, photo.height) == (cols, rows)
    assert manager.project_thumbnail(manager.project_id)[:4] == b"\x89PNG"
    entry = manager.list_projects()[0]
    assert entry.photo_count == 1 and entry.index_count >= 1 and entry.variable_count == 2


def test_older_files_gain_photo_sizes_when_opened(manager):
    project_id, path = manager.project_id, manager.project_path
    manager.close()
    old = sqlite3.connect(path)
    for column in ("thumbnail", "height", "width"):
        old.execute(f"ALTER TABLE photos DROP COLUMN {column}")
    old.execute("UPDATE project SET value = '2' WHERE key = 'schema_version'")
    old.commit()
    old.close()
    manager.open_project(project_id)
    assert manager.project_info().schema_version == 3
    photo = manager.crop_packet().photos[0]
    assert photo.width > 0 and photo.height > 0
    assert manager.project_thumbnail(project_id) is not None


def test_a_library_file_is_opened_not_imported(manager):
    assert manager.library_project_id(manager.project_path) == manager.project_id
    assert manager.library_project_id(manager.project_path.parent / "elsewhere.qcproj") is None


def test_browsable_copy_of_a_closed_project(manager, tmp_path):
    session = detect_and_edit(manager)
    manager.commit_detection(session.result())
    project_id = manager.project_id
    manager.close()
    folder = manager.export_browsable_copy(project_id, tmp_path / "look")
    assert (folder / "index.html").is_file() and not manager.is_open
